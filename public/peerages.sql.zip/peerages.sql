--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.0
-- Dumped by pg_dump version 9.5.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: administrations; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE administrations (
    number integer,
    prime_minister text NOT NULL,
    start_date date,
    end_date date,
    colour_code text,
    id integer NOT NULL
);


ALTER TABLE administrations OWNER TO michaelsmethurst;

--
-- Name: administrations_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE administrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE administrations_id_seq OWNER TO michaelsmethurst;

--
-- Name: administrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE administrations_id_seq OWNED BY administrations.id;


--
-- Name: announcement_types; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE announcement_types (
    name text,
    id integer NOT NULL
);


ALTER TABLE announcement_types OWNER TO michaelsmethurst;

--
-- Name: announcement_types_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE announcement_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE announcement_types_id_seq OWNER TO michaelsmethurst;

--
-- Name: announcement_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE announcement_types_id_seq OWNED BY announcement_types.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE announcements (
    announced_on date NOT NULL,
    in_gazette boolean,
    notes text,
    announcement_type_id integer,
    gazette_url character varying(255),
    id integer NOT NULL,
    administration_id integer
);


ALTER TABLE announcements OWNER TO michaelsmethurst;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE announcements_id_seq OWNER TO michaelsmethurst;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE announcements_id_seq OWNED BY announcements.id;


--
-- Name: genders; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE genders (
    id integer NOT NULL,
    label character varying(10) NOT NULL
);


ALTER TABLE genders OWNER TO michaelsmethurst;

--
-- Name: genders_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE genders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genders_id_seq OWNER TO michaelsmethurst;

--
-- Name: genders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE genders_id_seq OWNED BY genders.id;


--
-- Name: jurisdictions; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE jurisdictions (
    id integer NOT NULL,
    label character varying(100) NOT NULL
);


ALTER TABLE jurisdictions OWNER TO michaelsmethurst;

--
-- Name: jurisdictions_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE jurisdictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE jurisdictions_id_seq OWNER TO michaelsmethurst;

--
-- Name: jurisdictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE jurisdictions_id_seq OWNED BY jurisdictions.id;


--
-- Name: kingdom_ranks; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE kingdom_ranks (
    id integer NOT NULL,
    rank_id integer NOT NULL,
    kingdom_id integer NOT NULL
);


ALTER TABLE kingdom_ranks OWNER TO michaelsmethurst;

--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE kingdom_ranks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kingdom_ranks_id_seq OWNER TO michaelsmethurst;

--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE kingdom_ranks_id_seq OWNED BY kingdom_ranks.id;


--
-- Name: kingdoms; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE kingdoms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    start_on date,
    end_on date
);


ALTER TABLE kingdoms OWNER TO michaelsmethurst;

--
-- Name: kingdoms_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE kingdoms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kingdoms_id_seq OWNER TO michaelsmethurst;

--
-- Name: kingdoms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE kingdoms_id_seq OWNED BY kingdoms.id;


--
-- Name: law_lord_incumbencies; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE law_lord_incumbencies (
    appointed_on date NOT NULL,
    vice text,
    end_on date,
    notes text,
    old_office text,
    annuity_from date,
    annuity_london_gazette_issue integer,
    annuity_london_gazette_page integer,
    appointment_london_gazette_issue integer,
    appointment_london_gazette_page integer,
    id integer NOT NULL,
    peerage_id integer,
    jurisdiction_id integer
);


ALTER TABLE law_lord_incumbencies OWNER TO michaelsmethurst;

--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE law_lord_incumbencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE law_lord_incumbencies_id_seq OWNER TO michaelsmethurst;

--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE law_lord_incumbencies_id_seq OWNED BY law_lord_incumbencies.id;


--
-- Name: letters; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters (
    id integer NOT NULL,
    letter character varying(100) NOT NULL,
    url_key character(1) NOT NULL
);


ALTER TABLE letters OWNER TO michaelsmethurst;

--
-- Name: letters_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_id_seq OWNED BY letters.id;


--
-- Name: letters_patent_times; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters_patent_times (
    id integer NOT NULL,
    label character varying(20) NOT NULL
);


ALTER TABLE letters_patent_times OWNER TO michaelsmethurst;

--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_patent_times_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_patent_times_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_patent_times_id_seq OWNED BY letters_patent_times.id;


--
-- Name: letters_patents; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters_patents (
    id integer NOT NULL,
    patent_on date NOT NULL,
    person_prefix character varying(20),
    person_suffix character varying(20),
    previous_of_title boolean DEFAULT false,
    previous_title character varying(255),
    previous_rank character varying(255),
    ordinality_on_date integer,
    citations text,
    announcement_id integer,
    letters_patent_time_id integer,
    person_id integer,
    kingdom_id integer,
    previous_kingdom_id integer,
    reign_id integer
);


ALTER TABLE letters_patents OWNER TO michaelsmethurst;

--
-- Name: letters_patents_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_patents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_patents_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_patents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_patents_id_seq OWNED BY letters_patents.id;


--
-- Name: monarchs; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE monarchs (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    date_of_birth date,
    date_of_death date,
    wikidata_id character varying(20)
);


ALTER TABLE monarchs OWNER TO michaelsmethurst;

--
-- Name: monarchs_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE monarchs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE monarchs_id_seq OWNER TO michaelsmethurst;

--
-- Name: monarchs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE monarchs_id_seq OWNED BY monarchs.id;


--
-- Name: peerage_holdings; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerage_holdings (
    id integer NOT NULL,
    ordinality integer NOT NULL,
    start_on date,
    end_on date,
    notes character varying(2000),
    person_id integer NOT NULL,
    peerage_id integer NOT NULL,
    introduced_on date
);


ALTER TABLE peerage_holdings OWNER TO michaelsmethurst;

--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerage_holdings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerage_holdings_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerage_holdings_id_seq OWNED BY peerage_holdings.id;


--
-- Name: peerage_types; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerage_types (
    name text,
    id integer NOT NULL
);


ALTER TABLE peerage_types OWNER TO michaelsmethurst;

--
-- Name: peerage_types_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerage_types_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerage_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerage_types_id_seq OWNED BY peerage_types.id;


--
-- Name: peerages; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerages (
    title text,
    territorial_designation text,
    extinct_on date,
    last_number integer,
    notes text,
    id integer NOT NULL,
    peerage_type_id integer,
    rank_id integer,
    wikidata_id character varying(20),
    of_title boolean DEFAULT false,
    special_remainder_id integer,
    letters_patent_id integer,
    kingdom_id integer,
    letter_id integer
);


ALTER TABLE peerages OWNER TO michaelsmethurst;

--
-- Name: peerages_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerages_id_seq
    START WITH 2996
    INCREMENT BY 1
    MINVALUE 2996
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerages_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerages_id_seq OWNED BY peerages.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE people (
    id integer NOT NULL,
    forenames character varying(200) NOT NULL,
    surname character varying(100),
    date_of_birth date,
    date_of_death date,
    notes text,
    letter_id integer,
    gender_id integer,
    wikidata_id character varying(20),
    mnis_id character varying(20),
    rush_id character varying(20)
);


ALTER TABLE people OWNER TO michaelsmethurst;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE people_id_seq OWNER TO michaelsmethurst;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE people_id_seq OWNED BY people.id;


--
-- Name: rank_labels; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE rank_labels (
    id integer NOT NULL,
    label character varying(100) NOT NULL,
    rank_id integer NOT NULL,
    gender_id integer NOT NULL
);


ALTER TABLE rank_labels OWNER TO michaelsmethurst;

--
-- Name: rank_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE rank_labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rank_labels_id_seq OWNER TO michaelsmethurst;

--
-- Name: rank_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE rank_labels_id_seq OWNED BY rank_labels.id;


--
-- Name: ranks; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE ranks (
    degree integer,
    label character varying(100),
    id integer NOT NULL,
    is_peerage_rank boolean DEFAULT true
);


ALTER TABLE ranks OWNER TO michaelsmethurst;

--
-- Name: ranks_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE ranks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ranks_id_seq OWNER TO michaelsmethurst;

--
-- Name: ranks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE ranks_id_seq OWNED BY ranks.id;


--
-- Name: reigning_monarchs; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE reigning_monarchs (
    id integer NOT NULL,
    reign_id integer NOT NULL,
    monarch_id integer NOT NULL
);


ALTER TABLE reigning_monarchs OWNER TO michaelsmethurst;

--
-- Name: reigning_monarchs_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE reigning_monarchs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reigning_monarchs_id_seq OWNER TO michaelsmethurst;

--
-- Name: reigning_monarchs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE reigning_monarchs_id_seq OWNED BY reigning_monarchs.id;


--
-- Name: reigns; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE reigns (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    start_on date,
    end_on date,
    kingdom_id integer NOT NULL
);


ALTER TABLE reigns OWNER TO michaelsmethurst;

--
-- Name: reigns_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE reigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reigns_id_seq OWNER TO michaelsmethurst;

--
-- Name: reigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE reigns_id_seq OWNED BY reigns.id;


--
-- Name: special_remainders; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE special_remainders (
    id integer NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE special_remainders OWNER TO michaelsmethurst;

--
-- Name: special_remainders_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE special_remainders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE special_remainders_id_seq OWNER TO michaelsmethurst;

--
-- Name: special_remainders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE special_remainders_id_seq OWNED BY special_remainders.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY administrations ALTER COLUMN id SET DEFAULT nextval('administrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcement_types ALTER COLUMN id SET DEFAULT nextval('announcement_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements ALTER COLUMN id SET DEFAULT nextval('announcements_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY genders ALTER COLUMN id SET DEFAULT nextval('genders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY jurisdictions ALTER COLUMN id SET DEFAULT nextval('jurisdictions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks ALTER COLUMN id SET DEFAULT nextval('kingdom_ranks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdoms ALTER COLUMN id SET DEFAULT nextval('kingdoms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies ALTER COLUMN id SET DEFAULT nextval('law_lord_incumbencies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters ALTER COLUMN id SET DEFAULT nextval('letters_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patent_times ALTER COLUMN id SET DEFAULT nextval('letters_patent_times_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents ALTER COLUMN id SET DEFAULT nextval('letters_patents_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY monarchs ALTER COLUMN id SET DEFAULT nextval('monarchs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings ALTER COLUMN id SET DEFAULT nextval('peerage_holdings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_types ALTER COLUMN id SET DEFAULT nextval('peerage_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages ALTER COLUMN id SET DEFAULT nextval('peerages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people ALTER COLUMN id SET DEFAULT nextval('people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels ALTER COLUMN id SET DEFAULT nextval('rank_labels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY ranks ALTER COLUMN id SET DEFAULT nextval('ranks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigning_monarchs ALTER COLUMN id SET DEFAULT nextval('reigning_monarchs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns ALTER COLUMN id SET DEFAULT nextval('reigns_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY special_remainders ALTER COLUMN id SET DEFAULT nextval('special_remainders_id_seq'::regclass);


--
-- Data for Name: administrations; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY administrations (number, prime_minister, start_date, end_date, colour_code, id) FROM stdin;
34	Aberdeen	1852-12-19	\N	CCFFFF	1
17	Addington	1801-03-17	\N	CCCCFF	2
52	Asquith	1908-04-07	1916-12-07	FFCCCC	3
62	Attlee	1945-07-26	1951-10-26	FFCCCC	4
55	Baldwin (1)	1923-05-22	1924-01-22	CCFFFF	5
57	Baldwin (2)	1924-11-04	1929-06-05	CCFFFF	6
59	Baldwin (3)	1935-06-07	1937-05-28	CCFFFF	7
50	Balfour	1902-07-12	1905-12-05	CCCCFF	8
73	Blair	1997-05-02	2007-06-27	FFCCCC	9
54	Bonar Law	1922-10-23	1923-05-22	CCCCFF	10
70	Callaghan	1976-04-05	1979-05-04	FFFFCC	11
51	Campbell-Bannerman	1905-12-05	1908-04-07	FFFFCC	12
23	Canning	1827-04-10	1827-08-08	CCFFFF	13
60	Chamberlain	1937-05-28	1940-05-10	CCCCFF	14
61	Churchill (1)	1940-05-10	1945-07-26	CCFFFF	15
63	Churchill (2)	1951-10-26	1955-04-06	CCFFFF	16
33	Derby (1)	1852-02-23	\N	CCCCFF	17
36	Derby (2)	1858-02-20	\N	CCCCFF	18
39	Derby (3)	1866-06-28	1868-02-27	CCCCFF	19
40	Disraeli (1)	1868-02-27	1868-12-03	CCFFFF	20
42	Disraeli (2)	1874-02-20	1880-04-23	CCFFFF	21
66	Douglas-Home	1963-10-19	1964-10-16	CCCCFF	22
64	Eden	1955-04-06	1957-01-10	CCCCFF	23
41	Gladstone (1)	1868-12-03	1874-02-20	FFFFCC	24
43	Gladstone (2)	1880-04-23	1885-06-23	FFFFCC	25
45	Gladstone (3)	1886-02-01	1886-07-25	FFFFCC	26
47	Gladstone (4)	1892-08-15	1894-03-05	FFFFCC	27
24	Goderich	1827-08-31	\N	CCCCFF	28
19	Grenville	1806-02-11	\N	FFFFCC	29
26	Grey	1830-11-22	\N	CCCCFF	30
68	Heath	1970-06-19	1974-03-04	CCFFFF	31
22	Liverpool	1812-06-08	\N	CCCCFF	32
53	Lloyd George	1916-12-07	1922-10-23	FFFFCC	33
56	MacDonald (1)	1924-01-22	1924-11-04	FFCCCC	34
58	MacDonald (2)	1929-06-05	1935-06-07	FFCCCC	35
65	Macmillan	1957-01-10	1963-10-19	CCFFFF	36
72	Major	1990-11-28	1997-05-02	CCCCFF	37
27	Melbourne (1)	1834-07-16	\N	FFFFCC	38
30	Melbourne (2)	1835-04-18	\N	FFFFCC	39
35	Palmerston (1)	1855-02-06	\N	FFCCCC	40
37	Palmerston (2)	1859-06-12	1865-10-13	FFCCCC	41
29	Peel (1)	1834-12-10	\N	CCCCFF	42
31	Peel (2)	1841-08-30	\N	CCCCFF	43
21	Perceval	1809-10-04	1812-05-11	CCFFFF	44
16	Pitt (1)	1783-12-19	\N	CCFFFF	45
18	Pitt (2)	1804-05-10	1806-01-23	CCFFFF	46
20	Portland (2)	1807-03-31	\N	CCCCFF	47
48	Rosebery	1894-03-05	1895-06-25	FFCCCC	48
32	Russell (1)	1846-06-30	\N	FFFFCC	49
38	Russell (2)	1865-10-29	1866-06-28	FFFFCC	50
44	Salisbury (1)	1885-06-23	1886-02-01	CCFFFF	51
46	Salisbury (2)	1886-07-25	1892-08-15	CCFFFF	52
49	Salisbury (3)	1895-06-25	1902-07-12	CCFFFF	53
71	Thatcher	1979-05-04	1990-11-28	CCFFFF	54
25	Wellington (1)	1828-01-22	\N	CCFFFF	55
28	Wellington (2)	1834-11-17	\N	CCFFFF	56
67	Wilson (1)	1964-10-16	1970-06-19	FFCCCC	57
69	Wilson (2)	1974-03-04	1976-04-05	FFCCCC	58
74	Brown	2007-06-27	2010-05-11	FFFFCC	59
75	Cameron	2010-05-11	2016-07-13	CCFFFF	60
76	May	2016-07-13	2019-07-24	CCCCFF	61
77	Johnson	2019-07-24	\N	CCFFFF	62
\.


--
-- Name: administrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('administrations_id_seq', 62, true);


--
-- Data for Name: announcement_types; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY announcement_types (name, id) FROM stdin;
Appointments Commission list of Crossbench peers	1
Birthday Honours List	2
Coronation Honours List	3
Dissolution Honours List	4
London Gazette Notice	5
New Year Honours List	6
Office holder nominated by PM post 2001	7
Press Notice	8
Resignation Honours List	9
Times report	10
Victory Honours List	11
List of "Working Peers"	12
List of first appointments under Life Peerages Act 1958	13
\.


--
-- Name: announcement_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('announcement_types_id_seq', 13, true);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY announcements (announced_on, in_gazette, notes, announcement_type_id, gazette_url, id, administration_id) FROM stdin;
1919-04-29	f	\N	6	\N	4	33
1919-08-12	f	\N	2	\N	5	33
1920-01-01	f	\N	6	\N	6	33
1921-01-01	f	\N	6	\N	8	33
1921-06-04	f	\N	2	\N	9	33
1922-01-02	f	\N	6	\N	10	33
1922-06-03	f	\N	2	\N	11	33
1924-01-01	f	\N	6	\N	13	5
1924-02-08	f	\N	5	\N	14	34
1924-04-22	f	\N	5	\N	15	34
1924-05-30	f	\N	5	\N	16	34
1925-06-03	f	\N	2	\N	18	6
1926-01-01	f	\N	6	\N	19	6
1926-07-03	f	\N	2	\N	20	6
1927-01-01	f	\N	6	\N	21	6
1928-01-02	f	\N	6	\N	23	6
1928-06-04	f	\N	2	\N	24	6
1929-03-01	f	\N	5	\N	25	6
1929-06-03	f	\N	2	\N	26	6
1930-01-01	f	\N	6	\N	28	35
1930-06-03	f	\N	2	\N	29	35
1931-01-01	f	\N	6	\N	30	35
1931-11-17	t	\N	5	\N	31	35
1932-06-03	f	\N	2	\N	33	35
1933-01-02	f	\N	6	\N	34	35
1933-06-03	f	\N	2	\N	35	35
1934-01-01	f	\N	6	\N	36	35
1934-10-09	t	\N	5	\N	38	35
1935-01-01	f	\N	6	\N	39	35
1935-06-03	f	\N	2	\N	40	35
1936-01-01	f	\N	6	\N	41	7
1937-02-01	f	\N	6	\N	43	7
1937-05-11	f	\N	3	\N	44	7
1937-05-28	f	\N	5	\N	45	14
1938-01-01	f	\N	6	\N	46	14
1939-01-02	f	\N	6	\N	48	14
1939-06-08	f	\N	2	\N	49	14
1940-06-13	f	\N	8	\N	50	15
1941-01-01	f	\N	6	\N	51	15
1941-12-22	f	\N	8	\N	53	15
1942-01-01	f	\N	6	\N	54	15
1942-06-11	f	\N	2	\N	55	15
1943-01-01	f	\N	6	\N	56	15
1944-01-01	f	\N	6	\N	58	15
1944-06-08	f	\N	2	\N	59	15
1945-01-01	f	\N	6	\N	60	15
1945-06-08	f	\N	4	\N	61	15
1945-08-14	f	\N	4	\N	63	4
1945-08-17	f	\N	4	\N	64	4
1946-01-01	f	\N	6	\N	65	4
1946-06-13	f	\N	2	\N	66	4
1947-06-12	f	\N	2	\N	68	4
1948-01-01	f	\N	6	\N	69	4
1948-06-10	f	\N	2	\N	70	4
1949-01-01	f	\N	6	\N	71	4
1950-01-02	f	\N	6	\N	73	4
1950-06-08	f	\N	2	\N	74	4
1951-01-01	f	\N	6	\N	75	4
1951-06-07	f	\N	2	\N	76	4
1952-01-01	f	\N	6	\N	78	16
1952-06-05	f	\N	2	\N	79	16
1953-01-01	f	\N	6	\N	80	16
1953-06-01	f	\N	3	\N	81	16
1954-06-10	f	\N	2	\N	83	16
1955-01-01	f	\N	6	\N	84	16
1955-06-09	f	\N	2	\N	85	23
1956-01-01	f	\N	6	\N	86	23
1957-01-01	f	\N	6	\N	88	23
1957-06-13	f	\N	2	\N	89	36
1958-01-01	f	\N	6	\N	90	36
1958-06-12	f	\N	2	\N	91	36
1959-01-23	f	\N	5	\N	93	36
1959-06-13	f	\N	2	\N	94	36
1959-09-19	f	\N	4	\N	95	36
1960-01-01	f	\N	6	\N	96	36
1960-12-31	f	\N	6	\N	98	36
1961-01-16	f	\N	12	\N	99	36
1961-06-10	f	\N	2	\N	100	36
1962-01-01	f	\N	6	\N	101	36
1962-06-02	f	\N	2	\N	103	36
1963-01-01	f	\N	6	\N	104	36
1963-06-08	f	\N	2	\N	105	36
1963-10-22	f	\N	9	\N	106	22
1964-01-01	f	\N	6	\N	108	22
1964-03-31	f	\N	8	\N	109	22
1964-05-05	f	\N	8	\N	110	22
1964-06-13	f	\N	2	\N	111	22
1964-08-05	f	\N	5	\N	113	22
1964-12-01	f	\N	4	\N	114	57
1964-12-04	f	\N	4	\N	115	57
1965-01-01	f	\N	6	\N	116	57
1965-05-01	f	\N	12	\N	118	57
1965-06-12	f	\N	2	\N	119	57
1966-01-01	f	\N	6	\N	120	57
1966-05-19	f	\N	4	\N	121	57
1967-01-01	f	\N	6	\N	123	57
1967-06-10	f	\N	2	\N	124	57
1967-08-03	f	\N	12	\N	125	57
1967-08-28	f	\N	8	\N	126	57
1968-01-01	f	\N	6	\N	128	57
1968-05-01	f	\N	8	\N	129	57
1968-05-31	f	\N	2	\N	130	57
1968-07-25	f	\N	8	\N	131	57
1969-01-01	f	\N	6	\N	133	57
1969-01-31	f	\N	8	\N	134	57
1969-06-14	f	\N	2	\N	135	57
1970-01-01	f	\N	6	\N	136	57
1970-06-13	f	\N	2	\N	138	31
1970-06-20	f	\N	8	\N	139	31
1970-08-07	f	\N	4	\N	140	31
1971-01-01	f	\N	6	\N	141	31
1971-02-18	f	\N	8	\N	143	31
1971-02-27	f	\N	8	\N	144	31
1971-04-08	f	\N	5	\N	145	31
1971-06-12	f	\N	2	\N	146	31
1972-01-03	f	\N	8	\N	148	31
1972-03-30	f	\N	5	\N	149	31
1972-06-03	f	\N	2	\N	150	31
1973-01-01	f	\N	6	\N	151	31
1973-05-31	f	\N	5	\N	153	31
1974-01-01	f	\N	6	\N	154	31
1974-01-02	f	\N	6	\N	155	31
1974-03-05	f	\N	8	\N	156	58
1918-06-03	f	\N	2	\N	3	33
1974-04-11	f	\N	5	\N	160	58
1974-05-24	f	\N	5	\N	161	58
1974-06-15	f	\N	2	\N	162	58
1974-11-07	f	\N	8	\N	164	58
1974-11-25	f	\N	8	\N	165	58
1974-12-06	f	\N	4	\N	166	58
1975-01-01	f	\N	6	\N	167	58
1975-08-07	f	\N	8	\N	169	58
1975-12-18	f	\N	12	\N	170	58
1976-01-01	f	\N	6	\N	171	58
1976-02-04	f	\N	8	\N	172	58
1976-06-12	f	\N	2	\N	174	11
1976-09-10	f	\N	8	\N	175	11
1976-10-27	f	\N	8	\N	176	11
1976-12-31	f	\N	6	\N	177	11
1977-12-31	f	\N	6	\N	179	11
1978-03-21	f	\N	12	\N	180	11
1978-06-03	f	\N	2	\N	181	11
1978-12-30	f	\N	6	\N	182	11
1979-06-05	f	\N	8	\N	184	54
1979-06-15	f	\N	4	\N	185	54
1979-06-26	f	\N	2	\N	186	54
1980-01-08	f	\N	6	\N	187	54
1980-12-31	f	\N	6	\N	189	54
1981-04-14	f	\N	12	\N	190	54
1981-06-13	f	\N	2	\N	191	54
1981-12-31	f	\N	6	\N	192	54
1982-06-12	f	\N	2	\N	194	54
1982-07-16	f	\N	8	\N	195	54
1982-10-11	f	\N	11	\N	196	54
1982-12-15	f	\N	12	\N	197	54
1983-06-11	f	\N	2	\N	199	54
1983-07-22	f	\N	4	\N	200	54
1983-12-31	f	\N	6	\N	201	54
1984-12-31	f	\N	6	\N	202	54
1985-06-15	f	\N	2	\N	204	54
1985-12-31	f	\N	6	\N	205	54
1986-06-14	f	\N	2	\N	206	54
1986-12-31	f	\N	6	\N	207	54
1987-06-13	f	\N	2	\N	209	54
1987-07-30	f	\N	4	\N	210	54
1987-07-31	f	\N	4	\N	211	54
1987-12-31	f	\N	6	\N	212	54
1988-11-18	f	\N	5	\N	214	54
1988-12-31	f	\N	6	\N	215	54
1989-06-17	f	\N	2	\N	216	54
1989-12-30	f	\N	6	\N	217	54
1990-06-16	f	\N	2	\N	219	54
1990-12-21	f	\N	9	\N	220	37
1990-12-31	f	\N	6	\N	221	37
1991-04-30	f	\N	12	\N	222	37
1991-06-29	f	\N	11	\N	224	37
1991-09-23	f	\N	8	\N	225	37
1991-12-31	f	\N	6	\N	226	37
1992-03-23	f	\N	8	\N	227	37
1992-04-14	f	\N	8	\N	229	37
1992-06-06	f	\N	4	\N	230	37
1992-06-13	f	\N	2	\N	231	37
1992-06-13	f	\N	12	\N	232	37
1992-12-31	f	\N	6	\N	234	37
1993-06-12	f	\N	2	\N	235	37
1993-07-22	f	\N	8	\N	236	37
1993-08-13	f	\N	12	\N	237	37
1994-06-11	f	\N	2	\N	239	37
1994-07-27	f	\N	8	\N	240	37
1994-08-20	f	\N	12	\N	241	37
1994-12-16	f	\N	8	\N	242	37
1995-01-23	f	\N	8	\N	244	37
1995-06-17	f	\N	2	\N	245	37
1995-11-08	f	\N	8	\N	246	37
1995-11-18	f	\N	12	\N	247	37
1995-12-30	f	\N	6	\N	249	37
1996-06-03	f	\N	8	\N	250	37
1996-06-15	f	\N	2	\N	251	37
1996-07-19	f	\N	8	\N	252	37
1996-11-29	f	\N	8	\N	254	37
1996-12-31	f	\N	6	\N	255	37
1997-04-19	f	\N	4	\N	256	37
1997-05-05	f	\N	8	\N	257	9
1997-06-14	f	\N	2	\N	259	9
1997-08-02	f	\N	9	\N	260	9
1997-08-02	f	\N	12	\N	261	9
1997-10-31	f	\N	5	\N	262	9
1998-06-13	f	\N	2	\N	264	9
1998-06-20	f	\N	12	\N	265	9
1998-08-03	f	\N	8	\N	266	9
1998-12-31	f	\N	6	\N	267	9
1999-06-19	f	\N	8	\N	269	9
1999-06-19	f	\N	12	\N	270	9
1999-08-24	f	\N	8	\N	271	9
1999-11-02	f	\N	8	\N	272	9
2000-03-31	f	\N	12	\N	274	9
2000-04-18	f	\N	8	\N	275	9
2000-08-15	f	\N	8	\N	276	9
2000-10-24	f	\N	8	\N	277	9
2001-06-11	f	Morgan apptd Minister	8	\N	281	9
2001-04-26	f	Guthrie	8	\N	279	\N
1881-11-17	t	\N	5	\N	1	25
1912-01-01	f	\N	6	\N	2	3
1920-06-03	f	\N	5	\N	7	33
1923-06-29	f	\N	2	\N	12	5
1925-01-01	f	\N	6	\N	17	6
1927-06-03	f	\N	2	\N	22	6
1929-06-28	t	\N	5	\N	27	35
1932-01-01	f	\N	6	\N	32	35
1934-06-04	f	\N	2	\N	37	35
1936-06-23	f	\N	2	\N	42	7
1938-06-09	f	\N	2	\N	47	14
1941-06-12	f	\N	2	\N	52	15
1943-06-02	f	\N	2	\N	57	15
1947-01-01	f	\N	6	\N	67	4
1949-06-09	f	\N	2	\N	72	4
1951-11-30	f	\N	4	\N	77	16
1954-01-01	f	\N	6	\N	82	16
1956-05-31	f	\N	2	\N	87	23
1959-01-01	f	\N	6	\N	92	36
1960-06-11	f	\N	2	\N	97	36
1962-03-29	f	\N	5	\N	102	36
1963-12-23	f	\N	5	\N	107	22
1964-07-27	f	\N	8	\N	112	22
1965-05-01	f	\N	5	\N	117	57
1966-06-11	f	\N	2	\N	122	57
1974-04-05	f	\N	4	\N	159	58
1945-06-14	f	\N	2	\N	62	15
2001-06-02	t	Pre-election dissolution list	4	\N	280	9
1967-11-16	f	\N	5	\N	127	57
1968-08-14	f	\N	8	\N	132	57
1970-06-02	f	\N	5	\N	137	31
1971-01-26	f	\N	8	\N	142	31
1971-07-09	f	\N	8	\N	147	31
1973-02-08	f	\N	8	\N	152	31
1974-03-08	f	\N	8	\N	157	58
1974-03-11	f	\N	8	\N	158	58
1974-08-01	f	\N	8	\N	163	58
1975-06-14	f	\N	2	\N	168	58
1976-06-02	f	\N	9	\N	173	11
1977-06-11	f	\N	2	\N	178	11
1979-05-07	f	\N	8	\N	183	54
1980-06-14	f	\N	2	\N	188	54
1982-02-24	f	\N	8	\N	193	54
1982-12-31	f	\N	6	\N	198	54
1985-04-03	f	\N	12	\N	203	54
1987-02-13	f	\N	12	\N	208	54
1988-06-11	f	\N	2	\N	213	54
1990-04-05	f	\N	12	\N	218	54
1991-06-15	f	\N	2	\N	223	37
1992-04-11	f	\N	8	\N	228	37
1992-09-10	f	\N	8	\N	233	37
1993-12-31	f	\N	6	\N	238	37
1994-12-31	f	\N	6	\N	243	37
1995-11-27	f	\N	8	\N	248	37
1996-08-21	f	\N	12	\N	253	37
1997-05-07	f	\N	8	\N	258	9
1997-12-31	f	\N	6	\N	263	9
1999-06-12	f	\N	2	\N	268	9
1999-12-31	f	\N	6	\N	273	9
2001-04-26	f	Appointments Commission 1st list	1	\N	278	9
1849-09-10	f	\N	5	\N	282	49
1905-12-30	f	\N	10	\N	283	12
1909-01-28	f	\N	10	\N	284	3
1958-07-24	f	\N	13	\N	285	36
1997-07-14	f	\N	10	\N	286	9
2001-04-26	f	\N	7	\N	287	9
2001-09-11	f	\N	12	\N	288	9
2002-07-30	f	\N	8	\N	289	9
2002-05-28	f	\N	7	\N	290	9
2003-05-09	f	\N	7	\N	292	9
2003-05-02	f	\N	7	\N	293	9
2003-12-19	f	\N	8	\N	294	9
2004-05-01	f	\N	12	\N	295	9
2004-05-01	f	\N	7	\N	297	9
2003-12-11	f	\N	8	\N	298	9
2004-10-30	f	\N	8	\N	299	9
2005-01-25	f	\N	7	\N	300	9
2005-05-09	f	\N	8	\N	302	9
2005-03-22	f	\N	1	\N	303	9
2005-05-13	f	\N	4	\N	304	9
2005-07-22	f	\N	1	\N	305	9
2005-07-28	f	\N	7	\N	307	9
2006-03-21	f	\N	8	\N	308	9
2006-03-07	f	\N	7	\N	309	9
2006-04-11	f	\N	8	\N	310	9
2012-05-17	f	\N	1	\N	312	60
2012-09-04	f	\N	8	\N	313	60
2012-12-26	f	\N	7	\N	314	60
2013-01-10	f	\N	8	\N	315	60
2013-06-19	f	\N	8	\N	317	60
2013-08-01	f	\N	8	\N	318	60
2006-11-24	f	\N	7	\N	319	9
2006-12-13	f	\N	8	\N	320	9
2007-06-28	f	\N	8	\N	322	59
2007-06-29	f	\N	8	\N	323	59
2007-07-24	f	\N	7	\N	324	59
2007-09-13	f	\N	8	\N	325	59
2008-04-18	f	\N	1	\N	327	59
2008-05-22	f	\N	5	\N	328	59
2008-09-04	f	\N	5	\N	329	59
2008-10-03	f	\N	8	\N	330	59
2008-09-29	f	\N	1	\N	332	59
2009-01-14	f	\N	8	\N	333	59
2009-04-15	f	\N	8	\N	334	59
2009-06-02	f	\N	8	\N	335	59
2009-07-20	f	\N	8	\N	337	59
2009-07-13	f	\N	1	\N	338	59
2010-02-05	f	\N	1	\N	339	59
2006-05-26	f	\N	7	\N	340	9
2010-05-28	f	\N	8	\N	342	60
2014-10-21	f	\N	7	\N	343	60
2015-02-26	f	\N	7	\N	344	60
2015-05-11	f	\N	8	\N	345	60
2010-05-18	f	\N	8	\N	347	60
2010-05-19	f	\N	8	\N	348	60
2015-05-29	f	\N	8	\N	349	60
2015-08-27	f	\N	8	\N	350	60
2010-07-22	f	\N	8	\N	352	60
2010-10-05	f	\N	1	\N	353	60
2010-09-07	f	\N	8	\N	354	60
2010-10-21	f	\N	8	\N	355	60
2010-10-27	f	\N	7	\N	357	60
2011-04-29	f	\N	8	\N	358	60
2011-09-05	f	\N	1	\N	359	60
2014-08-08	f	\N	8	\N	360	60
2016-02-10	f	\N	8	\N	362	60
2016-08-04	f	\N	9	\N	363	61
2018-05-18	f	\N	8	\N	364	61
2016-08-04	f	\N	7	\N	365	61
2017-09-28	f	\N	8	\N	367	61
2017-10-12	f	\N	7	\N	368	61
2014-01-24	f	\N	7	\N	369	60
2018-06-08	f	\N	1	\N	370	61
2018-10-24	f	\N	8	\N	372	61
2019-09-10	f	\N	9	\N	373	62
2019-09-10	f	\N	8	\N	374	62
2019-09-10	f	\N	7	\N	375	62
2019-12-19	f	\N	8	\N	377	62
2019-07-24	f	\N	8	\N	378	61
2020-03-18	f	\N	8	\N	379	62
2020-07-31	f	\N	4	\N	380	62
2020-06-28	f	\N	8	\N	382	62
2020-12-22	f	\N	8	\N	383	62
2020-12-23	f	\N	8	\N	384	62
2020-12-22	f	\N	7	\N	385	62
2021-04-29	f	\N	7	\N	387	62
1963-10-21	f	\N	10	\N	388	22
2003-10-21	f	\N	8	\N	389	9
2012-10-11	f	\N	7	\N	390	60
2013-09-26	f	\N	7	\N	392	60
2002-09-13	f	\N	7	\N	291	9
2004-05-01	f	\N	1	\N	296	9
2005-01-31	f	\N	7	\N	301	9
2005-07-22	f	\N	8	\N	306	9
2006-05-03	f	\N	1	\N	311	9
2013-02-27	f	\N	1	\N	316	60
2007-02-15	f	\N	1	\N	321	9
2007-10-18	f	\N	1	\N	326	59
2008-10-05	f	\N	8	\N	331	59
2009-06-08	f	\N	8	\N	336	59
2006-07-21	f	\N	7	\N	341	9
2015-05-14	f	\N	8	\N	346	60
2010-05-28	f	\N	7	\N	351	60
2010-11-19	f	\N	8	\N	356	60
2015-10-13	f	\N	1	\N	361	60
2017-06-20	f	\N	8	\N	366	61
2018-05-19	f	\N	8	\N	371	61
2019-12-16	f	\N	8	\N	376	62
2020-07-31	f	\N	8	\N	381	62
2021-02-24	f	\N	1	\N	386	62
2009-04-08	f	\N	8	\N	391	59
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('announcements_id_seq', 392, true);


--
-- Data for Name: genders; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY genders (id, label) FROM stdin;
1	Male
2	Female
\.


--
-- Name: genders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('genders_id_seq', 2, true);


--
-- Data for Name: jurisdictions; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY jurisdictions (id, label) FROM stdin;
1	Scotland
2	Ireland
3	England and Wales
4	Northern Ireland
\.


--
-- Name: jurisdictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('jurisdictions_id_seq', 4, true);


--
-- Data for Name: kingdom_ranks; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY kingdom_ranks (id, rank_id, kingdom_id) FROM stdin;
1	6	1
2	6	2
3	6	3
4	6	4
5	6	5
6	8	1
7	8	3
8	8	4
9	8	5
10	9	1
11	9	2
12	9	3
13	9	4
14	9	5
15	12	1
16	12	2
17	12	3
18	12	4
19	12	5
20	4	1
21	4	2
22	4	3
23	4	4
24	4	5
25	11	1
26	11	2
27	11	3
28	11	4
29	11	5
30	14	2
\.


--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('kingdom_ranks_id_seq', 30, true);


--
-- Data for Name: kingdoms; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY kingdoms (id, name, start_on, end_on) FROM stdin;
1	Kingdom of England	\N	1707-05-01
2	Kingdom of Scotland	\N	1707-05-01
3	Kingdom of Ireland	\N	1801-01-01
4	Kingdom of Great Britain	1707-05-01	1801-01-01
5	United Kingdom	1801-01-01	\N
\.


--
-- Name: kingdoms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('kingdoms_id_seq', 5, true);


--
-- Data for Name: law_lord_incumbencies; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY law_lord_incumbencies (appointed_on, vice, end_on, notes, old_office, annuity_from, annuity_london_gazette_issue, annuity_london_gazette_page, appointment_london_gazette_issue, appointment_london_gazette_page, id, peerage_id, jurisdiction_id) FROM stdin;
1880-04-28	L Gordon of Drumearn deceased	\N	\N	MP, Lord Advocate	\N	\N	\N	24838	2725	3	433	1
1882-06-23	\N	\N	\N	J (Queen's Bench Division, Ireland)	\N	\N	\N	25119	2848	4	456	2
1887-01-25	L Blackburn resigned	\N	\N	QC MP	\N	\N	\N	25669	533	5	503	3
1889-12-05	L FitzGerald deceased	1900-05-09	\N	LCJ(I)	1900-05-10	27193	3142	25999	7014	6	519	3
1891-01-28	\N	1893-09-02	\N	President of the PDA Division	\N	26438	5056	26130	561	7	524	3
1893-09-23	L Hannen	\N	\N	LJ	\N	\N	\N	26444	5431	8	556	3
1894-05-07	L Bowen	1894-07-02	Appointed LCJ 3 July 1894	Attorney-General	\N	\N	\N	26511	2783	9	559	3
1894-08-13	\N	\N	\N	\N	\N	\N	\N	26543	4808	10	560	3
1899-11-14	L Watson deceased	\N	\N	\N	\N	\N	\N	27135	6814	11	605	1
1900-05-10	L Morris resigned	1905-12-01	\N	\N	1905-12-02	27860	8737	27192	3070	12	608	3
1913-10-14	\N	1932-04-05	appointed pursuant to 1913 Act	\N	1932-04-06	33815	2289	28765	7241	13	636	1
1905-12-19	L Lindley resigned	1928-02-08	\N	AG in Ireland	\N	\N	\N	27866	9173	14	642	3
1907-03-06	L Davey deceased	1910-10-06	\N	MR	1910-10-07	28425	7321	28002	1663	15	669	3
1910-10-07	L Collins resigned	\N	MP on appointment	\N	1912-08-01	28636	6099	28425	7321	17	701	3
1912-10-01	L Robson	\N	\N	LJ	\N	\N	\N	28650	7291	18	732	3
1913-03-04	L Macnaghten	\N	\N	J	\N	\N	\N	28697	1756	19	736	3
1913-10-20	\N	1930-01-26	appointed pursuant to 1913 Act	LJ	1930-01-27	33575	645	28766	7335	20	737	3
1919-01-15	\N	\N	\N	\N	\N	\N	\N	31123	714	21	819	3
1923-10-12	Cave	1937-04-26	\N	LJ	1937-04-27	34400	3296	32880	7852	23	901	3
1928-02-06	L Atkinson	\N	\N	LJ	\N	\N	\N	33356	1045	24	940	3
1929-02-11	\N	\N	appointed under 1929 Act	J	\N	\N	\N	33466	1039	25	949	3
1929-05-01	L Shaw	\N	\N	Lord Advocate	\N	\N	\N	33491	2919	26	953	1
1929-11-18	L Carson	1946-01-05	\N	LJ	1946-01-06	37432	459	33553	7453	27	974	3
1941-07-18	\N	1947-01-05	\N	\N	1947-01-06	37855	341	35225	4212	29	981	1
1932-04-11	V Dunedin	\N	\N	J	\N	\N	\N	33816	23917	30	1000	3
1937-04-27	\N	1947-04-05	\N	MR	1947-04-06	37940	1825	34392	2713	31	1000	3
1935-10-07	L Tomlin	\N	\N	LJ	\N	\N	\N	34208	6470	32	1041	3
1935-10-14	L Wright	1938-01-04	\N	LJ	1938-01-05	34476	512	34209	6541	33	1042	3
1938-01-05	L Roche	1944-04-05	\N	LJ	1944-04-06	36496	2013	34472	189	34	1079	3
1938-03-28	Maugham	1954-10-15	\N	J	\N	\N	\N	34497	2083	35	1086	3
1939-10-05	\N	\N	\N	\N	\N	\N	\N	34705	6794	36	1101	3
1949-06-01	\N	1950-05-05	\N	MR	1950-05-06	38914	2432	38627	2748	37	1119	3
1944-04-18	L Romer	1951-10-30	resigned on appointment as Lord Chancellor	J	\N	\N	\N	36481	1841	38	1145	3
1944-07-19	L Atkin	1946-01-21	\N	LJ	\N	\N	\N	36620	3415	39	1149	3
1946-01-09	L Russell of Killowen	\N	\N	J	\N	\N	\N	37429	415	40	1189	3
1946-02-05	L Goddard	\N	\N	LJ	\N	\N	\N	37461	863	41	1198	3
1947-01-06	L Macmillan	1953-10-05	\N	Lord Justice General	1953-10-06	39988	5497	37849	225	42	1215	1
1947-04-15	\N	1957-04-05	\N	LJ	1957-04-06	41082	3181	37934	1721	43	1216	3
1947-04-18	Admin of Justice Act 1947	1959-04-05	\N	LJ	1959-04-06	41676	2264	37938	1775	44	1226	3
1947-04-23	L Wright	1951-04-06	\N	J(NI)	\N	\N	\N	37940	1825	45	1227	4
1948-10-06	L Thankerton	1975-01-10	\N	KC, ex-Lord Advocate	\N	\N	\N	38425	5331	46	1243	1
1949-06-01	L du Parcq	1964-09-30	\N	KC	1964-10-01	43461	8651	38627	2748	47	1247	3
1950-09-29	L Greene	1961-10-05	\N	LJ	\N	\N	\N	39047	5243	48	1266	3
1951-04-23	L MacDermott	\N	\N	LJ	\N	\N	\N	39212	2327	49	1269	3
1951-11-12	L Simonds	1960-09-30	\N	LJ	1960-10-01	42159	6701	39382	5919	50	1273	3
1953-11-04	L Normand	1961-01-05	\N	Senator of the College of Justice	\N	\N	\N	40008	5921	51	1298	1
1954-10-04	L Asquith of Bishopstone	1960-01-05	\N	LJ	1960-01-06	41933	551	\N	\N	52	1310	3
1954-10-19	\N	1962-03-31	\N	ex-Lord Chancellor	1962-04-01	42641	2803	\N	\N	53	1311	3
1962-04-19	\N	1965-01-10	\N	MR	1965-01-11	43562	1009	42654	3277	54	1331	3
1959-04-06	L Morton of Henryton	1963-11-16	\N	LJ	1963-11-17	43180	10099	41676	2264	56	1374	3
1960-01-07	L Somervell of Harrow	1975-01-10	\N	LJ	\N	\N	\N	41924	251	57	1385	3
1960-10-01	L Cohen	1971-04-19	\N	LJ	\N	\N	\N	42159	6701	58	1399	3
1961-10-11	L Tucker	1964-01-10	\N	LJ	1964-01-11	43237	1061	42486	7353	60	1420	3
1962-04-19	L Denning appointed MR	1969-06-02	\N	LJ	\N	\N	\N	42654	3277	61	1429	3
1963-11-26	L Jenkins	\N	\N	LJ	\N	\N	\N	43169	9713	62	1450	3
1964-01-11	L Devlin	\N	\N	LJ	\N	\N	\N	43219	385	63	1452	3
1964-10-01	V Radcliffe	1982-03-10	\N	J	\N	\N	\N	43451	8292	64	1477	3
1969-06-09	\N	1980-07-31	\N	ex-Lord Chancellor	\N	\N	\N	44872	6025	65	1482	3
1965-02-18	L Evershed	1974-09-30	\N	LJ	\N	\N	\N	43580	1759	66	1510	3
1968-09-30	no one	\N	\N	LJ	\N	\N	\N	44687	10537	67	1596	3
1971-03-12	L Upjohn	1975-09-30	\N	LJ	\N	\N	\N	45323	2278	69	1636	3
1971-10-04	L Guest	1976-12-31	\N	Senator of the College of Justice	\N	\N	\N	45489	10769	70	1647	1
1972-01-10	L Donovan	1980-09-30	\N	LJ	\N	\N	\N	45572	449	71	1648	3
1974-10-01	L Pearson	1981-09-30	\N	LJ	\N	\N	\N	46361	8348	72	1706	3
1975-01-13	L Reid	1985-09-30	\N	Senator of the College of Justice	\N	\N	\N	46466	633	73	1716	1
1975-09-30	L Cross of Chelsea	1982-06-27	\N	LJ	\N	\N	\N	46701	12332	74	1738	3
1977-01-10	L Kilbrandon	1996-09-30	\N	Senator of the College of Justice	\N	\N	\N	47120	471	75	1769	1
1977-09-30	L Simon of Glaisdale	1986-01-13	\N	LJ	\N	\N	\N	47342	12509	76	1780	3
1988-08-05	[increase in number]	1994-01-07	\N	LCJ of NI	\N	\N	\N	51439	9161	78	1827	4
1979-09-28	\N	1980-04-15	\N	LJ	\N	\N	\N	47968	12353	79	1837	3
1980-04-15	\N	1985-12-31	\N	LJ	\N	\N	\N	48160	5816	80	1846	3
1980-09-29	V Dilhorne resigned & since died	1992-02-26	\N	LJ	\N	\N	\N	48326	13737	81	1852	3
1981-09-24	\N	1991-09-30	\N	LJ	\N	\N	\N	48749	12329	82	1874	3
1982-03-12	L Wilberforce	1986-06-19	\N	LJ	\N	\N	\N	48924	3707	83	1878	3
1982-09-30	L Russell of Killowen	1994-09-30	\N	LJ	\N	\N	\N	49131	12953	84	1883	3
1985-05-23	\N	1993-09-30	\N	LJ	\N	\N	\N	\N	\N	85	1940	3
1986-01-30	\N	1992-09-30	\N	LJ	\N	\N	\N	50421	1627	86	1948	3
1986-01-31	\N	1991-12-31	\N	LJ	\N	\N	\N	50422	1671	87	1949	3
1876-10-17	pursuant to Appellate Jurisdiction Act 1876	\N	\N	QC MP, Lord Advocate	\N	\N	\N	24372	5457	2	424	1
2000-07-17	L Phillips of Worth Matravers	\N	\N	Vice-Chancellor	\N	\N	\N	55920	8034	108	2403	3
2002-10-01	L Slynn of Hadley	\N	\N	LJ	\N	\N	\N	56712	11976	109	2449	3
2004-01-12	L Millett	\N	\N	LJ	\N	\N	\N	57179	503	110	2455	3
2004-01-12	L Hutton	2009-06-28	\N	LCJ of NI	\N	\N	\N	57179	503	111	2456	4
2004-01-13	L Hobhouse of Woodborough	\N	\N	LJ	\N	\N	\N	57180	591	112	2457	3
2005-10-03	L Steyn	\N	\N	LJ	\N	\N	\N	57779	12971	113	2540	3
2007-01-11	L Nicholls of Birkenhead	\N	\N	LJ	\N	\N	\N	58222	601	114	2580	3
2008-10-01	L Bingham of Cornhill	\N	reappointment	LCJ	\N	0	0	58843	15222	115	2305	3
2009-04-21	L Hoffmann	\N	\N	LJ	\N	0	0	59045	7037	116	2610	3
2009-06-29	L Carswell	\N	\N	LCJ of NI	\N	0	0	59117	11331	117	2613	4
1921-06-01	L Moulton	\N	MP at time of appointment	KC	1929-11-01	33549	7065	32344	4425	22	864	3
1961-01-20	L Keith of Avonholm	1971-09-30	\N	Senator of the College of Justice	\N	\N	\N	42257	499	59	1402	1
1876-10-16	pursuant to Appellate Jurisdiction Act 1876	1887-01-06	\N	J (Queen's Bench Division)	\N	\N	\N	24370	5347	1	423	3
1909-02-20	L Robertson deceased	1929-04-30	MP on appointment	Lord Advocate	\N	\N	\N	28238	2589	16	683	1
1930-02-03	L Sumner	\N	Resigned 1939 on appointment as Minister of Information. Reappointed 18 July 1941.	Lord Advocate	\N	\N	\N	33576	719	28	981	1
1957-04-24	L Oaksey	1962-04-19	appointed MR 19 April 1962	LJ	\N	\N	\N	41055	2519	55	1343	3
1971-04-19	\N	1977-09-30	\N	President of Family Division	\N	\N	\N	45347	3901	68	1632	3
1985-10-01	L Fraser of Tullybelton	1987-10-28	Resigned on appointment as Lord Chancellor	Senator of the College of Justice	\N	\N	\N	\N	\N	77	1817	1
1986-02-06	\N	1998-09-30	Senior Lord of Appeal in Ordinary from 1996	LJ	\N	\N	\N	50427	1981	88	1950	3
1988-02-09	\N	1996-09-30	\N	Senator of the College of Justice	\N	\N	\N	51239	1661	89	1992	1
1991-10-01	L Brandon of Oakbrook	2000-06-05	Senior Lord of Appeal in Ordinary from 1 Oct 1998	LJ	\N	\N	\N	52677	15091	90	2055	3
1992-01-10	L Oliver of Aylmerton	1997-03-21	\N	LJ	\N	\N	\N	52794	577	91	2056	3
1992-03-11	L Bridge of Harwich	2002-09-30	\N	LJ	\N	\N	\N	52861	4553	92	2061	3
2001-10-01	L Clyde	\N	\N	Lord Justice General	\N	\N	\N	56350	11695	93	2065	1
1992-10-01	L Ackner	1996-06-04	appointed Master of the Rolls June 1996; appointed Lord Chief Justice 2001 (retired 2006)	LJ	\N	\N	\N	53070	16751	94	2099	3
1993-10-01	L Griffiths	1998-12-31	\N	LJ	\N	\N	\N	53448	16099	95	2105	3
1994-01-11	L Lowry	1998-09-30	\N	LJ	\N	\N	\N	53547	553	96	2114	3
1994-10-03	L Templeman	2007-01-10	\N	LJ	\N	\N	\N	53811	14001	97	2125	3
1995-01-11	[increase in number]	2005-10-01	\N	LJ	\N	\N	\N	53914	551	98	2131	3
1995-02-21	[increase in number]	2009-04-20	\N	LJ	\N	\N	\N	53965	3079	99	2135	3
1996-10-01	L Keith of Kinkel	\N	\N	Lord Justice General	\N	\N	\N	54543	13211	100	2136	1
2000-06-06	L Browne-Wilkinson	2008-09-30	\N	LCJ	\N	\N	\N	55870	6307	101	2157	3
1996-10-01	L Jauncey of Tullichettle	2001-09-30	\N	Senator of the College of Justice	\N	\N	\N	54543	13211	102	2162	1
1997-01-06	L Woolf	2004-01-11	\N	LCJ	\N	\N	\N	54647	421	103	2176	4
1997-07-28	L Mustill	\N	\N	LJ	\N	\N	\N	54849	8779	104	2206	3
1998-10-01	L Goff of Chieveley resigned	2004-01-11	Announcement of appointment leaked in The Guardian 18 July 1998.	LJ	\N	\N	\N	55286	11339	105	2302	3
1998-10-01	L Nolan	2004-01-11	Announcement of appointment leaked in The Guardian 18 July 1998.	LJ	\N	\N	\N	55286	11339	106	2303	3
1999-01-12	L Lloyd of Berwick	2000-06-05	appointed Master of the Rolls 2001; Lord Chief Justice 2006	LJ	\N	\N	\N	55376	479	107	2305	3
\.


--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('law_lord_incumbencies_id_seq', 117, true);


--
-- Data for Name: letters; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters (id, letter, url_key) FROM stdin;
1	Without surname	-
2	A	a
3	B	b
4	C	c
5	D	d
6	E	e
7	F	f
8	G	g
9	H	h
10	I	i
11	J	j
12	K	k
13	L	l
14	M	m
15	N	n
16	O	o
17	P	p
18	Q	q
19	R	r
20	S	s
21	T	t
22	U	u
23	V	v
24	W	w
25	X	x
26	Y	y
27	Z	z
\.


--
-- Name: letters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_id_seq', 27, true);


--
-- Data for Name: letters_patent_times; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters_patent_times (id, label) FROM stdin;
1	Afternoon
2	Morning
3	6 a.m.
4	9 a.m.
5	12 noon
6	3 p.m.
7	11 p.m.
8	2 p.m.
9	1 p.m.
10	6 p.m.
11	9 p.m.
\.


--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_patent_times_id_seq', 11, true);


--
-- Data for Name: letters_patents; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters_patents (id, patent_on, person_prefix, person_suffix, previous_of_title, previous_title, previous_rank, ordinality_on_date, citations, announcement_id, letters_patent_time_id, person_id, kingdom_id, previous_kingdom_id, reign_id) FROM stdin;
57	1814-05-17	\N	\N	f	\N	\N	3	\N	\N	\N	54	5	\N	11
60	1814-06-01	\N	\N	f	\N	\N	2	\N	\N	\N	57	5	\N	11
61	1814-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	58	5	\N	11
35	1801-02-04	\N	\N	t	Exeter	10th Earl	1	\N	\N	\N	39	5	\N	11
70	1815-08-11	\N	\N	f	\N	\N	6	\N	\N	\N	66	5	\N	11
107	1815-08-12	\N	\N	f	\N	\N	1	\N	\N	\N	101	5	\N	11
71	1806-02-22	\N	\N	t	Lauderdale	8th Earl 	1	\N	\N	\N	67	5	2	11
13	1802-07-28	\N	\N	f	Arden	2nd Lord 	1	\N	\N	\N	15	5	3	11
4	1801-05-22	\N	\N	f	\N	\N	2	\N	\N	\N	4	5	\N	11
34	1801-05-28	\N	\N	f	\N	\N	1	\N	\N	\N	5	5	\N	11
11	1802-02-27	\N	\N	f	Curzon	1st Lord	1	\N	\N	\N	12	5	\N	11
27	1801-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	31	5	\N	11
9	1801-12-16	\N	\N	f	\N	\N	1	\N	\N	\N	10	5	\N	11
10	1802-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	11	5	\N	11
14	1802-07-29	\N	\N	f	Sheffield	1st Lord 	1	\N	\N	\N	16	5	3	11
12	1802-04-19	\N	\N	f	\N	\N	1	\N	\N	\N	13	5	\N	11
24	1806-02-24	\N	\N	t	Granard	6th Earl 	1	\N	\N	\N	28	5	3	11
37	1803-09-17	\N	\N	f	Keith	1st Lord	1	\N	\N	\N	9	5	\N	11
15	1802-12-24	\N	\N	f	\N	\N	1	\N	\N	\N	17	5	\N	11
17	1805-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	19	5	\N	11
38	1805-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	20	5	\N	11
20	1806-02-10	\N	\N	f	\N	\N	1	\N	\N	\N	24	5	\N	11
21	1806-02-17	\N	\N	f	\N	\N	1	\N	\N	\N	25	5	\N	11
46	1806-11-13	\N	\N	t	Breadalbane	4th Earl 	1	\N	\N	\N	44	5	2	11
8	1801-12-15	\N	\N	f	Keith	1st Lord 	1	\N	\N	\N	9	5	3	11
96	1821-07-17	\N	\N	t	Kingston	3rd Earl 	8	\N	\N	\N	89	5	3	8
25	1806-02-25	\N	\N	f	\N	\N	1	\N	\N	\N	29	5	\N	11
41	1806-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	40	5	\N	11
30	1801-06-19	\N	\N	f	Onslow	4th Lord	1	\N	\N	\N	34	5	\N	11
26	1801-11-27	\N	\N	f	\N	\N	2	\N	\N	\N	30	5	\N	11
31	1804-05-14	\N	\N	f	Clive	1st Lord	1	\N	\N	\N	35	5	\N	11
16	1804-09-01	\N	\N	f	\N	\N	1	\N	\N	\N	18	5	\N	11
5	1801-06-23	\N	\N	f	\N	\N	2	\N	\N	\N	6	5	\N	11
40	1801-04-21	\N	\N	f	Loughborough	1st Lord	1	\N	\N	\N	37	5	\N	11
39	1805-11-20	\N	\N	f	Nelson	2nd Lord	1	\N	\N	\N	22	5	\N	11
3	1801-05-22	\N	\N	f	Nelson	1st Lord	1	\N	\N	\N	3	5	\N	11
19	1805-11-20	\N	\N	f	\N	\N	2	\N	\N	\N	23	5	\N	11
42	1806-03-13	\N	\N	f	\N	\N	1	\N	\N	\N	41	5	\N	11
78	1806-04-10	\N	\N	f	Walpole	2nd Lord	1	\N	\N	\N	73	5	\N	11
44	1806-04-11	\N	\N	f	Grey	1st Lord	1	\N	\N	\N	6	5	\N	11
47	1806-11-27	\N	\N	f	Gardner	1st Lord 	1	\N	\N	\N	45	5	3	11
50	1807-11-09	\N	\N	f	Cathcart	10th Lord 	1	\N	\N	\N	47	5	2	11
75	1807-04-07	\N	\N	f	Lowther	2nd Viscount	1	\N	\N	\N	70	5	\N	11
48	1807-04-20	\N	\N	f	\N	\N	1	\N	\N	\N	46	5	\N	11
74	1809-07-19	\N	\N	f	Harrowby	2nd Lord	1	\N	\N	\N	69	5	\N	11
51	1807-11-09	\N	\N	f	\N	\N	2	\N	\N	\N	48	5	\N	11
80	1812-02-28	\N	\N	f	Wellington	1st Viscount	1	\N	\N	\N	49	5	\N	11
52	1809-09-04	\N	\N	f	\N	\N	1	\N	\N	\N	49	5	\N	11
53	1812-09-07	\N	\N	f	Camden	2nd Earl	2	\N	\N	\N	50	5	\N	11
97	1821-07-17	\N	\N	t	Longford	2nd Earl 	9	\N	\N	\N	90	5	3	8
55	1814-05-17	\N	\N	f	\N	\N	1	\N	\N	\N	52	5	\N	11
64	1815-08-04	\N	\N	t	Clancarty	2nd Earl 	1	\N	\N	\N	60	5	3	11
65	1815-08-07	\N	\N	t	Strathmore	10th Earl 	1	\N	\N	\N	61	5	2	11
66	1815-08-11	\N	\N	t	Aboyne	5th Earl 	2	\N	\N	\N	62	5	2	11
98	1821-07-17	\N	\N	f	\N	\N	10	\N	\N	\N	91	5	\N	8
82	1812-09-07	\N	\N	t	Northampton	9th Earl	1	\N	\N	\N	76	5	\N	11
54	1813-06-14	\N	\N	f	Whitworth	1st Lord 	1	\N	\N	\N	51	5	3	11
72	1815-11-25	\N	\N	f	Whitworth	1st Viscount	1	\N	\N	\N	51	5	\N	11
23	1801-01-17	\N	\N	t	Drogheda	1st Marquess 	1	\N	\N	\N	27	5	3	11
99	1821-07-17	\N	\N	f	\N	\N	11	\N	\N	\N	92	5	\N	8
100	1821-07-17	\N	\N	f	\N	\N	13	\N	\N	\N	93	5	\N	8
101	1821-07-17	\N	\N	f	\N	\N	14	\N	\N	\N	94	5	\N	8
102	1821-07-17	\N	\N	f	\N	\N	15	\N	\N	\N	95	5	\N	8
84	1815-11-27	\N	\N	f	Brownlow	2nd Lord	1	\N	\N	\N	77	5	\N	11
76	1813-02-24	\N	\N	f	Minto	1st Lord	1	\N	\N	\N	71	5	\N	11
103	1821-07-17	\N	\N	f	\N	\N	16	\N	\N	\N	96	5	\N	8
91	1821-07-17	\N	\N	t	Lothian	6th Marquess 	3	\N	\N	\N	83	5	2	8
124	1815-11-28	\N	\N	f	Eliot	2nd Lord	1	\N	\N	\N	110	5	\N	11
115	1815-11-29	\N	\N	f	Boringdon	2nd Lord	1	\N	\N	\N	109	5	\N	11
116	1821-07-18	\N	\N	f	\N	\N	2	\N	\N	\N	97	5	\N	8
112	1815-11-30	\N	\N	f	Bradford	2nd Lord	1	\N	\N	\N	106	5	\N	11
118	1821-07-17	\N	\N	t	Ailesbury	2nd Earl	1	\N	\N	\N	112	5	\N	8
121	1816-10-25	\N	\N	f	Lucas	Baroness	1	\N	\N	\N	78	5	\N	11
114	1821-07-14	\N	\N	f	Falmouth	4th Viscount	1	\N	\N	\N	108	5	\N	8
86	1816-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	79	5	\N	11
123	1823-07-08	\N	\N	t	Londonderry	3rd Marquess 	1	\N	\N	\N	99	5	3	8
88	1817-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	80	5	\N	11
89	1821-07-16	\N	\N	f	Curzon	2nd Viscount	1	\N	\N	\N	81	5	\N	8
106	1823-12-08	\N	\N	t	Clancarty	2nd Earl 	1	\N	\N	\N	100	5	3	8
105	1823-04-22	\N	\N	f	Beresford	1st Lord	1	\N	\N	\N	56	5	\N	8
108	1826-07-03	\N	\N	t	Thomond	2nd Marquess 	1	\N	\N	\N	102	5	3	8
104	1823-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	98	5	\N	8
119	1826-06-30	\N	\N	t	Bristol	5th Earl	1	\N	\N	\N	113	5	\N	8
77	1812-09-07	\N	\N	f	Mulgrave	1st Lord & 3rd Lord	3	\N	\N	\N	72	5	\N	11
7	1801-10-02	\N	\N	t	Thomond	1st Marquess 	1	\N	\N	\N	8	5	3	11
129	1826-12-19	\N	\N	f	Amherst	2nd Lord	1	\N	\N	\N	119	5	\N	8
83	1812-10-03	\N	\N	t	Wellington	1st Earl	1	\N	\N	\N	49	5	\N	11
130	1827-02-08	\N	\N	f	Combermere	1st Lord	1	\N	\N	\N	54	5	\N	8
125	1826-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	115	5	\N	8
126	1826-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	116	5	\N	8
127	1826-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	117	5	\N	8
128	1826-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	118	5	\N	8
93	1827-07-24	\N	\N	f	Binning	Lord	1	\N	\N	\N	85	5	\N	8
131	1827-04-25	\N	\N	f	\N	\N	1	\N	\N	\N	120	5	\N	8
132	1827-04-28	\N	\N	f	\N	\N	1	\N	\N	\N	121	5	\N	8
56	1814-05-17	\N	\N	f	\N	\N	2	\N	\N	\N	53	5	\N	11
152	1831-06-20	\N	\N	f	\N	\N	5	\N	\N	\N	142	5	\N	7
155	1831-09-10	\N	\N	f	Ludlow	3rd Earl 	6	\N	\N	\N	145	5	3	7
157	1831-09-10	\N	\N	f	Howden	1st Lord 	8	\N	\N	\N	147	5	3	7
166	1827-10-05	\N	\N	t	Darlington	3rd Earl	1	\N	\N	\N	155	5	\N	8
207	1831-09-13	\N	\N	f	Grosvenor	2nd Earl	1	\N	\N	\N	195	5	\N	7
158	1831-09-10	\N	\N	f	\N	\N	9	\N	\N	\N	148	5	\N	7
159	1831-09-10	\N	\N	f	\N	\N	10	\N	\N	\N	149	5	\N	7
161	1831-09-10	\N	\N	f	\N	\N	12	\N	\N	\N	151	5	\N	7
162	1831-09-10	\N	\N	f	\N	\N	13	\N	\N	\N	152	5	\N	7
168	1831-09-10	\N	\N	f	\N	\N	15	\N	\N	\N	156	5	\N	7
169	1831-09-10	\N	\N	f	\N	\N	16	\N	\N	\N	157	5	\N	7
135	1827-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	124	5	\N	8
178	1833-06-07	\N	\N	t	Queensberry	6th Marquess 	1	\N	\N	\N	166	5	2	7
137	1828-01-21	\N	\N	f	\N	\N	1	\N	\N	\N	126	5	\N	8
164	1828-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	127	5	\N	8
139	1828-01-23	\N	\N	f	\N	\N	1	\N	\N	\N	129	5	\N	8
142	1828-01-29	\N	\N	f	\N	\N	1	\N	\N	\N	132	5	\N	8
143	1828-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	133	5	\N	8
144	1828-02-02	\N	\N	f	\N	\N	1	\N	\N	\N	134	5	\N	8
145	1829-06-05	\N	\N	f	\N	\N	1	\N	\N	\N	135	5	\N	8
146	1830-11-22	\N	\N	f	\N	\N	1	\N	\N	\N	136	5	\N	7
167	1831-06-04	\N	\N	f	\N	\N	1	\N	\N	\N	154	5	\N	7
170	1831-09-14	\N	\N	f	Cloncurry	2nd Lord 	1	\N	\N	\N	158	5	3	7
136	1827-10-06	\N	\N	f	Cawdor	2nd Lord	1	\N	\N	\N	125	5	\N	8
134	1827-04-30	\N	\N	f	\N	\N	1	\N	\N	\N	123	5	\N	8
199	1833-01-28	\N	\N	t	Stafford	2nd Marquess	1	\N	\N	\N	189	5	\N	7
138	1828-01-22	\N	\N	f	\N	\N	2	\N	\N	\N	128	5	\N	8
203	1831-09-15	\N	\N	f	Anson	2nd Viscount	1	\N	\N	\N	192	5	\N	7
194	1838-07-05	\N	\N	t	Kintore	7th Earl 	1	\N	\N	\N	184	5	2	6
171	1831-09-15	\N	\N	f	\N	\N	2	\N	\N	\N	159	5	\N	7
172	1832-05-14	\N	\N	f	\N	\N	1	\N	\N	\N	160	5	\N	7
174	1832-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	162	5	\N	7
175	1832-12-22	\N	\N	f	\N	\N	1	\N	\N	\N	163	5	\N	7
176	1833-01-28	\N	\N	f	\N	\N	2	\N	\N	\N	164	5	\N	7
200	1837-01-28	\N	\N	f	Ducie	4th Lord	1	\N	\N	\N	190	5	\N	7
179	1834-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	167	5	\N	7
208	1834-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	168	5	\N	7
180	1834-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	169	5	\N	7
181	1835-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	170	5	\N	7
183	1835-03-10	\N	\N	f	\N	\N	1	\N	\N	\N	172	5	\N	7
184	1835-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	173	5	\N	7
185	1835-05-08	\N	\N	f	\N	\N	1	\N	\N	\N	174	5	\N	7
186	1835-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	175	5	\N	7
187	1835-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	176	5	\N	7
189	1836-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	178	5	\N	7
209	1836-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	179	5	\N	7
190	1836-01-23	\N	\N	f	\N	\N	1	\N	\N	\N	180	5	\N	7
191	1837-01-27	\N	\N	f	\N	\N	2	\N	\N	\N	181	5	\N	7
245	1838-06-25	\N	\N	t	Mulgrave	2nd Earl	1	\N	\N	\N	232	5	\N	6
192	1837-01-28	\N	\N	f	\N	\N	2	\N	\N	\N	182	5	\N	7
238	1841-08-16	\N	\N	t	Stair	8th Earl 	2	\N	\N	\N	212	5	2	6
231	1837-01-30	\N	\N	f	\N	\N	2	\N	\N	\N	218	5	\N	7
204	1838-06-30	\N	\N	f	King	8th Lord	1	\N	\N	\N	193	5	\N	6
205	1838-07-02	\N	\N	f	Dundas	2nd Lord	1	\N	\N	\N	194	5	\N	6
195	1838-07-06	\N	\N	f	Lismore	1st Viscount 	1	\N	\N	\N	185	5	3	6
196	1838-07-07	\N	\N	f	Rossmore	2nd Lord 	1	\N	\N	\N	186	5	3	6
197	1838-07-09	\N	\N	f	Carew	1st Lord 	1	\N	\N	\N	187	5	3	6
246	1841-12-08	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	233	5	\N	6
239	1839-12-21	\N	\N	f	Auckland	2nd Lord	1	\N	\N	\N	227	5	\N	6
198	1838-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	188	5	\N	6
210	1838-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	196	5	\N	6
241	1841-08-16	\N	\N	f	Barham	3rd Lord	1	\N	\N	\N	229	5	\N	6
215	1839-05-09	\N	\N	f	\N	\N	1	\N	\N	\N	201	5	\N	6
216	1839-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	202	5	\N	6
217	1839-05-13	\N	\N	f	\N	\N	1	\N	\N	\N	203	5	\N	6
218	1839-05-14	\N	\N	f	\N	\N	1	\N	\N	\N	204	5	\N	6
219	1839-05-15	\N	\N	f	\N	\N	1	\N	\N	\N	205	5	\N	6
220	1839-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	206	5	\N	6
222	1839-09-05	\N	\N	f	\N	\N	1	\N	\N	\N	208	5	\N	6
223	1839-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	209	5	\N	6
234	1847-09-20	\N	\N	f	Cremorne	3rd Lord 	1	\N	\N	\N	222	5	3	6
247	1840-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	226	5	\N	6
225	1840-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	211	5	\N	6
226	1841-08-17	\N	\N	f	Segrave	1st Lord	1	\N	\N	\N	213	5	\N	6
260	1856-03-12	\N	\N	t	Kenmare	3rd Earl 	1	\N	\N	\N	244	5	3	6
248	1842-09-27	\N	\N	f	Hill	1st Lord	1	\N	\N	\N	55	5	\N	6
228	1841-08-18	\N	\N	f	\N	\N	1	\N	\N	\N	215	5	\N	6
229	1841-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	216	5	\N	6
242	1847-09-18	\N	\N	f	Strafford	1st Lord	1	\N	\N	\N	176	5	\N	6
150	1831-06-20	\N	\N	t	Leitrim	2nd Earl 	3	\N	\N	\N	140	5	3	7
240	1846-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	228	5	\N	6
153	1831-09-10	\N	\N	t	Headfort	2nd Marquess 	3	\N	\N	\N	143	5	3	7
233	1847-09-18	\N	\N	f	\N	\N	2	\N	\N	\N	221	5	\N	6
262	1856-07-23	\N	\N	f	Wensleydale	Lord	1	\N	\N	\N	242	5	\N	6
235	1847-09-21	\N	\N	f	\N	\N	1	\N	\N	\N	223	5	\N	6
250	1850-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	234	5	\N	6
251	1850-03-05	\N	\N	f	\N	\N	1	\N	\N	\N	235	5	\N	6
252	1850-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	236	5	\N	6
253	1850-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	237	5	\N	6
255	1852-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	239	5	\N	6
256	1852-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	240	5	\N	6
257	1852-10-20	\N	\N	f	\N	\N	1	\N	\N	\N	241	5	\N	6
258	1856-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	242	5	\N	6
265	1857-04-11	\N	\N	f	Cowley	2nd Lord	1	\N	\N	\N	248	5	\N	6
261	1856-06-25	\N	\N	f	\N	\N	1	\N	\N	\N	245	5	\N	6
263	1856-08-29	\N	\N	f	\N	\N	1	\N	\N	\N	246	5	\N	6
266	1857-04-11	\N	\N	f	\N	\N	2	\N	\N	\N	249	5	\N	6
267	1857-09-15	\N	\N	f	\N	\N	1	\N	\N	\N	250	5	\N	6
154	1831-09-10	\N	\N	t	Meath	10th Earl 	4	\N	\N	\N	144	5	3	7
147	1831-06-17	\N	\N	t	Erroll	18th Earl 	1	\N	\N	\N	137	5	2	7
2996	1706-12-30	\N	\N	f	\N	\N	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 32	\N	\N	2904	1	\N	16
270	1858-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	253	5	\N	6
272	1858-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	255	5	\N	6
273	1858-08-28	\N	\N	f	\N	\N	1	\N	\N	\N	256	5	\N	6
274	1859-04-14	\N	\N	f	\N	\N	1	\N	\N	\N	257	5	\N	6
275	1859-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	258	5	\N	6
286	1860-02-17	\N	\N	f	Ward	11th Lord	1	\N	\N	\N	267	5	\N	6
278	1859-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	260	5	\N	6
279	1859-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	261	5	\N	6
363	1871-06-23	\N	\N	t	Ripon	2nd Earl	1	\N	\N	\N	343	5	\N	6
281	1861-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	263	5	\N	6
282	1861-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	264	5	\N	6
283	1861-07-30	\N	\N	f	\N	\N	1	\N	\N	\N	265	5	\N	6
326	1864-04-27	\N	\N	f	De La Warr	Countess	1	\N	\N	\N	272	5	\N	6
290	1863-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	270	5	\N	6
291	1863-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	271	5	\N	6
324	1866-06-01	\N	\N	f	Wodehouse	3rd Lord	1	\N	\N	\N	305	5	\N	6
293	1866-01-04	\N	\N	f	\N	\N	1	\N	\N	\N	274	5	\N	6
294	1866-02-21	\N	\N	f	\N	\N	1	\N	\N	\N	275	5	\N	6
322	1866-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	304	5	\N	6
299	1866-07-12	\N	\N	f	Monck	4th Viscount 	2	\N	\N	\N	280	5	3	6
300	1866-07-13	\N	\N	f	Henniker	4th Lord 	1	\N	\N	\N	281	5	3	6
313	1868-12-08	\N	\N	f	Gormanston	13th Viscount 	1	\N	\N	\N	295	5	3	6
361	1868-07-25	\N	\N	f	Feversham	3rd Lord	1	\N	\N	\N	341	5	\N	6
301	1866-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	282	5	\N	6
302	1866-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	283	5	\N	6
303	1866-07-31	\N	\N	f	\N	\N	1	\N	\N	\N	284	5	\N	6
304	1866-08-03	\N	\N	f	\N	\N	1	\N	\N	\N	285	5	\N	6
305	1867-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	286	5	\N	6
307	1868-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	288	5	\N	6
308	1868-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	289	5	\N	6
309	1868-04-17	\N	\N	f	\N	\N	1	\N	\N	\N	290	5	\N	6
350	1868-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	329	5	\N	6
360	1871-11-13	\N	\N	f	Dufferin and Claneboye	5th Lord 	1	\N	\N	\N	340	5	3	6
325	1868-11-30	\N	\N	f	\N	\N	1	\N	\N	\N	294	5	\N	6
339	1873-03-25	\N	\N	t	Breadalbane	7th Earl 	1	\N	\N	\N	319	5	2	6
314	1868-12-09	\N	\N	f	\N	\N	1	\N	\N	\N	296	5	\N	6
315	1869-04-06	\N	\N	f	\N	\N	1	\N	\N	\N	297	5	\N	6
318	1869-12-09	\N	\N	f	\N	\N	1	\N	\N	\N	300	5	\N	6
319	1869-12-10	\N	\N	f	\N	\N	1	\N	\N	\N	301	5	\N	6
320	1869-12-11	\N	\N	f	\N	\N	1	\N	\N	\N	302	5	\N	6
321	1869-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	303	5	\N	6
327	1869-12-15	\N	\N	f	\N	\N	1	\N	\N	\N	306	5	\N	6
328	1870-05-03	\N	\N	f	\N	\N	1	\N	\N	\N	307	5	\N	6
329	1870-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	308	5	\N	6
330	1870-10-26	\N	\N	f	\N	\N	1	\N	\N	\N	309	5	\N	6
331	1871-03-23	\N	\N	f	\N	\N	1	\N	\N	\N	310	5	\N	6
364	1871-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	312	5	\N	6
336	1872-07-16	\N	\N	f	Napier	10th Lord 	1	\N	\N	\N	316	5	2	6
334	1871-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	314	5	\N	6
341	1873-04-09	\N	\N	t	Normanton	3rd Earl 	1	\N	\N	\N	320	5	3	6
335	1872-02-13	\N	\N	f	\N	\N	1	\N	\N	\N	315	5	\N	6
357	1876-01-13	\N	\N	t	Erne	3rd Earl 	2	\N	\N	\N	336	5	3	6
337	1872-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	317	5	\N	6
340	1873-03-28	\N	\N	f	Portman	1st Lord	1	\N	\N	\N	181	5	\N	6
358	1876-01-13	\N	\N	t	Richmond	6th Duke	1	\N	\N	\N	338	5	\N	6
342	1873-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	321	5	\N	6
343	1873-06-12	\N	\N	f	\N	\N	1	\N	\N	\N	322	5	\N	6
345	1874-01-08	\N	\N	f	\N	\N	1	\N	\N	\N	324	5	\N	6
346	1874-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	325	5	\N	6
347	1874-01-10	\N	\N	f	\N	\N	1	\N	\N	\N	326	5	\N	6
348	1874-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	327	5	\N	6
385	1874-03-05	\N	\N	f	\N	\N	1	\N	\N	\N	365	5	\N	6
351	1874-03-06	\N	\N	f	\N	\N	1	\N	\N	\N	330	5	\N	6
352	1874-03-06	\N	\N	f	\N	\N	2	\N	\N	\N	331	5	\N	6
353	1874-03-16	\N	\N	f	\N	\N	1	\N	\N	\N	332	5	\N	6
356	1875-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	335	5	\N	6
403	1880-04-17	\N	\N	f	Barrington	7th Viscount 	1	\N	\N	\N	352	5	3	6
399	1876-06-10	\N	\N	f	Northbrook	2nd Lord	1	\N	\N	\N	379	5	\N	6
298	1866-06-12	\N	\N	t	Dunraven and Mount Earl	3rd Earl 	1	\N	\N	\N	279	5	3	6
366	1876-01-15	\N	\N	f	\N	\N	2	\N	\N	\N	344	5	\N	6
367	1876-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	345	5	\N	6
368	1876-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	346	5	\N	6
400	1877-01-03	\N	\N	f	Redesdale	2nd Lord	1	\N	\N	\N	380	5	\N	6
402	1876-10-02	\N	\N	f	\N	\N	1	\N	\N	\N	347	5	\N	6
369	1876-10-17	\N	\N	f	\N	\N	1	\N	\N	\N	348	5	\N	6
373	1878-09-27	\N	\N	f	Cairns	1st Lord	1	\N	\N	\N	287	5	\N	6
371	1878-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	350	5	\N	6
372	1878-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	351	5	\N	6
389	1881-10-08	\N	\N	f	Reay	11th Lord 	1	\N	\N	\N	369	5	2	6
379	1880-05-04	\N	\N	f	Sondes	5th Lord	1	\N	\N	\N	359	5	\N	6
404	1880-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	353	5	\N	6
374	1880-04-28	\N	\N	f	\N	\N	2	\N	\N	\N	354	5	\N	6
375	1880-04-29	\N	\N	f	\N	\N	1	\N	\N	\N	355	5	\N	6
378	1880-05-03	\N	\N	f	\N	\N	2	\N	\N	\N	358	5	\N	6
287	1859-06-23	\N	\N	t	Eglinton	13th Earl 	1	\N	\N	\N	268	5	2	6
380	1880-05-04	\N	\N	f	\N	\N	2	\N	\N	\N	360	5	\N	6
381	1880-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	361	5	\N	6
383	1880-05-25	\N	\N	f	\N	\N	1	\N	\N	\N	363	5	\N	6
386	1881-03-11	\N	\N	f	\N	\N	1	\N	\N	\N	366	5	\N	6
401	1882-12-30	\N	\N	f	Selborne	1st Lord	1	\N	\N	\N	318	5	\N	6
390	1881-10-10	\N	\N	f	\N	\N	1	\N	\N	\N	370	5	\N	6
391	1881-10-11	\N	\N	f	\N	\N	1	\N	\N	\N	371	5	\N	6
392	1881-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	372	5	\N	6
393	1882-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	373	5	\N	6
395	1882-11-24	\N	\N	f	\N	\N	1	\N	\N	\N	375	5	\N	6
396	1882-11-25	\N	\N	f	\N	\N	1	\N	\N	\N	376	5	\N	6
397	1884-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	377	5	\N	6
405	1884-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	381	5	\N	6
407	1884-11-05	\N	\N	f	\N	\N	1	\N	\N	\N	383	5	\N	6
277	1846-05-02	\N	\N	f	\N	\N	1	\N	\N	\N	259	5	\N	6
276	1846-04-25	\N	\N	f	\N	\N	1	\N	\N	\N	224	5	\N	6
429	1886-03-23	\N	\N	f	Kensington	4th Lord 	1	\N	\N	\N	406	5	3	6
411	1885-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	387	5	\N	6
446	1887-07-02	\N	\N	f	Galway	7th Viscount 	1	\N	\N	\N	420	5	3	6
414	1885-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	390	5	\N	6
415	1885-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	391	5	\N	6
416	1885-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	392	5	\N	6
439	1885-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	416	5	\N	6
419	1885-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	395	5	\N	6
420	1885-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	396	5	\N	6
441	1885-09-28	\N	\N	f	Wolseley	1st Lord	1	\N	\N	\N	376	5	\N	6
421	1885-07-23	\N	\N	f	\N	\N	1	\N	\N	\N	397	5	\N	6
475	1888-11-17	\N	\N	t	Dufferin	1st Earl	1	\N	\N	\N	340	5	\N	6
442	1885-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	399	5	\N	6
423	1885-12-29	\N	\N	f	\N	\N	1	\N	\N	\N	400	5	\N	6
460	1886-02-08	\N	\N	f	\N	\N	1	\N	\N	\N	437	5	\N	6
428	1886-03-22	\N	\N	f	\N	\N	1	\N	\N	\N	405	5	\N	6
431	1886-08-13	\N	\N	f	Monson	7th Lord	1	\N	\N	\N	408	5	\N	6
430	1886-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	407	5	\N	6
474	1887-07-01	\N	\N	f	Londesborough	2nd Lord	1	\N	\N	\N	453	5	\N	6
432	1886-08-13	\N	\N	f	\N	\N	2	\N	\N	\N	409	5	\N	6
434	1886-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	411	5	\N	6
435	1886-08-17	\N	\N	f	\N	\N	1	\N	\N	\N	412	5	\N	6
436	1886-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	413	5	\N	6
437	1886-08-27	\N	\N	f	\N	\N	1	\N	\N	\N	414	5	\N	6
444	1887-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	418	5	\N	6
513	1897-07-24	\N	\N	f	Downe	8th Viscount 	1	\N	\N	\N	485	5	3	6
473	1892-08-22	\N	\N	f	Cranbrook	1st Viscount	2	\N	\N	\N	452	5	\N	6
447	1887-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	421	5	\N	6
448	1887-07-05	\N	\N	f	\N	\N	1	\N	\N	\N	422	5	\N	6
449	1887-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	423	5	\N	6
450	1887-07-07	\N	\N	f	\N	\N	1	\N	\N	\N	424	5	\N	6
451	1887-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	425	5	\N	6
453	1887-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	427	5	\N	6
413	1885-06-28	\N	\N	f	Henley	3rd Lord 	1	\N	\N	\N	389	5	3	6
455	1890-04-14	\N	\N	f	\N	\N	1	\N	\N	\N	430	5	\N	6
470	1890-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	449	5	\N	6
456	1891-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	431	5	\N	6
457	1891-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	432	5	\N	6
458	1891-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	433	5	\N	6
481	1891-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	435	5	\N	6
506	1892-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	478	5	\N	6
472	1892-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	451	5	\N	6
461	1892-06-18	\N	\N	f	\N	\N	1	\N	\N	\N	438	5	\N	6
462	1892-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	439	5	\N	6
463	1892-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	440	5	\N	6
464	1892-08-22	\N	\N	f	\N	\N	3	\N	\N	\N	441	5	\N	6
465	1892-08-23	\N	\N	f	\N	\N	2	\N	\N	\N	442	5	\N	6
479	1892-08-24	\N	\N	f	\N	\N	1	\N	\N	\N	443	5	\N	6
480	1892-08-26	\N	\N	f	\N	\N	1	\N	\N	\N	445	5	\N	6
467	1892-08-27	\N	\N	f	\N	\N	1	\N	\N	\N	446	5	\N	6
468	1892-08-29	\N	\N	f	\N	\N	1	\N	\N	\N	447	5	\N	6
469	1892-08-30	\N	\N	f	\N	\N	1	\N	\N	\N	448	5	\N	6
482	1892-09-03	\N	\N	f	\N	\N	1	\N	\N	\N	455	5	\N	6
484	1893-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	457	5	\N	6
486	1893-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	459	5	\N	6
487	1893-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	460	5	\N	6
489	1893-09-23	\N	\N	f	\N	\N	1	\N	\N	\N	462	5	\N	6
490	1894-03-30	\N	\N	f	\N	\N	1	\N	\N	\N	463	5	\N	6
491	1894-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	464	5	\N	6
492	1894-05-07	\N	\N	f	\N	\N	1	\N	\N	\N	465	5	\N	6
494	1895-05-09	\N	\N	f	\N	\N	1	\N	\N	\N	467	5	\N	6
496	1895-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	469	5	\N	6
497	1895-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	470	5	\N	6
511	1897-07-22	\N	\N	f	Egerton	2nd Lord	1	\N	\N	\N	483	5	\N	6
500	1895-08-03	\N	\N	f	\N	\N	2	\N	\N	\N	472	5	\N	6
501	1895-08-05	\N	\N	f	\N	\N	1	\N	\N	\N	473	5	\N	6
502	1895-08-05	\N	\N	f	\N	\N	2	\N	\N	\N	474	5	\N	6
504	1895-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	476	5	\N	6
505	1895-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	477	5	\N	6
540	1896-01-31	\N	\N	f	\N	\N	1	\N	\N	\N	510	5	\N	6
509	1897-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	481	5	\N	6
510	1897-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	482	5	\N	6
512	1897-07-23	\N	\N	t	Glasgow	7th Earl 	1	\N	\N	\N	484	5	2	6
517	1897-11-11	\N	\N	f	Esher	1st Lord	1	\N	\N	\N	398	5	\N	6
522	1897-11-29	\N	\N	f	Burton	1st Lord	1	\N	\N	\N	409	5	\N	6
514	1897-07-26	\N	\N	f	\N	\N	1	\N	\N	\N	486	5	\N	6
515	1897-07-27	\N	\N	f	\N	\N	1	\N	\N	\N	487	5	\N	6
524	1899-01-25	\N	\N	f	Cromer	1st Lord	1	\N	\N	\N	439	5	\N	6
410	1884-11-10	\N	\N	f	Herries	11th Lord 	1	\N	\N	\N	386	5	2	6
518	1898-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	489	5	\N	6
520	1898-06-13	\N	\N	f	\N	\N	1	\N	\N	\N	491	5	\N	6
523	1898-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	492	5	\N	6
525	1899-01-25	\N	\N	f	\N	\N	2	\N	\N	\N	493	5	\N	6
526	1899-01-26	\N	\N	f	\N	\N	1	\N	\N	\N	494	5	\N	6
425	1880-05-26	\N	\N	f	\N	\N	1	\N	\N	\N	402	5	\N	6
527	1899-01-27	\N	\N	f	\N	\N	1	\N	\N	\N	495	5	\N	6
528	1899-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	496	5	\N	6
529	1899-08-22	\N	\N	f	\N	\N	1	\N	\N	\N	498	5	\N	6
531	1900-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	500	5	\N	6
532	1900-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	501	5	\N	6
533	1900-05-10	\N	\N	f	\N	\N	1	\N	\N	\N	502	5	\N	6
535	1900-06-16	\N	\N	f	\N	\N	1	\N	\N	\N	504	5	\N	6
537	1900-12-18	\N	\N	f	\N	\N	1	\N	\N	\N	506	5	\N	6
538	1900-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	507	5	\N	6
539	1901-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	509	5	\N	5
543	1902-07-15	\N	\N	f	\N	\N	2	\N	\N	\N	512	5	\N	5
544	1902-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	513	5	\N	5
545	1902-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	514	5	\N	5
547	1902-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	516	5	\N	5
549	1903-07-31	\N	\N	f	\N	\N	1	\N	\N	\N	518	5	\N	5
550	1903-08-01	\N	\N	f	\N	\N	1	\N	\N	\N	519	5	\N	5
552	1903-08-04	\N	\N	f	\N	\N	1	\N	\N	\N	521	5	\N	5
553	1905-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	522	5	\N	5
424	1880-05-25	\N	\N	f	\N	\N	2	\N	\N	\N	401	5	\N	6
554	1905-03-09	\N	\N	f	\N	\N	1	\N	\N	\N	523	5	\N	5
556	1905-12-18	\N	\N	f	Iveagh	1st Lord	2	\N	\N	\N	525	5	\N	5
639	1911-07-03	\N	\N	t	Crewe	1st Earl	1	\N	\N	\N	602	5	\N	4
561	1905-12-18	\N	\N	f	\N	\N	3	\N	\N	\N	528	5	\N	5
563	1905-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	530	5	\N	5
564	1905-12-19	\N	\N	f	\N	\N	2	\N	\N	\N	531	5	\N	5
565	1905-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	532	5	\N	5
566	1905-12-22	\N	\N	f	\N	\N	2	\N	\N	\N	533	5	\N	5
567	1905-12-23	\N	\N	f	\N	\N	1	\N	\N	\N	534	5	\N	5
569	1905-12-27	\N	\N	f	\N	\N	1	\N	\N	\N	536	5	\N	5
571	1905-12-28	\N	\N	f	\N	\N	2	\N	\N	\N	538	5	\N	5
572	1905-12-29	\N	\N	f	\N	\N	1	\N	\N	\N	539	5	\N	5
574	1906-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	541	5	\N	5
575	1906-01-08	\N	\N	f	\N	\N	1	\N	\N	\N	542	5	\N	5
576	1906-01-10	\N	\N	f	\N	\N	1	\N	\N	\N	543	5	\N	5
577	1906-01-11	\N	\N	f	\N	\N	1	\N	\N	\N	544	5	\N	5
618	1906-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	584	5	\N	5
619	1906-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	585	5	\N	5
580	1906-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	547	5	\N	5
582	1906-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	549	5	\N	5
583	1906-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	550	5	\N	5
585	1906-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	552	5	\N	5
586	1906-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	553	5	\N	5
587	1907-03-06	\N	\N	f	\N	\N	1	\N	\N	\N	554	5	\N	5
588	1907-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	555	5	\N	5
597	1908-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	564	5	\N	5
591	1907-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	558	5	\N	5
592	1908-05-02	\N	\N	f	\N	\N	1	\N	\N	\N	559	5	\N	5
593	1908-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	560	5	\N	5
595	1908-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	562	5	\N	5
596	1908-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	563	5	\N	5
562	1908-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	529	5	\N	5
620	1909-02-15	\N	\N	f	\N	\N	1	\N	284	\N	586	5	\N	5
598	1909-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	565	5	\N	5
602	1909-12-08	\N	\N	f	\N	\N	1	\N	\N	\N	568	5	\N	5
603	1910-03-15	\N	\N	f	\N	\N	1	\N	\N	\N	569	5	\N	5
604	1910-03-15	\N	\N	f	\N	\N	2	\N	\N	\N	570	5	\N	5
605	1910-03-16	\N	\N	f	\N	\N	1	\N	\N	\N	571	5	\N	5
606	1910-04-27	\N	\N	f	\N	\N	1	\N	\N	\N	572	5	\N	5
641	1910-06-23	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	604	5	\N	4
608	1910-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	574	5	\N	4
609	1910-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	575	5	\N	4
611	1910-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	577	5	\N	4
613	1910-07-21	\N	\N	f	\N	\N	1	\N	\N	\N	579	5	\N	4
614	1910-09-21	\N	\N	f	\N	\N	1	\N	\N	\N	580	5	\N	4
615	1910-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	581	5	\N	4
616	1911-03-27	\N	\N	f	\N	\N	1	\N	\N	\N	582	5	\N	4
659	1911-06-21	\N	\N	f	\N	\N	1	\N	\N	\N	621	5	\N	4
661	1911-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	623	5	\N	4
623	1911-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	589	5	\N	4
624	1911-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	590	5	\N	4
625	1911-07-03	\N	\N	f	Elibank	10th Lord 	3	\N	\N	\N	591	5	2	4
626	1911-07-04	\N	\N	f	Loreburn	1st Lord	1	\N	\N	\N	542	5	\N	4
628	1911-07-05	\N	\N	f	Brassey	1st Lord	1	\N	\N	\N	411	5	\N	4
640	1912-02-26	\N	\N	f	Carrington	1st Earl	1	\N	\N	\N	603	5	\N	4
629	1911-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	592	5	\N	4
631	1911-11-02	\N	\N	f	\N	\N	2	\N	\N	\N	594	5	\N	4
632	1911-11-03	\N	\N	f	\N	\N	1	\N	\N	\N	595	5	\N	4
633	1912-02-08	\N	\N	f	\N	\N	1	\N	2	\N	596	5	\N	4
634	1912-02-09	\N	\N	f	\N	\N	1	\N	2	\N	597	5	\N	4
636	1912-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	599	5	\N	4
637	1912-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	600	5	\N	4
638	1912-08-13	\N	\N	f	\N	\N	1	\N	\N	\N	601	5	\N	4
642	1912-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	605	5	\N	4
644	1913-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	607	5	\N	4
645	1913-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	608	5	\N	4
646	1913-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	609	5	\N	4
647	1913-10-20	\N	\N	f	\N	\N	1	\N	\N	\N	610	5	\N	4
649	1914-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	611	5	\N	4
651	1914-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	613	5	\N	4
652	1914-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	614	5	\N	4
653	1914-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	615	5	\N	4
654	1914-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	616	5	\N	4
656	1914-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	618	5	\N	4
657	1914-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	619	5	\N	4
658	1914-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	620	5	\N	4
662	1915-04-12	\N	\N	f	\N	\N	1	\N	\N	\N	624	5	\N	4
663	1915-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	625	5	\N	4
664	1915-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	626	5	\N	4
666	1916-01-01	\N	\N	f	\N	\N	1	\N	\N	\N	628	5	\N	4
684	1917-01-02	\N	\N	f	Cowdray	1st Lord	1	\N	\N	\N	576	5	\N	4
668	1916-01-22	\N	\N	f	\N	\N	2	\N	\N	\N	629	5	\N	4
669	1916-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	630	5	\N	4
670	1916-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	631	5	\N	4
673	1916-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	634	5	\N	4
674	1916-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	635	5	\N	4
676	1916-06-26	\N	\N	f	\N	\N	2	\N	\N	\N	636	5	\N	4
677	1916-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	637	5	\N	4
678	1916-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	638	5	\N	4
679	1916-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	639	5	\N	4
680	1916-07-27	\N	\N	f	\N	\N	1	\N	\N	\N	640	5	\N	4
683	1917-01-01	\N	\N	f	\N	\N	2	\N	\N	\N	643	5	\N	4
696	1917-06-22	\N	\N	f	Devonport	1st Lord	1	\N	\N	\N	575	5	\N	4
685	1917-01-02	\N	\N	f	\N	\N	2	\N	\N	\N	644	5	\N	4
686	1917-01-03	\N	\N	f	\N	\N	1	\N	\N	\N	645	5	\N	4
687	1917-01-03	\N	\N	f	\N	\N	2	\N	\N	\N	646	5	\N	4
688	1917-01-04	\N	\N	f	\N	\N	1	\N	\N	\N	647	5	\N	4
690	1917-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	649	5	\N	4
693	1917-06-19	\N	\N	f	\N	\N	1	\N	\N	\N	652	5	\N	4
694	1917-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	653	5	\N	4
695	1917-06-21	\N	\N	f	\N	\N	2	\N	\N	\N	654	5	\N	4
698	1917-06-23	\N	\N	f	Astor	1st Lord	1	\N	\N	\N	632	5	\N	4
697	1917-06-22	\N	\N	f	\N	\N	2	\N	\N	\N	655	5	\N	4
559	1899-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	497	5	\N	6
557	1905-12-18	\N	\N	f	Windsor	14th Lord	1	\N	\N	\N	526	5	\N	5
718	1917-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	673	5	\N	4
701	1917-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	657	5	\N	4
719	1918-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	658	5	\N	4
704	1918-01-16	\N	\N	f	\N	\N	2	\N	\N	\N	661	5	\N	4
705	1918-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	662	5	\N	4
706	1918-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	663	5	\N	4
707	1918-01-19	\N	\N	f	\N	\N	1	\N	\N	\N	664	5	\N	4
717	1918-09-02	\N	\N	f	Bertie of Thame	1st Lord	1	\N	\N	\N	626	5	\N	4
710	1918-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	666	5	\N	4
709	1918-06-27	\N	\N	f	\N	\N	1	\N	3	\N	665	5	\N	4
711	1918-06-28	\N	\N	f	\N	\N	1	\N	3	\N	667	5	\N	4
712	1918-06-29	\N	\N	f	\N	\N	1	\N	3	\N	668	5	\N	4
714	1918-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	670	5	\N	4
715	1918-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	671	5	\N	4
730	1919-03-27	\N	\N	f	Finlay	1st Lord	1	\N	\N	\N	641	5	\N	4
721	1918-10-15	\N	\N	f	\N	\N	1	\N	\N	\N	674	5	\N	4
722	1918-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	675	5	\N	4
723	1918-11-14	\N	\N	f	\N	\N	2	\N	\N	\N	676	5	\N	4
724	1918-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	677	5	\N	4
725	1919-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	678	5	\N	4
726	1919-02-04	\N	\N	f	\N	\N	1	\N	\N	\N	679	5	\N	4
727	1919-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	680	5	\N	4
749	1920-11-08	\N	\N	f	Buxton	1st Viscount	1	\N	\N	\N	616	5	\N	4
731	1919-04-24	\N	\N	f	\N	\N	1	\N	\N	\N	683	5	\N	4
733	1919-05-17	\N	\N	f	\N	\N	2	\N	4	\N	684	5	\N	4
734	1919-05-19	\N	\N	f	\N	\N	1	\N	4	\N	685	5	\N	4
735	1919-05-20	\N	\N	f	\N	\N	1	\N	4	\N	686	5	\N	4
775	1919-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	721	5	\N	4
776	1919-10-04	\N	\N	f	\N	\N	1	\N	\N	\N	722	5	\N	4
737	1919-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	687	5	\N	4
759	1919-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	688	5	\N	4
738	1919-10-07	\N	\N	f	\N	\N	2	\N	\N	\N	689	5	\N	4
739	1919-10-08	\N	\N	f	\N	\N	1	\N	\N	\N	690	5	\N	4
743	1919-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	694	5	\N	4
745	1919-12-12	\N	\N	f	\N	\N	1	\N	\N	\N	696	5	\N	4
741	1920-01-09	\N	\N	f	\N	\N	1	\N	6	\N	692	5	\N	4
746	1920-02-09	\N	\N	f	\N	\N	1	\N	6	\N	697	5	\N	4
747	1920-04-21	\N	\N	f	\N	\N	1	\N	\N	\N	698	5	\N	4
766	1921-06-28	\N	\N	f	Curzon of Kedleston	1st Earl	1	\N	9	\N	593	5	\N	4
750	1920-12-06	\N	\N	f	\N	\N	1	\N	\N	\N	700	5	\N	4
748	1921-01-14	\N	\N	f	\N	\N	1	\N	8	\N	699	5	\N	4
752	1921-01-17	\N	\N	f	\N	\N	1	\N	8	\N	702	5	\N	4
753	1921-01-18	\N	\N	f	\N	\N	1	\N	8	\N	703	5	\N	4
761	1921-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	709	5	\N	4
763	1921-06-04	\N	\N	f	\N	\N	1	\N	\N	\N	711	5	\N	4
764	1921-06-04	\N	\N	f	\N	\N	2	\N	\N	\N	712	5	\N	4
771	1921-07-09	\N	\N	f	Pirrie	1st Lord	1	\N	\N	\N	550	5	\N	4
785	1922-11-28	\N	\N	f	Lee of Fareham	1st Lord	2	\N	\N	\N	672	5	\N	4
767	1921-06-28	\N	\N	f	\N	\N	2	\N	9	\N	714	5	\N	4
768	1921-07-01	\N	\N	f	\N	\N	1	\N	9	\N	715	5	\N	4
770	1921-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	717	5	\N	4
786	1922-11-30	\N	\N	f	Farquhar	1st Viscount	1	\N	\N	\N	489	5	\N	4
772	1921-07-26	\N	\N	f	\N	\N	1	\N	\N	\N	718	5	\N	4
773	1921-08-24	\N	\N	f	\N	\N	1	\N	\N	\N	719	5	\N	4
769	1922-01-23	\N	\N	f	\N	\N	1	\N	10	\N	716	5	\N	4
811	1922-01-26	\N	\N	f	\N	\N	1	\N	10	\N	754	5	\N	4
813	1922-03-24	\N	\N	f	\N	\N	1	\N	\N	\N	756	5	\N	4
812	1922-06-19	\N	\N	f	\N	\N	1	\N	11	\N	755	5	\N	4
778	1922-07-18	\N	\N	f	\N	\N	1	\N	11	\N	724	5	\N	4
779	1922-07-20	\N	\N	f	\N	\N	1	\N	11	\N	725	5	\N	4
781	1922-11-20	\N	\N	f	\N	\N	1	\N	\N	\N	727	5	\N	4
783	1922-11-22	\N	\N	f	\N	\N	1	\N	\N	\N	729	5	\N	4
784	1922-11-23	\N	\N	f	\N	\N	1	\N	\N	\N	730	5	\N	4
814	1926-08-04	\N	\N	f	Tredegar	3rd Lord	1	\N	20	\N	757	5	\N	4
757	1920-02-02	\N	\N	f	Midleton	9th Viscount 	1	\N	6	\N	706	5	3	4
787	1923-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	731	5	\N	4
789	1923-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	733	5	\N	4
780	1923-07-23	\N	\N	f	\N	\N	1	\N	12	\N	726	5	\N	4
790	1923-07-24	\N	\N	f	\N	\N	1	\N	12	\N	734	5	\N	4
792	1923-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	736	5	\N	4
793	1923-12-24	\N	\N	f	\N	\N	1	\N	\N	\N	737	5	\N	4
791	1924-01-08	\N	\N	f	\N	\N	1	\N	13	\N	735	5	\N	4
794	1924-01-12	\N	\N	f	\N	\N	1	\N	13	\N	738	5	\N	4
800	1924-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	743	5	\N	4
801	1924-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	744	5	\N	4
802	1924-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	745	5	\N	4
803	1924-05-07	\N	\N	f	\N	\N	1	\N	15	\N	746	5	\N	4
804	1925-01-19	\N	\N	f	\N	\N	1	\N	17	\N	747	5	\N	4
805	1925-01-28	\N	\N	f	\N	\N	1	\N	17	\N	748	5	\N	4
839	1925-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	783	5	\N	4
807	1925-06-12	\N	\N	f	\N	\N	1	\N	\N	\N	750	5	\N	4
808	1925-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	751	5	\N	4
810	1926-01-28	\N	\N	f	\N	\N	1	\N	19	\N	753	5	\N	4
816	1926-10-25	\N	\N	f	\N	\N	1	\N	\N	\N	759	5	\N	4
815	1927-01-18	\N	\N	f	\N	\N	1	\N	21	\N	758	5	\N	4
818	1927-01-29	\N	\N	f	\N	\N	1	\N	21	\N	761	5	\N	4
820	1927-06-21	\N	\N	f	\N	\N	1	\N	22	\N	763	5	\N	4
758	1917-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	707	5	\N	4
821	1927-07-04	\N	\N	f	\N	\N	1	\N	22	\N	764	5	\N	4
823	1927-11-07	\N	\N	f	\N	\N	1	\N	\N	\N	766	5	\N	4
824	1928-01-19	\N	\N	f	\N	\N	1	\N	23	\N	767	5	\N	4
826	1928-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	769	5	\N	4
825	1928-03-16	\N	\N	f	\N	\N	1	\N	23	\N	768	5	\N	4
838	1928-03-31	\N	\N	f	\N	\N	1	\N	\N	\N	782	5	\N	4
828	1928-04-05	\N	\N	f	\N	\N	1	\N	\N	\N	771	5	\N	4
829	1928-06-26	\N	\N	f	\N	\N	1	\N	24	\N	773	5	\N	4
830	1928-07-05	\N	\N	f	\N	\N	1	\N	24	\N	774	5	\N	4
832	1928-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	776	5	\N	4
834	1929-03-19	\N	\N	f	\N	\N	1	\N	25	\N	778	5	\N	4
837	1929-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	781	5	\N	4
836	1929-06-17	\N	\N	f	\N	\N	1	\N	26	\N	780	5	\N	4
756	1917-07-16	\N	\N	f	\N	\N	2	\N	\N	\N	705	5	\N	4
842	1929-06-18	\N	\N	f	\N	\N	2	\N	26	\N	786	5	\N	4
843	1929-06-19	\N	\N	f	\N	\N	1	\N	26	\N	787	5	\N	4
845	1929-06-21	\N	\N	f	\N	\N	1	\N	\N	\N	788	5	\N	4
847	1929-07-05	\N	\N	f	\N	\N	1	\N	27	\N	790	5	\N	4
848	1929-07-08	\N	\N	f	\N	\N	1	\N	27	\N	791	5	\N	4
849	1929-07-09	\N	\N	f	\N	\N	1	\N	27	\N	792	5	\N	4
889	1929-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	830	5	\N	4
891	1929-07-24	\N	\N	f	\N	\N	1	\N	26	\N	832	5	\N	4
854	1929-09-17	\N	\N	f	\N	\N	1	\N	\N	\N	797	5	\N	4
852	1930-01-16	\N	\N	f	\N	\N	1	\N	28	\N	795	5	\N	4
853	1930-01-17	\N	\N	f	\N	\N	1	\N	28	\N	796	5	\N	4
856	1930-01-20	\N	\N	f	\N	\N	1	\N	28	\N	799	5	\N	4
857	1930-01-21	\N	\N	f	\N	\N	1	\N	28	\N	800	5	\N	4
858	1930-01-23	\N	\N	f	\N	\N	1	\N	28	\N	801	5	\N	4
861	1930-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	804	5	\N	4
859	1930-06-17	\N	\N	f	\N	\N	1	\N	29	\N	802	5	\N	4
860	1930-06-18	\N	\N	f	\N	\N	1	\N	29	\N	803	5	\N	4
862	1930-07-10	\N	\N	f	\N	\N	1	\N	29	\N	805	5	\N	4
863	1931-01-20	\N	\N	f	\N	\N	1	\N	30	\N	806	5	\N	4
866	1931-01-23	\N	\N	f	\N	\N	1	\N	30	\N	809	5	\N	4
869	1931-03-23	\N	\N	f	\N	\N	1	\N	\N	\N	812	5	\N	4
867	1931-11-24	\N	\N	f	\N	\N	1	\N	31	\N	810	5	\N	4
870	1931-12-07	\N	\N	f	\N	\N	1	\N	31	\N	813	5	\N	4
871	1932-01-13	\N	\N	f	\N	\N	1	\N	32	\N	814	5	\N	4
872	1932-01-14	\N	\N	f	\N	\N	1	\N	32	\N	815	5	\N	4
873	1932-01-18	\N	\N	f	\N	\N	1	\N	32	\N	816	5	\N	4
875	1932-01-25	\N	\N	f	\N	\N	1	\N	32	\N	818	5	\N	4
881	1932-04-11	\N	\N	f	\N	\N	1	\N	\N	\N	822	5	\N	4
879	1932-06-17	\N	\N	f	\N	\N	1	\N	33	\N	820	5	\N	4
880	1932-06-20	\N	\N	f	\N	\N	1	\N	33	\N	821	5	\N	4
882	1932-06-21	\N	\N	f	\N	\N	1	\N	33	\N	823	5	\N	4
883	1932-06-28	\N	\N	f	\N	\N	1	\N	33	\N	824	5	\N	4
884	1932-06-30	\N	\N	f	\N	\N	1	\N	33	\N	825	5	\N	4
885	1933-01-19	\N	\N	f	\N	\N	1	\N	34	\N	826	5	\N	4
887	1933-01-26	\N	\N	f	\N	\N	1	\N	34	\N	828	5	\N	4
888	1933-02-03	\N	\N	f	\N	\N	1	\N	34	\N	829	5	\N	4
926	1933-03-01	\N	\N	f	\N	\N	1	\N	34	\N	864	5	\N	4
927	1933-06-21	\N	\N	f	\N	\N	1	\N	35	\N	865	5	\N	4
928	1933-06-22	\N	\N	f	\N	\N	1	\N	35	\N	866	5	\N	4
892	1933-06-24	\N	\N	f	\N	\N	1	\N	35	\N	833	5	\N	4
895	1934-01-12	\N	\N	f	\N	\N	1	\N	36	\N	836	5	\N	4
896	1934-01-15	\N	\N	f	\N	\N	1	\N	36	\N	837	5	\N	4
897	1934-01-16	\N	\N	f	\N	\N	1	\N	36	\N	838	5	\N	4
898	1934-06-27	\N	\N	f	\N	\N	1	\N	37	\N	839	5	\N	4
900	1934-06-28	\N	\N	f	\N	\N	2	\N	37	\N	840	5	\N	4
901	1934-06-29	\N	\N	f	\N	\N	1	\N	37	\N	841	5	\N	4
902	1935-01-24	\N	\N	f	\N	\N	1	\N	39	\N	842	5	\N	4
904	1935-01-26	\N	\N	f	\N	\N	1	\N	39	\N	844	5	\N	4
906	1935-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	845	5	\N	4
907	1935-06-24	\N	\N	f	\N	\N	2	\N	40	\N	846	5	\N	4
908	1935-06-25	\N	\N	f	\N	\N	1	\N	40	\N	847	5	\N	4
909	1935-06-27	\N	\N	f	\N	\N	1	\N	40	\N	848	5	\N	4
910	1935-06-28	\N	\N	f	\N	\N	1	\N	40	\N	849	5	\N	4
911	1935-06-29	\N	\N	f	\N	\N	1	\N	40	\N	850	5	\N	4
913	1935-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	852	5	\N	4
914	1935-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	853	5	\N	4
915	1935-10-14	\N	\N	f	\N	\N	1	\N	\N	\N	854	5	\N	4
917	1935-11-30	\N	\N	f	\N	\N	1	\N	\N	\N	856	5	\N	4
920	1936-02-01	\N	\N	f	\N	\N	1	\N	41	\N	858	5	\N	3
921	1936-02-03	\N	\N	f	\N	\N	1	\N	41	\N	859	5	\N	3
922	1936-02-24	\N	\N	f	\N	\N	1	\N	41	\N	860	5	\N	3
923	1936-07-14	\N	\N	f	\N	\N	1	\N	42	\N	861	5	\N	3
924	1936-07-15	\N	\N	f	\N	\N	1	\N	42	\N	862	5	\N	3
925	1936-07-16	\N	\N	f	\N	\N	1	\N	42	\N	863	5	\N	3
966	1937-02-23	\N	\N	f	\N	\N	1	\N	43	\N	900	5	\N	2
929	1937-02-24	\N	\N	f	\N	\N	1	\N	43	\N	867	5	\N	2
930	1937-05-22	\N	\N	f	\N	\N	1	\N	44	\N	868	5	\N	2
931	1937-05-24	\N	\N	f	\N	\N	1	\N	44	\N	869	5	\N	2
968	1939-09-22	\N	\N	f	Maugham	Lord	1	\N	\N	\N	853	5	\N	2
932	1937-06-03	\N	\N	f	\N	\N	1	\N	44	\N	870	5	\N	2
933	1937-06-04	\N	\N	f	\N	\N	1	\N	44	\N	871	5	\N	2
934	1937-06-07	\N	\N	f	\N	\N	1	\N	44	\N	872	5	\N	2
935	1937-06-08	\N	\N	f	\N	\N	1	\N	45	\N	873	5	\N	2
936	1937-06-08	\N	\N	f	\N	\N	2	\N	44	\N	874	5	\N	2
939	1937-06-10	\N	\N	f	\N	\N	1	\N	45	\N	877	5	\N	2
940	1937-06-10	\N	\N	f	\N	\N	2	\N	44	\N	878	5	\N	2
941	1937-06-11	\N	\N	f	\N	\N	1	\N	45	\N	879	5	\N	2
943	1937-06-12	\N	\N	f	\N	\N	1	\N	44	\N	881	5	\N	2
945	1938-01-05	\N	\N	f	\N	\N	1	\N	\N	\N	883	5	\N	2
946	1938-01-24	\N	\N	f	\N	\N	2	\N	46	\N	884	5	\N	2
947	1938-01-25	\N	\N	f	\N	\N	1	\N	46	\N	885	5	\N	2
949	1938-01-26	\N	\N	f	\N	\N	1	\N	46	\N	887	5	\N	2
950	1938-01-28	\N	\N	f	\N	\N	1	\N	46	\N	888	5	\N	2
952	1938-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	889	5	\N	2
955	1938-06-29	\N	\N	f	\N	\N	1	\N	47	\N	891	5	\N	2
958	1939-02-01	\N	\N	f	\N	\N	1	\N	48	\N	893	5	\N	2
959	1939-02-02	\N	\N	f	\N	\N	1	\N	48	\N	894	5	\N	2
960	1939-02-03	\N	\N	f	\N	\N	1	\N	48	\N	895	5	\N	2
961	1939-02-04	\N	\N	f	\N	\N	1	\N	48	\N	896	5	\N	2
963	1939-07-05	\N	\N	f	\N	\N	1	\N	49	\N	898	5	\N	2
967	1939-09-06	\N	\N	f	\N	\N	1	\N	\N	\N	901	5	\N	2
841	1929-06-18	\N	\N	f	\N	\N	1	\N	26	\N	785	5	\N	4
969	1940-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	902	5	\N	2
970	1940-05-20	\N	\N	f	\N	\N	1	\N	\N	\N	903	5	\N	2
972	1940-06-27	\N	\N	f	\N	\N	1	\N	50	\N	905	5	\N	2
973	1940-06-28	\N	\N	f	\N	\N	1	\N	50	\N	906	5	\N	2
948	1957-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	886	5	\N	1
876	1932-01-30	\N	\N	f	Sankey	1st Lord	1	\N	32	\N	788	5	\N	4
851	1926-07-16	\N	\N	f	\N	\N	1	\N	20	\N	794	5	\N	4
976	1941-01-27	\N	\N	f	\N	\N	1	\N	51	\N	908	5	\N	2
977	1941-01-28	\N	\N	f	\N	\N	1	\N	51	\N	909	5	\N	2
978	1941-01-29	\N	\N	f	\N	\N	1	\N	51	\N	910	5	\N	2
980	1941-05-19	\N	\N	f	\N	\N	1	\N	\N	\N	912	5	\N	2
981	1941-07-16	\N	\N	f	\N	\N	1	\N	52	\N	913	5	\N	2
982	1941-07-16	\N	\N	f	\N	\N	2	\N	52	\N	914	5	\N	2
985	1941-08-06	\N	\N	f	\N	\N	1	\N	\N	\N	917	5	\N	2
984	1942-01-16	\N	\N	f	\N	\N	1	\N	53	\N	916	5	\N	2
987	1942-01-21	\N	\N	f	\N	\N	1	\N	53	\N	919	5	\N	2
988	1942-01-28	\N	\N	f	\N	\N	1	\N	54	\N	920	5	\N	2
993	1942-04-02	\N	\N	f	\N	\N	1	\N	\N	\N	925	5	\N	2
994	1942-04-27	\N	\N	f	\N	\N	1	\N	\N	\N	926	5	\N	2
991	1942-07-06	\N	\N	f	\N	\N	1	\N	55	\N	923	5	\N	2
992	1943-01-22	\N	\N	f	\N	\N	1	\N	56	\N	924	5	\N	2
998	1943-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	930	5	\N	2
996	1943-03-08	\N	\N	f	\N	\N	1	\N	56	\N	928	5	\N	2
1035	1943-05-03	\N	\N	f	\N	\N	1	\N	\N	\N	932	5	\N	2
997	1943-05-17	\N	\N	f	\N	\N	1	\N	56	\N	929	5	\N	2
999	1943-07-05	\N	\N	f	\N	\N	1	\N	57	\N	931	5	\N	2
1002	1943-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	935	5	\N	2
1000	1944-01-27	\N	\N	f	\N	\N	1	\N	58	\N	933	5	\N	2
1036	1944-01-29	\N	\N	f	\N	\N	1	\N	58	\N	965	5	\N	2
1040	1944-02-01	\N	\N	f	\N	\N	1	\N	58	\N	969	5	\N	2
1006	1944-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	939	5	\N	2
1008	1944-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	940	5	\N	2
1009	1944-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	941	5	\N	2
1011	1945-02-12	\N	\N	f	\N	\N	1	\N	60	\N	943	5	\N	2
1012	1945-02-12	\N	\N	f	\N	\N	2	\N	60	\N	944	5	\N	2
1013	1945-07-02	\N	\N	f	\N	\N	2	\N	61	\N	945	5	\N	2
1014	1945-07-03	\N	\N	f	\N	\N	1	\N	61	\N	946	5	\N	2
1015	1945-07-05	\N	\N	f	\N	\N	1	\N	61	\N	947	5	\N	2
1017	1945-07-07	\N	\N	f	\N	\N	1	\N	61	\N	949	5	\N	2
1018	1945-07-09	\N	\N	f	\N	\N	1	\N	61	\N	950	5	\N	2
1019	1945-07-10	\N	\N	f	\N	\N	1	\N	62	\N	951	5	\N	2
1021	1945-07-12	\N	\N	f	\N	\N	1	\N	62	\N	953	5	\N	2
1022	1945-07-13	\N	\N	f	\N	\N	1	\N	62	\N	954	5	\N	2
1024	1945-07-23	\N	\N	f	\N	\N	1	\N	61	\N	956	5	\N	2
1027	1945-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	958	5	\N	2
1028	1945-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	959	5	\N	2
1049	1946-01-29	\N	\N	f	Alanbrooke	1st Lord	1	\N	65	\N	963	5	\N	2
1029	1945-09-12	\N	\N	f	\N	\N	2	\N	64	\N	960	5	\N	2
1031	1945-09-13	\N	\N	f	\N	\N	2	\N	64	\N	961	5	\N	2
1032	1945-09-14	\N	\N	f	\N	\N	1	\N	64	\N	962	5	\N	2
1033	1945-09-18	\N	\N	f	\N	\N	1	\N	64	\N	963	5	\N	2
1034	1945-09-19	\N	\N	f	\N	\N	1	\N	63	\N	964	5	\N	2
1037	1945-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	966	5	\N	2
1038	1945-10-19	\N	\N	f	\N	\N	1	\N	\N	\N	967	5	\N	2
1077	1945-11-13	\N	\N	f	\N	\N	1	\N	\N	\N	1003	5	\N	2
1079	1945-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	1005	5	\N	2
1041	1945-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	970	5	\N	2
1042	1945-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	971	5	\N	2
1044	1945-12-01	\N	\N	f	\N	\N	1	\N	\N	\N	973	5	\N	2
1073	1947-01-20	\N	\N	f	Jowitt	1st Lord	1	\N	67	\N	958	5	\N	2
1050	1946-01-30	\N	\N	f	\N	\N	1	\N	65	\N	977	5	\N	2
1051	1946-01-31	\N	\N	f	\N	\N	1	\N	65	\N	978	5	\N	2
1053	1946-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	980	5	\N	2
1026	1945-09-12	\N	\N	f	Kemsley	1st Lord	1	\N	64	\N	859	5	\N	2
1052	1946-02-11	\N	\N	f	\N	\N	1	\N	65	\N	979	5	\N	2
1055	1946-02-12	\N	\N	f	\N	\N	1	\N	65	\N	982	5	\N	2
1056	1946-03-01	\N	\N	f	\N	\N	1	\N	65	\N	983	5	\N	2
1057	1946-03-12	\N	\N	f	\N	\N	1	\N	65	\N	984	5	\N	2
1059	1946-04-05	\N	\N	f	\N	\N	1	\N	\N	\N	986	5	\N	2
1061	1946-06-27	\N	\N	f	\N	\N	1	\N	66	\N	988	5	\N	2
1062	1946-07-16	\N	\N	f	\N	\N	1	\N	66	\N	989	5	\N	2
1063	1946-07-17	\N	\N	f	\N	\N	1	\N	66	\N	990	5	\N	2
1064	1946-07-18	\N	\N	f	\N	\N	1	\N	66	\N	991	5	\N	2
1065	1946-09-19	\N	\N	f	\N	\N	1	\N	65	\N	992	5	\N	2
1067	1946-10-28	\N	\N	f	\N	\N	1	\N	\N	\N	994	5	\N	2
1066	1947-01-13	\N	\N	f	\N	\N	1	\N	67	\N	993	5	\N	2
1069	1947-01-14	\N	\N	f	\N	\N	1	\N	67	\N	996	5	\N	2
1071	1947-01-16	\N	\N	f	\N	\N	1	\N	67	\N	998	5	\N	2
1083	1948-02-02	\N	\N	f	Hyndley	1st Lord	1	\N	69	\N	807	5	\N	2
1074	1947-01-20	\N	\N	f	\N	\N	2	\N	67	\N	1000	5	\N	2
1075	1947-01-21	\N	\N	f	\N	\N	1	\N	67	\N	1001	5	\N	2
1076	1947-03-18	\N	\N	f	\N	\N	1	\N	67	\N	1002	5	\N	2
1080	1947-07-15	\N	\N	f	\N	\N	1	\N	68	\N	1006	5	\N	2
1081	1947-07-16	\N	\N	f	\N	\N	1	\N	68	\N	1007	5	\N	2
1084	1948-02-06	\N	\N	f	\N	\N	1	\N	69	\N	1010	5	\N	2
1085	1948-02-07	\N	\N	f	\N	\N	1	\N	69	\N	1011	5	\N	2
1088	1948-06-23	\N	\N	f	\N	\N	1	\N	70	\N	1014	5	\N	2
1089	1948-06-24	\N	\N	f	\N	\N	1	\N	70	\N	1015	5	\N	2
1091	1948-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	1017	5	\N	2
1090	1949-02-16	\N	\N	f	\N	\N	1	\N	71	\N	1016	5	\N	2
1092	1949-03-09	\N	\N	f	\N	\N	1	\N	71	\N	1018	5	\N	2
1004	1940-06-26	\N	\N	f	\N	\N	1	\N	50	\N	937	5	\N	2
1094	1949-04-13	\N	\N	f	\N	\N	1	\N	\N	\N	1020	5	\N	2
1095	1949-07-07	\N	\N	f	\N	\N	1	\N	71	\N	1021	5	\N	2
1096	1949-07-12	\N	\N	f	\N	\N	1	\N	72	\N	1022	5	\N	2
1097	1950-01-30	\N	\N	f	\N	\N	1	\N	73	\N	1023	5	\N	2
1099	1950-02-01	\N	\N	f	\N	\N	1	\N	73	\N	1025	5	\N	2
1101	1950-02-03	\N	\N	f	\N	\N	1	\N	73	\N	1027	5	\N	2
1103	1950-03-17	\N	\N	f	\N	\N	1	\N	\N	\N	1029	5	\N	2
1104	1950-04-11	\N	\N	f	\N	\N	1	\N	\N	\N	1030	5	\N	2
1102	1950-07-04	\N	\N	f	\N	\N	1	\N	74	\N	1028	5	\N	2
1106	1950-07-06	\N	\N	f	\N	\N	1	\N	74	\N	1032	5	\N	2
1107	1950-07-07	\N	\N	f	\N	\N	1	\N	74	\N	1033	5	\N	2
1108	1950-07-08	\N	\N	f	\N	\N	1	\N	74	\N	1034	5	\N	2
1110	1950-07-11	\N	\N	f	\N	\N	1	\N	74	\N	1036	5	\N	2
1111	1951-01-25	\N	\N	f	\N	\N	1	\N	75	\N	1037	5	\N	2
1001	1939-07-07	\N	\N	f	\N	\N	1	\N	49	\N	934	5	\N	2
1114	1947-11-20	\N	\N	f	\N	\N	1	\N	\N	\N	1040	5	\N	2
1115	1951-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	1041	5	\N	2
1151	1951-06-27	\N	\N	f	\N	\N	1	\N	76	\N	1070	5	\N	2
1152	1951-10-16	\N	\N	f	\N	\N	1	\N	76	\N	1071	5	\N	2
1119	1951-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	1044	5	\N	2
1120	1951-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	1045	5	\N	2
1121	1951-12-22	\N	\N	f	\N	\N	1	\N	77	\N	1046	5	\N	2
1123	1951-12-24	\N	\N	f	\N	\N	2	\N	77	\N	1047	5	\N	2
1125	1952-01-28	\N	\N	f	\N	\N	1	\N	78	\N	1049	5	\N	2
1126	1952-01-30	\N	\N	f	\N	\N	1	\N	77	\N	1050	5	\N	2
1128	1952-04-10	\N	\N	f	\N	\N	1	\N	78	\N	1052	5	\N	1
1139	1953-07-02	\N	\N	f	Woolton	1st Lord	1	\N	81	\N	934	5	\N	1
1131	1952-07-01	\N	\N	f	\N	\N	1	\N	79	\N	1053	5	\N	1
1132	1952-07-05	\N	\N	f	\N	\N	1	\N	79	\N	1054	5	\N	1
1133	1952-07-12	\N	\N	f	\N	\N	1	\N	79	\N	1055	5	\N	1
1134	1953-02-11	\N	\N	f	\N	\N	1	\N	80	\N	1056	5	\N	1
1136	1953-06-29	\N	\N	f	\N	\N	1	\N	81	\N	1058	5	\N	1
1137	1953-06-30	\N	\N	f	\N	\N	1	\N	81	\N	1059	5	\N	1
1138	1953-07-01	\N	\N	f	\N	\N	1	\N	81	\N	1060	5	\N	1
1194	1958-07-26	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	1111	5	\N	1
1142	1953-10-16	\N	\N	f	\N	\N	1	\N	\N	\N	1063	5	\N	1
1143	1953-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	1064	5	\N	1
1140	1954-01-14	\N	\N	f	\N	\N	1	\N	82	\N	1061	5	\N	1
1141	1954-01-16	\N	\N	f	\N	\N	1	\N	82	\N	1062	5	\N	1
1147	1954-02-16	\N	\N	f	\N	\N	1	\N	82	\N	1067	5	\N	1
1148	1954-07-03	\N	\N	f	\N	\N	1	\N	83	\N	1068	5	\N	1
1146	1954-01-30	\N	\N	t	Drogheda	10th Earl 	1	\N	82	\N	1066	5	3	1
1150	1954-07-31	\N	\N	f	\N	\N	1	\N	83	\N	1069	5	\N	1
1153	1954-09-09	\N	\N	f	\N	\N	1	\N	\N	\N	1072	5	\N	1
1155	1954-10-19	\N	\N	f	\N	\N	1	\N	\N	\N	1073	5	\N	1
1192	1955-01-28	\N	\N	f	\N	\N	1	\N	84	\N	1110	5	\N	1
1195	1955-02-18	\N	\N	f	\N	\N	1	\N	84	\N	1112	5	\N	1
1157	1955-03-18	\N	\N	f	\N	\N	1	\N	\N	\N	1075	5	\N	1
1158	1955-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	1076	5	\N	1
1159	1955-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	1077	5	\N	1
1160	1955-07-25	\N	\N	f	\N	\N	1	\N	85	\N	1078	5	\N	1
1163	1955-12-16	\N	\N	f	\N	\N	1	\N	\N	\N	1081	5	\N	1
1165	1956-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	1083	5	\N	1
1166	1956-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	1084	5	\N	1
1167	1956-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	1085	5	\N	1
1168	1956-01-19	\N	\N	f	\N	\N	1	\N	\N	\N	1086	5	\N	1
1162	1956-01-20	\N	\N	f	\N	\N	1	\N	86	\N	1080	5	\N	1
1169	1956-01-21	\N	\N	f	\N	\N	1	\N	86	\N	1087	5	\N	1
1170	1956-01-23	\N	\N	f	\N	\N	1	\N	86	\N	1088	5	\N	1
1172	1956-07-09	\N	\N	f	\N	\N	1	\N	87	\N	1090	5	\N	1
1173	1956-07-16	\N	\N	f	\N	\N	1	\N	87	\N	1091	5	\N	1
1176	1957-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	1094	5	\N	1
1177	1957-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	1095	5	\N	1
1178	1957-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	1096	5	\N	1
1175	1957-07-01	\N	\N	f	\N	\N	1	\N	89	\N	1093	5	\N	1
1181	1958-01-31	\N	\N	f	\N	\N	1	\N	90	\N	1099	5	\N	1
1183	1958-02-17	\N	\N	f	\N	\N	1	\N	90	\N	1101	5	\N	1
1184	1958-07-10	\N	\N	f	\N	\N	1	\N	91	\N	1102	5	\N	1
1185	1958-07-11	\N	\N	f	\N	\N	1	\N	91	\N	1103	5	\N	1
1213	1960-01-20	\N	\N	f	Rochdale	2nd Lord	1	\N	96	\N	1134	5	\N	1
1186	1958-08-01	\N	\N	f	\N	\N	1	\N	285	\N	1104	5	\N	1
1187	1958-08-02	\N	\N	f	\N	\N	1	\N	285	\N	1105	5	\N	1
1189	1958-08-05	\N	\N	f	\N	\N	1	\N	285	\N	1107	5	\N	1
1191	1958-08-07	\N	\N	f	\N	\N	1	\N	285	\N	1109	5	\N	1
1221	1958-08-11	\N	\N	f	\N	\N	1	\N	285	\N	1142	5	\N	1
1230	1958-08-18	\N	\N	f	\N	\N	1	\N	285	\N	1151	5	\N	1
1234	1958-08-22	\N	\N	f	\N	\N	1	\N	285	\N	1152	5	\N	1
1197	1958-09-24	\N	\N	f	\N	\N	1	\N	285	\N	1115	5	\N	1
1198	1958-09-30	\N	\N	f	\N	\N	1	\N	\N	\N	1118	5	\N	1
1199	1959-02-14	\N	\N	f	\N	\N	1	\N	93	\N	1119	5	\N	1
1200	1959-02-16	\N	\N	f	\N	\N	1	\N	92	\N	1120	5	\N	1
1201	1959-02-17	\N	\N	f	\N	\N	1	\N	93	\N	1121	5	\N	1
1203	1959-03-10	\N	\N	f	\N	\N	1	\N	92	\N	1123	5	\N	1
1205	1959-04-06	\N	\N	f	\N	\N	1	\N	\N	\N	1125	5	\N	1
1204	1959-06-16	\N	\N	f	\N	\N	1	\N	93	\N	1124	5	\N	1
1206	1959-07-15	\N	\N	f	\N	\N	1	\N	94	\N	1126	5	\N	1
1207	1959-07-16	\N	\N	f	\N	\N	1	\N	94	\N	1127	5	\N	1
1209	1959-11-02	\N	\N	f	\N	\N	1	\N	95	\N	1129	5	\N	1
1211	1959-11-03	\N	\N	f	\N	\N	1	\N	\N	\N	1131	5	\N	1
1210	1959-11-20	\N	\N	f	\N	\N	1	\N	95	\N	1130	5	\N	1
1231	1959-12-16	\N	\N	f	\N	\N	1	\N	95	\N	1133	5	\N	1
1214	1960-01-20	\N	\N	f	\N	\N	2	\N	96	\N	1135	5	\N	1
1216	1960-01-30	\N	\N	f	\N	\N	1	\N	96	\N	1137	5	\N	1
1217	1960-02-08	\N	\N	f	\N	\N	1	\N	96	\N	1138	5	\N	1
1219	1960-04-12	\N	\N	f	\N	\N	1	\N	\N	\N	1140	5	\N	1
1218	1960-07-04	\N	\N	f	\N	\N	1	\N	97	\N	1139	5	\N	1
1222	1960-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	1143	5	\N	1
1223	1960-08-22	\N	\N	f	\N	\N	1	\N	\N	\N	1144	5	\N	1
1117	1947-07-03	\N	\N	f	\N	\N	1	\N	68	\N	1043	5	\N	2
1224	1960-09-01	\N	\N	f	\N	\N	1	\N	\N	\N	1145	5	\N	1
1227	1960-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	1148	5	\N	1
1228	1960-11-23	\N	\N	f	\N	\N	1	\N	\N	\N	1149	5	\N	1
1229	1961-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	1150	5	\N	1
1236	1961-02-09	\N	\N	f	\N	\N	1	\N	99	\N	1154	5	\N	1
1237	1961-02-10	\N	\N	f	\N	\N	1	\N	99	\N	1155	5	\N	1
1239	1961-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	1157	5	\N	1
1238	1961-02-21	\N	\N	f	\N	\N	1	\N	99	\N	1156	5	\N	1
1241	1961-06-02	\N	\N	f	\N	\N	1	\N	\N	\N	1159	5	\N	1
1240	1961-06-28	\N	\N	f	\N	\N	1	\N	100	\N	1158	5	\N	1
1242	1961-06-29	\N	\N	f	\N	\N	1	\N	100	\N	1160	5	\N	1
1245	1961-10-11	\N	\N	f	\N	\N	1	\N	\N	\N	1163	5	\N	1
1244	1962-01-25	\N	\N	f	\N	\N	1	\N	101	\N	1162	5	\N	1
1248	1962-02-02	\N	\N	f	\N	\N	1	\N	\N	\N	1166	5	\N	1
1130	1952-06-24	\N	\N	f	Simonds	Lord	1	\N	79	\N	939	5	\N	1
1116	1947-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	1042	5	\N	2
1315	1964-12-23	\N	\N	f	\N	\N	1	\N	114	\N	1230	5	\N	1
2997	1706-12-27	\N	\N	f	Cholmondeley	Viscount	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 33; dated 29 (sic) Dec. in CP, iii, 201	\N	\N	2905	1	3	16
1322	1965-01-28	\N	\N	f	\N	\N	1	\N	116	\N	1237	5	\N	1
2998	1706-12-26	\N	\N	f	Godolphin	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 34	\N	\N	2906	1	\N	16
2999	1706-12-24	\N	\N	f	Poulett	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 36	\N	\N	2907	1	\N	16
3000	1706-12-23	\N	\N	f	Wharton	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 35	\N	\N	2908	1	\N	16
3001	1706-12-23	\N	\N	t	Kingston	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 1 (C 66/3453) no. 37	\N	\N	2909	1	\N	16
1332	1965-05-12	\N	\N	f	\N	\N	2	\N	118	1	1248	5	\N	1
3002	1706-12-21	\N	\N	t	Lindsey	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 1 (C 66/3453) no. 38	\N	\N	2910	1	\N	16
3003	1706-12-16	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 4	\N	\N	2911	1	\N	16
3004	1706-12-14	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 17	\N	\N	2912	1	\N	16
3005	1800-12-29	\N	\N	f	Malmesbury	Lord	\N	C 231/13, p. 285; 41 Geo. III, pt. 4 (C 66/3982) no. 1	\N	\N	2913	4	\N	9
3006	1800-12-27	\N	\N	f	Cadogan	Lord	\N	C 231/13, p. 285; 41 Geo. III, pt. 4 (C 66/3982) no. 2	\N	\N	2914	4	\N	9
3007	1800-06-16	\N	\N	f	Bridport	Lord	\N	C 231/13, p. 248; 40 Geo. III, pt. 11 (C66/3973) no. 6	\N	\N	2915	4	3	9
3008	1799-09-24	\N	\N	t	Clare	Earl	\N	C 231/13, p. 231; 39 Geo. III, pt. 11 (C 66/3962) no. 1	\N	\N	2916	4	3	9
3009	1799-07-18	Sir	Kt.	f	\N	\N	\N	C 231/13, p. 230; 39 Geo. III, pt. 11 (C 66/3962) no. 18	\N	\N	110	4	\N	9
3010	1898-11-11	Hon.	\N	f	\N	\N	\N	LJ, cxl, 19	\N	\N	711	3	\N	\N
3011	1868-12-21	\N	\N	f	\N	\N	\N	LP printed in LJ, ci, 229-30	\N	\N	2917	3	\N	\N
3012	1868-08-10	\N	\N	t	Abercorn	Marquess	\N	CP, i, 9	\N	\N	2918	3	4	\N
3013	1863-12-14	Sir	Bart.	f	\N	\N	\N	LP printed in LJ, xcvi, 87-8	\N	\N	279	3	\N	\N
3014	1855-05-14	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxviii, 85-6; The House of Lords resolved 1 July 1856 that grantee had not made out his claim to vote at elections for representative peers (ibid. 336); in consequence he received fresh LP 10 Sept. 1856	\N	\N	2919	3	\N	\N
1333	1965-05-13	\N	\N	f	\N	\N	1	\N	118	2	1249	5	\N	1
3015	1852-02-11	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxv, 537-9	\N	\N	278	3	\N	\N
3016	1848-07-10	Sir	Bart.	f	\N	\N	\N	LP printed in LJ, lxxxviii, 387-8	\N	\N	2920	3	\N	\N
3017	1706-12-14	\N	\N	t	Kent	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 2 (C 66/3454) no. 1; dated 14 Nov. (sic) in CP, vii, 177	\N	\N	2921	1	\N	16
3018	1706-12-09	Prince	\N	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 3; dated 9 Nov. (sic) in CP, ii, 497	\N	\N	2922	1	\N	16
3019	1705-11-26	\N	\N	t	Argyll	Duke	\N	C 231/9, p. 134; 4 Ann., pt. 4 (C 66/3451) no. 9	\N	\N	2923	1	2	16
3020	1705-04-14	\N	\N	t	Montagu	Earl	\N	C 231/9, p. 124; 4 Ann., pt. 1 (C 66/3448) no. 16	\N	\N	2924	1	\N	16
3021	1703-03-29	\N	\N	t	Rutland	Earl	\N	C 231/9, p. 93; 2 Ann., pt. 2 (C 66/3439) no. 17	\N	\N	2925	1	\N	16
3022	1703-03-24	\N	\N	t	Normanby	Marquess	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 20; dated 23 (sic) Mar. in CP, ii, 398 but 24 Mar. in ibid., ix, 638	\N	\N	2926	1	\N	16
3023	1703-03-23	\N	\N	f	\N	\N	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 12	\N	\N	2927	1	\N	16
3024	1703-03-17	\N	\N	f	\N	\N	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 22; CP, iii, 402 omits mention of remainder to Seymour	\N	\N	2928	1	\N	16
3025	1703-03-16	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 91; 2 Ann., pt. 2 (C 66/3439) no. 27	\N	\N	2929	1	\N	16
3026	1799-04-24	Prince	\N	f	\N	\N	\N	C 231/13, p. 221; 39 Geo. III, pt. 7 (C 66/3958) no. 2	\N	\N	2930	4	\N	9
3027	1799-04-24	Prince	\N	f	\N	\N	\N	C 231/13, p. 221; 39 Geo. III, pt. 7 (C 66/3958) no. 3	\N	\N	2931	4	\N	9
3028	1798-11-06	Sir	Kt.	f	\N	\N	\N	C 231/13, p. 214; 39 Geo. III, pt. 1 (C 66/3952) no. 8	\N	\N	3	4	\N	9
1334	1965-05-13	\N	\N	f	\N	\N	2	\N	118	1	1250	5	\N	1
3029	1797-11-30	\N	\N	f	de Dunstanville	Lord	\N	C 231/13, p. 197; 38 Geo. III, pt. 2 (C 66/3944) no. 22	\N	\N	2932	4	\N	9
3030	1797-10-30	\N	\N	f	\N	\N	\N	C 231/13, p. 195; 38 Geo. III, pt. 1 (C 66/3943) no. 10	\N	\N	2933	4	\N	9
3031	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 11	\N	\N	2934	4	\N	9
3032	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 12	\N	\N	2935	4	\N	9
3033	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 13	\N	\N	2936	4	\N	9
3034	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 14	\N	\N	2937	4	\N	9
3035	1845-06-03	\N	\N	f	\N	\N	\N	LJ, lxxvii, 734; dated 6 (sic) June 1845 in CP, iv, 550	\N	\N	2938	3	\N	\N
1335	1965-05-14	\N	\N	f	\N	\N	1	\N	118	2	1251	5	\N	1
3036	1836-05-04	\N	\N	f	\N	\N	\N	Abstract, p. 67	\N	\N	2939	3	\N	\N
1336	1965-05-14	\N	\N	f	\N	\N	2	\N	118	1	1252	5	\N	1
1337	1965-06-22	\N	\N	f	\N	\N	1	\N	119	\N	1253	5	\N	1
1253	1962-05-10	\N	\N	f	\N	\N	1	\N	102	\N	1172	5	\N	1
1251	1962-05-03	\N	\N	f	\N	\N	1	\N	102	\N	1170	5	\N	1
1254	1962-05-11	\N	\N	f	\N	\N	1	\N	102	\N	1173	5	\N	1
1255	1962-05-14	\N	\N	f	\N	\N	1	\N	102	\N	1174	5	\N	1
1256	1962-05-15	\N	\N	f	\N	\N	1	\N	102	\N	1175	5	\N	1
1271	1962-07-20	\N	\N	f	Kilmuir	1st Viscount	1	\N	\N	\N	1073	5	\N	1
1260	1962-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	1179	5	\N	1
1367	1967-07-10	\N	\N	f	\N	\N	1	\N	124	\N	1285	5	\N	1
1368	1967-07-11	\N	\N	f	\N	\N	1	\N	124	\N	1286	5	\N	1
1371	1967-08-30	\N	\N	f	\N	\N	1	\N	125	\N	1290	5	\N	1
1372	1967-09-11	\N	\N	f	\N	\N	1	\N	125	\N	1291	5	\N	1
1373	1967-09-12	\N	\N	f	\N	\N	1	\N	125	\N	1292	5	\N	1
1374	1967-09-14	\N	\N	f	\N	\N	1	\N	125	\N	1293	5	\N	1
1375	1967-09-18	\N	\N	f	\N	\N	1	\N	125	\N	1295	5	\N	1
1376	1967-09-19	\N	\N	f	\N	\N	1	\N	125	\N	1296	5	\N	1
1377	1967-09-20	\N	\N	f	\N	\N	1	\N	126	\N	1297	5	\N	1
1379	1967-09-22	\N	\N	f	\N	\N	1	\N	125	\N	1299	5	\N	1
1380	1967-10-13	\N	\N	f	\N	\N	1	\N	125	\N	1300	5	\N	1
1381	1967-11-20	\N	\N	f	\N	\N	1	\N	125	\N	1301	5	\N	1
1384	1967-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	1304	5	\N	1
1258	1962-07-11	\N	\N	f	Radcliffe	Lord	1	\N	103	\N	1177	5	\N	1
1313	1964-12-22	\N	\N	f	\N	\N	1	\N	115	2	1228	5	\N	1
1314	1964-12-22	\N	\N	f	\N	\N	2	\N	115	1	1229	5	\N	1
1389	1967-08-29	\N	\N	f	\N	\N	1	\N	125	\N	1289	5	\N	1
1422	1967-12-04	\N	\N	f	\N	\N	1	\N	127	\N	1341	5	\N	1
1424	1968-01-18	\N	\N	f	\N	\N	1	\N	128	\N	1343	5	\N	1
1387	1968-01-29	\N	\N	f	\N	\N	1	\N	128	\N	1307	5	\N	1
1388	1968-02-12	\N	\N	f	\N	\N	1	\N	128	\N	1308	5	\N	1
1392	1968-05-21	\N	\N	f	\N	\N	1	\N	129	\N	1309	5	\N	1
1393	1968-06-20	\N	\N	f	\N	\N	1	\N	130	\N	1310	5	\N	1
1394	1968-06-21	\N	\N	f	\N	\N	1	\N	130	\N	1311	5	\N	1
1395	1968-06-28	\N	\N	f	\N	\N	1	\N	130	\N	1312	5	\N	1
1399	1968-09-30	\N	\N	f	\N	\N	1	\N	131	\N	1316	5	\N	1
1400	1969-01-09	\N	\N	f	\N	\N	1	\N	133	\N	1317	5	\N	1
1401	1969-01-27	\N	\N	f	\N	\N	1	\N	133	\N	1318	5	\N	1
1402	1969-02-21	\N	\N	f	\N	\N	1	\N	133	\N	1319	5	\N	1
1403	1969-03-24	\N	\N	f	\N	\N	1	\N	133	\N	1320	5	\N	1
1404	1969-07-02	\N	\N	f	\N	\N	1	\N	135	\N	1321	5	\N	1
1406	1969-07-24	\N	\N	f	\N	\N	1	\N	135	\N	1323	5	\N	1
1407	1970-01-16	\N	\N	f	\N	\N	1	\N	136	\N	1324	5	\N	1
1409	1970-02-05	\N	\N	f	\N	\N	1	\N	136	\N	1326	5	\N	1
1410	1970-06-19	\N	\N	f	\N	\N	1	\N	137	\N	1328	5	\N	1
1412	1970-06-30	\N	\N	f	\N	\N	1	\N	139	\N	1330	5	\N	1
1413	1970-07-02	\N	\N	f	\N	\N	1	\N	137	\N	1332	5	\N	1
1414	1970-07-03	\N	\N	f	\N	\N	1	\N	137	\N	1333	5	\N	1
1415	1970-07-04	\N	\N	f	\N	\N	1	\N	137	\N	1334	5	\N	1
1416	1970-07-06	\N	\N	f	\N	\N	1	\N	138	\N	1335	5	\N	1
1417	1970-07-07	\N	\N	f	\N	\N	1	\N	137	\N	1336	5	\N	1
1419	1970-07-09	\N	\N	f	\N	\N	1	\N	137	\N	1338	5	\N	1
1420	1970-07-28	\N	\N	f	\N	\N	1	\N	138	\N	1339	5	\N	1
1421	1970-07-31	\N	\N	f	\N	\N	1	\N	138	\N	1340	5	\N	1
1459	1970-09-22	\N	\N	f	\N	\N	1	\N	140	\N	1382	5	\N	1
1461	1970-09-28	\N	\N	f	\N	\N	1	\N	140	\N	1384	5	\N	1
1430	1970-10-12	\N	\N	f	\N	\N	1	\N	140	\N	1344	5	\N	1
1425	1970-11-06	\N	\N	f	\N	\N	1	\N	140	\N	1346	5	\N	1
1431	1971-03-02	\N	\N	f	\N	\N	1	\N	142	\N	1349	5	\N	1
1433	1971-03-12	\N	\N	f	\N	\N	1	\N	144	\N	1351	5	\N	1
1434	1971-04-20	\N	\N	f	\N	\N	1	\N	143	\N	1352	5	\N	1
1436	1971-05-01	\N	\N	f	\N	\N	1	\N	145	\N	1354	5	\N	1
1437	1971-05-17	\N	\N	f	\N	\N	1	\N	145	\N	1355	5	\N	1
1468	1971-05-18	\N	\N	f	\N	\N	1	\N	145	\N	1356	5	\N	1
1438	1971-05-21	\N	\N	f	\N	\N	1	\N	145	\N	1357	5	\N	1
1470	1971-05-24	\N	\N	f	\N	\N	1	\N	145	\N	1358	5	\N	1
1440	1971-07-20	\N	\N	f	\N	\N	1	\N	146	\N	1361	5	\N	1
1441	1971-10-04	\N	\N	f	\N	\N	1	\N	147	\N	1362	5	\N	1
1443	1972-04-20	\N	\N	f	\N	\N	1	\N	149	\N	1364	5	\N	1
1444	1972-04-24	\N	\N	f	\N	\N	1	\N	149	\N	1365	5	\N	1
1445	1972-04-26	\N	\N	f	\N	\N	1	\N	149	\N	1366	5	\N	1
1446	1972-04-28	\N	\N	f	\N	\N	1	\N	149	\N	1367	5	\N	1
1447	1972-05-01	\N	\N	f	\N	\N	1	\N	149	\N	1368	5	\N	1
1467	1972-05-02	\N	\N	f	\N	\N	1	\N	149	\N	1369	5	\N	1
1448	1972-05-09	\N	\N	f	\N	\N	1	\N	149	\N	1370	5	\N	1
1451	1972-07-10	\N	\N	f	\N	\N	1	\N	150	\N	1373	5	\N	1
1452	1973-02-05	\N	\N	f	\N	\N	1	\N	151	\N	1374	5	\N	1
1453	1973-03-14	\N	\N	f	\N	\N	1	\N	152	\N	1375	5	\N	1
1455	1973-06-25	\N	\N	f	\N	\N	1	\N	153	\N	1378	5	\N	1
1456	1973-06-29	\N	\N	f	\N	\N	1	\N	153	\N	1379	5	\N	1
1457	1973-07-06	\N	\N	f	\N	\N	1	\N	153	\N	1380	5	\N	1
1497	1974-03-06	\N	\N	f	\N	\N	1	\N	154	\N	1422	5	\N	1
1498	1974-03-07	\N	\N	f	\N	\N	1	\N	154	\N	1423	5	\N	1
1463	1974-03-26	\N	\N	f	\N	\N	1	\N	157	\N	1386	5	\N	1
1464	1974-05-02	\N	\N	f	\N	\N	1	\N	159	\N	1387	5	\N	1
1465	1974-05-03	\N	\N	f	\N	\N	1	\N	159	\N	1388	5	\N	1
1466	1974-05-06	\N	\N	f	\N	\N	1	\N	159	\N	1389	5	\N	1
1472	1974-05-09	\N	\N	f	\N	\N	1	\N	159	\N	1391	5	\N	1
1473	1974-05-10	\N	\N	f	\N	\N	1	\N	160	\N	1392	5	\N	1
1506	1974-05-13	\N	\N	f	\N	\N	1	\N	159	\N	1393	5	\N	1
1508	1974-05-14	\N	\N	f	\N	\N	1	\N	160	\N	1394	5	\N	1
1474	1974-05-16	\N	\N	f	\N	\N	1	\N	160	\N	1396	5	\N	1
1475	1974-06-11	\N	\N	f	\N	\N	1	\N	159	\N	1397	5	\N	1
1477	1974-06-19	\N	\N	f	\N	\N	1	\N	161	\N	1399	5	\N	1
1478	1974-06-20	\N	\N	f	\N	\N	1	\N	161	\N	1400	5	\N	1
1479	1974-06-21	\N	\N	f	\N	\N	1	\N	161	\N	1401	5	\N	1
1480	1974-06-24	\N	\N	f	\N	\N	1	\N	161	\N	1402	5	\N	1
1509	1974-06-25	\N	\N	f	\N	\N	1	\N	161	\N	1403	5	\N	1
1481	1974-06-26	\N	\N	f	\N	\N	1	\N	161	\N	1404	5	\N	1
1505	1974-07-02	\N	\N	f	\N	\N	1	\N	161	\N	1408	5	\N	1
1485	1974-07-03	\N	\N	f	\N	\N	1	\N	161	\N	1409	5	\N	1
1486	1974-07-04	\N	\N	f	\N	\N	1	\N	161	\N	1410	5	\N	1
1487	1974-07-08	\N	\N	f	\N	\N	1	\N	161	\N	1411	5	\N	1
1488	1974-07-09	\N	\N	f	\N	\N	1	\N	162	\N	1412	5	\N	1
1489	1974-07-10	\N	\N	f	\N	\N	1	\N	162	\N	1413	5	\N	1
1490	1974-07-12	\N	\N	f	\N	\N	1	\N	162	\N	1415	5	\N	1
1492	1974-11-18	\N	\N	f	\N	\N	1	\N	158	\N	1417	5	\N	1
1494	1975-01-03	\N	\N	f	\N	\N	1	\N	166	\N	1419	5	\N	1
1495	1975-01-06	\N	\N	f	\N	\N	1	\N	166	\N	1420	5	\N	1
1496	1975-01-07	\N	\N	f	\N	\N	1	\N	166	\N	1421	5	\N	1
1500	1975-01-14	\N	\N	f	\N	\N	1	\N	166	\N	1425	5	\N	1
1510	1975-01-15	\N	\N	f	\N	\N	1	\N	166	\N	1426	5	\N	1
1502	1975-01-17	\N	\N	f	\N	\N	1	\N	166	\N	1428	5	\N	1
1503	1975-01-20	\N	\N	f	\N	\N	1	\N	166	\N	1429	5	\N	1
1504	1975-01-21	\N	\N	f	\N	\N	1	\N	166	\N	1430	5	\N	1
1513	1975-01-28	\N	\N	f	\N	\N	1	\N	167	\N	1435	5	\N	1
1514	1975-01-29	\N	\N	f	\N	\N	1	\N	167	\N	1436	5	\N	1
1515	1975-01-30	\N	\N	f	\N	\N	1	\N	167	\N	1437	5	\N	1
1517	1975-07-10	\N	\N	f	\N	\N	1	\N	168	\N	1439	5	\N	1
1518	1975-07-11	\N	\N	f	\N	\N	1	\N	168	\N	1440	5	\N	1
1519	1975-07-14	\N	\N	f	\N	\N	1	\N	168	\N	1441	5	\N	1
1520	1975-07-15	\N	\N	f	\N	\N	1	\N	168	\N	1442	5	\N	1
1427	1981-05-12	\N	\N	f	\N	\N	1	\N	190	\N	1348	5	\N	1
1390	1967-01-20	\N	\N	f	\N	\N	1	\N	123	\N	1282	5	\N	1
1599	1979-07-16	\N	\N	f	\N	\N	1	\N	185	\N	1522	5	\N	1
1596	1979-07-11	\N	\N	f	\N	\N	2	\N	186	1	1519	5	\N	1
1541	1975-01-13	\N	\N	f	\N	\N	1	\N	165	\N	1464	5	\N	1
1625	1979-07-11	\N	\N	f	\N	\N	1	\N	185	2	1518	5	\N	1
1550	1975-01-23	\N	\N	f	\N	\N	1	\N	166	\N	1432	5	\N	1
1523	1975-09-30	\N	\N	f	\N	\N	1	\N	169	\N	1445	5	\N	1
1524	1976-01-14	\N	\N	f	\N	\N	1	\N	170	\N	1446	5	\N	1
1526	1976-01-16	\N	\N	f	\N	\N	1	\N	170	\N	1448	5	\N	1
1527	1976-01-19	\N	\N	f	\N	\N	1	\N	170	\N	1449	5	\N	1
1528	1976-01-20	\N	\N	f	\N	\N	1	\N	170	\N	1450	5	\N	1
1529	1976-01-21	\N	\N	f	\N	\N	1	\N	170	\N	1451	5	\N	1
1531	1976-01-23	\N	\N	f	\N	\N	1	\N	170	\N	1453	5	\N	1
1532	1976-01-27	\N	\N	f	\N	\N	1	\N	171	\N	1455	5	\N	1
1533	1976-01-29	\N	\N	f	\N	\N	1	\N	171	\N	1456	5	\N	1
1535	1976-02-03	\N	\N	f	\N	\N	1	\N	171	\N	1458	5	\N	1
1537	1976-03-08	\N	\N	f	\N	\N	1	\N	172	\N	1460	5	\N	1
1538	1976-06-22	\N	\N	f	\N	\N	1	\N	173	\N	1461	5	\N	1
1540	1976-06-24	\N	\N	f	\N	\N	1	\N	173	\N	1463	5	\N	1
1578	1976-06-29	\N	\N	f	\N	\N	1	\N	173	\N	1502	5	\N	1
1579	1976-06-30	\N	\N	f	\N	\N	1	\N	173	\N	1503	5	\N	1
1580	1976-07-01	\N	\N	f	\N	\N	1	\N	173	\N	1504	5	\N	1
1542	1976-07-02	\N	\N	f	\N	\N	1	\N	174	\N	1465	5	\N	1
1543	1976-07-12	\N	\N	f	\N	\N	1	\N	174	\N	1466	5	\N	1
1546	1976-09-23	\N	\N	f	\N	\N	1	\N	175	\N	1469	5	\N	1
1548	1976-10-18	\N	\N	f	\N	\N	1	\N	174	\N	1470	5	\N	1
1547	1977-01-10	\N	\N	f	\N	\N	1	\N	176	\N	1471	5	\N	1
1551	1977-01-28	\N	\N	f	\N	\N	1	\N	177	\N	1472	5	\N	1
1552	1977-02-01	\N	\N	f	\N	\N	1	\N	177	\N	1473	5	\N	1
1553	1977-02-07	\N	\N	f	\N	\N	1	\N	177	\N	1474	5	\N	1
1554	1977-02-08	\N	\N	f	\N	\N	1	\N	177	\N	1475	5	\N	1
1556	1977-07-15	\N	\N	f	\N	\N	1	\N	178	\N	1477	5	\N	1
1558	1977-07-19	\N	\N	f	\N	\N	1	\N	178	\N	1479	5	\N	1
1559	1977-07-20	\N	\N	f	\N	\N	1	\N	178	\N	1480	5	\N	1
1560	1977-07-22	\N	\N	f	\N	\N	1	\N	178	\N	1481	5	\N	1
1562	1977-09-30	\N	\N	f	\N	\N	1	\N	\N	\N	1483	5	\N	1
1561	1978-02-08	\N	\N	f	\N	\N	1	\N	179	\N	1482	5	\N	1
1589	1978-02-27	\N	\N	f	\N	\N	1	\N	179	\N	1485	5	\N	1
1565	1978-04-14	\N	\N	f	\N	\N	1	\N	180	\N	1487	5	\N	1
1566	1978-04-17	\N	\N	f	\N	\N	1	\N	180	\N	1488	5	\N	1
1567	1978-04-19	\N	\N	f	\N	\N	1	\N	180	\N	1489	5	\N	1
1569	1978-04-24	\N	\N	f	\N	\N	1	\N	180	\N	1491	5	\N	1
1570	1978-04-26	\N	\N	f	\N	\N	1	\N	180	\N	1492	5	\N	1
1571	1978-05-02	\N	\N	f	\N	\N	1	\N	180	\N	1494	5	\N	1
1573	1978-05-04	\N	\N	f	\N	\N	1	\N	180	\N	1496	5	\N	1
1574	1978-05-05	\N	\N	f	\N	\N	1	\N	180	\N	1497	5	\N	1
1575	1978-05-09	\N	\N	f	\N	\N	1	\N	180	\N	1498	5	\N	1
1576	1978-05-10	\N	\N	f	\N	\N	1	\N	180	\N	1499	5	\N	1
1588	1978-07-10	\N	\N	f	\N	\N	1	\N	181	\N	1501	5	\N	1
1615	1978-07-18	\N	\N	f	\N	\N	1	\N	181	\N	1542	5	\N	1
1590	1979-01-31	\N	\N	f	\N	\N	1	\N	181	\N	1505	5	\N	1
1581	1979-02-02	\N	\N	f	\N	\N	1	\N	182	\N	1506	5	\N	1
1582	1979-02-05	\N	\N	f	\N	\N	1	\N	182	\N	1507	5	\N	1
1583	1979-02-07	\N	\N	f	\N	\N	1	\N	182	\N	1508	5	\N	1
1584	1979-02-19	\N	\N	f	\N	\N	1	\N	182	\N	1509	5	\N	1
1585	1979-02-20	\N	\N	f	\N	\N	1	\N	182	\N	1510	5	\N	1
1586	1979-05-21	\N	\N	f	\N	\N	1	\N	183	\N	1511	5	\N	1
1593	1979-07-09	\N	\N	f	\N	\N	1	\N	185	\N	1515	5	\N	1
1600	1979-07-17	\N	\N	f	\N	\N	1	\N	185	\N	1523	5	\N	1
1601	1979-07-19	\N	\N	f	\N	\N	1	\N	186	\N	1524	5	\N	1
1602	1979-07-24	\N	\N	f	\N	\N	1	\N	185	\N	1525	5	\N	1
1603	1979-07-25	\N	\N	f	\N	\N	1	\N	186	\N	1526	5	\N	1
1604	1979-08-07	\N	\N	f	\N	\N	1	\N	186	\N	1529	5	\N	1
1605	1979-09-07	\N	\N	f	\N	\N	1	\N	186	\N	1530	5	\N	1
1606	1979-09-27	\N	\N	f	\N	\N	1	\N	186	\N	1531	5	\N	1
1608	1980-01-28	\N	\N	f	\N	\N	1	\N	184	\N	1534	5	\N	1
1629	1980-02-04	\N	\N	f	\N	\N	1	\N	187	\N	1535	5	\N	1
1609	1980-02-06	\N	\N	f	\N	\N	1	\N	187	\N	1536	5	\N	1
1611	1980-02-11	\N	\N	f	\N	\N	1	\N	187	\N	1538	5	\N	1
1612	1980-02-14	\N	\N	f	\N	\N	1	\N	187	\N	1539	5	\N	1
1614	1980-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	1541	5	\N	1
1653	1980-07-11	\N	\N	f	\N	\N	1	\N	188	\N	1580	5	\N	1
1654	1980-07-17	\N	\N	f	\N	\N	1	\N	188	\N	1581	5	\N	1
1617	1980-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	1544	5	\N	1
1655	1981-02-02	\N	\N	f	\N	\N	1	\N	189	\N	1582	5	\N	1
1620	1981-05-14	\N	\N	f	\N	\N	1	\N	190	\N	1547	5	\N	1
1626	1981-05-19	\N	\N	f	\N	\N	1	\N	190	\N	1549	5	\N	1
1622	1981-05-21	\N	\N	f	\N	\N	1	\N	190	\N	1550	5	\N	1
1624	1981-05-22	\N	\N	f	\N	\N	1	\N	190	\N	1551	5	\N	1
1623	1981-05-26	\N	\N	f	\N	\N	1	\N	190	\N	1552	5	\N	1
1630	1981-05-27	\N	\N	f	\N	\N	1	\N	190	\N	1553	5	\N	1
1632	1981-06-01	\N	\N	f	\N	\N	1	\N	190	\N	1556	5	\N	1
1633	1981-06-16	\N	\N	f	\N	\N	1	\N	190	\N	1557	5	\N	1
1636	1981-07-21	\N	\N	f	\N	\N	1	\N	191	\N	1560	5	\N	1
1637	1981-09-22	\N	\N	f	\N	\N	1	\N	191	\N	1561	5	\N	1
1640	1981-09-24	\N	\N	f	\N	\N	1	\N	\N	\N	1564	5	\N	1
1638	1982-02-02	\N	\N	f	\N	\N	1	\N	192	\N	1562	5	\N	1
1639	1982-02-08	\N	\N	f	\N	\N	1	\N	192	\N	1563	5	\N	1
1641	1982-02-10	\N	\N	f	\N	\N	1	\N	192	\N	1565	5	\N	1
1642	1982-03-12	\N	\N	f	\N	\N	1	\N	193	\N	1566	5	\N	1
1645	1982-07-20	\N	\N	f	\N	\N	1	\N	194	\N	1570	5	\N	1
1646	1982-09-30	\N	\N	f	\N	\N	1	\N	195	\N	1571	5	\N	1
1648	1983-01-17	\N	\N	f	\N	\N	1	\N	197	\N	1573	5	\N	1
1649	1983-01-27	\N	\N	f	\N	\N	1	\N	197	\N	1576	5	\N	1
1650	1983-01-31	\N	\N	f	\N	\N	1	\N	197	\N	1577	5	\N	1
1651	1983-02-02	\N	\N	f	\N	\N	1	\N	198	\N	1578	5	\N	1
1656	1983-03-28	\N	\N	f	\N	\N	1	\N	197	\N	1583	5	\N	1
1597	1979-07-12	\N	\N	f	\N	\N	1	\N	186	2	1520	5	\N	1
1598	1979-07-12	\N	\N	f	\N	\N	2	\N	185	1	1521	5	\N	1
1695	1983-02-10	\N	\N	f	\N	\N	1	\N	197	\N	1620	5	\N	1
1696	1983-03-14	\N	\N	f	\N	\N	1	\N	198	\N	1621	5	\N	1
1658	1983-06-16	\N	\N	f	\N	\N	1	\N	\N	\N	1585	5	\N	1
1659	1983-07-01	\N	\N	f	\N	\N	1	\N	199	\N	1586	5	\N	1
1661	1983-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	1588	5	\N	1
1662	1983-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	1589	5	\N	1
1660	1983-07-15	\N	\N	f	\N	\N	1	\N	199	\N	1587	5	\N	1
1664	1983-09-07	\N	\N	f	\N	\N	1	\N	200	\N	1591	5	\N	1
1666	1983-09-12	\N	\N	f	\N	\N	1	\N	200	\N	1593	5	\N	1
1670	1983-09-14	\N	\N	f	\N	\N	1	\N	200	\N	1594	5	\N	1
1671	1983-09-16	\N	\N	f	\N	\N	1	\N	200	\N	1595	5	\N	1
1673	1983-09-21	\N	\N	f	\N	\N	1	\N	200	\N	1597	5	\N	1
1674	1983-09-23	\N	\N	f	\N	\N	1	\N	200	\N	1598	5	\N	1
1676	1983-09-28	\N	\N	f	\N	\N	1	\N	200	\N	1600	5	\N	1
1677	1983-09-30	\N	\N	f	\N	\N	1	\N	200	\N	1601	5	\N	1
1678	1983-10-03	\N	\N	f	\N	\N	1	\N	200	\N	1602	5	\N	1
1679	1983-10-05	\N	\N	f	\N	\N	1	\N	200	\N	1603	5	\N	1
1681	1983-10-10	\N	\N	f	\N	\N	1	\N	200	\N	1605	5	\N	1
1682	1983-10-12	\N	\N	f	\N	\N	1	\N	200	\N	1606	5	\N	1
1685	1984-01-31	\N	\N	f	\N	\N	1	\N	201	\N	1609	5	\N	1
1687	1984-06-08	\N	\N	f	\N	\N	1	\N	\N	\N	1611	5	\N	1
1688	1984-10-10	\N	\N	f	\N	\N	1	\N	\N	\N	1612	5	\N	1
1686	1985-02-04	\N	\N	f	\N	\N	1	\N	202	\N	1610	5	\N	1
1708	1985-02-06	\N	\N	f	\N	\N	1	\N	202	\N	1613	5	\N	1
1689	1985-02-07	\N	\N	f	\N	\N	1	\N	202	\N	1614	5	\N	1
1690	1985-02-14	\N	\N	f	\N	\N	1	\N	202	\N	1615	5	\N	1
1692	1985-05-13	\N	\N	f	\N	\N	1	\N	203	\N	1617	5	\N	1
1693	1985-05-15	\N	\N	f	\N	\N	1	\N	203	\N	1618	5	\N	1
1733	1985-05-21	\N	\N	f	\N	\N	1	\N	203	\N	1659	5	\N	1
1697	1985-05-23	\N	\N	f	\N	\N	1	\N	\N	\N	1623	5	\N	1
1698	1985-05-30	\N	\N	f	\N	\N	1	\N	203	\N	1624	5	\N	1
1699	1985-06-05	\N	\N	f	\N	\N	1	\N	203	\N	1625	5	\N	1
1706	1985-06-10	\N	\N	f	\N	\N	1	\N	203	\N	1626	5	\N	1
1700	1985-06-13	\N	\N	f	\N	\N	1	\N	203	\N	1627	5	\N	1
1702	1985-07-22	\N	\N	f	\N	\N	1	\N	204	\N	1629	5	\N	1
1705	1986-01-31	\N	\N	f	\N	\N	1	\N	\N	\N	1632	5	\N	1
1709	1986-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	1633	5	\N	1
1703	1986-02-14	\N	\N	f	\N	\N	1	\N	205	\N	1630	5	\N	1
1710	1986-07-21	\N	\N	f	\N	\N	1	\N	206	\N	1634	5	\N	1
1711	1986-07-22	\N	\N	f	\N	\N	1	\N	206	\N	1635	5	\N	1
1745	1986-07-23	\N	\N	f	\N	\N	1	\N	\N	\N	1672	5	\N	1
1714	1987-02-09	\N	\N	f	\N	\N	1	\N	207	\N	1638	5	\N	1
1715	1987-03-23	\N	\N	f	\N	\N	1	\N	208	\N	1640	5	\N	1
1717	1987-03-25	\N	\N	f	\N	\N	1	\N	208	\N	1642	5	\N	1
1718	1987-03-27	\N	\N	f	\N	\N	1	\N	208	\N	1643	5	\N	1
1719	1987-03-31	\N	\N	f	\N	\N	1	\N	208	\N	1644	5	\N	1
1720	1987-04-03	\N	\N	f	\N	\N	1	\N	208	\N	1645	5	\N	1
1721	1987-04-06	\N	\N	f	\N	\N	1	\N	208	\N	1646	5	\N	1
1746	1987-04-07	\N	\N	f	\N	\N	1	\N	208	\N	1647	5	\N	1
1724	1987-07-22	\N	\N	f	\N	\N	1	\N	209	\N	1650	5	\N	1
1725	1987-10-06	\N	\N	f	\N	\N	1	\N	211	\N	1651	5	\N	1
1726	1987-10-07	\N	\N	f	\N	\N	1	\N	211	\N	1652	5	\N	1
1727	1987-10-08	\N	\N	f	\N	\N	1	\N	211	\N	1653	5	\N	1
1729	1987-10-12	\N	\N	f	\N	\N	1	\N	211	\N	1655	5	\N	1
1730	1987-10-13	\N	\N	f	\N	\N	1	\N	211	\N	1656	5	\N	1
1731	1987-10-14	\N	\N	f	\N	\N	1	\N	211	\N	1657	5	\N	1
1735	1987-11-03	\N	\N	f	\N	\N	1	\N	211	\N	1661	5	\N	1
1737	1987-11-05	\N	\N	f	\N	\N	1	\N	211	\N	1663	5	\N	1
1738	1987-11-16	\N	\N	f	\N	\N	1	\N	211	\N	1664	5	\N	1
1739	1987-11-20	\N	\N	f	\N	\N	1	\N	211	\N	1665	5	\N	1
1740	1988-02-05	\N	\N	f	\N	\N	1	\N	212	\N	1666	5	\N	1
1747	1988-02-08	\N	\N	f	\N	\N	1	\N	210	\N	1667	5	\N	1
1742	1988-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	1669	5	\N	1
1744	1988-07-11	\N	\N	f	\N	\N	1	\N	213	\N	1671	5	\N	1
1748	1988-08-08	\N	\N	f	\N	\N	1	\N	213	\N	1673	5	\N	1
1749	1988-08-10	\N	\N	f	\N	\N	1	\N	213	\N	1674	5	\N	1
1751	1989-01-09	\N	\N	f	\N	\N	1	\N	214	\N	1676	5	\N	1
1752	1989-01-31	\N	\N	f	\N	\N	1	\N	215	\N	1677	5	\N	1
1753	1989-02-08	\N	\N	f	\N	\N	1	\N	215	\N	1678	5	\N	1
1755	1989-02-10	\N	\N	f	\N	\N	1	\N	\N	\N	1681	5	\N	1
1756	1989-07-24	\N	\N	f	\N	\N	1	\N	216	\N	1682	5	\N	1
1757	1989-07-25	\N	\N	f	\N	\N	1	\N	216	\N	1683	5	\N	1
1758	1990-02-26	\N	\N	f	\N	\N	1	\N	217	\N	1684	5	\N	1
1759	1990-02-28	\N	\N	f	\N	\N	1	\N	217	\N	1685	5	\N	1
1760	1990-05-09	\N	\N	f	\N	\N	1	\N	218	\N	1686	5	\N	1
1761	1990-05-14	\N	\N	f	\N	\N	1	\N	218	\N	1688	5	\N	1
1763	1990-05-17	\N	\N	f	\N	\N	1	\N	218	\N	1690	5	\N	1
1764	1990-05-22	\N	\N	f	\N	\N	1	\N	218	\N	1693	5	\N	1
1765	1990-05-29	\N	\N	f	\N	\N	1	\N	218	\N	1694	5	\N	1
1766	1990-05-30	\N	\N	f	\N	\N	1	\N	218	\N	1695	5	\N	1
1784	1990-06-01	\N	\N	f	\N	\N	1	\N	218	\N	1696	5	\N	1
1782	1990-06-11	\N	\N	f	\N	\N	1	\N	218	\N	1697	5	\N	1
1769	1990-08-13	\N	\N	f	\N	\N	1	\N	219	\N	1700	5	\N	1
1771	1990-12-04	\N	\N	f	\N	\N	1	\N	\N	\N	1702	5	\N	1
1773	1991-02-01	\N	\N	f	\N	\N	1	\N	219	\N	1704	5	\N	1
1774	1991-02-04	\N	\N	f	\N	\N	1	\N	220	\N	1705	5	\N	1
1775	1991-02-05	\N	\N	f	\N	\N	1	\N	220	\N	1706	5	\N	1
1776	1991-02-08	\N	\N	f	\N	\N	1	\N	220	\N	1707	5	\N	1
1786	1991-02-14	\N	\N	f	\N	\N	1	\N	220	\N	1708	5	\N	1
1777	1991-03-26	\N	\N	f	\N	\N	1	\N	220	\N	1709	5	\N	1
1783	1991-06-06	\N	\N	f	\N	\N	1	\N	222	\N	1711	5	\N	1
1779	1991-06-07	\N	\N	f	\N	\N	1	\N	222	\N	1712	5	\N	1
1788	1991-06-20	\N	\N	f	\N	\N	1	\N	222	\N	1717	5	\N	1
1789	1991-06-24	\N	\N	f	\N	\N	1	\N	222	\N	1719	5	\N	1
1790	1991-06-26	\N	\N	f	\N	\N	1	\N	222	\N	1720	5	\N	1
1791	1991-07-15	\N	\N	f	\N	\N	1	\N	223	\N	1721	5	\N	1
1793	1991-07-29	\N	\N	f	\N	\N	1	\N	223	\N	1724	5	\N	1
1668	1983-01-20	\N	\N	f	\N	\N	1	\N	197	\N	1574	5	\N	1
1667	1983-01-24	\N	\N	f	\N	\N	1	\N	197	\N	1575	5	\N	1
1812	1992-07-08	\N	\N	f	\N	\N	2	\N	230	1	1746	5	\N	1
3037	1834-06-13	\N	\N	f	\N	\N	\N	Abstract, p. 47	\N	\N	185	3	\N	\N
1813	1992-07-09	\N	\N	f	\N	\N	1	\N	230	\N	1747	5	\N	1
1802	1992-04-27	\N	\N	f	\N	\N	1	\N	227	2	1734	5	\N	1
1806	1992-07-01	\N	\N	f	\N	\N	1	\N	230	2	1740	5	\N	1
1890	1996-10-02	\N	\N	f	\N	\N	1	\N	253	\N	1824	5	\N	1
1909	1997-05-14	\N	\N	f	\N	\N	2	\N	257	1	1839	5	\N	1
1805	1990-07-17	\N	\N	f	\N	\N	1	\N	219	\N	1739	5	\N	1
1796	1992-01-10	\N	\N	f	\N	\N	1	\N	225	\N	1727	5	\N	1
1797	1992-01-27	\N	\N	f	\N	\N	1	\N	226	\N	1728	5	\N	1
1800	1992-03-11	\N	\N	f	\N	\N	1	\N	225	\N	1731	5	\N	1
1819	1992-04-24	\N	\N	f	\N	\N	2	\N	228	1	1733	5	\N	1
1910	1997-05-16	\N	\N	f	\N	\N	1	\N	258	2	1840	5	\N	1
1911	1997-05-16	\N	\N	f	\N	\N	2	\N	257	1	1841	5	\N	1
1825	1992-06-26	\N	\N	f	\N	\N	1	\N	230	\N	1736	5	\N	1
1913	1997-05-21	\N	\N	f	\N	\N	1	\N	\N	\N	1843	5	\N	1
1820	1991-06-11	\N	\N	f	\N	\N	1	\N	222	\N	1714	5	\N	1
1916	1997-06-06	\N	\N	f	\N	\N	1	\N	256	2	1847	5	\N	1
1809	1992-07-06	\N	\N	f	\N	\N	1	\N	230	\N	1743	5	\N	1
1810	1992-07-07	\N	\N	f	\N	\N	1	\N	230	\N	1744	5	\N	1
1811	1992-07-08	\N	\N	f	\N	\N	1	\N	230	2	1745	5	\N	1
1815	1992-07-14	\N	\N	f	\N	\N	1	\N	232	\N	1749	5	\N	1
1919	1997-06-09	\N	\N	f	\N	\N	2	\N	256	1	1850	5	\N	1
1816	1992-07-15	\N	\N	f	\N	\N	1	\N	230	\N	1750	5	\N	1
1817	1992-07-17	\N	\N	f	\N	\N	1	\N	230	\N	1751	5	\N	1
1827	1992-07-21	\N	\N	f	\N	\N	1	\N	232	\N	1754	5	\N	1
1828	1992-07-24	\N	\N	f	\N	\N	1	\N	232	\N	1755	5	\N	1
1920	1997-06-10	\N	\N	f	\N	\N	1	\N	256	2	1851	5	\N	1
1821	1991-06-14	\N	\N	f	\N	\N	1	\N	222	\N	1715	5	\N	1
1822	1991-06-19	\N	\N	f	\N	\N	1	\N	222	\N	1716	5	\N	1
1823	1991-06-21	\N	\N	f	\N	\N	1	\N	222	\N	1718	5	\N	1
1824	1991-07-16	\N	\N	f	\N	\N	1	\N	223	\N	1722	5	\N	1
1803	1992-04-29	\N	\N	f	\N	\N	1	\N	229	\N	1735	5	\N	1
1845	1992-06-29	\N	\N	f	\N	\N	1	\N	230	2	1775	5	\N	1
1830	1992-07-28	\N	\N	f	\N	\N	1	\N	230	\N	1757	5	\N	1
1831	1992-07-30	\N	\N	f	\N	\N	1	\N	232	\N	1759	5	\N	1
1832	1992-08-10	\N	\N	f	\N	\N	1	\N	231	\N	1760	5	\N	1
1833	1992-08-11	\N	\N	f	\N	\N	1	\N	232	\N	1761	5	\N	1
1835	1992-08-21	\N	\N	f	\N	\N	1	\N	232	\N	1763	5	\N	1
1836	1992-09-18	\N	\N	f	\N	\N	1	\N	230	\N	1764	5	\N	1
1864	1993-02-01	\N	\N	f	\N	\N	1	\N	234	\N	1765	5	\N	1
1837	1993-07-14	\N	\N	f	\N	\N	1	\N	235	\N	1766	5	\N	1
1838	1993-07-15	\N	\N	f	\N	\N	1	\N	235	\N	1767	5	\N	1
1840	1993-07-30	\N	\N	f	\N	\N	1	\N	235	\N	1769	5	\N	1
1842	1993-10-04	\N	\N	f	\N	\N	1	\N	237	\N	1771	5	\N	1
1843	1993-10-05	\N	\N	f	\N	\N	1	\N	237	\N	1772	5	\N	1
1860	1993-10-06	\N	\N	f	\N	\N	1	\N	237	\N	1773	5	\N	1
1883	1993-10-13	\N	\N	f	\N	\N	1	\N	237	\N	1815	5	\N	1
1901	1993-10-14	\N	\N	f	\N	\N	1	\N	237	\N	1816	5	\N	1
1921	1997-06-10	\N	\N	f	\N	\N	2	\N	256	1	1852	5	\N	1
1922	1997-06-11	\N	\N	f	\N	\N	2	\N	256	1	1853	5	\N	1
1927	1997-07-21	\N	\N	f	\N	\N	2	\N	256	1	1858	5	\N	1
1850	1994-03-22	\N	\N	f	\N	\N	1	\N	238	\N	1780	5	\N	1
1851	1994-07-12	\N	\N	f	\N	\N	1	\N	239	\N	1781	5	\N	1
1853	1994-09-06	\N	\N	f	\N	\N	1	\N	239	\N	1783	5	\N	1
1854	1994-09-26	\N	\N	f	\N	\N	1	\N	241	\N	1784	5	\N	1
1855	1994-09-27	\N	\N	f	\N	\N	1	\N	241	\N	1785	5	\N	1
1856	1994-09-30	\N	\N	f	\N	\N	1	\N	241	\N	1787	5	\N	1
1862	1994-10-05	\N	\N	f	\N	\N	1	\N	241	\N	1789	5	\N	1
1863	1994-10-06	\N	\N	f	\N	\N	1	\N	241	\N	1790	5	\N	1
1858	1994-10-07	\N	\N	f	\N	\N	1	\N	241	\N	1791	5	\N	1
1865	1995-01-11	\N	\N	f	\N	\N	1	\N	242	\N	1793	5	\N	1
1848	1994-01-11	\N	\N	f	\N	\N	1	\N	236	\N	1778	5	\N	1
1899	1995-02-03	\N	\N	f	\N	\N	1	\N	243	\N	1794	5	\N	1
1866	1995-02-10	\N	\N	f	\N	\N	1	\N	243	\N	1795	5	\N	1
1903	1995-02-17	\N	\N	f	\N	\N	1	\N	243	\N	1796	5	\N	1
1868	1995-07-24	\N	\N	f	\N	\N	1	\N	245	\N	1798	5	\N	1
1869	1995-07-25	\N	\N	f	\N	\N	1	\N	245	\N	1799	5	\N	1
1870	1995-08-25	\N	\N	f	\N	\N	1	\N	245	\N	1800	5	\N	1
1871	1995-09-08	\N	\N	f	\N	\N	1	\N	245	\N	1801	5	\N	1
1873	1995-12-18	\N	\N	f	\N	\N	1	\N	247	\N	1803	5	\N	1
1875	1995-12-20	\N	\N	f	\N	\N	1	\N	247	\N	1805	5	\N	1
1898	1996-01-02	\N	\N	f	\N	\N	1	\N	247	\N	1807	5	\N	1
1877	1996-01-10	\N	\N	f	\N	\N	1	\N	247	\N	1808	5	\N	1
1878	1996-01-11	\N	\N	f	\N	\N	1	\N	247	\N	1809	5	\N	1
1880	1996-01-15	\N	\N	f	\N	\N	1	\N	247	\N	1811	5	\N	1
1905	1996-01-16	\N	\N	f	\N	\N	1	\N	247	\N	1812	5	\N	1
1881	1996-01-17	\N	\N	f	\N	\N	1	\N	247	\N	1813	5	\N	1
1882	1996-02-05	\N	\N	f	\N	\N	1	\N	249	\N	1814	5	\N	1
1924	1996-04-03	\N	\N	f	\N	\N	1	\N	248	\N	1855	5	\N	1
1925	1996-06-04	\N	\N	f	\N	\N	1	\N	250	\N	1856	5	\N	1
1900	1996-08-19	\N	\N	f	\N	\N	1	\N	251	\N	1818	5	\N	1
1885	1996-09-03	\N	\N	f	\N	\N	1	\N	251	\N	1819	5	\N	1
1886	1996-09-11	\N	\N	f	\N	\N	1	\N	251	\N	1820	5	\N	1
1887	1996-09-30	\N	\N	f	\N	\N	1	\N	253	\N	1821	5	\N	1
1888	1996-10-01	\N	\N	f	\N	\N	1	\N	252	2	1822	5	\N	1
1804	1990-07-16	\N	\N	f	\N	\N	1	\N	219	2	1737	5	\N	1
1892	1996-10-08	\N	\N	f	\N	\N	1	\N	253	\N	1827	5	\N	1
1902	1996-10-11	\N	\N	f	\N	\N	1	\N	253	\N	1829	5	\N	1
1897	1996-10-15	\N	\N	f	\N	\N	1	\N	253	\N	1831	5	\N	1
1895	1996-10-18	\N	\N	f	\N	\N	1	\N	253	\N	1833	5	\N	1
1896	1996-10-21	\N	\N	f	\N	\N	1	\N	253	\N	1834	5	\N	1
1907	1997-02-18	\N	\N	f	\N	\N	1	\N	255	\N	1837	5	\N	1
1894	1996-10-16	\N	\N	f	\N	\N	1	\N	253	\N	1832	5	\N	1
1912	1997-06-03	\N	\N	f	\N	\N	1	\N	256	\N	1842	5	\N	1
1915	1997-06-05	\N	\N	f	\N	\N	2	\N	256	1	1846	5	\N	1
1929	1997-07-28	\N	\N	f	\N	\N	1	\N	286	\N	1860	5	\N	1
1807	1992-07-02	\N	\N	f	\N	\N	1	\N	230	\N	1741	5	\N	1
1938	1997-09-29	\N	\N	f	\N	\N	2	\N	260	1	1871	5	\N	1
3038	1831-09-14	\N	\N	f	Northland	Viscount	\N	Abstract, p. 19	\N	\N	2633	3	\N	\N
1944	1997-09-30	\N	\N	f	\N	\N	1	\N	261	2	1872	5	\N	1
1945	1997-10-01	\N	\N	f	\N	\N	2	\N	261	1	1875	5	\N	1
1932	1997-09-25	\N	\N	f	\N	\N	1	\N	261	2	1865	5	\N	1
1941	1997-09-30	\N	\N	f	\N	\N	2	\N	260	1	1873	5	\N	1
1946	1997-10-02	\N	\N	f	\N	\N	1	\N	261	2	1876	5	\N	1
1947	1997-10-03	\N	\N	f	\N	\N	1	\N	261	2	1877	5	\N	1
1948	1997-10-03	\N	\N	f	\N	\N	2	\N	261	1	1878	5	\N	1
1952	1997-10-18	\N	\N	f	\N	\N	1	\N	261	\N	1883	5	\N	1
1954	1997-10-20	\N	\N	f	\N	\N	2	\N	260	1	1885	5	\N	1
1955	1997-10-21	\N	\N	f	\N	\N	1	\N	261	2	1886	5	\N	1
1956	1997-10-21	\N	\N	f	\N	\N	2	\N	261	1	1887	5	\N	1
1957	1997-10-22	\N	\N	f	\N	\N	1	\N	261	2	1888	5	\N	1
1958	1997-10-23	\N	\N	f	\N	\N	1	\N	261	2	1889	5	\N	1
1962	1997-06-13	\N	\N	f	\N	\N	1	\N	256	2	1894	5	\N	1
1982	1997-10-24	\N	\N	f	\N	\N	1	\N	261	2	1891	5	\N	1
1961	1997-10-25	\N	\N	f	\N	\N	2	\N	261	1	1893	5	\N	1
1963	1997-06-16	\N	\N	f	\N	\N	1	\N	256	\N	1895	5	\N	1
1964	1997-06-17	\N	\N	f	\N	\N	1	\N	256	\N	1896	5	\N	1
1983	1997-10-30	\N	\N	f	\N	\N	2	\N	261	1	1899	5	\N	1
1968	1997-11-01	\N	\N	f	\N	\N	1	\N	261	2	1901	5	\N	1
1969	1997-11-03	\N	\N	f	\N	\N	1	\N	261	2	1903	5	\N	1
1971	1997-11-05	\N	\N	f	\N	\N	1	\N	261	2	1906	5	\N	1
1972	1997-11-05	\N	\N	f	\N	\N	2	\N	261	1	1907	5	\N	1
1953	1997-10-20	\N	\N	f	\N	\N	1	\N	261	2	1884	5	\N	1
1974	1997-11-06	\N	\N	f	\N	\N	1	\N	261	2	1909	5	\N	1
2043	1999-07-30	\N	\N	f	\N	\N	1	\N	270	2	1977	5	\N	1
1976	1997-11-22	\N	\N	f	\N	\N	1	\N	256	\N	1911	5	\N	1
1960	1997-10-24	\N	\N	f	\N	\N	2	\N	261	1	1892	5	\N	1
1967	1997-10-31	\N	\N	f	\N	\N	1	\N	260	2	1900	5	\N	1
1986	1998-07-17	\N	\N	f	\N	\N	2	\N	265	1	1917	5	\N	1
1987	1998-07-18	\N	\N	f	\N	\N	1	\N	265	2	1918	5	\N	1
2024	1998-07-18	\N	\N	f	\N	\N	2	\N	265	1	1919	5	\N	1
1989	1998-07-20	\N	\N	f	\N	\N	2	\N	264	1	1921	5	\N	1
1942	1997-09-23	\N	\N	f	\N	\N	2	\N	260	1	1862	5	\N	1
1933	1997-09-26	\N	\N	f	\N	\N	1	\N	261	2	1866	5	\N	1
2015	1998-07-23	\N	\N	f	\N	\N	1	\N	265	2	1924	5	\N	1
2016	1998-07-24	\N	\N	f	\N	\N	2	\N	265	1	1927	5	\N	1
1994	1998-07-27	\N	\N	f	\N	\N	1	\N	264	2	1930	5	\N	1
1995	1998-07-27	\N	\N	f	\N	\N	2	\N	265	1	1931	5	\N	1
2019	1998-07-28	\N	\N	f	\N	\N	1	\N	265	2	1932	5	\N	1
1998	1997-10-28	\N	\N	f	\N	\N	2	\N	260	1	1936	5	\N	1
1965	1997-10-29	\N	\N	f	\N	\N	1	\N	261	2	1897	5	\N	1
2000	1998-07-31	\N	\N	f	\N	\N	2	\N	265	1	1938	5	\N	1
1977	1997-11-24	\N	\N	f	\N	\N	1	\N	256	\N	1912	5	\N	1
1978	1997-11-28	\N	\N	f	\N	\N	1	\N	262	\N	1913	5	\N	1
1979	1998-02-12	\N	\N	f	\N	\N	1	\N	263	\N	1914	5	\N	1
1985	1998-07-17	\N	\N	f	\N	\N	1	\N	265	2	1916	5	\N	1
1988	1998-07-20	\N	\N	f	\N	\N	1	\N	264	2	1920	5	\N	1
2003	1998-08-04	\N	\N	f	\N	\N	1	\N	265	2	1942	5	\N	1
2004	1998-08-04	\N	\N	f	\N	\N	2	\N	265	1	1943	5	\N	1
2010	1998-10-01	\N	\N	f	\N	\N	2	\N	\N	1	1949	5	\N	1
2007	1998-10-02	\N	\N	f	\N	\N	1	\N	266	\N	1946	5	\N	1
2022	1999-07-13	\N	\N	f	\N	\N	2	\N	268	1	1956	5	\N	1
2023	1998-07-23	\N	\N	f	\N	\N	2	\N	265	1	1925	5	\N	1
1993	1998-07-25	\N	\N	f	\N	\N	2	\N	265	1	1929	5	\N	1
1990	1998-07-21	\N	\N	f	\N	\N	2	\N	265	1	1923	5	\N	1
2002	1998-08-03	\N	\N	f	\N	\N	2	\N	265	1	1941	5	\N	1
2026	1999-07-14	\N	\N	f	\N	\N	1	\N	270	2	1957	5	\N	1
1991	1998-07-24	\N	\N	f	\N	\N	1	\N	265	2	1926	5	\N	1
2041	1998-07-30	\N	\N	f	\N	\N	1	\N	265	2	1975	5	\N	1
2027	1999-07-14	\N	\N	f	\N	\N	2	\N	270	1	1958	5	\N	1
2060	1999-07-15	\N	\N	f	\N	\N	1	\N	268	2	1959	5	\N	1
2030	1999-07-19	\N	\N	f	\N	\N	2	\N	270	1	1963	5	\N	1
2031	1999-07-20	\N	\N	f	\N	\N	1	\N	270	2	1964	5	\N	1
2033	1999-07-21	\N	\N	f	\N	\N	1	\N	270	2	1966	5	\N	1
2034	1999-07-22	\N	\N	f	\N	\N	1	\N	270	2	1967	5	\N	1
2036	1999-07-23	\N	\N	f	\N	\N	1	\N	270	2	1969	5	\N	1
2038	1999-07-26	\N	\N	f	\N	\N	1	\N	270	2	1971	5	\N	1
2008	1999-02-10	\N	\N	f	\N	\N	1	\N	267	\N	1947	5	\N	1
2005	1999-02-05	\N	\N	f	\N	\N	1	\N	267	\N	1944	5	\N	1
2006	1999-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	1945	5	\N	1
2011	1999-03-01	\N	\N	f	\N	\N	1	\N	267	\N	1951	5	\N	1
2058	1999-07-26	\N	\N	f	\N	\N	2	\N	270	1	1972	5	\N	1
2012	1999-03-02	\N	\N	f	\N	\N	1	\N	267	\N	1952	5	\N	1
2025	1999-07-10	\N	\N	f	\N	\N	1	\N	270	\N	1953	5	\N	1
2014	1999-07-13	\N	\N	f	\N	\N	1	\N	268	2	1955	5	\N	1
1973	1999-07-29	\N	\N	f	\N	\N	2	\N	270	1	1908	5	\N	1
1999	1998-07-31	\N	\N	f	\N	\N	1	\N	265	2	1937	5	\N	1
2056	1999-07-15	\N	\N	f	\N	\N	2	\N	270	1	1960	5	\N	1
2062	1999-07-30	\N	\N	f	\N	\N	2	\N	270	1	1978	5	\N	1
2055	1999-08-04	\N	\N	f	\N	\N	1	\N	270	2	1984	5	\N	1
2061	1999-08-05	\N	\N	f	\N	\N	2	\N	270	1	1987	5	\N	1
2048	1999-08-24	\N	\N	f	\N	\N	1	\N	271	\N	1990	5	\N	1
2059	1999-08-03	\N	\N	f	\N	\N	1	\N	270	2	1982	5	\N	1
2029	1999-07-16	\N	\N	f	\N	\N	2	\N	270	1	1962	5	\N	1
2063	2000-06-05	\N	\N	f	\N	\N	1	\N	274	\N	1995	5	\N	1
1935	1997-09-27	\N	\N	f	\N	\N	1	\N	261	2	1868	5	\N	1
2046	1999-08-05	\N	\N	f	\N	\N	1	\N	270	2	1986	5	\N	1
2039	1999-07-27	\N	\N	f	\N	\N	1	\N	270	2	1973	5	\N	1
2054	1999-07-31	\N	\N	f	\N	\N	1	\N	270	2	1979	5	\N	1
2044	1999-08-03	\N	\N	f	\N	\N	2	\N	270	1	1983	5	\N	1
2047	1999-08-06	\N	\N	f	\N	\N	1	\N	270	2	1988	5	\N	1
2050	2000-04-19	\N	\N	f	Chandos	3rd Viscount	1	\N	274	3	1992	5	\N	1
2064	2000-06-07	\N	\N	f	\N	\N	2	\N	274	1	1997	5	\N	1
1940	1997-02-17	\N	\N	f	\N	\N	1	\N	255	\N	1836	5	\N	1
1934	1997-09-26	\N	\N	f	\N	\N	2	\N	261	1	1867	5	\N	1
2074	1999-07-28	\N	\N	f	\N	\N	2	\N	270	1	2008	5	\N	1
2084	2000-04-17	\N	\N	f	Acton	4th Lord	1	\N	274	2	2019	5	\N	1
2135	2000-05-01	\N	\N	f	\N	\N	1	\N	274	2	2032	5	\N	1
2076	1999-11-17	\N	\N	f	Belstead	2nd Lord	2	\N	272	4	2010	5	\N	1
2079	2000-02-09	\N	\N	f	\N	\N	1	\N	273	\N	2013	5	\N	1
2066	2000-07-17	\N	\N	f	\N	\N	1	\N	275	\N	1999	5	\N	1
2086	2000-05-10	\N	\N	f	\N	\N	2	\N	274	1	2023	5	\N	1
2067	2000-10-02	\N	\N	f	\N	\N	1	\N	276	\N	2000	5	\N	1
2090	2001-01-15	\N	\N	f	\N	\N	1	\N	277	\N	2002	5	\N	1
2094	2000-05-11	\N	\N	f	\N	\N	1	\N	274	2	2024	5	\N	1
2089	2000-05-12	\N	\N	f	\N	\N	2	\N	274	1	2027	5	\N	1
2095	2000-05-15	\N	\N	f	\N	\N	1	\N	274	2	2028	5	\N	1
2085	2000-05-10	\N	\N	f	\N	\N	1	\N	274	2	2022	5	\N	1
2088	2000-05-12	\N	\N	f	\N	\N	1	\N	274	2	2026	5	\N	1
2096	2000-05-15	\N	\N	f	\N	\N	2	\N	274	1	2029	5	\N	1
2093	2000-06-07	\N	\N	f	\N	\N	1	\N	274	2	1996	5	\N	1
2131	2000-05-03	\N	\N	f	\N	\N	1	\N	274	2	2035	5	\N	1
2092	2000-02-10	\N	\N	f	\N	\N	1	\N	273	\N	2014	5	\N	1
2081	2000-02-14	\N	\N	f	\N	\N	1	\N	273	\N	2016	5	\N	1
2082	2000-02-15	\N	\N	f	\N	\N	1	\N	273	\N	2017	5	\N	1
2083	2000-02-16	\N	\N	f	\N	\N	1	\N	273	\N	2018	5	\N	1
2101	2000-05-04	\N	\N	f	\N	\N	1	\N	274	2	2037	5	\N	1
2099	2000-05-02	\N	\N	f	\N	\N	2	\N	274	1	2034	5	\N	1
2102	2000-05-04	\N	\N	f	\N	\N	2	\N	274	1	2038	5	\N	1
2103	2000-05-05	\N	\N	f	\N	\N	1	\N	274	2	2039	5	\N	1
2091	2000-05-09	\N	\N	f	\N	\N	1	\N	274	2	2020	5	\N	1
2108	2001-06-23	\N	\N	f	\N	\N	1	\N	278	\N	2044	5	\N	1
2104	2001-06-02	\N	\N	f	\N	\N	1	\N	278	\N	2040	5	\N	1
2113	2001-06-29	\N	\N	f	\N	\N	2	\N	278	1	2051	5	\N	1
2080	2000-02-11	\N	\N	f	\N	\N	1	\N	273	\N	2015	5	\N	1
2114	2001-06-30	\N	\N	f	\N	\N	1	\N	278	\N	2052	5	\N	1
2116	2001-07-02	\N	\N	f	\N	\N	2	\N	280	1	2054	5	\N	1
2117	2001-07-03	\N	\N	f	\N	\N	2	\N	280	1	2055	5	\N	1
2118	2001-07-04	\N	\N	f	\N	\N	1	\N	280	2	2056	5	\N	1
2119	2001-07-04	\N	\N	f	\N	\N	2	\N	280	1	2057	5	\N	1
2120	2001-07-05	\N	\N	f	\N	\N	1	\N	280	2	2058	5	\N	1
2121	2001-07-05	\N	\N	f	\N	\N	2	\N	280	1	2059	5	\N	1
2122	2001-07-06	\N	\N	f	\N	\N	1	\N	280	\N	2060	5	\N	1
2105	2001-06-04	\N	\N	f	\N	\N	1	\N	278	\N	2041	5	\N	1
2145	2001-06-19	\N	\N	f	\N	\N	1	\N	278	\N	2081	5	\N	1
2148	2004-06-03	\N	\N	f	\N	\N	1	\N	295	2	2085	5	\N	1
2149	2004-06-03	\N	\N	f	\N	\N	2	\N	295	1	2086	5	\N	1
2133	2001-06-25	\N	\N	f	\N	\N	1	\N	278	\N	2045	5	\N	1
2110	2001-06-27	\N	\N	f	\N	\N	1	\N	287	2	2047	5	\N	1
2150	2004-06-04	\N	\N	f	\N	\N	1	\N	295	2	2087	5	\N	1
2151	2004-06-04	\N	\N	f	\N	\N	2	\N	295	1	2088	5	\N	1
2153	2004-06-07	\N	\N	f	\N	\N	2	\N	295	1	2090	5	\N	1
2115	2001-07-02	\N	\N	f	\N	\N	1	\N	280	2	2053	5	\N	1
2168	2004-06-08	\N	\N	f	\N	\N	1	\N	295	2	2091	5	\N	1
2175	2004-06-10	\N	\N	f	\N	\N	2	\N	295	1	2095	5	\N	1
2158	2004-06-16	\N	\N	f	\N	\N	1	\N	295	2	2101	5	\N	1
2159	2004-06-16	\N	\N	f	\N	\N	2	\N	296	1	2102	5	\N	1
2160	2004-06-17	\N	\N	f	\N	\N	2	\N	295	1	2104	5	\N	1
2162	2004-06-18	\N	\N	f	\N	\N	2	\N	295	1	2106	5	\N	1
2124	2001-07-10	\N	\N	f	\N	\N	1	\N	280	\N	2062	5	\N	1
2125	2001-07-11	\N	\N	f	\N	\N	1	\N	280	\N	2063	5	\N	1
2134	2001-07-14	\N	\N	f	\N	\N	1	\N	280	\N	2065	5	\N	1
2127	2001-07-16	\N	\N	f	\N	\N	1	\N	280	\N	2066	5	\N	1
2128	2001-07-17	\N	\N	f	\N	\N	1	\N	280	\N	2067	5	\N	1
2129	2001-07-18	\N	\N	f	\N	\N	1	\N	278	\N	2068	5	\N	1
2137	2001-08-28	\N	\N	f	\N	\N	1	\N	280	\N	2072	5	\N	1
2163	2004-06-21	\N	\N	f	\N	\N	1	\N	295	2	2107	5	\N	1
2164	2004-06-21	\N	\N	f	\N	\N	2	\N	296	1	2108	5	\N	1
2109	2001-06-26	\N	\N	f	\N	\N	1	\N	278	\N	2046	5	\N	1
2138	2001-10-30	\N	\N	f	\N	\N	1	\N	288	\N	2073	5	\N	1
2176	2004-06-22	\N	\N	f	\N	\N	1	\N	296	2	2109	5	\N	1
2139	2002-10-01	\N	\N	f	\N	\N	1	\N	289	\N	2074	5	\N	1
2140	2002-11-01	\N	\N	f	\N	\N	1	\N	290	\N	2075	5	\N	1
2142	2003-06-16	\N	\N	f	\N	\N	1	\N	292	\N	2077	5	\N	1
2143	2003-06-17	\N	\N	f	\N	\N	1	\N	293	\N	2078	5	\N	1
2144	2004-01-09	\N	\N	f	\N	\N	1	\N	294	\N	2079	5	\N	1
2154	2004-06-09	\N	\N	f	\N	\N	1	\N	295	2	2092	5	\N	1
2170	2001-06-20	\N	\N	f	\N	\N	1	\N	281	\N	2082	5	\N	1
2166	2004-06-23	\N	\N	f	\N	\N	1	\N	295	2	2111	5	\N	1
2177	2004-06-25	\N	\N	f	\N	\N	1	\N	295	2	2114	5	\N	1
2174	2004-06-11	\N	\N	f	\N	\N	1	\N	295	2	2096	5	\N	1
2173	2004-06-15	\N	\N	f	\N	\N	1	\N	295	2	2099	5	\N	1
2157	2004-06-15	\N	\N	f	\N	\N	2	\N	295	1	2100	5	\N	1
2169	2004-06-11	\N	\N	f	\N	\N	2	\N	295	1	2097	5	\N	1
2178	2004-06-28	\N	\N	f	\N	\N	1	\N	295	2	2116	5	\N	1
2179	2004-06-28	\N	\N	f	\N	\N	2	\N	295	1	2117	5	\N	1
2181	2004-06-29	\N	\N	f	\N	\N	2	\N	297	1	2119	5	\N	1
2182	2004-06-30	\N	\N	f	\N	\N	2	\N	297	1	2120	5	\N	1
2185	2005-03-31	\N	\N	f	\N	\N	1	\N	300	\N	2123	5	\N	1
2187	2005-05-16	\N	\N	f	\N	\N	1	\N	302	\N	2125	5	\N	1
2188	2005-05-17	\N	\N	f	\N	\N	1	\N	303	\N	2126	5	\N	1
2189	2005-06-10	\N	\N	f	\N	\N	1	\N	304	\N	2128	5	\N	1
2191	2005-06-15	\N	\N	f	\N	\N	2	\N	304	1	2132	5	\N	1
2192	2005-06-16	\N	\N	f	\N	\N	1	\N	304	2	2133	5	\N	1
2194	2005-06-17	\N	\N	f	\N	\N	1	\N	304	2	2135	5	\N	1
2195	2005-06-17	\N	\N	f	\N	\N	2	\N	304	1	2136	5	\N	1
2107	2001-06-22	\N	\N	f	\N	\N	1	\N	280	2	2043	5	\N	1
2197	2005-06-20	\N	\N	f	\N	\N	2	\N	304	1	2138	5	\N	1
2198	2005-06-22	\N	\N	f	\N	\N	1	\N	304	2	2140	5	\N	1
2190	2005-06-15	\N	\N	f	\N	\N	1	\N	304	2	2131	5	\N	1
2073	1999-07-28	\N	\N	f	\N	\N	1	\N	270	2	2007	5	\N	1
2077	1999-11-17	\N	\N	f	Cecil	Lord	3	\N	272	5	2011	5	\N	1
2205	2005-06-29	\N	\N	f	\N	\N	1	\N	304	2	2149	5	\N	1
2212	2005-06-29	\N	\N	f	\N	\N	2	\N	304	1	2150	5	\N	1
2215	2004-06-25	\N	\N	f	\N	\N	2	\N	295	1	2115	5	\N	1
2206	2005-07-19	\N	\N	f	\N	\N	1	\N	304	\N	2151	5	\N	1
2217	2005-06-23	\N	\N	f	\N	\N	1	\N	304	2	2142	5	\N	1
2224	2005-01-11	\N	\N	f	\N	\N	1	\N	299	\N	2162	5	\N	1
2201	2005-06-24	\N	\N	f	\N	\N	2	\N	304	1	2144	5	\N	1
2227	2006-06-01	\N	\N	f	\N	\N	2	\N	310	1	2166	5	\N	1
2228	2006-06-02	\N	\N	f	\N	\N	1	\N	310	2	2167	5	\N	1
2259	2006-06-02	\N	\N	f	\N	\N	2	\N	310	1	2168	5	\N	1
2231	2006-06-07	\N	\N	f	\N	\N	1	\N	310	2	2173	5	\N	1
2232	2006-06-08	\N	\N	f	\N	\N	1	\N	310	2	2174	5	\N	1
2207	2005-09-06	\N	\N	f	\N	\N	1	\N	305	\N	2152	5	\N	1
2218	2005-10-03	\N	\N	f	\N	\N	1	\N	306	\N	2154	5	\N	1
2234	2006-06-09	\N	\N	f	\N	\N	1	\N	310	2	2176	5	\N	1
2235	2006-06-09	\N	\N	f	\N	\N	2	\N	310	1	2177	5	\N	1
2236	2006-06-12	\N	\N	f	\N	\N	1	\N	310	2	2178	5	\N	1
2257	2006-06-14	\N	\N	f	\N	\N	1	\N	310	2	2181	5	\N	1
2216	2005-06-13	\N	\N	f	\N	\N	1	\N	304	\N	2129	5	\N	1
2240	2006-06-15	\N	\N	f	\N	\N	1	\N	311	2	2183	5	\N	1
2260	2006-06-15	\N	\N	f	\N	\N	2	\N	311	1	2200	5	\N	1
2202	2005-06-27	\N	\N	f	\N	\N	1	\N	304	2	2145	5	\N	1
2252	2013-09-04	\N	\N	f	\N	\N	2	\N	318	1	2193	5	\N	1
2258	2005-10-10	\N	\N	f	\N	\N	1	\N	305	\N	2156	5	\N	1
2220	2005-10-12	\N	\N	f	\N	\N	1	\N	305	\N	2158	5	\N	1
2222	2006-04-28	\N	\N	f	\N	\N	1	\N	309	\N	2160	5	\N	1
2225	2005-01-28	\N	\N	f	\N	\N	1	\N	299	\N	2163	5	\N	1
2213	2005-05-31	\N	\N	f	\N	\N	1	\N	303	\N	2127	5	\N	1
2250	2013-09-05	\N	\N	f	\N	\N	2	\N	318	1	2196	5	\N	1
2295	2013-09-06	\N	\N	f	\N	\N	1	\N	318	2	2197	5	\N	1
2249	2013-09-05	\N	\N	f	\N	\N	1	\N	318	2	2195	5	\N	1
2230	2006-06-06	\N	\N	f	\N	\N	2	\N	310	1	2172	5	\N	1
2239	2006-06-14	\N	\N	f	\N	\N	2	\N	310	1	2182	5	\N	1
2253	2006-06-05	\N	\N	f	\N	\N	1	\N	310	2	2169	5	\N	1
2261	2006-06-16	\N	\N	f	\N	\N	1	\N	311	2	2201	5	\N	1
2304	2006-09-18	\N	\N	f	\N	\N	1	\N	341	\N	2244	5	\N	1
2297	2006-05-30	\N	\N	f	\N	\N	2	\N	310	1	2204	5	\N	1
2270	2007-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	2214	5	\N	1
2326	2014-11-28	\N	\N	f	\N	\N	1	\N	343	\N	2278	5	\N	1
2293	2013-09-06	\N	\N	f	\N	\N	2	\N	318	1	2198	5	\N	1
2226	2006-05-31	\N	\N	f	\N	\N	2	\N	310	1	2164	5	\N	1
2242	2012-11-01	\N	\N	f	\N	\N	1	\N	313	\N	2186	5	\N	1
2243	2013-01-08	\N	\N	f	\N	\N	1	\N	314	\N	2187	5	\N	1
2244	2013-01-21	\N	\N	f	\N	\N	1	\N	315	\N	2188	5	\N	1
2248	2013-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	2194	5	\N	1
2247	2013-09-04	\N	\N	f	\N	\N	1	\N	318	2	2192	5	\N	1
2305	2006-12-19	\N	\N	f	\N	\N	1	\N	319	\N	2245	5	\N	1
2327	2014-12-03	\N	\N	f	\N	\N	1	\N	343	\N	2280	5	\N	1
2308	2010-06-18	\N	\N	f	\N	\N	2	\N	342	4	2248	5	\N	1
2309	2010-06-18	\N	\N	f	\N	\N	4	\N	342	6	2250	5	\N	1
2310	2010-06-19	\N	\N	f	\N	\N	1	\N	342	\N	2251	5	\N	1
2313	2010-06-23	\N	\N	f	\N	\N	1	\N	342	2	2257	5	\N	1
2241	2012-07-03	\N	\N	f	\N	\N	1	\N	312	\N	2185	5	\N	1
2245	2013-03-26	\N	\N	f	\N	\N	1	\N	316	\N	2190	5	\N	1
2315	2010-06-24	\N	\N	f	\N	\N	1	\N	342	2	2259	5	\N	1
2219	2005-10-11	\N	\N	f	\N	\N	1	\N	307	\N	2157	5	\N	1
2316	2010-06-24	\N	\N	f	\N	\N	2	\N	342	1	2260	5	\N	1
2334	2010-06-25	\N	\N	f	\N	\N	1	\N	342	2	2261	5	\N	1
2318	2010-06-28	\N	\N	f	\N	\N	1	\N	342	3	2266	5	\N	1
2320	2010-07-07	\N	\N	f	\N	\N	1	\N	342	2	2268	5	\N	1
2290	2007-03-23	\N	\N	f	\N	\N	1	\N	321	\N	2206	5	\N	1
2265	2007-03-27	\N	\N	f	\N	\N	1	\N	321	\N	2208	5	\N	1
2268	2007-07-09	\N	\N	f	\N	\N	1	\N	322	2	2211	5	\N	1
2321	2010-07-07	\N	\N	f	\N	\N	3	\N	342	8	2270	5	\N	1
2323	2010-07-08	\N	\N	f	\N	\N	2	\N	342	1	2273	5	\N	1
2299	2007-07-11	\N	\N	f	\N	\N	1	\N	323	\N	2213	5	\N	1
2272	2007-10-10	\N	\N	f	\N	\N	1	\N	324	\N	2216	5	\N	1
2300	2007-10-11	\N	\N	f	\N	\N	1	\N	325	\N	2217	5	\N	1
2274	2008-05-28	\N	\N	f	\N	\N	1	\N	327	\N	2222	5	\N	1
2275	2008-05-29	\N	\N	f	\N	\N	1	\N	327	\N	2223	5	\N	1
2276	2008-06-30	\N	\N	f	\N	\N	1	\N	328	\N	2225	5	\N	1
2277	2008-10-01	\N	\N	f	\N	\N	1	\N	329	\N	2226	5	\N	1
2278	2008-10-13	\N	\N	f	\N	\N	1	\N	330	\N	2227	5	\N	1
2281	2008-11-03	\N	\N	f	\N	\N	1	\N	332	\N	2230	5	\N	1
2289	2008-11-10	\N	\N	f	\N	\N	1	\N	332	\N	2231	5	\N	1
2284	2009-06-27	\N	\N	f	\N	\N	1	\N	335	\N	2234	5	\N	1
2285	2009-07-20	\N	\N	f	\N	\N	1	\N	337	\N	2236	5	\N	1
2287	2009-08-25	\N	\N	f	\N	\N	1	\N	\N	\N	2238	5	\N	1
2301	2010-03-19	\N	\N	f	\N	\N	1	\N	339	\N	2240	5	\N	1
2302	2010-03-22	\N	\N	f	\N	\N	1	\N	339	\N	2241	5	\N	1
2324	2010-07-09	\N	\N	f	\N	\N	1	\N	342	2	2274	5	\N	1
2282	2009-02-02	\N	\N	f	\N	\N	1	\N	333	\N	2232	5	\N	1
2264	2007-03-26	\N	\N	f	\N	\N	1	\N	321	\N	2207	5	\N	1
2329	2010-07-09	\N	\N	f	\N	\N	2	\N	342	1	2275	5	\N	1
2332	2010-03-23	\N	\N	f	\N	\N	1	\N	339	\N	2242	5	\N	1
2254	2012-06-25	\N	\N	f	\N	\N	1	\N	312	\N	2184	5	\N	1
2291	2007-10-16	\N	\N	f	\N	\N	1	\N	325	\N	2219	5	\N	1
2317	2010-06-27	\N	\N	f	\N	\N	1	\N	342	2	2265	5	\N	1
2325	2010-07-10	\N	\N	f	\N	\N	2	\N	342	1	2276	5	\N	1
2296	2007-10-15	\N	\N	f	\N	\N	1	\N	325	\N	2218	5	\N	1
2303	2010-03-24	\N	\N	f	\N	\N	1	\N	339	\N	2243	5	\N	1
2331	2010-06-20	\N	\N	f	\N	\N	1	\N	342	2	2252	5	\N	1
2333	2010-06-22	\N	\N	f	\N	\N	1	\N	342	2	2255	5	\N	1
2312	2010-06-22	\N	\N	f	\N	\N	2	\N	342	1	2256	5	\N	1
2263	2007-01-11	\N	\N	f	\N	\N	1	\N	320	\N	2205	5	\N	1
2209	2004-06-23	\N	\N	f	\N	\N	2	\N	295	1	2112	5	\N	1
2203	2005-06-27	\N	\N	f	\N	\N	2	\N	304	1	2146	5	\N	1
2204	2005-06-28	\N	\N	f	\N	\N	1	\N	304	2	2147	5	\N	1
3039	1831-05-28	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxiii, 267-8; dated 26 (sic) May 1831 in Abstract, p. 16	\N	\N	2940	3	\N	\N
2349	2015-09-28	\N	\N	f	\N	\N	2	\N	350	1	2290	5	\N	1
2350	2015-09-29	\N	\N	f	\N	\N	2	\N	350	1	2291	5	\N	1
2351	2015-09-30	\N	\N	f	\N	\N	1	\N	350	2	2292	5	\N	1
2457	2015-09-30	\N	\N	f	\N	\N	2	\N	350	1	2379	5	\N	1
2353	2010-07-13	\N	\N	f	\N	\N	1	\N	342	2	2294	5	\N	1
2355	2010-07-14	\N	\N	f	\N	\N	1	\N	342	2	2296	5	\N	1
2379	2010-07-15	\N	\N	f	\N	\N	1	\N	342	2	2298	5	\N	1
2346	2010-05-29	\N	\N	f	\N	\N	1	\N	348	\N	2286	5	\N	1
2378	2010-07-19	\N	\N	f	\N	\N	1	\N	342	2	2301	5	\N	1
2359	2010-07-21	\N	\N	f	\N	\N	1	\N	342	2	2305	5	\N	1
2361	2010-07-22	\N	\N	f	\N	\N	2	\N	352	1	2308	5	\N	1
2342	2014-12-11	\N	\N	f	\N	\N	1	\N	343	\N	2281	5	\N	1
2343	2015-03-17	\N	\N	f	\N	\N	1	\N	344	\N	2282	5	\N	1
2344	2015-05-26	\N	\N	f	\N	\N	1	\N	346	2	2284	5	\N	1
2362	2010-07-23	\N	\N	f	\N	\N	1	\N	352	\N	2309	5	\N	1
2381	2010-06-17	\N	\N	f	\N	\N	1	\N	342	2	2287	5	\N	1
2348	2015-09-28	\N	\N	f	\N	\N	1	\N	350	2	2289	5	\N	1
2369	2010-12-18	\N	\N	f	\N	\N	1	\N	356	2	2316	5	\N	1
2370	2010-12-18	\N	\N	f	\N	\N	2	\N	356	1	2317	5	\N	1
2371	2010-12-20	\N	\N	f	\N	\N	1	\N	356	2	2318	5	\N	1
2376	2010-12-22	\N	\N	f	\N	\N	1	\N	356	2	2321	5	\N	1
2357	2010-07-20	\N	\N	f	\N	\N	1	\N	351	2	2303	5	\N	1
2356	2010-07-16	\N	\N	f	\N	\N	2	\N	342	1	2300	5	\N	1
2382	2010-12-22	\N	\N	f	\N	\N	2	\N	356	1	2322	5	\N	1
2374	2010-07-19	\N	\N	f	\N	\N	2	\N	342	1	2302	5	\N	1
2375	2010-07-15	\N	\N	f	\N	\N	2	\N	342	1	2299	5	\N	1
2372	2010-12-21	\N	\N	f	\N	\N	2	\N	356	1	2320	5	\N	1
2338	2010-07-07	\N	\N	f	\N	\N	2	\N	342	9	2269	5	\N	1
2363	2010-07-26	\N	\N	f	\N	\N	1	\N	352	\N	2310	5	\N	1
2364	2010-11-08	\N	\N	f	\N	\N	1	\N	353	\N	2311	5	\N	1
2365	2010-11-16	\N	\N	f	\N	\N	1	\N	354	\N	2312	5	\N	1
2384	2010-12-23	\N	\N	f	\N	\N	2	\N	356	1	2324	5	\N	1
2462	2011-01-10	\N	\N	f	\N	\N	1	\N	356	2	2366	5	\N	1
2425	2011-01-10	\N	\N	f	\N	\N	2	\N	356	1	2367	5	\N	1
2387	2015-05-29	\N	\N	f	\N	\N	1	\N	346	\N	2328	5	\N	1
2390	2011-01-13	\N	\N	f	\N	\N	1	\N	356	2	2331	5	\N	1
2391	2011-01-13	\N	\N	f	\N	\N	2	\N	356	1	2332	5	\N	1
2392	2011-01-14	\N	\N	f	\N	\N	1	\N	356	2	2333	5	\N	1
2393	2011-01-14	\N	\N	f	\N	\N	2	\N	356	1	2334	5	\N	1
2414	2011-01-18	\N	\N	f	\N	\N	1	\N	356	2	2336	5	\N	1
2397	2011-01-19	\N	\N	f	\N	\N	2	\N	356	1	2339	5	\N	1
2398	2011-01-20	\N	\N	f	\N	\N	1	\N	356	2	2340	5	\N	1
2399	2011-01-20	\N	\N	f	\N	\N	2	\N	356	2	2341	5	\N	1
2413	2011-01-21	\N	\N	f	\N	\N	1	\N	356	2	2342	5	\N	1
2420	2011-01-24	\N	\N	f	\N	\N	2	\N	356	1	2345	5	\N	1
2402	2011-01-25	\N	\N	f	\N	\N	2	\N	356	1	2347	5	\N	1
2417	2011-01-26	\N	\N	f	\N	\N	1	\N	356	2	2348	5	\N	1
2407	2011-02-02	\N	\N	f	\N	\N	1	\N	356	2	2357	5	\N	1
2408	2011-02-02	\N	\N	f	\N	\N	2	\N	356	1	2358	5	\N	1
2347	2015-06-08	\N	\N	f	\N	\N	1	\N	349	\N	2288	5	\N	1
2409	2011-02-04	\N	\N	f	\N	\N	1	\N	356	2	2359	5	\N	1
2410	2011-02-28	\N	\N	f	\N	\N	1	\N	356	\N	2361	5	\N	1
2416	2011-01-21	\N	\N	f	\N	\N	2	\N	356	1	2343	5	\N	1
2396	2011-01-19	\N	\N	f	\N	\N	1	\N	356	2	2338	5	\N	1
2400	2011-01-24	\N	\N	f	\N	\N	1	\N	356	2	2344	5	\N	1
2419	2011-01-26	\N	\N	f	\N	\N	2	\N	356	1	2349	5	\N	1
2421	2011-01-27	\N	\N	f	\N	\N	1	\N	356	2	2350	5	\N	1
2422	2011-01-28	\N	\N	f	\N	\N	1	\N	356	2	2352	5	\N	1
2423	2011-01-31	\N	\N	f	\N	\N	2	\N	356	1	2354	5	\N	1
2405	2011-02-01	\N	\N	f	\N	\N	1	\N	356	2	2355	5	\N	1
2426	2011-01-11	\N	\N	f	\N	\N	1	\N	356	2	2368	5	\N	1
2389	2011-01-12	\N	\N	f	\N	\N	2	\N	356	1	2330	5	\N	1
2429	2015-10-12	\N	\N	f	\N	\N	2	\N	350	1	2372	5	\N	1
2430	2015-10-13	\N	\N	f	\N	\N	1	\N	350	2	2373	5	\N	1
2431	2015-10-13	\N	\N	f	\N	\N	2	\N	350	1	2374	5	\N	1
2438	2015-10-16	\N	\N	f	\N	\N	2	\N	350	1	2386	5	\N	1
2435	2015-10-02	\N	\N	f	\N	\N	1	\N	350	2	2383	5	\N	1
2436	2015-10-05	\N	\N	f	\N	\N	1	\N	350	2	2384	5	\N	1
2411	2011-10-12	\N	\N	f	\N	\N	1	\N	359	\N	2362	5	\N	1
2412	2011-10-13	\N	\N	f	\N	\N	1	\N	359	\N	2363	5	\N	1
2444	2014-09-05	\N	\N	f	\N	\N	1	\N	360	\N	2395	5	\N	1
2437	2015-10-05	\N	\N	f	\N	\N	2	\N	350	1	2385	5	\N	1
2455	2015-10-06	\N	\N	f	\N	\N	2	\N	350	1	2365	5	\N	1
2439	2015-10-19	\N	\N	f	\N	\N	1	\N	350	2	2387	5	\N	1
2440	2015-10-19	\N	\N	f	\N	\N	2	\N	350	1	2388	5	\N	1
2450	2015-10-20	\N	\N	f	\N	\N	2	\N	350	1	2390	5	\N	1
2449	2015-10-22	\N	\N	f	\N	\N	2	\N	350	1	2394	5	\N	1
2446	2014-09-11	\N	\N	f	\N	\N	2	\N	360	1	2397	5	\N	1
2461	2014-09-12	\N	\N	f	\N	\N	1	\N	360	2	2398	5	\N	1
2453	2014-09-18	\N	\N	f	\N	\N	1	\N	360	2	2403	5	\N	1
2467	2015-10-23	\N	\N	f	\N	\N	2	\N	350	1	2410	5	\N	1
2464	2015-10-21	\N	\N	f	\N	\N	1	\N	350	2	2391	5	\N	1
2460	2014-09-16	\N	\N	f	\N	\N	2	\N	360	1	2400	5	\N	1
2458	2014-09-18	\N	\N	f	\N	\N	2	\N	360	1	2404	5	\N	1
2466	2015-10-07	\N	\N	f	\N	\N	2	\N	350	1	2407	5	\N	1
2465	2014-09-19	\N	\N	f	\N	\N	2	\N	360	1	2406	5	\N	1
2434	2015-10-01	\N	\N	f	\N	\N	2	\N	350	8	2381	5	\N	1
2456	2014-09-19	\N	\N	f	\N	\N	1	\N	360	2	2405	5	\N	1
2447	2014-09-17	\N	\N	f	\N	\N	1	\N	360	2	2401	5	\N	1
2452	2014-09-15	\N	\N	f	\N	\N	2	\N	360	1	2399	5	\N	1
2445	2014-09-11	\N	\N	f	\N	\N	1	\N	360	2	2396	5	\N	1
2469	2015-10-29	\N	\N	f	\N	\N	1	\N	361	\N	2413	5	\N	1
2341	2014-12-02	\N	\N	f	\N	\N	1	\N	343	\N	2279	5	\N	1
2427	2015-10-09	\N	\N	f	\N	\N	1	\N	350	2	2369	5	\N	1
2336	2009-09-11	\N	\N	f	\N	\N	1	\N	338	\N	2239	5	\N	1
2352	2010-07-12	\N	\N	f	\N	\N	2	\N	342	1	2293	5	\N	1
2386	2015-05-28	\N	\N	f	\N	\N	2	\N	346	1	2327	5	\N	1
2478	2013-09-11	\N	\N	f	\N	\N	1	\N	318	2	2427	5	\N	1
2482	2013-09-13	\N	\N	f	\N	\N	1	\N	318	2	2431	5	\N	1
2483	2013-09-13	\N	\N	f	\N	\N	2	\N	318	1	2432	5	\N	1
2495	2013-09-16	\N	\N	f	\N	\N	1	\N	318	2	2433	5	\N	1
2485	2013-09-17	\N	\N	f	\N	\N	1	\N	318	2	2435	5	\N	1
2502	2013-09-17	\N	\N	f	\N	\N	2	\N	318	1	2436	5	\N	1
2487	2013-09-19	\N	\N	f	\N	\N	1	\N	318	2	2438	5	\N	1
2472	2016-02-29	\N	\N	f	\N	\N	1	\N	362	\N	2418	5	\N	1
2501	2016-08-30	\N	\N	f	\N	\N	1	\N	363	2	2419	5	\N	1
2488	2013-10-02	\N	\N	f	\N	\N	1	\N	318	2	2441	5	\N	1
2494	2013-10-03	\N	\N	f	\N	\N	2	\N	318	1	2444	5	\N	1
2532	2015-10-23	\N	\N	f	\N	\N	1	\N	350	2	2449	5	\N	1
2505	2014-09-23	\N	\N	f	\N	\N	1	\N	360	2	2448	5	\N	1
2504	2015-11-02	\N	\N	f	\N	\N	1	\N	361	\N	2416	5	\N	1
2492	2014-09-22	\N	\N	f	\N	\N	2	\N	360	1	2447	5	\N	1
2484	2013-09-16	\N	\N	f	\N	\N	2	\N	318	1	2434	5	\N	1
2477	2013-09-10	\N	\N	f	\N	\N	2	\N	318	1	2426	5	\N	1
2491	2014-09-24	\N	\N	f	\N	\N	1	\N	360	2	2446	5	\N	1
2493	2015-10-30	\N	\N	f	\N	\N	2	\N	361	1	2415	5	\N	1
2486	2013-09-18	\N	\N	f	\N	\N	2	\N	318	1	2437	5	\N	1
2474	2016-08-31	\N	\N	f	\N	\N	2	\N	363	1	2422	5	\N	1
2499	2014-09-23	\N	\N	f	\N	\N	2	\N	360	1	2445	5	\N	1
2510	2017-10-30	\N	\N	f	\N	\N	1	\N	368	\N	2459	5	\N	1
2517	2018-06-18	\N	\N	f	\N	\N	2	\N	364	1	2466	5	\N	1
2539	2018-06-19	\N	\N	f	\N	\N	2	\N	364	1	2467	5	\N	1
2519	2018-06-22	\N	\N	f	\N	\N	1	\N	364	2	2471	5	\N	1
2564	2018-06-22	\N	\N	f	\N	\N	2	\N	364	1	2518	5	\N	1
2522	2019-10-08	\N	\N	f	\N	\N	1	\N	373	2	2477	5	\N	1
2525	2019-10-10	\N	\N	f	\N	\N	1	\N	374	2	2481	5	\N	1
2541	2019-10-10	\N	\N	f	\N	\N	2	\N	373	1	2482	5	\N	1
2585	2019-10-16	\N	\N	f	\N	\N	2	\N	374	1	2530	5	\N	1
2576	2016-09-05	\N	\N	f	\N	\N	1	\N	363	2	2490	5	\N	1
2536	2016-09-06	\N	\N	f	\N	\N	1	\N	\N	2	2452	5	\N	1
2500	2015-10-26	\N	\N	f	\N	\N	2	\N	350	1	2412	5	\N	1
2471	2015-12-01	\N	\N	f	\N	\N	1	\N	350	\N	2417	5	\N	1
2518	2018-06-21	\N	\N	f	\N	\N	1	\N	364	2	2470	5	\N	1
2545	2017-06-22	\N	\N	f	\N	\N	1	\N	363	\N	2455	5	\N	1
2508	2017-07-14	\N	\N	f	\N	\N	1	\N	366	\N	2456	5	\N	1
2509	2017-10-19	\N	\N	f	\N	\N	2	\N	367	1	2458	5	\N	1
2506	2016-10-17	\N	\N	f	\N	\N	1	\N	365	\N	2453	5	\N	1
2512	2017-11-03	\N	\N	f	\N	\N	1	\N	368	\N	2461	5	\N	1
2514	2017-11-07	\N	\N	f	\N	\N	2	\N	368	1	2463	5	\N	1
2543	2018-06-20	\N	\N	f	\N	\N	1	\N	364	2	2468	5	\N	1
2516	2018-06-18	\N	\N	f	\N	\N	1	\N	364	2	2465	5	\N	1
2538	2019-10-11	\N	\N	f	\N	\N	2	\N	375	1	2484	5	\N	1
2524	2019-10-09	\N	\N	f	\N	\N	2	\N	373	1	2480	5	\N	1
2533	2018-06-20	\N	\N	f	\N	\N	2	\N	364	1	2469	5	\N	1
2527	2019-10-14	\N	\N	f	\N	\N	2	\N	373	1	2486	5	\N	1
2540	2018-11-26	\N	\N	f	\N	\N	1	\N	364	\N	2474	5	\N	1
2555	2020-09-02	\N	\N	f	\N	\N	2	\N	380	1	2501	5	\N	1
2584	2020-09-03	\N	\N	f	\N	\N	1	\N	381	2	2502	5	\N	1
2586	2020-09-07	\N	\N	f	\N	\N	1	\N	380	2	2506	5	\N	1
2559	2020-09-09	\N	\N	f	\N	\N	2	\N	381	1	2510	5	\N	1
2560	2020-09-10	\N	\N	f	\N	\N	1	\N	381	2	2511	5	\N	1
2561	2020-09-10	\N	\N	f	\N	\N	2	\N	381	1	2512	5	\N	1
2521	2019-10-07	\N	\N	f	\N	\N	2	\N	373	1	2475	5	\N	1
2563	2020-09-11	\N	\N	f	\N	\N	2	\N	382	1	2514	5	\N	1
2578	2020-09-14	\N	\N	f	\N	\N	1	\N	381	2	2515	5	\N	1
2566	2018-07-10	\N	\N	f	\N	\N	1	\N	370	\N	2521	5	\N	1
2530	2019-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	2476	5	\N	1
2569	2020-09-16	\N	\N	f	\N	\N	2	\N	381	1	2524	5	\N	1
2570	2020-09-17	\N	\N	f	\N	\N	1	\N	381	2	2525	5	\N	1
2571	2020-09-18	\N	\N	f	\N	\N	1	\N	380	2	2526	5	\N	1
2574	2019-10-28	\N	\N	f	\N	\N	1	\N	374	\N	2531	5	\N	1
2573	2020-09-30	\N	\N	f	\N	\N	2	\N	380	1	2528	5	\N	1
2605	2020-10-12	\N	\N	f	\N	\N	1	\N	380	\N	2557	5	\N	1
2556	2020-09-04	\N	\N	f	\N	\N	1	\N	380	2	2504	5	\N	1
2531	2016-09-05	\N	\N	f	\N	\N	2	\N	363	1	2450	5	\N	1
2534	2018-07-11	\N	\N	f	\N	\N	1	\N	370	\N	2472	5	\N	1
2547	2019-11-11	\N	\N	f	\N	\N	1	\N	374	\N	2492	5	\N	1
2583	2020-01-06	\N	\N	f	\N	\N	1	\N	376	\N	2493	5	\N	1
2550	2020-04-16	\N	\N	f	\N	\N	1	\N	379	\N	2496	5	\N	1
2553	2020-08-12	\N	\N	f	\N	\N	1	\N	\N	\N	2499	5	\N	1
2551	2020-09-01	\N	\N	f	\N	\N	1	\N	380	2	2497	5	\N	1
2575	2020-09-03	\N	\N	f	\N	\N	2	\N	380	1	2503	5	\N	1
2581	2020-09-14	\N	\N	f	\N	\N	2	\N	380	1	2516	5	\N	1
2558	2020-09-08	\N	\N	f	\N	\N	2	\N	380	1	2508	5	\N	1
2577	2020-09-15	\N	\N	f	\N	\N	1	\N	381	2	2517	5	\N	1
2579	2020-09-07	\N	\N	f	\N	\N	2	\N	381	1	2507	5	\N	1
2546	2019-10-30	\N	\N	f	\N	\N	1	\N	374	\N	2491	5	\N	1
2587	2020-11-06	\N	\N	f	\N	\N	1	\N	381	2	2532	5	\N	1
2589	2020-11-06	\N	\N	f	\N	\N	2	\N	\N	1	2534	5	\N	1
2588	2020-11-19	\N	\N	f	\N	\N	1	\N	381	\N	2533	5	\N	1
2595	2021-01-27	\N	\N	f	\N	\N	1	\N	383	2	2541	5	\N	1
2548	2020-01-11	\N	\N	f	\N	\N	1	\N	378	\N	2494	5	\N	1
2598	2021-01-29	\N	\N	f	\N	\N	1	\N	385	1	2545	5	\N	1
2599	2021-02-03	\N	\N	f	\N	\N	1	\N	383	\N	2549	5	\N	1
2604	1858-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	2556	5	\N	6
2475	2016-09-01	\N	\N	f	\N	\N	1	\N	363	2	2423	5	\N	1
2497	2013-09-10	\N	\N	f	\N	\N	1	\N	318	2	2425	5	\N	1
2590	2020-12-23	\N	\N	f	\N	\N	1	\N	383	\N	2535	5	\N	1
2591	2020-12-30	\N	\N	f	\N	\N	1	\N	384	\N	2536	5	\N	1
2592	2021-01-25	\N	\N	f	\N	\N	1	\N	383	2	2537	5	\N	1
2601	2021-03-26	\N	\N	f	\N	\N	1	\N	386	\N	2551	5	\N	1
2602	2021-04-27	\N	\N	f	\N	\N	1	\N	385	\N	2552	5	\N	1
2603	2021-07-05	\N	\N	f	\N	\N	1	\N	387	\N	2553	5	\N	1
2476	2016-09-01	\N	\N	f	\N	\N	2	\N	363	1	2424	5	\N	1
2528	2016-09-02	\N	\N	f	\N	\N	1	\N	363	2	2487	5	\N	1
2620	2021-01-29	\N	\N	f	\N	\N	2	\N	383	1	2546	5	\N	1
2676	1966-01-18	\N	\N	f	\N	\N	1	\N	120	\N	2607	5	\N	1
2726	1993-10-12	\N	\N	f	\N	\N	1	\N	237	\N	2638	5	\N	1
2712	1997-09-25	\N	\N	f	\N	\N	2	\N	261	1	2645	5	\N	1
1959	1997-10-23	\N	\N	f	\N	\N	2	\N	261	1	1890	5	\N	1
2728	1997-10-30	\N	\N	f	\N	\N	1	\N	261	2	2648	5	\N	1
2730	1998-08-03	\N	\N	f	\N	\N	1	\N	264	2	2651	5	\N	1
2721	2001-06-16	\N	\N	f	\N	\N	1	\N	280	\N	2656	5	\N	1
2729	2004-06-24	\N	\N	f	\N	\N	2	\N	295	1	2660	5	\N	1
2727	2004-01-12	\N	\N	f	\N	\N	1	\N	389	2	2658	5	\N	1
2610	1869-12-13	\N	\N	f	\N	\N	1	\N	\N	\N	2562	5	\N	6
2611	1874-02-28	\N	\N	f	\N	\N	1	\N	\N	\N	2563	5	\N	6
2657	1886-02-17	\N	\N	f	\N	\N	1	\N	\N	\N	2588	5	\N	6
2621	2021-01-26	\N	\N	f	\N	\N	2	\N	383	1	2540	5	\N	1
2624	1892-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	508	5	\N	6
2607	1848-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	2559	5	\N	6
2734	2009-04-21	\N	\N	f	\N	\N	1	\N	391	\N	2669	5	\N	1
2723	2004-06-08	\N	\N	f	\N	\N	2	\N	295	1	2659	5	\N	1
2715	1998-02-13	\N	\N	f	\N	\N	1	\N	263	\N	2649	5	\N	1
2724	2006-05-26	\N	\N	f	\N	\N	1	\N	310	2	2663	5	\N	1
2717	1999-07-27	\N	\N	f	\N	\N	2	\N	268	1	2652	5	\N	1
2618	2021-02-01	\N	\N	f	\N	\N	2	\N	383	1	2548	5	\N	1
2614	1889-12-05	\N	\N	f	\N	\N	1	\N	\N	\N	503	5	\N	6
2625	1896-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	2568	5	\N	6
2626	1896-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	2569	5	\N	6
2629	1909-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	2572	5	\N	5
2630	1911-06-20	\N	\N	f	Mountgarret	14th Viscount 	1	\N	\N	\N	2573	5	3	4
2633	1917-06-21	\N	\N	f	Farquhar	1st Lord	1	\N	\N	\N	489	5	\N	4
2655	1919-09-30	\N	\N	f	Iveagh	1st Viscount	1	\N	5	\N	525	5	\N	4
2634	1917-06-23	\N	\N	f	\N	\N	2	\N	\N	\N	2576	5	\N	4
2635	1919-09-27	\N	\N	f	\N	\N	1	\N	\N	\N	2577	5	\N	4
2638	1925-06-16	\N	\N	f	Bearsted	1st Lord	1	\N	18	\N	713	5	\N	4
2637	1922-01-25	\N	\N	f	\N	\N	1	\N	10	\N	2579	5	\N	4
2640	1926-02-17	\N	\N	f	Dunedin	1st Lord	1	\N	19	\N	523	5	\N	4
2642	1928-01-12	\N	\N	f	Byng of Vimy	1st Lord	1	\N	\N	\N	689	5	\N	4
2646	1933-02-24	\N	\N	f	Buckmaster	1st Lord	1	\N	33	\N	625	5	\N	4
2643	1929-07-10	\N	\N	f	\N	\N	2	\N	27	\N	2580	5	\N	4
2645	1929-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	2582	5	\N	4
2652	1945-07-02	\N	\N	f	Addison	1st Lord	1	\N	61	\N	868	5	\N	2
2644	1932-06-22	\N	\N	f	\N	\N	1	\N	33	\N	2581	5	\N	4
2647	1935-06-26	\N	\N	f	\N	\N	1	\N	40	\N	2583	5	\N	4
2648	1936-07-17	\N	\N	f	\N	\N	1	\N	42	\N	2584	5	\N	3
2650	1939-07-06	\N	\N	f	\N	\N	1	\N	49	\N	2586	5	\N	2
2687	1942-03-09	\N	\N	f	\N	\N	1	\N	\N	\N	2619	5	\N	2
2686	1944-01-28	\N	\N	f	\N	\N	1	\N	58	\N	2618	5	\N	2
2658	1945-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	2590	5	\N	2
2662	1947-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	2594	5	\N	2
2628	1906-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	2571	5	\N	5
2632	1916-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	2575	5	\N	4
2659	1946-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	2591	5	\N	2
2653	1946-06-28	\N	\N	f	\N	\N	1	\N	66	\N	2589	5	\N	2
2664	1952-01-07	\N	\N	f	\N	\N	1	\N	78	\N	2595	5	\N	2
2622	2021-01-28	\N	\N	f	\N	\N	2	\N	383	1	2544	5	\N	1
2663	1949-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	1177	5	\N	2
2661	1951-06-26	\N	\N	f	\N	\N	1	\N	76	\N	2593	5	\N	2
2666	1955-01-10	\N	\N	f	\N	\N	1	\N	84	\N	2597	5	\N	1
2694	1958-08-08	\N	\N	f	\N	\N	1	\N	285	\N	2599	5	\N	1
2670	1960-01-07	\N	\N	f	\N	\N	1	\N	\N	\N	2601	5	\N	1
2671	1961-07-11	\N	\N	f	\N	\N	1	\N	100	\N	2602	5	\N	1
2669	1961-02-02	\N	\N	f	\N	\N	1	\N	98	\N	2600	5	\N	1
2672	1963-11-08	\N	\N	f	\N	\N	1	\N	388	\N	2603	5	\N	1
2674	1964-12-16	\N	\N	f	\N	\N	1	\N	115	2	2605	5	\N	1
2738	2015-05-26	\N	\N	f	\N	\N	2	\N	346	1	2673	5	\N	1
2737	2010-07-10	\N	\N	f	\N	\N	1	\N	342	2	2672	5	\N	1
2677	1966-05-31	\N	\N	f	\N	\N	1	\N	121	\N	2608	5	\N	1
2679	1967-11-29	\N	\N	f	\N	\N	1	\N	127	\N	2610	5	\N	1
2680	1969-03-03	\N	\N	f	\N	\N	1	\N	134	\N	2611	5	\N	1
2681	1970-09-21	\N	\N	f	\N	\N	1	\N	140	\N	2612	5	\N	1
2682	1971-02-05	\N	\N	f	\N	\N	1	\N	141	\N	2613	5	\N	1
2683	1973-07-09	\N	\N	f	\N	\N	1	\N	153	\N	2614	5	\N	1
2685	1974-05-07	\N	\N	f	\N	\N	1	\N	159	\N	2616	5	\N	1
2719	1976-06-25	\N	\N	f	\N	\N	1	\N	173	\N	2654	5	\N	1
2689	1978-05-11	\N	\N	f	\N	\N	1	\N	180	\N	2621	5	\N	1
2690	1978-07-13	\N	\N	f	\N	\N	1	\N	181	\N	2622	5	\N	1
2691	1979-02-09	\N	\N	f	\N	\N	1	\N	182	\N	2623	5	\N	1
2692	1979-07-26	\N	\N	f	\N	\N	1	\N	186	\N	2624	5	\N	1
2693	1980-07-10	\N	\N	f	\N	\N	1	\N	188	\N	2625	5	\N	1
2695	1981-06-02	\N	\N	f	\N	\N	1	\N	190	\N	2626	5	\N	1
2698	1984-02-01	\N	\N	f	\N	\N	1	\N	201	\N	2629	5	\N	1
2699	1985-05-16	\N	\N	f	\N	\N	1	\N	203	\N	2630	5	\N	1
2701	1987-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	2632	5	\N	1
2702	1987-10-19	\N	\N	f	\N	\N	1	\N	211	\N	2633	5	\N	1
2703	1990-06-18	\N	\N	f	\N	\N	1	\N	218	\N	2635	5	\N	1
2704	1992-06-27	\N	\N	f	\N	\N	1	\N	232	\N	2636	5	\N	1
2705	1992-07-01	\N	\N	f	\N	\N	2	\N	230	1	2637	5	\N	1
2707	1996-01-12	\N	\N	f	\N	\N	1	\N	247	\N	2640	5	\N	1
2708	1996-02-16	\N	\N	f	\N	\N	1	\N	249	\N	2641	5	\N	1
2709	1996-10-17	\N	\N	f	\N	\N	1	\N	253	\N	2642	5	\N	1
2711	1997-06-12	\N	\N	f	\N	\N	2	\N	256	1	2644	5	\N	1
2739	2010-07-16	\N	\N	f	\N	\N	1	\N	342	2	2674	5	\N	1
2714	1997-10-27	\N	\N	f	\N	\N	1	\N	261	2	2647	5	\N	1
2716	1998-07-29	\N	\N	f	\N	\N	1	\N	265	2	2650	5	\N	1
2722	2001-07-03	\N	\N	f	\N	\N	1	\N	280	2	2657	5	\N	1
2735	2010-05-27	\N	\N	f	\N	\N	1	\N	348	\N	2670	5	\N	1
2613	2020-11-05	\N	\N	f	\N	\N	1	\N	380	\N	2565	5	\N	1
2615	1837-08-12	\N	\N	f	\N	\N	1	\N	\N	\N	2566	5	\N	6
2733	2013-09-09	\N	\N	f	\N	\N	1	\N	318	2	2666	5	\N	1
2619	2021-07-16	\N	\N	f	\N	\N	1	\N	380	\N	2554	5	\N	1
2749	2020-09-17	\N	\N	f	\N	\N	2	\N	381	1	2692	5	\N	1
2872	2014-09-15	\N	\N	f	\N	\N	1	\N	360	2	2791	5	\N	1
2745	2013-10-04	\N	\N	f	\N	\N	1	\N	392	\N	2685	5	\N	1
2870	2014-12-16	\N	\N	f	\N	\N	1	\N	360	\N	2789	5	\N	1
2761	2013-09-18	\N	\N	f	\N	\N	1	\N	318	2	2684	5	\N	1
2813	2007-12-10	\N	\N	f	\N	\N	1	\N	326	\N	2741	5	\N	1
2743	2015-10-15	\N	\N	f	\N	\N	2	\N	350	1	2680	5	\N	1
2811	2004-06-14	\N	\N	f	\N	\N	1	\N	295	2	2739	5	\N	1
2808	1997-10-31	\N	\N	f	\N	\N	2	\N	260	1	2735	5	\N	1
1970	1997-11-04	\N	\N	f	\N	\N	2	\N	261	1	1905	5	\N	1
2868	2004-06-30	\N	\N	f	\N	\N	1	\N	295	2	2786	5	\N	1
2760	2014-09-12	\N	\N	f	\N	\N	2	\N	360	1	2681	5	\N	1
2816	2017-11-20	\N	\N	f	\N	\N	1	\N	368	\N	2746	5	\N	1
2765	2006-06-16	\N	\N	f	\N	\N	2	\N	311	1	2667	5	\N	1
2756	1815-08-11	\N	\N	f	\N	\N	8	\N	\N	\N	2701	5	\N	11
2810	2001-06-22	\N	\N	f	\N	\N	2	\N	280	1	2738	5	\N	1
2820	1869-12-07	\N	\N	t	Southesk	9th Earl 	1	\N	\N	\N	2753	5	2	6
2863	1801-04-27	\N	\N	t	St Vincent	1st Earl	1	\N	\N	\N	2769	5	\N	11
2757	1821-07-17	\N	\N	f	\N	\N	12	\N	\N	\N	2702	5	\N	8
2768	1824-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	2703	5	\N	8
2826	2010-11-15	\N	\N	f	\N	\N	1	\N	353	\N	2743	5	\N	1
2789	2020-11-02	\N	\N	f	\N	\N	1	\N	381	\N	2716	5	\N	1
2766	2015-10-07	\N	\N	f	\N	\N	1	\N	350	2	2679	5	\N	1
2792	1966-06-01	\N	\N	f	\N	\N	1	\N	121	\N	2720	5	\N	1
2762	2014-09-24	\N	\N	f	\N	\N	2	\N	360	1	2686	5	\N	1
2812	2005-06-14	\N	\N	f	\N	\N	2	\N	304	1	2740	5	\N	1
2747	2019-10-15	\N	\N	f	\N	\N	1	\N	374	2	2689	5	\N	1
2764	2011-01-31	\N	\N	f	\N	\N	1	\N	356	2	2678	5	\N	1
2771	1831-09-10	\N	\N	f	\N	\N	14	\N	\N	\N	213	5	\N	7
2769	1826-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	2704	5	\N	8
2844	1934-06-26	\N	\N	t	Lucan	5th Earl 	1	\N	37	\N	2766	5	3	4
2744	2014-09-22	\N	\N	f	\N	\N	1	\N	360	2	2682	5	\N	1
2753	1806-02-21	\N	\N	t	Eglinton	12th Earl 	1	\N	\N	\N	2697	5	2	11
2773	1839-04-20	\N	\N	f	\N	\N	2	\N	\N	\N	2707	5	\N	6
2848	1839-05-10	\N	\N	f	\N	\N	1	\N	\N	\N	2768	5	\N	6
2819	1866-08-31	\N	\N	f	Boyne	7th Viscount 	1	\N	\N	\N	2752	5	3	6
2830	1802-04-01	\N	\N	f	Rivers	1st Lord	1	\N	\N	\N	2749	5	\N	11
2822	1891-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	2755	5	\N	6
2779	1893-06-24	\N	\N	f	\N	\N	1	\N	\N	\N	2710	5	\N	6
2780	1898-01-19	\N	\N	f	\N	\N	2	\N	\N	\N	2711	5	\N	6
2782	1906-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	2712	5	\N	5
2783	1910-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	819	5	\N	4
2784	1911-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	2713	5	\N	4
2824	1911-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	739	5	\N	4
2787	1934-01-13	\N	\N	f	\N	\N	1	\N	36	\N	882	5	\N	4
2847	1945-09-15	\N	\N	f	\N	\N	1	\N	64	\N	974	5	\N	2
2758	2021-04-26	\N	\N	f	\N	\N	1	\N	386	\N	2695	5	\N	1
2846	1957-08-22	\N	\N	f	\N	\N	1	\N	89	\N	2767	5	\N	1
2790	1957-02-04	\N	\N	f	\N	\N	1	\N	88	\N	2718	5	\N	1
2850	1966-06-13	\N	\N	f	\N	\N	1	\N	121	\N	2772	5	\N	1
2834	1960-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	2758	5	\N	1
2851	1968-01-19	\N	\N	f	\N	\N	1	\N	128	\N	2773	5	\N	1
2852	1974-12-19	\N	\N	f	\N	\N	1	\N	164	\N	2775	5	\N	1
2797	1979-07-18	\N	\N	f	\N	\N	1	\N	186	\N	2725	5	\N	1
2856	1980-02-21	\N	\N	f	\N	\N	1	\N	187	\N	2779	5	\N	1
2802	1987-03-30	\N	\N	f	\N	\N	1	\N	208	\N	2728	5	\N	1
2751	1881-11-24	\N	\N	f	Lyons	2nd Lord	1	\N	1	\N	2694	5	\N	6
2865	1987-10-05	\N	\N	f	\N	\N	1	\N	211	\N	2782	5	\N	1
2860	1990-08-24	\N	\N	f	\N	\N	1	\N	219	\N	2764	5	\N	1
2750	2001-06-05	\N	\N	f	\N	\N	1	\N	278	\N	2693	5	\N	1
2807	1997-10-25	\N	\N	f	\N	\N	1	\N	261	2	2734	5	\N	1
2869	2009-06-29	\N	\N	f	\N	\N	1	\N	391	\N	2788	5	\N	1
2763	2015-10-27	\N	\N	f	\N	\N	1	\N	350	\N	2683	5	\N	1
2755	1815-08-11	\N	\N	f	Melbourne	1st Viscount 	7	\N	\N	\N	2700	5	3	11
2818	1841-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	2751	5	\N	6
2835	1859-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	2759	5	\N	6
2814	2010-06-27	\N	\N	f	\N	\N	2	\N	342	1	2742	5	\N	1
2775	1869-04-03	\N	\N	f	\N	\N	1	\N	\N	\N	2708	5	\N	6
2821	1876-10-16	\N	\N	f	\N	\N	1	\N	\N	\N	2754	5	\N	6
2845	1950-01-27	\N	\N	f	\N	\N	1	\N	73	\N	1182	5	\N	2
2833	1918-01-14	\N	\N	f	Northcliffe	1st Lord	1	\N	\N	\N	536	5	\N	4
2777	1891-01-21	\N	\N	f	\N	\N	1	\N	\N	\N	525	5	\N	6
2778	1892-02-22	\N	\N	f	\N	\N	1	\N	\N	\N	2709	5	\N	6
2776	1924-06-23	\N	\N	f	Willingdon	1st Lord	1	\N	16	\N	819	5	\N	4
2857	1917-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	2780	5	\N	4
2842	1927-01-31	\N	\N	f	Sumner	Lord	1	\N	21	\N	610	5	\N	4
2788	1941-01-20	\N	\N	f	Camrose	1st Lord	1	\N	51	\N	787	5	\N	2
2815	2011-01-15	\N	\N	f	\N	\N	1	\N	356	2	2744	5	\N	1
2836	1885-12-30	\N	\N	f	Elphinstone	15th Lord 	1	\N	\N	\N	2760	5	2	6
2786	1933-01-17	\N	\N	f	\N	\N	1	\N	34	\N	2715	5	\N	4
2837	1940-10-21	\N	\N	f	\N	\N	1	\N	\N	\N	2761	5	\N	2
2861	1946-08-23	\N	\N	f	\N	\N	1	\N	66	\N	1009	5	\N	2
2858	1964-12-21	\N	\N	f	\N	\N	2	\N	115	1	2771	5	\N	1
2817	1948-02-26	\N	\N	f	\N	\N	1	\N	69	\N	2748	5	\N	2
2791	1954-10-04	\N	\N	f	\N	\N	1	\N	\N	\N	2719	5	\N	1
2748	2020-09-08	\N	\N	f	\N	\N	1	\N	380	2	2691	5	\N	1
2793	1959-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	2721	5	\N	1
2854	1975-01-09	\N	\N	f	\N	\N	1	\N	166	\N	2777	5	\N	1
2794	1967-12-05	\N	\N	f	\N	\N	1	\N	127	\N	2722	5	\N	1
2859	1970-10-14	\N	\N	f	\N	\N	1	\N	140	\N	2774	5	\N	1
2795	1974-09-02	\N	\N	f	\N	\N	1	\N	162	\N	2723	5	\N	1
2853	1975-01-10	\N	\N	f	\N	\N	1	\N	166	\N	2776	5	\N	1
2839	1975-02-03	\N	\N	f	\N	\N	1	\N	167	\N	2763	5	\N	1
2864	1980-09-01	\N	\N	f	\N	\N	1	\N	188	\N	2781	5	\N	1
2866	1987-10-16	\N	\N	f	\N	\N	1	\N	211	\N	2783	5	\N	1
2803	1990-05-08	\N	\N	f	\N	\N	1	\N	218	\N	2729	5	\N	1
2805	1992-10-01	\N	\N	f	\N	\N	1	\N	233	\N	2732	5	\N	1
2829	2015-10-02	\N	\N	f	\N	\N	2	\N	350	1	2745	5	\N	1
2978	1976-01-26	\N	\N	f	\N	\N	1	\N	170	\N	1454	5	\N	1
2961	2000-05-02	\N	\N	f	\N	\N	1	\N	274	2	2033	5	\N	1
2886	1994-10-03	\N	\N	f	\N	\N	1	\N	240	\N	2805	5	\N	1
2972	1982-07-14	\N	\N	f	\N	\N	1	\N	194	\N	1568	5	\N	1
2896	2001-07-30	\N	\N	f	\N	\N	1	\N	280	\N	2811	5	\N	1
2882	1967-02-06	\N	\N	f	\N	\N	1	\N	123	\N	2800	5	\N	1
2885	1992-08-25	\N	\N	f	\N	\N	1	\N	230	\N	2804	5	\N	1
2884	1971-02-09	\N	\N	f	\N	\N	1	\N	141	\N	2802	5	\N	1
1984	1997-11-04	\N	\N	f	\N	\N	1	\N	261	2	1904	5	\N	1
2966	1990-05-21	\N	\N	f	\N	\N	1	\N	218	\N	1692	5	\N	1
2001	1998-08-01	\N	\N	f	\N	\N	1	\N	265	2	1939	5	\N	1
2877	1929-08-31	\N	\N	f	\N	\N	1	\N	27	\N	899	5	\N	4
2921	1937-06-02	\N	\N	t	Bessborough	9th Earl 	1	\N	44	\N	2837	5	3	2
2906	1999-11-16	\N	\N	t	Longford	7th Earl 	4	\N	272	10	966	5	3	1
2880	1953-02-13	\N	\N	f	\N	\N	1	\N	80	\N	2797	5	\N	1
2920	1876-08-21	\N	\N	f	\N	\N	1	\N	\N	\N	2836	5	\N	6
2968	2015-10-09	\N	\N	f	\N	\N	2	\N	350	1	2370	5	\N	1
2037	1999-07-23	\N	\N	f	\N	\N	2	\N	270	1	1970	5	\N	1
2888	1997-07-18	\N	\N	f	\N	\N	1	\N	259	\N	2807	5	\N	1
2970	2006-06-13	\N	\N	f	\N	\N	1	\N	311	2	2787	5	\N	1
2990	2015-10-08	\N	\N	f	\N	\N	2	\N	350	1	2409	5	\N	1
2911	2011-05-26	\N	\N	f	\N	\N	1	\N	358	\N	2829	5	\N	1
2878	1936-01-17	\N	\N	f	Hanworth	1st Lord	1	\N	41	\N	753	5	\N	4
2900	2015-09-29	\N	\N	f	\N	\N	1	\N	350	2	2817	5	\N	1
2879	1941-07-04	\N	\N	f	\N	\N	1	\N	52	\N	1089	5	\N	2
2994	1947-10-18	\N	\N	f	Mountbatten of Burma	1st Viscount	1	\N	\N	\N	1009	5	\N	2
2917	1937-03-08	\N	\N	f	\N	\N	1	\N	\N	\N	604	5	\N	2
2895	1945-09-17	\N	\N	f	\N	\N	1	\N	64	\N	975	5	\N	2
2977	1958-09-26	\N	\N	f	\N	\N	1	\N	285	\N	1116	5	\N	1
2967	1964-12-07	\N	\N	f	\N	\N	2	\N	114	\N	1214	5	\N	1
2962	1967-09-15	\N	\N	f	\N	\N	1	\N	125	\N	1294	5	\N	1
2986	1970-11-05	\N	\N	f	\N	\N	1	\N	140	\N	1345	5	\N	1
2981	1994-09-29	\N	\N	f	\N	\N	1	\N	241	\N	1786	5	\N	1
2907	1997-01-06	\N	\N	f	\N	\N	1	\N	254	\N	2823	5	\N	1
2964	2005-06-24	\N	\N	f	\N	\N	1	\N	304	2	2662	5	\N	1
2018	1997-10-27	\N	\N	f	\N	\N	2	\N	261	1	1934	5	\N	1
2028	1999-07-16	\N	\N	f	\N	\N	1	\N	270	2	1961	5	\N	1
2923	2014-09-16	\N	\N	f	\N	\N	1	\N	360	2	2819	5	\N	1
2965	2018-07-09	\N	\N	f	\N	\N	1	\N	370	\N	2520	5	\N	1
2902	2020-01-07	\N	\N	f	\N	\N	1	\N	377	\N	2821	5	\N	1
2984	1965-12-07	\N	\N	f	\N	\N	1	\N	\N	\N	1261	5	\N	1
1	1801-01-20	\N	\N	t	Ormond and Ossory	18th Earl 	1	\N	\N	\N	1	5	3	11
2897	2004-01-13	\N	\N	f	\N	\N	1	\N	298	\N	2813	5	\N	1
2980	2004-06-02	\N	\N	f	\N	\N	1	\N	295	2	2812	5	\N	1
2958	2018-06-21	\N	\N	f	\N	\N	2	\N	364	1	2439	5	\N	1
2971	2007-03-30	\N	\N	f	\N	\N	1	\N	321	\N	2668	5	\N	1
2975	2005-10-05	\N	\N	f	\N	\N	1	\N	305	\N	2155	5	\N	1
2894	1965-05-17	\N	\N	f	\N	\N	1	\N	117	\N	2799	5	\N	1
2905	1962-01-29	\N	\N	f	\N	\N	1	\N	101	\N	2003	5	\N	1
2969	1962-04-12	\N	\N	f	\N	\N	1	\N	102	\N	1167	5	\N	1
2087	2000-05-11	\N	\N	f	\N	\N	2	\N	274	1	2025	5	\N	1
2887	1997-06-11	\N	\N	f	\N	\N	1	\N	256	2	2806	5	\N	1
2919	1892-08-23	\N	\N	f	Willoughby de Eresby	24th Lord	1	\N	\N	\N	2834	5	\N	6
2995	1860-03-22	\N	\N	f	Brougham and Vaux	1st Lord	1	\N	\N	\N	136	5	\N	6
2922	1831-09-10	\N	\N	f	\N	\N	2	\N	\N	\N	2838	5	\N	7
2892	2013-09-19	\N	\N	f	\N	\N	2	\N	318	1	2792	5	\N	1
2912	1833-01-29	\N	\N	t	Cleveland	1st Marquess	1	\N	\N	\N	155	5	\N	7
2069	1999-11-16	\N	\N	f	Aldington	1st Lord	1	\N	272	4	2003	5	\N	1
2991	1928-05-08	\N	\N	f	\N	\N	1	\N	\N	\N	772	5	\N	4
2918	1920-06-03	\N	\N	f	\N	\N	1	\N	7	\N	2833	5	\N	4
2908	1881-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2826	5	\N	6
2875	1938-01-27	\N	\N	f	\N	\N	1	\N	46	\N	2795	5	\N	2
2899	2006-06-30	\N	\N	f	\N	\N	1	\N	340	\N	2816	5	\N	1
2985	1991-02-07	\N	\N	f	\N	\N	1	\N	221	\N	2730	5	\N	1
18	1814-06-01	\N	\N	f	Keith	1st Lord	1	\N	\N	\N	21	5	\N	11
28	1801-06-23	\N	\N	f	Pelham	2nd Lord	1	\N	\N	\N	32	5	\N	11
2891	1999-11-17	\N	\N	f	Jellicoe	2nd Earl	1	\N	272	3	2810	5	\N	1
2925	2013-09-20	\N	\N	f	\N	\N	1	\N	318	2	2820	5	\N	1
1992	1998-07-25	\N	\N	f	\N	\N	1	\N	265	2	1928	5	\N	1
2890	1998-08-05	\N	\N	f	\N	\N	1	\N	265	\N	2809	5	\N	1
2883	1969-10-28	\N	\N	f	\N	\N	1	\N	135	\N	2801	5	\N	1
2989	1990-02-27	\N	\N	f	\N	\N	1	\N	217	\N	2634	5	\N	1
2987	1997-11-01	\N	\N	f	\N	\N	2	\N	261	1	1902	5	\N	1
2959	2019-10-07	\N	\N	f	\N	\N	1	\N	374	2	2688	5	\N	1
2973	1990-07-16	\N	\N	f	\N	\N	2	\N	219	1	1738	5	\N	1
2903	1964-12-19	\N	\N	f	\N	\N	1	\N	114	\N	2004	5	\N	1
2874	1999-07-19	\N	\N	f	\N	\N	1	\N	268	2	2794	5	\N	1
2881	1964-06-29	\N	\N	f	\N	\N	1	\N	111	\N	2798	5	\N	1
2045	1999-08-04	\N	\N	f	\N	\N	2	\N	270	1	1985	5	\N	1
2901	2011-01-15	\N	\N	f	\N	\N	2	\N	356	1	2818	5	\N	1
2963	1987-03-18	\N	\N	f	\N	\N	1	\N	208	\N	1639	5	\N	1
2057	1999-08-06	\N	\N	f	\N	\N	2	\N	270	1	1989	5	\N	1
2982	1981-06-19	\N	\N	f	\N	\N	1	\N	190	\N	2803	5	\N	1
2979	1974-07-11	\N	\N	f	\N	\N	1	\N	161	\N	1414	5	\N	1
33	1801-06-26	\N	\N	f	Grey de Wilton	1st Lord	1	\N	\N	\N	38	5	\N	11
2926	1803-10-26	\N	\N	f	Bath	1st Baroness	1	\N	\N	\N	2824	5	\N	11
2924	2005-06-21	\N	\N	f	\N	\N	1	\N	304	2	2814	5	\N	1
2893	1997-11-03	\N	\N	f	\N	\N	2	\N	261	1	2785	5	\N	1
2909	1892-04-07	\N	\N	t	Argyll	8th Duke 	1	\N	\N	\N	2827	5	2	6
2992	1801-08-18	\N	\N	f	Nelson	1st Viscount	1	\N	\N	\N	3	5	\N	11
62	1814-07-16	\N	\N	f	Cathcart	1st Viscount	1	\N	\N	\N	47	5	\N	11
2993	1816-01-16	\N	\N	f	Hill	1st Lord	1	\N	\N	\N	55	5	\N	11
2106	1999-11-16	\N	\N	f	Windlesham	3rd Lord	6	\N	272	7	2042	5	\N	1
2097	2000-05-16	\N	\N	f	\N	\N	1	\N	274	2	2030	5	\N	1
2132	2001-06-28	\N	\N	f	\N	\N	1	\N	278	2	2049	5	\N	1
2983	2001-07-13	\N	\N	f	\N	\N	1	\N	280	\N	2070	5	\N	1
2974	1978-04-28	\N	\N	f	\N	\N	1	\N	180	\N	1493	5	\N	1
201	1833-03-23	\N	\N	f	Durham	1st Lord	1	\N	\N	\N	132	5	\N	7
133	1827-04-28	\N	\N	t	Fife	4th Earl 	2	\N	\N	\N	122	5	3	8
90	1821-07-17	\N	\N	f	Somers	2nd Lord	2	\N	\N	\N	82	5	\N	8
227	1841-08-17	\N	\N	t	Kenmare	2nd Earl 	2	\N	\N	\N	214	5	3	6
163	1827-10-05	\N	\N	f	Dudley and Ward	4th Viscount	2	\N	\N	\N	153	5	\N	8
214	1839-05-08	\N	\N	f	Talbot de Malahide	2nd Lord 	1	\N	\N	\N	200	5	3	6
177	1833-05-10	\N	\N	f	Granville	1st Viscount	1	\N	\N	\N	165	5	\N	7
271	1858-08-14	\N	\N	t	Seafield	7th Earl 	1	\N	\N	\N	254	5	2	6
211	1838-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	197	5	\N	6
285	1850-01-17	\N	\N	t	Wales	Prince	1	\N	282	\N	233	5	\N	6
224	1839-12-23	\N	\N	f	\N	\N	1	\N	\N	\N	210	5	\N	6
236	1849-06-15	\N	\N	f	Gough	1st Lord	1	\N	\N	\N	224	5	\N	6
295	1866-05-01	\N	\N	t	Caithness	14th Earl 	1	\N	\N	\N	276	5	2	6
354	1875-06-11	\N	\N	t	Home	11th Earl 	1	\N	\N	\N	333	5	2	6
254	1851-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	238	5	\N	6
259	1856-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	243	5	\N	6
269	1858-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	252	5	\N	6
311	1859-05-21	\N	\N	f	Canning	2nd Viscount	1	\N	\N	\N	292	5	\N	6
323	1866-07-12	\N	\N	f	Cremorne	3rd Lord 	1	\N	\N	\N	222	5	3	6
280	1859-08-18	\N	\N	f	\N	\N	1	\N	\N	\N	262	5	\N	6
292	1866-01-03	\N	\N	f	\N	\N	1	\N	\N	\N	273	5	\N	6
316	1869-06-29	\N	\N	f	Rollo	10th Lord 	1	\N	\N	\N	298	5	2	6
408	1884-11-07	\N	\N	t	Arran	5th Earl 	1	\N	\N	\N	384	5	3	6
306	1867-02-27	\N	\N	f	\N	\N	1	\N	\N	\N	287	5	\N	6
471	1889-07-29	\N	\N	t	Fife	6th Earl 	1	\N	\N	\N	450	5	3	6
332	1871-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	311	5	\N	6
338	1872-10-23	\N	\N	f	\N	\N	1	\N	\N	\N	318	5	\N	6
344	1873-08-23	\N	\N	f	\N	\N	1	\N	\N	\N	323	5	\N	6
409	1884-11-08	\N	\N	f	de Vesci	4th Viscount 	1	\N	\N	\N	385	5	3	6
365	1876-01-14	\N	\N	f	\N	\N	2	\N	\N	\N	337	5	\N	6
370	1876-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	349	5	\N	6
376	1880-04-30	\N	\N	f	\N	\N	1	\N	\N	\N	356	5	\N	6
382	1880-05-06	\N	\N	f	\N	\N	1	\N	\N	\N	362	5	\N	6
438	1886-09-09	\N	\N	f	Hawarden	4th Viscount 	1	\N	\N	\N	415	5	3	6
394	1882-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	374	5	\N	6
406	1884-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	382	5	\N	6
507	1896-06-17	\N	\N	t	Rutland	7th Duke	1	\N	\N	\N	479	5	\N	6
692	1917-05-07	\N	\N	f	Valentia	11th Viscount 	1	\N	\N	\N	651	5	3	4
417	1885-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	393	5	\N	6
422	1885-07-24	\N	\N	f	\N	\N	1	\N	\N	\N	398	5	\N	6
433	1886-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	410	5	\N	6
94	1821-07-17	\N	\N	t	Wemyss and March	8th & 4th Earl 	6	\N	\N	\N	87	5	2	8
454	1888-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	428	5	\N	6
478	1888-10-27	\N	\N	f	\N	\N	1	\N	\N	\N	429	5	\N	6
521	1898-01-19	\N	\N	f	Halsbury	1st Lord	1	\N	\N	\N	387	5	\N	6
466	1892-08-25	\N	\N	f	\N	\N	1	\N	\N	\N	444	5	\N	6
483	1892-09-05	\N	\N	f	\N	\N	1	\N	\N	\N	456	5	\N	6
488	1893-08-21	\N	\N	f	\N	\N	1	\N	\N	\N	461	5	\N	6
493	1894-08-13	\N	\N	f	\N	\N	1	\N	\N	\N	466	5	\N	6
498	1895-07-25	\N	\N	f	\N	\N	1	\N	\N	\N	471	5	\N	6
503	1895-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	475	5	\N	6
541	1896-06-08	\N	\N	f	\N	\N	1	\N	\N	\N	511	5	\N	6
534	1900-06-15	\N	\N	f	Morris	Lord	1	\N	\N	\N	503	5	\N	6
516	1897-07-28	\N	\N	f	\N	\N	1	\N	\N	\N	488	5	\N	6
627	1911-07-04	\N	\N	f	Knollys	1st Lord	2	\N	\N	\N	517	5	\N	4
530	1899-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	499	5	\N	6
546	1902-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	515	5	\N	5
551	1903-08-03	\N	\N	f	\N	\N	1	\N	\N	\N	520	5	\N	5
568	1905-12-26	\N	\N	f	\N	\N	1	\N	\N	\N	535	5	\N	5
573	1905-12-30	\N	\N	f	\N	\N	1	\N	\N	\N	540	5	\N	5
578	1906-01-09	\N	\N	f	\N	\N	1	\N	283	\N	545	5	\N	5
584	1906-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	551	5	\N	5
589	1907-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	556	5	\N	5
594	1908-05-22	\N	\N	f	\N	\N	1	\N	\N	\N	561	5	\N	5
607	1910-07-13	\N	\N	f	\N	\N	1	\N	\N	\N	573	5	\N	4
612	1910-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	578	5	\N	4
617	1911-04-03	\N	\N	f	\N	\N	1	\N	\N	\N	583	5	\N	4
622	1911-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	588	5	\N	4
700	1915-02-22	\N	\N	f	St Aldwyn	1st Viscount	1	\N	\N	\N	541	5	\N	4
660	1912-02-07	\N	\N	f	\N	\N	1	\N	2	\N	622	5	\N	4
643	1912-12-10	\N	\N	f	\N	\N	1	\N	\N	\N	606	5	\N	4
682	1917-01-01	\N	\N	f	Sandhurst	2nd Lord	1	\N	\N	\N	642	5	\N	4
655	1914-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	617	5	\N	4
122	1821-07-17	\N	\N	t	Ormonde and Ossory	19th Earl 	5	\N	\N	\N	86	5	3	8
665	1915-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	627	5	\N	4
671	1916-01-26	\N	\N	f	\N	\N	1	\N	\N	\N	632	5	\N	4
703	1918-01-16	\N	\N	f	Furness	2nd Lord	1	\N	\N	\N	660	5	\N	4
689	1917-01-05	\N	\N	f	\N	\N	1	\N	\N	\N	648	5	\N	4
720	1918-06-19	\N	\N	f	Rhondda	1st Lord	1	\N	3	\N	634	5	\N	4
732	1919-05-17	\N	\N	f	Rothermere	1st Lord	1	\N	4	\N	614	5	\N	4
840	1929-05-07	\N	\N	f	Shaw	Lord	1	\N	\N	\N	784	5	\N	4
728	1919-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	681	5	\N	4
877	1931-02-20	\N	\N	f	Willingdon	1st Viscount	1	\N	\N	\N	819	5	\N	4
744	1919-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	695	5	\N	4
751	1921-01-15	\N	\N	f	\N	\N	1	\N	8	\N	701	5	\N	4
760	1921-04-28	\N	\N	f	\N	\N	1	\N	\N	\N	708	5	\N	4
765	1921-06-15	\N	\N	f	\N	\N	2	\N	9	\N	713	5	\N	4
774	1922-01-24	\N	\N	f	\N	\N	1	\N	10	\N	720	5	\N	4
782	1922-11-21	\N	\N	f	\N	\N	1	\N	\N	\N	728	5	\N	4
788	1923-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	732	5	\N	4
817	1927-01-20	\N	\N	f	\N	\N	1	\N	21	\N	760	5	\N	4
827	1928-06-15	\N	\N	f	\N	\N	1	\N	24	\N	770	5	\N	4
835	1929-03-20	\N	\N	f	\N	\N	1	\N	25	\N	779	5	\N	4
846	1929-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	789	5	\N	4
890	1929-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	831	5	\N	4
855	1930-01-18	\N	\N	f	\N	\N	1	\N	28	\N	798	5	\N	4
81	1815-07-04	\N	\N	t	Uxbridge	2nd Earl	1	\N	\N	\N	75	5	\N	11
193	1831-09-10	\N	\N	f	Belhaven and Stenton	8th Lord 	7	\N	\N	\N	183	5	2	7
1966	1997-10-29	\N	\N	f	\N	\N	2	\N	260	1	1898	5	\N	1
2009	1998-10-01	\N	\N	f	\N	\N	1	\N	\N	2	1948	5	\N	1
1951	1997-10-06	\N	\N	f	\N	\N	2	\N	261	1	1882	5	\N	1
2020	1999-02-25	\N	\N	f	\N	\N	1	\N	267	\N	1950	5	\N	1
2098	2000-05-16	\N	\N	f	\N	\N	2	\N	274	1	2031	5	\N	1
2065	2000-06-12	\N	\N	f	\N	\N	1	\N	274	\N	1998	5	\N	1
2223	2004-07-01	\N	\N	f	\N	\N	2	\N	295	1	2161	5	\N	1
2068	2000-10-20	\N	\N	f	\N	\N	1	\N	274	\N	2001	5	\N	1
2126	2001-07-12	\N	\N	f	\N	\N	1	\N	280	\N	2064	5	\N	1
2186	2005-04-06	\N	\N	f	\N	\N	1	\N	301	\N	2124	5	\N	1
2266	2007-03-28	\N	\N	f	\N	\N	1	\N	321	\N	2209	5	\N	1
2238	2006-06-13	\N	\N	f	\N	\N	2	\N	311	1	2180	5	\N	1
2373	2010-07-21	\N	\N	f	\N	\N	2	\N	342	1	2306	5	\N	1
2322	2010-07-08	\N	\N	f	\N	\N	1	\N	342	2	2272	5	\N	1
2418	2010-12-24	\N	\N	f	\N	\N	1	\N	356	2	2325	5	\N	1
2360	2010-07-22	\N	\N	f	\N	\N	1	\N	352	2	2307	5	\N	1
2481	2013-09-12	\N	\N	f	\N	\N	2	\N	318	1	2430	5	\N	1
2388	2011-01-11	\N	\N	f	\N	\N	2	\N	356	1	2329	5	\N	1
2463	2015-10-01	\N	\N	f	\N	\N	3	\N	350	6	2382	5	\N	1
2448	2014-09-17	\N	\N	f	\N	\N	2	\N	360	1	2402	5	\N	1
919	1936-01-31	\N	\N	f	Trenchard	1st Lord	1	\N	41	\N	801	5	\N	3
1904	1996-10-07	\N	\N	f	\N	\N	1	\N	253	\N	1826	5	\N	1
1936	1997-09-27	\N	\N	f	\N	\N	2	\N	261	1	1869	5	\N	1
916	1935-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	855	5	\N	4
951	1938-06-25	\N	\N	f	Weir	1st Lord	1	\N	47	\N	666	5	\N	2
942	1937-06-11	\N	\N	f	\N	\N	2	\N	44	\N	880	5	\N	2
975	1940-10-28	\N	\N	f	Hewart	1st Lord	1	\N	\N	\N	756	5	\N	2
1003	1939-07-08	\N	\N	f	\N	\N	1	\N	49	\N	936	5	\N	2
986	1941-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	918	5	\N	2
995	1942-04-27	\N	\N	f	\N	\N	2	\N	\N	\N	927	5	\N	2
1010	1944-10-13	\N	\N	f	\N	\N	1	\N	\N	\N	942	5	\N	2
1023	1945-07-14	\N	\N	f	\N	\N	1	\N	62	\N	955	5	\N	2
1154	1954-10-18	\N	\N	f	Simonds	1st Lord	1	\N	\N	\N	939	5	\N	1
1043	1945-11-17	\N	\N	f	\N	\N	1	\N	\N	\N	972	5	\N	2
1078	1946-01-23	\N	\N	f	\N	\N	1	\N	65	\N	1004	5	\N	2
1068	1947-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	995	5	\N	2
1193	1956-01-09	\N	\N	f	Woolton	1st Viscount	1	\N	\N	\N	934	5	\N	1
1087	1948-06-22	\N	\N	f	\N	\N	1	\N	70	\N	1013	5	\N	2
1098	1950-01-31	\N	\N	f	\N	\N	1	\N	73	\N	1024	5	\N	2
1109	1950-07-10	\N	\N	f	\N	\N	1	\N	74	\N	1035	5	\N	2
1112	1950-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	1038	5	\N	2
1113	1951-02-07	\N	\N	f	\N	\N	1	\N	75	\N	1039	5	\N	2
1164	1956-01-12	\N	\N	f	De L'Isle and Dudley	6th Lord	1	\N	\N	\N	1082	5	\N	1
1171	1956-06-26	\N	\N	f	Cherwell	1st Lord	1	\N	87	\N	1089	5	\N	1
1264	1963-01-30	\N	\N	f	Alexander of Hillsborough	1st Viscount	1	\N	104	\N	1182	5	\N	1
1182	1958-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	1100	5	\N	1
1512	1975-01-24	\N	\N	f	Balniel	Lord	1	\N	166	\N	1433	5	\N	1
1208	1959-08-20	\N	\N	f	\N	\N	1	\N	94	\N	1128	5	\N	1
1220	1960-07-15	\N	\N	f	\N	\N	1	\N	97	\N	1141	5	\N	1
1226	1960-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	1147	5	\N	1
1246	1962-01-26	\N	\N	f	\N	\N	1	\N	101	\N	1164	5	\N	1
1257	1962-06-15	\N	\N	f	\N	\N	1	\N	103	\N	1176	5	\N	1
1311	1964-01-13	\N	\N	f	Davidson	Viscountess	1	\N	107	\N	1225	5	\N	1
1279	1964-01-18	\N	\N	f	\N	\N	1	\N	107	\N	1194	5	\N	1
1294	1964-09-17	\N	\N	f	\N	\N	1	\N	113	\N	1210	5	\N	1
1340	1965-07-07	\N	\N	f	\N	\N	1	\N	119	\N	1256	5	\N	1
1981	1997-10-06	\N	\N	f	\N	\N	1	\N	261	2	1881	5	\N	1
1385	1966-06-02	\N	\N	f	\N	\N	1	\N	121	\N	1305	5	\N	1
1355	1966-06-16	\N	\N	f	\N	\N	1	\N	121	\N	1271	5	\N	1
1370	1967-08-26	\N	\N	f	\N	\N	1	\N	125	\N	1288	5	\N	1
1386	1968-01-22	\N	\N	f	\N	\N	1	\N	128	\N	1306	5	\N	1
1411	1970-06-20	\N	\N	f	\N	\N	1	\N	137	\N	1329	5	\N	1
1426	1971-01-29	\N	\N	f	\N	\N	1	\N	141	\N	1347	5	\N	1
1439	1971-06-18	\N	\N	f	\N	\N	1	\N	145	\N	1360	5	\N	1
1454	1973-06-22	\N	\N	f	\N	\N	1	\N	153	\N	1377	5	\N	1
1484	1974-07-01	\N	\N	f	\N	\N	1	\N	161	\N	1407	5	\N	1
1549	1975-01-27	\N	\N	f	\N	\N	1	\N	166	\N	1434	5	\N	1
1521	1975-07-16	\N	\N	f	\N	\N	1	\N	168	\N	1443	5	\N	1
1563	1978-02-09	\N	\N	f	\N	\N	1	\N	179	\N	1484	5	\N	1
1577	1978-05-19	\N	\N	f	\N	\N	1	\N	180	\N	1500	5	\N	1
1592	1979-07-06	\N	\N	f	\N	\N	1	\N	186	\N	1514	5	\N	1
1607	1979-09-28	\N	\N	f	\N	\N	1	\N	\N	\N	1533	5	\N	1
1618	1981-02-16	\N	\N	f	\N	\N	1	\N	189	\N	1545	5	\N	1
1657	1983-06-30	\N	\N	f	\N	\N	1	\N	199	\N	1584	5	\N	1
1665	1983-09-09	\N	\N	f	\N	\N	1	\N	200	\N	1592	5	\N	1
1680	1983-10-07	\N	\N	f	\N	\N	1	\N	200	\N	1604	5	\N	1
1691	1985-05-09	\N	\N	f	\N	\N	1	\N	203	\N	1616	5	\N	1
1704	1986-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	1631	5	\N	1
1728	1987-10-09	\N	\N	f	\N	\N	1	\N	211	\N	1654	5	\N	1
1767	1987-10-20	\N	\N	f	\N	\N	1	\N	211	\N	1698	5	\N	1
1743	1988-02-26	\N	\N	f	\N	\N	1	\N	212	\N	1670	5	\N	1
1754	1989-07-21	\N	\N	f	\N	\N	1	\N	216	\N	1680	5	\N	1
1799	1992-02-14	\N	\N	f	\N	\N	1	\N	226	\N	1730	5	\N	1
1814	1992-07-10	\N	\N	f	\N	\N	1	\N	230	\N	1748	5	\N	1
1829	1992-07-27	\N	\N	f	\N	\N	1	\N	232	\N	1756	5	\N	1
1844	1993-10-11	\N	\N	f	\N	\N	1	\N	237	\N	1774	5	\N	1
1874	1995-12-19	\N	\N	f	\N	\N	1	\N	247	\N	1804	5	\N	1
1889	1996-10-01	\N	\N	f	\N	\N	2	\N	253	1	1823	5	\N	1
1917	1997-06-06	\N	\N	f	\N	\N	2	\N	256	1	1848	5	\N	1
2035	1999-07-22	\N	\N	f	\N	\N	2	\N	270	1	1968	5	\N	1
2141	2002-11-18	\N	\N	f	\N	\N	1	\N	291	\N	2076	5	\N	1
2171	2004-06-09	\N	\N	f	\N	\N	2	\N	295	1	2093	5	\N	1
2199	2005-06-22	\N	\N	f	\N	\N	2	\N	304	1	2141	5	\N	1
2251	2006-06-05	\N	\N	f	\N	\N	2	\N	310	1	2170	5	\N	1
2279	2008-10-15	\N	\N	f	\N	\N	1	\N	331	\N	2228	5	\N	1
2345	2010-05-28	\N	\N	f	\N	\N	1	\N	347	\N	2285	5	\N	1
899	1934-06-28	\N	\N	f	Wakefield	1st Lord	1	\N	37	\N	799	5	\N	4
2616	2021-02-01	\N	\N	f	\N	\N	1	\N	383	2	2547	5	\N	1
2953	1997-09-24	\N	\N	f	\N	\N	1	\N	261	2	1863	5	\N	1
2193	2005-06-16	\N	\N	f	\N	\N	2	\N	304	1	2134	5	\N	1
2608	1857-10-01	\N	\N	t	Fife	5th Earl 	1	\N	\N	\N	2560	5	3	6
2954	2000-05-09	\N	\N	f	\N	\N	2	\N	274	1	2021	5	\N	1
2565	2018-06-25	\N	\N	f	\N	\N	1	\N	364	\N	2519	5	\N	1
2731	2006-05-31	\N	\N	f	\N	\N	1	\N	310	2	2664	5	\N	1
2889	1998-02-14	\N	\N	f	\N	\N	1	\N	263	\N	2808	5	\N	1
2340	2010-06-20	\N	\N	f	\N	\N	2	\N	342	1	2253	5	\N	1
2152	2004-06-07	\N	\N	f	\N	\N	1	\N	295	2	2089	5	\N	1
2840	2000-04-17	\N	\N	f	Grenfell	3rd Lord	2	\N	274	1	2765	5	\N	1
2916	1814-05-11	\N	\N	t	Wellington	1st Marquess	1	\N	\N	\N	49	5	\N	11
2172	2004-06-17	\N	\N	f	\N	\N	1	\N	296	2	2103	5	\N	1
2180	2004-06-29	\N	\N	f	\N	\N	1	\N	296	2	2118	5	\N	1
2725	2004-07-01	\N	\N	f	\N	\N	1	\N	296	2	2661	5	\N	1
2200	2005-06-23	\N	\N	f	\N	\N	2	\N	304	1	2143	5	\N	1
2949	2005-06-28	\N	\N	f	\N	\N	2	\N	304	1	2148	5	\N	1
2237	2006-06-12	\N	\N	f	\N	\N	2	\N	310	1	2179	5	\N	1
2950	2007-12-11	\N	\N	f	\N	\N	1	\N	326	\N	2221	5	\N	1
2229	2006-06-06	\N	\N	f	\N	\N	1	\N	310	2	2171	5	\N	1
2480	2013-09-12	\N	\N	f	\N	\N	1	\N	318	2	2429	5	\N	1
2337	2010-06-25	\N	\N	f	\N	\N	2	\N	342	1	2262	5	\N	1
2354	2010-07-13	\N	\N	f	\N	\N	2	\N	342	1	2295	5	\N	1
2330	2010-06-26	\N	\N	f	\N	\N	2	\N	342	1	2264	5	\N	1
2311	2010-06-21	\N	\N	f	\N	\N	1	\N	342	2	2254	5	\N	1
2377	2010-07-14	\N	\N	f	\N	\N	2	\N	342	1	2297	5	\N	1
2740	2010-12-20	\N	\N	f	\N	\N	2	\N	356	1	2675	5	\N	1
2368	2010-12-17	\N	\N	f	\N	\N	2	\N	356	1	2315	5	\N	1
2498	2015-10-08	\N	\N	f	\N	\N	1	\N	350	2	2408	5	\N	1
2404	2011-01-28	\N	\N	f	\N	\N	2	\N	357	1	2353	5	\N	1
2415	2011-02-04	\N	\N	f	\N	\N	2	\N	356	1	2360	5	\N	1
2451	2015-10-14	\N	\N	f	\N	\N	2	\N	350	1	2376	5	\N	1
2468	2015-10-26	\N	\N	f	\N	\N	1	\N	350	2	2411	5	\N	1
2459	2015-10-15	\N	\N	f	\N	\N	1	\N	350	2	2377	5	\N	1
2441	2015-10-20	\N	\N	f	\N	\N	1	\N	350	2	2389	5	\N	1
2473	2016-08-31	\N	\N	f	\N	\N	1	\N	363	2	2421	5	\N	1
2535	2016-09-06	\N	\N	f	\N	\N	2	\N	363	1	2451	5	\N	1
2489	2013-10-02	\N	\N	f	\N	\N	2	\N	318	1	2442	5	\N	1
2511	2014-02-24	\N	\N	f	\N	\N	1	\N	369	\N	2460	5	\N	1
2432	2015-10-14	\N	\N	f	\N	\N	1	\N	350	2	2375	5	\N	1
2526	2019-10-11	\N	\N	f	\N	\N	1	\N	374	2	2483	5	\N	1
2537	2017-10-19	\N	\N	f	\N	\N	1	\N	367	2	2457	5	\N	1
2580	2020-09-09	\N	\N	f	\N	\N	1	\N	381	2	2509	5	\N	1
2572	2020-09-18	\N	\N	f	\N	\N	2	\N	380	1	2527	5	\N	1
2617	2020-10-30	\N	\N	f	\N	\N	1	\N	381	\N	2555	5	\N	1
2684	1974-01-31	\N	\N	f	\N	\N	1	\N	155	\N	2615	5	\N	1
2957	1999-08-02	\N	\N	f	\N	\N	2	\N	270	1	1981	5	\N	1
2255	2006-06-01	\N	\N	f	\N	\N	1	\N	310	2	2165	5	\N	1
2395	2011-01-18	\N	\N	f	\N	\N	2	\N	356	1	2337	5	\N	1
2955	1996-10-14	\N	\N	f	\N	\N	1	\N	253	\N	1830	5	\N	1
2759	2019-10-15	\N	\N	f	\N	\N	2	\N	374	1	2690	5	\N	1
2513	2017-11-07	\N	\N	f	\N	\N	1	\N	368	2	2462	5	\N	1
2948	1815-11-22	\N	\N	t	Cholmondeley	4th Earl	1	\N	\N	\N	2845	5	\N	11
2934	1885-07-13	\N	\N	t	Fife	6th Earl 	1	\N	\N	\N	450	5	3	6
2930	1831-09-12	\N	\N	f	Duncan	2nd Viscount	2	\N	\N	\N	2839	5	\N	7
2943	1833-04-13	\N	\N	f	Goderich	1st Viscount	1	\N	\N	\N	121	5	\N	7
2933	1844-10-22	\N	\N	f	Ellenborough	2nd Lord	1	\N	\N	\N	2840	5	\N	6
2931	1850-06-11	\N	\N	f	Cottenham	1st Lord	1	\N	\N	\N	178	5	\N	6
2606	1845-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	2558	5	\N	6
2929	1861-10-21	\N	\N	t	Sutherland	Duchess	1	\N	\N	\N	2825	5	\N	6
2927	1899-10-16	\N	\N	t	Fife	1st Duke	1	\N	\N	\N	450	5	\N	6
2941	1874-04-02	\N	\N	f	Ravensworth	2nd Lord	1	\N	\N	\N	2843	5	\N	6
2938	1880-05-03	\N	\N	f	Skelmersdale	2nd Lord	1	\N	\N	\N	2841	5	\N	6
2913	1874-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2830	5	\N	6
2785	1919-10-28	\N	\N	f	Ruthven of Freeland	9th Lord 	1	\N	\N	\N	2714	5	2	4
2932	1895-07-17	\N	\N	f	Houghton	2nd Lord	1	\N	\N	\N	602	5	\N	6
2665	1954-07-30	\N	\N	t	Dundee	11th Earl 	1	\N	83	\N	2596	5	2	1
2627	1897-08-23	\N	\N	f	\N	\N	1	\N	\N	\N	2570	5	\N	6
2939	1905-12-22	\N	\N	f	Hawkesbury	1st Lord	1	\N	\N	\N	2710	5	\N	5
2823	1902-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	2756	5	\N	5
2631	1911-07-05	\N	\N	f	Allendale	2nd Lord	2	\N	\N	\N	2574	5	\N	4
2639	1922-11-27	\N	\N	f	Leverhulme	1st Lord	1	\N	\N	\N	654	5	\N	4
2651	1919-05-16	\N	\N	f	\N	\N	2	\N	4	\N	2587	5	\N	4
2876	1919-10-09	\N	\N	f	\N	\N	1	\N	5	\N	2796	5	\N	4
2936	1944-07-11	\N	\N	f	Halifax	3rd Viscount	1	\N	59	\N	752	5	\N	2
2928	1922-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	2835	5	\N	4
2935	1945-01-08	\N	\N	f	Gowrie	1st Lord	1	\N	\N	\N	857	5	\N	2
2914	1934-10-12	\N	\N	f	\N	\N	1	\N	38	\N	2831	5	\N	4
2767	1809-02-03	\N	\N	t	Hopetoun	3rd Earl 	1	\N	\N	\N	2698	5	2	11
2946	1955-05-05	\N	\N	f	Swinton	1st Viscount	1	\N	\N	\N	855	5	\N	1
2660	1947-04-01	\N	\N	f	\N	\N	1	\N	67	\N	2592	5	\N	2
2809	2000-04-18	\N	\N	f	Berkeley	18th Lord	2	\N	274	1	2737	5	\N	1
2944	1961-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	2006	5	\N	1
2675	1964-12-17	\N	\N	f	\N	\N	1	\N	115	2	2606	5	\N	1
2855	1978-05-16	\N	\N	f	\N	\N	1	\N	180	\N	2778	5	\N	1
2562	2020-09-11	\N	\N	f	\N	\N	1	\N	380	2	2513	5	\N	1
2798	1980-07-22	\N	\N	f	\N	\N	1	\N	188	\N	2726	5	\N	1
2697	1983-02-11	\N	\N	f	\N	\N	1	\N	198	\N	2628	5	\N	1
2945	1984-02-24	\N	\N	f	\N	\N	1	\N	\N	\N	2844	5	\N	1
2804	1992-06-30	\N	\N	f	\N	\N	2	\N	230	1	2731	5	\N	1
2710	1997-06-12	\N	\N	f	\N	\N	1	\N	256	2	2643	5	\N	1
2718	1999-08-02	\N	\N	f	\N	\N	1	\N	270	2	2653	5	\N	1
2956	2010-06-18	\N	\N	f	\N	\N	3	\N	342	5	2249	5	\N	1
2952	2015-05-19	\N	\N	f	\N	\N	1	\N	345	\N	2283	5	\N	1
2915	2018-07-16	\N	\N	f	\N	\N	1	\N	371	\N	2832	5	\N	1
1931	1997-09-24	\N	\N	f	\N	\N	2	\N	261	1	1864	5	\N	1
2827	1999-07-21	\N	\N	f	\N	\N	2	\N	270	1	2736	5	\N	1
2211	2005-06-21	\N	\N	f	\N	\N	2	\N	304	1	2139	5	\N	1
2741	2010-12-24	\N	\N	f	\N	\N	2	\N	356	1	2676	5	\N	1
2496	2013-09-20	\N	\N	f	\N	\N	2	\N	318	1	2440	5	\N	1
2552	2020-09-01	\N	\N	f	\N	\N	2	\N	380	1	2498	5	\N	1
2424	2015-10-06	\N	\N	f	\N	\N	1	\N	350	2	2364	5	\N	1
2596	2021-01-27	\N	\N	f	\N	\N	2	\N	383	1	2542	5	\N	1
2403	2011-01-27	\N	\N	f	\N	\N	2	\N	356	1	2351	5	\N	1
120	1817-02-13	\N	\N	t	Moira	2nd Earl 	1	\N	\N	\N	114	5	3	11
22	1806-02-20	\N	\N	t	Sligo	1st Marquess 	1	\N	\N	\N	26	5	3	11
63	1814-07-16	\N	\N	t	Aberdeen	4th Earl 	2	\N	\N	\N	59	5	2	11
2754	1815-08-11	\N	\N	t	Dalhousie	9th Earl 	1	\N	\N	\N	2699	5	2	11
1328	1965-05-10	\N	\N	f	\N	\N	2	\N	118	1	1244	5	\N	1
1846	1992-06-29	\N	\N	f	\N	\N	2	\N	230	1	1776	5	\N	1
1914	1997-06-05	\N	\N	f	\N	\N	1	\N	256	2	1845	5	\N	1
1926	1997-07-21	\N	\N	f	\N	\N	1	\N	259	2	1857	5	\N	1
1930	1997-09-23	\N	\N	f	\N	\N	1	\N	261	2	1861	5	\N	1
1939	1997-10-01	\N	\N	f	\N	\N	1	\N	261	2	1874	5	\N	1
1996	1998-07-28	\N	\N	f	\N	\N	2	\N	265	1	1933	5	\N	1
2307	2010-06-18	\N	\N	f	\N	\N	1	\N	342	3	2247	5	\N	1
2470	2015-10-30	\N	\N	f	\N	\N	1	\N	361	2	2414	5	\N	1
109	1826-07-04	\N	\N	t	Clanricarde	1st Marquess 	1	\N	\N	\N	103	5	3	8
29	1801-06-18	\N	\N	f	Craven	7th Lord	1	\N	\N	\N	33	5	\N	11
49	1807-11-04	\N	\N	f	Lake	1st Lord	1	\N	\N	\N	18	5	\N	11
141	1828-01-28	\N	\N	t	Clanwilliam	3rd Earl 	1	\N	\N	\N	131	5	3	8
58	1814-05-17	\N	\N	f	\N	\N	4	\N	\N	\N	55	5	\N	11
165	1831-09-10	\N	\N	t	Cassillis	12th Earl 	1	\N	\N	\N	43	5	2	7
206	1831-09-12	\N	\N	t	Breadalbane	4th Earl 	1	\N	\N	\N	44	5	2	7
117	1821-07-18	\N	\N	f	Rous	1st Lord	1	\N	\N	\N	111	5	\N	8
188	1835-06-13	\N	\N	t	Gosford	2nd Earl 	1	\N	\N	\N	177	5	3	7
249	1837-02-13	\N	\N	t	Charlemont	2nd Earl 	1	\N	\N	\N	219	5	3	7
244	1849-08-25	\N	\N	t	Dalhousie	10th Earl 	1	\N	\N	\N	231	5	2	6
635	1912-07-08	\N	\N	t	Carrick	7th Earl 	1	\N	\N	\N	598	5	3	4
296	1866-05-02	\N	\N	f	Clermont	1st Lord 	1	\N	\N	\N	277	5	3	6
182	1835-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	171	5	\N	7
412	1885-06-27	\N	\N	f	Powerscourt	7th Viscount 	1	\N	\N	\N	388	5	3	6
359	1874-02-27	\N	\N	t	Westminster	3rd Marquess	1	\N	\N	\N	339	5	\N	6
600	1901-11-09	\N	\N	t	Cornwall and York	Duke	1	\N	\N	\N	451	5	\N	5
2623	1876-01-15	\N	\N	f	Wharncliffe	3rd Lord	1	\N	\N	\N	2567	5	\N	6
36	1802-06-19	\N	\N	t	Downshire	Marchioness	1	\N	\N	\N	14	5	\N	11
2832	1900-06-26	\N	\N	f	Strathcona and Mount Royal	1st Lord	1	\N	\N	\N	2570	5	\N	6
560	1901-02-11	\N	\N	f	Roberts of Kandahar	1st Lord	1	\N	\N	\N	508	5	\N	5
878	1926-05-07	\N	\N	t	Reading	1st Earl	1	\N	\N	\N	611	5	\N	4
2862	1902-07-11	\N	\N	f	Kitchener of Khartoum	1st Lord	1	\N	\N	\N	492	5	\N	5
542	1902-07-15	\N	\N	f	Milner	1st Lord	1	\N	\N	\N	509	5	\N	5
1233	1958-09-22	\N	\N	t	Reading	Marchioness dowager	1	\N	285	\N	1114	5	\N	1
708	1918-06-15	\N	\N	f	Wimborne	2nd Lord	1	\N	\N	\N	570	5	\N	4
713	1919-05-16	\N	\N	f	Burnham	2nd Lord	1	\N	4	\N	669	5	\N	4
799	1922-06-05	\N	\N	f	French of Ypres	1st Viscount	1	\N	\N	\N	742	5	\N	4
2904	1999-11-16	\N	\N	f	Shepherd	2nd Lord	5	\N	272	11	2822	5	\N	1
740	1919-10-27	\N	\N	f	\N	\N	1	\N	5	\N	691	5	\N	4
754	1921-01-19	\N	\N	f	\N	\N	1	\N	8	\N	704	5	\N	4
850	1929-07-10	\N	\N	f	Peel	2nd Viscount	1	\N	27	\N	793	5	\N	4
796	1924-01-21	\N	\N	f	\N	\N	2	\N	13	\N	740	5	\N	4
965	1937-02-16	\N	\N	f	Greenwood	1st Lord	1	\N	43	\N	899	5	\N	2
819	1927-01-31	\N	\N	f	\N	\N	2	\N	21	\N	762	5	\N	4
831	1929-03-18	\N	\N	f	\N	\N	1	\N	25	\N	775	5	\N	4
944	1938-01-24	\N	\N	f	Nuffield	1st Lord	1	\N	46	\N	882	5	\N	2
864	1931-01-21	\N	\N	f	\N	\N	1	\N	30	\N	807	5	\N	4
874	1932-01-21	\N	\N	f	\N	\N	1	\N	32	\N	817	5	\N	4
886	1933-01-23	\N	\N	f	\N	\N	1	\N	34	\N	827	5	\N	4
894	1934-01-11	\N	\N	f	\N	\N	1	\N	36	\N	835	5	\N	4
903	1935-01-25	\N	\N	f	\N	\N	1	\N	39	\N	843	5	\N	4
912	1936-01-11	\N	\N	f	\N	\N	1	\N	41	\N	851	5	\N	4
1045	1946-01-25	\N	\N	f	Southwood	1st Lord	1	\N	65	\N	880	5	\N	2
2649	1937-02-22	\N	\N	f	\N	\N	1	\N	43	\N	2585	5	\N	2
937	1937-06-08	\N	\N	f	\N	\N	3	\N	44	\N	875	5	\N	2
1129	1952-03-11	\N	\N	f	Alexander of Tunis	1st Viscount	1	\N	\N	\N	983	5	\N	1
962	1939-07-04	\N	\N	f	\N	\N	1	\N	49	\N	897	5	\N	2
979	1941-07-03	\N	\N	f	\N	\N	1	\N	52	\N	911	5	\N	2
990	1942-02-20	\N	\N	f	\N	\N	1	\N	54	\N	922	5	\N	2
1039	1944-01-31	\N	\N	f	\N	\N	1	\N	58	\N	968	5	\N	2
1016	1945-07-06	\N	\N	f	\N	\N	1	\N	61	\N	948	5	\N	2
1273	1961-07-25	\N	\N	f	Fairhaven	1st Lord	1	\N	\N	\N	779	5	\N	1
1060	1946-06-26	\N	\N	f	\N	\N	1	\N	66	\N	987	5	\N	2
1070	1947-01-15	\N	\N	f	\N	\N	1	\N	67	\N	997	5	\N	2
1082	1947-10-09	\N	\N	f	\N	\N	1	\N	68	\N	1008	5	\N	2
1093	1949-06-21	\N	\N	f	\N	\N	1	\N	72	\N	1019	5	\N	2
1105	1950-07-05	\N	\N	f	\N	\N	1	\N	74	\N	1031	5	\N	2
1594	1979-07-10	\N	\N	f	\N	\N	1	\N	185	2	1516	5	\N	1
1156	1951-12-20	\N	\N	f	\N	\N	1	\N	77	\N	1074	5	\N	2
1145	1954-01-18	\N	\N	f	\N	\N	2	\N	82	\N	1065	5	\N	1
1161	1955-08-04	\N	\N	f	\N	\N	1	\N	85	\N	1079	5	\N	1
1180	1957-07-02	\N	\N	f	\N	\N	1	\N	89	\N	1098	5	\N	1
1188	1958-08-04	\N	\N	f	\N	\N	1	\N	285	\N	1106	5	\N	1
1212	1959-12-08	\N	\N	f	\N	\N	1	\N	95	\N	1132	5	\N	1
1235	1961-02-08	\N	\N	f	\N	\N	1	\N	99	\N	1153	5	\N	1
1247	1962-03-26	\N	\N	f	\N	\N	1	\N	101	\N	1165	5	\N	1
1250	1962-04-16	\N	\N	f	\N	\N	1	\N	102	\N	1169	5	\N	1
1266	1963-06-13	\N	\N	f	\N	\N	1	\N	105	\N	1184	5	\N	1
2849	1963-11-27	\N	\N	f	\N	\N	1	\N	106	\N	2770	5	\N	1
1302	1964-12-11	\N	\N	f	\N	\N	1	\N	114	\N	1219	5	\N	1
1304	1964-12-14	\N	\N	f	\N	\N	1	\N	115	\N	1221	5	\N	1
1345	1964-12-17	\N	\N	f	\N	\N	2	\N	115	1	1263	5	\N	1
1323	1965-01-29	\N	\N	f	\N	\N	1	\N	116	\N	1238	5	\N	1
1342	1965-07-20	\N	\N	f	\N	\N	1	\N	119	\N	1258	5	\N	1
1352	1966-06-09	\N	\N	f	\N	\N	1	\N	121	\N	1268	5	\N	1
2678	1967-01-19	\N	\N	f	\N	\N	1	\N	123	\N	2609	5	\N	1
1369	1967-08-25	\N	\N	f	\N	\N	1	\N	125	\N	1287	5	\N	1
1378	1967-09-21	\N	\N	f	\N	\N	1	\N	125	\N	1298	5	\N	1
1423	1967-12-06	\N	\N	f	\N	\N	1	\N	127	\N	1342	5	\N	1
1396	1968-07-10	\N	\N	f	\N	\N	1	\N	130	\N	1313	5	\N	1
1405	1969-07-03	\N	\N	f	\N	\N	1	\N	135	\N	1322	5	\N	1
1429	1970-07-01	\N	\N	f	Tweedsmuir	Lady	1	\N	137	\N	1331	5	\N	1
1460	1970-09-25	\N	\N	f	\N	\N	1	\N	140	\N	1383	5	\N	1
1435	1971-04-30	\N	\N	f	\N	\N	1	\N	145	\N	1353	5	\N	1
1442	1972-01-10	\N	\N	f	\N	\N	1	\N	148	\N	1363	5	\N	1
1449	1972-05-10	\N	\N	f	\N	\N	1	\N	149	\N	1371	5	\N	1
1458	1973-07-16	\N	\N	f	\N	\N	1	\N	153	\N	1381	5	\N	1
1499	1974-03-11	\N	\N	f	\N	\N	1	\N	156	\N	1424	5	\N	1
1476	1974-06-18	\N	\N	f	\N	\N	1	\N	161	\N	1398	5	\N	1
1491	1974-10-01	\N	\N	f	\N	\N	1	\N	163	\N	1416	5	\N	1
2838	1975-01-08	\N	\N	f	\N	\N	1	\N	166	\N	2762	5	\N	1
1501	1975-01-16	\N	\N	f	\N	\N	1	\N	166	\N	1427	5	\N	1
1516	1975-01-31	\N	\N	f	\N	\N	1	\N	167	\N	1438	5	\N	1
1522	1975-07-17	\N	\N	f	\N	\N	1	\N	168	\N	1444	5	\N	1
1530	1976-01-22	\N	\N	f	\N	\N	1	\N	170	\N	1452	5	\N	1
1534	1976-01-30	\N	\N	f	\N	\N	1	\N	171	\N	1457	5	\N	1
2720	1976-06-28	\N	\N	f	\N	\N	1	\N	173	\N	2655	5	\N	1
1545	1976-08-02	\N	\N	f	\N	\N	1	\N	173	\N	1468	5	\N	1
1555	1977-03-23	\N	\N	f	\N	\N	1	\N	177	\N	1476	5	\N	1
1564	1978-03-20	\N	\N	f	\N	\N	1	\N	179	\N	1486	5	\N	1
1572	1978-05-03	\N	\N	f	\N	\N	1	\N	180	\N	1495	5	\N	1
1616	1978-07-21	\N	\N	f	\N	\N	1	\N	181	\N	1543	5	\N	1
1587	1979-07-03	\N	\N	f	\N	\N	1	\N	185	\N	1512	5	\N	1
1627	1979-07-30	\N	\N	f	\N	\N	1	\N	186	\N	1527	5	\N	1
1621	1981-05-18	\N	\N	f	\N	\N	1	\N	190	\N	1548	5	\N	1
1669	1981-05-28	\N	\N	f	\N	\N	1	\N	190	\N	1554	5	\N	1
1634	1981-07-06	\N	\N	f	\N	\N	1	\N	191	\N	1558	5	\N	1
1643	1982-05-21	\N	\N	f	\N	\N	1	\N	192	\N	1567	5	\N	1
1644	1982-07-16	\N	\N	f	\N	\N	1	\N	194	\N	1569	5	\N	1
1652	1983-02-03	\N	\N	f	\N	\N	1	\N	198	\N	1579	5	\N	1
2696	1983-02-07	\N	\N	f	\N	\N	1	\N	197	\N	2627	5	\N	1
1663	1983-09-05	\N	\N	f	\N	\N	1	\N	199	\N	1590	5	\N	1
1684	1984-01-30	\N	\N	f	\N	\N	1	\N	201	\N	1608	5	\N	1
2799	1984-02-02	\N	\N	f	\N	\N	1	\N	201	\N	2727	5	\N	1
1732	1985-05-17	\N	\N	f	\N	\N	1	\N	203	\N	1658	5	\N	1
1701	1985-07-12	\N	\N	f	\N	\N	1	\N	204	\N	1628	5	\N	1
1713	1987-02-03	\N	\N	f	\N	\N	1	\N	207	\N	1637	5	\N	1
1716	1987-03-24	\N	\N	f	\N	\N	1	\N	208	\N	1641	5	\N	1
1768	1987-11-02	\N	\N	f	\N	\N	1	\N	211	\N	1699	5	\N	1
1741	1988-02-15	\N	\N	f	\N	\N	1	\N	212	\N	1668	5	\N	1
1762	1990-05-16	\N	\N	f	\N	\N	1	\N	218	\N	1689	5	\N	1
1770	1991-01-17	\N	\N	f	\N	\N	1	\N	220	\N	1701	5	\N	1
1778	1991-06-05	\N	\N	f	\N	\N	1	\N	222	\N	1710	5	\N	1
1792	1991-07-17	\N	\N	f	\N	\N	1	\N	223	\N	1723	5	\N	1
1794	1991-07-30	\N	\N	f	\N	\N	1	\N	224	\N	1725	5	\N	1
1795	1991-10-01	\N	\N	f	\N	\N	1	\N	225	\N	1726	5	\N	1
1808	1992-07-03	\N	\N	f	\N	\N	1	\N	230	\N	1742	5	\N	1
1826	1992-07-20	\N	\N	f	\N	\N	1	\N	232	\N	1753	5	\N	1
1841	1993-10-01	\N	\N	f	\N	\N	1	\N	236	\N	1770	5	\N	1
1849	1994-02-10	\N	\N	f	\N	\N	1	\N	238	\N	1779	5	\N	1
2706	1994-09-28	\N	\N	f	\N	\N	1	\N	241	\N	2639	5	\N	1
1857	1994-10-04	\N	\N	f	\N	\N	1	\N	241	\N	1788	5	\N	1
1867	1995-02-21	\N	\N	f	\N	\N	1	\N	244	\N	1797	5	\N	1
2806	1995-02-28	\N	\N	f	\N	\N	1	\N	243	\N	2733	5	\N	1
1876	1995-12-21	\N	\N	f	\N	\N	1	\N	247	\N	1806	5	\N	1
1923	1996-02-21	\N	\N	f	\N	\N	1	\N	249	\N	1854	5	\N	1
1906	1997-02-14	\N	\N	f	\N	\N	1	\N	255	\N	1835	5	\N	1
1943	1997-06-04	\N	\N	f	\N	\N	1	\N	256	\N	1844	5	\N	1
1980	1998-02-23	\N	\N	f	\N	\N	1	\N	263	\N	1915	5	\N	1
2947	1999-06-19	\N	\N	f	\N	\N	1	\N	269	\N	2489	5	\N	1
2013	1999-07-12	\N	\N	f	\N	\N	1	\N	268	\N	1954	5	\N	1
95	1821-07-17	\N	\N	t	Roden	3rd Earl 	7	\N	\N	\N	88	5	3	8
2167	2001-06-18	\N	\N	f	\N	\N	1	\N	278	\N	2080	5	\N	1
2123	2001-07-09	\N	\N	f	\N	\N	1	\N	280	\N	2061	5	\N	1
2136	2001-07-20	\N	\N	f	\N	\N	1	\N	280	\N	2071	5	\N	1
2214	2005-06-14	\N	\N	f	\N	\N	1	\N	304	2	2130	5	\N	1
2298	2006-05-26	\N	\N	f	\N	\N	2	\N	310	1	2202	5	\N	1
2271	2007-07-12	\N	\N	f	\N	\N	1	\N	323	\N	2215	5	\N	1
2294	2008-06-02	\N	\N	f	\N	\N	1	\N	327	\N	2224	5	\N	1
2283	2009-05-29	\N	\N	f	\N	\N	1	\N	334	\N	2233	5	\N	1
2292	2009-06-30	\N	\N	f	\N	\N	1	\N	336	\N	2235	5	\N	1
2306	2010-06-17	\N	\N	f	\N	\N	2	\N	342	1	2246	5	\N	1
2736	2010-06-21	\N	\N	f	\N	\N	2	\N	342	1	2671	5	\N	1
2246	2013-07-12	\N	\N	f	\N	\N	1	\N	317	\N	2191	5	\N	1
43	1806-04-09	\N	\N	f	Newark	1st Viscount	1	\N	\N	\N	42	5	\N	11
2746	2016-10-04	\N	\N	f	\N	\N	1	\N	365	\N	2687	5	\N	1
2507	2016-10-20	\N	\N	f	\N	\N	1	\N	363	\N	2454	5	\N	1
2520	2018-10-26	\N	\N	f	\N	\N	1	\N	372	\N	2473	5	\N	1
2523	2019-10-09	\N	\N	f	\N	\N	1	\N	374	2	2479	5	\N	1
2549	2020-04-08	\N	\N	f	\N	\N	1	\N	379	\N	2495	5	\N	1
149	1831-06-20	\N	\N	t	Sefton	2nd Earl 	2	\N	\N	\N	139	5	3	7
2078	1999-11-17	\N	\N	f	Carrington	6th Lord	4	\N	272	6	2012	5	\N	1
173	1832-05-15	\N	\N	f	Falkland	10th Viscount 	1	\N	\N	\N	161	5	2	7
69	1815-08-11	\N	\N	t	Limerick	1st Earl 	5	\N	\N	\N	65	5	3	11
113	1821-07-07	\N	\N	f	Eldon	1st Lord	1	\N	\N	\N	107	5	\N	8
212	1838-07-13	\N	\N	f	\N	\N	1	\N	\N	\N	198	5	\N	6
1291	1964-08-24	\N	\N	f	\N	\N	1	\N	113	\N	1207	5	\N	1
2051	2000-04-19	\N	\N	t	Mar and Kellie	Earl	2	\N	274	4	1993	5	\N	1
519	1898-06-11	\N	\N	f	Muncaster	5th Lord 	1	\N	\N	\N	490	5	3	6
630	1911-11-02	\N	\N	f	Curzon of Kedleston	1st Lord 	1	\N	\N	\N	593	5	3	4
476	1892-08-22	\N	\N	t	Zetland	3rd Earl	1	\N	\N	\N	454	5	\N	6
317	1869-12-08	\N	\N	t	Listowel	3rd Earl 	1	\N	\N	\N	299	5	3	6
288	1851-04-05	\N	\N	f	de Freyne	1st Lord	1	\N	\N	\N	206	5	\N	6
221	1839-06-07	\N	\N	f	\N	\N	1	\N	\N	\N	207	5	\N	6
495	1895-07-16	\N	\N	f	Carrington	3rd Lord	1	\N	\N	\N	468	5	\N	6
230	1841-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	217	5	\N	6
579	1902-07-14	\N	\N	f	Churchill	3rd Lord	1	\N	\N	\N	546	5	\N	5
570	1905-12-28	\N	\N	f	Tredegar	2nd Lord	1	\N	\N	\N	537	5	\N	5
798	1922-11-28	\N	\N	f	Birkenhead	1st Viscount	1	\N	\N	\N	678	5	\N	4
844	1929-07-04	\N	\N	f	Hailsham	1st Lord	1	\N	26	\N	771	5	\N	4
1007	1945-02-01	\N	\N	f	Portal	1st Lord	1	\N	60	\N	844	5	\N	2
1047	1946-01-28	\N	\N	f	Portal of Hungerford	1st Lord	1	\N	65	\N	975	5	\N	2
1122	1951-12-24	\N	\N	f	Jowitt	1st Viscount	1	\N	77	\N	958	5	\N	2
297	1866-05-03	\N	\N	f	Athlumney	1st Lord 	1	\N	\N	\N	278	5	3	6
268	1857-09-16	\N	\N	f	\N	\N	1	\N	\N	\N	251	5	\N	6
284	1861-08-05	\N	\N	f	\N	\N	1	\N	\N	\N	266	5	\N	6
310	1868-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	291	5	\N	6
384	1874-03-02	\N	\N	f	\N	\N	1	\N	\N	\N	364	5	\N	6
377	1880-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	357	5	\N	6
418	1885-07-03	\N	\N	f	\N	\N	2	\N	\N	\N	394	5	\N	6
426	1886-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	403	5	\N	6
443	1887-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	417	5	\N	6
452	1887-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	426	5	\N	6
477	1891-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	434	5	\N	6
485	1893-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	458	5	\N	6
508	1896-08-11	\N	\N	f	\N	\N	1	\N	\N	\N	480	5	\N	6
536	1900-06-18	\N	\N	f	\N	\N	1	\N	\N	\N	505	5	\N	6
548	1902-07-21	\N	\N	f	\N	\N	1	\N	\N	\N	517	5	\N	5
581	1906-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	548	5	\N	5
590	1907-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	557	5	\N	5
601	1909-12-07	\N	\N	f	\N	\N	1	\N	\N	\N	567	5	\N	5
610	1910-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	576	5	\N	4
621	1911-06-24	\N	\N	f	\N	\N	1	\N	\N	\N	587	5	\N	4
650	1914-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	612	5	\N	4
699	1914-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	656	5	\N	4
672	1916-01-27	\N	\N	f	\N	\N	1	\N	\N	\N	633	5	\N	4
681	1916-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	641	5	\N	4
691	1917-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	650	5	\N	4
716	1918-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	672	5	\N	4
729	1919-03-24	\N	\N	f	\N	\N	1	\N	\N	\N	682	5	\N	4
742	1919-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	693	5	\N	4
809	1925-12-22	\N	\N	f	\N	\N	1	\N	\N	\N	752	5	\N	4
833	1929-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	777	5	\N	4
918	1935-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	857	5	\N	4
971	1940-05-28	\N	\N	f	\N	\N	1	\N	\N	\N	904	5	\N	2
983	1942-01-12	\N	\N	f	\N	\N	1	\N	53	\N	915	5	\N	2
1196	1955-06-20	\N	\N	f	\N	\N	1	\N	85	\N	1113	5	\N	1
1179	1957-04-24	\N	\N	f	\N	\N	1	\N	\N	\N	1097	5	\N	1
1225	1960-09-08	\N	\N	f	\N	\N	1	\N	\N	\N	1146	5	\N	1
1329	1965-05-11	\N	\N	f	\N	\N	2	\N	118	1	1245	5	\N	1
1272	1961-02-04	\N	\N	f	\N	\N	1	\N	99	\N	1187	5	\N	1
1300	1964-10-29	\N	\N	f	\N	\N	1	\N	\N	\N	1216	5	\N	1
1327	1965-02-19	\N	\N	f	\N	\N	1	\N	\N	\N	1242	5	\N	1
1428	1970-02-12	\N	\N	f	Masham	Lady	1	\N	136	\N	1327	5	\N	1
1595	1979-07-10	\N	\N	f	\N	\N	2	\N	185	1	1517	5	\N	1
1707	1985-05-29	\N	\N	f	\N	\N	1	\N	203	\N	1622	5	\N	1
1847	1992-06-30	\N	\N	f	\N	\N	1	\N	230	2	1777	5	\N	1
1918	1997-06-09	\N	\N	f	\N	\N	1	\N	256	2	1849	5	\N	1
1908	1997-05-14	\N	\N	f	\N	\N	1	\N	256	2	1838	5	\N	1
1937	1997-09-29	\N	\N	f	\N	\N	1	\N	260	2	1870	5	\N	1
1997	1997-10-28	\N	\N	f	\N	\N	1	\N	261	2	1935	5	\N	1
1975	1997-11-06	\N	\N	f	\N	\N	2	\N	261	1	1910	5	\N	1
2017	1998-07-21	\N	\N	f	\N	\N	1	\N	265	2	1922	5	\N	1
2021	1998-08-01	\N	\N	f	\N	\N	2	\N	265	1	1940	5	\N	1
2040	1998-07-29	\N	\N	f	\N	\N	2	\N	265	1	1974	5	\N	1
2032	1999-07-20	\N	\N	f	\N	\N	2	\N	270	1	1965	5	\N	1
2042	1998-07-30	\N	\N	f	\N	\N	2	\N	265	1	1976	5	\N	1
2075	1999-07-29	\N	\N	f	\N	\N	1	\N	270	2	2009	5	\N	1
2112	2001-06-28	\N	\N	f	\N	\N	2	\N	278	1	2050	5	\N	1
2147	2004-06-02	\N	\N	f	\N	\N	2	\N	295	1	2084	5	\N	1
2071	2000-05-01	\N	\N	f	\N	\N	2	\N	274	1	2005	5	\N	1
2155	2004-06-10	\N	\N	f	\N	\N	1	\N	295	2	2094	5	\N	1
2184	2004-06-01	\N	\N	f	\N	\N	1	\N	295	2	2122	5	\N	1
2165	2004-06-22	\N	\N	f	\N	\N	2	\N	295	1	2110	5	\N	1
2196	2005-06-20	\N	\N	f	\N	\N	1	\N	304	2	2137	5	\N	1
2210	2004-06-24	\N	\N	f	\N	\N	1	\N	296	2	2113	5	\N	1
2233	2006-06-08	\N	\N	f	\N	\N	2	\N	311	1	2175	5	\N	1
2262	2006-05-30	\N	\N	f	\N	\N	1	\N	310	2	2203	5	\N	1
2314	2010-06-23	\N	\N	f	\N	\N	2	\N	342	1	2258	5	\N	1
2286	2009-09-01	\N	\N	f	\N	\N	1	\N	338	\N	2237	5	\N	1
2328	2010-06-26	\N	\N	f	\N	\N	1	\N	342	2	2263	5	\N	1
2358	2010-07-20	\N	\N	f	\N	\N	2	\N	342	1	2304	5	\N	1
2380	2010-12-21	\N	\N	f	\N	\N	1	\N	356	2	2319	5	\N	1
2383	2010-12-23	\N	\N	f	\N	\N	1	\N	356	2	2323	5	\N	1
2394	2011-01-17	\N	\N	f	\N	\N	2	\N	356	1	2335	5	\N	1
2406	2011-02-01	\N	\N	f	\N	\N	2	\N	356	1	2356	5	\N	1
2401	2011-01-25	\N	\N	f	\N	\N	1	\N	356	2	2346	5	\N	1
2454	2015-10-16	\N	\N	f	\N	\N	1	\N	350	2	2378	5	\N	1
2443	2015-10-22	\N	\N	f	\N	\N	1	\N	350	2	2393	5	\N	1
2442	2015-10-21	\N	\N	f	\N	\N	2	\N	350	1	2392	5	\N	1
1949	1997-10-04	\N	\N	f	\N	\N	1	\N	261	2	1879	5	\N	1
2479	2013-09-11	\N	\N	f	\N	\N	2	\N	318	1	2428	5	\N	1
2490	2013-10-03	\N	\N	f	\N	\N	1	\N	318	2	2443	5	\N	1
2503	2016-08-30	\N	\N	f	\N	\N	2	\N	363	1	2420	5	\N	1
2544	2019-10-14	\N	\N	f	\N	\N	1	\N	374	2	2485	5	\N	1
2557	2020-09-04	\N	\N	f	\N	\N	2	\N	380	1	2505	5	\N	1
388	1881-10-07	\N	\N	t	Howth	4th Earl 	1	\N	\N	\N	368	5	3	6
2774	1850-01-22	\N	\N	f	Dufferin and Claneboye	5th Lord 	1	\N	\N	\N	340	5	3	6
151	1831-06-20	\N	\N	f	Kinnaird	9th Lord 	4	\N	\N	\N	141	5	2	7
459	1885-12-31	\N	\N	f	Colville of Culross	10th Lord 	1	\N	\N	\N	436	5	2	6
1127	1952-01-31	\N	\N	f	Winterton	6th Earl 	1	\N	78	\N	1051	5	3	2
67	1815-08-11	\N	\N	t	Glasgow	4th Earl 	3	\N	\N	\N	63	5	2	11
355	1875-06-12	\N	\N	t	Dalhousie	12th Earl 	1	\N	\N	\N	334	5	2	6
87	1816-12-10	\N	\N	f	Exmouth	1st Lord	1	\N	\N	\N	57	5	\N	11
232	1837-08-11	\N	\N	t	Roxburghe	6th Duke 	1	\N	\N	\N	220	5	2	6
445	1887-07-01	\N	\N	t	Strathmore and Kinghorne	13th Earl 	2	\N	\N	\N	419	5	2	6
599	1909-05-12	\N	\N	t	Desart	5th Earl 	1	\N	\N	\N	566	5	3	5
755	1921-06-15	\N	\N	f	Birkenhead	1st Lord	1	\N	9	\N	678	5	\N	4
2940	1911-07-03	\N	\N	t	Rosebery	5th Earl 	2	\N	\N	\N	2842	5	2	4
2937	1929-06-20	\N	\N	f	Inchcape	1st Viscount	1	\N	26	\N	739	5	\N	4
59	1814-05-17	\N	\N	f	\N	\N	5	\N	\N	\N	56	5	\N	11
73	1812-09-07	\N	\N	f	Harewood	1st Lord	4	\N	\N	\N	68	5	\N	11
2	1801-01-21	\N	\N	t	Carysfort	1st Earl 	1	\N	\N	\N	2	5	3	11
32	1801-06-22	\N	\N	f	Romney	3rd Lord	1	\N	\N	\N	36	5	\N	11
2568	2020-09-16	\N	\N	f	\N	\N	1	\N	380	2	2523	5	\N	1
2567	2020-09-15	\N	\N	f	\N	\N	2	\N	381	1	2522	5	\N	1
2597	2021-01-28	\N	\N	f	\N	\N	1	\N	383	2	2543	5	\N	1
2713	1997-10-22	\N	\N	f	\N	\N	2	\N	261	1	2646	5	\N	1
2828	2020-09-30	\N	\N	f	\N	\N	1	\N	381	2	2747	5	\N	1
2800	2001-06-29	\N	\N	f	\N	\N	1	\N	278	2	2717	5	\N	1
956	1937-06-01	\N	\N	t	Strathmore and Kinghorne	14th Earl 	1	\N	44	\N	892	5	2	2
2641	1929-06-24	\N	\N	f	Plumer	1st Lord	1	\N	26	\N	722	5	\N	4
2668	1957-07-10	\N	\N	f	Mackintosh of Halifax	1st Lord	1	\N	89	\N	1010	5	\N	1
2781	1902-07-12	\N	\N	f	Colville of Culross	1st Lord	1	\N	\N	\N	436	5	\N	5
2843	1926-02-20	\N	\N	f	D'Abernon	1st Lord	1	\N	19	\N	618	5	\N	4
398	1880-04-28	\N	\N	f	Lytton	2nd Lord	1	\N	\N	\N	378	5	\N	6
675	1916-06-26	\N	\N	f	Reading	1st Lord	1	\N	\N	\N	611	5	\N	4
795	1924-01-21	\N	\N	f	Inchcape	1st Lord	1	\N	13	\N	739	5	\N	4
312	1859-05-21	\N	\N	f	Elphinstone	13th Lord 	2	\N	\N	\N	293	5	2	6
1054	1946-02-08	\N	\N	f	Gort	6th Viscount 	1	\N	\N	\N	981	5	3	2
2609	1868-07-06	\N	\N	f	Bridport	3rd Lord 	1	\N	\N	\N	2561	5	3	6
2049	2000-04-18	\N	\N	f	Redesdale	6th Lord	1	\N	274	2	1991	5	\N	1
2772	1835-01-10	\N	\N	f	Fitz Gerald and Vesey	2nd Lord 	1	\N	\N	\N	2706	5	3	7
2801	1860-09-01	\N	\N	f	Kinnaird	9th Lord 	1	\N	\N	\N	141	5	2	6
2072	1999-11-16	\N	\N	t	Snowdon	1st Earl	3	\N	272	6	2006	5	\N	1
111	1826-07-06	\N	\N	f	Northland	2nd Viscount 	1	\N	\N	\N	105	5	3	8
264	1856-11-19	\N	\N	f	Talbot of Malahide	4th Lord 	1	\N	\N	\N	247	5	3	6
440	1885-07-11	\N	\N	t	Breadalbane	7th Earl 	1	\N	\N	\N	319	5	2	6
558	1902-10-27	\N	\N	t	Hopetoun	7th Earl 	1	\N	\N	\N	527	5	2	5
68	1815-08-11	\N	\N	t	Enniskillen	2nd Earl 	4	\N	\N	\N	64	5	3	11
237	1849-11-13	\N	\N	t	Elgin and Kincardine	8/12 Earl 	1	\N	\N	\N	225	5	2	6
3040	1831-01-06	\N	\N	f	\N	\N	\N	Abstract, p. 11; LP printed in LJ, lxxxviii, 385-6; dated 28 (sic) Jan. 1831 in CP, vi, 219	\N	\N	2941	3	\N	\N
92	1821-07-17	\N	\N	f	Conyngham	1st Marquess 	4	\N	\N	\N	84	5	3	8
79	1815-11-24	\N	\N	f	Grimston	4th Viscount 	1	\N	\N	\N	74	5	3	11
85	1815-12-01	\N	\N	f	Beauchamp	1st Lord	1	\N	\N	\N	40	5	\N	11
110	1826-07-05	\N	\N	t	Balcarres	7th Earl 	1	\N	\N	\N	104	5	2	8
160	1831-09-10	\N	\N	f	\N	\N	11	\N	\N	\N	150	5	\N	7
148	1831-06-20	\N	\N	t	Fingall	8th Earl 	1	\N	\N	\N	138	5	3	7
156	1825-01-26	\N	\N	f	Strangford	6th Viscount 	1	\N	\N	\N	146	5	3	8
202	1837-01-27	\N	\N	f	Howard of Effingham	11th Lord	1	\N	\N	\N	191	5	\N	7
427	1886-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	404	5	\N	6
555	1905-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	524	5	\N	5
2433	2015-10-01	\N	\N	f	\N	\N	1	\N	350	2	2380	5	\N	1
2111	2001-06-27	\N	\N	f	\N	\N	2	\N	278	1	2048	5	\N	1
2742	2011-01-12	\N	\N	f	\N	\N	1	\N	356	2	2677	5	\N	1
2161	2004-06-18	\N	\N	f	\N	\N	1	\N	295	2	2105	5	\N	1
2319	2010-06-28	\N	\N	f	\N	\N	2	\N	342	4	2267	5	\N	1
2288	2013-09-09	\N	\N	f	\N	\N	2	\N	318	1	2199	5	\N	1
2873	2018-06-19	\N	\N	f	\N	\N	1	\N	364	2	2793	5	\N	1
2582	2019-10-16	\N	\N	f	\N	\N	1	\N	373	2	2529	5	\N	1
2385	2015-05-28	\N	\N	f	\N	\N	1	\N	346	2	2326	5	\N	1
2156	2004-06-14	\N	\N	f	\N	\N	2	\N	295	1	2098	5	\N	1
1025	1945-08-01	\N	\N	f	\N	\N	1	\N	61	\N	957	5	\N	2
1801	1992-04-24	\N	\N	f	\N	\N	1	\N	228	2	1732	5	\N	1
1283	1964-03-10	\N	\N	f	\N	\N	1	\N	108	\N	1199	5	\N	1
1361	1966-07-20	\N	\N	f	\N	\N	1	\N	121	\N	1277	5	\N	1
1483	1974-06-28	\N	\N	f	\N	\N	1	\N	161	\N	1406	5	\N	1
2951	1979-08-06	\N	\N	f	\N	\N	1	\N	186	\N	1528	5	\N	1
1723	1987-07-14	\N	\N	f	\N	\N	1	\N	209	\N	1649	5	\N	1
1859	1994-10-10	\N	\N	f	\N	\N	1	\N	241	\N	1792	5	\N	1
2366	2010-11-22	\N	\N	t	Lothian	13th Marquess 	1	\N	355	\N	2313	5	2	1
2612	1884-06-17	\N	\N	t	Seafield	9th Earl 	1	\N	\N	\N	2564	5	2	6
45	1806-11-12	\N	\N	t	Cassillis	12th Earl 	1	\N	\N	\N	43	5	2	11
1144	1954-01-18	\N	\N	f	Leathers	1st Lord	1	\N	82	\N	912	5	\N	1
2052	2000-04-19	\N	\N	f	Ponsonby of Shulbrede	4th Lord	3	\N	274	5	1994	5	\N	1
2070	1999-11-16	\N	\N	f	Erroll of Hale	1st Lord	2	\N	272	5	2004	5	\N	1
2841	1925-06-29	\N	\N	f	Jellicoe	1st Viscount	1	\N	17	\N	658	5	\N	4
2910	1822-02-04	\N	\N	t	Buckingham	2nd Marquess	1	\N	\N	\N	2828	5	\N	8
387	1881-10-06	\N	\N	t	Tweeddale	10th Marquess 	1	\N	\N	\N	367	5	2	6
1030	1945-09-13	\N	\N	f	Marchwood	1st Lord	1	\N	64	\N	875	5	\N	2
2752	1801-01-19	\N	\N	t	Ely	1st Marquess 	1	\N	\N	\N	2696	5	3	11
806	1926-01-19	\N	\N	f	Oranmore and Browne	3rd Lord 	1	\N	19	\N	749	5	3	4
2428	2015-10-12	\N	\N	f	Hailsham	3rd Viscount	1	\N	350	2	2371	5	\N	1
333	1871-08-07	\N	\N	f	Bloomfield	2nd Lord 	1	\N	\N	\N	313	5	3	6
2654	1901-08-06	\N	\N	f	Cromer	1st Viscount	1	\N	\N	\N	439	5	\N	5
243	1837-01-30	\N	\N	f	Yarborough	2nd Lord	1	\N	\N	\N	230	5	\N	7
213	1839-04-20	\N	\N	f	Ponsonby	2nd Lord	1	\N	\N	\N	199	5	\N	6
289	1863-06-19	\N	\N	t	Somerset	12th Duke	1	\N	\N	\N	269	5	\N	6
362	1876-01-14	\N	\N	t	Abergavenny	5th Earl	1	\N	\N	\N	342	5	\N	6
499	1895-08-03	\N	\N	f	Knutsford	1st Lord	1	\N	\N	\N	428	5	\N	6
667	1916-01-22	\N	\N	f	Mersey	1st Lord	1	\N	\N	\N	571	5	\N	4
736	1918-06-17	\N	\N	f	St Davids	1st Lord	1	\N	3	\N	564	5	\N	4
777	1922-06-20	\N	\N	f	\N	\N	1	\N	11	\N	723	5	\N	4
797	1924-02-19	\N	\N	f	\N	\N	1	\N	14	\N	741	5	\N	4
822	1928-01-11	\N	\N	f	\N	\N	1	\N	23	\N	765	5	\N	4
865	1931-01-22	\N	\N	f	\N	\N	1	\N	30	\N	808	5	\N	4
905	1935-06-24	\N	\N	f	Bledisloe	1st Lord	1	\N	40	\N	674	5	\N	4
893	1933-07-24	\N	\N	f	\N	\N	1	\N	35	\N	834	5	\N	4
957	1936-05-26	\N	\N	t	Willingdon	1st Earl	1	\N	\N	\N	819	5	\N	3
953	1938-06-27	\N	\N	f	Stonehaven	1st Lord	1	\N	47	\N	750	5	\N	2
938	1937-06-09	\N	\N	f	\N	\N	1	\N	44	\N	876	5	\N	2
954	1938-06-28	\N	\N	f	\N	\N	1	\N	47	\N	890	5	\N	2
974	1941-01-25	\N	\N	f	\N	\N	1	\N	51	\N	907	5	\N	2
989	1942-02-04	\N	\N	f	\N	\N	1	\N	53	\N	921	5	\N	2
1005	1944-06-26	\N	\N	f	\N	\N	1	\N	59	\N	938	5	\N	2
1020	1945-07-11	\N	\N	f	\N	\N	1	\N	62	\N	952	5	\N	2
1048	1946-01-28	\N	\N	f	\N	\N	2	\N	65	\N	976	5	\N	2
1058	1946-06-25	\N	\N	f	\N	\N	1	\N	66	\N	985	5	\N	2
1072	1947-01-17	\N	\N	f	\N	\N	1	\N	67	\N	999	5	\N	2
1086	1948-02-09	\N	\N	f	\N	\N	1	\N	69	\N	1012	5	\N	2
1100	1950-02-02	\N	\N	f	\N	\N	1	\N	73	\N	1026	5	\N	2
1124	1952-01-05	\N	\N	f	\N	\N	1	\N	78	\N	1048	5	\N	2
1135	1953-02-12	\N	\N	f	\N	\N	1	\N	80	\N	1057	5	\N	1
1149	1954-07-16	\N	\N	f	Soulbury	1st Lord	1	\N	83	\N	917	5	\N	1
1174	1957-01-21	\N	\N	f	\N	\N	1	\N	88	\N	1092	5	\N	1
1190	1958-08-06	\N	\N	f	\N	\N	1	\N	285	\N	1108	5	\N	1
1202	1959-02-19	\N	\N	f	\N	\N	1	\N	93	\N	1122	5	\N	1
1215	1960-01-28	\N	\N	f	\N	\N	1	\N	96	\N	1136	5	\N	1
1243	1961-07-10	\N	\N	f	\N	\N	1	\N	100	\N	1161	5	\N	1
1331	1965-05-12	\N	\N	f	\N	\N	1	\N	118	2	1247	5	\N	1
1263	1963-01-24	\N	\N	f	\N	\N	1	\N	104	\N	1181	5	\N	1
1262	1962-08-22	\N	\N	f	Mills	1st Lord	1	\N	\N	\N	886	5	\N	1
1276	1964-01-14	\N	\N	f	Eccles	1st Lord	1	\N	108	\N	1180	5	\N	1
1259	1963-01-18	\N	\N	f	\N	\N	1	\N	104	\N	1178	5	\N	1
1265	1963-01-31	\N	\N	f	\N	\N	1	\N	104	\N	1183	5	\N	1
1267	1963-07-09	\N	\N	f	\N	\N	1	\N	105	\N	1185	5	\N	1
1307	1963-11-09	\N	\N	f	\N	\N	1	\N	\N	\N	1224	5	\N	1
1308	1963-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	1226	5	\N	1
1270	1961-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	1189	5	\N	1
1252	1962-04-19	\N	\N	f	\N	\N	1	\N	\N	\N	1171	5	\N	1
1261	1962-08-01	\N	\N	f	\N	\N	1	\N	\N	\N	1180	5	\N	1
1269	1961-02-07	\N	\N	f	\N	\N	1	\N	99	\N	1188	5	\N	1
1274	1963-11-26	\N	\N	f	\N	\N	1	\N	\N	\N	1190	5	\N	1
1275	1964-01-11	\N	\N	f	\N	\N	1	\N	\N	\N	1191	5	\N	1
1298	1964-12-07	\N	\N	f	Dilhorne	1st Lord	1	\N	114	\N	1179	5	\N	1
1277	1964-01-15	\N	\N	f	\N	\N	1	\N	107	\N	1192	5	\N	1
1278	1964-01-16	\N	\N	f	\N	\N	1	\N	107	\N	1193	5	\N	1
1280	1964-01-20	\N	\N	f	\N	\N	1	\N	107	\N	1195	5	\N	1
1281	1964-01-21	\N	\N	f	\N	\N	1	\N	107	\N	1196	5	\N	1
1282	1964-01-22	\N	\N	f	\N	\N	1	\N	107	\N	1197	5	\N	1
1310	1964-01-23	\N	\N	f	\N	\N	1	\N	107	\N	1198	5	\N	1
1284	1964-04-20	\N	\N	f	\N	\N	1	\N	109	\N	1200	5	\N	1
1285	1964-05-13	\N	\N	f	\N	\N	1	\N	110	\N	1201	5	\N	1
1286	1964-06-26	\N	\N	f	\N	\N	1	\N	111	\N	1202	5	\N	1
1287	1964-07-16	\N	\N	f	\N	\N	1	\N	111	\N	1203	5	\N	1
1288	1964-07-16	\N	\N	f	\N	\N	2	\N	111	\N	1204	5	\N	1
1289	1964-08-21	\N	\N	f	\N	\N	1	\N	113	\N	1205	5	\N	1
1290	1964-08-22	\N	\N	f	\N	\N	1	\N	113	\N	1206	5	\N	1
1292	1964-08-25	\N	\N	f	\N	\N	1	\N	113	\N	1208	5	\N	1
1295	1964-09-04	\N	\N	f	\N	\N	1	\N	\N	\N	1211	5	\N	1
1293	1964-09-14	\N	\N	f	\N	\N	1	\N	113	\N	1209	5	\N	1
1296	1964-10-01	\N	\N	f	\N	\N	1	\N	112	\N	1212	5	\N	1
1297	1964-10-05	\N	\N	f	\N	\N	1	\N	113	\N	1213	5	\N	1
1299	1964-10-27	\N	\N	f	\N	\N	1	\N	\N	\N	1215	5	\N	1
1309	1964-12-08	\N	\N	f	\N	\N	1	\N	114	\N	1218	5	\N	1
1301	1964-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	1217	5	\N	1
1303	1964-12-12	\N	\N	f	\N	\N	1	\N	115	\N	1220	5	\N	1
1305	1964-12-15	\N	\N	f	\N	\N	1	\N	115	\N	1222	5	\N	1
1306	1964-12-16	\N	\N	f	\N	\N	2	\N	115	1	1223	5	\N	1
1346	1964-12-18	\N	\N	f	\N	\N	1	\N	115	2	1264	5	\N	1
1347	1964-12-18	\N	\N	f	\N	\N	2	\N	115	1	1265	5	\N	1
1312	1964-12-21	\N	\N	f	\N	\N	1	\N	115	2	1227	5	\N	1
1316	1964-12-28	\N	\N	f	\N	\N	1	\N	115	\N	1231	5	\N	1
1317	1964-12-29	\N	\N	f	\N	\N	1	\N	115	\N	1232	5	\N	1
1318	1964-12-30	\N	\N	f	\N	\N	1	\N	114	\N	1233	5	\N	1
1319	1964-12-31	\N	\N	f	\N	\N	1	\N	114	\N	1234	5	\N	1
1330	1965-05-11	\N	\N	f	\N	\N	1	\N	\N	2	1246	5	\N	1
1268	1961-02-03	\N	\N	f	\N	\N	1	\N	98	\N	1186	5	\N	1
1320	1965-01-01	\N	\N	f	\N	\N	1	\N	114	2	1235	5	\N	1
1324	1965-02-04	\N	\N	f	\N	\N	1	\N	116	\N	1239	5	\N	1
1326	1965-02-18	\N	\N	f	\N	\N	1	\N	\N	\N	1241	5	\N	1
1325	1965-03-24	\N	\N	f	\N	\N	1	\N	116	\N	1240	5	\N	1
1350	1965-05-10	\N	\N	f	\N	\N	1	\N	118	2	1243	5	\N	1
1338	1965-07-05	\N	\N	f	\N	\N	1	\N	119	\N	1254	5	\N	1
1339	1965-07-06	\N	\N	f	\N	\N	1	\N	119	\N	1255	5	\N	1
1341	1965-07-16	\N	\N	f	\N	\N	1	\N	119	\N	1257	5	\N	1
1343	1966-01-14	\N	\N	f	\N	\N	1	\N	120	\N	1259	5	\N	1
1344	1966-01-15	\N	\N	f	\N	\N	1	\N	120	\N	1260	5	\N	1
1351	1966-01-17	\N	\N	f	\N	\N	1	\N	120	\N	1262	5	\N	1
1382	1966-01-19	\N	\N	f	\N	\N	1	\N	120	\N	1302	5	\N	1
1383	1966-05-27	\N	\N	f	\N	\N	1	\N	121	\N	1303	5	\N	1
1348	1966-06-06	\N	\N	f	\N	\N	1	\N	121	\N	1266	5	\N	1
1349	1966-06-07	\N	\N	f	\N	\N	1	\N	121	\N	1267	5	\N	1
1353	1966-06-10	\N	\N	f	\N	\N	1	\N	121	\N	1269	5	\N	1
1354	1966-06-15	\N	\N	f	\N	\N	1	\N	121	\N	1270	5	\N	1
1356	1966-06-23	\N	\N	f	\N	\N	1	\N	122	\N	1272	5	\N	1
1357	1966-06-24	\N	\N	f	\N	\N	1	\N	122	\N	1273	5	\N	1
1358	1966-07-04	\N	\N	f	\N	\N	1	\N	122	\N	1274	5	\N	1
1359	1966-07-05	\N	\N	f	\N	\N	1	\N	122	\N	1275	5	\N	1
1360	1966-07-11	\N	\N	f	\N	\N	1	\N	122	\N	1276	5	\N	1
1362	1967-01-16	\N	\N	f	\N	\N	1	\N	123	\N	1279	5	\N	1
1363	1967-01-17	\N	\N	f	\N	\N	1	\N	123	\N	1280	5	\N	1
1364	1967-01-18	\N	\N	f	\N	\N	1	\N	123	\N	1281	5	\N	1
1365	1967-07-06	\N	\N	f	\N	\N	1	\N	124	\N	1283	5	\N	1
1366	1967-07-07	\N	\N	f	\N	\N	1	\N	124	\N	1284	5	\N	1
1398	1968-09-17	\N	\N	f	\N	\N	1	\N	132	\N	1315	5	\N	1
1408	1970-01-23	\N	\N	f	\N	\N	1	\N	136	\N	1325	5	\N	1
1418	1970-07-08	\N	\N	f	\N	\N	1	\N	137	\N	1337	5	\N	1
1432	1971-03-05	\N	\N	f	\N	\N	1	\N	138	\N	1350	5	\N	1
1391	1966-09-19	\N	\N	f	\N	\N	1	\N	122	\N	1278	5	\N	1
1450	1972-07-03	\N	\N	f	\N	\N	1	\N	150	\N	1372	5	\N	1
1462	1974-03-25	\N	\N	f	\N	\N	1	\N	157	\N	1385	5	\N	1
1507	1974-05-15	\N	\N	f	\N	\N	1	\N	159	\N	1395	5	\N	1
1482	1974-06-27	\N	\N	f	\N	\N	1	\N	161	\N	1405	5	\N	1
1493	1975-01-02	\N	\N	f	\N	\N	1	\N	166	\N	1418	5	\N	1
1511	1975-01-22	\N	\N	f	\N	\N	1	\N	166	\N	1431	5	\N	1
1525	1976-01-15	\N	\N	f	\N	\N	1	\N	170	\N	1447	5	\N	1
1536	1976-02-05	\N	\N	f	\N	\N	1	\N	171	\N	1459	5	\N	1
1544	1976-07-19	\N	\N	f	\N	\N	1	\N	174	\N	1467	5	\N	1
1557	1977-07-18	\N	\N	f	\N	\N	1	\N	178	\N	1478	5	\N	1
1568	1978-04-21	\N	\N	f	\N	\N	1	\N	180	\N	1490	5	\N	1
1613	1978-07-17	\N	\N	f	\N	\N	1	\N	181	\N	1540	5	\N	1
1591	1979-07-05	\N	\N	f	\N	\N	1	\N	185	\N	1513	5	\N	1
1628	1979-10-02	\N	\N	f	\N	\N	1	\N	186	\N	1532	5	\N	1
1619	1981-05-11	\N	\N	f	\N	\N	1	\N	190	\N	1546	5	\N	1
1635	1981-07-15	\N	\N	f	\N	\N	1	\N	191	\N	1559	5	\N	1
1647	1982-11-19	\N	\N	f	\N	\N	1	\N	196	\N	1572	5	\N	1
1694	1983-02-09	\N	\N	f	\N	\N	1	\N	197	\N	1619	5	\N	1
1672	1983-09-19	\N	\N	f	\N	\N	1	\N	200	\N	1596	5	\N	1
1683	1983-10-14	\N	\N	f	\N	\N	1	\N	200	\N	1607	5	\N	1
1734	1985-05-22	\N	\N	f	\N	\N	1	\N	203	\N	1660	5	\N	1
1712	1986-09-23	\N	\N	f	\N	\N	1	\N	206	\N	1636	5	\N	1
1722	1987-04-08	\N	\N	f	\N	\N	1	\N	208	\N	1648	5	\N	1
1736	1987-11-04	\N	\N	f	\N	\N	1	\N	211	\N	1662	5	\N	1
1750	1988-10-18	\N	\N	f	\N	\N	1	\N	213	\N	1675	5	\N	1
1781	1990-05-10	\N	\N	f	\N	\N	1	\N	218	\N	1687	5	\N	1
1772	1991-01-25	\N	\N	f	\N	\N	1	\N	220	\N	1703	5	\N	1
1787	1991-06-10	\N	\N	f	\N	\N	1	\N	222	\N	1713	5	\N	1
1798	1992-01-30	\N	\N	f	\N	\N	1	\N	226	\N	1729	5	\N	1
1818	1992-07-18	\N	\N	f	\N	\N	1	\N	230	\N	1752	5	\N	1
1861	1992-07-29	\N	\N	f	\N	\N	1	\N	232	\N	1758	5	\N	1
1839	1993-07-19	\N	\N	f	\N	\N	1	\N	235	\N	1768	5	\N	1
1852	1994-07-14	\N	\N	f	\N	\N	1	\N	239	\N	1782	5	\N	1
1884	1993-10-15	\N	\N	f	\N	\N	1	\N	237	\N	1817	5	\N	1
1872	1995-12-13	\N	\N	f	\N	\N	1	\N	246	\N	1802	5	\N	1
1928	1997-07-22	\N	\N	f	\N	\N	1	\N	259	\N	1859	5	\N	1
1893	1996-10-09	\N	\N	f	\N	\N	1	\N	253	\N	1828	5	\N	1
1879	1997-10-02	\N	\N	f	\N	\N	2	\N	260	1	1810	5	\N	1
2053	1999-07-31	\N	\N	f	\N	\N	2	\N	270	1	1980	5	\N	1
2100	2000-05-03	\N	\N	f	\N	\N	2	\N	274	1	2036	5	\N	1
2130	2001-07-19	\N	\N	f	\N	\N	1	\N	280	\N	2069	5	\N	1
2146	2004-06-01	\N	\N	f	\N	\N	2	\N	295	1	2083	5	\N	1
2221	2006-03-22	\N	\N	f	\N	\N	1	\N	308	\N	2159	5	\N	1
2256	2013-03-25	\N	\N	f	\N	\N	1	\N	316	\N	2189	5	\N	1
2267	2007-03-29	\N	\N	f	\N	\N	1	\N	321	\N	2210	5	\N	1
2280	2008-10-16	\N	\N	f	\N	\N	1	\N	331	\N	2229	5	\N	1
2273	2007-10-17	\N	\N	f	\N	\N	1	\N	325	\N	2220	5	\N	1
2367	2010-12-17	\N	\N	f	\N	\N	1	\N	356	2	2314	5	\N	1
2339	2010-07-12	\N	\N	f	\N	\N	1	\N	342	2	2277	5	\N	1
2515	2018-06-12	\N	\N	f	\N	\N	1	\N	364	\N	2464	5	\N	1
2529	2019-03-10	\N	\N	t	Wessex	Earl	1	\N	\N	\N	2489	5	\N	1
2594	2021-01-26	\N	\N	f	\N	\N	1	\N	383	2	2539	5	\N	1
2656	1914-07-27	\N	\N	f	Kitchener of Khartoum	1st Viscount	1	\N	\N	\N	492	5	\N	4
2636	1920-01-28	\N	\N	f	\N	\N	1	\N	6	\N	2578	5	\N	4
2673	1964-06-30	\N	\N	f	\N	\N	1	\N	111	\N	2604	5	\N	1
2688	1976-09-29	\N	\N	f	\N	\N	1	\N	175	\N	2620	5	\N	1
2700	1987-10-15	\N	\N	f	\N	\N	1	\N	211	\N	2631	5	\N	1
2732	2012-01-10	\N	\N	f	\N	\N	1	\N	390	\N	2665	5	\N	1
2871	2011-01-17	\N	\N	f	\N	\N	1	\N	356	2	2790	5	\N	1
2825	1915-05-15	\N	\N	t	Aberdeen	7th Earl 	1	\N	\N	\N	2757	5	2	4
2770	1831-09-10	\N	\N	t	Dunmore	5th Earl 	5	\N	\N	\N	2705	5	2	7
2796	1978-02-07	\N	\N	f	\N	\N	1	\N	179	\N	2724	5	\N	1
2867	1992-02-12	\N	\N	f	\N	\N	1	\N	226	\N	2784	5	\N	1
2976	1974-07-05	\N	\N	f	Delacourt-Smith	Lady	1	\N	162	\N	2617	5	\N	1
2988	1971-06-04	\N	\N	f	\N	\N	1	\N	145	\N	1359	5	\N	1
2960	2016-09-02	\N	\N	f	\N	\N	2	\N	363	1	2488	5	\N	1
6	1801-07-31	\N	\N	f	Saint Helens	1st Lord 	1	\N	\N	\N	7	5	3	11
2898	2006-06-07	\N	\N	f	\N	\N	2	\N	310	1	2815	5	\N	1
140	1828-01-26	\N	\N	t	Rosebery	4th Earl 	1	\N	\N	\N	130	5	2	8
648	1913-11-24	\N	\N	f	Alverstone	1st Lord	1	\N	\N	\N	505	5	\N	4
868	1931-12-05	\N	\N	f	\N	\N	1	\N	31	\N	811	5	\N	4
2208	2005-09-07	\N	\N	f	\N	\N	1	\N	305	\N	2153	5	\N	1
1118	1947-05-01	\N	\N	f	Wavell	1st Viscount	1	\N	\N	\N	935	5	\N	2
1232	1958-10-06	\N	\N	f	Ravensdale	2nd Baroness	1	\N	285	\N	1117	5	\N	1
1469	1973-06-18	\N	\N	f	\N	\N	1	\N	153	\N	1376	5	\N	1
1631	1981-05-29	\N	\N	f	\N	\N	1	\N	190	\N	1555	5	\N	1
1780	1990-05-18	\N	\N	f	\N	\N	1	\N	218	\N	1691	5	\N	1
2335	2010-07-07	\N	\N	f	\N	\N	4	\N	342	6	2271	5	\N	1
2554	2020-09-02	\N	\N	f	\N	\N	1	\N	381	2	2500	5	\N	1
2942	1917-12-20	\N	\N	f	Reading	1st Viscount	1	\N	\N	\N	611	5	\N	4
2593	2021-01-25	\N	\N	f	\N	\N	2	\N	383	1	2538	5	\N	1
2831	1821-07-14	\N	\N	t	Donoughmore	1st Earl 	2	\N	\N	\N	2750	5	3	8
349	1874-02-27	\N	\N	f	Sydney	3rd Viscount	2	\N	\N	\N	328	5	\N	6
964	1936-10-30	\N	\N	f	Dawson of Penn	1st Lord	1	\N	42	\N	697	5	\N	3
1046	1946-01-26	\N	\N	f	Cunningham of Hyndhope	1st Lord	1	\N	65	\N	974	5	\N	2
2667	1955-09-02	\N	\N	f	\N	\N	1	\N	85	\N	2598	5	\N	1
1321	1965-01-01	\N	\N	f	\N	\N	2	\N	115	1	1236	5	\N	1
1397	1968-07-11	\N	\N	f	\N	\N	1	\N	130	\N	1314	5	\N	1
1471	1974-05-08	\N	\N	f	\N	\N	1	\N	159	\N	1390	5	\N	1
1539	1976-06-23	\N	\N	f	\N	\N	1	\N	173	\N	1462	5	\N	1
1610	1980-02-08	\N	\N	f	\N	\N	1	\N	187	\N	1537	5	\N	1
1675	1983-09-27	\N	\N	f	\N	\N	1	\N	200	\N	1599	5	\N	1
1785	1989-02-09	\N	\N	f	\N	\N	1	\N	215	\N	1679	5	\N	1
1834	1992-08-12	\N	\N	f	\N	\N	1	\N	231	\N	1762	5	\N	1
1891	1996-10-04	\N	\N	f	\N	\N	1	\N	253	\N	1825	5	\N	1
2183	2004-01-12	\N	\N	f	\N	\N	2	\N	298	1	2121	5	\N	1
2600	2021-02-04	\N	\N	f	\N	\N	1	\N	383	\N	2550	5	\N	1
702	1918-01-15	\N	\N	f	\N	\N	2	\N	\N	\N	659	5	\N	4
1249	1962-04-13	\N	\N	f	\N	\N	1	\N	102	\N	1168	5	\N	1
1950	1997-10-04	\N	\N	f	\N	\N	2	\N	261	1	1880	5	\N	1
2269	2007-07-09	\N	\N	f	\N	\N	2	\N	323	1	2212	5	\N	1
2542	2019-10-08	\N	\N	f	\N	\N	2	\N	373	1	2478	5	\N	1
762	1921-06-03	\N	\N	f	Chelmsford	3rd Lord	1	\N	\N	\N	710	5	\N	4
3041	1827-06-23	\N	\N	f	Norbury	Lord	\N	LJ, lxiii, 964; CP, v, 566	\N	\N	2942	3	\N	\N
3042	1826-06-27	\N	\N	f	\N	\N	\N	LJ, lxvi, 346; dated 31 July (sic) 1826 in CP, v, 405	\N	\N	2943	3	\N	\N
\.


--
-- Name: letters_patents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_patents_id_seq', 3042, true);


--
-- Data for Name: monarchs; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY monarchs (id, name, date_of_birth, date_of_death, wikidata_id) FROM stdin;
1	Elizabeth II	1926-04-21	\N	Q9682
2	George VI	1895-12-14	1952-02-06	Q280856
3	Edward VIII	1894-06-23	1972-05-28	Q590227
4	George V	1865-06-03	1936-01-20	Q269412
5	Edward VII	1841-11-09	1910-05-06	Q20875
6	Victoria	1819-05-24	1901-01-22	Q9439
7	William IV	1765-08-21	1837-06-20	Q130822
8	George IV	1762-08-12	1830-06-26	Q130586
9	George III	1738-05-24	1820-01-29	Q127318
10	George II	1683-10-30	1760-10-25	Q131981
11	George I	1660-05-28	1727-06-11	Q130805
12	Anne	1665-02-06	1714-08-01	Q119702
13	William III	1650-11-04	1702-03-08	Q129987
14	Mary II	1662-04-30	1694-12-28	Q130812
15	James II	1633-10-14	1701-09-05	Q126188
16	Charles II	1630-05-29	1685-02-06	Q122553
17	Charles I	1600-11-19	1649-01-30	Q81506
18	James I	1566-06-19	1625-03-27	Q79972
\.


--
-- Name: monarchs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('monarchs_id_seq', 18, true);


--
-- Data for Name: peerage_holdings; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerage_holdings (id, ordinality, start_on, end_on, notes, person_id, peerage_id, introduced_on) FROM stdin;
1	1	1801-01-20	1820-08-10	\N	1	3	1801-03-27
2	1	1801-01-21	1828-04-07	\N	2	4	1801-11-27
3	1	1801-05-22	1805-10-21	\N	3	8	1801-10-29
4	1	1801-05-22	1804-03-19	\N	4	9	1801-05-27
5	1	1801-05-28	1821-02-11	\N	5	10	1821-04-09
6	1	1801-06-23	1807-11-14	\N	6	15	1801-10-29
7	1	1801-07-31	1839-02-19	\N	7	17	1802-11-22
8	1	1801-08-18	1805-10-21	\N	3	18	\N
9	1	1801-10-02	1808-02-10	\N	8	19	1801-10-29
10	1	1801-12-15	1823-03-10	\N	9	22	1802-11-17
11	1	1801-12-16	1832-06-29	\N	10	23	1802-06-21
12	1	1802-02-15	1830-01-16	\N	11	24	1802-02-19
13	1	1802-02-27	1820-03-21	\N	12	25	1802-03-08
14	1	1802-04-19	1818-12-13	\N	13	27	1802-04-26
15	1	1802-06-19	1836-08-01	\N	14	28	1836-08-12
16	1	1802-07-28	1840-07-05	\N	15	29	1802-11-22
17	1	1802-07-29	1821-05-30	\N	16	30	1802-11-23
18	1	1802-12-24	1811-05-29	\N	17	31	1803-04-20
19	1	1803-09-17	1823-03-10	\N	9	32	\N
20	1	1804-09-01	1808-02-20	\N	18	35	\N
21	1	1805-01-12	1844-02-15	\N	19	36	1805-01-15
22	1	1805-05-01	1813-06-17	\N	20	37	1805-06-05
23	1	1814-06-01	1823-03-10	\N	21	77	1815-03-20
24	1	1805-11-20	1835-02-28	\N	22	38	1806-01-21
25	1	1805-11-20	1810-03-07	\N	23	39	\N
26	1	1806-02-10	1823-11-17	\N	24	40	1806-02-10
27	1	1806-02-17	1818-07-31	\N	25	41	1806-02-28
28	1	1806-02-20	1809-06-02	\N	26	42	1806-05-02
29	1	1801-01-17	1822-12-22	\N	27	1	1847-07-21
30	1	1806-02-24	1837-06-09	\N	28	45	1806-06-18
31	1	1806-02-25	1829-04-28	\N	29	46	1806-03-04
32	1	1801-11-27	1850-07-08	\N	30	21	1801-12-15
33	1	1801-11-27	1843-04-21	\N	31	20	1805-01-15
34	1	1801-06-23	1805-01-08	\N	32	14	1801-06-30
35	1	1801-06-18	1825-07-30	\N	33	11	1801-10-30
36	1	1801-06-19	1814-05-17	\N	34	12	1801-10-29
37	1	1804-05-14	1839-05-16	\N	35	34	1804-05-18
38	1	1801-06-22	1811-03-01	\N	36	13	1801-06-29
39	1	1801-04-21	1805-01-03	\N	37	6	1801-04-28
40	1	1801-06-26	1814-09-23	\N	38	16	1801-06-29
41	1	1801-02-04	1804-05-01	\N	39	5	1801-05-18
42	1	1806-02-26	1816-10-21	\N	40	47	1806-05-08
43	1	1806-03-13	1806-11-05	\N	41	48	1806-04-25
44	1	1806-04-09	1816-06-17	\N	42	49	1806-06-19
45	1	1806-04-11	1807-11-14	\N	6	51	1806-04-28
46	1	1806-11-12	1846-09-08	\N	43	52	1806-12-15
47	1	1806-11-13	1834-03-29	\N	44	53	1807-01-02
48	1	1806-11-27	1809-01-01	\N	45	54	1807-06-22
49	1	1807-04-20	1842-05-31	\N	46	56	1807-04-24
50	1	1807-11-04	1808-02-20	\N	18	57	1808-01-21
51	1	1807-11-09	1843-06-16	\N	47	58	1808-02-01
52	1	1807-11-09	1833-04-19	\N	48	59	1808-01-21
53	1	1809-09-04	1852-09-14	\N	49	62	1814-06-28
54	1	1812-09-07	1840-10-08	\N	50	65	1812-11-28
55	1	1813-06-14	1825-05-12	\N	51	70	1813-06-16
56	1	1814-05-17	1823-08-27	\N	52	72	1817-04-25
57	1	1814-05-17	1843-12-18	\N	53	73	1815-03-10
58	1	1814-05-17	1865-02-21	\N	54	74	1814-06-01
59	1	1814-05-17	1842-12-10	\N	55	75	1814-06-01
60	1	1814-05-17	1854-01-08	\N	56	76	1814-06-01
61	1	1814-06-01	1833-01-23	\N	57	78	1814-11-08
62	1	1814-07-01	1854-03-06	\N	58	79	1814-07-06
63	1	1814-07-16	1843-06-16	\N	47	80	1814-07-21
64	1	1814-07-16	1860-12-14	\N	59	81	1814-07-27
65	1	1815-08-04	1837-11-24	\N	60	83	1817-02-21
66	1	1815-08-07	1820-07-03	\N	61	84	1816-04-29
67	1	1815-08-11	1853-06-17	\N	62	86	1816-05-24
68	1	1815-08-11	1843-07-03	\N	63	87	1817-07-10
69	1	1815-08-11	1840-03-31	\N	64	88	1817-07-10
70	1	1815-08-11	1844-12-07	\N	65	89	1816-05-24
71	1	1815-08-11	1845-03-10	\N	66	90	1816-02-01
72	1	1806-02-22	1839-09-15	\N	67	44	1806-02-28
73	1	1815-11-25	1825-05-12	\N	51	96	1818-01-27
74	1	1812-09-07	1820-04-03	\N	68	67	1813-02-05
75	1	1809-07-19	1847-12-26	\N	69	61	1810-01-23
76	1	1807-04-07	1844-03-19	\N	70	55	1807-04-09
77	1	1813-02-24	1814-06-21	\N	71	69	1816-03-22
78	1	1812-09-07	1831-04-07	\N	72	66	1812-11-24
79	1	1806-04-10	1809-02-24	\N	73	50	1806-04-25
80	1	1815-11-24	1845-11-17	\N	74	95	1816-02-01
81	1	1812-02-28	1852-09-14	\N	49	63	1814-06-28
82	1	1815-07-04	1854-04-29	\N	75	82	1816-03-11
83	1	1812-09-07	1828-05-24	\N	76	64	1812-11-28
84	1	1812-10-03	1852-09-14	\N	49	68	1814-06-28
85	1	1815-11-27	1853-09-15	\N	77	97	1816-02-01
86	1	1815-12-01	1816-10-21	\N	40	101	1816-05-06
87	1	1816-01-16	1842-12-10	\N	55	102	\N
88	1	1816-10-25	1833-05-04	\N	78	103	1833-05-15
89	1	1816-11-27	1865-02-12	\N	79	104	1817-01-28
90	1	1816-12-10	1833-01-23	\N	57	105	1817-01-28
91	1	1817-06-03	1829-05-08	\N	80	107	1817-07-03
92	1	1821-07-16	1870-05-12	\N	81	111	1822-03-14
93	1	1821-07-17	1841-01-05	\N	82	113	1822-02-05
94	1	1821-07-17	1824-04-27	\N	83	114	1822-03-07
95	1	1821-07-17	1832-12-28	\N	84	115	1833-02-04
96	1	1827-07-24	1858-12-01	\N	85	154	1828-01-29
97	1	1821-07-17	1838-05-18	\N	86	116	1822-03-20
98	1	1821-07-17	1853-06-28	\N	87	117	1822-04-26
99	1	1821-07-17	1870-03-20	\N	88	118	1822-02-05
100	1	1821-07-17	1839-10-18	\N	89	119	1824-03-29
101	1	1821-07-17	1835-05-24	\N	90	120	1824-06-22
102	1	1821-07-17	1837-10-12	\N	91	121	1822-04-01
103	1	1821-07-17	1845-02-22	\N	92	122	1822-02-05
104	1	1821-07-17	1836-01-28	\N	93	124	1822-02-05
105	1	1821-07-17	1855-03-07	\N	94	125	1822-02-06
106	1	1821-07-17	1855-10-30	\N	95	126	1822-05-20
107	1	1821-07-17	1828-05-23	\N	96	127	1822-05-30
108	1	1821-07-18	1836-09-01	\N	97	129	1837-01-31
109	1	1823-03-01	1851-02-08	\N	98	131	1823-03-05
110	1	1823-04-22	1854-01-08	\N	56	132	1823-04-25
111	1	1823-07-08	1854-03-06	\N	99	133	1823-07-16
112	1	1823-12-08	1837-11-24	\N	100	134	1827-03-07
113	1	1815-08-12	1846-01-08	\N	101	93	1816-02-01
114	1	1826-07-03	1846-08-21	\N	102	138	1827-02-27
115	1	1826-07-04	1874-04-10	\N	103	139	1826-07-04
116	1	1826-07-05	1869-12-15	\N	104	140	1827-02-27
117	1	1826-07-06	1840-04-26	\N	105	141	1827-03-05
118	1	1815-11-30	1825-09-07	\N	106	100	1816-02-02
119	1	1821-07-07	1838-01-13	\N	107	108	1821-07-09
120	1	1821-07-14	1841-12-29	\N	108	109	1822-03-18
121	1	1815-11-29	1840-03-14	\N	109	99	1816-06-06
122	1	1815-11-28	1823-11-17	\N	110	98	1816-02-16
123	1	1821-07-18	1827-08-27	\N	111	128	1822-02-05
124	1	1821-07-17	1856-01-04	\N	112	112	1822-02-05
125	1	1826-06-30	1859-02-15	\N	113	137	1826-11-28
126	1	1817-02-13	1826-11-28	\N	114	106	1825-06-03
127	1	1826-07-08	1838-01-17	\N	115	142	1826-11-14
128	1	1826-07-10	1827-06-18	\N	116	143	1834-05-30
129	1	1826-07-12	1845-12-19	\N	117	144	1826-11-20
130	1	1826-07-14	1841-07-16	\N	118	145	1826-11-14
131	1	1826-12-19	1857-03-13	\N	119	147	1829-02-05
132	1	1827-02-08	1865-02-21	\N	54	148	1830-06-03
133	1	1827-04-25	1863-10-12	\N	120	149	1827-05-02
134	1	1827-04-28	1859-01-28	\N	121	150	1827-05-02
135	1	1827-04-28	1857-03-09	\N	122	151	1827-05-07
136	1	1827-04-30	1832-11-04	\N	123	152	1827-05-02
137	1	1827-05-01	1854-01-05	\N	124	153	1827-05-02
138	1	1827-10-06	1860-11-07	\N	125	157	1828-01-29
139	1	1828-01-21	1847-04-27	\N	126	158	1831-09-05
140	1	1828-01-22	1837-03-15	\N	127	159	1837-04-24
141	1	1828-01-22	1845-11-06	\N	128	160	1828-01-29
142	1	1828-01-23	1860-05-31	\N	129	161	1828-03-28
143	1	1828-01-26	1868-03-04	\N	130	162	1828-03-07
144	1	1828-01-28	1879-10-07	\N	131	163	1828-01-29
145	1	1828-01-29	1840-07-28	\N	132	164	1828-01-31
146	1	1828-01-30	1853-04-03	\N	133	165	1828-02-05
147	1	1828-02-02	1844-02-23	\N	134	166	1828-02-08
148	1	1829-06-05	1845-03-03	\N	135	167	1829-06-11
149	1	1830-11-22	1868-05-07	\N	136	168	1830-11-23
150	1	1831-06-17	1846-04-19	\N	137	170	1831-06-20
151	1	1831-06-20	1836-07-30	\N	138	171	1831-06-20
152	1	1831-06-20	1838-11-20	\N	139	172	1831-06-20
153	1	1831-06-20	1854-12-31	\N	140	173	1831-06-24
154	1	1831-06-20	1878-01-07	\N	141	174	1831-06-20
155	1	1831-06-20	1833-07-10	\N	142	175	1831-06-20
156	1	1831-09-10	1870-12-06	\N	143	178	1831-09-14
157	1	1831-09-10	1851-03-15	\N	144	179	1831-09-14
158	1	1831-09-10	1842-04-16	\N	145	181	1831-09-26
159	1	1825-01-26	1855-05-29	\N	146	136	1825-02-03
160	1	1831-09-10	1839-07-26	\N	147	183	1831-09-14
161	1	1831-09-10	1852-04-13	\N	148	184	1831-09-13
162	1	1831-09-10	1864-09-15	\N	149	185	1831-09-14
163	1	1831-09-10	1858-12-19	\N	150	186	1831-09-13
164	1	1831-09-10	1834-04-10	\N	151	187	1831-10-03
165	1	1831-09-10	1854-04-03	\N	152	188	1831-10-03
166	1	1827-10-05	1833-03-06	\N	153	156	1828-01-29
167	1	1831-06-04	1842-03-20	\N	154	169	1831-06-15
168	1	1831-09-10	1846-09-08	\N	43	176	1831-10-13
169	1	1827-10-05	1842-01-29	\N	155	155	1828-01-29
170	1	1831-09-10	1837-09-26	\N	156	190	1831-09-17
171	1	1831-09-10	1852-02-10	\N	157	191	1831-09-10
172	1	1831-09-14	1853-10-28	\N	158	195	1831-09-15
173	1	1831-09-15	1836-10-09	\N	159	197	1831-09-15
174	1	1832-05-14	1850-02-15	\N	160	198	1832-05-18
175	1	1832-05-15	1884-03-12	\N	161	199	1833-02-04
176	1	1832-05-16	1832-06-30	\N	162	200	1832-05-21
177	1	1832-12-22	1851-06-30	\N	163	201	1833-02-04
178	1	1833-01-28	1844-11-04	\N	164	203	1833-02-04
179	1	1833-05-10	1846-01-08	\N	165	207	1833-05-18
180	1	1833-06-07	1837-12-03	\N	166	208	1833-06-10
181	1	1834-03-28	1854-09-22	\N	167	209	1834-04-01
182	1	1834-06-03	1870-08-09	\N	168	210	\N
183	1	1834-07-19	1847-05-16	\N	169	211	1834-07-22
184	1	1835-01-12	1844-04-07	\N	170	213	1835-02-20
185	1	1835-01-13	1851-03-04	\N	171	214	1835-02-20
186	1	1835-03-10	1845-07-21	\N	172	215	1835-04-03
187	1	1835-04-10	1848-05-12	\N	173	216	1835-05-12
188	1	1835-05-08	1866-04-23	\N	174	217	1835-05-12
189	1	1835-05-11	1863-05-04	\N	175	218	1835-06-01
190	1	1835-05-12	1860-06-03	\N	176	219	1835-05-15
191	1	1835-06-13	1849-03-27	\N	177	220	1835-06-30
192	1	1836-01-20	1851-04-29	\N	178	221	1836-02-04
193	1	1836-01-22	1860-03-25	\N	179	222	1860-04-19
194	1	1836-01-23	1851-04-18	\N	180	223	1836-02-04
195	1	1837-01-27	1888-11-19	\N	181	225	1837-03-14
196	1	1837-01-28	1875-06-28	\N	182	227	1837-01-31
197	1	1831-09-10	1868-12-22	\N	183	182	1833-06-28
198	1	1838-07-05	1844-07-11	\N	184	236	1838-07-17
199	1	1838-07-06	1857-05-30	\N	185	237	1838-07-09
200	1	1838-07-07	1842-08-10	\N	186	238	1839-02-05
201	1	1838-07-09	1856-06-02	\N	187	239	1838-07-10
202	1	1838-07-10	1855-05-16	\N	188	240	1838-07-10
203	1	1833-01-28	1833-07-19	\N	189	202	1833-02-04
204	1	1837-01-28	1840-06-22	\N	190	226	1837-01-31
205	1	1833-03-23	1840-07-28	\N	132	205	1833-06-03
206	1	1837-01-27	1845-02-13	\N	191	224	1837-04-21
207	1	1831-09-15	1854-03-18	\N	192	196	1831-09-15
208	1	1838-06-30	1893-12-29	\N	193	234	1838-07-03
209	1	1838-07-02	1839-02-19	\N	194	235	1838-07-04
210	1	1831-09-12	1834-03-29	\N	44	192	1831-09-15
211	1	1831-09-13	1845-02-17	\N	195	194	1831-09-13
212	1	1838-07-11	1841-03-16	\N	196	241	1838-07-12
213	1	1838-07-12	1858-02-10	\N	197	242	1838-07-13
214	1	1838-07-13	1849-09-11	\N	198	243	1838-07-16
215	1	1839-04-20	1855-02-21	\N	199	244	1842-02-02
216	1	1839-05-08	1849-10-29	\N	200	246	1839-05-13
217	1	1839-05-09	1850-10-02	\N	201	247	1839-05-13
218	1	1839-05-11	1850-09-27	\N	202	249	1839-05-30
219	1	1839-05-13	1852-05-09	\N	203	250	1839-05-16
220	1	1839-05-14	1847-04-30	\N	204	251	1839-05-31
221	1	1839-05-15	1854-05-03	\N	205	252	1839-05-16
222	1	1839-05-16	1856-09-29	\N	206	253	1839-05-27
223	1	1839-06-07	1858-04-17	\N	207	254	1840-01-16
224	1	1839-09-05	1866-02-07	\N	208	255	1840-01-16
225	1	1839-12-14	1863-04-17	\N	209	256	1840-01-16
226	1	1839-12-23	1844-08-26	\N	210	258	1840-06-29
227	1	1840-08-19	1841-09-19	\N	211	260	\N
228	1	1841-08-16	1853-01-10	\N	212	263	1842-05-12
229	1	1841-08-17	1857-10-10	\N	213	264	1841-08-24
230	1	1841-08-17	1853-10-31	\N	214	265	1843-02-16
231	1	1841-08-18	1883-10-20	\N	215	266	1841-08-19
232	1	1841-08-19	1842-08-20	\N	216	267	1841-08-19
233	1	1841-08-20	1842-06-08	\N	217	268	1841-08-23
234	1	1842-09-27	1842-12-10	\N	55	270	1843-02-02
235	1	1837-01-30	1845-07-22	\N	218	229	1837-01-31
236	1	1837-02-13	1863-12-26	\N	219	230	1864-02-04
237	1	1837-08-11	1879-04-23	\N	220	231	1837-12-14
238	1	1847-09-18	1864-06-15	\N	221	277	1848-04-11
239	1	1847-09-20	1897-05-12	\N	222	278	1848-02-03
240	1	1847-09-21	1857-01-03	\N	223	279	1847-11-18
241	1	1849-06-15	1869-03-02	\N	224	281	1850-03-04
242	1	1849-11-13	1863-11-20	\N	225	283	1854-01-31
243	1	1840-04-10	1873-08-01	\N	226	259	\N
244	1	1839-12-21	1849-01-01	\N	227	257	1843-02-02
245	1	1846-07-06	1857-02-18	\N	228	275	1847-02-01
246	1	1841-08-16	1866-06-10	\N	229	262	1841-08-24
247	1	1847-09-18	1860-06-03	\N	176	276	1847-11-23
248	1	1837-01-30	1846-09-05	\N	230	228	1837-01-31
249	1	1849-08-25	1860-12-22	\N	231	282	\N
250	1	1838-06-25	1863-07-28	\N	232	233	1838-06-29
251	1	1841-12-08	1910-05-06	\N	233	269	1863-02-05
252	1	1850-03-04	1860-01-15	\N	234	286	1850-03-07
253	1	1850-03-05	1883-11-17	\N	235	287	1850-03-07
254	1	1850-07-15	1855-11-11	\N	236	289	1850-07-15
255	1	1850-12-20	1868-07-26	\N	237	290	1851-02-04
256	1	1851-02-26	1869-06-03	\N	238	291	1851-02-28
257	1	1851-04-05	1856-09-29	\N	206	292	1857-05-11
258	1	1852-03-01	1875-01-29	\N	239	293	1852-03-04
259	1	1852-05-01	1880-08-14	\N	240	294	1852-11-08
260	1	1852-10-20	1855-06-28	\N	241	295	1852-11-08
261	1	1856-01-16	1868-02-25	\N	242	296	\N
262	1	1856-02-26	1867-09-06	\N	243	297	1856-04-29
263	1	1856-03-12	1871-12-26	\N	244	298	1856-05-20
264	1	1856-06-25	1858-11-23	\N	245	299	1856-06-27
265	1	1856-07-23	1868-02-25	\N	242	300	1856-07-25
266	1	1856-08-29	1880-06-30	\N	246	301	1857-02-03
267	1	1856-11-19	1883-04-14	\N	247	302	1857-02-12
268	1	1857-04-11	1884-07-15	\N	248	303	1857-06-05
269	1	1857-04-11	1888-12-28	\N	249	304	1857-05-01
270	1	1857-09-15	1893-11-18	\N	250	305	1858-02-04
271	1	1857-09-16	1859-12-28	\N	251	306	1857-12-03
272	1	1858-03-01	1878-10-05	\N	252	309	1858-03-12
273	1	1858-08-02	1871-09-04	\N	253	310	1859-02-03
274	1	1858-08-14	1881-02-18	\N	254	311	1859-05-31
275	1	1858-08-16	1863-08-14	\N	255	312	1860-07-30
276	1	1858-08-28	1867-10-07	\N	256	313	1859-02-03
277	1	1859-04-14	1869-03-18	\N	257	314	1859-06-07
278	1	1859-04-15	1883-02-21	\N	258	315	1859-06-03
279	1	1846-04-25	1869-03-02	\N	224	273	\N
280	1	1846-05-02	1856-09-24	\N	259	274	1848-03-20
281	1	1859-06-28	1873-11-10	\N	260	320	1859-07-04
282	1	1859-06-29	1867-04-27	\N	261	321	1859-07-04
283	1	1859-08-18	1869-07-13	\N	262	322	1860-01-24
284	1	1861-01-15	1861-08-02	\N	263	326	1861-02-05
285	1	1861-06-27	1873-07-20	\N	264	327	1861-06-27
286	1	1861-07-30	1878-05-28	\N	265	328	1861-07-30
287	1	1861-08-05	1867-10-17	\N	266	329	1861-08-06
288	1	1850-01-17	1910-05-06	\N	233	284	\N
289	1	1860-02-17	1885-05-07	\N	267	323	1860-03-01
290	1	1859-06-23	1861-10-04	\N	268	319	1860-03-08
291	1	1863-06-19	1885-11-28	\N	269	331	\N
292	1	1863-08-19	1873-09-01	\N	270	332	1864-02-04
293	1	1863-08-20	1885-08-11	\N	271	333	1864-02-04
294	1	1864-04-27	1870-01-01	\N	272	334	1870-02-08
295	1	1866-01-03	1874-12-23	\N	273	335	1866-02-05
296	1	1866-01-04	1866-09-06	\N	274	336	1866-02-05
297	1	1866-02-21	1885-08-08	\N	275	337	1866-02-22
298	1	1866-05-01	1881-03-28	\N	276	338	1869-02-18
299	1	1866-05-02	1887-07-29	\N	277	339	1866-06-01
300	1	1866-05-03	1873-12-07	\N	278	340	1866-06-22
301	1	1866-06-12	1871-10-06	\N	279	343	1866-06-25
302	1	1866-07-12	1894-11-29	\N	280	345	1867-02-05
303	1	1866-07-13	1870-04-16	\N	281	346	1866-07-23
304	1	1866-07-14	1873-01-18	\N	282	347	1866-07-26
305	1	1866-07-16	1876-06-01	\N	283	348	1866-07-26
306	1	1866-07-31	1885-10-16	\N	284	349	1866-08-06
307	1	1866-08-03	1886-03-31	\N	285	350	1866-08-06
308	1	1867-02-26	1874-01-31	\N	286	352	1867-03-01
309	1	1867-02-27	1885-04-02	\N	287	353	1867-03-01
310	1	1868-04-15	1874-12-17	\N	288	354	1868-05-05
311	1	1868-04-16	1881-02-03	\N	289	355	1868-05-15
312	1	1868-04-17	1875-12-06	\N	290	356	1868-05-05
313	1	1868-04-18	1883-04-18	\N	291	357	1868-06-16
314	1	1859-05-21	1862-06-17	\N	292	317	\N
315	1	1859-05-21	1860-07-19	\N	293	318	\N
316	1	1868-11-30	1872-12-15	\N	294	361	\N
317	1	1868-12-08	1876-09-28	\N	295	362	1869-03-02
318	1	1868-12-09	1881-07-10	\N	296	363	1868-12-15
319	1	1869-04-06	1899-12-09	\N	297	365	1869-04-23
320	1	1869-06-29	1916-10-02	\N	298	366	1869-07-02
321	1	1869-12-08	1924-06-05	\N	299	368	1870-02-08
322	1	1869-12-09	1883-12-01	\N	300	369	1870-02-08
323	1	1869-12-10	1883-01-22	\N	301	370	1870-02-08
324	1	1869-12-11	1902-06-19	\N	302	371	1870-06-23
325	1	1869-12-14	1873-07-24	\N	303	373	1870-04-28
326	1	1866-05-24	1900-07-30	\N	304	341	1866-06-08
327	1	1866-07-12	1897-05-12	\N	222	344	1866-07-26
328	1	1866-06-01	1902-04-08	\N	305	342	1866-07-23
329	1	1869-12-15	1883-01-25	\N	306	374	1870-02-08
330	1	1870-05-03	1887-02-10	\N	307	375	1870-06-13
331	1	1870-06-14	1885-02-01	\N	308	376	1870-06-21
332	1	1870-10-26	1876-10-06	\N	309	377	1872-07-08
333	1	1871-03-23	1872-05-23	\N	310	378	1871-03-31
334	1	1871-03-28	1876-06-23	\N	311	379	1871-05-12
335	1	1871-06-09	1906-12-30	\N	312	380	\N
336	1	1871-08-07	1879-08-17	\N	313	382	1872-02-15
337	1	1871-11-04	1889-11-21	\N	314	383	1872-02-15
338	1	1872-02-13	1873-03-07	\N	315	385	1872-02-13
339	1	1872-07-16	1898-12-19	\N	316	386	1872-08-01
340	1	1872-10-01	1881-03-08	\N	317	387	1873-02-06
341	1	1872-10-23	1895-05-04	\N	318	388	1873-02-06
342	1	1873-03-25	1922-10-19	\N	319	389	1874-03-19
343	1	1873-03-28	1888-11-19	\N	181	390	1873-05-06
344	1	1873-04-09	1896-12-19	\N	320	391	1873-05-12
345	1	1873-04-10	1886-02-05	\N	321	392	1873-05-06
346	1	1873-06-12	1873-06-19	\N	322	393	\N
347	1	1873-08-23	1895-02-25	\N	323	394	1874-03-10
348	1	1874-01-08	1880-10-08	\N	324	395	1874-05-07
349	1	1874-01-09	1895-04-27	\N	325	396	1874-04-20
350	1	1874-01-10	1894-06-14	\N	326	397	1874-04-23
351	1	1874-01-12	1894-04-20	\N	327	398	1874-03-19
352	1	1874-02-27	1890-02-14	\N	328	400	1874-03-20
353	1	1868-07-17	1890-01-14	\N	329	359	1868-07-27
354	1	1874-03-06	1886-02-15	\N	330	404	1874-03-10
355	1	1874-03-06	1880-04-09	\N	331	405	1874-03-10
356	1	1874-03-16	1892-07-11	\N	332	406	1874-03-19
357	1	1875-06-11	1881-07-04	\N	333	409	1875-06-15
358	1	1875-06-12	1880-07-20	\N	334	410	1875-06-21
359	1	1875-06-14	1885-01-18	\N	335	411	1875-06-15
360	1	1876-01-13	1885-10-03	\N	336	413	1886-01-21
361	1	1876-01-14	1876-06-15	\N	337	415	1876-02-08
362	1	1876-01-13	1903-09-27	\N	338	412	1904-07-11
363	1	1874-02-27	1899-12-22	\N	339	399	1874-03-26
364	1	1871-11-13	1902-02-12	\N	340	384	1872-02-06
365	1	1868-07-25	1915-01-13	\N	341	360	1868-12-15
366	1	1876-01-14	1915-12-12	\N	342	414	1876-02-10
367	1	1871-06-23	1900-07-09	\N	343	381	1871-06-26
368	1	1876-01-15	1904-02-17	\N	344	417	1876-02-17
369	1	1876-01-17	1890-12-09	\N	345	418	1876-02-08
370	1	1876-01-18	1887-03-15	\N	346	419	1876-02-08
371	1	1876-10-02	1888-10-01	\N	347	422	1877-02-08
372	1	1876-10-17	1879-08-21	\N	348	424	1876-11-21
373	1	1876-11-29	1881-09-13	\N	349	425	1877-02-08
374	1	1878-04-16	1905-03-28	\N	350	427	1878-05-14
375	1	1878-05-04	1906-10-30	\N	351	428	1878-05-14
376	1	1878-09-27	1885-04-02	\N	287	429	1878-12-06
377	1	1880-04-17	1886-11-07	\N	352	430	1880-05-07
378	1	1880-04-23	1893-08-07	\N	353	431	\N
379	1	1880-04-28	1899-09-14	\N	354	433	1880-05-07
380	1	1880-04-29	1883-03-22	\N	355	434	1880-05-13
381	1	1880-04-30	1914-02-22	\N	356	435	1880-05-07
382	1	1880-05-01	1915-01-20	\N	357	436	1880-05-25
383	1	1880-05-03	1890-02-15	\N	358	438	1880-05-20
384	1	1880-05-04	1894-09-10	\N	359	439	1880-05-27
385	1	1880-05-04	1895-07-24	\N	360	440	1880-05-20
386	1	1880-05-05	1894-12-25	\N	361	441	1880-06-07
387	1	1880-05-06	1903-11-09	\N	362	442	1880-05-13
388	1	1880-05-25	1892-07-27	\N	363	443	1880-05-27
389	1	1874-03-02	1890-12-03	\N	364	402	1874-03-06
390	1	1874-03-05	1890-04-29	\N	365	403	1874-06-02
391	1	1881-03-11	1884-08-25	\N	366	446	1881-07-05
392	1	1881-10-06	1911-11-25	\N	367	448	1882-02-07
393	1	1881-10-07	1909-03-09	\N	368	449	1882-03-09
394	1	1881-10-08	1921-08-01	\N	369	450	1882-02-07
395	1	1881-10-10	1916-03-01	\N	370	451	1882-07-13
396	1	1881-10-11	1926-10-29	\N	371	452	1882-02-07
397	1	1881-10-12	1894-03-04	\N	372	453	1882-02-07
398	1	1882-02-03	1892-05-09	\N	373	455	1882-04-24
399	1	1882-06-23	1889-10-16	\N	374	456	1882-06-27
400	1	1882-11-24	1895-03-30	\N	375	457	1883-04-12
401	1	1882-11-25	1913-03-25	\N	376	458	1883-02-15
402	1	1884-01-24	1892-10-06	\N	377	460	1884-03-11
403	1	1880-04-28	1891-11-24	\N	378	432	1881-01-06
404	1	1876-06-10	1904-11-15	\N	379	420	1876-06-15
405	1	1877-01-03	1886-05-02	\N	380	426	1877-02-08
406	1	1882-12-30	1895-05-04	\N	318	459	1883-02-15
407	1	1884-03-04	1892-03-14	\N	381	461	1884-05-20
408	1	1884-11-04	1897-05-25	\N	382	463	1884-11-11
409	1	1884-11-05	1893-02-04	\N	383	464	1884-11-11
410	1	1884-11-07	1901-03-14	\N	384	465	1884-11-11
411	1	1884-11-08	1903-07-06	\N	385	466	1884-11-11
412	1	1884-11-10	1908-10-05	\N	386	467	1884-11-13
413	1	1885-06-26	1921-12-11	\N	387	468	1885-06-26
414	1	1885-06-27	1904-06-05	\N	388	469	1885-07-13
415	1	1885-06-28	1898-11-27	\N	389	470	1885-07-13
416	1	1885-06-29	1915-03-31	\N	390	471	1885-07-09
417	1	1885-06-30	1897-07-17	\N	391	472	1885-07-07
418	1	1885-07-01	1886-10-27	\N	392	473	1885-07-07
419	1	1885-07-02	1904-12-06	\N	393	474	1885-07-13
420	1	1885-07-03	1905-07-22	\N	394	476	1885-07-07
421	1	1885-07-04	1913-05-22	\N	395	477	1885-07-06
422	1	1885-07-06	1893-01-20	\N	396	478	1885-07-06
423	1	1885-07-23	1901-06-10	\N	397	481	1885-07-28
424	1	1885-07-24	1899-05-24	\N	398	482	1885-07-27
425	1	1885-09-28	1913-03-25	\N	376	483	1886-01-19
426	1	1885-11-18	1890-12-01	\N	399	484	1886-01-19
427	1	1885-12-29	1905-11-04	\N	400	485	1886-01-19
428	1	1880-05-25	1888-10-17	\N	401	444	1880-05-27
429	1	1880-05-26	1893-02-06	\N	402	445	1880-05-27
430	1	1886-02-15	1898-04-03	\N	403	489	1886-02-18
431	1	1886-02-16	1887-04-03	\N	404	490	1886-02-25
432	1	1886-03-22	1912-05-18	\N	405	492	1886-04-01
433	1	1886-03-23	1896-10-07	\N	406	493	1886-04-01
434	1	1886-05-11	1886-05-17	\N	407	494	\N
435	1	1886-08-13	1898-04-16	\N	408	495	1886-08-19
436	1	1886-08-13	1909-02-01	\N	409	496	1886-08-19
437	1	1886-08-14	1900-10-15	\N	410	497	1887-01-27
438	1	1886-08-16	1918-02-23	\N	411	498	1886-08-19
439	1	1886-08-17	1907-02-04	\N	412	499	1886-08-19
440	1	1886-08-19	1914-01-08	\N	413	500	1886-09-02
441	1	1886-08-27	1908-06-14	\N	414	501	1886-09-02
442	1	1886-09-09	1905-01-09	\N	415	502	1887-07-12
443	1	1885-07-03	1887-01-12	\N	416	475	1885-07-06
444	1	1885-07-11	1922-10-19	\N	319	479	1885-07-14
445	1	1887-01-25	1913-02-17	\N	417	503	1887-01-27
446	1	1887-05-12	1902-09-03	\N	418	504	1892-06-23
447	1	1887-07-01	1904-02-16	\N	419	506	1887-07-11
448	1	1887-07-02	1931-03-07	\N	420	507	1887-07-12
449	1	1887-07-04	1908-05-14	\N	421	508	1887-07-12
450	1	1887-07-05	1890-06-27	\N	422	509	1887-07-15
451	1	1887-07-06	1900-12-27	\N	423	510	1887-07-29
452	1	1887-07-07	1894-10-22	\N	424	511	1887-07-12
453	1	1887-07-08	1887-08-09	\N	425	512	1888-04-17
454	1	1887-07-09	1891-10-02	\N	426	513	1887-07-11
455	1	1887-07-22	1889-08-28	\N	427	514	1887-07-25
456	1	1888-02-23	1914-01-29	\N	428	515	1888-02-28
457	1	1888-10-27	1896-11-28	\N	429	516	1888-11-13
458	1	1890-04-14	1907-01-23	\N	430	520	1890-04-28
459	1	1891-01-20	1893-12-31	\N	431	522	1891-01-22
460	1	1891-01-28	1894-03-29	\N	432	524	1891-01-29
461	1	1891-07-15	1906-02-02	\N	433	526	1891-07-27
462	1	1891-08-14	1920-09-05	\N	434	527	\N
463	1	1891-11-11	1913-08-13	\N	435	528	1914-02-11
464	1	1885-12-31	1903-07-01	\N	436	487	1886-01-19
465	1	1886-02-08	1899-03-01	\N	437	488	1886-02-08
466	1	1892-06-18	1902-01-15	\N	438	534	1892-06-20
467	1	1892-06-20	1917-01-29	\N	439	535	1893-07-24
468	1	1892-08-20	1904-03-06	\N	440	536	1892-12-05
469	1	1892-08-22	1917-02-26	\N	441	539	1893-01-31
470	1	1892-08-23	1895-12-19	\N	442	541	1893-04-20
471	1	1892-08-24	1908-07-08	\N	443	542	1893-05-18
472	1	1892-08-25	1908-02-05	\N	444	543	1893-01-31
473	1	1892-08-26	1909-01-16	\N	445	544	1893-01-31
474	1	1892-08-27	1898-12-15	\N	446	545	1893-02-07
475	1	1892-08-29	1895-12-11	\N	447	546	1893-05-15
476	1	1892-08-30	1912-09-24	\N	448	547	1893-01-31
477	1	1890-05-24	1892-01-14	\N	449	521	1890-06-23
478	1	1889-07-29	1912-01-29	\N	450	518	1890-02-13
479	1	1892-05-24	1936-01-20	\N	451	533	1892-06-17
480	1	1892-08-22	1906-10-30	\N	452	538	1893-01-31
481	1	1887-07-01	1900-04-19	\N	453	505	1887-07-12
482	1	1888-11-17	1902-02-12	\N	340	517	1889-02-21
483	1	1892-08-22	1929-03-11	\N	454	537	1893-01-31
484	1	1892-09-03	1898-05-29	\N	455	548	1893-01-31
485	1	1892-09-05	1907-11-27	\N	456	549	1893-01-31
486	1	1893-06-09	1894-11-28	\N	457	550	1893-06-19
487	1	1893-06-22	1899-10-11	\N	458	551	1893-07-07
488	1	1893-06-23	1908-02-15	\N	459	552	1893-07-04
489	1	1893-06-26	1894-10-19	\N	460	554	1893-07-04
490	1	1893-08-21	1912-01-30	\N	461	555	1893-09-05
491	1	1893-09-23	1894-04-10	\N	462	556	1893-11-09
492	1	1894-03-30	1913-06-04	\N	463	557	1894-04-23
493	1	1894-04-16	1915-10-29	\N	464	558	1894-04-23
494	1	1894-05-07	1900-08-10	\N	465	559	1894-05-28
495	1	1894-08-13	1907-02-20	\N	466	560	1894-08-14
496	1	1895-05-09	1912-10-24	\N	467	561	1896-02-11
497	1	1895-07-16	1928-06-13	\N	468	562	1896-02-11
498	1	1895-07-18	1900-06-20	\N	469	564	1895-08-13
499	1	1895-07-19	1912-02-10	\N	470	565	1895-08-13
500	1	1895-07-25	1930-05-27	\N	471	566	1897-03-25
501	1	1895-08-03	1914-01-29	\N	428	567	1895-08-13
502	1	1895-08-03	1921-05-06	\N	472	568	1896-02-11
503	1	1895-08-05	1913-04-03	\N	473	569	1895-08-13
504	1	1895-08-05	1911-08-18	\N	474	570	1896-02-11
505	1	1895-11-14	1919-08-22	\N	475	571	1896-02-11
506	1	1895-11-15	1903-01-09	\N	476	572	1896-02-11
507	1	1895-11-16	1908-11-24	\N	477	573	1896-02-11
508	1	1892-02-23	1907-12-17	\N	478	531	1892-02-25
509	1	1896-06-17	1906-08-04	\N	479	578	\N
510	1	1896-08-11	1897-10-28	\N	480	579	1896-08-13
511	1	1897-02-05	1917-12-20	\N	481	580	1897-03-25
512	1	1897-02-06	1912-02-10	\N	482	581	1897-02-23
513	1	1897-07-22	1909-03-16	\N	483	582	1898-05-12
514	1	1897-07-23	1915-12-13	\N	484	583	1898-02-15
515	1	1897-07-24	1924-01-21	\N	485	584	1898-02-08
516	1	1897-07-26	1899-12-25	\N	486	585	1897-08-05
517	1	1897-07-27	1898-03-06	\N	487	586	1909-07-05
518	1	1897-07-28	1901-02-12	\N	488	587	1897-07-30
519	1	1897-11-11	1899-05-24	\N	398	589	1898-02-08
520	1	1897-11-29	1909-02-01	\N	409	590	1963-07-17
521	1	1898-01-20	1923-08-30	\N	489	593	1898-02-08
522	1	1898-06-11	1917-03-30	\N	490	594	1898-07-01
523	1	1898-06-13	1907-04-21	\N	491	595	1898-06-20
524	1	1898-01-19	1921-12-11	\N	387	591	1898-02-08
525	1	1898-11-01	1916-06-05	\N	492	596	1899-07-25
526	1	1899-01-25	1917-01-29	\N	439	597	1899-07-25
527	1	1899-01-25	1906-05-12	\N	493	598	1899-06-27
528	1	1899-01-26	1906-01-06	\N	494	599	1899-02-07
529	1	1899-01-27	1907-10-06	\N	495	600	1899-02-07
530	1	1899-01-28	1902-10-13	\N	496	601	1899-02-07
531	1	1899-08-02	1925-03-02	\N	497	602	1925-07-08
532	1	1899-08-22	1902-05-24	\N	498	603	1899-10-26
533	1	1899-11-14	1909-02-02	\N	499	605	1899-11-16
534	1	1900-01-20	1911-09-29	\N	500	606	1900-01-30
535	1	1900-01-22	1913-05-28	\N	501	607	1900-01-30
536	1	1900-05-10	1921-12-09	\N	502	608	1900-05-14
537	1	1900-06-15	1901-09-08	\N	503	609	1902-01-16
538	1	1900-06-16	1914-09-07	\N	504	610	1900-06-25
539	1	1900-06-18	1915-12-15	\N	505	611	1900-06-18
540	1	1900-12-18	1907-02-07	\N	506	613	1901-02-14
541	1	1900-12-19	1904-11-28	\N	507	614	1901-02-14
542	1	1901-02-11	1914-11-14	\N	508	615	1901-02-14
543	1	1901-06-03	1925-05-13	\N	509	616	1901-06-13
544	1	1896-01-31	1907-09-13	\N	510	575	1896-02-11
545	1	1896-06-08	1922-08-10	\N	511	576	1896-06-26
546	1	1902-07-15	1925-05-13	\N	509	622	1905-07-27
547	1	1902-07-15	1905-01-22	\N	512	623	1902-08-07
548	1	1902-07-16	1939-12-20	\N	513	624	1904-02-02
549	1	1902-07-17	1917-04-04	\N	514	625	1902-07-21
550	1	1902-07-18	1925-02-22	\N	515	626	1902-07-29
551	1	1902-07-19	1925-01-27	\N	516	627	1902-07-22
552	1	1902-07-21	1924-08-15	\N	517	628	1902-08-07
553	1	1903-07-31	1916-01-09	\N	518	631	1903-08-06
554	1	1903-08-01	1923-04-06	\N	519	632	1903-08-06
555	1	1903-08-03	1915-01-12	\N	520	633	1903-08-06
556	1	1903-08-04	1941-10-16	\N	521	634	1904-02-25
557	1	1905-02-23	1905-04-09	\N	522	635	\N
558	1	1905-03-09	1942-08-21	\N	523	636	1905-04-04
559	1	1905-07-06	1909-11-06	\N	524	637	1905-07-18
560	1	1905-12-18	1927-10-07	\N	525	639	1906-02-13
561	1	1905-12-18	1923-03-06	\N	526	638	1906-02-13
562	1	1902-10-27	1908-02-29	\N	527	630	1904-03-14
563	1	1905-12-18	1925-11-14	\N	528	640	1906-02-13
564	1	1908-07-04	1912-03-25	\N	529	679	1909-06-29
565	1	1905-12-19	1922-09-26	\N	530	641	1906-02-13
566	1	1905-12-19	1932-03-13	\N	531	642	1906-02-13
567	1	1905-12-20	1923-03-21	\N	532	643	1906-02-13
568	1	1905-12-22	1906-01-09	\N	533	645	1906-06-18
569	1	1905-12-23	1925-05-17	\N	534	646	1906-02-19
570	1	1905-12-26	1929-03-03	\N	535	647	1906-02-13
571	1	1905-12-27	1922-08-14	\N	536	648	1906-02-14
572	1	1905-12-28	1913-03-11	\N	537	649	1907-07-16
573	1	1905-12-28	1919-01-07	\N	538	650	1906-02-13
574	1	1905-12-29	1920-09-17	\N	539	651	1906-02-14
575	1	1905-12-30	1945-01-09	\N	540	652	1906-02-14
576	1	1906-01-06	1916-04-30	\N	541	653	1906-02-14
577	1	1906-01-08	1923-11-30	\N	542	654	1906-02-13
578	1	1906-01-10	1923-03-01	\N	543	656	1906-02-19
579	1	1906-01-11	1917-05-10	\N	544	657	1906-02-14
580	1	1906-01-09	1935-06-21	\N	545	655	1906-02-14
581	1	1902-07-14	1934-01-03	\N	546	621	1902-07-24
582	1	1906-02-01	1911-01-29	\N	547	661	1906-02-14
583	1	1906-07-14	1918-05-11	\N	548	663	1906-07-19
584	1	1906-07-16	1928-04-19	\N	549	664	1906-07-23
585	1	1906-07-17	1924-06-06	\N	550	665	1906-07-23
586	1	1906-07-18	1915-07-27	\N	551	666	1906-07-23
587	1	1906-07-19	1915-12-07	\N	552	667	1906-07-23
588	1	1906-07-20	1907-02-13	\N	553	668	1907-04-25
589	1	1907-03-06	1911-01-03	\N	554	669	1907-03-07
590	1	1907-07-17	1911-03-16	\N	555	670	1907-08-01
591	1	1907-07-18	1911-01-12	\N	556	671	1907-08-01
592	1	1907-07-19	1925-02-08	\N	557	672	1907-08-01
593	1	1907-07-20	1919-10-21	\N	558	673	\N
594	1	1908-05-02	1923-09-23	\N	559	674	1908-05-05
595	1	1908-05-04	1911-02-25	\N	560	675	1908-05-05
596	1	1908-05-22	1911-09-13	\N	561	676	1908-05-26
597	1	1908-07-02	1925-06-09	\N	562	677	1908-07-14
598	1	1908-07-03	1925-10-21	\N	563	678	1908-07-20
599	1	1908-07-06	1938-03-28	\N	564	680	1908-07-13
600	1	1909-02-16	1913-04-22	\N	565	682	1909-02-16
601	1	1909-05-12	1934-11-04	\N	566	684	1909-07-05
602	1	1901-11-09	1936-01-20	\N	451	618	\N
603	1	1909-12-07	1920-07-10	\N	567	685	1910-03-10
604	1	1909-12-08	1932-06-27	\N	568	686	1911-02-15
605	1	1910-03-15	1930-03-06	\N	569	687	1910-04-14
606	1	1910-03-15	1939-06-14	\N	570	688	1910-03-22
607	1	1910-03-16	1929-09-03	\N	571	689	1910-04-07
608	1	1910-04-27	1936-12-06	\N	572	690	1910-04-28
609	1	1910-07-13	1929-02-23	\N	573	692	1910-07-21
610	1	1910-07-14	1913-01-31	\N	574	693	1910-07-25
611	1	1910-07-15	1934-09-05	\N	575	694	1910-07-26
612	1	1910-07-16	1927-05-01	\N	576	695	1910-07-27
613	1	1910-07-18	1927-12-26	\N	577	696	1910-07-28
614	1	1910-07-19	1912-11-10	\N	578	697	1910-07-25
615	1	1910-07-21	1944-08-02	\N	579	699	1916-05-16
616	1	1910-09-21	1914-09-02	\N	580	700	1911-07-10
617	1	1910-10-07	1918-09-11	\N	581	701	1910-10-19
618	1	1911-03-27	1928-08-19	\N	582	702	1911-03-30
619	1	1911-04-03	1920-11-21	\N	583	703	1911-05-16
620	1	1906-01-13	1936-11-21	\N	584	659	1906-02-14
621	1	1906-01-16	1907-10-27	\N	585	660	1906-02-14
622	1	1909-02-15	1925-01-11	\N	586	681	1909-02-16
623	1	1911-06-24	1914-08-27	\N	587	708	1911-07-24
624	1	1911-06-27	1933-03-19	\N	588	710	1911-07-19
625	1	1911-06-28	1933-05-01	\N	589	711	1911-07-20
626	1	1911-06-29	1945-02-03	\N	590	712	1911-07-17
627	1	1911-07-03	1927-02-20	\N	591	715	1911-08-01
628	1	1911-07-04	1923-11-30	\N	542	716	1911-08-01
629	1	1911-07-04	1924-08-15	\N	517	717	1911-07-05
630	1	1911-07-05	1918-02-23	\N	411	718	1911-08-01
631	1	1911-07-06	1926-01-15	\N	592	720	1911-07-25
632	1	1911-11-02	1925-03-20	\N	593	721	1912-02-21
633	1	1911-11-02	1926-12-13	\N	594	722	1911-11-14
634	1	1911-11-03	1936-07-25	\N	595	723	1911-11-14
635	1	1912-02-08	1927-12-14	\N	596	725	1912-02-19
636	1	1912-02-09	1929-02-18	\N	597	726	1912-03-21
637	1	1912-07-08	1931-11-02	\N	598	728	1912-10-14
638	1	1912-07-09	1926-02-20	\N	599	729	1912-07-11
639	1	1912-07-11	1918-09-13	\N	600	730	1913-07-17
640	1	1912-08-13	1920-09-13	\N	601	731	1912-12-10
641	1	1911-07-03	1945-06-20	\N	602	713	1911-08-09
642	1	1912-02-26	1928-06-13	\N	603	727	1912-03-13
643	1	1910-06-23	1972-05-28	\N	604	691	1918-02-19
644	1	1912-10-01	1921-03-09	\N	605	732	1912-10-14
645	1	1912-12-10	1967-09-29	\N	606	733	1912-12-10
646	1	1913-02-12	1933-02-07	\N	607	734	1913-06-05
647	1	1913-02-14	1945-03-24	\N	608	735	1913-03-10
648	1	1913-03-04	1918-07-12	\N	609	736	1913-03-06
649	1	1913-10-20	1934-05-24	\N	610	737	1913-10-20
650	1	1913-11-24	1915-12-15	\N	505	738	\N
651	1	1914-01-09	1935-12-30	\N	611	739	1914-02-12
652	1	1914-01-15	1928-10-02	\N	612	740	1914-04-28
653	1	1914-01-16	1941-06-30	\N	613	741	1914-02-10
654	1	1914-01-17	1940-11-26	\N	614	742	1914-03-18
655	1	1914-01-28	1922-01-22	\N	615	743	1914-02-10
656	1	1914-05-11	1934-10-15	\N	616	744	1914-06-15
657	1	1914-07-01	1920-06-18	\N	617	745	1914-07-02
658	1	1914-07-02	1941-11-01	\N	618	746	1914-07-20
659	1	1914-07-03	1921-02-28	\N	619	747	1914-07-15
660	1	1914-07-04	1926-09-18	\N	620	748	1914-07-13
661	1	1911-06-21	1934-01-23	\N	621	705	1911-07-17
662	1	1912-02-07	1926-01-16	\N	622	724	1917-05-16
663	1	1911-06-23	1931-03-31	\N	623	707	1911-07-24
664	1	1915-04-12	1935-10-27	\N	624	752	1915-04-14
665	1	1915-06-14	1934-12-05	\N	625	754	1915-06-22
666	1	1915-06-28	1919-09-26	\N	626	755	1916-04-12
667	1	1915-06-29	1930-05-22	\N	627	756	1915-06-30
668	1	1916-01-01	1925-05-22	\N	628	757	1916-02-29
669	1	1916-01-22	1929-09-03	\N	571	758	1916-02-22
670	1	1916-01-22	1919-09-06	\N	629	759	1916-01-26
671	1	1916-01-24	1934-03-17	\N	630	760	1916-02-16
672	1	1916-01-25	1923-12-10	\N	631	761	1916-11-23
673	1	1916-01-26	1919-10-18	\N	632	762	1916-02-16
674	1	1916-01-27	1930-12-07	\N	633	763	1916-02-22
675	1	1916-01-28	1918-07-03	\N	634	764	1916-02-24
676	1	1916-06-20	1923-05-29	\N	635	765	1916-06-22
677	1	1916-06-26	1935-12-30	\N	611	766	1916-07-26
678	1	1916-06-26	1935-02-25	\N	636	767	1916-07-13
679	1	1916-06-27	1928-11-05	\N	637	768	1916-07-26
680	1	1916-06-28	1933-08-20	\N	638	769	1916-07-20
681	1	1916-06-29	1918-11-26	\N	639	770	1916-07-13
682	1	1916-07-27	1933-09-07	\N	640	772	1916-08-01
683	1	1916-12-19	1929-03-09	\N	641	773	1916-12-19
684	1	1917-01-01	1921-11-02	\N	642	774	1917-02-07
685	1	1917-01-01	1926-04-24	\N	643	775	1917-02-13
686	1	1917-01-02	1927-05-01	\N	576	776	1917-02-15
687	1	1917-01-02	1964-06-09	\N	644	777	1917-02-14
688	1	1917-01-03	1922-02-24	\N	645	778	1917-02-07
689	1	1917-01-03	1943-02-15	\N	646	779	1917-02-08
690	1	1917-01-04	1929-11-23	\N	647	780	1917-02-04
691	1	1917-01-05	1923-06-07	\N	648	781	1917-02-08
692	1	1917-01-06	1925-01-05	\N	649	782	1925-03-25
693	1	1917-05-05	1938-01-28	\N	650	783	1920-04-28
694	1	1917-05-07	1927-01-20	\N	651	784	1917-05-16
695	1	1917-06-19	1928-12-26	\N	652	785	1917-07-04
696	1	1917-06-20	1933-10-18	\N	653	786	1917-07-10
697	1	1917-06-21	1925-05-07	\N	654	788	1917-07-24
698	1	1917-06-22	1934-09-05	\N	575	789	1917-08-01
699	1	1917-06-22	1946-01-26	\N	655	790	1917-07-19
700	1	1917-06-23	1919-10-18	\N	632	791	1917-07-19
701	1	1914-12-14	1920-01-06	\N	656	750	1915-02-16
702	1	1915-02-22	1916-04-30	\N	541	751	1915-03-02
703	1	1917-11-01	1947-01-17	\N	657	797	1918-04-25
704	1	1918-01-15	1935-11-20	\N	658	800	1918-04-09
705	1	1918-01-15	1935-10-24	\N	659	801	1918-04-09
706	1	1918-01-16	1940-10-06	\N	660	802	1918-03-05
707	1	1918-01-16	1937-03-30	\N	661	803	1918-02-26
708	1	1918-01-17	1924-06-08	\N	662	804	1918-01-24
709	1	1918-01-18	1949-09-22	\N	663	805	1918-01-24
710	1	1918-01-19	1921-02-08	\N	664	806	1918-01-29
711	1	1918-06-15	1939-06-14	\N	570	807	1919-02-06
712	1	1918-06-19	1918-07-03	\N	634	809	\N
713	1	1918-06-27	1928-09-23	\N	665	811	1918-07-24
714	1	1918-06-26	1959-07-02	\N	666	810	1918-07-09
715	1	1918-06-28	1942-06-28	\N	667	812	1918-07-23
716	1	1918-06-29	1931-02-01	\N	668	813	1918-07-11
717	1	1919-05-16	1933-07-20	\N	669	829	1919-08-06
718	1	1918-07-01	1930-09-10	\N	670	814	1918-07-23
719	1	1918-07-02	1929-03-13	\N	671	815	1918-07-11
720	1	1918-07-09	1947-07-21	\N	672	816	1918-07-10
721	1	1918-09-02	1919-09-26	\N	626	817	1919-05-21
722	1	1917-07-18	1960-02-23	\N	673	796	1918-03-06
723	1	1918-10-15	1958-07-03	\N	674	818	1918-10-16
724	1	1918-11-14	1928-03-29	\N	675	819	1918-11-14
725	1	1918-11-14	1923-08-17	\N	676	820	1918-11-14
726	1	1918-11-16	1920-07-02	\N	677	821	1918-11-18
727	1	1919-02-03	1930-09-30	\N	678	822	1919-02-04
728	1	1919-02-04	1937-07-01	\N	679	823	1919-02-05
729	1	1919-02-05	1955-09-17	\N	680	824	1919-02-26
730	1	1919-02-14	1928-03-05	\N	681	825	1919-02-25
731	1	1919-03-24	1942-06-02	\N	682	826	1919-04-08
732	1	1919-03-27	1929-03-09	\N	641	827	1919-04-08
733	1	1919-04-24	1938-11-17	\N	683	828	1919-07-09
734	1	1919-05-17	1940-11-26	\N	614	831	1935-01-30
735	1	1919-05-17	1937-06-03	\N	684	832	1919-05-28
736	1	1919-05-19	1955-12-19	\N	685	833	1919-05-21
737	1	1919-05-20	1930-04-11	\N	686	834	1919-05-28
738	1	1918-06-17	1938-03-28	\N	564	808	1918-07-02
739	1	1919-10-06	1925-03-28	\N	687	839	1919-11-05
740	1	1919-10-07	1936-05-14	\N	688	840	1925-07-08
741	1	1919-10-07	1935-06-06	\N	689	841	1919-11-05
742	1	1919-10-08	1929-08-14	\N	690	842	1919-11-12
743	1	1919-10-27	1933-02-02	\N	691	844	1919-11-12
744	1	1920-01-09	1948-11-04	\N	692	850	1920-02-18
745	1	1919-11-01	1919-11-15	\N	693	846	1925-02-25
746	1	1919-11-18	1933-05-24	\N	694	847	1920-05-12
747	1	1919-11-29	1943-10-07	\N	695	848	1919-12-03
748	1	1919-12-12	1936-01-15	\N	696	849	1919-12-17
749	1	1920-02-09	1945-03-07	\N	697	853	1920-02-18
750	1	1920-04-21	1932-11-03	\N	698	854	1920-05-12
751	1	1921-01-14	1936-03-29	\N	699	858	1921-03-02
752	1	1920-11-08	1934-10-15	\N	616	856	1920-11-10
753	1	1920-12-06	1934-03-30	\N	700	857	1920-12-06
754	1	1921-01-15	1936-04-09	\N	701	859	1921-05-04
755	1	1921-01-17	1927-03-28	\N	702	860	1921-03-23
756	1	1921-01-18	1935-08-21	\N	703	861	1921-02-23
757	1	1921-01-19	1923-03-03	\N	704	862	1921-04-13
758	1	1921-06-15	1930-09-30	\N	678	868	1921-07-07
759	1	1917-07-16	1957-01-16	\N	705	794	1918-07-17
760	1	1920-02-02	1942-02-13	\N	706	852	1920-02-11
761	1	1917-07-17	1921-09-11	\N	707	795	1917-07-25
762	1	1921-04-28	1947-05-18	\N	708	863	1921-07-27
763	1	1921-06-01	1935-10-22	\N	709	864	1921-06-01
764	1	1921-06-03	1933-04-01	\N	710	865	1921-07-20
765	1	1921-06-04	1924-09-26	\N	711	866	1921-11-02
766	1	1921-06-04	1942-01-23	\N	712	867	1921-07-06
767	1	1921-06-15	1927-01-17	\N	713	869	1921-07-06
768	1	1921-06-28	1925-03-20	\N	593	870	1921-07-07
769	1	1921-06-28	1935-07-15	\N	714	871	1921-08-10
770	1	1921-07-01	1924-09-23	\N	715	872	1921-08-03
771	1	1922-01-23	1930-06-14	\N	716	877	1922-02-22
772	1	1921-07-08	1949-03-27	\N	717	873	1921-10-26
773	1	1921-07-09	1924-06-06	\N	550	874	1921-07-13
774	1	1921-07-26	1931-03-22	\N	718	875	1921-11-09
775	1	1921-08-24	1936-08-03	\N	719	876	1921-10-26
776	1	1922-01-24	1935-08-09	\N	720	878	1922-05-24
777	1	1919-09-29	1928-01-29	\N	721	836	1919-11-12
778	1	1919-10-04	1932-07-16	\N	722	838	1921-07-20
779	1	1922-06-20	1940-12-10	\N	723	885	1922-06-21
780	1	1922-07-18	1940-01-09	\N	724	886	1922-07-19
781	1	1922-07-20	1936-01-27	\N	725	887	1922-07-26
782	1	1923-07-23	1927-12-17	\N	726	899	1923-07-25
783	1	1922-11-20	1947-02-08	\N	727	888	1923-02-21
784	1	1922-11-21	1951-04-24	\N	728	889	1922-12-07
785	1	1922-11-22	1936-07-17	\N	729	890	1922-11-29
786	1	1922-11-23	1945-05-27	\N	730	891	1922-12-06
787	1	1922-11-28	1947-07-21	\N	672	894	1922-12-06
788	1	1922-11-30	1923-08-30	\N	489	895	1922-12-01
789	1	1923-02-12	1949-05-10	\N	731	896	1923-03-14
790	1	1923-02-14	1937-06-05	\N	732	897	1923-03-07
791	1	1923-02-20	1929-04-29	\N	733	898	1923-02-21
792	1	1923-07-24	1935-05-22	\N	734	900	1923-07-25
793	1	1924-01-08	1950-11-01	\N	735	903	1924-01-16
794	1	1923-10-12	1946-08-17	\N	736	901	1923-11-14
795	1	1923-12-24	1958-11-24	\N	737	902	1924-01-16
796	1	1924-01-12	1936-05-29	\N	738	904	1924-01-16
797	1	1924-01-21	1932-05-23	\N	739	905	1924-01-22
798	1	1924-01-21	1936-08-13	\N	740	906	1924-01-22
799	1	1924-02-19	1935-06-30	\N	741	910	1924-02-20
800	1	1922-11-28	1930-09-30	\N	678	893	1922-11-30
801	1	1922-06-05	1925-05-22	\N	742	883	1922-06-27
802	1	1924-02-09	1943-02-15	\N	743	907	1924-02-12
803	1	1924-02-11	1930-10-05	\N	744	908	1924-02-12
804	1	1924-02-12	1945-08-03	\N	745	909	1924-02-12
805	1	1924-05-07	1926-06-10	\N	746	911	1924-07-09
806	1	1925-01-19	1939-05-20	\N	747	913	1925-02-11
807	1	1925-01-28	1950-05-03	\N	748	914	1925-03-11
808	1	1926-01-19	1927-06-30	\N	749	921	1926-02-03
809	1	1925-06-12	1941-08-20	\N	750	916	1925-06-17
810	1	1925-11-16	1941-02-04	\N	751	919	1926-07-28
811	1	1925-12-22	1959-12-23	\N	752	920	1926-02-10
812	1	1926-01-28	1936-10-22	\N	753	922	1926-02-10
813	1	1922-01-26	1929-02-16	\N	754	880	1922-02-08
814	1	1922-06-19	1931-10-29	\N	755	884	1922-07-05
815	1	1922-03-24	1943-05-05	\N	756	881	1922-03-29
816	1	1926-08-04	1934-05-03	\N	757	927	1926-11-17
817	1	1927-01-18	1934-12-17	\N	758	929	1927-05-04
818	1	1926-10-25	1937-10-26	\N	759	928	1926-11-17
819	1	1927-01-20	1940-11-24	\N	760	930	1927-05-25
820	1	1927-01-29	1946-11-07	\N	761	931	1927-02-16
821	1	1927-01-31	1935-09-26	\N	762	933	1927-05-25
822	1	1927-06-21	1938-10-24	\N	763	934	1927-06-29
823	1	1927-07-04	1928-04-18	\N	764	935	1927-07-06
824	1	1928-01-11	1931-10-28	\N	765	937	1928-02-15
825	1	1927-11-07	1934-10-12	\N	766	936	1927-11-09
826	1	1928-01-19	1940-08-22	\N	767	939	1928-11-07
827	1	1928-03-16	1945-04-11	\N	768	941	1928-04-25
828	1	1928-02-06	1944-06-25	\N	769	940	1928-02-15
829	1	1928-06-15	1930-12-27	\N	770	945	1928-06-20
830	1	1928-04-05	1950-08-16	\N	771	943	1928-04-19
831	1	1928-05-08	1938-01-07	\N	772	944	\N
832	1	1928-06-26	1933-01-30	\N	773	946	1928-07-11
833	1	1928-07-05	1953-05-24	\N	774	947	1928-07-18
834	1	1929-03-18	1931-06-13	\N	775	950	1931-11-25
835	1	1928-11-14	1930-05-25	\N	776	948	1928-11-14
836	1	1929-02-11	1935-08-12	\N	777	949	1929-02-13
837	1	1929-03-19	1936-09-07	\N	778	951	1929-04-17
838	1	1929-03-20	1966-08-20	\N	779	952	1929-05-08
839	1	1929-06-17	1930-10-21	\N	780	955	1929-07-03
840	1	1929-05-01	1948-06-13	\N	781	953	1929-05-01
841	1	1928-03-31	1974-06-10	\N	782	942	1928-04-24
842	1	1925-02-09	1928-02-15	\N	783	915	1925-02-17
843	1	1929-05-07	1937-06-28	\N	784	954	1929-05-08
844	1	1929-06-18	1935-08-14	\N	785	956	1929-06-26
845	1	1929-06-18	1940-02-24	\N	786	957	1929-07-03
846	1	1929-06-19	1954-06-15	\N	787	958	1929-07-03
847	1	1929-07-04	1950-08-16	\N	771	963	1929-07-10
848	1	1929-06-21	1948-02-06	\N	788	960	1929-06-25
849	1	1929-06-22	1947-10-13	\N	789	961	1929-06-27
850	1	1929-07-05	1932-06-08	\N	790	964	1929-07-10
851	1	1929-07-08	1956-12-01	\N	791	965	1929-07-24
852	1	1929-07-09	1943-02-23	\N	792	966	1929-07-10
853	1	1929-07-10	1937-09-28	\N	793	967	1929-07-24
854	1	1926-07-16	1928-05-23	\N	794	926	1926-07-21
855	1	1930-01-16	1952-02-29	\N	795	975	1930-01-22
856	1	1930-01-17	1946-03-24	\N	796	976	1930-01-22
857	1	1929-09-17	1941-01-08	\N	797	973	1929-10-30
858	1	1930-01-18	1943-05-31	\N	798	977	1930-10-29
859	1	1930-01-20	1941-01-15	\N	799	978	1930-01-29
860	1	1930-01-21	1935-09-11	\N	800	979	1930-02-05
861	1	1930-01-23	1956-02-10	\N	801	980	1930-01-29
862	1	1930-06-17	1948-09-12	\N	802	982	1930-07-16
863	1	1930-06-18	1939-03-25	\N	803	983	1930-07-09
864	1	1930-02-03	1952-09-05	\N	804	981	1930-02-05
865	1	1930-07-10	1939-08-01	\N	805	984	1930-07-23
866	1	1931-01-20	1946-01-19	\N	806	985	1931-01-28
867	1	1931-01-21	1963-01-05	\N	807	986	1931-02-04
868	1	1931-01-22	1937-10-19	\N	808	987	1931-02-04
869	1	1931-01-23	1955-01-13	\N	809	988	1931-01-28
870	1	1931-11-24	1937-05-15	\N	810	991	1931-11-25
871	1	1931-12-05	1945-11-02	\N	811	992	1931-12-09
872	1	1931-03-23	1944-04-21	\N	812	990	1931-03-25
873	1	1931-12-07	1937-04-19	\N	813	993	1931-12-09
874	1	1932-01-13	1939-07-03	\N	814	994	1932-02-10
875	1	1932-01-14	1938-12-24	\N	815	995	1932-02-10
876	1	1932-01-18	1939-03-03	\N	816	996	1932-02-17
877	1	1932-01-21	1944-11-06	\N	817	997	1932-02-10
878	1	1932-01-25	1939-09-26	\N	818	998	1932-02-17
879	1	1932-01-30	1948-02-06	\N	788	999	1932-02-02
880	1	1931-02-20	1941-08-12	\N	819	989	1931-02-25
881	1	1926-05-07	1935-12-30	\N	611	925	1926-06-09
882	1	1932-06-17	1949-02-03	\N	820	1001	1932-06-29
883	1	1932-06-20	1944-06-24	\N	821	1002	1932-07-05
884	1	1932-04-11	1964-06-27	\N	822	1000	1932-04-13
885	1	1932-06-21	1944-06-16	\N	823	1003	1932-06-29
886	1	1932-06-28	1949-02-14	\N	824	1005	1932-07-05
887	1	1932-06-30	1950-06-13	\N	825	1006	1932-07-06
888	1	1933-01-19	1934-11-21	\N	826	1008	1933-02-15
889	1	1933-01-23	1955-08-13	\N	827	1009	1933-03-08
890	1	1933-01-26	1948-03-23	\N	828	1010	1933-02-15
891	1	1933-02-03	1939-05-25	\N	829	1011	1933-06-14
892	1	1929-07-16	1938-09-24	\N	830	969	1929-07-17
893	1	1929-07-22	1942-05-05	\N	831	970	1929-07-24
894	1	1929-07-24	1947-03-14	\N	832	971	1935-05-08
895	1	1933-06-24	1948-12-08	\N	833	1016	1933-07-05
896	1	1933-07-24	1947-12-11	\N	834	1017	1933-11-15
897	1	1934-01-11	1941-04-01	\N	835	1018	1934-02-07
898	1	1934-01-12	1948-11-01	\N	836	1019	1934-02-07
899	1	1934-01-15	1942-09-02	\N	837	1021	1934-02-14
900	1	1934-01-16	1973-04-18	\N	838	1022	1934-02-14
901	1	1934-06-27	1955-10-06	\N	839	1024	1934-07-25
902	1	1934-06-28	1941-01-15	\N	799	1025	1934-07-25
903	1	1934-06-28	1943-01-22	\N	840	1026	1934-07-11
904	1	1934-06-29	1936-04-30	\N	841	1027	1934-07-11
905	1	1935-01-24	1949-11-18	\N	842	1029	1935-02-06
906	1	1935-01-25	1944-07-20	\N	843	1030	1935-03-13
907	1	1935-01-26	1949-05-06	\N	844	1031	1935-02-06
908	1	1935-06-24	1958-07-03	\N	674	1033	1935-07-09
909	1	1935-06-01	1940-02-11	\N	845	1032	1935-07-09
910	1	1935-06-24	1935-10-20	\N	846	1034	1935-07-03
911	1	1935-06-25	1960-09-03	\N	847	1035	1935-07-03
912	1	1935-06-27	1957-07-07	\N	848	1037	1935-07-24
913	1	1935-06-28	1946-04-10	\N	849	1038	1935-07-24
914	1	1935-06-29	1941-11-26	\N	850	1039	1936-06-24
915	1	1936-01-11	1937-08-14	\N	851	1046	1936-04-29
916	1	1935-07-15	1960-07-11	\N	852	1040	1935-07-15
917	1	1935-10-07	1958-03-23	\N	853	1041	1935-10-22
918	1	1935-10-14	1956-12-22	\N	854	1042	1935-10-22
919	1	1935-11-29	1972-07-27	\N	855	1043	1935-12-04
920	1	1935-11-30	1969-03-21	\N	856	1044	1935-12-04
921	1	1935-12-20	1955-05-02	\N	857	1045	1938-05-11
922	1	1936-01-31	1956-02-10	\N	801	1048	1936-02-05
923	1	1936-02-01	1937-06-13	\N	858	1049	1936-02-05
924	1	1936-02-03	1968-02-06	\N	859	1050	1936-03-11
925	1	1936-02-24	1959-08-23	\N	860	1051	1936-03-11
926	1	1936-07-14	1946-09-21	\N	861	1053	1936-11-11
927	1	1936-07-15	1969-06-01	\N	862	1054	1936-07-29
928	1	1936-07-16	1941-05-23	\N	863	1055	1936-07-29
929	1	1933-03-01	1941-07-26	\N	864	1013	1933-05-10
930	1	1933-06-21	1947-11-07	\N	865	1014	1933-06-28
931	1	1933-06-22	1960-07-25	\N	866	1015	1933-07-26
932	1	1937-02-24	1961-07-13	\N	867	1061	1937-04-28
933	1	1937-05-22	1951-12-11	\N	868	1063	1937-06-30
934	1	1937-05-24	1948-11-30	\N	869	1064	1937-06-16
935	1	1937-06-03	1948-05-26	\N	870	1067	1937-06-16
936	1	1937-06-04	1967-11-15	\N	871	1068	1937-07-07
937	1	1937-06-07	1941-05-31	\N	872	1069	1937-07-07
938	1	1937-06-08	1947-12-14	\N	873	1070	1937-06-09
939	1	1937-06-08	1963-02-05	\N	874	1071	1937-06-09
940	1	1937-06-08	1955-01-01	\N	875	1072	1937-06-23
941	1	1937-06-09	1940-09-03	\N	876	1073	1937-06-23
942	1	1937-06-10	1949-11-14	\N	877	1074	1937-06-23
943	1	1937-06-10	1953-11-03	\N	878	1075	1937-07-14
944	1	1937-06-11	1970-12-11	\N	879	1076	1937-06-30
945	1	1937-06-11	1946-04-10	\N	880	1077	1937-07-14
946	1	1937-06-12	1949-12-04	\N	881	1078	1937-11-17
947	1	1938-01-24	1963-08-22	\N	882	1080	1938-05-18
948	1	1938-01-05	1944-08-19	\N	883	1079	1938-02-02
949	1	1938-01-24	1938-04-14	\N	884	1081	1938-02-16
950	1	1938-01-25	1951-05-17	\N	885	1082	1938-02-02
951	1	1957-01-22	1968-09-10	\N	886	1338	1957-01-23
952	1	1938-01-26	1958-10-22	\N	887	1083	1938-02-09
953	1	1938-01-28	1956-06-17	\N	888	1085	1938-02-16
954	1	1938-06-25	1959-07-02	\N	666	1087	1938-07-20
955	1	1938-03-28	1956-02-13	\N	889	1086	1938-03-29
956	1	1938-06-27	1941-08-20	\N	750	1088	1938-06-29
957	1	1938-06-28	1941-04-16	\N	890	1089	1938-07-20
958	1	1938-06-29	1956-02-17	\N	891	1090	1938-07-20
959	1	1937-06-01	1944-11-07	\N	892	1065	1945-11-28
960	1	1936-05-26	1941-08-12	\N	819	1052	1936-06-24
961	1	1939-02-01	1945-02-04	\N	893	1091	1939-02-08
962	1	1939-02-02	1962-12-07	\N	894	1092	1939-02-15
963	1	1939-02-03	1963-01-25	\N	895	1093	1939-02-15
964	1	1939-02-04	1948-08-13	\N	896	1094	1939-02-08
965	1	1939-07-04	1944-11-17	\N	897	1095	1939-07-19
966	1	1939-07-05	1958-03-17	\N	898	1096	1939-07-12
967	1	1936-10-30	1945-03-07	\N	697	1057	1936-12-16
968	1	1937-02-16	1948-09-10	\N	899	1058	1937-03-24
969	1	1937-02-23	1942-08-17	\N	900	1060	1937-03-10
970	1	1939-09-06	1947-10-11	\N	901	1100	1939-09-06
971	1	1939-09-22	1958-03-23	\N	853	1101	1939-09-27
972	1	1940-04-18	1940-11-24	\N	902	1102	1940-04-24
973	1	1940-05-20	1954-01-11	\N	903	1103	1940-05-21
974	1	1940-05-28	1947-12-07	\N	904	1104	1940-05-29
975	1	1940-06-27	1968-01-07	\N	905	1106	1940-07-03
976	1	1940-06-28	1963-10-23	\N	906	1107	1940-07-03
977	1	1941-01-25	1956-12-10	\N	907	1111	1941-02-12
978	1	1940-10-28	1943-05-05	\N	756	1109	\N
979	1	1941-01-27	1962-01-18	\N	908	1112	1941-02-05
980	1	1941-01-28	1954-07-20	\N	909	1113	1941-02-05
981	1	1941-01-29	1959-09-22	\N	910	1114	1941-02-26
982	1	1941-07-03	1957-02-14	\N	911	1116	1941-07-16
983	1	1941-05-19	1965-03-18	\N	912	1115	1941-06-11
984	1	1941-07-16	1947-06-27	\N	913	1118	1941-07-23
985	1	1941-07-16	1952-04-16	\N	914	1119	1941-07-23
986	1	1942-01-12	1960-11-17	\N	915	1122	1942-01-21
987	1	1942-01-16	1970-03-31	\N	916	1123	1942-01-21
988	1	1941-08-06	1971-01-31	\N	917	1120	1941-09-10
989	1	1941-08-14	1970-04-01	\N	918	1121	1941-09-10
990	1	1942-01-21	1943-07-26	\N	919	1124	1942-01-28
991	1	1942-01-28	1954-01-08	\N	920	1125	1942-02-04
992	1	1942-02-04	1961-06-07	\N	921	1126	1942-02-04
993	1	1942-02-20	1946-03-15	\N	922	1127	1942-02-25
994	1	1942-07-06	1946-04-21	\N	923	1132	1942-07-08
995	1	1943-01-22	1945-12-26	\N	924	1133	1943-01-27
996	1	1942-04-02	1945-12-05	\N	925	1129	1942-04-15
997	1	1942-04-27	1965-12-24	\N	926	1130	1942-05-06
998	1	1942-04-27	1964-05-17	\N	927	1131	1942-05-06
999	1	1943-03-08	1977-04-12	\N	928	1135	1943-03-31
1000	1	1943-05-17	1964-09-18	\N	929	1137	1945-11-07
1001	1	1943-02-01	1947-12-10	\N	930	1134	1943-02-10
1002	1	1943-07-05	1970-02-15	\N	931	1138	1943-07-28
1003	1	1943-05-03	1962-07-08	\N	932	1136	1962-12-05
1004	1	1944-01-27	1947-06-02	\N	933	1140	1944-02-16
1005	1	1939-07-07	1964-12-14	\N	934	1098	1939-07-26
1006	1	1943-07-22	1950-05-24	\N	935	1139	1943-07-28
1007	1	1939-07-08	1950-07-20	\N	936	1099	1939-07-26
1008	1	1940-06-26	1940-12-06	\N	937	1105	1940-07-03
1009	1	1944-06-26	1956-06-28	\N	938	1146	1944-06-28
1010	1	1944-04-18	1971-06-28	\N	939	1145	1944-04-18
1011	1	1945-02-01	1949-05-06	\N	844	1152	1945-02-21
1012	1	1944-07-14	1959-05-07	\N	940	1148	1944-10-11
1013	1	1944-07-19	1971-05-29	\N	941	1149	1944-07-19
1014	1	1944-10-13	1950-02-04	\N	942	1150	1945-05-30
1015	1	1945-02-12	1945-03-26	\N	943	1153	1945-06-13
1016	1	1945-02-12	1949-05-25	\N	944	1154	1945-03-14
1017	1	1945-07-02	1950-07-29	\N	945	1156	1945-08-07
1018	1	1945-07-03	1955-09-02	\N	946	1157	1945-10-16
1019	1	1945-07-05	1988-09-21	\N	947	1158	1945-08-01
1020	1	1945-07-06	1954-05-02	\N	948	1159	\N
1021	1	1945-07-07	1962-04-16	\N	949	1160	1945-08-03
1022	1	1945-07-09	1951-04-25	\N	950	1161	1945-08-03
1023	1	1945-07-10	1950-07-06	\N	951	1162	1945-08-07
1024	1	1945-07-11	1946-07-15	\N	952	1163	1945-08-01
1025	1	1945-07-12	1955-08-09	\N	953	1164	1945-10-31
1026	1	1945-07-13	1945-08-24	\N	954	1165	\N
1027	1	1945-07-14	1959-05-16	\N	955	1166	1945-08-02
1028	1	1945-07-23	1958-02-17	\N	956	1167	1945-08-01
1029	1	1945-08-01	1955-12-01	\N	957	1168	1945-08-22
1030	1	1945-09-12	1968-02-06	\N	859	1171	1945-10-24
1031	1	1945-08-02	1957-08-16	\N	958	1169	1945-08-02
1032	1	1945-08-16	1961-09-17	\N	959	1170	1945-08-21
1033	1	1945-09-12	1957-01-24	\N	960	1172	1945-10-10
1034	1	1945-09-13	1955-01-01	\N	875	1173	1945-10-10
1035	1	1945-09-13	1954-03-06	\N	961	1174	1945-10-17
1036	1	1945-09-14	1952-04-17	\N	962	1175	1945-10-17
1037	1	1945-09-18	1963-06-17	\N	963	1178	\N
1038	1	1945-09-19	1953-01-19	\N	964	1179	1945-10-24
1039	1	1944-01-29	1953-09-13	\N	965	1142	1944-02-02
1040	1	1945-10-12	2001-08-03	\N	966	1180	1945-10-16
1041	1	1945-10-19	1984-04-04	\N	967	1181	1945-10-23
1042	1	1944-01-31	1960-04-02	\N	968	1143	1944-02-02
1043	1	1944-02-01	1954-11-01	\N	969	1144	1944-02-09
1044	1	1945-11-15	1953-12-25	\N	970	1185	1945-11-20
1045	1	1945-11-16	1978-01-27	\N	971	1186	1945-11-28
1046	1	1945-11-17	1955-09-20	\N	972	1187	1945-11-20
1047	1	1945-12-01	1977-08-18	\N	973	1188	1945-12-12
1048	1	1946-01-25	1946-04-10	\N	880	1191	1946-02-06
1049	1	1946-01-26	1963-06-12	\N	974	1192	1946-02-27
1050	1	1946-01-28	1971-04-22	\N	975	1193	1946-02-27
1051	1	1946-01-28	1954-11-03	\N	976	1194	1946-03-06
1052	1	1946-01-29	1963-06-17	\N	963	1195	1946-02-27
1053	1	1946-01-30	1979-08-26	\N	977	1196	1946-01-30
1054	1	1946-01-31	1976-03-24	\N	978	1197	1946-07-24
1055	1	1946-02-11	1971-01-12	\N	979	1200	1946-02-20
1056	1	1946-02-05	1949-04-27	\N	980	1198	1946-02-13
1057	1	1946-02-08	1946-03-31	\N	981	1199	\N
1058	1	1946-02-12	1950-12-26	\N	982	1201	1946-03-06
1059	1	1946-03-01	1969-06-16	\N	983	1202	1946-03-13
1060	1	1946-03-12	1964-12-31	\N	984	1203	1947-06-04
1061	1	1946-06-25	1963-03-16	\N	985	1205	1946-06-25
1062	1	1946-04-05	1951-07-05	\N	986	1204	1946-05-15
1063	1	1946-06-26	1974-02-28	\N	987	1206	1946-07-24
1064	1	1946-06-27	1967-10-11	\N	988	1207	1946-07-10
1065	1	1946-07-16	1983-01-22	\N	989	1209	1946-07-25
1066	1	1946-07-17	1963-08-23	\N	990	1210	1946-10-09
1067	1	1946-07-18	1963-11-30	\N	991	1211	1946-07-24
1068	1	1946-09-19	1981-02-12	\N	992	1213	1946-10-09
1069	1	1947-01-13	1971-08-28	\N	993	1216	1947-02-19
1070	1	1946-10-28	1965-11-08	\N	994	1214	1946-10-30
1071	1	1947-01-06	1962-10-05	\N	995	1215	1947-01-22
1072	1	1947-01-14	1965-12-17	\N	996	1217	1947-02-05
1073	1	1947-01-15	1969-04-20	\N	997	1218	1947-04-16
1074	1	1947-01-16	1966-02-14	\N	998	1219	1947-02-19
1075	1	1947-01-17	1960-10-03	\N	999	1220	1947-02-12
1076	1	1947-01-20	1957-08-16	\N	958	1221	1947-01-21
1077	1	1947-01-20	1961-02-05	\N	1000	1222	1947-02-05
1078	1	1947-01-21	1960-09-27	\N	1001	1223	1947-01-22
1079	1	1947-03-18	1967-08-25	\N	1002	1224	1947-03-26
1080	1	1945-11-13	1952-03-18	\N	1003	1183	1945-12-05
1081	1	1946-01-23	1967-06-03	\N	1004	1190	1946-03-13
1082	1	1945-11-14	1966-07-07	\N	1005	1184	1945-11-20
1083	1	1947-07-15	1952-09-05	\N	1006	1230	1947-07-16
1084	1	1947-07-16	1966-10-15	\N	1007	1231	1947-07-30
1085	1	1947-10-09	1978-10-27	\N	1008	1232	1947-11-12
1086	1	1948-02-02	1963-01-05	\N	807	1235	1948-02-25
1087	1	1947-10-18	1979-08-27	\N	1009	1233	1948-07-21
1088	1	1948-02-06	1964-12-27	\N	1010	1236	1948-02-25
1089	1	1948-02-07	1969-10-30	\N	1011	1237	1948-02-25
1090	1	1948-02-09	1961-05-21	\N	1012	1238	1948-04-14
1091	1	1948-06-22	1958-05-28	\N	1013	1240	1948-07-14
1092	1	1948-06-23	1951-09-22	\N	1014	1241	1948-07-14
1093	1	1948-06-24	1966-02-18	\N	1015	1242	1948-07-14
1094	1	1949-02-16	1960-08-23	\N	1016	1244	1949-02-23
1095	1	1948-10-06	1975-03-29	\N	1017	1243	1948-10-27
1096	1	1949-03-09	1971-06-25	\N	1018	1245	1949-03-09
1097	1	1949-06-21	1951-09-27	\N	1019	1248	1949-06-22
1098	1	1949-04-13	1966-01-20	\N	1020	1246	1949-04-13
1099	1	1949-07-07	1951-08-17	\N	1021	1249	\N
1100	1	1949-07-12	1975-02-25	\N	1022	1250	1949-07-13
1101	1	1950-01-30	1964-07-22	\N	1023	1252	1950-03-02
1102	1	1950-01-31	1970-12-10	\N	1024	1253	1950-03-02
1103	1	1950-02-01	1970-05-27	\N	1025	1254	1950-03-01
1104	1	1950-02-02	1960-08-20	\N	1026	1255	1950-03-01
1105	1	1950-02-03	1950-02-26	\N	1027	1256	\N
1106	1	1950-07-04	1972-05-11	\N	1028	1259	1950-07-19
1107	1	1950-03-17	1965-08-03	\N	1029	1257	1950-03-22
1108	1	1950-04-11	1980-03-31	\N	1030	1258	1950-04-26
1109	1	1950-07-05	1975-08-07	\N	1031	1260	1950-07-12
1110	1	1950-07-06	1958-04-06	\N	1032	1261	1950-07-12
1111	1	1950-07-07	1965-04-24	\N	1033	1262	1950-07-26
1112	1	1950-07-08	1967-02-18	\N	1034	1263	1950-07-26
1113	1	1950-07-10	1976-08-30	\N	1035	1264	1950-07-12
1114	1	1950-07-11	1954-07-01	\N	1036	1265	1950-10-18
1115	1	1951-01-25	1965-06-13	\N	1037	1267	1951-02-14
1116	1	1950-09-29	1975-11-17	\N	1038	1266	1950-10-18
1117	1	1951-02-07	1966-06-14	\N	1039	1268	1951-04-11
1118	1	1947-11-20	2021-04-09	\N	1040	1234	1948-07-21
1119	1	1951-04-23	1954-08-24	\N	1041	1269	1951-04-25
1120	1	1947-04-23	1979-07-13	\N	1042	1227	1947-04-23
1121	1	1947-07-03	1989-03-10	\N	1043	1229	1947-07-30
1122	1	1947-05-01	1950-05-24	\N	935	1228	1947-06-04
1123	1	1951-11-12	1973-05-09	\N	1044	1273	1951-11-14
1124	1	1951-12-14	1958-05-05	\N	1045	1274	1952-05-21
1125	1	1951-12-22	1955-04-16	\N	1046	1276	1952-02-20
1126	1	1951-12-24	1957-08-16	\N	958	1277	1952-01-30
1127	1	1951-12-24	1968-11-20	\N	1047	1278	1952-02-05
1128	1	1952-01-05	1957-02-02	\N	1048	1279	1952-02-27
1129	1	1952-01-28	1958-01-04	\N	1049	1281	1952-01-30
1130	1	1952-01-30	1965-09-26	\N	1050	1282	1952-02-27
1131	1	1952-01-31	1962-08-26	\N	1051	1283	1952-02-20
1132	1	1952-04-10	1970-06-15	\N	1052	1285	1954-07-07
1133	1	1952-03-11	1969-06-16	\N	983	1284	1952-03-12
1134	1	1952-06-24	1971-06-28	\N	939	1286	1952-06-25
1135	1	1952-07-01	1973-08-18	\N	1053	1287	1952-11-12
1136	1	1952-07-05	1954-01-01	\N	1054	1288	1952-07-23
1137	1	1952-07-12	1960-12-19	\N	1055	1289	1952-07-16
1138	1	1953-02-11	1982-11-28	\N	1056	1290	1953-04-01
1139	1	1953-02-12	1958-04-03	\N	1057	1291	1953-04-01
1140	1	1953-06-29	1960-05-01	\N	1058	1293	1953-07-07
1141	1	1953-06-30	1976-07-02	\N	1059	1294	1953-07-22
1142	1	1953-07-01	1957-09-29	\N	1060	1295	1953-07-22
1143	1	1953-07-02	1964-12-14	\N	934	1296	1953-07-07
1144	1	1954-01-14	1957-02-16	\N	1061	1299	1954-01-20
1145	1	1954-01-16	1978-05-27	\N	1062	1300	1954-02-17
1146	1	1953-10-16	1975-06-27	\N	1063	1297	1953-10-21
1147	1	1953-11-04	1964-06-29	\N	1064	1298	1953-11-04
1148	1	1954-01-18	1965-03-18	\N	912	1301	1954-02-24
1149	1	1954-01-18	1961-04-22	\N	1065	1302	1954-01-27
1150	1	1954-01-30	1957-11-22	\N	1066	1303	1958-01-29
1151	1	1954-02-16	1980-11-15	\N	1067	1304	1954-02-17
1152	1	1954-07-03	1968-11-29	\N	1068	1305	1954-07-07
1153	1	1954-07-16	1971-01-31	\N	917	1306	1954-11-03
1154	1	1954-07-31	1955-07-15	\N	1069	1308	1955-03-30
1155	1	1951-06-27	1963-04-21	\N	1070	1271	1951-06-27
1156	1	1951-10-16	1963-07-04	\N	1071	1272	1952-10-29
1157	1	1954-09-09	1972-01-21	\N	1072	1309	1954-12-08
1158	1	1954-10-18	1971-06-28	\N	939	1311	1954-11-03
1159	1	1954-10-19	1967-01-27	\N	1073	1312	1954-10-19
1160	1	1951-12-20	1967-06-16	\N	1074	1275	1952-01-30
1161	1	1955-03-18	1971-05-08	\N	1075	1316	1955-10-26
1162	1	1955-05-04	1985-07-12	\N	1076	1317	1955-05-05
1163	1	1955-05-12	1974-08-28	\N	1077	1319	1955-06-22
1164	1	1955-07-25	1974-06-15	\N	1078	1321	1955-11-23
1165	1	1955-08-04	1975-05-22	\N	1079	1322	1955-11-23
1166	1	1956-01-20	1966-10-03	\N	1080	1331	1956-01-31
1167	1	1955-12-16	1967-10-08	\N	1081	1324	1956-01-25
1168	1	1956-01-12	1991-04-05	\N	1082	1326	1956-02-01
1169	1	1956-01-13	1961-10-17	\N	1083	1327	1956-02-15
1170	1	1956-01-17	1966-10-11	\N	1084	1328	1956-02-01
1171	1	1956-01-18	1960-07-13	\N	1085	1329	1956-01-26
1172	1	1956-01-19	1996-01-06	\N	1086	1330	1956-01-31
1173	1	1956-01-21	1971-07-19	\N	1087	1332	1956-03-21
1174	1	1956-01-23	1976-04-10	\N	1088	1333	1956-02-15
1175	1	1956-06-26	1957-07-03	\N	1089	1334	1956-07-11
1176	1	1956-07-09	1960-08-19	\N	1090	1335	1956-07-18
1177	1	1956-07-16	1977-08-07	\N	1091	1336	1956-10-30
1178	1	1957-01-21	1979-03-04	\N	1092	1337	1957-03-27
1179	1	1957-07-01	1963-10-26	\N	1093	1344	1957-07-24
1180	1	1957-02-11	1965-01-09	\N	1094	1340	1957-04-03
1181	1	1957-02-12	1967-02-14	\N	1095	1341	1957-02-27
1182	1	1957-02-15	1974-11-05	\N	1096	1342	1957-05-22
1183	1	1957-04-24	1999-03-05	\N	1097	1343	1957-05-15
1184	1	1957-07-02	1972-03-29	\N	1098	1345	1957-07-17
1185	1	1958-01-31	1962-02-10	\N	1099	1349	1958-02-19
1186	1	1958-01-30	1976-10-10	\N	1100	1348	1958-02-18
1187	1	1958-02-17	1989-01-20	\N	1101	1350	1958-02-19
1188	1	1958-07-10	1962-07-21	\N	1102	1351	1958-07-16
1189	1	1958-07-11	1993-01-28	\N	1103	1352	1958-07-16
1190	1	1958-08-01	1974-12-19	\N	1104	1354	1958-10-22
1191	1	1958-08-02	1971-12-22	\N	1105	1355	1958-10-21
1192	1	1958-08-04	1983-05-02	\N	1106	1356	1958-10-22
1193	1	1958-08-05	1961-03-06	\N	1107	1357	1959-03-10
1194	1	1958-08-06	1984-09-23	\N	1108	1358	1958-10-21
1195	1	1958-08-07	1988-02-01	\N	1109	1359	1958-10-22
1196	1	1955-01-28	1977-08-04	\N	1110	1314	1955-03-02
1197	1	1956-01-09	1964-12-14	\N	934	1325	1956-02-01
1198	1	1958-07-26	\N	\N	1111	1353	1970-02-11
1199	1	1955-02-18	1970-04-01	\N	1112	1315	1955-04-27
1200	1	1955-06-20	1984-09-20	\N	1113	1320	1955-07-20
1201	1	1958-09-22	1971-05-22	\N	1114	1364	1958-10-21
1202	1	1958-09-24	1992-06-04	\N	1115	1365	1958-10-22
1203	1	1958-09-26	1994-01-03	\N	1116	1366	1958-10-22
1204	1	1958-10-06	1966-02-09	\N	1117	1368	1958-10-22
1205	1	1958-09-30	1972-09-15	\N	1118	1367	1958-10-21
1206	1	1959-02-14	2003-07-10	\N	1119	1369	1959-05-06
1207	1	1959-02-16	1964-12-12	\N	1120	1370	1959-04-15
1208	1	1959-02-17	2001-02-15	\N	1121	1371	1959-04-15
1209	1	1959-02-19	1992-05-16	\N	1122	1372	1959-03-10
1210	1	1959-03-10	1980-11-08	\N	1123	1373	1959-04-08
1211	1	1959-06-16	1984-05-15	\N	1124	1375	1959-07-15
1212	1	1959-04-06	1969-07-21	\N	1125	1374	1959-04-08
1213	1	1959-07-15	1977-03-26	\N	1126	1376	1959-07-16
1214	1	1959-07-16	1972-07-24	\N	1127	1377	1959-07-22
1215	1	1959-08-20	1973-11-15	\N	1128	1378	1959-10-21
1216	1	1959-11-02	1965-03-06	\N	1129	1379	1959-11-17
1217	1	1959-11-20	1971-02-20	\N	1130	1382	1959-12-16
1218	1	1959-11-03	1993-07-28	\N	1131	1380	1959-11-04
1219	1	1959-12-08	1979-11-11	\N	1132	1383	1959-12-09
1220	1	1959-12-16	1969-12-06	\N	1133	1384	1960-01-27
1221	1	1960-01-20	1993-05-24	\N	1134	1386	1960-02-10
1222	1	1960-01-20	1962-07-16	\N	1135	1387	1960-04-06
1223	1	1960-01-28	1962-02-13	\N	1136	1388	1960-02-03
1224	1	1960-01-30	1965-09-04	\N	1137	1389	1960-02-10
1225	1	1960-02-08	1973-03-10	\N	1138	1390	1960-03-09
1226	1	1960-07-04	1971-08-15	\N	1139	1393	1960-10-26
1227	1	1960-04-12	1996-10-24	\N	1140	1391	1960-06-01
1228	1	1960-07-15	1970-12-14	\N	1141	1394	1960-11-16
1229	1	1958-08-11	1994-09-22	\N	1142	1361	1958-10-21
1230	1	1960-08-02	1983-03-29	\N	1143	1395	1966-04-20
1231	1	1960-08-22	1973-04-27	\N	1144	1396	1960-11-09
1232	1	1960-09-01	1981-01-19	\N	1145	1397	1960-10-26
1233	1	1960-09-08	1983-03-08	\N	1146	1398	1960-11-16
1234	1	1960-10-01	1984-03-11	\N	1147	1399	1960-10-25
1235	1	1960-11-11	1988-06-15	\N	1148	1400	1960-11-23
1236	1	1960-11-23	1987-11-01	\N	1149	1401	1960-11-30
1237	1	1961-01-20	1984-09-25	\N	1150	1402	1961-01-24
1238	1	1958-08-18	1967-07-21	\N	1151	1362	1958-10-22
1239	1	1958-08-22	1986-07-16	\N	1152	1363	1958-11-12
1240	1	1961-02-08	1978-04-13	\N	1153	1407	1961-03-01
1241	1	1961-02-09	1971-09-08	\N	1154	1408	1961-02-15
1242	1	1961-02-10	1991-05-29	\N	1155	1409	1961-04-12
1243	1	1961-02-21	1991-10-13	\N	1156	1411	1961-03-01
1244	1	1961-02-16	1998-10-28	\N	1157	1410	1961-02-21
1245	1	1961-06-28	1999-06-27	\N	1158	1413	1961-07-26
1246	1	1961-06-02	1972-09-15	\N	1159	1412	1961-06-07
1247	1	1961-06-29	1974-04-29	\N	1160	1414	1961-07-19
1248	1	1961-07-10	1964-12-08	\N	1161	1415	1961-07-26
1249	1	1962-01-25	1963-10-17	\N	1162	1421	1962-02-14
1250	1	1961-07-25	1966-08-20	\N	779	1418	1967-05-10
1251	1	1961-10-11	1992-08-09	\N	1163	1420	1961-10-19
1252	1	1962-01-26	1966-12-29	\N	1164	1422	1962-02-13
1253	1	1962-03-26	1967-09-13	\N	1165	1425	1962-05-17
1254	1	1962-02-02	1989-10-16	\N	1166	1424	1962-05-22
1255	1	1962-04-12	1991-10-06	\N	1167	1426	1962-04-18
1256	1	1962-04-13	1970-06-05	\N	1168	1427	1962-04-18
1257	1	1962-04-16	1997-01-10	\N	1169	1428	1962-05-16
1258	1	1962-05-03	1998-10-21	\N	1170	1430	1962-05-22
1259	1	1962-04-19	1990-11-26	\N	1171	1429	1962-05-02
1260	1	1962-05-10	1992-10-15	\N	1172	1431	1962-06-05
1261	1	1962-05-11	1985-03-02	\N	1173	1432	1962-05-17
1262	1	1962-05-14	1974-08-20	\N	1174	1433	1962-05-23
1263	1	1962-05-15	1983-02-27	\N	1175	1434	1962-05-30
1264	1	1962-06-15	1969-11-16	\N	1176	1435	1962-07-11
1265	1	1962-07-11	1977-04-01	\N	1177	1436	1962-07-25
1266	1	1963-01-18	1976-12-03	\N	1178	1441	1963-01-23
1267	1	1962-07-17	1980-09-07	\N	1179	1437	1962-07-17
1268	1	1962-08-01	1999-02-24	\N	1180	1439	1962-08-01
1269	1	1962-08-22	1968-09-10	\N	886	1440	1962-11-06
1270	1	1963-01-24	1967-06-15	\N	1181	1442	1963-11-13
1271	1	1963-01-30	1965-01-11	\N	1182	1443	1963-01-31
1272	1	1963-01-31	1997-03-03	\N	1183	1444	1963-02-13
1273	1	1963-06-13	1989-08-22	\N	1184	1445	1963-07-10
1274	1	1963-07-09	1984-07-28	\N	1185	1446	1963-07-17
1275	1	1961-02-03	1968-08-06	\N	1186	1404	1961-02-15
1276	1	1961-02-04	1980-02-04	\N	1187	1405	1961-02-07
1277	1	1961-02-07	1999-12-31	\N	1188	1406	1961-02-22
1278	1	1961-07-12	1977-01-14	\N	1189	1417	1961-07-25
1279	1	1962-07-20	1967-01-27	\N	1073	1438	1962-07-25
1280	1	1963-11-26	1971-01-27	\N	1190	1450	1963-12-04
1281	1	1964-01-11	1971-12-12	\N	1191	1452	1964-01-23
1282	1	1964-01-14	1999-02-24	\N	1180	1454	1964-01-15
1283	1	1964-01-15	1990-01-07	\N	1192	1455	1964-01-16
1284	1	1964-01-16	1981-10-27	\N	1193	1456	1964-01-22
1285	1	1964-01-18	1989-07-31	\N	1194	1457	1964-01-29
1286	1	1964-01-20	1966-02-17	\N	1195	1458	1964-01-23
1287	1	1964-01-21	1992-12-22	\N	1196	1459	1964-01-22
1288	1	1964-01-22	1973-06-05	\N	1197	1460	1964-02-05
1289	1	1964-01-23	1989-07-01	\N	1198	1461	1964-01-29
1290	1	1964-03-10	1976-08-04	\N	1199	1462	1964-03-18
1291	1	1964-04-20	1968-01-20	\N	1200	1463	1964-07-01
1292	1	1964-05-13	1989-05-03	\N	1201	1464	1964-05-13
1293	1	1964-06-26	1995-12-19	\N	1202	1465	1964-07-15
1294	1	1964-07-16	1992-08-17	\N	1203	1468	1964-07-22
1295	1	1964-07-16	1996-01-18	\N	1204	1469	1964-07-22
1296	1	1964-08-21	1975-02-01	\N	1205	1470	1964-10-28
1297	1	1964-08-22	1982-06-26	\N	1206	1471	1964-12-02
1298	1	1964-08-24	1966-02-12	\N	1207	1472	1964-11-11
1299	1	1964-08-25	1975-09-30	\N	1208	1473	1964-10-28
1300	1	1964-09-14	1987-09-11	\N	1209	1475	1964-10-28
1301	1	1964-09-17	1993-10-10	\N	1210	1476	1964-11-11
1302	1	1964-09-04	1980-12-14	\N	1211	1474	1964-11-25
1303	1	1964-10-01	2003-02-15	\N	1212	1477	1964-10-29
1304	1	1964-10-05	1970-02-14	\N	1213	1478	1964-10-29
1305	1	1964-12-07	1980-09-07	\N	1179	1482	1964-12-16
1306	1	1964-12-07	2000-09-01	\N	1214	1483	1964-12-09
1307	1	1964-10-27	1990-09-05	\N	1215	1479	1964-11-18
1308	1	1964-10-29	1980-07-01	\N	1216	1480	1964-11-04
1309	1	1964-11-11	2020-01-10	\N	1217	1481	1964-11-12
1310	1	1964-12-08	1980-10-10	\N	1218	1484	1964-12-16
1311	1	1964-12-11	1979-12-08	\N	1219	1485	1964-12-15
1312	1	1964-12-12	1970-12-29	\N	1220	1486	1964-12-14
1313	1	1964-12-14	1995-12-29	\N	1221	1487	1964-12-15
1314	1	1964-12-15	1971-10-08	\N	1222	1488	1964-12-17
1315	1	1964-12-16	1987-10-25	\N	1223	1490	1964-12-17
1316	1	1963-11-09	1987-10-11	\N	1224	1448	1963-11-14
1317	1	1964-01-13	1985-11-25	\N	1225	1453	1964-02-05
1318	1	1963-11-15	1983-08-12	\N	1226	1449	1963-12-04
1319	1	1964-12-21	1992-08-14	\N	1227	1496	1964-12-22
1320	1	1964-12-22	1985-03-17	\N	1228	1498	1965-01-20
1321	1	1964-12-22	1984-02-06	\N	1229	1499	1964-12-23
1322	1	1964-12-23	1973-09-30	\N	1230	1500	1965-03-10
1323	1	1964-12-28	1988-11-06	\N	1231	1501	1965-01-20
1324	1	1964-12-29	1978-02-23	\N	1232	1502	1965-01-21
1325	1	1964-12-30	1966-11-06	\N	1233	1503	1965-01-20
1326	1	1964-12-31	1980-12-27	\N	1234	1504	1965-02-17
1327	1	1965-01-01	1996-05-25	\N	1235	1505	1965-02-10
1328	1	1965-01-01	1965-11-11	\N	1236	1506	1965-01-26
1329	1	1965-01-28	1983-06-22	\N	1237	1507	1965-03-10
1330	1	1965-01-29	1975-10-17	\N	1238	1508	1965-03-24
1331	1	1965-02-04	1968-02-21	\N	1239	1509	1965-04-07
1332	1	1965-03-24	1979-11-29	\N	1240	1512	1965-04-14
1333	1	1965-02-18	1980-01-31	\N	1241	1510	1965-03-03
1334	1	1965-02-19	1982-03-08	\N	1242	1511	1965-02-24
1335	1	1965-05-10	1972-06-13	\N	1243	1513	1965-06-02
1336	1	1965-05-10	1991-01-17	\N	1244	1514	1965-06-02
1337	1	1965-05-11	1977-05-03	\N	1245	1516	1965-05-19
1338	1	1965-05-11	1990-10-31	\N	1246	1515	1965-06-23
1339	1	1965-05-12	1998-12-22	\N	1247	1517	1965-05-25
1340	1	1965-05-12	1969-12-27	\N	1248	1518	1965-05-26
1341	1	1965-05-13	1966-10-07	\N	1249	1519	1965-05-19
1342	1	1965-05-13	1966-10-21	\N	1250	1520	1965-05-26
1343	1	1965-05-14	1992-07-04	\N	1251	1521	1965-06-23
1344	1	1965-05-14	1992-12-31	\N	1252	1522	1965-06-02
1345	1	1965-06-22	1997-12-21	\N	1253	1524	1965-07-07
1346	1	1965-07-05	1980-09-03	\N	1254	1525	1965-12-01
1347	1	1965-07-06	1989-06-06	\N	1255	1526	1965-07-28
1348	1	1965-07-07	1985-03-23	\N	1256	1527	1965-07-14
1349	1	1965-07-16	2000-02-21	\N	1257	1528	1965-07-28
1350	1	1965-07-20	1995-05-12	\N	1258	1529	1965-07-21
1351	1	1966-01-14	1994-12-26	\N	1259	1531	1966-01-27
1352	1	1966-01-15	1966-06-02	\N	1260	1532	1966-02-02
1353	1	1965-12-07	2002-10-31	\N	1261	1530	1965-12-15
1354	1	1966-01-17	1975-07-06	\N	1262	1533	1966-02-16
1355	1	1964-12-17	1982-11-08	\N	1263	1492	1965-01-21
1356	1	1964-12-18	1987-08-17	\N	1264	1493	1964-12-21
1357	1	1964-12-18	1985-06-04	\N	1265	1494	1964-12-21
1358	1	1966-06-06	1977-08-11	\N	1266	1540	1966-06-29
1359	1	1966-06-07	1979-01-01	\N	1267	1541	1966-06-14
1360	1	1966-06-09	1982-01-16	\N	1268	1542	1966-06-22
1361	1	1966-06-10	1983-04-28	\N	1269	1543	1966-07-06
1362	1	1966-06-15	1966-10-12	\N	1270	1545	1966-07-13
1363	1	1966-06-16	1978-01-17	\N	1271	1546	1966-07-06
1364	1	1966-06-23	1974-12-23	\N	1272	1547	1966-07-05
1365	1	1966-06-24	1996-01-14	\N	1273	1548	1966-07-12
1366	1	1966-07-04	1998-11-08	\N	1274	1549	1966-11-23
1367	1	1966-07-05	1982-01-31	\N	1275	1550	1966-07-20
1368	1	1966-07-11	1988-09-02	\N	1276	1551	1966-07-13
1369	1	1966-07-20	1984-03-29	\N	1277	1552	1966-07-26
1370	1	1966-09-19	1985-09-01	\N	1278	1553	1966-10-26
1371	1	1967-01-16	1978-06-30	\N	1279	1554	1967-02-01
1372	1	1967-01-17	1990-05-30	\N	1280	1555	1967-01-25
1373	1	1967-01-18	1986-07-31	\N	1281	1556	1967-02-22
1374	1	1967-01-20	2002-10-21	\N	1282	1558	1967-01-25
1375	1	1967-07-06	1982-11-20	\N	1283	1560	1967-07-12
1376	1	1967-07-07	1991-03-03	\N	1284	1561	1967-11-15
1377	1	1967-07-10	1990-03-13	\N	1285	1562	1967-07-19
1378	1	1967-07-11	1969-12-03	\N	1286	1563	1967-07-19
1379	1	1967-08-25	1982-08-28	\N	1287	1564	1967-10-25
1380	1	1967-08-26	1993-11-28	\N	1288	1565	1967-10-24
1381	1	1967-08-29	1997-11-06	\N	1289	1566	1967-10-25
1382	1	1967-08-30	1993-12-06	\N	1290	1567	1967-10-24
1383	1	1967-09-11	1976-10-01	\N	1291	1568	1967-11-01
1384	1	1967-09-12	1998-02-14	\N	1292	1569	1967-11-01
1385	1	1967-09-14	1975-03-12	\N	1293	1570	1967-11-08
1386	1	1967-09-15	1996-12-29	\N	1294	1571	1967-10-27
1387	1	1967-09-18	1975-01-13	\N	1295	1572	1967-10-26
1388	1	1967-09-19	1974-09-05	\N	1296	1573	1967-11-08
1389	1	1967-09-20	1994-04-30	\N	1297	1574	1967-11-22
1390	1	1967-09-21	1969-12-14	\N	1298	1575	1967-11-15
1391	1	1967-09-22	1978-04-05	\N	1299	1576	1967-10-27
1392	1	1967-10-13	1972-08-02	\N	1300	1577	1967-10-26
1393	1	1967-11-20	1998-03-08	\N	1301	1578	1967-11-22
1394	1	1966-01-19	1986-03-14	\N	1302	1535	1966-02-23
1395	1	1966-05-27	1968-08-28	\N	1303	1536	1966-06-14
1396	1	1967-11-27	1983-08-11	\N	1304	1579	1967-11-28
1397	1	1966-06-02	1985-08-06	\N	1305	1539	1966-07-27
1398	1	1968-01-22	1974-09-15	\N	1306	1586	1968-02-07
1399	1	1968-01-29	2001-07-13	\N	1307	1587	1968-01-31
1400	1	1968-02-12	1985-02-08	\N	1308	1588	1968-02-21
1401	1	1968-05-21	1978-12-05	\N	1309	1589	1968-05-29
1402	1	1968-06-20	1985-01-20	\N	1310	1590	1968-06-26
1403	1	1968-06-21	1984-12-27	\N	1311	1591	1968-07-17
1404	1	1968-06-28	1972-02-05	\N	1312	1592	1968-07-31
1405	1	1968-07-10	1985-06-27	\N	1313	1593	1968-07-24
1406	1	1968-07-11	1995-12-20	\N	1314	1594	1968-07-17
1407	1	1968-09-17	1999-10-17	\N	1315	1595	1968-10-16
1408	1	1968-09-30	1985-10-14	\N	1316	1596	1968-10-07
1409	1	1969-01-09	2008-07-21	\N	1317	1597	1969-01-22
1410	1	1969-01-27	1974-07-13	\N	1318	1598	1969-02-19
1411	1	1969-02-21	1983-12-10	\N	1319	1599	1969-04-23
1412	1	1969-03-24	1971-07-01	\N	1320	1601	1969-03-26
1413	1	1969-07-02	1984-06-29	\N	1321	1602	1969-07-23
1414	1	1969-07-03	1993-02-05	\N	1322	1603	1969-11-12
1415	1	1969-07-24	1983-05-21	\N	1323	1604	1969-11-12
1416	1	1970-01-16	1994-08-18	\N	1324	1606	1970-01-21
1417	1	1970-01-23	1990-06-12	\N	1325	1607	1970-01-28
1418	1	1970-02-05	1992-07-02	\N	1326	1608	1973-06-27
1419	1	1970-02-12	\N	\N	1327	1609	1970-02-25
1420	1	1970-06-19	1986-05-08	\N	1328	1610	1970-06-29
1421	1	1970-06-20	1982-05-04	\N	1329	1611	1970-07-01
1422	1	1970-06-30	2001-10-12	\N	1330	1612	1970-06-30
1423	1	1970-07-01	1978-03-11	\N	1331	1613	1970-07-01
1424	1	1970-07-02	1995-01-26	\N	1332	1614	1970-07-21
1425	1	1970-07-03	1981-09-28	\N	1333	1615	1970-07-21
1426	1	1970-07-04	1976-08-07	\N	1334	1616	1970-07-14
1427	1	1970-07-06	1980-03-17	\N	1335	1617	1970-07-15
1428	1	1970-07-07	1981-03-08	\N	1336	1618	1970-07-22
1429	1	1970-07-08	1977-04-21	\N	1337	1619	1970-07-15
1430	1	1970-07-09	1990-06-09	\N	1338	1620	1970-07-16
1431	1	1970-07-28	1988-07-28	\N	1339	1621	1970-11-04
1432	1	1970-07-31	1972-12-02	\N	1340	1622	1970-11-04
1433	1	1967-12-04	1994-06-04	\N	1341	1581	1967-12-06
1434	1	1967-12-06	2008-04-08	\N	1342	1583	1967-12-13
1435	1	1968-01-18	1983-12-22	\N	1343	1584	1968-02-07
1436	1	1970-10-12	1999-12-23	\N	1344	1627	1970-11-11
1437	1	1970-11-05	1988-11-16	\N	1345	1629	1970-11-10
1438	1	1970-11-06	1985-06-02	\N	1346	1630	1970-11-10
1439	1	1971-01-29	1980-02-08	\N	1347	1631	1971-02-03
1440	1	1981-05-12	2001-05-26	\N	1348	1856	1981-05-13
1441	1	1971-03-02	1986-09-03	\N	1349	1634	1971-03-31
1442	1	1971-03-05	1989-07-11	\N	1350	1635	1971-03-24
1443	1	1971-03-12	1989-08-04	\N	1351	1636	1971-03-15
1444	1	1971-04-20	1981-07-26	\N	1352	1637	1971-04-26
1445	1	1971-04-30	1999-08-19	\N	1353	1638	1971-05-04
1446	1	1971-05-01	1994-04-05	\N	1354	1639	1971-05-12
1447	1	1971-05-17	2003-09-20	\N	1355	1640	1971-06-08
1448	1	1971-05-18	1997-04-23	\N	1356	1641	1971-05-19
1449	1	1971-05-21	\N	\N	1357	1642	1971-05-25
1450	1	1971-05-24	2002-09-06	\N	1358	1643	1971-06-16
1451	1	1971-06-04	1999-11-17	\N	1359	1644	1971-06-09
1452	1	1971-06-18	1993-04-01	\N	1360	1645	1971-07-20
1453	1	1971-07-20	2002-05-17	\N	1361	1646	1971-12-08
1454	1	1971-10-04	1989-09-10	\N	1362	1647	1971-10-27
1455	1	1972-01-10	1991-11-07	\N	1363	1648	1972-01-26
1456	1	1972-04-20	1984-04-30	\N	1364	1649	1972-06-28
1457	1	1972-04-24	1985-05-09	\N	1365	1650	1972-05-03
1458	1	1972-04-26	1979-07-02	\N	1366	1651	1972-06-08
1459	1	1972-04-28	1990-12-15	\N	1367	1652	1972-06-07
1460	1	1972-05-01	1998-07-11	\N	1368	1653	1972-06-15
1461	1	1972-05-02	2009-10-17	\N	1369	1654	1972-05-10
1462	1	1972-05-09	1993-04-04	\N	1370	1655	1972-06-14
1463	1	1972-05-10	1983-11-02	\N	1371	1656	1972-06-07
1464	1	1972-07-03	1987-08-28	\N	1372	1657	1972-07-19
1465	1	1972-07-10	1980-11-28	\N	1373	1658	1972-07-27
1466	1	1973-02-05	1994-01-01	\N	1374	1659	1973-02-07
1467	1	1973-03-14	1995-11-24	\N	1375	1660	1973-06-13
1468	1	1973-06-18	\N	\N	1376	1661	1973-06-27
1469	1	1973-06-22	1977-03-16	\N	1377	1662	1973-07-11
1470	1	1973-06-25	1987-12-28	\N	1378	1663	1973-11-13
1471	1	1973-06-29	1991-01-30	\N	1379	1664	1973-07-04
1472	1	1973-07-06	1992-10-22	\N	1380	1665	1973-07-17
1473	1	1973-07-16	1979-04-04	\N	1381	1667	1973-07-24
1474	1	1970-09-22	1982-04-12	\N	1382	1624	1970-10-28
1475	1	1970-09-25	2004-04-03	\N	1383	1625	1970-11-03
1476	1	1970-09-28	1985-10-28	\N	1384	1626	1970-11-11
1477	1	1974-03-25	1981-07-22	\N	1385	1672	1974-03-26
1478	1	1974-03-26	2001-04-11	\N	1386	1673	1974-03-26
1479	1	1974-05-02	1987-11-26	\N	1387	1674	1974-05-21
1480	1	1974-05-03	1984-05-15	\N	1388	1675	1974-05-09
1481	1	1974-05-06	1984-09-12	\N	1389	1676	1974-05-09
1482	1	1974-05-08	1978-07-06	\N	1390	1678	1974-05-15
1483	1	1974-05-09	1994-01-17	\N	1391	1679	1974-06-25
1484	1	1974-05-10	2015-02-17	\N	1392	1680	1974-05-15
1485	1	1974-05-13	1985-07-03	\N	1393	1681	1974-06-12
1486	1	1974-05-14	1999-02-09	\N	1394	1682	1974-05-22
1487	1	1974-05-15	2004-01-11	\N	1395	1683	1974-07-03
1488	1	1974-05-16	2004-08-12	\N	1396	1684	1974-05-22
1489	1	1974-06-11	1996-07-01	\N	1397	1685	1974-07-24
1490	1	1974-06-18	1979-12-26	\N	1398	1686	1974-06-26
1491	1	1974-06-19	1979-10-12	\N	1399	1687	1974-07-16
1492	1	1974-06-20	1996-05-02	\N	1400	1688	1974-07-10
1493	1	1974-06-21	1980-03-23	\N	1401	1689	1974-07-10
1494	1	1974-06-24	1997-01-01	\N	1402	1690	1974-10-24
1495	1	1974-06-25	1996-06-08	\N	1403	1691	1974-07-11
1496	1	1974-06-26	2001-01-06	\N	1404	1692	1974-07-03
1497	1	1974-06-27	1997-11-22	\N	1405	1693	1974-07-29
1498	1	1974-06-28	1997-12-23	\N	1406	1694	1974-07-24
1499	1	1974-07-01	1984-02-04	\N	1407	1695	1974-07-08
1500	1	1974-07-02	2005-12-18	\N	1408	1696	1974-07-09
1501	1	1974-07-03	1985-10-18	\N	1409	1697	1974-07-09
1502	1	1974-07-04	1980-12-02	\N	1410	1698	1974-07-17
1503	1	1974-07-08	1992-04-28	\N	1411	1700	1974-07-18
1504	1	1974-07-09	1986-09-30	\N	1412	1701	1974-07-17
1505	1	1974-07-10	1985-01-14	\N	1413	1702	1974-11-13
1506	1	1974-07-11	2019-02-06	\N	1414	1703	1974-07-23
1507	1	1974-07-12	1985-01-18	\N	1415	1704	1974-11-27
1508	1	1974-10-01	1992-12-27	\N	1416	1706	1974-10-23
1509	1	1974-11-18	1988-04-23	\N	1417	1707	1975-01-29
1510	1	1975-01-02	1990-01-02	\N	1418	1709	1975-01-21
1511	1	1975-01-03	1977-07-23	\N	1419	1710	1975-03-05
1512	1	1975-01-06	2005-12-16	\N	1420	1711	1975-04-16
1513	1	1975-01-07	1997-06-15	\N	1421	1712	1975-02-11
1514	1	1974-03-06	1976-07-28	\N	1422	1669	1974-04-10
1515	1	1974-03-07	1987-07-21	\N	1423	1670	1974-03-27
1516	1	1974-03-11	1989-12-04	\N	1424	1671	1974-03-11
1517	1	1975-01-14	1983-01-25	\N	1425	1717	1975-01-28
1518	1	1975-01-15	1984-12-28	\N	1426	1718	1975-01-28
1519	1	1975-01-16	1992-03-27	\N	1427	1719	1975-02-11
1520	1	1975-01-17	2003-11-11	\N	1428	1720	1975-02-05
1521	1	1975-01-20	2005-04-18	\N	1429	1721	1975-01-27
1522	1	1975-01-21	2004-07-26	\N	1430	1722	1975-02-04
1523	1	1975-01-22	1978-01-18	\N	1431	1723	1975-02-04
1524	1	1975-01-23	1980-04-26	\N	1432	1724	1975-02-25
1525	1	1975-01-24	\N	\N	1433	1725	1975-03-05
1526	1	1975-01-27	1994-05-23	\N	1434	1726	1975-02-03
1527	1	1975-01-28	1978-01-05	\N	1435	1727	1975-02-19
1528	1	1975-01-29	1980-07-12	\N	1436	1728	1975-03-04
1529	1	1975-01-30	1995-10-16	\N	1437	1729	1975-02-25
1530	1	1975-01-31	2004-04-20	\N	1438	1730	1975-02-18
1531	1	1975-07-10	1977-07-26	\N	1439	1732	\N
1532	1	1975-07-11	2009-08-12	\N	1440	1733	1975-07-23
1533	1	1975-07-14	1981-03-12	\N	1441	1734	1975-10-22
1534	1	1975-07-15	2003-05-12	\N	1442	1735	1975-07-15
1535	1	1975-07-16	1988-08-13	\N	1443	1736	1975-11-03
1536	1	1975-07-17	\N	\N	1444	1737	1975-07-23
1537	1	1975-09-30	1986-06-23	\N	1445	1738	1975-10-27
1538	1	1976-01-14	2002-07-31	\N	1446	1739	1976-04-07
1539	1	1976-01-15	2012-02-17	\N	1447	1740	1976-03-10
1540	1	1976-01-16	1976-08-12	\N	1448	1741	1976-01-28
1541	1	1976-01-19	2012-11-18	\N	1449	1742	1976-02-11
1542	1	1976-01-20	2013-04-18	\N	1450	1743	1976-01-27
1543	1	1976-01-21	2004-09-01	\N	1451	1744	1976-01-27
1544	1	1976-01-22	1999-09-04	\N	1452	1745	1976-02-03
1545	1	1976-01-23	1993-07-18	\N	1453	1746	1976-02-04
1546	1	1976-01-26	1996-03-13	\N	1454	1747	1976-02-17
1547	1	1976-01-27	1995-01-07	\N	1455	1748	1976-02-10
1548	1	1976-01-29	1995-08-02	\N	1456	1749	1976-02-25
1549	1	1976-01-30	2004-02-02	\N	1457	1750	1976-02-17
1550	1	1976-02-03	1980-02-24	\N	1458	1751	1976-03-03
1551	1	1976-02-05	1980-12-29	\N	1459	1752	1976-03-17
1552	1	1976-03-08	1978-05-17	\N	1460	1753	1976-03-10
1553	1	1976-06-22	1998-12-13	\N	1461	1754	1976-06-23
1554	1	1976-06-23	1984-07-19	\N	1462	1755	1976-07-07
1555	1	1976-06-24	1986-07-17	\N	1463	1756	1976-07-14
1556	1	1975-01-13	1989-02-17	\N	1464	1716	1975-01-22
1557	1	1976-07-02	1976-12-04	\N	1465	1762	\N
1558	1	1976-07-12	2007-11-27	\N	1466	1763	1976-07-21
1559	1	1976-07-19	2016-03-15	\N	1467	1764	1976-12-08
1560	1	1976-08-02	2003-10-10	\N	1468	1765	1976-10-12
1561	1	1976-09-23	1988-08-26	\N	1469	1766	1976-09-27
1562	1	1976-10-18	1981-05-31	\N	1470	1768	1977-02-15
1563	1	1977-01-10	2002-06-21	\N	1471	1769	1977-01-10
1564	1	1977-01-28	2012-05-04	\N	1472	1770	1977-02-02
1565	1	1977-02-01	1985-09-09	\N	1473	1771	1977-02-15
1566	1	1977-02-07	1977-03-03	\N	1474	1772	1977-02-22
1567	1	1977-02-08	1989-11-26	\N	1475	1773	1977-03-09
1568	1	1977-03-23	2008-10-03	\N	1476	1774	1977-03-30
1569	1	1977-07-15	2001-12-09	\N	1477	1775	1977-07-19
1570	1	1977-07-18	2013-07-12	\N	1478	1776	1977-07-26
1571	1	1977-07-19	2005-03-30	\N	1479	1777	1977-07-20
1572	1	1977-07-20	2012-03-09	\N	1480	1778	1977-07-26
1573	1	1977-07-22	1982-10-08	\N	1481	1779	1977-11-16
1574	1	1978-02-08	2011-09-11	\N	1482	1782	1978-04-05
1575	1	1977-09-30	2004-12-08	\N	1483	1780	1977-10-26
1576	1	1978-02-09	1997-11-10	\N	1484	1783	1978-03-01
1577	1	1978-02-27	2019-04-29	\N	1485	1784	1978-03-15
1578	1	1978-03-20	2002-01-14	\N	1486	1785	1978-03-22
1579	1	1978-04-14	2007-01-08	\N	1487	1786	1978-04-19
1580	1	1978-04-17	2006-06-28	\N	1488	1787	1978-04-19
1581	1	1978-04-19	1987-09-16	\N	1489	1788	1978-04-26
1582	1	1978-04-21	2018-05-26	\N	1490	1789	1978-05-03
1583	1	1978-04-24	1992-03-22	\N	1491	1790	1978-04-26
1584	1	1978-04-26	2005-08-16	\N	1492	1791	1978-05-17
1585	1	1978-04-28	2009-11-29	\N	1493	1792	1978-05-03
1586	1	1978-05-02	1983-07-17	\N	1494	1793	1978-06-14
1587	1	1978-05-03	2001-09-09	\N	1495	1794	1978-05-24
1588	1	1978-05-04	2016-11-25	\N	1496	1795	1978-05-17
1589	1	1978-05-05	1992-10-11	\N	1497	1796	1978-05-10
1590	1	1978-05-09	1986-08-09	\N	1498	1797	1978-06-07
1591	1	1978-05-10	2006-01-27	\N	1499	1798	1978-06-28
1592	1	1978-05-19	1985-05-15	\N	1500	1801	1978-05-24
1593	1	1978-07-10	1998-08-22	\N	1501	1802	1978-07-19
1594	1	1976-06-29	1994-07-28	\N	1502	1759	1976-09-29
1595	1	1976-06-30	1995-01-17	\N	1503	1760	1976-07-06
1596	1	1976-07-01	2011-07-23	\N	1504	1761	1976-07-07
1597	1	1979-01-31	2000-11-02	\N	1505	1807	1979-07-24
1598	1	1979-02-02	2004-08-15	\N	1506	1808	1979-03-07
1599	1	1979-02-05	2004-05-16	\N	1507	1809	1979-03-21
1600	1	1979-02-07	1991-06-14	\N	1508	1810	1979-03-29
1601	1	1979-02-19	2004-01-27	\N	1509	1812	1979-02-21
1602	1	1979-02-20	2010-06-25	\N	1510	1813	1979-03-28
1603	1	1979-05-21	2001-02-11	\N	1511	1814	1979-05-23
1604	1	1979-07-03	1995-08-06	\N	1512	1815	1979-07-10
1605	1	1979-07-05	1990-03-10	\N	1513	1816	1979-07-17
1606	1	1979-07-06	\N	\N	1514	1817	1979-07-11
1607	1	1979-07-09	1993-06-05	\N	1515	1818	1979-07-11
1608	1	1979-07-10	1989-12-18	\N	1516	1819	1979-07-10
1609	1	1979-07-10	1993-09-23	\N	1517	1820	1979-07-16
1610	1	1979-07-11	2007-02-26	\N	1518	1821	1979-07-25
1611	1	1979-07-11	2007-05-24	\N	1519	1822	1979-07-16
1612	1	1979-07-12	1980-08-25	\N	1520	1823	1979-07-18
1613	1	1979-07-12	1993-03-12	\N	1521	1824	1979-07-17
1614	1	1979-07-16	2001-02-22	\N	1522	1825	1979-07-18
1615	1	1979-07-17	2016-03-04	\N	1523	1826	1979-07-23
1616	1	1979-07-19	2006-10-19	\N	1524	1828	1979-07-24
1617	1	1979-07-24	1988-06-10	\N	1525	1829	1979-07-25
1618	1	1979-07-25	2009-07-05	\N	1526	1830	1979-11-28
1619	1	1979-07-30	2012-05-13	\N	1527	1832	1979-11-20
1620	1	1979-08-06	1992-11-27	\N	1528	1833	1979-11-07
1621	1	1979-08-07	2002-08-11	\N	1529	1834	1979-11-14
1622	1	1979-09-07	2002-02-07	\N	1530	1835	1979-11-07
1623	1	1979-09-27	2003-01-26	\N	1531	1836	1979-11-14
1624	1	1979-10-02	1979-11-07	\N	1532	1838	1979-10-31
1625	1	1979-09-28	2005-08-21	\N	1533	1837	1979-10-24
1626	1	1980-01-28	2000-05-17	\N	1534	1839	1980-03-05
1627	1	1980-02-04	2018-11-26	\N	1535	1840	1980-02-06
1628	1	1980-02-06	2004-09-01	\N	1536	1841	1980-02-13
1629	1	1980-02-08	2008-07-17	\N	1537	1842	1980-02-20
1630	1	1980-02-11	2002-11-20	\N	1538	1843	1980-02-13
1631	1	1980-02-14	2001-02-23	\N	1539	1844	1980-03-05
1632	1	1978-07-17	1994-03-24	\N	1540	1804	1978-07-19
1633	1	1980-04-15	1996-10-04	\N	1541	1846	1980-04-16
1634	1	1978-07-18	1990-10-11	\N	1542	1805	1978-07-24
1635	1	1978-07-21	2008-05-16	\N	1543	1806	1978-07-25
1636	1	1980-09-29	2007-11-20	\N	1544	1852	1980-10-08
1637	1	1981-02-16	1990-09-22	\N	1545	1854	1981-02-24
1638	1	1981-05-11	2019-06-22	\N	1546	1855	1981-05-20
1639	1	1981-05-14	2004-01-26	\N	1547	1857	1981-05-19
1640	1	1981-05-18	1994-05-26	\N	1548	1858	1981-05-19
1641	1	1981-05-19	1988-04-17	\N	1549	1859	1981-06-09
1642	1	1981-05-21	1984-04-19	\N	1550	1860	1981-06-02
1643	1	1981-05-22	1992-10-08	\N	1551	1861	1981-06-03
1644	1	1981-05-26	1999-03-22	\N	1552	1862	1981-06-02
1645	1	1981-05-27	2021-07-07	\N	1553	1863	1981-06-16
1646	1	1981-05-28	2015-02-01	\N	1554	1864	1981-06-17
1647	1	1981-05-29	2009-10-02	\N	1555	1865	1981-07-01
1648	1	1981-06-01	2003-05-31	\N	1556	1866	1981-06-10
1649	1	1981-06-16	2017-05-07	\N	1557	1868	1981-07-07
1650	1	1981-07-06	1997-01-07	\N	1558	1870	1981-07-08
1651	1	1981-07-15	2011-07-29	\N	1559	1871	1981-07-28
1652	1	1981-07-21	2004-02-13	\N	1560	1872	1981-07-28
1653	1	1981-09-22	1993-08-25	\N	1561	1873	1981-10-14
1654	1	1982-02-02	2007-02-28	\N	1562	1875	1982-03-02
1655	1	1982-02-08	1999-04-16	\N	1563	1876	1982-03-24
1656	1	1981-09-24	1999-03-24	\N	1564	1874	1981-10-05
1657	1	1982-02-10	1996-11-19	\N	1565	1877	1982-03-03
1658	1	1982-03-12	2006-02-06	\N	1566	1878	1982-03-17
1659	1	1982-05-21	2000-05-27	\N	1567	1879	1982-07-21
1660	1	1982-07-14	2010-11-09	\N	1568	1880	1982-07-28
1661	1	1982-07-16	1993-02-23	\N	1569	1881	1982-10-20
1662	1	1982-07-20	1993-05-27	\N	1570	1882	1982-07-28
1663	1	1982-09-30	2014-06-04	\N	1571	1883	1982-10-13
1664	1	1982-11-19	1999-01-23	\N	1572	1884	1983-02-02
1665	1	1983-01-17	2010-08-27	\N	1573	1885	1983-01-26
1666	1	1983-01-20	2018-01-15	\N	1574	1886	1983-01-26
1667	1	1983-01-24	\N	\N	1575	1887	1983-03-02
1668	1	1983-01-27	1995-02-15	\N	1576	1888	1983-02-16
1669	1	1983-01-31	2002-02-07	\N	1577	1889	1983-02-02
1670	1	1983-02-02	2015-12-22	\N	1578	1890	1983-02-09
1671	1	1983-02-03	1998-06-26	\N	1579	1891	1983-02-09
1672	1	1980-07-11	1990-11-01	\N	1580	1848	1980-07-23
1673	1	1980-07-17	2002-07-23	\N	1581	1849	1980-10-15
1674	1	1981-02-02	1995-03-05	\N	1582	1853	1981-02-11
1675	1	1983-03-28	2004-01-04	\N	1583	1897	1983-03-30
1676	1	1983-06-30	2004-11-01	\N	1584	1899	1983-07-06
1677	1	1983-06-16	1999-07-01	\N	1585	1898	1983-06-16
1678	1	1983-07-01	1984-11-27	\N	1586	1900	1983-07-06
1679	1	1983-07-15	2005-07-12	\N	1587	1903	1983-07-26
1680	1	1983-07-04	2006-03-14	\N	1588	1901	1983-07-05
1681	1	1983-07-11	1997-09-22	\N	1589	1902	1983-07-19
1682	1	1983-09-05	1994-06-03	\N	1590	1904	1983-11-01
1683	1	1983-09-07	2008-03-29	\N	1591	1905	1983-11-09
1684	1	1983-09-09	1995-06-17	\N	1592	1906	1983-11-01
1685	1	1983-09-12	2020-03-20	\N	1593	1907	1983-10-25
1686	1	1983-09-14	2020-11-14	\N	1594	1908	1983-10-26
1687	1	1983-09-16	1995-05-24	\N	1595	1909	1983-11-15
1688	1	1983-09-19	1993-11-09	\N	1596	1910	1983-11-02
1689	1	1983-09-21	1992-01-22	\N	1597	1911	1983-11-30
1690	1	1983-09-23	1991-03-13	\N	1598	1912	1983-11-09
1691	1	1983-09-27	2001-12-28	\N	1599	1913	1983-11-22
1692	1	1983-09-28	1999-02-26	\N	1600	1914	1983-11-02
1693	1	1983-09-30	2014-11-01	\N	1601	1915	1983-11-08
1694	1	1983-10-03	2020-05-23	\N	1602	1916	1983-11-16
1695	1	1983-10-05	2006-11-22	\N	1603	1917	1983-10-25
1696	1	1983-10-07	1990-04-15	\N	1604	1918	1983-11-15
1697	1	1983-10-10	2001-07-19	\N	1605	1919	1983-11-22
1698	1	1983-10-12	1993-10-24	\N	1606	1920	1983-11-16
1699	1	1983-10-14	2005-08-26	\N	1607	1921	1983-10-26
1700	1	1984-01-30	1995-03-15	\N	1608	1922	1984-02-01
1701	1	1984-01-31	1995-11-03	\N	1609	1923	1984-02-15
1702	1	1985-02-04	2004-10-19	\N	1610	1929	1985-02-06
1703	1	1984-06-08	\N	\N	1611	1927	1984-06-20
1704	1	1984-10-10	\N	\N	1612	1928	1984-10-16
1705	1	1985-02-06	2019-03-20	\N	1613	1930	1985-03-27
1706	1	1985-02-07	\N	\N	1614	1931	1985-02-27
1707	1	1985-02-14	2004-05-20	\N	1615	1932	1985-02-20
1708	1	1985-05-09	2014-03-27	\N	1616	1933	1985-05-21
1709	1	1985-05-13	1988-08-17	\N	1617	1934	1985-05-15
1710	1	1985-05-15	2003-06-19	\N	1618	1935	1985-06-05
1711	1	1983-02-09	2017-03-28	\N	1619	1893	1983-02-23
1712	1	1983-02-10	2002-05-03	\N	1620	1894	1983-03-16
1713	1	1983-03-14	1985-01-29	\N	1621	1896	1983-03-16
1714	1	1985-05-29	2018-02-26	\N	1622	1941	1985-06-18
1715	1	1985-05-23	2015-05-30	\N	1623	1940	1985-06-05
1716	1	1985-05-30	1995-04-26	\N	1624	1942	1985-06-12
1717	1	1985-06-05	\N	\N	1625	1943	1985-06-11
1718	1	1985-06-10	\N	\N	1626	1944	1985-06-12
1719	1	1985-06-13	2010-05-20	\N	1627	1945	1985-06-26
1720	1	1985-07-12	1998-05-09	\N	1628	1946	1985-07-17
1721	1	1985-07-22	1996-02-20	\N	1629	1947	1985-07-30
1722	1	1986-02-14	1997-12-05	\N	1630	1951	1986-07-22
1723	1	1986-01-30	2006-03-21	\N	1631	1948	1986-02-05
1724	1	1986-01-31	2007-10-17	\N	1632	1949	1986-02-05
1725	1	1986-02-06	2016-08-14	\N	1633	1950	1986-02-11
1726	1	1986-07-21	1994-09-04	\N	1634	1952	1986-07-30
1727	1	1986-07-22	2009-04-07	\N	1635	1953	1986-07-22
1728	1	1986-09-23	2007-08-17	\N	1636	1955	1986-10-15
1729	1	1987-02-03	1997-12-07	\N	1637	1956	1987-02-04
1730	1	1987-02-09	2019-11-12	\N	1638	1957	1987-02-17
1731	1	1987-03-18	\N	\N	1639	1958	1987-04-07
1732	1	1987-03-23	2006-12-18	\N	1640	1959	1987-03-24
1733	1	1987-03-24	2016-04-23	\N	1641	1960	1987-03-25
1734	1	1987-03-25	\N	\N	1642	1961	1987-03-25
1735	1	1987-03-27	\N	\N	1643	1962	1987-03-31
1736	1	1987-03-31	1989-01-25	\N	1644	1964	1987-03-31
1737	1	1987-04-03	1989-09-16	\N	1645	1965	1987-04-07
1738	1	1987-04-06	\N	\N	1646	1966	1987-04-28
1739	1	1987-04-07	2005-05-31	\N	1647	1967	1987-05-06
1740	1	1987-04-08	1997-07-27	\N	1648	1968	1987-04-08
1741	1	1987-07-14	2012-07-08	\N	1649	1970	1987-07-15
1742	1	1987-07-22	2014-12-11	\N	1650	1971	1987-07-22
1743	1	1987-10-06	2001-03-26	\N	1651	1973	1987-10-20
1744	1	1987-10-07	2008-02-04	\N	1652	1974	1987-10-21
1745	1	1987-10-08	1996-03-06	\N	1653	1975	1987-10-21
1746	1	1987-10-09	2008-03-07	\N	1654	1976	1987-10-28
1747	1	1987-10-12	1994-12-10	\N	1655	1977	1987-10-28
1748	1	1987-10-13	2003-12-18	\N	1656	1978	1987-11-03
1749	1	1987-10-14	2016-12-12	\N	1657	1979	1987-11-11
1750	1	1985-05-17	1986-07-16	\N	1658	1937	1985-06-04
1751	1	1985-05-21	\N	\N	1659	1938	1985-06-26
1752	1	1985-05-22	2019-12-30	\N	1660	1939	1985-06-04
1753	1	1987-11-03	2016-12-20	\N	1661	1985	1987-11-11
1754	1	1987-11-04	1993-05-10	\N	1662	1986	1987-12-08
1755	1	1987-11-05	2005-03-26	\N	1663	1987	1987-11-17
1756	1	1987-11-16	2008-11-30	\N	1664	1988	1987-11-24
1757	1	1987-11-20	2003-01-05	\N	1665	1989	1987-12-01
1758	1	1988-02-05	1999-10-31	\N	1666	1990	1988-02-09
1759	1	1988-02-08	1991-12-08	\N	1667	1991	1988-02-10
1760	1	1988-02-15	2005-08-31	\N	1668	1993	1988-02-24
1761	1	1988-02-09	2007-07-18	\N	1669	1992	1988-02-09
1762	1	1988-02-26	2020-04-03	\N	1670	1994	1988-03-15
1763	1	1988-07-11	2005-11-06	\N	1671	1995	1988-07-12
1764	1	1986-07-23	\N	\N	1672	1954	1987-02-11
1765	1	1988-08-08	2012-12-29	\N	1673	1996	1988-10-25
1766	1	1988-08-10	2000-07-22	\N	1674	1997	1988-11-09
1767	1	1988-10-18	2000-04-01	\N	1675	1998	1988-11-30
1768	1	1989-01-09	2014-06-12	\N	1676	1999	1989-01-18
1769	1	1989-01-31	\N	\N	1677	2000	1989-01-31
1770	1	1989-02-08	2014-07-17	\N	1678	2001	1989-02-08
1771	1	1989-02-09	\N	\N	1679	2002	1989-02-28
1772	1	1989-07-21	1994-05-02	\N	1680	2004	1989-07-26
1773	1	1989-02-10	2013-06-22	\N	1681	2003	1989-02-22
1774	1	1989-07-24	2016-04-21	\N	1682	2005	1989-10-11
1775	1	1989-07-25	\N	\N	1683	2006	1989-07-26
1776	1	1990-02-26	1992-02-17	\N	1684	2007	1990-03-07
1777	1	1990-02-28	2020-04-11	\N	1685	2009	1990-03-13
1778	1	1990-05-09	2001-04-30	\N	1686	2011	1990-05-09
1779	1	1990-05-10	\N	\N	1687	2012	1990-05-15
1780	1	1990-05-14	2018-03-18	\N	1688	2013	1990-05-15
1781	1	1990-05-16	2018-06-07	\N	1689	2014	1990-05-22
1782	1	1990-05-17	\N	\N	1690	2015	1990-06-06
1783	1	1990-05-18	\N	\N	1691	2016	1990-05-23
1784	1	1990-05-21	2004-04-30	\N	1692	2017	1990-05-23
1785	1	1990-05-22	2017-05-08	\N	1693	2018	1990-06-12
1786	1	1990-05-29	2008-05-04	\N	1694	2019	1990-06-06
1787	1	1990-05-30	2008-07-29	\N	1695	2020	1990-06-05
1788	1	1990-06-01	2018-10-13	\N	1696	2021	1990-06-11
1789	1	1990-06-11	\N	\N	1697	2022	1990-06-19
1790	1	1987-10-20	2015-04-19	\N	1698	1983	1987-11-03
1791	1	1987-11-02	2005-07-14	\N	1699	1984	1987-11-10
1792	1	1990-08-13	2002-11-02	\N	1700	2027	1990-10-17
1793	1	1991-01-17	\N	\N	1701	2030	1991-01-23
1794	1	1990-12-04	2017-02-24	\N	1702	2029	1990-12-04
1795	1	1991-01-25	1995-08-23	\N	1703	2031	1991-01-29
1796	1	1991-02-01	2000-07-11	\N	1704	2032	1991-02-26
1797	1	1991-02-04	\N	\N	1705	2033	1991-02-12
1798	1	1991-02-05	\N	\N	1706	2034	1991-02-20
1799	1	1991-02-08	2010-06-21	\N	1707	2036	1991-02-19
1800	1	1991-02-14	\N	\N	1708	2037	1991-02-26
1801	1	1991-03-26	2021-03-10	\N	1709	2038	1991-03-26
1802	1	1991-06-05	\N	\N	1710	2039	1991-06-18
1803	1	1991-06-06	\N	\N	1711	2040	1991-06-12
1804	1	1991-06-07	\N	\N	1712	2041	1991-06-11
1805	1	1991-06-10	2021-04-17	\N	1713	2042	1991-06-25
1806	1	1991-06-11	2001-02-05	\N	1714	2043	1991-06-11
1807	1	1991-06-14	\N	\N	1715	2044	1991-07-02
1808	1	1991-06-19	\N	\N	1716	2045	1991-06-19
1809	1	1991-06-20	\N	\N	1717	2046	1991-06-25
1810	1	1991-06-21	2021-04-23	\N	1718	2047	1991-07-03
1811	1	1991-06-24	\N	\N	1719	2048	1991-07-09
1812	1	1991-06-26	2001-02-21	\N	1720	2049	1991-06-26
1813	1	1991-07-15	\N	\N	1721	2050	1991-07-17
1814	1	1991-07-16	\N	\N	1722	2051	1991-07-16
1815	1	1991-07-17	1992-07-31	\N	1723	2052	1991-07-24
1816	1	1991-07-29	\N	\N	1724	2053	1991-10-15
1817	1	1991-07-30	\N	\N	1725	2054	1991-10-16
1818	1	1991-10-01	2018-07-25	\N	1726	2055	1991-10-15
1819	1	1992-01-10	2015-04-24	\N	1727	2056	1992-03-11
1820	1	1992-01-27	2016-08-20	\N	1728	2057	1992-02-12
1821	1	1992-01-30	2001-01-18	\N	1729	2058	1992-02-12
1822	1	1992-02-14	\N	\N	1730	2060	1992-07-15
1823	1	1992-03-11	2009-04-07	\N	1731	2061	1992-03-11
1824	1	1992-04-24	\N	\N	1732	2062	1992-04-28
1825	1	1992-04-24	\N	\N	1733	2063	1992-04-28
1826	1	1992-04-27	1997-04-28	\N	1734	2064	1992-04-29
1827	1	1992-04-29	2011-06-26	\N	1735	2065	1992-04-29
1828	1	1992-06-26	2013-04-08	\N	1736	2066	1992-06-30
1829	1	1990-07-16	2002-08-31	\N	1737	2024	1990-07-24
1830	1	1990-07-16	2002-05-03	\N	1738	2025	1990-07-18
1831	1	1990-07-17	2009-01-09	\N	1739	2026	1990-07-17
1832	1	1992-07-01	\N	\N	1740	2072	1992-07-06
1833	1	1992-07-02	1998-04-19	\N	1741	2074	1992-07-09
1834	1	1992-07-03	2019-05-20	\N	1742	2075	1992-07-06
1835	1	1992-07-06	\N	\N	1743	2076	1992-07-09
1836	1	1992-07-07	2003-01-26	\N	1744	2077	1992-07-14
1837	1	1992-07-08	1996-09-03	\N	1745	2078	1992-07-08
1838	1	1992-07-08	2010-06-23	\N	1746	2079	1992-10-21
1839	1	1992-07-09	2012-06-14	\N	1747	2080	1992-07-14
1840	1	1992-07-10	2012-04-20	\N	1748	2081	1992-07-13
1841	1	1992-07-14	\N	\N	1749	2082	1992-10-19
1842	1	1992-07-15	2007-05-06	\N	1750	2083	1992-07-15
1843	1	1992-07-17	2007-06-09	\N	1751	2084	1992-10-26
1844	1	1992-07-18	2004-04-17	\N	1752	2085	1992-10-27
1845	1	1992-07-20	2018-03-03	\N	1753	2086	1992-10-20
1846	1	1992-07-21	2004-10-04	\N	1754	2087	1992-10-28
1847	1	1992-07-24	\N	\N	1755	2088	1992-11-04
1848	1	1992-07-27	\N	\N	1756	2089	1992-10-20
1849	1	1992-07-28	1993-03-04	\N	1757	2090	1992-10-28
1850	1	1992-07-29	\N	\N	1758	2091	1992-10-21
1851	1	1992-07-30	2003-09-20	\N	1759	2092	1992-10-26
1852	1	1992-08-10	2000-01-05	\N	1760	2093	1992-11-02
1853	1	1992-08-11	2007-11-13	\N	1761	2094	1992-11-03
1854	1	1992-08-12	2017-11-21	\N	1762	2095	1992-11-02
1855	1	1992-08-21	2013-09-07	\N	1763	2096	1992-11-03
1856	1	1992-09-18	\N	\N	1764	2098	1992-10-27
1857	1	1993-02-01	2021-04-12	\N	1765	2100	1993-02-17
1858	1	1993-07-14	2013-11-24	\N	1766	2101	1993-07-21
1859	1	1993-07-15	2009-06-17	\N	1767	2102	1993-07-21
1860	1	1993-07-19	1999-03-12	\N	1768	2103	1993-07-20
1861	1	1993-07-30	2014-08-24	\N	1769	2104	1993-10-25
1862	1	1993-10-01	\N	\N	1770	2105	1993-10-12
1863	1	1993-10-04	\N	\N	1771	2106	1993-10-12
1864	1	1993-10-05	2009-04-01	\N	1772	2107	1993-10-13
1865	1	1993-10-06	\N	\N	1773	2108	1993-10-13
1866	1	1993-10-11	\N	\N	1774	2109	1993-10-19
1867	1	1992-06-29	2016-01-22	\N	1775	2068	1992-07-07
1868	1	1992-06-29	2015-10-03	\N	1776	2069	1992-07-01
1869	1	1992-06-30	\N	\N	1777	2070	1992-07-08
1870	1	1994-01-11	2007-01-22	\N	1778	2114	1994-01-18
1871	1	1994-02-10	2020-03-06	\N	1779	2115	1994-02-16
1872	1	1994-03-22	\N	\N	1780	2116	1994-05-04
1873	1	1994-07-12	2017-12-20	\N	1781	2117	1994-07-20
1874	1	1994-07-14	1999-02-23	\N	1782	2118	1994-10-12
1875	1	1994-09-06	2015-03-25	\N	1783	2119	1994-10-26
1876	1	1994-09-26	2002-11-07	\N	1784	2120	1994-10-26
1877	1	1994-09-27	\N	\N	1785	2121	1994-10-19
1878	1	1994-09-29	2018-03-30	\N	1786	2123	1994-10-11
1879	1	1994-09-30	2021-01-08	\N	1787	2124	1994-10-11
1880	1	1994-10-04	\N	\N	1788	2126	1994-10-12
1881	1	1994-10-05	\N	\N	1789	2127	1994-10-18
1882	1	1994-10-06	\N	\N	1790	2128	1994-11-02
1883	1	1994-10-07	2009-07-12	\N	1791	2129	1994-11-02
1884	1	1994-10-10	2009-07-05	\N	1792	2130	1994-10-25
1885	1	1995-01-11	2017-11-28	\N	1793	2131	1995-01-18
1886	1	1995-02-03	\N	\N	1794	2132	1995-02-14
1887	1	1995-02-10	2000-10-25	\N	1795	2133	1995-02-15
1888	1	1995-02-17	\N	\N	1796	2134	1995-02-22
1889	1	1995-02-21	\N	\N	1797	2135	1995-03-01
1890	1	1995-07-24	\N	\N	1798	2137	1995-10-18
1891	1	1995-07-25	2008-10-30	\N	1799	2138	1995-10-18
1892	1	1995-08-25	\N	\N	1800	2139	1995-11-01
1893	1	1995-09-08	2019-03-06	\N	1801	2140	1995-10-25
1894	1	1995-12-13	2018-08-21	\N	1802	2141	1995-12-13
1895	1	1995-12-18	\N	\N	1803	2142	1995-12-20
1896	1	1995-12-19	\N	\N	1804	2143	1995-12-20
1897	1	1995-12-20	\N	\N	1805	2144	1996-01-09
1898	1	1995-12-21	2016-09-30	\N	1806	2145	1996-01-16
1899	1	1996-01-02	\N	\N	1807	2146	1996-01-10
1900	1	1996-01-10	\N	\N	1808	2147	1996-01-10
1901	1	1996-01-11	\N	\N	1809	2148	1996-02-07
1902	1	1997-10-02	\N	\N	1810	2224	1997-10-29
1903	1	1996-01-15	2019-11-19	\N	1811	2150	1996-02-14
1904	1	1996-01-16	\N	\N	1812	2151	1996-02-13
1905	1	1996-01-17	\N	\N	1813	2152	1996-01-31
1906	1	1996-02-05	\N	\N	1814	2153	1996-02-14
1907	1	1993-10-13	2020-08-08	\N	1815	2111	1993-11-03
1908	1	1993-10-14	2014-06-21	\N	1816	2112	1993-10-20
1909	1	1993-10-15	\N	\N	1817	2113	1993-10-27
1910	1	1996-08-19	2006-06-28	\N	1818	2158	1997-06-10
1911	1	1996-09-03	2018-09-08	\N	1819	2159	1996-10-30
1912	1	1996-09-11	2006-12-27	\N	1820	2160	1996-11-06
1913	1	1996-09-30	\N	\N	1821	2161	1996-10-29
1914	1	1996-10-01	2009-03-06	\N	1822	2162	1996-10-16
1915	1	1996-10-01	\N	\N	1823	2163	1996-10-29
1916	1	1996-10-02	\N	\N	1824	2164	1996-10-30
1917	1	1996-10-04	\N	\N	1825	2165	1996-11-20
1918	1	1996-10-07	\N	\N	1826	2166	1996-11-27
1919	1	1996-10-08	\N	\N	1827	2167	1996-11-05
1920	1	1996-10-09	\N	\N	1828	2168	1996-11-12
1921	1	1996-10-11	\N	\N	1829	2169	1996-11-13
1922	1	1996-10-14	\N	\N	1830	2170	1996-11-05
1923	1	1996-10-15	\N	\N	1831	2171	1996-11-19
1924	1	1996-10-16	\N	\N	1832	2172	1996-11-06
1925	1	1996-10-18	\N	\N	1833	2174	1996-11-27
1926	1	1996-10-21	\N	\N	1834	2175	1996-11-19
1927	1	1997-02-14	2017-04-26	\N	1835	2177	1997-02-26
1928	1	1997-02-17	\N	\N	1836	2178	1997-02-19
1929	1	1997-02-18	\N	\N	1837	2179	1997-02-26
1930	1	1997-05-14	\N	\N	1838	2180	1997-05-15
1931	1	1997-05-14	\N	\N	1839	2181	1997-05-15
1932	1	1997-05-16	\N	\N	1840	2182	1997-05-19
1933	1	1997-05-16	2013-06-02	\N	1841	2183	1997-05-21
1934	1	1997-06-03	2007-08-14	\N	1842	2185	1997-06-10
1935	1	1997-05-21	\N	\N	1843	2184	1997-05-21
1936	1	1997-06-04	1998-03-27	\N	1844	2186	1997-06-04
1937	1	1997-06-05	\N	\N	1845	2187	1997-06-17
1938	1	1997-06-05	2001-09-24	\N	1846	2188	1997-06-11
1939	1	1997-06-06	\N	\N	1847	2189	1997-06-18
1940	1	1997-06-06	\N	\N	1848	2190	1997-06-11
1941	1	1997-06-09	2017-02-19	\N	1849	2191	1997-06-17
1942	1	1997-06-09	2020-08-25	\N	1850	2192	1997-06-25
1943	1	1997-06-10	2016-03-05	\N	1851	2193	1997-06-12
1944	1	1997-06-10	2015-03-09	\N	1852	2194	1997-06-24
1945	1	1997-06-11	2007-01-27	\N	1853	2196	1997-07-01
1946	1	1996-02-21	1999-03-20	\N	1854	2155	1996-02-28
1947	1	1996-04-03	2006-08-30	\N	1855	2156	1996-05-08
1948	1	1996-06-04	2010-09-11	\N	1856	2157	1996-06-26
1949	1	1997-07-21	\N	\N	1857	2203	1997-07-22
1950	1	1997-07-21	2008-07-27	\N	1858	2204	1997-07-23
1951	1	1997-07-22	\N	\N	1859	2205	1997-07-22
1952	1	1997-07-28	\N	\N	1860	2206	1997-07-29
1953	1	1997-09-23	\N	\N	1861	2207	1997-10-29
1954	1	1997-09-23	\N	\N	1862	2208	1997-11-04
1955	1	1997-09-24	\N	\N	1863	2209	1997-10-23
1956	1	1997-09-24	2008-10-08	\N	1864	2210	1997-10-14
1957	1	1997-09-25	\N	\N	1865	2211	1997-10-15
1958	1	1997-09-26	\N	\N	1866	2213	1997-10-21
1959	1	1997-09-26	2003-11-11	\N	1867	2214	1997-10-21
1960	1	1997-09-27	2003-12-16	\N	1868	2215	1997-10-15
1961	1	1997-09-27	\N	\N	1869	2216	1997-10-15
1962	1	1997-09-29	\N	\N	1870	2217	1997-10-28
1963	1	1997-09-29	\N	\N	1871	2218	1997-10-28
1964	1	1997-09-30	\N	\N	1872	2219	1997-10-23
1965	1	1997-09-30	\N	\N	1873	2220	1997-10-16
1966	1	1997-10-01	2019-03-04	\N	1874	2221	1997-10-22
1967	1	1997-10-01	2013-12-13	\N	1875	2222	1997-10-22
1968	1	1997-10-02	2017-07-02	\N	1876	2223	1997-10-16
1969	1	1997-10-03	\N	\N	1877	2225	1997-10-21
1970	1	1997-10-03	\N	\N	1878	2226	1997-10-14
1971	1	1997-10-04	2020-03-31	\N	1879	2227	1997-10-28
1972	1	1997-10-04	\N	\N	1880	2228	1997-10-22
1973	1	1997-10-06	\N	\N	1881	2229	1997-11-04
1974	1	1997-10-06	2012-08-12	\N	1882	2230	1997-10-27
1975	1	1997-10-18	2014-06-21	\N	1883	2231	1997-11-11
1976	1	1997-10-20	\N	\N	1884	2232	1997-11-05
1977	1	1997-10-20	\N	\N	1885	2233	1997-10-30
1978	1	1997-10-21	2005-04-28	\N	1886	2234	1997-11-04
1979	1	1997-10-21	2008-05-20	\N	1887	2235	1997-11-03
1980	1	1997-10-22	\N	\N	1888	2236	1997-11-03
1981	1	1997-10-23	2017-01-10	\N	1889	2238	1997-11-12
1982	1	1997-10-23	\N	\N	1890	2239	1997-10-27
1983	1	1997-10-24	2015-05-02	\N	1891	2240	1997-11-10
1984	1	1997-10-24	\N	\N	1892	2241	1997-10-29
1985	1	1997-10-25	2003-12-19	\N	1893	2243	1997-11-12
1986	1	1997-06-13	\N	\N	1894	2199	1997-06-25
1987	1	1997-06-16	\N	\N	1895	2200	1997-06-18
1988	1	1997-06-17	\N	\N	1896	2201	1997-07-02
1989	1	1997-10-29	\N	\N	1897	2248	1997-11-17
1990	1	1997-10-29	\N	\N	1898	2249	1997-11-06
1991	1	1997-10-30	\N	\N	1899	2251	1997-11-06
1992	1	1997-10-31	2001-03-13	\N	1900	2252	1997-11-10
1993	1	1997-11-01	1999-11-05	\N	1901	2254	1997-11-10
1994	1	1997-11-01	\N	\N	1902	2255	1997-11-17
1995	1	1997-11-03	\N	\N	1903	2256	1997-11-18
1996	1	1997-11-04	\N	\N	1904	2258	1997-11-24
1997	1	1997-11-04	2021-04-24	\N	1905	2259	1997-11-19
1998	1	1997-11-05	2018-07-01	\N	1906	2260	1997-11-19
1999	1	1997-11-05	\N	\N	1907	2261	1997-11-17
2000	1	1999-07-29	\N	\N	1908	2339	1999-10-13
2001	1	1997-11-06	2006-08-30	\N	1909	2262	1997-11-18
2002	1	1997-11-06	\N	\N	1910	2263	1997-11-19
2003	1	1997-11-22	\N	\N	1911	2264	1997-11-24
2004	1	1997-11-24	\N	\N	1912	2265	1997-11-24
2005	1	1997-11-28	2016-05-28	\N	1913	2266	1998-01-13
2006	1	1998-02-12	\N	\N	1914	2267	1998-03-31
2007	1	1998-02-23	2001-08-31	\N	1915	2270	1998-03-11
2008	1	1998-07-17	\N	\N	1916	2271	1998-07-20
2009	1	1998-07-17	\N	\N	1917	2272	1998-07-20
2010	1	1998-07-18	\N	\N	1918	2273	1998-07-21
2011	1	1998-07-18	\N	\N	1919	2274	1998-07-21
2012	1	1998-07-20	2012-07-05	\N	1920	2275	1998-07-22
2013	1	1998-07-20	\N	\N	1921	2276	1998-07-29
2014	1	1998-07-21	\N	\N	1922	2277	1998-07-27
2015	1	1998-07-21	\N	\N	1923	2278	1998-07-22
2016	1	1998-07-23	\N	\N	1924	2279	1998-07-28
2017	1	1998-07-23	\N	\N	1925	2280	1998-07-27
2018	1	1998-07-24	\N	\N	1926	2281	1998-10-19
2019	1	1998-07-24	\N	\N	1927	2282	1998-10-05
2020	1	1998-07-25	\N	\N	1928	2283	1998-10-05
2021	1	1998-07-25	\N	\N	1929	2284	1998-10-26
2022	1	1998-07-27	\N	\N	1930	2285	1998-07-29
2023	1	1998-07-27	\N	\N	1931	2286	1998-07-28
2024	1	1998-07-28	\N	\N	1932	2287	1998-10-06
2025	1	1998-07-28	\N	\N	1933	2288	1998-10-20
2026	1	1997-10-27	\N	\N	1934	2245	1997-11-05
2027	1	1997-10-28	\N	\N	1935	2246	1997-11-11
2028	1	1997-10-28	\N	\N	1936	2247	1997-11-03
2029	1	1998-07-31	\N	\N	1937	2293	1998-10-13
2030	1	1998-07-31	2019-08-25	\N	1938	2294	1998-10-14
2031	1	1998-08-01	\N	\N	1939	2295	1998-10-06
2032	1	1998-08-01	\N	\N	1940	2296	1998-10-19
2033	1	1998-08-03	\N	\N	1941	2298	1998-10-13
2034	1	1998-08-04	\N	\N	1942	2299	1998-10-28
2035	1	1998-08-04	\N	\N	1943	2300	1998-10-14
2036	1	1999-02-05	2015-08-30	\N	1944	2306	1999-02-17
2037	1	1999-01-12	\N	\N	1945	2305	1999-01-12
2038	1	1998-10-02	\N	\N	1946	2304	1998-10-08
2039	1	1999-02-10	2017-11-13	\N	1947	2307	1999-02-23
2040	1	1998-10-01	2004-03-15	\N	1948	2302	1998-10-07
2041	1	1998-10-01	2021-05-27	\N	1949	2303	1998-10-07
2042	1	1999-02-25	\N	\N	1950	2308	1999-03-03
2043	1	1999-03-01	\N	\N	1951	2309	1999-03-03
2044	1	1999-03-02	2005-04-25	\N	1952	2310	1999-06-22
2045	1	1999-07-10	\N	\N	1953	2312	1999-07-15
2046	1	1999-07-12	\N	\N	1954	2313	1999-10-26
2047	1	1999-07-13	\N	\N	1955	2314	1999-07-13
2048	1	1999-07-13	\N	\N	1956	2315	1999-07-13
2049	1	1999-07-14	\N	\N	1957	2316	1999-07-15
2050	1	1999-07-14	\N	\N	1958	2317	1999-07-20
2051	1	1999-07-15	\N	\N	1959	2318	1999-07-26
2052	1	1999-07-15	\N	\N	1960	2319	1999-07-27
2053	1	1999-07-16	2018-07-10	\N	1961	2320	1999-07-22
2054	1	1999-07-16	\N	\N	1962	2321	1999-07-22
2055	1	1999-07-19	\N	\N	1963	2323	1999-07-21
2056	1	1999-07-20	\N	\N	1964	2324	1999-07-21
2057	1	1999-07-20	2012-03-29	\N	1965	2325	1999-07-20
2058	1	1999-07-21	\N	\N	1966	2326	1999-07-27
2059	1	1999-07-22	\N	\N	1967	2328	1999-07-26
2060	1	1999-07-22	2013-01-09	\N	1968	2329	1999-07-28
2061	1	1999-07-23	\N	\N	1969	2330	1999-07-28
2062	1	1999-07-23	\N	\N	1970	2331	1999-11-02
2063	1	1999-07-26	\N	\N	1971	2332	1999-10-27
2064	1	1999-07-26	\N	\N	1972	2333	1999-11-01
2065	1	1999-07-27	\N	\N	1973	2334	1999-10-12
2066	1	1998-07-29	\N	\N	1974	2290	1998-10-20
2067	1	1998-07-30	\N	\N	1975	2291	1998-10-21
2068	1	1998-07-30	\N	\N	1976	2292	1998-11-03
2069	1	1999-07-30	\N	\N	1977	2340	1999-10-13
2070	1	1999-07-30	\N	\N	1978	2341	1999-10-11
2071	1	1999-07-31	\N	\N	1979	2342	1999-11-02
2072	1	1999-07-31	\N	\N	1980	2343	1999-10-11
2073	1	1999-08-02	\N	\N	1981	2345	1999-10-20
2074	1	1999-08-03	\N	\N	1982	2346	1999-10-20
2075	1	1999-08-03	\N	\N	1983	2347	1999-10-19
2076	1	1999-08-04	\N	\N	1984	2348	1999-10-18
2077	1	1999-08-04	\N	\N	1985	2349	1999-11-29
2078	1	1999-08-05	\N	\N	1986	2350	1999-11-01
2079	1	1999-08-05	\N	\N	1987	2351	1999-11-03
2080	1	1999-08-06	2015-02-07	\N	1988	2352	1999-11-08
2081	1	1999-08-06	\N	\N	1989	2353	1999-10-25
2082	1	1999-08-24	\N	\N	1990	2354	2000-02-03
2083	1	2000-04-18	\N	\N	1991	2373	2000-04-18
2084	1	2000-04-19	\N	\N	1992	2375	2000-05-02
2085	1	2000-04-19	\N	\N	1993	2376	2000-04-19
2086	1	2000-04-19	\N	\N	1994	2377	2000-04-19
2087	1	2000-06-05	\N	\N	1995	2399	2000-10-17
2088	1	2000-06-07	\N	\N	1996	2400	2000-07-12
2089	1	2000-06-07	\N	\N	1997	2401	2000-06-28
2090	1	2000-06-12	\N	\N	1998	2402	2000-07-12
2091	1	2000-07-17	\N	\N	1999	2403	2000-07-18
2092	1	2000-10-02	\N	\N	2000	2404	2000-10-17
2093	1	2000-10-20	\N	\N	2001	2405	2000-10-24
2094	1	2001-01-15	\N	\N	2002	2406	2001-01-16
2095	1	1999-11-16	2000-12-07	\N	2003	2355	1999-11-17
2096	1	1999-11-16	2000-09-14	\N	2004	2356	\N
2097	1	2000-05-01	\N	\N	2005	2379	2000-05-08
2098	1	1999-11-16	2017-01-13	\N	2006	2357	1999-11-25
2099	1	1999-07-28	\N	\N	2007	2336	1999-10-26
2100	1	1999-07-28	\N	\N	2008	2337	1999-10-18
2101	1	1999-07-29	\N	\N	2009	2338	1999-10-19
2102	1	1999-11-17	2005-12-03	\N	2010	2362	1999-11-23
2103	1	1999-11-17	\N	\N	2011	2363	1999-11-18
2104	1	1999-11-17	2018-07-09	\N	2012	2364	1999-11-17
2105	1	2000-02-09	2015-01-21	\N	2013	2365	2000-02-29
2106	1	2000-02-10	\N	\N	2014	2366	2000-02-15
2107	1	2000-02-11	\N	\N	2015	2367	2000-03-07
2108	1	2000-02-14	2019-05-29	\N	2016	2368	2000-02-16
2109	1	2000-02-15	\N	\N	2017	2369	2000-03-07
2110	1	2000-02-16	2017-06-18	\N	2018	2370	2000-02-22
2111	1	2000-04-17	2010-10-10	\N	2019	2371	2000-04-17
2112	1	2000-05-09	2018-04-20	\N	2020	2387	2000-05-15
2113	1	2000-05-09	\N	\N	2021	2388	2000-05-22
2114	1	2000-05-10	\N	\N	2022	2389	2000-05-24
2115	1	2000-05-10	\N	\N	2023	2390	2000-05-23
2116	1	2000-05-11	\N	\N	2024	2391	2000-05-15
2117	1	2000-05-11	2016-07-06	\N	2025	2392	2000-05-17
2118	1	2000-05-12	2020-10-30	\N	2026	2393	2000-05-16
2119	1	2000-05-12	2016-01-29	\N	2027	2394	2000-05-17
2120	1	2000-05-15	\N	\N	2028	2395	2000-05-23
2121	1	2000-05-15	2010-04-12	\N	2029	2396	2000-05-22
2122	1	2000-05-16	2011-02-01	\N	2030	2397	2000-05-24
2123	1	2000-05-16	\N	\N	2031	2398	2000-06-05
2124	1	2000-05-01	\N	\N	2032	2378	2000-05-10
2125	1	2000-05-02	\N	\N	2033	2380	2000-05-09
2126	1	2000-05-02	\N	\N	2034	2381	2000-05-03
2127	1	2000-05-03	\N	\N	2035	2382	2000-05-03
2128	1	2000-05-03	\N	\N	2036	2383	2000-05-10
2129	1	2000-05-04	2021-03-23	\N	2037	2384	2000-05-08
2130	1	2000-05-04	\N	\N	2038	2385	2000-05-09
2131	1	2000-05-05	\N	\N	2039	2386	2000-05-16
2132	1	2001-06-02	2006-01-21	\N	2040	2407	2001-07-02
2133	1	2001-06-04	\N	\N	2041	2408	2001-06-26
2134	1	1999-11-16	2010-12-21	\N	2042	2360	1999-11-22
2135	1	2001-06-22	2020-02-03	\N	2043	2414	2001-06-27
2136	1	2001-06-23	2015-09-04	\N	2044	2416	2001-07-09
2137	1	2001-06-25	\N	\N	2045	2417	2001-07-24
2138	1	2001-06-26	\N	\N	2046	2418	2001-07-10
2139	1	2001-06-27	\N	\N	2047	2419	2001-07-23
2140	1	2001-06-27	\N	\N	2048	2420	2001-07-17
2141	1	2001-06-28	\N	\N	2049	2421	2001-07-10
2142	1	2001-06-28	\N	\N	2050	2422	2001-07-18
2143	1	2001-06-29	2018-01-29	\N	2051	2424	2001-07-18
2144	1	2001-06-30	\N	\N	2052	2425	2001-10-24
2145	1	2001-07-02	\N	\N	2053	2426	2001-07-03
2146	1	2001-07-02	\N	\N	2054	2427	2001-07-02
2147	1	2001-07-03	\N	\N	2055	2429	2001-07-04
2148	1	2001-07-04	\N	\N	2056	2430	2001-07-11
2149	1	2001-07-04	\N	\N	2057	2431	2001-07-19
2150	1	2001-07-05	\N	\N	2058	2432	2001-07-23
2151	1	2001-07-05	2012-02-19	\N	2059	2433	2001-07-17
2152	1	2001-07-06	\N	\N	2060	2434	2001-07-19
2153	1	2001-07-09	\N	\N	2061	2435	2001-10-17
2154	1	2001-07-10	2018-12-22	\N	2062	2436	2001-07-24
2155	1	2001-07-11	\N	\N	2063	2437	2001-10-15
2156	1	2001-07-12	\N	\N	2064	2438	2001-10-23
2157	1	2001-07-14	2008-05-06	\N	2065	2440	2001-10-31
2158	1	2001-07-16	\N	\N	2066	2441	2001-10-23
2159	1	2001-07-17	\N	\N	2067	2442	2001-10-17
2160	1	2001-07-18	2020-04-28	\N	2068	2443	2001-10-15
2161	1	2001-07-19	2020-01-18	\N	2069	2444	2001-10-16
2162	1	2001-07-13	\N	\N	2070	2439	2001-10-22
2163	1	2001-07-20	\N	\N	2071	2445	2001-10-24
2164	1	2001-08-28	2010-09-15	\N	2072	2447	2001-10-16
2165	1	2001-10-30	\N	\N	2073	2448	2001-10-31
2166	1	2002-10-01	\N	\N	2074	2449	2002-10-08
2167	1	2002-11-01	\N	\N	2075	2450	2002-11-19
2168	1	2002-11-18	\N	\N	2076	2451	2003-01-15
2169	1	2003-06-16	\N	\N	2077	2452	2003-06-30
2170	1	2003-06-17	\N	\N	2078	2453	2003-06-24
2171	1	2004-01-09	\N	\N	2079	2454	2004-01-12
2172	1	2001-06-18	\N	\N	2080	2411	2001-06-26
2173	1	2001-06-19	\N	\N	2081	2412	2001-06-27
2174	1	2001-06-20	\N	\N	2082	2413	2001-06-21
2175	1	2004-06-01	\N	\N	2083	2459	2004-06-08
2176	1	2004-06-02	\N	\N	2084	2461	2004-06-21
2177	1	2004-06-03	2019-03-01	\N	2085	2462	2004-06-09
2178	1	2004-06-03	2007-08-09	\N	2086	2463	2004-06-08
2179	1	2004-06-04	\N	\N	2087	2464	2004-06-16
2180	1	2004-06-04	2017-08-03	\N	2088	2465	2004-06-16
2181	1	2004-06-07	\N	\N	2089	2466	2004-07-05
2182	1	2004-06-07	2011-11-06	\N	2090	2467	2004-07-19
2183	1	2004-06-08	\N	\N	2091	2468	2004-06-15
2184	1	2004-06-09	\N	\N	2092	2470	2004-06-29
2185	1	2004-06-09	\N	\N	2093	2471	2004-06-22
2186	1	2004-06-10	\N	\N	2094	2472	2004-06-23
2187	1	2004-06-10	2017-01-25	\N	2095	2473	2004-06-23
2188	1	2004-06-11	\N	\N	2096	2474	2004-07-07
2189	1	2004-06-11	\N	\N	2097	2475	2004-07-05
2190	1	2004-06-14	\N	\N	2098	2477	2004-06-28
2191	1	2004-06-15	\N	\N	2099	2478	2004-07-12
2192	1	2004-06-15	\N	\N	2100	2479	2004-06-30
2193	1	2004-06-16	\N	\N	2101	2480	2004-06-29
2194	1	2004-06-16	\N	\N	2102	2481	2004-06-30
2195	1	2004-06-17	\N	\N	2103	2482	2004-06-28
2196	1	2004-06-17	\N	\N	2104	2483	2004-07-07
2197	1	2004-06-18	2014-03-13	\N	2105	2484	2004-07-12
2198	1	2004-06-18	\N	\N	2106	2485	2004-07-13
2199	1	2004-06-21	\N	\N	2107	2486	2004-07-14
2200	1	2004-06-21	\N	\N	2108	2487	2004-07-19
2201	1	2004-06-22	\N	\N	2109	2488	2004-07-20
2202	1	2004-06-22	\N	\N	2110	2489	2004-09-08
2203	1	2004-06-23	2009-11-02	\N	2111	2490	2004-09-13
2204	1	2004-06-23	\N	\N	2112	2491	2004-07-21
2205	1	2004-06-24	2009-09-03	\N	2113	2492	2004-09-08
2206	1	2004-06-25	\N	\N	2114	2494	2004-09-07
2207	1	2004-06-25	\N	\N	2115	2495	2004-10-11
2208	1	2004-06-28	\N	\N	2116	2496	2004-07-20
2209	1	2004-06-28	\N	\N	2117	2497	2004-07-14
2210	1	2004-06-29	\N	\N	2118	2498	2004-09-07
2211	1	2004-06-29	2009-04-18	\N	2119	2499	2004-09-14
2212	1	2004-06-30	\N	\N	2120	2501	2004-09-14
2213	1	2004-01-12	\N	\N	2121	2456	2004-01-13
2214	1	2004-06-01	\N	\N	2122	2458	2004-06-09
2215	1	2005-03-31	\N	\N	2123	2506	2005-06-21
2216	1	2005-04-06	\N	\N	2124	2507	2005-05-24
2217	1	2005-05-16	\N	\N	2125	2508	2005-05-23
2218	1	2005-05-17	\N	\N	2126	2509	2005-05-23
2219	1	2005-05-31	\N	\N	2127	2510	2005-07-19
2220	1	2005-06-10	\N	\N	2128	2511	2005-06-14
2221	1	2005-06-13	\N	\N	2129	2512	2005-06-14
2222	1	2005-06-14	\N	\N	2130	2513	2005-06-21
2223	1	2005-06-15	\N	\N	2131	2515	2005-06-22
2224	1	2005-06-15	\N	\N	2132	2516	2005-06-15
2225	1	2005-06-16	\N	\N	2133	2517	2005-06-28
2226	1	2005-06-16	2019-01-06	\N	2134	2518	2005-06-22
2227	1	2005-06-17	\N	\N	2135	2519	2005-06-28
2228	1	2005-06-17	\N	\N	2136	2520	2005-06-27
2229	1	2005-06-20	\N	\N	2137	2521	2005-06-29
2230	1	2005-06-20	2014-02-25	\N	2138	2522	2005-07-05
2231	1	2005-06-21	\N	\N	2139	2524	2005-07-13
2232	1	2005-06-22	\N	\N	2140	2525	2005-07-05
2233	1	2005-06-22	\N	\N	2141	2526	2005-07-18
2234	1	2005-06-23	\N	\N	2142	2527	2005-06-27
2235	1	2005-06-23	2006-01-08	\N	2143	2528	2005-07-04
2236	1	2005-06-24	2019-11-09	\N	2144	2530	2005-07-06
2237	1	2005-06-27	\N	\N	2145	2531	2005-10-11
2238	1	2005-06-27	2010-08-30	\N	2146	2532	2005-07-04
2239	1	2005-06-28	\N	\N	2147	2533	2005-07-19
2240	1	2005-06-28	\N	\N	2148	2534	2005-07-18
2241	1	2005-06-29	\N	\N	2149	2535	2005-07-13
2242	1	2005-06-29	\N	\N	2150	2536	2005-07-20
2243	1	2005-07-19	\N	\N	2151	2537	2005-07-20
2244	1	2005-09-06	\N	\N	2152	2538	2005-10-18
2245	1	2005-09-07	\N	\N	2153	2539	2005-10-12
2246	1	2005-10-03	\N	\N	2154	2540	2005-10-12
2247	1	2005-10-05	\N	\N	2155	2541	2005-10-25
2248	1	2005-10-10	\N	\N	2156	2542	2005-10-25
2249	1	2005-10-11	\N	\N	2157	2543	2005-12-07
2250	1	2005-10-12	\N	\N	2158	2544	2005-12-06
2251	1	2006-03-22	\N	\N	2159	2545	2006-03-28
2252	1	2006-04-28	\N	\N	2160	2546	2006-06-26
2253	1	2004-07-01	\N	\N	2161	2503	2004-09-13
2254	1	2005-01-11	\N	\N	2162	2504	2005-01-19
2255	1	2005-01-28	\N	\N	2163	2505	2005-01-31
2256	1	2006-05-31	\N	\N	2164	2552	2006-06-06
2257	1	2006-06-01	\N	\N	2165	2553	2006-06-15
2258	1	2006-06-01	\N	\N	2166	2554	2006-06-26
2259	1	2006-06-02	\N	\N	2167	2555	2006-06-06
2260	1	2006-06-02	\N	\N	2168	2556	2006-06-22
2261	1	2006-06-05	\N	\N	2169	2557	2006-07-18
2262	1	2006-06-05	\N	\N	2170	2558	2006-07-10
2263	1	2006-06-06	2016-06-12	\N	2171	2559	2006-06-22
2264	1	2006-06-06	\N	\N	2172	2560	2006-06-27
2265	1	2006-06-07	\N	\N	2173	2561	2006-06-27
2266	1	2006-06-08	\N	\N	2174	2563	2006-06-12
2267	1	2006-06-08	\N	\N	2175	2564	2006-07-10
2268	1	2006-06-09	2008-08-14	\N	2176	2565	2006-07-11
2269	1	2006-06-09	\N	\N	2177	2566	2006-07-20
2270	1	2006-06-12	\N	\N	2178	2567	2006-07-18
2271	1	2006-06-12	\N	\N	2179	2568	2006-07-24
2272	1	2006-06-13	\N	\N	2180	2570	2006-07-11
2273	1	2006-06-14	\N	\N	2181	2571	2006-07-03
2274	1	2006-06-14	\N	\N	2182	2572	2006-07-03
2275	1	2006-06-15	\N	\N	2183	2573	2006-07-20
2276	1	2012-06-25	\N	\N	2184	2744	2012-06-26
2277	1	2012-07-03	\N	\N	2185	2745	2012-07-12
2278	1	2012-11-01	\N	\N	2186	2746	2012-11-01
2279	1	2013-01-08	\N	\N	2187	2747	2013-01-15
2280	1	2013-01-21	\N	\N	2188	2748	2013-01-21
2281	1	2013-03-25	\N	\N	2189	2749	2013-03-26
2282	1	2013-03-26	\N	\N	2190	2750	2013-03-26
2283	1	2013-07-12	\N	\N	2191	2751	2013-07-15
2284	1	2013-09-04	\N	\N	2192	2753	2013-10-08
2285	1	2013-09-04	\N	\N	2193	2754	2013-10-08
2286	1	2013-07-19	\N	\N	2194	2752	2013-07-22
2287	1	2013-09-05	\N	\N	2195	2755	2013-10-09
2288	1	2013-09-05	\N	\N	2196	2756	2013-10-10
2289	1	2013-09-06	\N	\N	2197	2757	2013-10-10
2290	1	2013-09-06	\N	\N	2198	2758	2013-10-15
2291	1	2013-09-09	\N	\N	2199	2760	2013-10-15
2292	1	2006-06-15	\N	\N	2200	2574	2006-10-10
2293	1	2006-06-16	\N	\N	2201	2575	2006-07-24
2294	1	2006-05-26	\N	\N	2202	2548	2006-06-15
2295	1	2006-05-30	\N	\N	2203	2549	2006-06-05
2296	1	2006-05-30	\N	\N	2204	2550	2006-06-13
2297	1	2007-01-11	\N	\N	2205	2580	2007-01-15
2298	1	2007-03-23	\N	\N	2206	2581	2007-04-24
2299	1	2007-03-26	\N	\N	2207	2582	2007-05-15
2300	1	2007-03-27	\N	\N	2208	2583	2007-04-26
2301	1	2007-03-28	\N	\N	2209	2584	2007-04-30
2302	1	2007-03-29	\N	\N	2210	2585	2007-04-30
2303	1	2007-07-09	\N	\N	2211	2587	2007-07-09
2304	1	2007-07-09	\N	\N	2212	2588	2007-07-09
2305	1	2007-07-11	\N	\N	2213	2590	2007-07-11
2306	1	2007-07-10	\N	\N	2214	2589	2007-07-10
2307	1	2007-07-12	\N	\N	2215	2591	2007-07-19
2308	1	2007-10-10	\N	\N	2216	2592	2007-10-18
2309	1	2007-10-11	\N	\N	2217	2593	2007-10-15
2310	1	2007-10-15	\N	\N	2218	2594	2007-10-15
2311	1	2007-10-16	\N	\N	2219	2595	2007-10-18
2312	1	2007-10-17	\N	\N	2220	2596	2007-11-13
2313	1	2007-12-11	\N	\N	2221	2598	2007-12-13
2314	1	2008-05-28	\N	\N	2222	2599	2008-06-02
2315	1	2008-05-29	\N	\N	2223	2600	2008-07-14
2316	1	2008-06-02	\N	\N	2224	2601	2008-07-01
2317	1	2008-06-30	\N	\N	2225	2602	2008-07-07
2318	1	2008-10-01	\N	\N	2226	2603	2008-10-06
2319	1	2008-10-13	\N	\N	2227	2604	2008-10-13
2320	1	2008-10-15	\N	\N	2228	2605	2008-10-16
2321	1	2008-10-16	\N	\N	2229	2606	2008-10-21
2322	1	2008-11-03	\N	\N	2230	2607	2008-11-03
2323	1	2008-11-10	\N	\N	2231	2608	2008-12-11
2324	1	2009-02-02	\N	\N	2232	2609	2009-02-02
2325	1	2009-05-29	\N	\N	2233	2611	2009-06-01
2326	1	2009-06-27	\N	\N	2234	2612	2009-06-29
2327	1	2009-06-30	\N	\N	2235	2614	2009-06-30
2328	1	2009-07-20	\N	\N	2236	2615	2009-07-20
2329	1	2009-09-01	2020-11-07	\N	2237	2617	2009-10-27
2330	1	2009-08-25	2018-04-29	\N	2238	2616	2009-10-13
2331	1	2009-09-11	\N	\N	2239	2618	2009-10-27
2332	1	2010-03-19	\N	\N	2240	2619	2010-03-22
2333	1	2010-03-22	\N	\N	2241	2620	2010-03-22
2334	1	2010-03-23	\N	\N	2242	2621	2010-03-29
2335	1	2010-03-24	\N	\N	2243	2622	2010-03-29
2336	1	2006-09-18	\N	\N	2244	2578	2006-10-12
2337	1	2006-12-19	\N	\N	2245	2579	2007-01-23
2338	1	2010-06-17	\N	\N	2246	2627	2010-07-06
2339	1	2010-06-18	\N	\N	2247	2628	2010-07-06
2340	1	2010-06-18	\N	\N	2248	2629	2010-07-07
2341	1	2010-06-18	\N	\N	2249	2630	2010-07-06
2342	1	2010-06-18	2014-09-12	\N	2250	2631	2010-07-05
2343	1	2010-06-19	\N	\N	2251	2632	2010-06-21
2344	1	2010-06-20	\N	\N	2252	2633	2010-07-05
2345	1	2010-06-20	\N	\N	2253	2634	2010-07-14
2346	1	2010-06-21	\N	\N	2254	2635	2010-06-21
2347	1	2010-06-22	\N	\N	2255	2637	2010-06-22
2348	1	2010-06-22	\N	\N	2256	2638	2010-06-22
2349	1	2010-06-23	\N	\N	2257	2639	2010-06-23
2350	1	2010-06-23	\N	\N	2258	2640	2010-06-24
2351	1	2010-06-24	2012-06-09	\N	2259	2641	2010-06-24
2352	1	2010-06-24	\N	\N	2260	2642	2010-06-29
2353	1	2010-06-25	\N	\N	2261	2643	2010-06-29
2354	1	2010-06-25	2012-04-24	\N	2262	2644	2010-06-29
2355	1	2010-06-26	\N	\N	2263	2645	2010-06-28
2356	1	2010-06-26	\N	\N	2264	2646	2010-07-01
2357	1	2010-06-27	\N	\N	2265	2647	2010-07-01
2358	1	2010-06-28	\N	\N	2266	2649	2010-06-28
2359	1	2010-06-28	\N	\N	2267	2650	2010-06-30
2360	1	2010-07-07	\N	\N	2268	2651	2010-07-08
2361	1	2010-07-07	\N	\N	2269	2652	2010-07-08
2362	1	2010-07-07	\N	\N	2270	2653	2010-07-08
2363	1	2010-07-07	\N	\N	2271	2654	2010-07-13
2364	1	2010-07-08	2019-05-29	\N	2272	2655	2010-07-12
2365	1	2010-07-08	\N	\N	2273	2656	2010-07-19
2366	1	2010-07-09	\N	\N	2274	2657	2010-07-13
2367	1	2010-07-09	\N	\N	2275	2658	2010-07-13
2368	1	2010-07-10	\N	\N	2276	2660	2010-07-12
2369	1	2010-07-12	\N	\N	2277	2661	2010-07-19
2370	1	2014-11-28	\N	\N	2278	2806	2014-12-08
2371	1	2014-12-02	\N	\N	2279	2807	2015-01-12
2372	1	2014-12-03	\N	\N	2280	2808	2014-12-09
2373	1	2014-12-11	\N	\N	2281	2809	2015-01-22
2374	1	2015-03-17	\N	\N	2282	2811	2015-03-19
2375	1	2015-05-19	\N	\N	2283	2812	2015-06-01
2376	1	2015-05-26	\N	\N	2284	2813	2015-05-28
2377	1	2010-05-28	\N	\N	2285	2624	2010-06-03
2378	1	2010-05-29	\N	\N	2286	2625	2010-06-03
2379	1	2010-06-17	\N	\N	2287	2626	2010-07-05
2380	1	2015-06-08	\N	\N	2288	2818	2015-06-09
2381	1	2015-09-28	\N	\N	2289	2819	2015-10-13
2382	1	2015-09-28	\N	\N	2290	2820	2015-10-13
2383	1	2015-09-29	\N	\N	2291	2822	2015-10-12
2384	1	2015-09-30	\N	\N	2292	2823	2015-10-15
2385	1	2010-07-12	\N	\N	2293	2662	2010-07-20
2386	1	2010-07-13	\N	\N	2294	2663	2010-07-15
2387	1	2010-07-13	\N	\N	2295	2664	2010-07-20
2388	1	2010-07-14	\N	\N	2296	2665	2010-07-15
2389	1	2010-07-14	\N	\N	2297	2666	2010-07-15
2390	1	2010-07-15	\N	\N	2298	2667	2010-07-19
2391	1	2010-07-15	\N	\N	2299	2668	2010-07-26
2392	1	2010-07-16	\N	\N	2300	2670	2010-07-22
2393	1	2010-07-19	\N	\N	2301	2671	2010-07-20
2394	1	2010-07-19	\N	\N	2302	2672	2010-07-21
2395	1	2010-07-20	\N	\N	2303	2673	2010-07-26
2396	1	2010-07-20	\N	\N	2304	2674	2010-07-27
2397	1	2010-07-21	\N	\N	2305	2675	2010-07-28
2398	1	2010-07-21	\N	\N	2306	2676	2010-07-22
2399	1	2010-07-22	\N	\N	2307	2677	2010-07-26
2400	1	2010-07-22	\N	\N	2308	2678	2010-07-27
2401	1	2010-07-23	2017-04-23	\N	2309	2679	2010-10-18
2402	1	2010-07-26	\N	\N	2310	2680	2010-10-11
2403	1	2010-11-08	\N	\N	2311	2681	2011-11-25
2404	1	2010-11-16	\N	\N	2312	2683	2010-11-22
2405	1	2010-11-22	\N	\N	2313	2684	2010-11-22
2406	1	2010-12-17	\N	\N	2314	2685	2010-12-20
2407	1	2010-12-17	\N	\N	2315	2686	2010-12-20
2408	1	2010-12-18	\N	\N	2316	2687	2010-12-20
2409	1	2010-12-18	\N	\N	2317	2688	2010-12-21
2410	1	2010-12-20	\N	\N	2318	2689	2010-12-21
2411	1	2010-12-21	\N	\N	2319	2691	2010-12-22
2412	1	2010-12-21	\N	\N	2320	2692	2010-12-22
2413	1	2010-12-22	\N	\N	2321	2693	2011-01-10
2414	1	2010-12-22	\N	\N	2322	2694	2011-01-10
2415	1	2010-12-23	\N	\N	2323	2695	2011-01-11
2416	1	2010-12-23	\N	\N	2324	2696	2011-01-10
2417	1	2010-12-24	\N	\N	2325	2697	2011-01-11
2418	1	2015-05-28	\N	\N	2326	2815	2015-06-01
2419	1	2015-05-28	\N	\N	2327	2816	2015-06-02
2420	1	2015-05-29	\N	\N	2328	2817	2015-06-02
2421	1	2011-01-11	\N	\N	2329	2702	2011-01-13
2422	1	2011-01-12	\N	\N	2330	2704	2011-01-17
2423	1	2011-01-13	\N	\N	2331	2705	2011-01-17
2424	1	2011-01-13	\N	\N	2332	2706	2011-01-17
2425	1	2011-01-14	\N	\N	2333	2707	2011-01-18
2426	1	2011-01-14	\N	\N	2334	2708	2011-01-18
2427	1	2011-01-17	\N	\N	2335	2712	2011-01-20
2428	1	2011-01-18	\N	\N	2336	2713	2011-01-20
2429	1	2011-01-18	\N	\N	2337	2714	2011-01-20
2430	1	2011-01-19	\N	\N	2338	2715	2011-01-24
2431	1	2011-01-19	\N	\N	2339	2716	2011-01-24
2432	1	2011-01-20	\N	\N	2340	2717	2011-01-24
2433	1	2011-01-20	\N	\N	2341	2718	2011-01-25
2434	1	2011-01-21	\N	\N	2342	2719	2011-01-25
2435	1	2011-01-21	2017-01-18	\N	2343	2720	2011-01-25
2436	1	2011-01-24	\N	\N	2344	2721	2011-01-26
2437	1	2011-01-24	\N	\N	2345	2722	2011-01-26
2438	1	2011-01-25	\N	\N	2346	2723	2011-01-27
2439	1	2011-01-25	\N	\N	2347	2724	2011-01-27
2440	1	2011-01-26	\N	\N	2348	2725	2011-01-27
2441	1	2011-01-26	\N	\N	2349	2726	2011-01-31
2442	1	2011-01-27	\N	\N	2350	2727	2011-01-31
2443	1	2011-01-27	2015-10-27	\N	2351	2728	2011-01-31
2444	1	2011-01-28	\N	\N	2352	2729	2011-02-01
2445	1	2011-01-28	\N	\N	2353	2730	2011-02-01
2446	1	2011-01-31	\N	\N	2354	2732	2011-02-02
2447	1	2011-02-01	\N	\N	2355	2733	2011-03-22
2448	1	2011-02-01	\N	\N	2356	2734	2011-02-03
2449	1	2011-02-02	\N	\N	2357	2735	2011-02-03
2450	1	2011-02-02	\N	\N	2358	2736	2011-02-07
2451	1	2011-02-04	\N	\N	2359	2737	2011-03-08
2452	1	2011-02-04	\N	\N	2360	2738	2011-02-10
2453	1	2011-02-28	\N	\N	2361	2739	2011-03-10
2454	1	2011-10-12	\N	\N	2362	2741	2011-10-24
2455	1	2011-10-13	\N	\N	2363	2742	2011-10-24
2456	1	2015-10-06	\N	\N	2364	2832	2015-10-29
2457	1	2015-10-06	\N	\N	2365	2833	2015-10-27
2458	1	2011-01-10	\N	\N	2366	2699	2011-01-12
2459	1	2011-01-10	\N	\N	2367	2700	2011-01-12
2460	1	2011-01-11	\N	\N	2368	2701	2011-01-13
2461	1	2015-10-09	\N	\N	2369	2838	2015-11-26
2462	1	2015-10-09	\N	\N	2370	2839	2015-11-10
2463	1	2015-10-12	\N	\N	2371	2840	2015-11-09
2464	1	2015-10-12	\N	\N	2372	2841	2015-11-10
2465	1	2015-10-13	\N	\N	2373	2842	2015-11-09
2466	1	2015-10-13	\N	\N	2374	2843	2015-11-05
2467	1	2015-10-14	\N	\N	2375	2844	2015-11-17
2468	1	2015-10-14	\N	\N	2376	2845	2015-11-30
2469	1	2015-10-15	\N	\N	2377	2846	2015-11-19
2470	1	2015-10-16	\N	\N	2378	2848	2015-11-30
2471	1	2015-09-30	\N	\N	2379	2824	2015-10-15
2472	1	2015-10-01	\N	\N	2380	2825	2015-10-20
2473	1	2015-10-01	\N	\N	2381	2826	2015-10-22
2474	1	2015-10-01	\N	\N	2382	2827	2015-10-22
2475	1	2015-10-02	\N	\N	2383	2828	2015-10-20
2476	1	2015-10-05	\N	\N	2384	2830	2015-10-26
2477	1	2015-10-05	\N	\N	2385	2831	2015-10-27
2478	1	2015-10-16	\N	\N	2386	2849	2015-11-23
2479	1	2015-10-19	\N	\N	2387	2850	2015-11-19
2480	1	2015-10-19	\N	\N	2388	2851	2015-11-23
2481	1	2015-10-20	\N	\N	2389	2852	2015-11-24
2482	1	2015-10-20	\N	\N	2390	2853	2015-11-26
2483	1	2015-10-21	\N	\N	2391	2854	2015-12-03
2484	1	2015-10-21	\N	\N	2392	2855	2015-12-01
2485	1	2015-10-22	\N	\N	2393	2856	2015-11-24
2486	1	2015-10-22	\N	\N	2394	2857	2015-12-08
2487	1	2014-09-05	\N	\N	2395	2785	2014-10-15
2488	1	2014-09-11	\N	\N	2396	2786	2014-10-22
2489	1	2014-09-11	\N	\N	2397	2787	2014-10-13
2490	1	2014-09-12	\N	\N	2398	2788	2014-10-21
2491	1	2014-09-15	\N	\N	2399	2791	2014-10-20
2492	1	2014-09-16	\N	\N	2400	2793	2014-10-16
2493	1	2014-09-17	\N	\N	2401	2794	2014-10-30
2494	1	2014-09-17	\N	\N	2402	2795	2014-10-21
2495	1	2014-09-18	\N	\N	2403	2796	2014-11-24
2496	1	2014-09-18	\N	\N	2404	2797	2014-10-16
2497	1	2014-09-19	\N	\N	2405	2798	2014-10-20
2498	1	2014-09-19	\N	\N	2406	2799	2014-10-23
2499	1	2015-10-07	\N	\N	2407	2835	2015-11-05
2500	1	2015-10-08	\N	\N	2408	2836	2015-11-03
2501	1	2015-10-08	\N	\N	2409	2837	2015-11-03
2502	1	2015-10-23	\N	\N	2410	2859	2015-12-03
2503	1	2015-10-26	\N	\N	2411	2860	2015-12-07
2504	1	2015-10-26	\N	\N	2412	2861	2015-12-08
2505	1	2015-10-29	\N	\N	2413	2863	2016-01-19
2506	1	2015-10-30	\N	\N	2414	2864	2015-12-07
2507	1	2015-10-30	\N	\N	2415	2865	2015-12-17
2508	1	2015-11-02	\N	\N	2416	2866	2015-12-14
2509	1	2015-12-01	\N	\N	2417	2867	2015-12-10
2510	1	2016-02-29	\N	\N	2418	2868	2016-03-21
2511	1	2016-08-30	\N	\N	2419	2869	2016-10-11
2512	1	2016-08-30	\N	\N	2420	2870	2016-09-12
2513	1	2016-08-31	2021-02-08	\N	2421	2871	2016-10-20
2514	1	2016-08-31	\N	\N	2422	2872	2016-09-12
2515	1	2016-09-01	\N	\N	2423	2873	2016-09-17
2516	1	2016-09-01	\N	\N	2424	2874	2016-10-13
2517	1	2013-09-10	\N	\N	2425	2761	2013-10-29
2518	1	2013-09-10	\N	\N	2426	2762	2013-10-16
2519	1	2013-09-11	\N	\N	2427	2763	2013-10-24
2520	1	2013-09-11	\N	\N	2428	2764	2013-10-17
2521	1	2013-09-12	\N	\N	2429	2765	2013-10-28
2522	1	2013-09-12	\N	\N	2430	2766	2013-10-28
2523	1	2013-09-13	\N	\N	2431	2767	2013-10-22
2524	1	2013-09-13	\N	\N	2432	2768	2013-10-30
2525	1	2013-09-16	\N	\N	2433	2769	2013-10-22
2526	1	2013-09-16	\N	\N	2434	2770	2013-10-17
2527	1	2013-09-17	\N	\N	2435	2771	2013-10-21
2528	1	2013-09-17	\N	\N	2436	2772	2013-10-21
2529	1	2013-09-18	\N	\N	2437	2774	2013-10-29
2530	1	2013-09-19	\N	\N	2438	2775	2013-10-31
2531	1	2018-06-21	\N	\N	2439	2901	2018-07-02
2532	1	2013-09-20	\N	\N	2440	2778	2013-11-05
2533	1	2013-10-02	\N	\N	2441	2779	2013-11-06
2534	1	2013-10-02	\N	\N	2442	2780	2013-10-31
2535	1	2013-10-03	\N	\N	2443	2781	2013-11-07
2536	1	2013-10-03	\N	\N	2444	2782	2013-11-11
2537	1	2014-09-23	\N	\N	2445	2803	2014-10-27
2538	1	2014-09-24	\N	\N	2446	2804	2014-11-06
2539	1	2014-09-22	\N	\N	2447	2801	2014-11-06
2540	1	2014-09-23	\N	\N	2448	2802	2014-10-28
2541	1	2015-10-23	\N	\N	2449	2858	2015-12-01
2542	1	2016-09-05	\N	\N	2450	2878	2016-09-13
2543	1	2016-09-06	\N	\N	2451	2880	2016-10-11
2544	1	2016-09-06	\N	\N	2452	2879	2016-09-13
2545	1	2016-10-17	\N	\N	2453	2882	2016-10-31
2546	1	2016-10-20	\N	\N	2454	2883	2016-10-31
2547	1	2017-06-22	\N	\N	2455	2884	2017-06-26
2548	1	2017-07-14	\N	\N	2456	2885	2017-07-20
2549	1	2017-10-19	\N	\N	2457	2886	2017-10-24
2550	1	2017-10-19	\N	\N	2458	2887	2017-10-23
2551	1	2017-10-30	\N	\N	2459	2888	2017-11-20
2552	1	2014-02-24	\N	\N	2460	2784	2014-02-25
2553	1	2017-11-03	\N	\N	2461	2889	2017-11-16
2554	1	2017-11-07	\N	\N	2462	2890	2017-11-21
2555	1	2017-11-07	\N	\N	2463	2891	2017-11-16
2556	1	2018-06-12	\N	\N	2464	2893	2018-06-21
2557	1	2018-06-18	\N	\N	2465	2894	2018-06-25
2558	1	2018-06-18	\N	\N	2466	2895	2018-06-26
2559	1	2018-06-19	\N	\N	2467	2897	2018-07-09
2560	1	2018-06-20	\N	\N	2468	2898	2018-06-25
2561	1	2018-06-20	\N	\N	2469	2899	2018-07-02
2562	1	2018-06-21	\N	\N	2470	2900	2018-07-09
2563	1	2018-06-22	\N	\N	2471	2902	2018-07-03
2564	1	2018-07-11	\N	\N	2472	2907	2018-07-17
2565	1	2018-10-26	2018-11-04	\N	2473	2909	\N
2566	1	2018-11-26	\N	\N	2474	2910	2018-12-04
2567	1	2019-10-07	\N	\N	2475	2914	2019-10-17
2568	1	2019-02-01	\N	\N	2476	2911	2019-02-04
2569	1	2019-10-08	\N	\N	2477	2915	2019-10-22
2570	1	2019-10-08	\N	\N	2478	2916	2019-10-22
2571	1	2019-10-09	\N	\N	2479	2917	2019-11-05
2572	1	2019-10-09	\N	\N	2480	2918	2019-10-15
2573	1	2019-10-10	\N	\N	2481	2919	2019-10-17
2574	1	2019-10-10	\N	\N	2482	2920	2019-10-21
2575	1	2019-10-11	\N	\N	2483	2921	2019-10-29
2576	1	2019-10-11	\N	\N	2484	2922	2020-01-23
2577	1	2019-10-14	\N	\N	2485	2923	2019-11-04
2578	1	2019-10-14	\N	\N	2486	2924	2019-10-21
2579	1	2016-09-02	\N	\N	2487	2875	2016-10-20
2580	1	2016-09-02	\N	\N	2488	2876	2016-10-18
2581	1	2019-03-10	\N	\N	2489	2912	\N
2582	1	2016-09-05	\N	\N	2490	2877	2016-09-17
2583	1	2019-10-30	\N	\N	2491	2930	\N
2584	1	2019-11-11	\N	\N	2492	2931	2020-01-16
2585	1	2020-01-06	\N	\N	2493	2932	2020-01-13
2586	1	2020-01-11	\N	\N	2494	2934	2020-01-16
2587	1	2020-04-08	\N	\N	2495	2935	2020-04-21
2588	1	2020-04-16	\N	\N	2496	2936	2020-04-21
2589	1	2020-09-01	\N	\N	2497	2938	2020-09-08
2590	1	2020-09-01	\N	\N	2498	2939	2020-09-10
2591	1	2020-08-12	\N	\N	2499	2937	2020-09-08
2592	1	2020-09-02	\N	\N	2500	2940	2020-09-10
2593	1	2020-09-02	\N	\N	2501	2941	2020-09-14
2594	1	2020-09-03	\N	\N	2502	2942	2020-09-14
2595	1	2020-09-03	\N	\N	2503	2943	2020-09-15
2596	1	2020-09-04	\N	\N	2504	2944	2020-09-15
2597	1	2020-09-04	\N	\N	2505	2945	2020-09-17
2598	1	2020-09-07	\N	\N	2506	2946	2020-09-17
2599	1	2020-09-07	\N	\N	2507	2947	2020-09-28
2600	1	2020-09-08	\N	\N	2508	2949	2020-09-29
2601	1	2020-09-09	\N	\N	2509	2950	2020-09-29
2602	1	2020-09-09	\N	\N	2510	2951	2020-10-05
2603	1	2020-09-10	\N	\N	2511	2952	2020-10-05
2604	1	2020-09-10	\N	\N	2512	2953	2020-10-06
2605	1	2020-09-11	\N	\N	2513	2954	2020-10-06
2606	1	2020-09-11	\N	\N	2514	2955	\N
2607	1	2020-09-14	\N	\N	2515	2956	2020-10-08
2608	1	2020-09-14	\N	\N	2516	2957	2020-10-13
2609	1	2020-09-15	\N	\N	2517	2958	2020-10-08
2610	1	2018-06-22	\N	\N	2518	2903	2018-07-05
2611	1	2018-06-25	\N	\N	2519	2904	2018-07-10
2612	1	2018-07-09	\N	\N	2520	2905	2018-07-12
2613	1	2018-07-10	\N	\N	2521	2906	2018-07-12
2614	1	2020-09-15	\N	\N	2522	2959	2020-10-12
2615	1	2020-09-16	\N	\N	2523	2960	2020-10-12
2616	1	2020-09-16	\N	\N	2524	2961	2020-10-15
2617	1	2020-09-17	\N	\N	2525	2962	2020-10-13
2618	1	2020-09-18	\N	\N	2526	2964	2020-10-29
2619	1	2020-09-18	\N	\N	2527	2965	2020-10-19
2620	1	2020-09-30	\N	\N	2528	2967	2020-10-26
2621	1	2019-10-16	\N	\N	2529	2927	2019-10-28
2622	1	2019-10-16	\N	\N	2530	2928	2019-11-05
2623	1	2019-10-28	\N	\N	2531	2929	2019-10-29
2624	1	2020-11-06	\N	\N	2532	2972	2021-03-08
2625	1	2020-11-19	\N	\N	2533	2974	2020-12-17
2626	1	2020-11-06	\N	\N	2534	2973	2020-11-09
2627	1	2020-12-23	\N	\N	2535	2975	2021-03-01
2628	1	2020-12-30	\N	\N	2536	2976	2021-01-07
2629	1	2021-01-25	\N	\N	2537	2977	2021-02-01
2630	1	2021-01-25	\N	\N	2538	2978	2021-02-01
2631	1	2021-01-26	\N	\N	2539	2979	2021-02-02
2632	1	2021-01-26	\N	\N	2540	2980	2021-02-08
2633	1	2021-01-27	\N	\N	2541	2981	2021-02-11
2634	1	2021-01-27	\N	\N	2542	2982	2021-02-02
2635	1	2021-01-28	\N	\N	2543	2983	2021-02-11
2636	1	2021-01-28	\N	\N	2544	2984	2021-04-15
2637	1	2021-01-29	\N	\N	2545	2985	2021-02-09
2638	1	2021-01-29	\N	\N	2546	2986	2021-02-09
2639	1	2021-02-01	\N	\N	2547	2987	2021-03-25
2640	1	2021-02-01	\N	\N	2548	2988	2021-03-01
2641	1	2021-02-03	\N	\N	2549	2989	\N
2642	1	2021-02-04	\N	\N	2550	2990	2021-03-02
2643	1	2021-03-26	\N	\N	2551	2991	2021-04-15
2644	1	2021-04-27	\N	\N	2552	2993	2021-05-25
2645	1	2021-07-05	\N	\N	2553	2994	2021-07-06
2646	1	2021-07-16	\N	\N	2554	2995	2021-07-20
2647	1	2020-10-30	\N	\N	2555	2969	\N
2648	1	1858-01-15	1863-11-10	\N	2556	308	1858-02-04
2649	1	2020-10-12	\N	\N	2557	2968	2020-10-29
2650	1	1845-01-25	1846-09-12	\N	2558	272	\N
2651	1	1848-05-12	1869-06-16	\N	2559	280	1848-05-15
2652	1	1857-10-01	1879-08-07	\N	2560	307	1858-02-18
2653	1	1860-03-22	1868-05-07	\N	136	324	1868-06-26
2654	1	1868-07-06	1904-06-04	\N	2561	358	1868-07-14
2655	1	1869-12-13	1882-03-09	\N	2562	372	1870-02-08
2656	1	1874-02-28	1898-01-30	\N	2563	401	1874-03-10
2657	1	1884-06-17	1888-06-05	\N	2564	462	1884-06-24
2658	1	2020-11-05	\N	\N	2565	2971	2020-11-19
2659	1	1889-12-05	1901-09-08	\N	503	519	1889-12-06
2660	1	1837-08-12	1842-06-30	\N	2566	232	1837-11-20
2661	1	1876-01-15	1899-05-13	\N	2567	416	1876-02-10
2662	1	1892-02-20	1914-11-14	\N	508	529	1893-06-19
2663	1	1896-01-24	1896-01-25	\N	2568	574	\N
2664	1	1896-06-09	1902-03-06	\N	2569	577	1896-06-26
2665	1	1897-08-23	1914-01-21	\N	2570	588	1898-02-15
2666	1	1906-01-12	1908-03-04	\N	2571	658	1906-02-14
2667	1	1909-02-20	1937-06-28	\N	2572	683	1909-02-23
2668	1	1911-06-20	1912-10-02	\N	2573	704	1911-07-20
2669	1	1911-07-05	1923-12-12	\N	2574	719	1911-08-01
2670	1	1914-07-27	1916-06-05	\N	492	749	1914-07-29
2671	1	1916-06-30	1925-06-17	\N	2575	771	1916-07-20
2672	1	1917-06-21	1923-08-30	\N	489	787	1917-06-27
2673	1	1917-06-23	1938-01-23	\N	2576	792	1917-07-18
2674	1	1919-09-27	1936-03-11	\N	2577	835	1919-11-05
2675	1	1920-01-28	1934-12-05	\N	2578	851	1920-02-11
2676	1	1922-01-25	1922-03-13	\N	2579	879	1922-02-22
2677	1	1925-06-16	1927-01-17	\N	713	917	1925-06-17
2678	1	1922-11-27	1925-05-07	\N	654	892	1922-12-06
2679	1	1926-02-17	1942-08-21	\N	523	923	1926-03-03
2680	1	1929-06-24	1932-07-16	\N	722	962	1929-11-27
2681	1	1928-01-12	1935-06-06	\N	689	938	1928-06-13
2682	1	1929-07-10	1955-11-27	\N	2580	968	1929-07-17
2683	1	1932-06-22	1935-04-28	\N	2581	1004	1932-07-06
2684	1	1929-11-18	1946-12-20	\N	2582	974	1929-11-20
2685	1	1933-02-24	1934-12-05	\N	625	1012	1933-03-08
2686	1	1935-06-26	1947-07-21	\N	2583	1036	1935-07-24
2687	1	1936-07-17	1950-08-07	\N	2584	1056	1936-11-11
2688	1	1937-02-22	1953-10-08	\N	2585	1059	1937-03-10
2689	1	1939-07-06	1963-08-17	\N	2586	1097	1939-07-12
2690	1	1919-05-16	1951-01-17	\N	2587	830	1919-05-28
2691	1	1886-02-17	1905-04-29	\N	2588	491	1886-02-23
2692	1	1945-07-02	1951-12-11	\N	868	1155	1945-08-01
2693	1	1946-06-28	1954-12-04	\N	2589	1208	1946-07-10
2694	1	1901-08-06	1917-01-29	\N	439	617	1901-08-08
2695	1	1919-09-30	1927-10-07	\N	525	837	1919-10-29
2696	1	1945-11-12	1957-08-20	\N	2590	1182	1945-11-20
2697	1	1946-01-09	1949-04-24	\N	2591	1189	1946-01-11
2698	1	1947-04-01	1948-05-14	\N	2592	1225	1947-04-02
2699	1	1951-06-26	1953-02-11	\N	2593	1270	1951-07-11
2700	1	1947-04-18	1973-07-18	\N	2594	1226	1947-04-23
2701	1	1949-06-01	1977-04-01	\N	1177	1247	1949-06-01
2702	1	1952-01-07	1958-08-08	\N	2595	1280	\N
2703	1	1954-07-30	1983-06-29	\N	2596	1307	1954-10-27
2704	1	1955-01-10	1965-07-27	\N	2597	1313	1955-03-30
2705	1	1955-09-02	1971-09-25	\N	2598	1323	1955-11-09
2706	1	1957-07-10	1964-12-27	\N	1010	1346	1957-07-24
2707	1	1958-08-08	1988-07-11	\N	2599	1360	1958-10-21
2708	1	1961-02-02	1967-03-29	\N	2600	1403	1961-02-07
2709	1	1960-01-07	1979-06-09	\N	2601	1385	1960-01-27
2710	1	1961-07-11	1973-12-18	\N	2602	1416	1961-07-27
2711	1	1963-11-08	1982-03-07	\N	2603	1447	1963-11-13
2712	1	1964-06-30	1989-06-22	\N	2604	1467	1964-07-01
2713	1	1964-12-16	1992-12-18	\N	2605	1489	1964-12-17
2714	1	1964-12-17	1988-04-28	\N	2606	1491	1964-12-21
2715	1	1966-01-18	1972-02-14	\N	2607	1534	1966-02-09
2716	1	1966-05-31	1994-03-16	\N	2608	1537	1966-06-15
2717	1	1967-01-19	1970-02-17	\N	2609	1557	1967-02-01
2718	1	1967-11-29	1999-10-11	\N	2610	1580	1967-12-13
2719	1	1969-03-03	1997-11-23	\N	2611	1600	1969-03-12
2720	1	1970-09-21	1982-01-24	\N	2612	1623	1970-10-28
2721	1	1971-02-05	2006-05-07	\N	2613	1632	1971-03-03
2722	1	1973-07-09	1987-02-16	\N	2614	1666	1973-07-25
2723	1	1974-01-31	2000-11-08	\N	2615	1668	1974-03-27
2724	1	1974-05-07	1989-04-06	\N	2616	1677	1974-06-19
2725	1	1974-07-05	2010-06-08	\N	2617	1699	1974-07-16
2726	1	1944-01-28	1950-11-06	\N	2618	1141	1944-02-16
2727	1	1942-03-09	1993-01-14	\N	2619	1128	1942-03-18
2728	1	1976-09-29	2017-07-20	\N	2620	1767	1976-10-06
2729	1	1978-05-11	2009-09-01	\N	2621	1799	1978-07-12
2730	1	1978-07-13	1998-07-01	\N	2622	1803	1978-07-26
2731	1	1979-02-09	2003-07-17	\N	2623	1811	1979-03-06
2732	1	1979-07-26	2012-02-21	\N	2624	1831	1979-10-31
2733	1	1980-07-10	2003-03-10	\N	2625	1847	1980-07-30
2734	1	1981-06-02	2013-06-30	\N	2626	1867	1981-06-24
2735	1	1983-02-07	2010-06-19	\N	2627	1892	1983-02-23
2736	1	1983-02-11	2010-01-22	\N	2628	1895	1983-03-23
2737	1	1984-02-01	2000-01-13	\N	2629	1924	1984-02-02
2738	1	1985-05-16	2011-05-20	\N	2630	1936	1985-05-22
2739	1	1987-10-15	2018-03-17	\N	2631	1980	1987-11-04
2740	1	1987-06-22	1992-04-01	\N	2632	1969	1987-06-22
2741	1	1987-10-19	2012-03-02	\N	2633	1982	1987-11-04
2742	1	1990-02-27	2010-03-24	\N	2634	2008	1990-03-06
2743	1	1990-06-18	\N	\N	2635	2023	1990-06-19
2744	1	1992-06-27	1996-10-07	\N	2636	2067	1992-07-13
2745	1	1992-07-01	2006-01-05	\N	2637	2073	1992-07-07
2746	1	1993-10-12	2018-03-13	\N	2638	2110	1993-10-19
2747	1	1994-09-28	2003-04-10	\N	2639	2122	1994-10-18
2748	1	1996-01-12	2011-02-14	\N	2640	2149	1996-02-07
2749	1	1996-02-16	2015-09-16	\N	2641	2154	1996-02-28
2750	1	1996-10-17	\N	\N	2642	2173	1996-12-03
2751	1	1997-06-12	\N	\N	2643	2197	1997-07-08
2752	1	1997-06-12	2016-06-25	\N	2644	2198	1997-06-25
2753	1	1997-09-25	2012-08-11	\N	2645	2212	1997-10-14
2754	1	1997-10-22	2020-03-24	\N	2646	2237	1997-10-27
2755	1	1997-10-27	\N	\N	2647	2244	1997-11-05
2756	1	1997-10-30	2020-06-26	\N	2648	2250	1997-11-12
2757	1	1998-02-13	2009-02-19	\N	2649	2268	1998-03-17
2758	1	1998-07-29	\N	\N	2650	2289	1998-10-12
2759	1	1998-08-03	\N	\N	2651	2297	1998-10-12
2760	1	1999-07-27	\N	\N	2652	2335	1999-10-12
2761	1	1999-08-02	\N	\N	2653	2344	1999-10-27
2762	1	1976-06-25	2016-01-20	\N	2654	1757	1976-06-30
2763	1	1976-06-28	1980-02-10	\N	2655	1758	1976-06-29
2764	1	2001-06-16	\N	\N	2656	2410	2001-06-21
2765	1	2001-07-03	\N	\N	2657	2428	2001-07-04
2766	1	2004-01-12	\N	\N	2658	2455	2004-01-12
2767	1	2004-06-08	\N	\N	2659	2469	2004-06-22
2768	1	2004-06-24	\N	\N	2660	2493	2004-07-13
2769	1	2004-07-01	\N	\N	2661	2502	2004-09-15
2770	1	2005-06-24	\N	\N	2662	2529	2005-07-06
2771	1	2006-05-26	\N	\N	2663	2547	2006-06-12
2772	1	2006-05-31	\N	\N	2664	2551	2006-06-05
2773	1	2012-01-10	\N	\N	2665	2743	2012-01-12
2774	1	2013-09-09	\N	\N	2666	2759	2013-10-14
2775	1	2006-06-16	\N	\N	2667	2576	2006-10-10
2776	1	2007-03-30	\N	\N	2668	2586	2007-04-24
2777	1	2009-04-21	\N	\N	2669	2610	2009-04-28
2778	1	2010-05-27	\N	\N	2670	2623	2010-05-27
2779	1	2010-06-21	\N	\N	2671	2636	2010-06-28
2780	1	2010-07-10	\N	\N	2672	2659	2010-07-12
2781	1	2015-05-26	\N	\N	2673	2814	2015-05-28
2782	1	2010-07-16	\N	\N	2674	2669	2010-07-22
2783	1	2010-12-20	\N	\N	2675	2690	2010-12-21
2784	1	2010-12-24	\N	\N	2676	2698	2011-01-11
2785	1	2011-01-12	\N	\N	2677	2703	2011-01-13
2786	1	2011-01-31	\N	\N	2678	2731	2011-02-01
2787	1	2015-10-07	\N	\N	2679	2834	2015-10-29
2788	1	2015-10-15	\N	\N	2680	2847	2015-11-17
2789	1	2014-09-12	\N	\N	2681	2789	2014-10-28
2790	1	2014-09-22	\N	\N	2682	2800	2014-10-27
2791	1	2015-10-27	2018-05-12	\N	2683	2862	2015-12-10
2792	1	2013-09-18	\N	\N	2684	2773	2013-10-24
2793	1	2013-10-04	\N	\N	2685	2783	2013-11-25
2794	1	2014-09-24	\N	\N	2686	2805	2014-11-10
2795	1	2016-10-04	\N	\N	2687	2881	2016-10-24
2796	1	2019-10-07	\N	\N	2688	2913	2019-10-15
2797	1	2019-10-15	\N	\N	2689	2925	2019-10-28
2798	1	2019-10-15	\N	\N	2690	2926	2019-11-04
2799	1	2020-09-08	\N	\N	2691	2948	2020-09-28
2800	1	2020-09-17	\N	\N	2692	2963	2020-12-10
2801	1	2001-06-05	\N	\N	2693	2409	2001-07-09
2802	1	1881-11-24	1887-12-05	\N	2694	454	\N
2803	1	2021-04-26	\N	\N	2695	2992	2021-05-17
2804	1	1801-01-19	1806-03-22	\N	2696	2	1801-02-24
2805	1	1806-02-21	1819-12-14	\N	2697	43	1806-02-25
2806	1	1809-02-03	1816-05-29	\N	2698	60	1817-04-25
2807	1	1815-08-11	1838-03-21	\N	2699	85	1816-05-24
2808	1	1815-08-11	1828-07-22	\N	2700	91	1816-02-01
2809	1	1815-08-11	1829-05-19	\N	2701	92	1816-02-01
2810	1	1821-07-17	1828-08-16	\N	2702	123	1822-02-06
2811	1	1824-01-30	1826-09-04	\N	2703	135	1824-02-03
2812	1	1826-07-15	1845-07-01	\N	2704	146	1826-12-05
2813	1	1831-09-10	1836-11-11	\N	2705	180	1831-09-26
2814	1	1831-09-10	1857-10-10	\N	213	189	1831-09-12
2815	1	1835-01-10	1843-05-11	\N	2706	212	1835-02-20
2816	1	1839-04-20	1853-01-29	\N	2707	245	1843-07-03
2817	1	1850-01-22	1902-02-12	\N	340	285	1850-01-31
2818	1	1860-09-01	1878-01-07	\N	141	325	1878-01-25
2819	1	1869-04-03	1879-06-27	\N	2708	364	1869-04-15
2820	1	1924-06-23	1941-08-12	\N	819	912	1924-07-09
2821	1	1891-01-21	1927-10-07	\N	525	523	1891-01-22
2822	1	1892-02-22	1901-11-15	\N	2709	530	1892-03-03
2823	1	1893-06-24	1907-03-23	\N	2710	553	1893-06-27
2824	1	1898-01-19	1906-01-30	\N	2711	592	1898-02-17
2825	1	1902-07-12	1903-07-01	\N	436	620	1902-07-25
2826	1	1906-02-20	1939-02-28	\N	2712	662	1906-04-05
2827	1	1910-07-20	1941-08-12	\N	819	698	1910-07-20
2828	1	1911-06-22	1917-06-04	\N	2713	706	1911-07-24
2829	1	1919-10-28	1921-02-28	\N	2714	845	1919-11-05
2830	1	1933-01-17	1937-08-13	\N	2715	1007	1933-02-15
2831	1	1934-01-13	1963-08-22	\N	882	1020	1934-04-25
2832	1	1941-01-20	1954-06-15	\N	787	1110	1941-01-29
2833	1	2020-11-02	\N	\N	2716	2970	2020-11-17
2834	1	2001-06-29	\N	\N	2717	2423	2001-07-11
2835	1	1957-02-04	1969-08-27	\N	2718	1339	1957-03-27
2836	1	1954-10-04	1960-11-18	\N	2719	1310	1954-10-20
2837	1	1966-06-01	1991-04-11	\N	2720	1538	1966-06-22
2838	1	1959-11-12	1961-02-03	\N	2721	1381	1959-11-18
2839	1	1967-12-05	1969-05-10	\N	2722	1582	1967-12-06
2840	1	1974-09-02	1993-09-08	\N	2723	1705	1974-11-19
2841	1	1978-02-07	1999-12-23	\N	2724	1781	1978-02-22
2842	1	1979-07-18	1999-01-15	\N	2725	1827	1979-07-19
2843	1	1980-07-22	1995-12-05	\N	2726	1850	1980-07-23
2844	1	1984-02-02	2014-01-17	\N	2727	1925	1984-02-08
2845	1	1987-03-30	2002-04-30	\N	2728	1963	1987-04-29
2846	1	1990-05-08	\N	\N	2729	2010	1990-05-08
2847	1	1991-02-07	2014-11-27	\N	2730	2035	1991-02-19
2848	1	1992-06-30	2015-10-09	\N	2731	2071	1992-07-01
2849	1	1992-10-01	\N	\N	2732	2099	1992-11-11
2850	1	1995-02-28	\N	\N	2733	2136	1995-03-28
2851	1	1997-10-25	2015-12-19	\N	2734	2242	1997-10-30
2852	1	1997-10-31	2012-03-25	\N	2735	2253	1997-11-11
2853	1	1999-07-21	\N	\N	2736	2327	1999-10-25
2854	1	2000-04-18	\N	\N	2737	2374	2000-05-02
2855	1	2001-06-22	2018-05-01	\N	2738	2415	2001-07-03
2856	1	2004-06-14	\N	\N	2739	2476	2004-06-21
2857	1	2005-06-14	2020-08-26	\N	2740	2514	2005-06-15
2858	1	2007-12-10	\N	\N	2741	2597	2007-12-17
2859	1	2010-06-27	\N	\N	2742	2648	2010-07-01
2860	1	2010-11-15	\N	\N	2743	2682	2010-11-15
2861	1	2011-01-15	\N	\N	2744	2709	2011-01-18
2862	1	2015-10-02	\N	\N	2745	2829	2015-10-26
2863	1	2017-11-20	\N	\N	2746	2892	2017-12-12
2864	1	2020-09-30	\N	\N	2747	2966	2020-10-15
2865	1	1948-02-26	1954-10-31	\N	2748	1239	1948-03-10
2866	1	1802-04-01	1803-05-07	\N	2749	26	1829-02-05
2867	1	1821-07-14	1825-08-22	\N	2750	110	1822-06-03
2868	1	1841-06-30	1861-06-23	\N	2751	261	1841-08-23
2869	1	1866-08-31	1872-10-27	\N	2752	351	1867-02-05
2870	1	1869-12-07	1905-02-21	\N	2753	367	1870-02-08
2871	1	1876-10-16	1896-01-08	\N	2754	423	1876-11-21
2872	1	1891-06-23	1921-11-29	\N	2755	525	1891-07-27
2873	1	1900-06-26	1914-01-21	\N	2570	612	1926-11-24
2874	1	1902-07-22	1916-08-17	\N	2756	629	1902-07-24
2875	1	1911-06-26	1932-05-23	\N	739	709	1911-07-19
2876	1	1915-05-15	1934-03-07	\N	2757	753	1918-07-02
2877	1	1918-01-14	1922-08-14	\N	536	799	1918-02-26
2878	1	1960-05-16	1976-06-17	\N	2758	1392	1960-05-18
2879	1	1859-04-16	1875-04-16	\N	2759	316	1859-06-03
2880	1	1885-12-30	1893-01-18	\N	2760	486	1886-01-26
2881	1	1940-10-21	1971-06-16	\N	2761	1108	1940-11-06
2882	1	1975-01-08	1998-05-17	\N	2762	1713	1975-02-26
2883	1	1975-02-03	1994-12-18	\N	2763	1731	1975-02-10
2884	1	1990-08-24	\N	\N	2764	2028	1990-10-09
2885	1	2000-04-17	\N	\N	2765	2372	2000-04-18
2886	1	1925-06-29	1935-11-20	\N	658	918	1926-02-17
2887	1	1927-01-31	1934-05-24	\N	610	932	1927-02-09
2888	1	1926-02-20	1941-11-01	\N	618	924	1926-06-30
2889	1	1934-06-26	1949-04-20	\N	2766	1023	1934-07-11
2890	1	1946-08-23	1979-08-27	\N	1009	1212	1946-10-23
2891	1	1950-01-27	1965-01-11	\N	1182	1251	1950-03-01
2892	1	1957-08-22	1977-05-25	\N	2767	1347	1957-10-30
2893	1	1945-09-15	1963-06-12	\N	974	1176	1945-11-21
2894	1	1839-05-10	1874-01-23	\N	2768	248	1839-05-31
2895	1	1902-07-11	1916-06-05	\N	492	619	1911-04-26
2896	1	1801-04-27	1823-03-13	\N	2769	7	1823-06-04
2897	1	1963-11-27	1972-06-06	\N	2770	1451	1964-01-15
2898	1	1964-12-21	1969-02-19	\N	2771	1497	1964-12-23
2899	1	1966-06-13	1984-11-18	\N	2772	1544	1966-06-29
2900	1	1968-01-19	2001-04-03	\N	2773	1585	1968-02-21
2901	1	1970-10-14	1993-03-24	\N	2774	1628	1970-10-29
2902	1	1974-12-19	1995-10-09	\N	2775	1708	1975-01-22
2903	1	1975-01-10	2000-09-15	\N	2776	1715	1975-01-29
2904	1	1975-01-09	2005-04-26	\N	2777	1714	1975-01-21
2905	1	1978-05-16	2017-11-13	\N	2778	1800	1978-07-05
2906	1	1980-02-21	1990-01-07	\N	2779	1845	1980-02-27
2907	1	1917-07-16	1927-10-24	\N	2780	793	1917-10-31
2908	1	1980-09-01	1992-05-23	\N	2781	1851	1980-10-22
2909	1	1987-10-05	1997-01-28	\N	2782	1972	1987-10-20
2910	1	1987-10-16	1996-10-04	\N	2783	1981	1987-11-10
2911	1	1992-02-12	\N	\N	2784	2059	1992-02-25
2912	1	1997-11-03	\N	\N	2785	2257	1997-11-18
2913	1	2004-06-30	\N	\N	2786	2500	2004-07-21
2914	1	2006-06-13	\N	\N	2787	2569	2006-07-25
2915	1	2009-06-29	2020-12-01	\N	2788	2613	2009-06-29
2916	1	2014-12-16	\N	\N	2789	2810	2015-01-13
2917	1	2011-01-17	\N	\N	2790	2711	2011-01-19
2918	1	2014-09-15	\N	\N	2791	2790	2014-10-29
2919	1	2013-09-19	\N	\N	2792	2776	2013-11-04
2920	1	2018-06-19	\N	\N	2793	2896	2018-06-26
2921	1	1999-07-19	\N	\N	2794	2322	1999-11-03
2922	1	1938-01-27	1958-08-15	\N	2795	1084	1938-02-09
2923	1	1945-09-17	1971-04-22	\N	975	1177	1945-11-21
2924	1	1919-10-09	1920-02-20	\N	2796	843	1919-10-29
2925	1	1929-08-31	1948-09-10	\N	899	972	1929-11-06
2926	1	1936-01-17	1936-10-22	\N	753	1047	1937-11-17
2927	1	1941-07-04	1957-07-03	\N	1089	1117	1941-07-09
2928	1	1953-02-13	1967-06-18	\N	2797	1292	1953-03-04
2929	1	1964-06-29	1996-11-09	\N	2798	1466	1964-07-15
2930	1	1965-05-17	1977-12-12	\N	2799	1523	1965-06-15
2931	1	1967-02-06	1991-06-27	\N	2800	1559	1967-02-15
2932	1	1969-10-28	1988-09-17	\N	2801	1605	1969-11-19
2933	1	1971-02-09	1990-02-08	\N	2802	1633	1971-03-10
2934	1	1981-06-19	\N	\N	2803	1869	1981-06-23
2935	1	1992-08-25	2007-09-21	\N	2804	2097	1992-11-04
2936	1	1994-10-03	2019-09-25	\N	2805	2125	1994-10-19
2937	1	1997-06-11	2012-11-01	\N	2806	2195	1997-06-12
2938	1	1997-07-18	2000-12-04	\N	2807	2202	1997-07-23
2939	1	1998-02-14	2005-03-05	\N	2808	2269	1998-04-28
2940	1	1998-08-05	\N	\N	2809	2301	1998-10-26
2941	1	1999-11-17	2007-02-22	\N	2810	2361	1999-11-23
2942	1	2001-07-30	\N	\N	2811	2446	2001-10-22
2943	1	2004-06-02	\N	\N	2812	2460	2004-06-15
2944	1	2004-01-13	\N	\N	2813	2457	2004-01-13
2945	1	2005-06-21	\N	\N	2814	2523	2005-06-29
2946	1	2006-06-07	\N	\N	2815	2562	2006-06-13
2947	1	2006-06-30	\N	\N	2816	2577	2006-07-25
2948	1	2015-09-29	\N	\N	2817	2821	2015-10-12
2949	1	2011-01-15	\N	\N	2818	2710	2011-01-19
2950	1	2014-09-16	\N	\N	2819	2792	2014-10-23
2951	1	2013-09-20	\N	\N	2820	2777	2013-11-05
2952	1	2020-01-07	\N	\N	2821	2933	2020-01-13
2953	1	1964-12-19	2000-09-14	\N	2004	1495	1965-02-10
2954	1	1999-11-16	2001-04-05	\N	2822	2359	1999-11-18
2955	1	1962-01-29	2000-12-07	\N	2003	1423	1962-02-21
2956	1	1999-11-16	2001-08-03	\N	966	2358	1999-11-17
2957	1	1997-01-06	2020-07-14	\N	2823	2176	1997-01-14
2958	1	1803-10-26	1808-07-14	\N	2824	33	\N
2959	1	1861-10-21	1888-11-25	\N	2825	330	1889-04-01
2960	1	1881-05-24	1884-03-28	\N	2826	447	1881-06-20
2961	1	1892-04-07	1900-04-24	\N	2827	532	1892-06-13
2962	1	1822-02-04	1839-01-17	\N	2828	130	1822-02-07
2963	1	2011-05-26	\N	\N	2829	2740	\N
2964	1	1833-01-29	1842-01-29	\N	155	204	1833-02-04
2965	1	1874-05-24	1942-01-16	\N	2830	408	1874-06-08
2966	1	1899-10-16	1912-01-29	\N	450	604	1959-11-11
2967	1	1934-10-12	1942-08-25	\N	2831	1028	1934-11-07
2968	1	2018-07-16	\N	\N	2832	2908	\N
2969	1	1814-05-11	1852-09-14	\N	49	71	1814-06-28
2970	1	1937-03-08	1972-05-28	\N	604	1062	\N
2971	1	1920-06-03	1952-02-06	\N	2833	855	1920-06-23
2972	1	1892-08-23	1910-12-24	\N	2834	540	1893-01-31
2973	1	1922-05-05	1930-03-19	\N	2835	882	1922-05-30
2974	1	1876-08-21	1881-04-19	\N	2836	421	1877-02-08
2975	1	1937-06-02	1956-03-10	\N	2837	1066	1937-06-30
2976	1	1831-09-10	1834-05-04	\N	2838	177	1831-09-13
2977	1	1831-09-12	1859-12-22	\N	2839	193	1831-09-13
2978	1	1850-06-11	1851-04-29	\N	178	288	1851-07-11
2979	1	1895-07-17	1945-06-20	\N	602	563	1895-08-15
2980	1	1844-10-22	1871-12-22	\N	2840	271	1845-02-04
2981	1	1885-07-13	1912-01-29	\N	450	480	1885-07-27
2982	1	1945-01-08	1955-05-02	\N	857	1151	1945-01-24
2983	1	1944-07-11	1959-12-23	\N	752	1147	1944-07-12
2984	1	1929-06-20	1932-05-23	\N	739	959	1929-06-26
2985	1	1880-05-03	1898-11-19	\N	2841	437	1880-05-27
2986	1	1905-12-22	1907-03-23	\N	2710	644	1906-02-13
2987	1	1911-07-03	1929-05-21	\N	2842	714	1929-11-06
2988	1	1874-04-02	1878-03-19	\N	2843	407	1874-04-30
2989	1	1917-12-20	1935-12-30	\N	611	798	1918-01-09
2990	1	1833-04-13	1859-01-28	\N	121	206	1833-04-16
2991	1	1961-10-06	2017-01-13	\N	2006	1419	1962-02-28
2992	1	1984-02-24	1986-12-29	\N	2844	1926	1984-02-29
2993	1	1955-05-05	1972-07-27	\N	855	1318	1955-06-21
2994	1	1999-06-19	\N	\N	2489	2311	\N
2995	1	1815-11-22	1827-04-10	\N	2845	94	1816-03-20
2996	1	1801-11-27	1850-07-08	\N	30	2996	1801-12-15
2997	1	1812-09-07	1840-10-08	\N	50	2997	1812-11-28
2998	1	1815-11-22	1827-04-10	\N	2845	2998	1816-03-20
2999	1	1817-02-13	1826-11-28	\N	114	2999	1825-06-03
3000	1	1831-09-12	1834-03-29	\N	44	3000	1831-09-15
3001	1	1841-12-08	1910-05-06	\N	233	3001	1863-02-05
3002	1	1866-05-24	1900-07-30	\N	304	3002	1866-06-08
3003	1	1866-05-24	1900-07-30	\N	304	3003	1866-06-08
3004	1	1822-02-04	1839-01-17	\N	2828	3004	1822-02-07
3005	1	1861-10-21	1888-11-25	\N	2825	3005	1889-04-01
3006	1	1805-11-20	1835-02-28	\N	22	3006	1806-01-21
3007	1	1801-06-18	1825-07-30	\N	33	3007	1801-10-30
3008	1	1822-02-04	1839-01-17	\N	2828	3008	1822-02-07
3009	1	1861-10-21	1888-11-25	\N	2825	3009	1889-04-01
3010	1	1801-06-22	1811-03-01	\N	36	3010	1801-06-29
3011	1	1801-06-26	1814-09-23	\N	38	3011	1801-06-29
3012	1	1801-11-27	1843-04-21	\N	31	3012	1805-01-15
3013	1	1801-11-27	1850-07-08	\N	30	3013	1801-12-15
3014	1	1802-12-24	1811-05-29	\N	17	3014	1803-04-20
3015	1	1804-05-14	1839-05-16	\N	35	3015	1804-05-18
3016	1	1804-05-14	1839-05-16	\N	35	3016	1804-05-18
3017	1	1804-05-14	1839-05-16	\N	35	3017	1804-05-18
3018	1	1806-02-17	1818-07-31	\N	25	3018	1806-02-28
3019	1	1806-04-11	1807-11-14	\N	6	3019	1806-04-28
3020	1	1807-11-09	1843-06-16	\N	47	3020	1808-02-01
3021	1	1809-09-04	1852-09-14	\N	49	3021	1814-06-28
3022	1	1812-09-07	1820-04-03	\N	68	3022	1813-02-05
3023	1	1812-09-07	1828-05-24	\N	76	3023	1812-11-28
3024	1	1812-09-07	1828-05-24	\N	76	3024	1812-11-28
3025	1	1813-02-24	1814-06-21	\N	71	3025	1816-03-22
3026	1	1814-05-11	1852-09-14	\N	49	3026	1814-06-28
3027	1	1815-11-24	1845-11-17	\N	74	3027	1816-02-01
3028	1	1815-11-25	1825-05-12	\N	51	3028	1818-01-27
3029	1	1815-11-27	1853-09-15	\N	77	3029	1816-02-01
3030	1	1815-11-30	1825-09-07	\N	106	3030	1816-02-02
3031	1	1815-12-01	1816-10-21	\N	40	3031	1816-05-06
3032	1	1817-02-13	1826-11-28	\N	114	3032	1825-06-03
3033	1	1821-07-07	1838-01-13	\N	107	3033	1821-07-09
3034	1	1821-07-17	1856-01-04	\N	112	3034	1822-02-05
3035	1	1821-07-17	1856-01-04	\N	112	3035	1822-02-05
3036	1	1821-07-18	1827-08-27	\N	111	3036	1822-02-05
3037	1	1823-07-08	1854-03-06	\N	99	3037	1823-07-16
3038	1	1826-06-30	1859-02-15	\N	113	3038	1826-11-28
3039	1	1826-12-19	1857-03-13	\N	119	3039	1829-02-05
3040	1	1827-10-05	1833-03-06	\N	153	3040	1828-01-29
3041	1	1827-10-06	1860-11-07	\N	125	3041	1828-01-29
3042	1	1831-06-04	1842-03-20	\N	154	3042	1831-06-15
3043	1	1831-06-04	1842-03-20	\N	154	3043	1831-06-15
3044	1	1833-01-29	1842-01-29	\N	155	3044	1833-02-04
3045	1	1833-03-23	1840-07-28	\N	132	3045	1833-06-03
3046	1	1833-05-10	1846-01-08	\N	165	3046	1833-05-18
3047	1	1835-03-10	1845-07-21	\N	172	3047	1835-04-03
3048	1	1837-01-28	1840-06-22	\N	190	3048	1837-01-31
3049	1	1837-01-30	1846-09-05	\N	230	3049	1837-01-31
3050	1	1837-08-12	1842-06-30	\N	2566	3050	1837-11-20
3051	1	1838-06-30	1893-12-29	\N	193	3051	1838-07-03
3052	1	1841-08-16	1866-06-10	\N	229	3052	1841-08-24
3053	1	1844-10-22	1871-12-22	\N	2840	3053	1845-02-04
3054	1	1846-07-06	1857-02-18	\N	228	3054	1847-02-01
3055	1	1847-09-18	1860-06-03	\N	176	3055	1847-11-23
3056	1	1850-06-11	1851-04-29	\N	178	3056	1851-07-11
3057	1	1857-04-11	1884-07-15	\N	248	3057	1857-06-05
3058	1	1860-02-17	1885-05-07	\N	267	3058	1860-03-01
3059	1	1868-07-25	1915-01-13	\N	341	3059	1868-12-15
3060	1	1801-11-27	1843-04-21	\N	31	3060	1805-01-15
3061	1	1876-01-14	1915-12-12	\N	342	3061	1876-02-10
3062	1	1881-05-24	1884-03-28	\N	2826	3062	1881-06-20
3063	1	1885-07-11	1922-10-19	\N	319	3063	1885-07-14
3064	1	1888-11-17	1902-02-12	\N	340	3064	1889-02-21
3065	1	1890-05-24	1892-01-14	\N	449	3065	1890-06-23
3066	1	1892-05-24	1936-01-20	\N	451	3066	1892-06-17
3067	1	1892-08-22	1929-03-11	\N	454	3067	1893-01-31
3068	1	1901-11-09	1936-01-20	\N	451	3068	\N
3069	1	1874-04-02	1878-03-19	\N	2843	3069	1874-04-30
3070	1	1911-07-03	1945-06-20	\N	602	3070	1911-08-09
3071	1	1915-05-15	1934-03-07	\N	2757	3071	1918-07-02
3072	1	1917-07-16	1927-10-24	\N	2780	3072	1917-10-31
3073	1	1917-07-17	1921-09-11	\N	707	3073	1917-07-25
3074	1	1917-07-18	1960-02-23	\N	673	3074	1918-03-06
3075	1	1920-06-03	1952-02-06	\N	2833	3075	1920-06-23
3076	1	1921-06-28	1925-03-20	\N	593	3076	1921-07-07
3077	1	1928-03-31	1974-06-10	\N	782	3077	1928-04-24
3078	1	1889-07-29	1912-01-29	\N	450	3078	1890-02-13
3079	1	1901-02-11	1914-11-14	\N	508	3079	1901-02-14
3080	1	1914-07-27	1916-06-05	\N	492	3080	1914-07-29
3081	1	1914-07-27	1916-06-05	\N	492	3081	1914-07-29
3082	1	1922-05-05	1930-03-19	\N	2835	3082	1922-05-30
3083	1	1899-10-16	1912-01-29	\N	450	3083	1959-11-11
3084	1	1876-06-10	1904-11-15	\N	379	3084	1876-06-15
3085	1	1876-08-21	1881-04-19	\N	2836	3085	1877-02-08
3086	1	1878-09-27	1885-04-02	\N	287	3086	1878-12-06
3087	1	1880-05-04	1894-09-10	\N	359	3087	1880-05-27
3088	1	1881-05-24	1884-03-28	\N	2826	3088	1881-06-20
3089	1	1882-12-30	1895-05-04	\N	318	3089	1883-02-15
3090	1	1885-07-03	1887-01-12	\N	416	3090	1885-07-06
3091	1	1887-07-01	1900-04-19	\N	453	3091	1887-07-12
3092	1	1892-05-24	1936-01-20	\N	451	3092	1892-06-17
3093	1	1892-08-22	1906-10-30	\N	452	3093	1893-01-31
3094	1	1897-07-22	1909-03-16	\N	483	3094	1898-05-12
3095	1	1900-12-19	1904-11-28	\N	507	3095	1901-02-14
3096	1	1901-08-06	1917-01-29	\N	439	3096	1901-08-08
3097	1	1905-12-18	1923-03-06	\N	526	3097	1906-02-13
3098	1	1905-12-22	1907-03-23	\N	2710	3098	1906-02-13
3099	1	1911-07-03	1929-05-21	\N	2842	3099	1929-11-06
3100	1	1911-07-03	1929-05-21	\N	2842	3100	1929-11-06
3101	1	1911-07-05	1918-02-23	\N	411	3101	1911-08-01
3102	1	1911-07-06	1926-01-15	\N	592	3102	1911-07-25
3103	1	1915-02-22	1916-04-30	\N	541	3103	1915-03-02
3104	1	1917-01-03	1922-02-24	\N	645	3104	1917-02-07
3105	1	1917-07-16	1927-10-24	\N	2780	3105	1917-10-31
3106	1	1917-07-16	1957-01-16	\N	705	3106	1918-07-17
3107	1	1917-07-17	1921-09-11	\N	707	3107	1917-07-25
3108	1	1917-12-20	1935-12-30	\N	611	3108	1918-01-09
3109	1	1919-09-27	1936-03-11	\N	2577	3109	1919-11-05
3110	1	1919-09-27	1936-03-11	\N	2577	3110	1919-11-05
3111	1	1919-09-29	1928-01-29	\N	721	3111	1919-11-12
3112	1	1919-09-29	1928-01-29	\N	721	3112	1919-11-12
3113	1	1920-02-02	1942-02-13	\N	706	3113	1920-02-11
3114	1	1920-06-03	1952-02-06	\N	2833	3114	1920-06-23
3115	1	1922-11-28	1930-09-30	\N	678	3115	1922-11-30
3116	1	1925-02-09	1928-02-15	\N	783	3116	1925-02-17
3117	1	1925-06-29	1935-11-20	\N	658	3117	1926-02-17
3118	1	1928-03-31	1974-06-10	\N	782	3118	1928-04-24
3119	1	1929-06-20	1932-05-23	\N	739	3119	1929-06-26
3120	1	1801-06-19	1814-05-17	\N	34	3120	1801-10-29
3121	1	1809-07-19	1847-12-26	\N	69	3121	1810-01-23
3122	1	1874-05-24	1942-01-16	\N	2830	3122	1874-06-08
3123	1	1911-11-02	1925-03-20	\N	593	3123	1912-02-21
3124	1	1947-10-18	1979-08-27	\N	1009	3124	1948-07-21
3125	1	1861-10-21	1888-11-25	\N	2825	3125	1889-04-01
3126	1	1812-09-07	1831-04-07	\N	72	3126	1812-11-24
3127	1	1821-07-17	1841-01-05	\N	82	3127	1822-02-05
3128	1	1839-12-21	1849-01-01	\N	227	3128	1843-02-02
3129	1	1861-07-30	1878-05-28	\N	265	3129	1861-07-30
3130	1	1898-01-19	1921-12-11	\N	387	3130	1898-02-08
3131	1	1917-07-18	1960-02-23	\N	673	3131	1918-03-06
3132	1	1929-07-10	1937-09-28	\N	793	3132	1929-07-24
3133	1	1911-11-02	1925-03-20	\N	593	3133	1912-02-21
3134	1	1815-11-29	1840-03-14	\N	109	3134	1816-06-06
3135	1	1831-09-10	1834-05-04	\N	2838	3135	1831-09-13
3136	1	1841-08-16	1866-06-10	\N	229	3136	1841-08-24
3137	1	1871-11-13	1902-02-12	\N	340	3137	1872-02-06
3138	1	1880-04-28	1891-11-24	\N	378	3138	1881-01-06
3139	1	1895-07-16	1928-06-13	\N	468	3139	1896-02-11
3140	1	1919-09-30	1927-10-07	\N	525	3140	1919-10-29
3141	1	1931-02-20	1941-08-12	\N	819	3141	1931-02-25
3142	1	1934-10-12	1942-08-25	\N	2831	3142	1934-11-07
3143	1	1937-06-08	1947-12-14	\N	873	3143	1937-06-09
3144	1	1945-01-08	1955-05-02	\N	857	3144	1945-01-24
3145	1	1945-02-12	1945-03-26	\N	943	3145	1945-06-13
3146	1	1947-05-01	1950-05-24	\N	935	3146	1947-06-04
3147	1	1947-11-20	2021-04-09	\N	1040	3147	1948-07-21
3148	1	1951-12-24	1957-08-16	\N	958	3148	1952-01-30
3149	1	1952-03-11	1969-06-16	\N	983	3149	1952-03-12
3150	1	1955-05-05	1972-07-27	\N	855	3150	1955-06-21
3151	1	1955-12-16	1967-10-08	\N	1081	3151	1956-01-25
3152	1	1956-01-09	1964-12-14	\N	934	3152	1956-02-01
3153	1	1961-07-12	1977-01-14	\N	1189	3153	1961-07-25
3154	1	1961-10-06	2017-01-13	\N	2006	3154	1962-02-28
3155	1	1962-07-20	1967-01-27	\N	1073	3155	1962-07-25
3156	1	1963-01-30	1965-01-11	\N	1182	3156	1963-01-31
3157	1	1984-02-24	1986-12-29	\N	2844	3157	1984-02-29
3158	1	1986-07-23	\N	\N	1672	3158	1987-02-11
3159	1	1999-06-19	\N	\N	2489	3159	\N
3160	1	2011-05-26	\N	\N	2829	3160	\N
3161	1	2018-07-16	\N	\N	2832	3161	\N
3162	1	1876-01-13	1903-09-27	\N	338	3162	1904-07-11
3163	1	1934-10-12	1942-08-25	\N	2831	3163	1934-11-07
3164	1	1947-11-20	2021-04-09	\N	1040	3164	1948-07-21
3165	1	1958-07-26	\N	\N	1111	3165	1970-02-11
3166	1	1986-07-23	\N	\N	1672	3166	1987-02-11
3167	1	2011-05-26	\N	\N	2829	3167	\N
3168	1	2018-07-16	\N	\N	2832	3168	\N
3169	1	1876-01-15	1899-05-13	\N	2567	3169	1876-02-10
3170	2	1936-05-14	1984-07-17	\N	2846	840	\N
3171	3	1984-07-17	2014-10-03	\N	2847	840	\N
3172	4	2014-10-03	\N	\N	2848	840	\N
3173	2	1930-03-19	1945-01-14	\N	2849	882	\N
3174	3	1945-01-14	1968-11-27	\N	2850	882	\N
3175	4	1968-11-27	2003-06-27	\N	2851	882	\N
3176	5	2003-06-27	\N	\N	2852	882	\N
3177	2	1908-07-08	1916-09-30	\N	2853	542	\N
3178	3	1916-09-30	1918-03-13	\N	2854	542	\N
3179	4	1918-03-13	1929-11-14	\N	2855	542	\N
3180	5	1929-11-14	1937-03-03	\N	2856	542	\N
3181	6	1937-03-03	1940-02-08	\N	2857	542	\N
3182	7	1940-02-08	1940-09-14	\N	2858	542	\N
3183	2	1868-05-07	1886-01-03	\N	2859	324	\N
3184	3	1886-01-03	1927-05-24	\N	2860	324	\N
3185	4	1927-05-24	1967-06-20	\N	2861	324	\N
3186	5	1967-06-20	\N	\N	2862	324	\N
3187	2	1899-05-13	1926-05-08	\N	2863	3108	\N
3188	3	1926-05-08	1953-05-16	\N	2864	3108	\N
3189	4	1953-05-16	1987-06-03	\N	2865	3108	\N
3190	5	1987-06-03	\N	\N	2866	3108	\N
3191	2	1909-01-16	1919-12-27	\N	2867	544	\N
3192	3	1919-12-27	1980-07-22	\N	2868	544	\N
3193	4	1980-07-22	2009-04-02	\N	2869	544	\N
3194	5	2009-04-02	\N	\N	2870	544	\N
3195	2	1916-06-05	1937-03-27	\N	2871	3019	\N
3196	3	1937-03-27	2011-12-16	\N	2872	3019	\N
3197	2	1909-02-01	1962-05-28	\N	2873	590	\N
3198	3	1962-05-28	2013-05-30	\N	2874	590	\N
3199	4	2013-05-30	\N	\N	2875	590	\N
3200	2	1893-08-07	1943-04-26	\N	2876	431	\N
3201	3	1943-04-26	1977-03-21	\N	2877	431	\N
3202	2	1888-11-25	1893-11-24	\N	2878	330	\N
3203	3	1895-02-25	1962-05-20	\N	2879	330	\N
3204	4	1962-05-20	1989-12-13	\N	2880	330	\N
3205	5	1989-12-13	\N	\N	2881	330	\N
3206	3	2014-03-14	\N	\N	2882	1122	\N
3207	3	2001-12-31	2020-08-01	\N	2883	1168	\N
3208	4	2020-08-01	\N	\N	2884	1168	\N
3209	2	1934-01-23	1953-05-23	\N	2885	705	\N
3210	3	1953-05-23	2003-02-04	\N	2886	705	\N
3211	4	2003-02-04	\N	Not on Peerage Roll	2887	705	\N
3212	2	1895-02-25	1929-02-20	\N	2888	394	\N
3213	3	1929-02-20	1957-10-04	\N	2889	394	\N
3214	4	1957-10-04	\N	Check date of death	2890	394	\N
3215	5	\N	\N	Add date of succession	2891	394	\N
3216	2	1934-03-07	1965-01-06	On Peerages a-z list date of Patent is wrong should be 04-01-1916	2892	753	\N
3217	3	1965-01-06	1972-04-16	\N	2893	753	\N
3218	4	1972-04-16	1974-09-13	\N	2894	753	\N
3219	5	1974-09-13	\N	Check date of death	2895	753	\N
3220	6	\N	2002-08-19	Add date of succession	2896	753	\N
3221	7	2002-08-19	2020-03-12	\N	2897	753	\N
3222	8	2020-03-12	\N	\N	2898	753	\N
3223	2	1915-12-02	1927-10-13	\N	2899	414	\N
3224	3	1927-10-13	1938-01-10	\N	2900	414	\N
3225	4	1938-01-10	1954-03-30	\N	2901	414	\N
3226	5	1954-03-30	2000-02-23	\N	2902	414	\N
3227	6	2000-02-23	\N	\N	2903	414	\N
3228	1	1706-12-30	\N	\N	2904	3170	\N
3229	1	1706-12-30	\N	\N	2904	3171	\N
3230	1	1706-12-27	\N	\N	2905	3172	\N
3231	1	1706-12-27	\N	\N	2905	3173	\N
3232	1	1706-12-26	\N	\N	2906	3174	\N
3233	1	1706-12-26	\N	\N	2906	3175	\N
3234	1	1706-12-24	\N	\N	2907	3176	\N
3235	1	1706-12-24	\N	\N	2907	3177	\N
3236	1	1706-12-23	\N	\N	2908	3178	\N
3237	1	1706-12-23	\N	\N	2908	3179	\N
3238	1	1706-12-23	\N	\N	2909	3180	\N
3239	1	1706-12-21	\N	\N	2910	3181	\N
3240	1	1706-12-16	\N	\N	2911	3182	\N
3241	1	1706-12-14	\N	\N	2912	3183	\N
3242	1	1800-12-29	\N	\N	2913	3184	\N
3243	1	1800-12-29	\N	\N	2913	3185	\N
3244	1	1800-12-27	\N	\N	2914	3186	\N
3245	1	1800-12-27	\N	\N	2914	3187	\N
3246	1	1800-06-16	\N	\N	2915	3188	\N
3247	1	1799-09-24	\N	\N	2916	3189	\N
3250	1	1868-12-21	\N	\N	2917	3192	\N
3251	1	1868-08-10	\N	\N	2918	3193	\N
3252	1	1868-08-10	\N	\N	2918	3194	\N
3254	1	1855-05-14	\N	\N	2919	3196	\N
3256	1	1848-07-10	\N	\N	2920	3198	\N
3257	1	1706-12-14	\N	\N	2921	3199	\N
3258	1	1706-12-14	\N	\N	2921	3200	\N
3259	1	1706-12-14	\N	\N	2921	3201	\N
3260	1	1706-12-09	\N	\N	2922	3202	\N
3261	1	1706-12-09	\N	\N	2922	3203	\N
3262	1	1706-12-09	\N	\N	2922	3204	\N
3263	1	1706-12-09	\N	\N	2922	3205	\N
3264	1	1706-12-09	\N	\N	2922	3206	\N
3265	1	1705-11-26	\N	\N	2923	3207	\N
3266	1	1705-11-26	\N	\N	2923	3208	\N
3267	1	1705-04-14	\N	\N	2924	3209	\N
3268	1	1705-04-14	\N	\N	2924	3210	\N
3269	1	1703-03-29	\N	\N	2925	3211	\N
3270	1	1703-03-29	\N	\N	2925	3212	\N
3271	1	1703-03-24	\N	\N	2926	3213	\N
3272	1	1703-03-23	\N	\N	2927	3214	\N
3273	1	1703-03-17	\N	\N	2928	3215	\N
3274	1	1703-03-16	\N	\N	2929	3216	\N
3275	1	1799-04-24	\N	\N	2930	3217	\N
3276	1	1799-04-24	\N	\N	2930	3218	\N
3277	1	1799-04-24	\N	\N	2931	3219	\N
3278	1	1799-04-24	\N	\N	2931	3220	\N
3280	1	1797-11-30	\N	\N	2932	3222	\N
3281	1	1797-10-30	\N	\N	2933	3223	\N
3282	1	1797-10-30	\N	\N	2933	3224	\N
3283	1	1797-10-26	\N	\N	2934	3225	\N
3284	1	1797-10-26	\N	\N	2935	3226	\N
3285	1	1797-10-26	\N	\N	2936	3227	\N
3286	1	1797-10-26	\N	\N	2937	3228	\N
3287	1	1845-06-03	\N	\N	2938	3229	\N
3288	1	1836-05-04	\N	\N	2939	3230	\N
3291	1	1831-05-28	\N	\N	2940	3233	\N
3292	1	1831-01-06	\N	\N	2941	3234	\N
3293	1	1831-01-06	\N	\N	2941	3235	\N
3294	1	1827-06-23	\N	\N	2942	3236	\N
3295	1	1827-06-23	\N	\N	2942	3237	\N
3296	1	1826-06-27	\N	\N	2943	3238	\N
3248	1	1799-07-18	1823-11-17	\N	110	3190	\N
3249	1	1898-11-11	1924-09-26	\N	711	3191	\N
3253	1	1863-12-14	1871-10-06	\N	279	3195	\N
3255	1	1852-02-11	1873-12-07	\N	278	3197	\N
3279	1	1798-11-06	1805-10-21	\N	3	3221	\N
3289	1	1834-06-13	1857-05-30	\N	185	3231	\N
3290	1	1831-09-14	2012-03-02	\N	2633	3232	\N
\.


--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerage_holdings_id_seq', 3296, true);


--
-- Data for Name: peerage_types; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerage_types (name, id) FROM stdin;
Life peerage: Appellate Jurisdiction Act 1876	1
Hereditary peerage	2
Hereditary peerage (already peer of Ireland)	3
Hereditary peerage (already peer of Scotland)	4
Life peerage: Life Peerages Act 1958	5
Life peerage: already a hereditary peer	6
Promotion	7
New hereditary peerage: not a promotion	8
Hereditary peerage subsidiary to another created by the same letters patent	9
Peerage of Ireland	10
Promotion in the peerage of Ireland	11
\.


--
-- Name: peerage_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerage_types_id_seq', 11, true);


--
-- Data for Name: peerages; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerages (title, territorial_designation, extinct_on, last_number, notes, id, peerage_type_id, rank_id, wikidata_id, of_title, special_remainder_id, letters_patent_id, kingdom_id, letter_id) FROM stdin;
Craven	in the County of York	\N	\N	8th E died 30 Aug 1990	11	7	6	\N	t	\N	29	5	4
Powis	in the County of Montgomery	\N	\N	7th E died 13 Aug 1993	34	7	6	\N	t	\N	31	5	17
Romney	\N	\N	\N	\N	13	7	6	\N	t	\N	32	5	19
Wilton	of Wilton Castle in the County of Hereford	\N	\N	SR to 2nd & subsequent sons of his dau Eleanor	16	7	6	\N	t	1	33	5	24
Abercromby	of Aboukir and of Tullibody in the County of Clackmannan	1924-10-07	5	SR to heirs male by late husband	10	2	8	\N	f	3	34	5	2
Exeter	\N	\N	\N	\N	5	7	9	\N	t	\N	35	5	6
Sandys	of Ombersley in the County of Worcester	\N	\N	SR to younger sons before eldest	28	2	8	\N	f	1	36	5	20
Keith	of Banheath in the County of Dumbarton	1867-11-11	2	SR to dau; cr V Keith 1814	32	8	8	\N	f	2	37	5	12
Barham	of Barham Court and Teston in the County of Kent	\N	\N	SR to dau; 3rd L cr E of Gainsborough 1841	37	2	8	\N	f	2	38	5	3
Butler	of Lanthony in the County of Monmouth	1820-08-10	1	cr M of Ormonde (I) 1816	3	3	8	\N	f	\N	1	5	3
Rosslyn	in the County of MidLothian	\N	\N	SR to heirs male of his sister Janet Erskine deceased	6	7	6	\N	t	1	40	5	19
Carysfort	of the Hundred of Norman Cross in the County of Huntingdon	1909-09-04	5	\N	4	3	8	\N	f	\N	2	5	4
Nelson	of the Nile and of Burnham Thorpe in the County of Norfolk	1805-10-21	1	cr L Nelson with special remainder 18 August 1801	8	7	12	\N	f	\N	3	5	15
Sussex	\N	1843-04-21	1	\N	20	2	4	\N	t	\N	27	5	20
Alvanley	of Alvanley in the County Palatine of Chester	1857-06-24	3	\N	9	2	8	\N	f	\N	4	5	2
Grey	of Howick in the County of Northumberland	\N	\N	cr E Grey 1806	15	2	8	\N	f	\N	5	5	8
Saint Helens	of Saint Helens, Isle of Wight and County of Southampton	1839-02-19	1	\N	17	3	8	\N	f	\N	6	5	20
Thomond	of Taplow Court in the County of Buckingham	1808-02-10	1	\N	19	3	8	\N	f	\N	7	5	21
Keith	of Stonehaven Marischal in the County of Kincardine	1823-03-10	1	cr L Keith (SR) 1803, V Keith 1814	22	3	8	\N	f	\N	8	5	12
Hutchinson	of Alexandria and of Knocklofty in the County of Tipperary	1832-06-29	1	succ as 2nd E of Donoughmore (I) 1825	23	2	8	\N	f	\N	9	5	9
Redesdale	of Redesdale in the County of Northumberland	1886-05-02	2	2nd L cr E of Redesdale 1877	24	2	8	\N	f	\N	10	5	19
Curzon	of Penn in the County of Buckingham	\N	\N	2nd V cr E Howe 1821	25	7	12	\N	f	\N	11	5	4
Ellenborough	of Ellenborough in the County of Cumberland	\N	\N	2nd L cr E of Ellenborough 1844,ext 1871	27	2	8	\N	f	\N	12	5	6
Arden	of Arden in the County of Warwick	1929-01-10	5	2nd L succ 1841 as 6th E of Egmont (I)\nIrish barony (also Arden) survived until 2011	29	3	8	\N	f	\N	13	5	2
Sheffield	of Sheffield in the County of York	1909-04-21	3	cr E of Sheffield (I) 1816	30	3	8	\N	f	\N	14	5	20
Melville	of Melville in the County of Edinburgh	\N	\N	\N	31	2	12	\N	f	\N	15	5	14
Lake	of Delhi and Laswary and of Aston Clinton in the County of Buckingham	1848-06-24	3	cr V Lake 1807	35	2	8	\N	f	\N	16	5	13
Sidmouth	of Sidmouth in the County of Devon	\N	\N	\N	36	2	12	\N	f	\N	17	5	20
Keith	\N	1823-03-10	1	\N	77	7	12	\N	f	\N	18	5	12
Collingwood	of Coldbourne and Hethpoole in the County of Northumberland	1810-03-07	1	\N	39	2	8	\N	f	\N	19	5	4
Erskine	of Restormel Castle in the County of Cornwall	\N	\N	7th L succ 1960 as 16th E of Buchan	40	2	8	\N	f	\N	20	5	6
Anson	of Shugborough and Orgrave in the County of Stafford	\N	\N	2nd V cr E of Lichfield 1831	41	2	12	\N	f	\N	21	5	2
Monteagle	of Westport in the County of Mayo	\N	\N	\N	42	3	8	\N	f	\N	22	5	14
Moore	of Moore Place in the County of Kent	1892-06-29	3	\N	1	3	8	\N	f	\N	23	5	14
Granard	of Castle Donnington in the County of Leicester	\N	\N	9th E died 19 Nov 1992	45	3	8	\N	f	\N	24	5	8
Crewe	of Crewe in the County Palatine of Chester	1894-01-03	3	\N	46	2	8	\N	f	\N	25	5	4
Cambridge	\N	1904-03-17	2	\N	21	2	4	\N	t	\N	26	5	4
Chichester	\N	\N	\N	\N	14	7	6	\N	t	\N	28	5	4
Minto	in the County of Roxburgh	\N	\N	\N	69	7	6	\N	t	\N	76	5	14
Mulgrave	\N	\N	\N	2nd E cr M of Normanby 1838	66	7	6	\N	t	\N	77	5	14
Orford	\N	1931-09-27	5	\N	50	7	6	\N	t	\N	78	5	16
Verulam	\N	\N	\N	Old title: also 2nd L Verulam (GB)	95	7	6	\N	t	\N	79	5	23
Wellington	in the County of Somerset	\N	\N	cr M of Wellington 3 Oct 1812	63	7	6	\N	t	\N	80	5	24
Anglesey	\N	\N	\N	\N	82	7	9	\N	t	\N	81	5	2
Northampton	\N	\N	\N	\N	64	7	9	\N	t	\N	82	5	15
Wellington	in the County of Somerset	\N	\N	cr D of Wellington 1814	68	7	9	\N	t	\N	83	5	24
Beauchamp	of Powyke in the County of Worcester	1979-01-03	8	cr E Beauchamp 1815	47	2	8	\N	f	\N	41	5	3
Harrowby	in the County of Lincoln	\N	\N	\N	61	7	6	\N	t	\N	74	5	9
Ponsonby	of Imokilly in the County of Cork	1866-09-10	4	title subsumed 12 April 1839-21 Feb 1855	48	2	8	\N	f	\N	42	5	17
Manvers	\N	1955-02-13	6	\N	49	7	6	\N	f	\N	43	5	14
Grey	\N	\N	\N	\N	51	7	6	\N	f	\N	44	5	8
Ailsa	of Ailsa in the County of Ayr	\N	\N	cr M of Ailsa 1831	52	4	8	\N	f	\N	45	5	2
Gardner	of Uttoxeter in the County of Stafford	\N	\N	dormant on death of 2nd L on 2 Nov 1883	54	3	8	\N	f	\N	47	5	8
Manners	of Foston in the County of Sutton	\N	\N	\N	56	2	8	\N	f	\N	48	5	14
Lake	of Delhi and Laswary and of Aston Clinton in the County of Buckingham	1848-06-24	3	\N	57	7	12	\N	f	\N	49	5	13
Cathcart	of Cathcart in the County of Renfrew	\N	\N	cr E Cathcart 1814	58	4	12	\N	f	\N	50	5	4
Gambier	of Iver in the County of Bucks	1833-04-19	1	\N	59	2	8	\N	f	\N	51	5	8
Wellington	of Talavera and of Wellington in the County of Somerset	\N	\N	cr E of Wellington 28 Feb 1812	62	2	12	\N	f	\N	52	5	24
Camden	\N	\N	\N	\N	65	7	9	\N	f	\N	53	5	4
Whitworth	of Adbaston in the County of Stafford	1825-05-12	1	cr E Whitworth 1815	70	3	12	\N	f	\N	54	5	24
Niddry	of Niddry in the County of Linlithgow	\N	\N	succ as L Hopetoun etc 1817; 4th L cr M of Linlithgow	72	2	8	\N	f	\N	55	5	15
Lynedoch	of Balgowan in the County of Perth	1843-12-18	1	\N	73	2	8	\N	f	\N	56	5	13
Combermere	of Combermere in the County Palatine of Chester	\N	\N	cr V Combermere 1827	74	2	8	\N	f	\N	57	5	4
Hill	of Almaraz and of Hawkestone in the County of Salop	1842-12-10	1	further grant (SR) 1816; cr V Hill 1842	75	2	8	\N	f	\N	58	5	9
Beresford	of Albuera and of Dungarvan in the County of Waterford	1854-01-08	1	cr V Beresford 1823	76	2	8	\N	f	\N	59	5	3
Exmouth	of Canonteign in the County of Devon	\N	\N	cr V Exmouth 1816	78	2	8	\N	f	\N	60	5	6
Stewart of Stewart's Court	and of Ballilawn in the County of Donegal	\N	\N	cr E Vane 1823; succ as 3rd M of Londonderry (I) 1822	79	2	8	\N	f	\N	61	5	20
Cathcart	\N	\N	\N	\N	80	7	6	\N	f	\N	62	5	4
Gordon	of Aberdeen in the County of Aberdeen	\N	\N	4th V cr M of Aberdeen and Temair	81	4	12	\N	f	\N	63	5	8
Trench	of Garbally in the County of Galway	\N	\N	cr V Clancarty 1823	83	3	8	\N	f	\N	64	5	21
Meldrum	of Morven in the County of Aberdeen	\N	\N	succ as 9th M of Huntly (S) 1836	86	4	8	\N	f	\N	66	5	14
Ross	of Hawkhead in the County of Renfrew	1890-04-23	3	\N	87	4	8	\N	f	\N	67	5	19
Grinstead	of Grinstead in the County of Wilts	\N	\N	\N	88	3	8	\N	f	\N	68	5	8
Foxford	of Stackpole Court in the County of Clare	\N	\N	\N	89	3	8	\N	f	\N	69	5	7
Churchill	of Whichwood in the County of Oxford	\N	\N	3rd L cr V Churchill 1902	90	2	8	\N	f	\N	70	5	4
Lauderdale	of Thirlestone in the County of Berwick	1863-03-22	3	\N	44	4	8	\N	f	\N	71	5	13
Whitworth	\N	1825-05-12	1	\N	96	7	6	\N	f	\N	72	5	24
Lonsdale	in the County of Westmorland	\N	\N	\N	55	7	6	\N	t	\N	75	5	13
Morley	in the County of Devon	\N	\N	\N	99	7	6	\N	t	\N	115	5	14
Rayleigh	of Terling Place in the County of Essex	\N	\N	SR to heirs male by her husband	129	2	8	\N	f	3	116	5	19
Stradbroke	in the County of Suffolk	\N	\N	\N	128	7	6	\N	t	\N	117	5	20
Ailesbury	in the County of Buckingham	\N	\N	\N	112	7	9	\N	t	\N	118	5	2
Bristol	\N	\N	\N	\N	137	7	9	\N	t	\N	119	5	3
Hastings	\N	1868-11-01	4	Old title also 1st L Rawdon (cr 1783) & 14th L Hastings (succ 1808)	106	7	9	\N	t	\N	120	5	9
Vane	\N	\N	\N	SR to h m of b lawfully begotten by his present wife Frances Ann; 2nd E succ as 5th M of Londonderry 1872	133	8	6	\N	f	3	123	5	23
Brownlow	\N	1921-03-17	3	\N	97	7	6	\N	f	\N	84	5	3
Saint Germans	in the County of Cornwall	\N	\N	SR in default of h m of b to his brother Wm Eliot & h m of b	98	7	6	\N	t	1	124	5	20
Beauchamp	\N	1979-01-03	8	\N	101	7	6	\N	f	\N	85	5	3
Eldon	in the County Palatine of Durham	\N	\N	had been cr L Eldon 1799	108	7	6	\N	t	\N	113	5	6
Prudhoe	of Prudhoe Castle in the County of Northumberland	1865-02-12	1	succ as 4th D of Northumberland 1847	104	2	8	\N	f	\N	86	5	17
Exmouth	of Canonteign in the County of Devon	\N	\N	\N	105	7	12	\N	f	\N	87	5	6
Colchester	of Colchester in the County of Essex	1919-02-26	3	\N	107	2	8	\N	f	\N	88	5	4
Howe	\N	\N	\N	\N	111	7	6	\N	f	\N	89	5	9
Somers	\N	1883-09-26	3	\N	113	7	6	\N	f	\N	90	5	20
Ker	of Kersheugh in the County of Roxburgh	\N	\N	\N	114	4	8	\N	f	\N	91	5	12
Minster	of Minster Abbey in the County of Kent	\N	\N	\N	115	3	8	\N	f	\N	92	5	14
Melros	of Tynninghame in the County of Haddington	1858-12-01	1	succ father as 9th E of Haddington (S) 17 March 1828	154	2	8	\N	f	\N	93	5	14
Wemyss	of Wemyss in the County of Fife	\N	\N	\N	117	4	8	\N	f	\N	94	5	24
Clanbrassill	of Hyde Hall in the County of Hertford and Dundalk in the County of Louth	1897-07-03	3	\N	118	3	8	\N	f	\N	95	5	4
Kingston	of Mitchelstown in the County of Cork	1869-09-08	3	\N	119	3	8	\N	f	\N	96	5	12
Silchester	of Silchester in the County of Southampton	\N	\N	\N	120	3	8	\N	f	\N	97	5	20
Glenlyon	of Glenlyon in the County of Perth	1957-05-08	5	2nd L succ 1846 as 6th D of Atholl	121	2	8	\N	f	\N	98	5	8
Maryborough	of Maryborough in the Queen's County	1863-07-25	3	succ 1842 as 3rd E of Mornington (I)	122	2	8	\N	f	\N	99	5	14
Stowell	of Stowell Park in the County of Gloucester	1836-01-28	1	bro of E of Eldon	124	2	8	\N	f	\N	100	5	20
Ravensworth	of Ravensworth Castle in the County Palatine of Durham and of Elsington in the County of Northumberland	\N	\N	2nd L cr E of Ravensworth 1874 (extinct on death of 3rd E 1904)	125	2	8	\N	f	\N	101	5	19
Delamere	of Vale Royal in the County Palatine of Chester	\N	\N	\N	126	2	8	\N	f	\N	102	5	5
Forester	of Willey Park in the County of Salop	\N	\N	\N	127	2	8	\N	f	\N	103	5	7
Bexley	of Bexley in the County of Kent	1851-02-08	1	\N	131	2	8	\N	f	\N	104	5	3
Beresford	of Beresford in the County of Stafford	1854-01-08	1	\N	132	7	12	\N	f	\N	105	5	3
Clancarty	of the County of Cork	\N	\N	had been cr L Trench 1815	134	8	12	\N	f	\N	106	5	4
Granville	of Stone Park in the County of Stafford	\N	\N	cr E Granville 1833	93	2	12	\N	f	\N	107	5	8
Tadcaster	of Tadcaster in the County of York	1846-08-21	1	\N	138	3	8	\N	f	\N	108	5	21
Somerhill	of Somerhill in the County of Kent	1916-04-12	2	\N	139	3	8	\N	f	\N	109	5	20
Wigan	of Haigh Hall in the County Palatine of Lancaster	\N	\N	\N	140	4	8	\N	f	\N	110	5	24
Ranfurly	of Ramphorlie in the County of Renfrew	\N	\N	cr E of Ranfurly (I) 1831; ?th L died 6 Nov 1988	141	3	8	\N	f	\N	111	5	19
Bradford	in the County of Salop	\N	\N	\N	100	7	6	\N	t	\N	112	5	3
Falmouth	in the County of Cornwall	1852-08-29	2	\N	109	7	6	\N	t	\N	114	5	7
Cleveland	\N	1891-08-21	4	cr D of Cleveland 1833	155	7	9	\N	t	\N	166	5	4
Munster	\N	2000-12-30	7	SR to brothers	169	2	6	\N	t	1	167	5	14
Farnborough	of Bromley Hill Place in the County of Kent	1838-01-17	1	\N	142	2	8	\N	f	\N	125	5	7
de Tabley	of Tabley House in the County Palatine of Chester	1895-11-22	3	\N	143	2	8	\N	f	\N	126	5	5
Canning	of Kilbrahan in the County of Kilkenny	1862-06-17	2	SR to heirs male of body by late husband George Canning	159	2	12	\N	f	3	164	5	4
Feversham	of Duncombe Place in the County of York	\N	\N	3rd L cr E of Feversham 1868 (ext(2) 1963)	145	2	8	\N	f	\N	128	5	7
Amherst	of Arracan in the East Indies	1993-03-04	5	\N	147	7	6	\N	f	\N	129	5	2
Combermere	of Bhurtpore in the East Indies and of Combermere in the County Palatine of Chester	\N	\N	\N	148	7	12	\N	f	\N	130	5	4
Lyndhurst	of Lyndhurst in the County of Southampton	1863-10-12	1	\N	149	2	8	\N	f	\N	131	5	13
Goderich	of Nocton in the County of Lincoln	1923-09-22	3	cr E of Ripon 1833	150	2	12	\N	f	\N	132	5	8
Fife	of the County of Fife	1857-03-09	1	\N	151	3	8	\N	f	\N	133	5	7
Tenterden	of Hendon in the County of Middlesex	1939-09-16	4	\N	152	2	8	\N	f	\N	134	5	21
Plunket	of Newtown in the County of Cork	\N	\N	\N	153	2	8	\N	f	\N	135	5	17
Cawdor	of Castle Martin in the County of Pembroke	\N	\N	6th E died 20 June 1993	157	7	6	\N	f	\N	136	5	4
Cowley	of Wellesley in the County of Somerset	\N	\N	2nd L cr E Cowley 1857	158	2	8	\N	f	\N	137	5	4
Stuart de Rothesay	of the Isle of Bute	1845-11-06	1	\N	160	2	8	\N	f	\N	138	5	20
Heytesbury	of Heytesbury in the County of Wilts	\N	\N	\N	161	2	8	\N	f	\N	139	5	9
Rosebery	of Rosebery in the County of Edinburgh	\N	\N	2nd L cr E of Midlothian 1911	162	4	8	\N	f	\N	140	5	19
Clanwilliam	of Clanwilliam in the County of Tipperary	\N	\N	\N	163	3	8	\N	f	\N	141	5	4
Durham	of the City of Durham and of Lambton Castle in the County Palatine of Durham	\N	\N	cr E of Durham 1833	164	2	8	\N	f	\N	142	5	5
Skelmersdale	of Skelmersdale in the County Palatine of Lancaster	\N	\N	2nd L cr E of Lathom 1880 (ext(3) 1930)	165	2	8	\N	f	\N	143	5	20
Wallace	of Knaresdale in the County of Northumberland	1844-02-23	1	\N	166	2	8	\N	f	\N	144	5	24
Wynford	of Wynford Eagle in the County of Dorset	\N	\N	\N	167	2	8	\N	f	\N	145	5	24
Brougham and Vaux	of Brougham in the County of Westmorland	1868-05-07	1	further creation (SR) 1860	168	2	8	\N	f	\N	146	5	3
Kilmarnock	of Kilmarnock in the County of Ayr	\N	\N	\N	170	4	8	\N	f	\N	147	5	12
Fingall	of Woolhampton Lodge in the County of Berks	1984-03-05	5	\N	171	3	8	\N	f	\N	148	5	7
Sefton	of Croxteth in the County Palatine of Lancaster	1972-04-13	6	\N	172	3	8	\N	f	\N	149	5	20
Clements	of Kilmacrenan in the County of Donegal	1952-06-09	4	\N	173	3	8	\N	f	\N	150	5	4
Dover	of Dover in the County of Kent	1899-09-10	4	2nd L succ as 3rd V Clifden (I) 1836	175	2	8	\N	f	\N	152	5	5
Kenlis	of Kenlis or Kells in the County of Meath	\N	\N	\N	178	3	8	\N	f	\N	153	5	12
Chaworth	of Eaton Hall in the County of Hereford	\N	\N	\N	179	3	8	\N	f	\N	154	5	4
Ludlow	\N	1842-04-16	1	\N	181	3	8	\N	f	\N	155	5	13
Penshurst	of Penshurst in the County of Kent	1869-01-09	3	\N	136	3	8	\N	f	\N	156	5	17
Howden	of Howden and Grimston in the County of York	1873-10-09	2	\N	183	3	8	\N	f	\N	157	5	9
Oakley	of Caversham in the County of Oxford	\N	\N	succ 1832 as 3rd E Cadogan	185	2	8	\N	f	\N	159	5	16
Poltimore	of Poltimore in the County of Devon	\N	\N	\N	186	2	8	\N	f	\N	160	5	17
Wenlock	of Wenlock in the County of Salop	1834-04-10	1	brother cr L Wenlock 1839	187	2	8	\N	f	\N	161	5	24
Mostyn	of Mostyn in the County of Flint	\N	\N	\N	188	2	8	\N	f	\N	162	5	14
Dudley	of Dudley Castle in the County of Stafford	1833-03-06	1	\N	156	7	6	\N	t	\N	163	5	5
Ailsa	of the Isle of Ailsa in the County of Ayr	\N	\N	7th M died 7 April 1994	176	7	9	\N	t	\N	165	5	2
Effingham	in the County of Surrey	\N	\N	6th E died 23 Feb 1996	224	7	6	\N	t	\N	202	5	6
Lichfield	of Lichfield in the County of Stafford	\N	\N	\N	196	7	6	\N	t	\N	203	5	13
Lovelace	\N	2018-01-31	5	& V Ockham	234	7	6	\N	t	\N	204	5	13
Zetland	\N	\N	\N	3rd E cr M of Zetland 1892	235	7	6	\N	t	\N	205	5	27
Breadalbane	\N	1862-11-08	2	\N	192	7	9	\N	t	\N	206	5	3
Westminster	\N	\N	\N	3rd M cr D of Westminster 1874	194	7	9	\N	t	\N	207	5	24
Wenman	of Thame Park and Swalcliffe in the County of Oxford	1870-08-09	1	\N	210	2	8	\N	f	\N	208	5	24
Templemore	of Templemore in the County of Donegall	\N	\N	5th L succ 1975 as 7th M of Donegall (I) & 7th L Fisherwick	190	2	8	\N	f	\N	168	5	21
Stratheden	of Cupar in the County of Fife	\N	\N	SR to h m by her husband (cr L Campbell 1841)	222	2	8	\N	f	3	209	5	20
Dinorben	of Kinmell in the County of Denbigh	1852-10-06	2	\N	191	2	8	\N	f	\N	169	5	5
Ducie	\N	\N	\N	6th E died 12 Nov 1991	226	7	6	\N	t	\N	200	5	5
Cloncurry	of Cloncurry in the County of Kildare	1929-07-18	4	\N	195	3	8	\N	f	\N	170	5	4
de Saumarez	in the Island of Guernsey	\N	\N	6th L died 20 Jan 1991	197	2	8	\N	f	\N	171	5	5
Godolphin	of Farnham Royal in the County of Bucks	1964-03-20	6	2nd L succ as 8th D of Leeds 4 May 1859	198	2	8	\N	f	\N	172	5	8
Hunsdon	of Scutterskelfe in the County of York	1884-03-12	1	\N	199	4	8	\N	f	\N	173	5	9
Amesbury	of Kintbury, Amesbury and of Barton Bourt in the County of Berks and of Aston Hall in the County of Flint	1832-06-30	1	\N	200	2	8	\N	f	\N	174	5	2
Stanley	of Bickerstaffe in the County Palatine of Lancaster	\N	\N	succ as 13th E of Derby 21 Oct 1834	201	2	8	\N	f	\N	175	5	20
Western	of Rivenhall in the County of Essex	1844-11-04	1	\N	203	2	8	\N	f	\N	176	5	24
Granville	\N	\N	\N	5th E died 31 Oct 1996	207	7	6	\N	f	\N	177	5	8
Solway	of Kinmount in the County of Dumfries	1837-12-03	1	\N	208	4	8	\N	f	\N	178	5	20
Denman	of Dovedale in the County of Derby	\N	\N	\N	209	2	8	\N	f	\N	179	5	5
Duncannon	of Bessborough in the County of Kilkenny	\N	\N	succ 1844 as 4th E of Bessborough (I) & 4th L Ponsonby	211	2	8	\N	f	\N	180	5	5
Abinger	of Abinger in the County of Surrey and of the City of Norwich	\N	\N	\N	213	2	8	\N	f	\N	181	5	2
De L'Isle and Dudley	of Penshurst in the County of Kent	\N	\N	6th L cr V De L'Isle 1956	214	2	8	\N	f	\N	182	5	5
Canterbury	of the City of Canterbury	1941-02-26	6	\N	215	2	12	\N	f	\N	183	5	4
Ashburton	of Ashburton in the County of Devon	\N	\N	6th L died 12 June 1991	216	2	8	\N	f	\N	184	5	2
Glenelg	of Glenelg in the County of Inverness	1866-04-23	1	\N	217	2	8	\N	f	\N	185	5	8
Hatherton	of Hatherton in the County of Stafford	\N	\N	\N	218	2	8	\N	f	\N	186	5	9
Strafford	of Harmondsworth in the County of Middlesex	\N	\N	cr E of Strafford 1847	219	2	8	\N	f	\N	187	5	20
Worlingham	of Beccles in the County of Suffolk	\N	\N	\N	220	3	8	\N	f	\N	188	5	24
Langdale	of Langdale in the County of Westmorland	1851-04-18	1	\N	223	2	8	\N	f	\N	190	5	13
Portman	of Orchard Portman in the County of Somerset	\N	\N	cr V Portman 1873	225	2	8	\N	f	\N	191	5	17
Hamilton	of Wishaw in the County of Lanark	1868-12-22	1	\N	182	4	8	\N	f	\N	193	5	9
Lismore	of Shanbally castle in the County of Tipperary	1898-10-29	2	\N	237	3	8	\N	f	\N	195	5	13
Rossmore	of Monaghan in the County of Monaghan	\N	\N	\N	238	3	8	\N	f	\N	196	5	19
Carew	of Castleboro' in the County of Wexford	\N	\N	6th L died 27 June 1994	239	3	8	\N	f	\N	197	5	4
De Mauley	of Canford in the County of Dorset	\N	\N	\N	240	2	8	\N	f	\N	198	5	5
Sutherland	in Scotland	\N	\N	\N	202	7	4	\N	t	\N	199	5	20
Durham	\N	\N	\N	6th E disclaimed	205	7	6	\N	t	\N	201	5	5
Gainsborough	in the County of Lincoln	\N	\N	\N	262	7	6	\N	t	\N	241	5	8
Strafford	\N	\N	\N	\N	276	7	6	\N	t	\N	242	5	20
Yarborough	\N	\N	\N	7th E died 21 March 1991	228	7	6	\N	t	\N	243	5	26
Normanby	in the County of York	\N	\N	4th M died 30 Jan 1994	233	7	9	\N	t	\N	245	5	15
Wales	\N	1901-01-22	1	merged in Crown 22 January 1901	269	7	11	\N	t	\N	246	5	24
Inverness	\N	1873-08-01	1	\N	259	2	4	\N	t	\N	247	5	10
Hill	of Hawkstone and of Hardwick in the County of Salop	\N	\N	\N	270	7	12	\N	f	1	248	5	9
Charlemont	of Charlemont in the County of Armagh	1892-01-12	2	SR to brother	230	3	8	\N	f	1	249	5	4
Wrottesley	of Wrottesley in the County of Stafford	\N	\N	\N	241	2	8	\N	f	\N	210	5	24
Sudeley	of Toddington in the County of Gloucester	\N	\N	\N	242	2	8	\N	f	\N	211	5	20
Auckland	\N	1849-01-01	1	\N	257	7	6	\N	t	\N	239	5	2
Methuen	of Corsham in the County of Wilts	\N	\N	?th L died 24 Aug 1994	243	2	8	\N	f	\N	212	5	14
Ponsonby	of Imokilly in the County of Cork	1855-02-21	1	\N	244	7	12	\N	f	\N	213	5	17
Furnival	of Malahide in the County of Dublin	1849-10-29	1	\N	246	3	8	\N	f	\N	214	5	7
Stanley of Alderley	in the County of Chester	\N	\N	4th L succeeded 1909 as 4th L Sheffield (I)	247	2	8	\N	f	\N	215	5	20
Leigh	of Stoneleigh in the County of Warwick	\N	\N	\N	249	2	8	\N	f	\N	216	5	13
Wenlock	of Wenlock in the County of Salop	1932-06-14	6	brother had been cr L Wenlock 1831 (ext 1834)	250	2	8	\N	f	\N	217	5	24
Lurgan	of Lurgan in the County of Armagh	1991-09-17	5	\N	251	2	8	\N	f	\N	218	5	13
Colborne	of West Harling in the County of Norfolk	1854-05-03	1	\N	252	2	8	\N	f	\N	219	5	4
De Freyne	of Artagh in the County of Roscommon	1856-09-29	1	new patent with SR 5 April 1851	253	2	8	\N	f	\N	220	5	5
Dunfermline	of Dunfermline in the County of Fife	1868-07-02	2	mother had been cr B Abercromby	254	2	8	\N	f	\N	221	5	5
Monteagle of Brandon	in the County of Kerry	\N	\N	\N	255	2	8	\N	f	\N	222	5	14
Seaton	of Seaton in the County of Devon	1955-03-12	4	\N	256	2	8	\N	f	\N	223	5	20
Keane	of Ghuznee in Affghanistan and of Cappoquin in the County of Waterford	1901-11-27	3	\N	258	2	8	\N	f	\N	224	5	12
Fitzhardinge	\N	1857-10-10	1	brother cr L Fitzhardinge 1861	264	7	6	\N	f	\N	226	5	7
Kenmare	of Castle Rosse in the County of Kerry	1853-10-31	1	\N	265	3	8	\N	f	\N	227	5	12
Vivian	of Glynn and Truro in the County of Cornwall	\N	\N	5th L died 24 June 1991	267	2	8	\N	f	\N	229	5	23
Congleton	of Congleton in the County Palatine of Chester	\N	\N	\N	268	2	8	\N	f	\N	230	5	4
Bateman	of Shobdon in the County of Hereford	1931-11-04	3	\N	229	2	8	\N	f	\N	231	5	3
Innes	\N	\N	\N	\N	231	4	6	\N	f	\N	232	5	10
Acheson	of Clancairney in the County of Armagh	\N	\N	succ 1849 as 3rd E of Gosford (I) & 2nd L Worlingham	277	2	8	\N	f	\N	233	5	2
Dartrey	of Dartrey in the County of Monaghan	1933-02-09	3	cr E of Dartrey 1866	278	3	8	\N	f	\N	234	5	5
Milford	of Picton Castle in the County of Pembroke	1857-01-03	1	\N	279	2	8	\N	f	\N	235	5	14
Gough	of Goojerat of the Punjaub and of the City of Limerick in Ireland	\N	\N	\N	281	7	12	\N	f	\N	236	5	8
Elgin	of Elgin in Scotland	\N	\N	\N	283	4	8	\N	f	\N	237	5	6
Oxenfoord	of Cousland in the County of Edinburgh	\N	\N	\N	263	4	8	\N	f	1	238	5	16
Ellesmere	of Ellesmere in the County of Salop	\N	\N	5th E succ 1963 as 6th D of Sutherland	275	2	6	\N	t	\N	240	5	6
de Freyne	of Coolavin in the County of Sligo	\N	\N	SR to 3 brothers	292	8	8	\N	f	1	288	5	5
Londesborough	of Londesborough in the East Riding of the County of York	\N	\N	2nd L cr E of Londesborough 1887 (ext 1937)	286	2	8	\N	f	\N	250	5	13
Dudley	of Dudley Castle in the County of Stafford	\N	\N	\N	323	7	6	\N	t	\N	286	5	5
Overstone	of Overstone and of Fotheringhay, both in the County of Northampton	1883-11-17	1	\N	287	2	8	\N	f	\N	251	5	16
Truro	of Bowes in the County of Middlesex	1899-03-08	3	\N	289	2	8	\N	f	\N	252	5	21
Cranworth	of Cranworth in the County of Norfolk	1868-07-26	1	\N	290	2	8	\N	f	\N	253	5	4
Broughton	of Broughton de Gyfford in the County of Wilts	1869-06-03	1	\N	291	2	8	\N	f	\N	254	5	3
Saint Leonards	of Slaugham in the County of Sussex	1985-06-01	4	\N	293	2	8	\N	f	\N	255	5	20
Stratford de Redcliffe	in the County of Somerset	1880-08-14	1	\N	294	2	12	\N	f	\N	256	5	20
Raglan	of Raglan in the County of Monmouth	\N	\N	\N	295	2	8	\N	f	\N	257	5	19
Aveland	of Aveland in the County of Lincoln	1983-03-29	4	2nd L succ 1888 as 24th L Willoughby de Eresby & was cr E of Ancaster 1892	297	2	8	\N	f	\N	259	5	2
Kenmare	of Castlerosse in the County of Kerry	1952-02-14	5	\N	298	3	8	\N	f	\N	260	5	12
Lyons	of Christchurch in the County of Southampton	1887-12-05	2	2nd L cr V Lyons 1881	299	2	8	\N	f	\N	261	5	13
Wensleydale	of Walton in the County Palatine of Lancaster	1868-02-25	1	\N	300	8	8	\N	f	\N	262	5	24
Belper	of Belper in the County of Derby	\N	\N	\N	301	2	8	\N	f	\N	263	5	3
Talbot de Malahide	in the County of Dublin	1973-04-14	4	\N	302	3	8	\N	f	\N	264	5	21
Cowley	\N	\N	\N	\N	303	7	6	\N	f	\N	265	5	4
Eversley	of Heckfield in the County of Southampton	1888-12-28	1	\N	304	2	12	\N	f	\N	266	5	6
Ebury	of Ebury Manor in the County of Middlesex	\N	\N	6th L succeeded 1 Oct 1999 as 8th E of Wilton	305	2	8	\N	f	\N	267	5	6
Macaulay	of Rothley in the County of Leicester	1859-12-28	1	\N	306	2	8	\N	f	\N	268	5	14
Chelmsford	of Chelmsford in the County of Essex	\N	\N	3rd L cr V Chelmsford 1921	309	2	8	\N	f	\N	269	5	4
Strathspey	of Strathspey in the Counties of Inverness and Moray	1884-03-31	2	5th L died 27 Jan 1992	311	4	8	\N	f	\N	271	5	20
Clyde	of Clydesdale in Scotland	1863-08-14	1	\N	312	2	8	\N	f	\N	272	5	4
Kingsdown	of Kingsdown in the County of Kent	1867-10-07	1	\N	313	2	8	\N	f	\N	273	5	12
Leconfield	of Leconfield in the East Riding of the County of York	\N	\N	6th L (succ 1967) had been cr L Egremont 1963	314	2	8	\N	f	\N	274	5	13
Egerton	of Tatton in the County Palatine of Chester	1958-01-30	4	2nd L cr E Egerton 1897 (ext on his death 1909)	315	2	8	\N	f	\N	275	5	6
Hardinge	of Lahore and of King's Newton in the County of Derby	\N	\N	\N	274	2	12	\N	f	\N	277	5	9
Lyveden	of Lyveden in the County of Northampton	\N	\N	\N	320	2	8	\N	f	\N	278	5	13
Llanover	of Llanover and Abercarn in the County of Monmouth	1867-04-27	1	1	321	2	8	\N	f	\N	279	5	13
Taunton	of Taunton in the County of Somerset	1869-07-13	1	\N	322	2	8	\N	f	\N	280	5	21
Herbert	of Lea in the County of Wilts	\N	\N	2nd L succ 25 Apr 1862 as 13th E of Pembroke & 10th E of Montgomery	326	2	8	\N	f	\N	281	5	9
Westbury	of Westbury in the County of Wilts	\N	\N	\N	327	2	8	\N	f	\N	282	5	24
Russell	of Kingston Russell in the County of Dorset	\N	\N	& V Amberley	328	2	6	\N	f	\N	283	5	19
Fitzhardinge	of the City and County of the City of Bristol	1916-12-05	3	\N	329	2	8	\N	f	\N	284	5	7
Dublin	\N	1901-01-22	1	merged in Crown 22 January 1901	284	8	6	\N	t	\N	285	5	5
Winton	\N	\N	\N	was also E of Winton (S) & 2nd L Ardrossan	319	8	6	\N	t	\N	287	5	24
Beaconsfield	of Beaconsfield in the County of Buckingham	1872-12-15	1	\N	361	2	12	\N	f	\N	325	5	3
Saint Maur	of Berry Pomeroy in the County of Devon	1885-11-28	1	granted so son (who dvp) might be summoned as L Seymour	331	8	6	\N	f	\N	289	5	20
Buckhurst	of Buckhurst in the County of Sussex	\N	\N	SR to younger branches of family; 2nd L succ 1873 as 7th E De La Warr	334	2	8	\N	f	3	326	5	3
Annaly	of Annaly and Rathcline in the County of Longford	\N	\N	5th L died 30 Sep 1990	332	2	8	\N	f	\N	290	5	2
Dartrey	of Dartrey in the County of Monaghan	1933-02-09	3	also 1st L Dartrey (cr 1847)	344	7	6	\N	t	\N	323	5	5
Houghton	of Great Houghton in the West Riding of the County of York	1945-06-20	2	2nd L cr E of Crewe 17 July 1895	333	2	8	\N	f	\N	291	5	9
Romilly	of Barry in the County of Glamorgan	1983-06-29	4	\N	335	2	8	\N	f	\N	292	5	19
Northbrook	of Stratton in the County of Southampton	\N	\N	2nd L cr E of Northbrook 1876, ext(2) 1929; 5th L died 4 Dec 1990	336	2	8	\N	f	\N	293	5	15
Halifax	of Monk Bretton in the West Riding of the County of York	\N	\N	3rd V cr E of Halifax 1944	337	2	12	\N	f	\N	294	5	9
Barrogill	of Barrogill Castle in the County of Caithness	1889-05-25	2	\N	338	4	8	\N	f	\N	295	5	3
Clermont	of Clermont Park in the County of Louth	1887-07-29	1	\N	339	3	8	\N	f	\N	296	5	4
Meredyth	of Dollardstown in the County of Meath	1929-01-08	2	\N	340	3	8	\N	f	\N	297	5	14
Kenry	of Kenry in the County of Limerick	1926-06-14	2	\N	343	3	8	\N	f	\N	298	5	12
Monck	of Ballytrammon in the County of Wexford	\N	\N	\N	345	3	8	\N	f	\N	299	5	14
Hartismere	of Hartismere in the County of Suffolk	\N	\N	\N	346	3	8	\N	f	\N	300	5	9
Lytton	of Knebworth in the County of Hertford	\N	\N	2nd L cr E of Lytton 1880	347	2	8	\N	f	\N	301	5	13
Hylton	of Hylton in the County Palatine of Durham and of Petersfield in the County of Southampton	\N	\N	\N	348	2	8	\N	f	\N	302	5	9
Strathnairn	of Strathnairn in the County of Nairn and of Jhansi in the East Indies	1885-10-16	1	\N	349	2	8	\N	f	\N	303	5	20
Penrhyn	of Llandegai in the County of Carnarvon	\N	\N	\N	350	2	8	\N	f	\N	304	5	17
Colonsay	of Colonsay and Oronsay in the County of Argyll	1874-01-31	1	\N	352	2	8	\N	f	\N	305	5	4
Cairns	of Garmoyle in the County of Antrim	\N	\N	cr E Cairns 1878	353	2	8	\N	f	\N	306	5	4
Kesteven	of Casewick in the County of Lincoln	1915-11-05	3	\N	354	2	8	\N	f	\N	307	5	12
Ormathwaite	of Ormathwaite in the County of Cumberland	1984-03-08	6	\N	355	2	8	\N	f	\N	308	5	16
Fitzwalter	of Woodham Walter in the County of Essex	1875-12-06	1	\N	356	2	8	\N	f	\N	309	5	7
O'Neill	of Shanes Castle in the County of Antrim	\N	\N	\N	357	2	8	\N	f	\N	310	5	16
Canning	\N	1862-06-17	1	\N	317	7	6	\N	f	\N	311	5	4
Gormanston	of Whitewood in the County of Meath	\N	\N	\N	362	3	8	\N	f	\N	313	5	8
Hatherley	of Down Hatherley in the County of Gloucester	1881-07-10	1	\N	363	2	8	\N	f	\N	314	5	9
Penzance	of Penzance in the County of Cornwall	1899-12-09	1	\N	365	2	8	\N	f	\N	315	5	17
Dunning	of Dunning and Pitcairns in the County of Perth	\N	\N	\N	366	4	8	\N	f	\N	316	5	5
Howard of Glossop	in the County of Derby	\N	\N	title passed 1972 to L Beaumont, who succ 1975 as D of Norfolk	369	2	8	\N	f	\N	318	5	9
Castletown	of Upper Ossory in the Queen's County	1937-05-29	2	\N	370	2	8	\N	f	\N	319	5	4
Acton	of Aldenham in the County of Salop	\N	\N	?th L died 23 Jan 1989	371	2	8	\N	f	\N	320	5	2
Wolverton	of Wolverton in the County of Buckingham	\N	\N	\N	373	2	8	\N	f	\N	321	5	24
Edinburgh	\N	1900-07-30	1	\N	341	2	4	\N	t	\N	322	5	6
Kimberley	of Kimberley in the County of Norfolk	\N	\N	\N	342	7	6	\N	t	\N	324	5	12
Abergavenny	in the County of Monmouth	\N	\N	\N	414	7	9	\N	t	\N	362	5	2
Ripon	in the County of York	1923-09-22	2	\N	381	7	9	\N	t	\N	363	5	19
Burdett-Coutts	of Highgate and Brookfield in the County of Middlesex	1906-12-30	1	\N	380	2	8	\N	f	\N	364	5	3
Harlech	of Harlech in the County of Merioneth	\N	\N	SR to brother	415	2	8	\N	f	1	365	5	9
Greville	of Clonyn in the County of Westmeath	1987-12-09	4	\N	374	2	8	\N	f	\N	327	5	8
Kildare	of Kildare in the County of Kildare	\N	\N	succ 1874 as 4th D of Leinster (I) & 4th V Leinster	375	2	8	\N	f	\N	328	5	12
Westminster	\N	\N	\N	\N	399	7	4	\N	t	\N	359	5	24
O'Hagan	of Tullahogue in the County of Tyrone	\N	\N	\N	376	2	8	\N	f	\N	329	5	16
Lisgar	of Lisgar and Bailieborough in the County of Cavan	1876-10-06	1	\N	377	2	8	\N	f	\N	330	5	13
Dalling and Bulwer	of Dalling in the County of Norfolk	1872-05-23	1	\N	378	2	8	\N	f	\N	331	5	5
Sandhurst	of Sandhurst in the County of Berks	\N	\N	2nd L cr V Sandhurst 1917, ext(1) 1921	379	2	8	\N	f	\N	332	5	20
Blachford	of Wisdome in the County of Devon	1889-11-21	1	\N	383	2	8	\N	f	\N	334	5	3
Ossington	of Ossington in the County of Nottingham	1873-03-07	1	\N	385	2	12	\N	f	\N	335	5	16
Ettrick	of Ettrick in the County of Selkirk	\N	\N	\N	386	4	8	\N	f	\N	336	5	6
Hanmer	of Hanmer and of Flint (both in the County of Flint)	1881-03-08	1	\N	387	2	8	\N	f	\N	337	5	9
Selborne	of Selborne in the County of Southampton	\N	\N	cr E of Selborne 1882	388	2	8	\N	f	\N	338	5	20
Breadalbane	of Kenmore in the County of Perth	1922-10-19	1	cr M of Breadalbane 1885	389	4	8	\N	f	\N	339	5	3
Portman	of Bryanston in the County of Dorset	\N	\N	\N	390	7	12	\N	f	\N	340	5	17
Waveney	of South Elmham in the County of Suffolk	1886-02-05	1	\N	392	2	8	\N	f	\N	342	5	24
Marjoribanks	of Ladykirk in the County of Berwick	1873-06-19	1	\N	393	2	8	\N	f	\N	343	5	14
Aberdare	of Duffryn in the County of Glamorgan	\N	\N	\N	394	2	8	\N	f	\N	344	5	2
Lanerton	of Lanerton in the County of Cumberland	1880-10-08	1	\N	395	2	8	\N	f	\N	345	5	13
Moncreiff	of Tulliebole in the County of Kinross	\N	\N	\N	396	2	8	\N	f	\N	346	5	14
Coleridge	of Ottery St Mary in the County of Devon	\N	\N	\N	397	2	8	\N	f	\N	347	5	4
Emly	of Jervoe in the County of Limerick	1932-11-24	2	\N	398	2	8	\N	f	\N	348	5	6
Sydney	of Scadbury in the County of Kent	1890-02-14	1	\N	400	7	6	\N	f	\N	349	5	20
Napier of Magdâla	in Abyssinia and of Caryngton in the County Palatine of Chester	\N	\N	\N	359	2	8	\N	f	\N	350	5	15
Cardwell	of Ellerbeck in the County Palatine of Lancaster	1886-02-15	1	\N	404	2	12	\N	f	\N	351	5	4
Hampton	of Hampton Lovett and of Westwood in the County of Worcester	\N	\N	\N	405	2	8	\N	f	\N	352	5	9
Winmarleigh	of Winmarleigh in the County Palatine of Lancaster	1892-07-11	1	\N	406	2	8	\N	f	\N	353	5	24
Douglas	of Douglas in the County of Lanark	\N	\N	4th L disclaimed 1963 & died 9 Oct 1995	409	4	8	\N	f	\N	354	5	5
Ramsay	of Glenmark in the County of Forfar	\N	\N	\N	410	4	8	\N	f	\N	355	5	19
Grey de Radcliffe	in the County Palatine of Lancaster	1885-01-18	1	succ 1882 as 3rd E of Wilton	411	2	8	\N	f	\N	356	5	8
Fermanagh	of Lisnaskea in the County of Fermanagh	\N	\N	\N	413	3	8	\N	f	\N	357	5	7
Gordon	of Gordon Castle in Scotland	\N	\N	\N	412	8	4	\N	t	\N	358	5	8
Feversham	of Ryedale in the North Riding of the County of York	1963-09-04	3	\N	360	7	6	\N	t	\N	361	5	7
Selborne	in the County of Southampton	\N	\N	\N	459	7	6	\N	t	\N	401	5	20
Sackville	of Knole in the County of Kent	\N	\N	SR to brothers	422	2	8	\N	f	1	402	5	20
Alington	of Crichel in the County of Dorset	1940-09-17	3	\N	417	2	8	\N	f	\N	366	5	2
Shute	of Beckett in the County of Berks	1990-04-06	5	\N	430	3	8	\N	f	1	403	5	20
Tollemache	of Helmingham Hall in the County of Suffolk	\N	\N	\N	418	2	8	\N	f	\N	367	5	21
Gerard	of Bryn in the County Palatine of Lancaster	\N	\N	4th L died 11 July 1992	419	2	8	\N	f	\N	368	5	8
Northbrook	in the County of Southampton	1929-04-12	2	\N	420	7	6	\N	t	\N	399	5	15
Gordon of Drumearn	in the County of Stirling	1879-08-21	1	\N	424	1	8	\N	f	\N	369	5	8
Airey	of Killingworth in the County of Northumberland	1881-09-13	1	\N	425	2	8	\N	f	\N	370	5	2
Norton	of Norton-on-the-Moors in the County of Stafford	\N	\N	7th L died 24 Sep 1993	427	2	8	\N	f	\N	371	5	15
Cranbrook	of Hemsted in the County of Kent	\N	\N	cr E of Cranbrook 1892	428	2	12	\N	f	\N	372	5	4
Cairns	\N	\N	\N	\N	429	7	6	\N	f	\N	373	5	4
Watson	of Thankerton in the County of Lanark	1899-09-14	1	vice L Gordon of Drumearn deceased	433	1	8	\N	f	\N	374	5	24
Haldon	of Haldon in the County of Devon	1939-01-11	5	\N	434	2	8	\N	f	\N	375	5	9
Wimborne	of Canford Magna in the County of Dorset	\N	\N	2nd L cr V Wimborne 1918	435	2	8	\N	f	\N	376	5	24
Ardilaun	of Ashford in the County of Galway	1915-01-20	1	\N	436	2	8	\N	f	\N	377	5	2
Lamington	of Lamington in the County of Lanark	1951-09-20	3	\N	438	2	8	\N	f	\N	378	5	13
Sondes	of Lees Court in the County of Kent	1996-12-02	5	\N	439	7	6	\N	f	\N	379	5	20
Donington	of Donington Park in the County of Leicester	1927-05-31	3	\N	440	2	8	\N	f	\N	380	5	5
Trevor	of Brynkinalt in the County of Denbigh	\N	\N	4th L died 1 Jan 1997	441	2	8	\N	f	\N	381	5	21
Rowton	of Rowton Castle in the County of Salop	1903-11-09	1	\N	442	2	8	\N	f	\N	382	5	19
Sherbrooke	of Sherbrooke in the County of Surrey	1892-07-27	1	\N	443	2	12	\N	f	\N	383	5	20
Cottesloe	of Swanbourne and of Hardwick in the County of Buckingham	\N	\N	4th L died 21 April 1994	402	2	8	\N	f	\N	384	5	4
Hammond	of Kirkella in the town and County of the town of Kingston upon Hull	1890-04-29	1	\N	403	2	8	\N	f	\N	385	5	9
Ampthill	of Ampthill in the County of Bedford	\N	\N	\N	446	2	8	\N	f	\N	386	5	2
Tweeddale	of Yester in the County of Haddington	\N	\N	\N	448	4	8	\N	f	\N	387	5	21
Reay	of Durness in the County of Sutherland	1921-08-01	1	\N	450	4	8	\N	f	\N	389	5	19
Derwent	of Hackness in the North Riding of the County of York	\N	\N	\N	451	2	8	\N	f	\N	390	5	5
Hothfield	of Hothfield in the County of Kent	\N	\N	5th L died 5 Feb 1991	452	2	8	\N	f	\N	391	5	9
Tweedmouth	of Edington in the County of Berwick	1935-04-23	3	\N	453	2	8	\N	f	\N	392	5	21
Bramwell	of Hever in the County of Kent	1892-05-09	1	\N	455	2	8	\N	f	\N	393	5	3
FitzGerald	of Kilmarnock in the County of Dublin	1889-10-16	1	\N	456	1	8	\N	f	\N	394	5	7
Alcester	of Alcester in the County of Warwick	1895-03-30	1	\N	457	2	8	\N	f	\N	395	5	2
Wolseley	of Cairo and of Wolseley in the County of Stafford	1913-03-25	1	cr V Wolseley (SR) 1885	458	2	8	\N	f	\N	396	5	24
Tennyson	of Aldworth in the County of Sussex and of Freshwater in the Isle of Wight	\N	\N	4th L died 19 Oct 1991	460	2	8	\N	f	\N	397	5	21
Lytton	in the County of Derby	\N	\N	\N	432	7	6	\N	t	\N	398	5	13
Redesdale	in the County of Northumberland	1886-05-02	1	\N	426	7	6	\N	t	\N	400	5	19
Deramore	of Belvoir in the County of Down	2006-08-20	6	SR to brother	484	2	8	\N	f	1	442	5	5
Hampden	of Glynde in the County of Sussex	\N	\N	succ 1890 as 23rd L Dacre; titles separated 17 Oct 1965	461	2	12	\N	f	\N	405	5	9
Breadalbane	\N	1922-10-19	1	\N	479	7	9	\N	t	\N	440	5	3
Monk Bretton	of Conyboro and of Hurstpierpoint in the County of Sussex	\N	\N	\N	463	2	8	\N	f	\N	406	5	14
Northbourne	of Betteshanger in the County of Kent and of Jarrow Grange in the County Palatine of Durham	\N	\N	\N	464	2	8	\N	f	\N	407	5	15
Sudley	of Castle Gore in the County of Mayo	\N	\N	\N	465	3	8	\N	f	\N	408	5	20
de Vesci	of Abbey Leix in the Queen's Co	1903-07-06	1	\N	466	3	8	\N	f	\N	409	5	5
Herries	of Carlaverock Castle in the County of Dumfries and of Everingham in the East Riding of the County of York	1908-10-05	1	\N	467	4	8	\N	f	\N	410	5	9
Halsbury	of Halsbury in the County of Devon	2010-12-31	4	cr E of Halsbury 1898	468	2	8	\N	f	\N	411	5	9
Powerscourt	of Powerscourt in the County of Wicklow	\N	\N	\N	469	3	8	\N	f	\N	412	5	17
Northington	of Watford in the County of Northampton	\N	\N	\N	470	3	8	\N	f	\N	413	5	15
Rothschild	of Tring in the County of Hertford	\N	\N	3rd L died 20 March 1990	471	2	8	\N	f	\N	414	5	19
Revelstoke	of Membland in the County of Devon	\N	\N	4th L died 18 July 1994	472	2	8	\N	f	\N	415	5	19
Monkswell	of Monkswell in the County of Devon	\N	\N	4th L disclaimed 1964 & died 27 Jly 1984	473	2	8	\N	f	\N	416	5	14
Hobhouse	of Hadspen in the County of Somerset	1904-12-06	1	\N	474	2	8	\N	f	\N	417	5	9
Lingen	of Lingen in the County of Hereford	1905-07-22	1	\N	476	2	8	\N	f	\N	418	5	13
Ashbourne	of Ashbourne in the County of Meath	\N	\N	\N	477	2	8	\N	f	\N	419	5	2
Saint Oswald	of Nostell in the West Riding of the County of York	\N	\N	\N	478	2	8	\N	f	\N	420	5	20
Wantage	of Lockinge in the County of Berks	1901-06-10	1	\N	481	2	8	\N	f	\N	421	5	24
Esher	of Esher in the County of Surrey	\N	\N	cr V Esher 1897	482	2	8	\N	f	\N	422	5	6
Montagu of Beaulieu	in the County of Southampton	\N	\N	\N	485	2	8	\N	f	\N	423	5	14
Mount-Temple	of Mount Temple in the County of Sligo	1888-10-17	1	\N	444	2	8	\N	f	\N	424	5	14
Brabourne	of Brabourne in the County of Kent	\N	\N	\N	445	2	8	\N	f	\N	425	5	3
Hillingdon	of Hillingdon in the County of Middlesex	1982-09-01	5	\N	489	2	8	\N	f	\N	426	5	9
Hindlip	of Hindlip in the County of Worcester and of Alsop-en-le-Dale in the County of Derby	\N	\N	\N	490	2	8	\N	f	\N	427	5	9
Stalbridge	of Stalbridge in the County of Dorset	1949-12-24	2	\N	492	2	8	\N	f	\N	428	5	20
Kensington	of Kensington in the County of Middlesex	\N	\N	\N	493	3	8	\N	f	\N	429	5	12
Farnborough	of Farnborough in the County of Southampton	1886-05-17	1	\N	494	2	8	\N	f	\N	430	5	7
Oxenbridge	of Burton in the County of Lincoln	1898-04-16	1	\N	495	7	12	\N	f	\N	431	5	16
Hamilton of Dalzell	in the County of Lanark	\N	\N	3rd L died 31 Jan 1990	497	2	8	\N	f	\N	433	5	9
Brassey	of Bulkeley in the County Palatine of Chester	1919-11-12	2	cr E Brassey 1911	498	2	8	\N	f	\N	434	5	3
Thring	of Alderhurst in the County of Surrey	1907-02-04	1	\N	499	2	8	\N	f	\N	435	5	21
Cross	of Broughton-in-Furness in the County Palatine of Lancaster	2004-12-05	3	\N	500	2	12	\N	f	\N	436	5	4
Stanley of Preston	in the County Palatine of Lancaster	\N	\N	succ 1893 as 16th E of Derby	501	2	8	\N	f	\N	437	5	20
de Montalt	of Dundrum in the County of Tipperary	1905-01-09	1	\N	502	3	6	\N	f	\N	438	5	5
Iddesleigh	in the County of Devon	\N	\N	\N	475	2	6	\N	t	\N	439	5	10
Cranbrook	in the County of Kent	\N	\N	\N	538	7	6	\N	t	\N	473	5	4
Londesborough	in the County of York	1937-04-17	4	\N	505	7	6	\N	t	\N	474	5	13
Dufferin and Ava	in the County of Down and in Burma	1988-05-29	5	\N	517	7	9	\N	t	\N	475	5	5
Zetland	\N	\N	\N	\N	537	7	9	\N	t	\N	476	5	27
Macdonald of Earnscliffe	in the Province of Ontario and Dominion of Canada	1920-09-05	1	\N	527	2	8	\N	f	\N	477	5	14
Savile	of Rufford in the County of Nottingham	\N	\N	SR to father's heirs	516	2	8	\N	f	1	478	5	20
Macnaghten	of Runkerry in the County of Antrim	1913-02-17	1	vice L Blackburn resigned	503	1	8	\N	f	\N	443	5	14
Blythswood	of Blythswood in the County of Renfrew	1940-09-14	7	SR to 5 brothers	542	2	8	\N	f	1	479	5	3
Amherst of Hackney	in the County of London	\N	\N	SR to eldest dau	544	2	8	\N	f	2	480	5	2
Hambleden	of Hambleden in the County of Buckingham	\N	\N	SR to heirs male by her late husband	528	2	12	\N	f	3	481	5	9
Connemara	of Connemara in the County of Galway	1902-09-03	1	\N	504	2	8	\N	f	\N	444	5	4
Fife	in Scotland	1912-01-29	1	further patent (SR) 1900	518	7	4	\N	t	\N	471	5	7
Monckton	of Serlby in the County of Nottingham	1971-01-01	3	\N	507	3	8	\N	f	\N	446	5	14
Saint Levan	of Saint Michael's Mount in the County of Cornwall	\N	\N	\N	508	2	8	\N	f	\N	447	5	20
Magheramorne	of Magheramorne in the County of Antrim	1957-04-21	4	\N	509	2	8	\N	f	\N	448	5	14
Armstrong	of Cragside in the County of Northumberland	1900-12-27	1	\N	510	2	8	\N	f	\N	449	5	2
Basing	of Basing Byflete and of Hoddington both in the County of Southampton	\N	\N	\N	511	2	8	\N	f	\N	450	5	3
De Ramsey	of Ramsey Abbey in the County of Huntingdon	\N	\N	3rd L died 31 March 1993	512	2	8	\N	f	\N	451	5	5
Cheylesmore	of Cheylesmore in the City of Coventry and County of Warwick	1974-04-21	4	\N	513	2	8	\N	f	\N	452	5	4
Addington	of Addington in the County of Buckingham	\N	\N	\N	514	2	8	\N	f	\N	453	5	2
Knutsford	of Knutsford in the County Palatine of Chester	\N	\N	cr V Knutsford 1895	515	2	8	\N	f	\N	454	5	12
Field	of Bakeham in the County of Surrey	1907-01-23	1	\N	520	2	8	\N	f	\N	455	5	7
Sandford	of Sandford in the County of Salop	1893-12-31	1	\N	522	2	8	\N	f	\N	456	5	20
Hannen	of Burdock in the County of Sussex	1894-03-29	1	\N	524	1	8	\N	f	\N	457	5	9
Masham	of Swinton in the County of York	1924-01-04	3	\N	526	2	8	\N	f	\N	458	5	14
Herschell	of the City of Durham	2008-10-26	3	\N	488	2	8	\N	f	\N	460	5	9
Rookwood	of Rookwood Hall and Down Hall both in the County of Essex	1902-01-15	1	\N	534	2	8	\N	f	\N	461	5	19
Cromer	of Cromer in the County of Norfolk	\N	\N	cr V Cromer 1899, E of Cromer 1901	535	2	8	\N	f	\N	462	5	4
Shand	of Woodhouse in the County of Dumfries	1904-03-06	1	\N	536	2	8	\N	f	\N	463	5	20
Ashcombe	of Dorking in the County of Surrey and of Bodiam Castle in the County of Sussex	\N	\N	\N	539	2	8	\N	f	\N	464	5	2
Knightley	of Fawsley in the County of Northampton	1895-12-19	1	\N	541	2	8	\N	f	\N	465	5	12
Crawshaw	of Crawshaw in the County Palatine of Lancaster and of Whatton in the County of Leicester	\N	\N	\N	543	2	8	\N	f	\N	466	5	4
Newton	of Newton in Makerfield in the County Palatine of Lancaster	\N	\N	4th L died 16 June 1992	545	2	8	\N	f	\N	467	5	15
Dunleath	of Ballywalter in the County of Down	\N	\N	4th L died 9 Jan 1993	546	2	8	\N	f	\N	468	5	5
Llangattock	of the Hendre in the County of Monmouth	1916-10-31	2	\N	547	2	8	\N	f	\N	469	5	13
Clarence and Avondale	\N	1892-01-14	1	\N	521	2	4	\N	t	\N	470	5	4
York	\N	1910-05-06	1	merged in Crown 6 May 1910	533	2	4	\N	t	\N	472	5	26
Battersea	of Battersea in the County of London and Overstrand in the County of Norfolk	1907-11-27	1	\N	549	2	8	\N	f	\N	483	5	3
Swansea	of Singleton in the County of Glamorgan	\N	\N	\N	550	2	8	\N	f	\N	484	5	20
Farrer	of Abinger in the County of Surrey	1964-12-16	5	\N	551	2	8	\N	f	\N	485	5	7
Overtoun	of Overtoun in the County of Dumbarton	1908-02-15	1	\N	552	2	8	\N	f	\N	486	5	16
Kelhead	of Kelhead in the County of Dumfries	1894-10-19	1	\N	554	2	8	\N	f	\N	487	5	12
Stanmore	of Great Stanmore in the County of Middlesex	1957-04-13	2	\N	555	2	8	\N	f	\N	488	5	20
Bowen	of Colwood in the County of Sussex	1894-04-10	1	vice L Hannen resigned	556	1	8	\N	f	\N	489	5	3
Rendel	of Hatchlands in the County of Surrey	1913-06-04	1	\N	557	2	8	\N	f	\N	490	5	19
Welby	of Allington in the County of Lincoln	1915-10-29	1	\N	558	2	8	\N	f	\N	491	5	24
Russell of Killowen	in the County of Down	1900-08-10	1	vice L Bowen deceased	559	1	8	\N	f	\N	492	5	19
Davey	of Fernhurst in the County of Sussex	1907-02-20	1	vice L Russell of Killowen resigned	560	1	8	\N	f	\N	493	5	5
Peel	of Sandy in the County of Bedford	\N	\N	2nd V cr E Peel 1929	561	2	12	\N	f	\N	494	5	17
Carrington	\N	1928-06-13	1	cr M of Lincolnshire 1912	562	7	6	\N	f	\N	495	5	4
Loch	of Drylaw in the County of Midlothian	1991-06-24	4	\N	564	2	8	\N	f	\N	496	5	13
Wandsworth	of Wandsworth in the County of London	1912-02-10	1	\N	565	2	8	\N	f	\N	497	5	24
Knutsford	of Knutsford in the County Palatine of Chester	\N	\N	\N	567	7	12	\N	f	\N	499	5	12
Burghclere	of Walden in the County of Essex	1921-05-06	1	\N	568	2	8	\N	f	\N	500	5	3
Llandaff	of Hereford in the County of Hereford	1913-04-03	1	\N	569	2	12	\N	f	\N	501	5	13
James of Hereford	in the County of Hereford	1911-08-18	1	\N	570	2	8	\N	f	\N	502	5	11
Rathmore	of Shanganagh in the County of Dublin	1919-08-22	1	\N	571	2	8	\N	f	\N	503	5	19
Pirbright	of Pirbright in the County of Surrey	1903-01-09	1	\N	572	2	8	\N	f	\N	504	5	17
Glenesk	of Glenesk in the County of Midlothian	1908-11-24	1	\N	573	2	8	\N	f	\N	505	5	8
Kelvin	of Largs in the County of Ayr	1907-12-17	1	\N	531	2	8	\N	f	\N	506	5	12
Roos	of Belvoir in the County of Leicester	\N	\N	\N	578	8	8	\N	f	\N	507	5	19
Rosmead	of Rosmead in the County of Westmeath and of Tafelberg in South Africa	1933-05-26	2	\N	579	2	8	\N	f	\N	508	5	19
Kinnear	of Spurness in the County of Orkney	1917-12-20	1	\N	580	2	8	\N	f	\N	509	5	12
Lister	of Lyme Regis in the County of Dorset	1912-02-10	1	\N	581	2	8	\N	f	\N	510	5	13
Egerton	of Tatton in the County Palatine of Chester	1909-03-16	1	\N	582	7	6	\N	f	\N	511	5	6
Fairlie	of Fairlie in the County of Ayr	\N	\N	\N	583	4	8	\N	f	\N	512	5	7
Dawnay	of Danby in the North Riding of the County of York	\N	\N	\N	584	3	8	\N	f	\N	513	5	5
Ludlow	of Heywood in the County of Wilts	1922-11-08	2	\N	585	2	8	\N	f	\N	514	5	13
HolmPatrick	of HolmPatrick in the County of Dublin	\N	\N	3rd L died 15 Feb 1991	586	2	8	\N	f	\N	515	5	9
Inverclyde	of Castle Wemyss in the County of Renfrew	1957-06-17	4	\N	587	2	8	\N	f	\N	516	5	10
Esher	of Esher in the County of Surrey	\N	\N	\N	589	7	12	\N	f	\N	517	5	6
Muncaster	of Muncaster in the County of Cumberland	1917-03-30	1	\N	594	3	8	\N	f	\N	519	5	14
Haliburton	of Windsor in the Province of Nova Scotia and Dominion of Canada	1907-04-21	1	\N	595	2	8	\N	f	\N	520	5	9
Halsbury	in the County of Devon	2010-12-31	4	\N	591	7	6	\N	t	\N	521	5	9
Playfair	of Saint Andrews in the County of Fife	1939-12-26	2	\N	548	2	8	\N	f	\N	482	5	17
Kitchener of Khartoum	and of Aspall in the County of Suffolk	1916-06-05	1	cr  V Kitchener of Khartoum (SR) 1902, E Kitchener (SR) 1914	596	2	8	\N	f	\N	523	5	12
Dorchester	of Dorchester in the County of Oxford	1963-01-20	2	\N	602	2	8	\N	f	\N	559	5	5
Cromer	of Cromer in the County of Norfolk	\N	\N	cr E of Cromer 1901	597	7	12	\N	f	\N	524	5	4
Currie	of Hawley in the County of Southampton	1906-05-12	1	\N	598	2	8	\N	f	\N	525	5	4
Glanusk	of Glanusk Park in the County of Brecknock	\N	\N	\N	599	2	8	\N	f	\N	526	5	8
Brampton	of Brampton in the County of Huntingdon	1907-10-06	1	\N	600	2	8	\N	f	\N	527	5	3
Cranworth	of Letton and Cranworth in the County of Norfolk	\N	\N	\N	601	2	8	\N	f	\N	528	5	4
Pauncefote	of Preston in the County of Gloucester	1902-05-24	1	\N	603	2	8	\N	f	\N	529	5	17
Robertson	of Forteviot in the County of Perth	1909-02-02	1	vice L Watson deceased	605	1	8	\N	f	\N	530	5	19
Northcote	of the City and County of the City of Exeter	1911-09-29	1	\N	606	2	8	\N	f	\N	531	5	15
Avebury	of Avebury in the County of Wilts	\N	\N	\N	607	2	8	\N	f	\N	532	5	2
Lindley	of East Carleton in the County of Norfolk	1921-12-09	1	vice L Morris resigned	608	1	8	\N	f	\N	533	5	13
Killanin	of Galway in the County of Galway	\N	\N	\N	609	8	8	\N	f	\N	534	5	12
O'Brien	of Kilfenora in the County of Clare	1914-09-07	1	\N	610	2	8	\N	f	\N	535	5	16
Goschen	of Hawkhurst in the County of Kent	\N	\N	\N	613	2	12	\N	f	\N	537	5	8
Ridley	\N	\N	\N	\N	614	2	12	\N	f	\N	538	5	19
Milner	of St James's in the County of London and of Capetwon in the Colony of the Cape of Good Hope	1925-05-13	1	cr V Milner 15 July 1902	616	2	8	\N	f	\N	539	5	14
Aldenham	of Aldenham in the County of Hertford	\N	\N	\N	575	2	8	\N	f	\N	540	5	2
Heneage	of Hainton in the County of Lincoln	1967-02-19	3	\N	576	2	8	\N	f	\N	541	5	9
Milner	of Saint James's in the County of London and of Cape Town in the Cape Colony	1925-05-13	1	\N	622	7	12	\N	f	\N	542	5	14
Kinross	of Glasclune in the County of Haddington	\N	\N	\N	623	2	8	\N	f	\N	543	5	12
Shuttleworth	of Gawthorpe in the County Palatine of Lancaster	\N	\N	\N	624	2	8	\N	f	\N	544	5	20
Allerton	of Chapel Allerton, Leeds, in the West Riding of the County of York	1991-07-01	3	\N	625	2	8	\N	f	\N	545	5	2
Barrymore	of Barrymore in the County of Cork	1925-02-22	1	\N	626	2	8	\N	f	\N	546	5	3
Grenfell	of Kilvey in the County of Glamorgan	\N	\N	\N	627	2	8	\N	f	\N	547	5	8
Knollys	of Caversham in the County of Oxford	\N	\N	cr V Knollys 1911	628	2	8	\N	f	\N	548	5	12
Biddulph	of Ledbury in the County of Hereford	\N	\N	?th L died 3 Nov 1988	632	2	8	\N	f	\N	550	5	3
Estcourt	of Estcourt in the parish of Shipton Moyne in the County of Gloucester and of Darrington in the West Riding of the County of York	1915-01-12	1	\N	633	2	8	\N	f	\N	551	5	6
Armstrong	of Bamburgh and Cragside in the County of Northumberland	1987-10-01	3	\N	634	2	8	\N	f	\N	552	5	2
St Helier	of St Helier in the Island of Jersey and of Arlington Manor in the County of Berks	1905-04-09	1	St. Helier	635	2	8	\N	f	\N	553	5	20
Dunedin	of Stenton in the County of Perth	1942-08-21	1	cr V Dunedin 1926; apptd L of A in O 1913	636	2	8	\N	f	\N	554	5	5
Selby	of the City of Carlisle	\N	\N	4th V died 10 Jan 1997	637	2	12	\N	f	\N	555	5	20
Iveagh	of Iveagh in the County of Down	\N	\N	cr E of Iveagh 1919	639	7	12	\N	f	\N	556	5	10
Plymouth	in the County of Devon	\N	\N	\N	638	7	6	\N	t	\N	557	5	17
Roberts	of Kandahar in Afghanistan and Pretoria in the Transvaal Colony, and of the City of Waterford	1955-02-21	3	SR to daus	615	7	6	\N	f	2	560	5	19
Holden	of Alston in the County of Cumberland	1951-07-06	3	\N	679	2	8	\N	f	\N	562	5	9
Althorp	of Great Brington in the County of Northampton	\N	\N	succ as 6th E Spencer 1910	641	2	12	\N	f	\N	563	5	2
Atkinson	of Glenwilliam in the County of Limerick	1932-03-13	1	vice L Lindley resigned	642	1	8	\N	f	\N	564	5	2
Sanderson	of Armthorpe in the County of York	1923-03-21	1	\N	643	2	8	\N	f	\N	565	5	20
Waleran	of Uffcalme in the County of Devon	1966-04-04	2	\N	646	2	8	\N	f	\N	567	5	24
Knaresborough	of Kirby Hall in the County of York	1929-03-03	1	\N	647	2	8	\N	f	\N	568	5	12
Tredegar	of Tredegar in the County of Monmouth	1913-03-11	1	same title to 3rd L Tredegar, 1926	649	7	12	\N	f	\N	570	5	21
Michelham	of Hellingly in the County of Sussex	1984-03-29	2	\N	650	2	8	\N	f	\N	571	5	14
Faber	of Butterwick in the County of Lincoln	1920-09-17	1	\N	651	2	8	\N	f	\N	572	5	7
Desborough	of Taplow in the County of Buckingham	1945-01-09	1	\N	652	2	8	\N	f	\N	573	5	5
St Aldwyn	of Coln St Aldwyn in the County of Gloucester	\N	\N	cr E St Aldwyn 1915	653	2	12	\N	f	\N	574	5	20
Loreburn	of Dumfries in the County of Dumfries	1923-11-30	1	cr E Loreburn 1911	654	2	8	\N	f	\N	575	5	13
Weardale	of Stanhope in the County of Durham	1923-03-01	1	\N	656	2	8	\N	f	\N	576	5	24
Haversham	of Bracknell in the County of Berks	1917-05-10	1	\N	657	2	8	\N	f	\N	577	5	9
Fitzmaurice	of Leigh in the County of Wilts	1935-06-21	1	\N	655	2	8	\N	f	\N	578	5	7
Churchill	of Rolleston in the County of Leicester	2017-10-18	3	\N	621	7	12	\N	f	\N	579	5	4
Winterstoke	of Blagdon in the County of Somerset	1911-01-29	1	\N	661	2	8	\N	f	\N	580	5	24
Courtney of Penwith	in the County of Cornwall	1918-05-11	1	\N	663	2	8	\N	f	\N	581	5	4
Eversley	of Old Ford in the County of London	1928-04-19	1	\N	664	2	8	\N	f	\N	582	5	6
Pirrie	of the City of Belfast	1924-06-06	1	cr V Pirrie 1921	665	2	8	\N	f	\N	583	5	17
Glantawe	of Swansea in the County of Glamorgan	1915-07-27	1	\N	666	2	8	\N	f	\N	584	5	8
Armitstead	of Castlehill in the City of Dundee	1915-12-07	1	\N	667	2	8	\N	f	\N	585	5	2
Collins	of Kensington in the County of London	1911-01-03	1	\N	669	1	8	\N	f	\N	587	5	4
Airedale	of Gledhow in the West Riding of the County of York	1996-03-19	4	\N	670	2	8	\N	f	\N	588	5	2
Swaythling	of Swaythling in the County of Southampton	\N	\N	\N	671	2	8	\N	f	\N	589	5	20
Blyth	of Blythwood in the County of Essex	\N	\N	\N	672	2	8	\N	f	\N	590	5	3
Peckover	of Wisbech in the County of Cambridge	1919-10-21	1	\N	673	2	8	\N	f	\N	591	5	17
Morley of Blackburn	in the County Palatine of Lancaster	1923-09-23	1	\N	674	2	8	\N	f	\N	592	5	14
Wolverhampton	of Wolverhampton in the County of Stafford	1943-03-09	2	\N	675	2	12	\N	f	\N	593	5	24
Lochee	of Gowrie in the County of Perth	1911-09-13	1	\N	676	2	8	\N	f	\N	594	5	13
MacDonnell	of Swinford in the County of Mayo	1925-06-09	1	\N	677	2	8	\N	f	\N	595	5	14
Marchamley	of Hawkstone in the County of Salop	\N	\N	3rd L died 26 May 1994	678	2	8	\N	f	\N	596	5	14
St Davids	of Roch Castle in the County of Pembroke	\N	\N	cr V St Davids 1918	680	2	8	\N	f	\N	597	5	20
Gorell	of Brampton in the County of Derby	\N	\N	\N	682	2	8	\N	f	\N	598	5	8
Desart	of Desart in the County of Kilkenny	1934-11-04	1	\N	684	3	8	\N	f	\N	599	5	5
Wales	\N	1910-05-06	1	merged in Crown 1910	618	7	11	\N	t	\N	600	5	24
Leith of Fyvie	of Fyvie in the County of Aberdeen	1925-11-14	1	\N	640	2	8	\N	f	\N	561	5	13
Fisher	of Kilverstone in the County of Norfolk	\N	\N	\N	685	2	8	\N	f	\N	601	5	7
Lincolnshire	\N	1928-06-13	1	3rd L Carrington	727	7	9	\N	t	\N	640	5	13
Kilbracken	of Killegar in the County of Leitrim	\N	\N	\N	686	2	8	\N	f	\N	602	5	12
Gladstone	of the County of Lanark	1930-03-06	1	\N	687	2	12	\N	f	\N	603	5	8
Ashby St Ledgers	of Ashby St Ledgers in the County of Northampton	\N	\N	succ as 2nd L Wimborne 1914; cr V 1918	688	2	8	\N	f	\N	604	5	2
Mersey	of Toxteth in the County Palatine of Lancaster	\N	\N	cr V Mersey 1916	689	2	8	\N	f	\N	605	5	14
Islington	of Islington in the County of London	1936-12-06	1	\N	690	2	8	\N	f	\N	606	5	10
Southwark	of Southwark in the County of London	1929-02-23	1	\N	692	2	8	\N	f	\N	607	5	20
Ilkeston	of Ilkeston in the County of Derby	1952-01-04	2	\N	693	2	8	\N	f	\N	608	5	10
Devonport	of Wittington in the County of Buckingham	\N	\N	cr V Devonport 1917	694	2	8	\N	f	\N	609	5	5
Cowdray	of Midhurst in the County of Sussex	\N	\N	cr V Cowdray 1917	695	2	8	\N	f	\N	610	5	4
Rotherham	of Broughton in the County Palatine of Lancaster	1950-01-24	2	\N	696	2	8	\N	f	\N	611	5	19
Hardinge of Penshurst	in the County of Kent	\N	\N	\N	699	2	8	\N	f	\N	613	5	9
de Villiers	of Wynberg in the Province of the Cape of Good Hope and Union of South Africa	\N	\N	de Villiers	700	2	8	\N	f	\N	614	5	5
Robson	of Jesmond in the County of Northumberland	1918-09-11	1	vice L Collins resigned	701	1	8	\N	f	\N	615	5	19
Haldane	of Cloan in the County of Perth	1928-08-19	1	\N	702	2	12	\N	f	\N	616	5	9
Glenconner	of Glen in the County of Peebles	\N	\N	\N	703	2	8	\N	f	\N	617	5	8
Joicey	of Chester-le-Street in the County of Durham	\N	\N	\N	659	2	8	\N	f	\N	618	5	11
Nunburnholme	of the city of Kingston upon Hull	\N	\N	\N	660	2	8	\N	f	\N	619	5	15
Pentland	of Lyth in the County of Caithness	1984-02-14	2	\N	681	2	8	\N	f	\N	620	5	17
Merthyr	of Senghenydd in the County of Glamorgan	\N	\N	\N	708	2	8	\N	f	\N	621	5	14
Rowallan	of Rowallan in the County of Ayr	\N	\N	3rd L died 24 June 1993	710	2	8	\N	f	\N	622	5	19
Ashton of Hyde	in the County of Chester	\N	\N	\N	711	2	8	\N	f	\N	623	5	2
Charnwood	of Castle Donington in the County of Leicester	1955-02-01	2	\N	712	2	8	\N	f	\N	624	5	4
Loreburn	\N	1923-11-30	1	\N	716	7	6	\N	f	\N	626	5	13
Knollys	of Caversham in the County of Oxford	\N	\N	\N	717	7	12	\N	f	\N	627	5	12
Brassey	\N	1919-11-12	2	\N	718	7	6	\N	f	\N	628	5	3
Chilston	of Boughton Malherbe in the County of Kent	\N	\N	\N	720	2	12	\N	f	\N	629	5	4
Emmott	of Oldham in the County Palatine of Lancaster	1926-12-13	1	\N	722	2	8	\N	f	\N	631	5	6
Strachie	of Sutton Court in the County of Somerset	1973-05-17	2	\N	723	2	8	\N	f	\N	632	5	20
Pontypridd	of Cardiff in the County of Glamorgan	1927-12-14	1	\N	725	2	8	\N	f	\N	633	5	17
Hollenden	of Leigh in the County of Kent	\N	\N	\N	726	2	8	\N	f	\N	634	5	9
Butler of Mount Juliet	in the County of Kilkenny	\N	\N	3rd L died 5 Oct 1992	728	3	8	\N	f	\N	635	5	3
Channing of Wellingborough	in the County of Northampton	1926-02-20	1	\N	729	2	8	\N	f	\N	636	5	4
Nicholson	of Roundhay in the County of York	1918-09-13	1	\N	730	2	8	\N	f	\N	637	5	15
Murray of Elibank	of Elibank in the County of Selkirk	1920-09-13	1	heir to V Elibank but d.v.p.	731	2	8	\N	f	\N	638	5	14
Crewe	\N	1945-06-20	1	\N	713	7	9	\N	t	\N	639	5	4
Wales	\N	1936-01-20	1	& E of Chester; cr D Windsor 1937	691	7	11	\N	t	\N	641	5	24
Rochdale	of Rochdale in the County Palatine of Lancaster	\N	\N	2nd L cr V Rochdale 1960	735	2	8	\N	f	\N	645	5	19
Parker of Waddington	of Waddington in the County of York	1918-07-12	1	vice L Macnaghten deceased	736	1	8	\N	f	\N	646	5	17
Sumner	of Ibstone in the County of Buckingham	1934-05-24	1	cr V Sumner 1927	737	1	8	\N	f	\N	647	5	20
Alverstone	of Alverstone in the County of Southampton	1915-12-15	1	never introduced	738	7	12	\N	f	\N	648	5	2
Reading	of Erleigh in the County of Berks	\N	\N	cr V Reading 1916 etc.	739	2	8	\N	f	\N	649	5	19
Strathclyde	of Sandyford in the County of Lanark	1928-10-02	1	\N	740	2	8	\N	f	\N	650	5	20
Parmoor	of Frieth in the County of Buckingham	\N	\N	\N	741	2	8	\N	f	\N	651	5	17
Rothermere	of Hemsted in the County of Kent	\N	\N	cr V Rothermere 1919	742	2	8	\N	f	\N	652	5	19
Bryce	of Dechmount in the County of Lanark	1922-01-22	1	\N	743	2	12	\N	f	\N	653	5	3
Buxton	of Newtimber in the County of Sussex	1934-10-15	1	cr E Buxton 1920	744	2	12	\N	f	\N	654	5	3
Cozens-Hardy	of Letheringsett in the County of Norfolk	1975-09-11	4	\N	745	2	8	\N	f	\N	655	5	4
D'Abernon	of Esher in the County of Surrey	1941-11-01	1	cr V D'Abernon 1926	746	2	8	\N	f	\N	656	5	5
Ranksborough	of Ranksborough in the County of Rutland	1921-02-28	1	\N	747	2	8	\N	f	\N	657	5	19
Lyell	of Kinnordy in the County of Forfar	2017-01-11	3	\N	748	2	8	\N	f	\N	658	5	13
Aberconway	of Bodnant in the County of Denbigh	\N	\N	\N	705	2	8	\N	f	\N	659	5	2
Carmichael	of Skirling in the County of Peebles	1926-01-16	1	\N	724	2	8	\N	f	\N	660	5	4
Stamfordham	of Stamfordham in the County of Northumberland	1931-03-31	1	\N	707	2	8	\N	f	\N	661	5	20
Wrenbury	of Old Castle in the County of Sussex	\N	\N	\N	752	2	8	\N	f	\N	662	5	24
Buckmaster	of Cheddington in the County of Buckingham	\N	\N	cr V Buckmaster 1933	754	2	8	\N	f	\N	663	5	3
Bertie of Thame	in the County of Oxford	1954-08-29	2	cr V Bertie of Thame 1918	755	2	8	\N	f	\N	664	5	3
Muir-Mackenzie	of Delvine in the County of Perth	1930-05-22	1	\N	756	2	8	\N	f	\N	665	5	14
Beresford	of Metemmeh and of Curraghmore in the County of Waterford	1919-09-06	1	\N	759	2	8	\N	f	\N	668	5	3
Faringdon	of Buscot Park in the County of Berks	\N	\N	\N	760	2	8	\N	f	\N	669	5	7
Shaughnessy	of the City of Montreal in the Dominion of Canada and of Ashford in the County of Limerick	\N	\N	\N	761	2	8	\N	f	\N	670	5	20
Astor	of Hever Castle in the County of Kent	\N	\N	cr V Astor 1917	762	2	8	\N	f	\N	671	5	2
Rathcreedan	of Bellehatch Park in the County of Oxford	\N	\N	2nd L died 15 May 1990	763	2	8	\N	f	\N	672	5	19
Rhondda	of Llanwern in the County of Monmouth	1918-07-03	1	cr V Rhondda (with SR) 1918	764	2	8	\N	f	\N	673	5	19
Chaplin	of Saint Oswald's, Blankney, in the County of Lincoln	1981-12-18	3	\N	765	2	12	\N	f	\N	674	5	4
Reading	of Erleigh in the County of Berks	\N	\N	cr E of Reading 1917, etc.	766	7	12	\N	f	\N	675	5	19
Somerleyton	of Somerleyton in the County of Suffolk	\N	\N	\N	767	2	8	\N	f	\N	676	5	20
Carnock	of Carnock in the County of Stirling	\N	\N	\N	768	2	8	\N	f	\N	677	5	4
Anslow	of Iver in the County of Buckingham	1933-08-20	1	\N	769	2	8	\N	f	\N	678	5	2
Glentanar	of Glen Tanar in the County of Aberdeen	1971-06-28	2	\N	770	2	8	\N	f	\N	679	5	8
Grey of Fallodon	in the County of Northumberland	1933-09-07	1	\N	772	2	12	\N	f	\N	680	5	8
Finlay	of Nairn in the County of Nairn	1945-06-30	2	cr V Finlay 1919	773	2	8	\N	f	\N	681	5	7
Moulton	of Bank in the County of Southampton	1921-03-09	1	\N	732	1	8	\N	f	\N	642	5	14
Sydenham of Combe	of Dulverton in the County of Devon	1933-02-07	1	\N	734	2	8	\N	f	\N	644	5	20
Rhondda	of Llanwern in the County of Monmouth	1958-07-20	2	SR to only daughter & her heirs male	809	7	12	\N	f	2	720	5	19
Cowdray	of Cowdray in the County of Sussex	\N	\N	\N	776	7	12	\N	f	\N	684	5	4
Beaverbrook	of Beaverbrook in the Province of New Brunswick in the Dominion of Canada and of Cherkley in the County of Surrey	\N	\N	\N	777	2	8	\N	f	\N	685	5	3
Harcourt	of Stanton Harcourt in the County of Oxford	1979-01-03	2	\N	778	2	12	\N	f	\N	686	5	9
Gainford	of Headlam in the County of Durham	\N	\N	\N	779	2	8	\N	f	\N	687	5	8
Forteviot	of Dupplin in the County of Perth	\N	\N	3rd L died 25 March 1993	780	2	8	\N	f	\N	688	5	7
Roe	of the Borough of Derby	1923-06-07	1	\N	781	2	8	\N	f	\N	689	5	19
Doverdale	of Westwood Park in the County of Worcester	1949-01-18	3	\N	782	2	8	\N	f	\N	690	5	5
Atholstan	of Huntingdon in the Province of Quebec in the Dominion of Canada and of the City of Edinburgh	1938-01-28	1	\N	783	2	8	\N	f	\N	691	5	2
Annesley	of Bletchington in the County of Oxford	1949-10-06	2	\N	784	3	8	\N	f	\N	692	5	2
Lambourne	of Lambourne in the County of Essex	1928-12-26	1	\N	785	2	8	\N	f	\N	693	5	13
Treowen	of Treowen and Llanarth in the County of Monmouth	1933-10-18	1	\N	786	2	8	\N	f	\N	694	5	21
Devonport	of Wittington in the County of Buckingham	\N	\N	\N	789	7	12	\N	f	\N	696	5	5
Colwyn	of Colwyn Bay in the County of Denbigh	\N	\N	\N	790	2	8	\N	f	\N	697	5	4
Astor	of Hever Castle in the County of Kent	\N	\N	\N	791	7	12	\N	f	\N	698	5	2
Cunliffe	of Headley in the County of Surrey	\N	\N	\N	750	2	8	\N	f	\N	699	5	4
St Aldwyn	of Coln St Aldwyn in the County of Gloucester	\N	\N	2nd E died 29 Jan 1992	751	7	6	\N	f	\N	700	5	20
Southborough	of Southborough in the County of Kent	1992-06-15	4	\N	797	2	8	\N	f	\N	701	5	20
Morris	of St John's in the Dominion of Newfoundland and of the City of Waterford	\N	\N	\N	801	2	8	\N	f	\N	702	5	14
Furness	of Grantley in the West Riding of the County of York	1995-05-01	2	\N	802	7	12	\N	f	\N	703	5	7
Cawley	of Prestwich in the County Palatine of Lancaster	\N	\N	\N	803	2	8	\N	f	\N	704	5	4
Armaghdale	of Armagh in the County of Armagh	1924-06-08	1	\N	804	2	8	\N	f	\N	705	5	2
Queenborough	of Queenborough in the County of Kent	1949-09-22	1	\N	805	2	8	\N	f	\N	706	5	18
Terrington	of Huddersfield in the County of York	\N	\N	\N	806	2	8	\N	f	\N	707	5	21
Wimborne	of Canford Magna in the County of Dorset	\N	\N	1st L Ashby St. Ledgers 1910	807	7	12	\N	f	\N	708	5	24
Glenarthur	of Carlung in the County of Ayr	\N	\N	\N	811	2	8	\N	f	\N	709	5	8
Weir	of Eastwood in the County of Renfrew	\N	\N	cr V Weir 1938	810	2	8	\N	f	\N	710	5	24
Glanely	of St Fagans in the County of Glamorgan	1942-06-28	1	\N	812	2	8	\N	f	\N	711	5	8
Wittenham	of Wallingford in the County of Berks	1931-02-01	1	\N	813	2	8	\N	f	\N	712	5	24
Burnham	of Hall Barn in the County of Buckingham	1933-07-20	1	\N	829	7	12	\N	f	\N	713	5	3
Shandon	of the City of Cork	1930-09-10	1	\N	814	2	8	\N	f	\N	714	5	20
Phillimore	of Shiplake in the County of Oxford	\N	\N	3rd L died 26 Feb 1990; 4th L died 29 March 1994	815	2	8	\N	f	\N	715	5	17
Lee of Fareham	of Chequers in the County of Buckingham	1947-07-21	1	cr V Lee of Fareham 1922	816	2	8	\N	f	\N	716	5	13
Bertie of Thame	in the County of Oxford	1954-08-29	2	\N	817	7	12	\N	f	\N	717	5	3
Carisbrooke	\N	1960-02-23	1	\N	796	2	9	\N	t	\N	718	5	4
Stuart of Wortley	of the City of Sheffield	1926-04-24	1	\N	775	2	8	\N	f	\N	683	5	20
Allenby of Megiddo	and of Felixstowe in the County of Suffolk	\N	\N	SR to brother & hm of body	840	2	12	\N	f	1	759	5	2
Bledisloe	of Lydney in the County of Gloucster	\N	\N	cr V Bledisloe 1935	818	2	8	\N	f	\N	721	5	3
Midleton	\N	1979-11-02	2	\N	852	7	6	\N	t	\N	757	5	14
Cave	of Richmond in the County of Surrey	1928-03-29	1	widow cr C Cave of Richmond 1928	819	2	12	\N	f	\N	722	5	4
Sterndale	of King Sterndale in the County of Derby	1923-08-17	1	\N	820	2	8	\N	f	\N	723	5	20
Downham	of Fulham in the County of London	1920-07-02	1	\N	821	2	8	\N	f	\N	724	5	5
Birkenhead	of Birkenhead in the County of Chester	1985-02-18	3	cr V Birkenhead 1921, E of Birkenhead 1922	822	2	8	\N	f	\N	725	5	3
Ernle	of Chelsea in the County of London	1937-07-01	1	\N	823	2	8	\N	f	\N	726	5	6
Inverforth	of Southgate in the County of Middlesex	\N	\N	\N	824	2	8	\N	f	\N	727	5	10
Askwith	of Saint Ives in the County of Huntingdon	1942-06-02	1	\N	826	2	8	\N	f	\N	729	5	2
Finlay	of Nairn in the County of Nairn	1945-06-30	2	\N	827	7	12	\N	f	\N	730	5	7
Chalmers	of Northiam in the County of Sussex	1938-11-17	1	\N	828	2	8	\N	f	\N	731	5	4
Rothermere	of Hemsted in the County of Kent	\N	\N	\N	831	7	12	\N	f	\N	732	5	19
Wyfold	of Accrington in the County Palatine of Lancaster	1999-04-08	3	\N	832	2	8	\N	f	\N	733	5	24
Clwyd	of Abergele in the County of Denbigh	\N	\N	\N	833	2	8	\N	f	\N	734	5	4
Dewar	of Homestall in the County of Sussex	1930-04-11	1	\N	834	2	8	\N	f	\N	735	5	5
Rawlinson	of Trent in the County of Dorset	1925-03-28	1	\N	839	2	8	\N	f	\N	737	5	19
Byng of Vimy	of Thorpe-le-Soken in the County of Essex	1935-06-06	1	cr V Byng of Vimy 1928	841	2	8	\N	f	\N	738	5	3
Horne	of Stirkoke in the County of Caithness	1929-08-14	1	\N	842	2	8	\N	f	\N	739	5	9
Wavertree	of Delamere in the County of Chester	1933-02-02	1	\N	844	2	8	\N	f	\N	740	5	24
Ashfield	of Southwell in the County of Nottingham	1948-11-04	1	\N	850	2	8	\N	f	\N	741	5	2
Swinfen	of Chertsey in the County of Surrey	\N	\N	\N	846	2	8	\N	f	\N	742	5	20
Wester Wemyss	of Wemyss in the County of Fife	1933-05-24	1	\N	847	2	8	\N	f	\N	743	5	24
Meston	of Agra in the Indian Empire and Dunottar in the County of Kincardine	\N	\N	\N	848	2	8	\N	f	\N	744	5	14
Forster	of Lepe in the County of Southampton	1936-01-15	1	\N	849	2	8	\N	f	\N	745	5	7
Dawson of Penn	of Penn in the County of Buckingham	1945-03-07	1	cr V Dawson of Penn 30 Oct 1936	853	2	8	\N	f	\N	746	5	5
Cullen of Ashbourne	of Roehampton in the County of Surrey	\N	\N	\N	854	2	8	\N	f	\N	747	5	4
Marshall of Chipstead	of Chipstead in the County of Surrey	1936-03-29	1	\N	858	2	8	\N	f	\N	748	5	14
Buxton	\N	1934-10-15	1	\N	856	7	6	\N	f	\N	749	5	3
Novar	of Raith in the County of Fife and of Novar in the County of Ross	1934-03-30	1	\N	857	2	12	\N	f	\N	750	5	15
Invernairn	of Strathnairn in the County of Inverness	1936-04-09	1	\N	859	2	8	\N	f	\N	751	5	10
Cable	of Ideford in the County of Devon	1927-03-28	1	\N	860	2	8	\N	f	\N	752	5	4
Ystwyth	of Tan-y-Bwlch in the County of Cardigan	1935-08-21	1	\N	861	2	8	\N	f	\N	753	5	26
Birkenhead	of Birkenhead in the County of Chester	1985-02-18	3	cr E of Birkenhead 1922	868	7	12	\N	f	\N	755	5	3
Athlone	\N	1957-01-16	1	\N	794	2	6	\N	t	\N	756	5	2
Milford Haven	\N	\N	\N	\N	795	2	9	\N	t	\N	758	5	14
Ypres	\N	1988-03-04	3	\N	883	7	6	\N	t	\N	799	5	26
Carson	of Duncairn in the County of Antrim	1935-10-22	1	vice L Moulton deceased	864	1	8	\N	f	\N	761	5	4
Chelmsford	of Chelmsford in the County of Essex	\N	\N	\N	865	7	12	\N	f	\N	762	5	4
Long	of Wraxall in the County of Wilts	\N	\N	\N	866	2	12	\N	f	\N	763	5	13
Illingworth	of Denton in the West Riding of the County of York	1942-01-23	1	\N	867	2	8	\N	f	\N	764	5	10
Bearsted	of Maidstone in the County of Kent	\N	\N	cr V Bearsted 1925	869	2	8	\N	f	\N	765	5	3
Curzon of Kedleston	\N	1925-03-20	1	\N	870	7	9	\N	f	\N	766	5	4
Dalziel of Kirkcaldy	of Marylebone in the County of London	1935-07-15	1	\N	871	2	8	\N	f	\N	767	5	5
Ailwyn	of Honingham in the County of Norfolk	1988-09-27	4	\N	872	2	8	\N	f	\N	768	5	2
Glendyne	of Sanquhar in the County of Dumfries	\N	\N	\N	877	2	8	\N	f	\N	769	5	8
Ullswater	of Campsea Ashe in the County of Suffolk	\N	\N	\N	873	2	12	\N	f	\N	770	5	22
Pirrie	of the City of Belfast	1924-06-06	1	\N	874	7	12	\N	f	\N	771	5	17
Glenavy	of Milltown in the County of Dublin	1984-06-01	4	\N	875	2	8	\N	f	\N	772	5	8
Trevethin	of Blaengawney in the County of Monmouth	\N	\N	\N	876	2	8	\N	f	\N	773	5	21
Woolavington	of Lavington in the County of Sussex	1935-08-09	1	\N	878	2	8	\N	f	\N	774	5	24
Haig	\N	\N	\N	\N	836	2	6	\N	f	\N	775	5	9
Vestey	of Kingswood in the County of Surrey	\N	\N	\N	885	2	8	\N	f	\N	777	5	23
Waring	of Foots Cray in the County of Kent	1940-01-09	1	\N	886	2	8	\N	f	\N	778	5	24
Borwick	of Hawkshead in the County of Lancaster	\N	\N	\N	887	2	8	\N	f	\N	779	5	3
Mildmay of Flete	of Totnes in the County of Devon	1950-05-12	2	\N	888	2	8	\N	f	\N	781	5	14
Maclay	of Glasgow in the County of Lanark	\N	\N	\N	889	2	8	\N	f	\N	782	5	14
Wargrave	of Wargrave Hall in the County of Berks	1936-07-17	1	\N	890	2	8	\N	f	\N	783	5	24
Bethell	of Romford in the County of Essex	\N	\N	\N	891	2	8	\N	f	\N	784	5	3
Lee of Fareham	of Bridport in the County of Dorset	1947-07-21	1	\N	894	7	12	\N	f	\N	785	5	13
Farquhar	\N	1923-08-30	1	\N	895	7	6	\N	f	\N	786	5	7
Daryngton	of Witley in the County of Surrey	1994-04-05	2	\N	896	2	8	\N	f	\N	787	5	5
Younger of Leckie	of Alloa in the County of Clackmannan	\N	\N	\N	898	2	12	\N	f	\N	789	5	26
Hunsdon of Hunsdon	of Briggens in the County of Hertford	\N	\N	2nd L succ 1939 as 4th L Aldenham	900	2	8	\N	f	\N	790	5	9
Jessel	of Westminster in the County of London	1990-06-13	2	\N	903	2	8	\N	f	\N	791	5	11
Blanesburgh	of Alloa in the County of Clackmannan	1946-08-17	1	vice V Cave, appointed Lord Chancellor	901	1	8	\N	f	\N	792	5	3
Cecil of Chelwood	of East Grinstead in the County of Sussex	1958-11-24	1	\N	902	2	12	\N	f	\N	793	5	4
Darling	of Langham in the County of Essex	\N	\N	\N	904	2	8	\N	f	\N	794	5	5
Inchcape	of Strathnaver in the County of Sutherland	\N	\N	cr E of Inchcape 1929	905	7	12	\N	f	\N	795	5	10
Banbury of Southam	of Southam in the County of Warwick	\N	\N	\N	906	2	8	\N	f	\N	796	5	3
Danesfort	of Danesfort in the County of Kerry	1935-06-30	1	\N	910	2	8	\N	f	\N	797	5	5
Birkenhead	\N	1985-02-18	3	\N	893	7	6	\N	t	\N	798	5	3
FitzAlan of Derwent	of Derwent in the County of Derby	1962-05-17	2	\N	863	2	12	\N	f	\N	760	5	7
Oxford and Asquith	\N	\N	\N	\N	915	2	6	\N	t	\N	839	5	16
Thomson	of Cardington in the County of Bedford	1930-10-05	1	\N	908	2	8	\N	f	\N	801	5	21
Arnold	of Hale in the County of Chester	1945-08-03	1	\N	909	2	8	\N	f	\N	802	5	2
Stevenson	of Holmbury in the County of Surrey	1926-06-10	1	\N	911	2	8	\N	f	\N	803	5	20
Merrivale	of Walkhampton in the County of Devon	\N	\N	\N	913	2	8	\N	f	\N	804	5	14
Mereworth	of Mereworth Castle in the County of Kent	\N	\N	\N	921	3	8	\N	f	\N	806	5	14
Stonehaven	of Ury in the County of Kincardine	\N	\N	cr V Stonehaven 1938	916	2	8	\N	f	\N	807	5	20
Lloyd	of Dolobran in the County of Montgomery	1985-11-05	2	\N	919	2	8	\N	f	\N	808	5	13
Irwin	of Kirby Underdale in the County of York	\N	\N	succ as 3rd V Halifax 1934; cr E of H 1944	920	2	8	\N	f	\N	809	5	10
Hanworth	of Hanworth in the County of Middlesex	\N	\N	cr V Hanworth 1936	922	2	8	\N	f	\N	810	5	9
Barnby	of Blyth in the County of Nottingham	1982-04-30	2	\N	880	2	8	\N	f	\N	811	5	3
Forres	of Glenogil in the County of Forfar	\N	\N	\N	884	2	8	\N	f	\N	812	5	7
Hewart	of Bury in the County of Lancaster	1964-07-23	2	cr V Hewart 1940	881	2	8	\N	f	\N	813	5	9
Tredegar	of Tredegar in the County of Monmouth	1949-04-27	2	\N	927	7	12	\N	f	\N	814	5	21
Greenway	of Stanbridge Earls in the County of Southampton	\N	\N	\N	929	2	8	\N	f	\N	815	5	8
Warrington of Clyffe	of Market Lavington in the County of Wilts	1937-10-26	1	\N	928	2	8	\N	f	\N	816	5	24
Craigavon	of Stormont in the County of Down	\N	\N	\N	930	2	12	\N	f	\N	817	5	4
Hayter	of Chislehurst in the County of Kent	\N	\N	\N	931	2	8	\N	f	\N	818	5	9
Dalziel of Wooler	of Wooler in the County of Northumberland	1928-04-18	1	\N	935	2	8	\N	f	\N	821	5	5
Wraxall	of Clyst St George in the County of Devon	\N	\N	\N	937	2	8	\N	f	\N	822	5	24
Cushendun	of Cushendun in the County of Antrim	1934-10-12	1	\N	936	2	8	\N	f	\N	823	5	4
Strickland	of Sizergh Castle in the County of Westmorland	1940-08-22	1	\N	939	2	8	\N	f	\N	824	5	20
Lugard	of Abinger in the County of Surrey	1945-04-11	1	\N	941	2	8	\N	f	\N	825	5	13
Atkin	of Aberdovey in the County of Merioneth	1944-06-25	1	\N	940	1	8	\N	f	\N	826	5	2
Melchett	of Landford in the County of Southampton	2018-08-29	4	\N	945	2	8	\N	f	\N	827	5	14
Hailsham	of Hailsham in the County of Sussex	\N	\N	cr V Hailsham 1929	943	2	8	\N	f	\N	828	5	9
Remnant	of Wenhaston in the County of Suffolk	\N	\N	\N	946	2	8	\N	f	\N	829	5	19
Ebbisham	of Cobham in the County of Surrey	1991-04-12	2	\N	947	2	8	\N	f	\N	830	5	6
Trent	of Nottingham in the County of Nottingham	1956-03-08	2	\N	950	2	8	\N	f	\N	831	5	21
Davidson of Lambeth	of Lambeth in the County of London	1930-05-25	1	\N	948	2	8	\N	f	\N	832	5	5
Tomlin	of Ash in the County of Kent	1935-08-12	1	\N	949	1	8	\N	f	\N	833	5	21
Moynihan	of Leeds in the County of York	\N	\N	3rd L died 25 Nov 1991	951	2	8	\N	f	\N	834	5	14
Fairhaven	of Lode in the County of Cambridge	1966-08-20	1	father died before LP; further creation (SR) 1961	952	2	8	\N	f	\N	835	5	7
Brotherton	of Wakefield in the County of York	1930-10-21	1	\N	955	2	8	\N	f	\N	836	5	3
Thankerton	of Thankerton in the County of Lanark	1948-06-13	1	vice L Shaw resigned	953	1	8	\N	f	\N	837	5	21
Gloucester	\N	\N	\N	\N	942	2	4	\N	t	\N	838	5	8
Olivier	of Ramsden in the County of Oxford	1943-02-15	1	\N	907	2	8	\N	f	\N	800	5	16
Reading	\N	\N	\N	\N	925	7	9	\N	t	\N	878	5	19
Bridgeman	of Leigh in the County of Salop	\N	\N	\N	956	2	12	\N	f	\N	841	5	3
Bayford	of Stoke Trister in the County of Somerset	1940-02-24	1	\N	957	2	8	\N	f	\N	842	5	3
Camrose	of Long Cross in the County of Surrey	\N	\N	cr V Camrose 1941	958	2	8	\N	f	\N	843	5	4
Sankey	of Moreton in the County of Gloucester	1948-02-06	1	cr V Sankey 1932	960	2	8	\N	f	\N	845	5	20
Passfield	of Passfield Corner in the County of Southampton	1947-10-13	1	\N	961	2	8	\N	f	\N	846	5	17
Brentford	of Newick in the County of Sussex	\N	\N	\N	964	2	12	\N	f	\N	847	5	3
Luke	of Pavenham in the County of Bedford	\N	\N	2nd L died 25 May 1996	966	2	8	\N	f	\N	849	5	13
Peel	\N	\N	\N	\N	967	7	6	\N	f	\N	850	5	17
Buckland	of Bwlch in the County of Brecon	1928-05-23	1	\N	926	2	8	\N	f	\N	851	5	3
Marley	of Marley in the County of Sussex	1990-03-13	2	\N	975	2	8	\N	f	\N	852	5	14
Ponsonby of Shulbrede	of Shulbrede in the County of Sussex	\N	\N	3rd L died 13 June 1990	976	2	8	\N	f	\N	853	5	17
Baden-Powell	of Gilwell in the County of Essex	\N	\N	\N	973	2	8	\N	f	\N	854	5	3
Dickinson	of Painswick in the County of Gloucester	\N	\N	\N	977	2	8	\N	f	\N	855	5	5
Wakefield	of Hythe in the County of Kent	1941-01-15	1	cr V Wakefield 28 June 1934	978	2	8	\N	f	\N	856	5	24
Kirkley	of Kirkley in the County of Northumberland	1935-09-11	1	\N	979	2	8	\N	f	\N	857	5	12
Trenchard	of Wolfeton in the County of Dorset	\N	\N	cr V Trenchard 31 Jan 1936	980	2	8	\N	f	\N	858	5	21
Noel-Buxton	of Aylsham in the County of Norfolk	\N	\N	\N	982	2	8	\N	f	\N	859	5	15
Sanderson	of Hunmanby in the County of York	1939-03-25	1	\N	983	2	8	\N	f	\N	860	5	20
Macmillan	of Aberfeldy in the County of Perth	1952-09-05	1	vice V Sumner resigned	981	1	8	\N	f	\N	861	5	14
Howard of Penrith	of Gowbarrow in the County of Cumberland	\N	\N	\N	984	2	8	\N	f	\N	862	5	9
Plender	of Sundridge in the County of Kent	1946-01-19	1	\N	985	2	8	\N	f	\N	863	5	17
Hyndley	of Meads in the County of Sussex	1963-01-05	1	cr V Hyndley 2 Feb 1948	986	2	8	\N	f	\N	864	5	9
Rutherford of Nelson	of Cambridge in the County of Cambridge	1937-10-19	1	\N	987	2	8	\N	f	\N	865	5	19
Rochester	of Rochester in the County of Kent	\N	\N	\N	988	2	8	\N	f	\N	866	5	19
Snowden	of Ickornshaw in the West Riding of the County of York	1937-05-15	1	\N	991	2	12	\N	f	\N	867	5	20
Mamhead	of Exeter in the County of Devon	1945-11-02	1	\N	992	2	8	\N	f	\N	868	5	14
Snell	of Plumstead in the County of Kent	1944-04-21	1	\N	990	2	8	\N	f	\N	869	5	20
Conway of Allington	of Allington in the County of Kent	1937-04-19	1	\N	993	2	8	\N	f	\N	870	5	4
Mount Temple	of Lee in the County of Southampton	1939-07-03	1	\N	994	2	8	\N	f	\N	871	5	14
Selsdon	of Croydon in the County of Surrey	\N	\N	\N	995	2	8	\N	f	\N	872	5	20
Moyne	of Bury St Edmunds in the County of Suffolk	\N	\N	2nd L died 6 July 1992	997	2	8	\N	f	\N	874	5	14
Rhayader	of Rhayader in the County of Radnor	1939-09-26	1	\N	998	2	8	\N	f	\N	875	5	19
Sankey	of Moreton in the County of Gloucester	1948-02-06	1	\N	999	7	12	\N	f	\N	876	5	20
Willingdon	\N	1979-03-19	2	cr Marquess of Willingdon 1936	989	7	6	\N	t	\N	877	5	24
Craigmyle	of Craigmyle in the County of Aberdeen	\N	\N	\N	954	8	8	\N	f	\N	840	5	4
Wright	of Durley in the County of Wilts	1964-06-27	1	vice L Dunedin resigned	1000	1	8	\N	f	\N	881	5	24
Davies	of Llandinam in the County of Montgomery	\N	\N	\N	1003	2	8	\N	f	\N	882	5	5
Rankeillour	of Buxted in the County of Sussex	\N	\N	\N	1005	2	8	\N	f	\N	883	5	19
Hutchison of Montrose	of Kirkcaldy in the County of Fife	1950-06-13	1	\N	1006	2	8	\N	f	\N	884	5	9
Brocket	of Brocket Hall in the County of Hertford	\N	\N	\N	1008	2	8	\N	f	\N	885	5	3
Horder	of Ashford in the County of Southampton	1997-07-02	2	\N	1009	2	8	\N	f	\N	886	5	9
Duveen	of Millbank in the City of Westminster	1939-05-25	1	\N	1011	2	8	\N	f	\N	888	5	5
Marks	of Woolwich in the County of Kent	1938-09-24	1	\N	969	2	8	\N	f	\N	889	5	14
Amulree	of Strathbraan in the County of Perth	1983-12-15	2	\N	970	2	8	\N	f	\N	890	5	2
Tyrrell	of Avon in the County of Southampton	1947-03-14	1	\N	971	2	8	\N	f	\N	891	5	21
Palmer	of Reading in the County of Berks	\N	\N	3rd L died 26 June 1990	1016	2	8	\N	f	\N	892	5	17
Bingley	of Bramham in the County of York	1947-12-11	1	\N	1017	2	8	\N	f	\N	893	5	3
Rockley	of Lytchett Heath in the County of Dorset	\N	\N	\N	1018	2	8	\N	f	\N	894	5	19
Portsea	of Portsmouth in the County of Southampton	1948-11-01	1	\N	1019	2	8	\N	f	\N	895	5	17
Eltisley	of Croxton in the County of Cambridge	1942-09-02	1	\N	1021	2	8	\N	f	\N	896	5	6
Elton	of Headington in the County of Oxford	\N	\N	\N	1022	2	8	\N	f	\N	897	5	6
Alness	of Alness in the County of Ross and Cromarty	1955-10-06	1	\N	1024	2	8	\N	f	\N	898	5	2
Wakefield	of Hythe in the County of Kent	1941-01-15	1	\N	1025	7	12	\N	f	\N	899	5	24
Hirst	of Witton in the County of Warwick	1943-01-22	1	\N	1026	2	8	\N	f	\N	900	5	9
Wakehurst	of Ardingly in the County of Sussex	\N	\N	\N	1027	2	8	\N	f	\N	901	5	24
Rushcliffe	of Blackfordby in the County of Leicester	1949-11-18	1	\N	1029	2	8	\N	f	\N	902	5	19
Hesketh	of Hesketh in the County Palatine of Lancaster	\N	\N	\N	1030	2	8	\N	f	\N	903	5	9
Portal	of Laverstoke in the County of Southampton	1949-05-06	1	cr V Portal 1 Feb 1945	1031	2	8	\N	f	\N	904	5	17
Bledisloe	of Lydney in the County of Gloucester	\N	\N	\N	1033	7	12	\N	f	\N	905	5	3
Tweedsmuir	of Elsfield in the County of Oxford	\N	\N	2nd L died 20 June 1996	1032	2	8	\N	f	\N	906	5	21
Sysonby	of Wonersh in the County of Surrey	2009-10-23	3	\N	1034	2	8	\N	f	\N	907	5	20
Wigram	of Clewer in the County of Berks	\N	\N	\N	1035	2	8	\N	f	\N	908	5	24
Riverdale	of Sheffield in the County of York	\N	\N	\N	1037	2	8	\N	f	\N	909	5	19
May	of Weybridge in the County of Surrey	\N	\N	\N	1038	2	8	\N	f	\N	910	5	14
Strathcarron	of Banchor in the County of Inverness	\N	\N	\N	1046	2	8	\N	f	\N	912	5	20
Kennet	of the Dene in the County of Wilts	\N	\N	\N	1040	2	8	\N	f	\N	913	5	12
Roche	of Chadlington in the County of Oxford	1956-12-22	1	vice L Wright appointed MR	1042	1	8	\N	f	\N	915	5	19
Swinton	of Masham in the County of York	\N	\N	cr E of Swinton 5 May 1955	1043	2	12	\N	f	\N	916	5	20
Monsell	of Evesham in the County of Worcester	1993-11-28	2	\N	1044	2	12	\N	f	\N	917	5	14
Woodbridge	of Ipswich in the County of Suffolk	1949-02-03	1	\N	1001	2	8	\N	f	\N	879	5	24
Essendon	of Essendon in the County of Hertford	1978-07-18	2	\N	1002	2	8	\N	f	\N	880	5	6
Willingdon	\N	1979-03-19	2	\N	1052	7	9	\N	t	\N	957	5	24
Glenravel	of Kensington in the County of London	1937-06-13	1	\N	1049	2	8	\N	f	\N	920	5	8
Kemsley	of Farnham Royal in the County of Buckingham	\N	\N	cr V Kemsley 12 Sep 1945	1050	2	8	\N	f	\N	921	5	12
Catto	of Cairncatto in the County of Aberdeen	\N	\N	\N	1051	2	8	\N	f	\N	922	5	4
Cautley	of Lindfield in the County of Sussex	1946-09-21	1	\N	1053	2	8	\N	f	\N	923	5	4
Austin	of Longbridge in the City of Birmingham	1941-05-23	1	\N	1055	2	8	\N	f	\N	925	5	2
Rennell	of Rodd in the County of Hereford	\N	\N	\N	1013	2	8	\N	f	\N	926	5	19
Mottistone	of Mottistone in the County of Southampton	\N	\N	\N	1014	2	8	\N	f	\N	927	5	14
Iliffe	of Yattendon in the County of Berks	\N	\N	2nd L died 15 Feb 1996	1015	2	8	\N	f	\N	928	5	10
McGowan	of Ardeer in the County of Ayr	\N	\N	\N	1061	2	8	\N	f	\N	929	5	14
Addison	of Stallingborough in the County of Lincoln	\N	\N	cr V Addison 2 July 1945	1063	2	8	\N	f	\N	930	5	2
Denham	of Weston Underwood in the County of Buckingham	\N	\N	\N	1064	2	8	\N	f	\N	931	5	5
Rea	of Eskdale in the County of Cumberland	\N	\N	\N	1067	2	8	\N	f	\N	932	5	19
Chatfield	of Ditchling in the County of Sussex	2007-09-30	2	\N	1068	2	8	\N	f	\N	933	5	4
Cadman	of Silverdale in the County of Stafford	\N	\N	\N	1069	2	8	\N	f	\N	934	5	4
Baldwin of Bewdley	\N	\N	\N	\N	1070	2	6	\N	f	\N	935	5	3
Samuel	of Mount Carmel and Toxteth in the City of Liverpool	\N	\N	\N	1071	2	12	\N	f	\N	936	5	20
Horne of Slamannan	of Slamannan in the County of Stirling	1940-09-03	1	\N	1073	2	12	\N	f	\N	938	5	9
Runciman of Doxford	of Doxford in the County of Northumberland	\N	\N	succ as 2nd L Runciman 13 Aug 1937	1074	2	12	\N	f	\N	939	5	19
Kenilworth	of Kenilworth in the County of Warwick	\N	\N	\N	1075	2	8	\N	f	\N	940	5	12
Davidson	of Little Gaddesden in the County of Hertford	\N	\N	\N	1076	2	12	\N	f	\N	941	5	5
Southwood	of Fernhurst in the County of Sussex	1946-04-10	1	cr V Southwood 25 Jan 1946	1077	2	8	\N	f	\N	942	5	20
Pender	of Porthcurnow in the County of Cornwall	\N	\N	\N	1078	2	8	\N	f	\N	943	5	17
Nuffield	of Nuffield in the County of Oxford	1963-08-22	1	\N	1080	7	12	\N	f	\N	944	5	15
Romer	of New Romney in the County of Kent	1944-08-19	1	vice L Roche resigned	1079	1	8	\N	f	\N	945	5	19
Roborough	of Maristow in the County of Devon	\N	\N	2nd L died 30 June 1992	1081	2	8	\N	f	\N	946	5	19
Birdwood	of Anzac and of Totnes in the County of Devon	2015-07-11	3	\N	1082	2	8	\N	f	\N	947	5	3
Mills	of Studley in the County of Warwick	\N	\N	cr V Mills 1962	1338	2	8	\N	f	\N	948	5	14
Perry	of Stock Harvard in the County of Essex	1956-06-17	1	\N	1085	2	8	\N	f	\N	950	5	17
Weir	of Eastwood in the County of Renfrew	\N	\N	\N	1087	7	12	\N	f	\N	951	5	24
Porter	of Longfield in the County of Tyrone	1956-02-13	1	vice L Maugham appointed Lord Chancellor	1086	1	8	\N	f	\N	952	5	17
Stonehaven	of Ury in the County of Kincardine	\N	\N	subsumed in E of Kintore Sep 1974	1088	7	12	\N	f	\N	953	5	20
Stamp	of Shortlands in the County of Kent	\N	\N	\N	1089	2	8	\N	f	\N	954	5	20
Bicester	of Tusmore in the County of Oxford	\N	\N	\N	1090	2	8	\N	f	\N	955	5	3
Strathmore and Kinghorne	\N	\N	\N	\N	1065	8	6	\N	t	\N	956	5	20
Trenchard	of Wolfeton in the County of Dorset	\N	\N	\N	1048	7	12	\N	f	\N	919	5	21
Harmsworth	of Egham in the County of Surrey	\N	\N	?th L died 2 June 1990	1094	2	8	\N	f	\N	961	5	9
Brooke of Oakley	of Oakley in the County of Northampton	1944-11-17	1	\N	1095	2	8	\N	f	\N	962	5	3
Rotherwick	of Tylney in the County of Southampton	\N	\N	2nd L died 11 June 1996	1096	2	8	\N	f	\N	963	5	19
Dawson of Penn	of Penn in the County of Buckingham	1945-03-07	1	\N	1057	7	12	\N	f	\N	964	5	5
Greenwood	of Holbourne in the County of London	2003-07-07	3	\N	1058	7	12	\N	f	\N	965	5	8
Mancroft	of Mancroft in the City of Norwich	\N	\N	\N	1060	2	8	\N	f	\N	966	5	14
Caldecote	of Bristol in the County of Gloucester	\N	\N	\N	1100	2	12	\N	f	\N	967	5	4
Maugham	of Hartfield in the County of Sussex	1981-03-13	2	\N	1101	7	12	\N	f	\N	968	5	14
Tryon	of Durnford in the County of Wilts	\N	\N	\N	1102	2	8	\N	f	\N	969	5	21
Simon	of Stackpole Elidor in the County of Pembroke	\N	\N	2nd V died 5 Dec 1993	1103	2	12	\N	f	\N	970	5	20
Croft	of Bournemouth in the County of Southampton	\N	\N	\N	1104	2	8	\N	f	\N	971	5	4
Teviot	of Burghclere in the County of Southampton	\N	\N	\N	1106	2	8	\N	f	\N	972	5	21
Nathan	of Churt in the County of Surrey	\N	\N	\N	1107	2	8	\N	f	\N	973	5	15
Quickswood	of Clothall in the County of Hertford	1956-12-10	1	\N	1111	2	8	\N	f	\N	974	5	18
Hewart	of Bury in the County of Lancaster	1964-07-23	2	\N	1109	7	12	\N	f	\N	975	5	9
Merriman	of Knutdford in the County Palatine of Chester	1962-01-18	1	\N	1112	2	8	\N	f	\N	976	5	14
Kindersley	of West Hoathly in the County of Sussex	\N	\N	\N	1113	2	8	\N	f	\N	977	5	12
Ironside	of Archangel and Ironside in the County of Aberdeen	\N	\N	\N	1114	2	8	\N	f	\N	978	5	10
Vansittart	of Denham in the County of Buckingham	1957-02-14	1	\N	1116	2	8	\N	f	\N	979	5	23
Leathers	of Purfleet in the County of Essex	\N	\N	cr V Leathers 18 Jan 1954	1115	2	8	\N	f	\N	980	5	13
Greene	of Holmbury St Mary in the County of Surrey	1952-04-16	1	\N	1119	2	8	\N	f	\N	982	5	8
Stansgate	of Stansgate in the County of Essex	\N	\N	2nd V disclaimed	1122	2	12	\N	f	\N	983	5	20
Latham	of Hendon in the County of Middlesex	\N	\N	\N	1123	2	8	\N	f	\N	984	5	13
Soulbury	of Soulbury in the County of Buckingham	\N	\N	cr V Soulbury 16 July 1954	1120	2	8	\N	f	\N	985	5	20
Sherwood	of Calverton in the County of Nottingham	1970-04-01	1	\N	1121	2	8	\N	f	\N	986	5	20
Wedgwood	of Barlaston in the County of Stafford	\N	\N	\N	1124	2	8	\N	f	\N	987	5	24
Geddes	of Rolvenden in the County of Kent	\N	\N	\N	1125	2	8	\N	f	\N	988	5	8
Clauson	of Hawkshead in the County of Hertford	1946-03-15	1	\N	1127	2	8	\N	f	\N	990	5	4
Keynes	of Tilton in the County of Sussex	1946-04-21	1	\N	1132	2	8	\N	f	\N	991	5	12
Keyes	of Zeebrugge and of Dover in the County of Kent	\N	\N	\N	1133	2	8	\N	f	\N	992	5	12
Lang of Lambeth	of Lambeth in the County of Surrey	1945-12-05	1	\N	1129	2	8	\N	f	\N	993	5	13
Margesson	of Rugby in the County of Warwick	\N	\N	\N	1130	2	12	\N	f	\N	994	5	14
Brabazon of Tara	of Sandwich in the County of Kent	\N	\N	\N	1131	2	8	\N	f	\N	995	5	3
Moran	of Manton in the County of Wilts	\N	\N	\N	1135	2	8	\N	f	\N	996	5	14
Killearn	of Killearn in the County of Stirling	\N	\N	2nd L died 27 July 1996	1137	2	8	\N	f	\N	997	5	12
Milford	of Llanstephan in the County of Radnor	\N	\N	2nd L died 30 Nov 1993	1092	2	8	\N	f	\N	959	5	14
Hankey	of The Chart in the County of Surrey	\N	\N	2nd L died 28 Oct 1996	1093	2	8	\N	f	\N	960	5	9
Dowding	of Bentley Priory in the County of Middlesex	\N	\N	2nd L died 22 Nov 1992	1138	2	8	\N	f	\N	999	5	5
Gretton	of Stapleford in the County of Leicester	\N	\N	\N	1140	2	8	\N	f	\N	1000	5	8
Woolton	of Liverpool in the County Palatine of Lancaster	\N	\N	cr V Woolton 2 July 1953, E of Woolton 1956	1098	2	8	\N	f	\N	1001	5	24
Wavell	of Cyrenaica and of Winchester in the County of Southampton	1953-12-24	2	cr E Wavell 1 May 1947	1139	2	12	\N	f	\N	1002	5	24
Glentoran	of Ballyalloly in the County of Down	\N	\N	2nd L died 22 July 1995	1099	2	8	\N	f	\N	1003	5	8
Abertay	of Tullybelton in the County of Perth	1940-12-06	1	\N	1105	2	8	\N	f	\N	1004	5	2
Schuster	of Cerne in the County of Dorset	1956-06-28	1	\N	1146	2	8	\N	f	\N	1005	5	20
Portal	of Laverstoke in the County of Southampton	1949-05-06	1	\N	1152	7	12	\N	f	\N	1007	5	17
Templewood	of Chelsea in the County of Middlesex	1959-05-07	1	\N	1148	2	12	\N	f	\N	1008	5	21
Goddard	of Aldbourne in the County of Wilts	1971-05-29	1	vice L Atkin deceased	1149	1	8	\N	f	\N	1009	5	8
Norman	of St Clere in the County of Kent	1950-02-04	1	\N	1150	2	8	\N	f	\N	1010	5	15
Lloyd-George of Dwyfor	\N	\N	\N	\N	1153	2	6	\N	f	\N	1011	5	13
Hazlerigg	of Noseley in the County of Leicester	\N	\N	\N	1154	2	8	\N	f	\N	1012	5	9
Hacking	of Chorley in the County Palatine of Lancaster	\N	\N	\N	1156	2	8	\N	f	\N	1013	5	9
Courthope	of Whitligh in the County of Sussex	1955-09-02	1	\N	1157	2	8	\N	f	\N	1014	5	4
Balfour of Inchrye	of Shefford in the County of Berks	2013-04-14	2	\N	1158	2	8	\N	f	\N	1015	5	3
Jackson	of Glewstone in the County of Hereford	1954-05-02	1	\N	1159	2	8	\N	f	\N	1016	5	11
Quibell	of Scunthorpe in the County of Lincoln	1962-04-16	1	\N	1160	2	8	\N	f	\N	1017	5	18
Walkden	of Great Bookham in the County of Surrey	1951-04-25	1	\N	1161	2	8	\N	f	\N	1018	5	24
Cope	of St Mellons in the County of Monmouth	1946-07-15	1	\N	1163	2	8	\N	f	\N	1020	5	4
Ramsden	of Birkenshaw in the West Riding of the County of York	1955-08-09	1	\N	1164	2	8	\N	f	\N	1021	5	19
Chattisham	of Clitheroe in the County Palatine of Lancaster	1945-08-24	1	\N	1165	2	8	\N	f	\N	1022	5	4
Sandford	of Banbury in the County of Oxford	\N	\N	\N	1166	2	8	\N	f	\N	1023	5	20
Lambert	of South Molton in the County of Devon	1999-10-22	3	\N	1167	2	12	\N	f	\N	1024	5	13
Altrincham	of Tormerton in the County of Gloucester	\N	\N	2nd L disclaimed & died 28.12.2001	1168	2	8	\N	f	\N	1025	5	2
Kemsley	of Dropmore in the County of Buckingham	\N	\N	\N	1171	7	12	\N	f	\N	1026	5	12
Jowitt	of Stevenage in the County of Hertford	1957-08-16	1	cr V Jowitt 20 Jan 1947, E Jowitt 24 Dec 1951	1169	2	8	\N	f	\N	1027	5	11
Pethick-Lawrence	of Peaslake in the County of Surrey	1961-09-17	1	\N	1170	2	8	\N	f	\N	1028	5	17
Llewellin	of Upton in the County of Dorset	1957-01-24	1	\N	1172	2	8	\N	f	\N	1029	5	13
Marchwood	of Penang and of Marchwood in the County of Southampton	\N	\N	\N	1173	7	12	\N	f	\N	1030	5	14
Lyle of Westbourne	of Canford Cliffs in the County of Dorset	1976-08-01	2	\N	1174	2	8	\N	f	\N	1031	5	13
Broadbridge	of Brighton in the County of Sussex	\N	\N	\N	1175	2	8	\N	f	\N	1032	5	3
Broughshane	of Kensington in the County of London	2006-03-24	3	2nd L died 22 Sep 1995	1179	2	8	\N	f	\N	1034	5	3
Daventry	of Daventry in the County of Northampton	\N	\N	husband died 3 Mch 1943	1136	2	12	\N	f	\N	1035	5	5
Hemingford	of Watford in the County of Hertford	\N	\N	\N	1134	2	8	\N	f	\N	998	5	9
Courtauld-Thomson	of Dorneywood in the County of Buckingham	1954-11-01	1	\N	1144	2	8	\N	f	\N	1040	5	4
Morrison	of Tottenham in the County of Middlesex	1997-10-28	2	\N	1185	2	8	\N	f	\N	1041	5	14
Chorley	of Kendal in the County of Westmorland	\N	\N	\N	1186	2	8	\N	f	\N	1042	5	4
Calverley	of the City of Bradford in the West Riding of the County of York	\N	\N	\N	1187	2	8	\N	f	\N	1043	5	4
Rusholme	of Rusholme in the City of Manchester	1977-08-18	1	\N	1188	2	8	\N	f	\N	1044	5	19
Southwood	of Fernhurst in the County of Sussex	1946-04-10	1	\N	1191	7	12	\N	f	\N	1045	5	20
Portal of Hungerford	of Hungerford in the County of Berks	1971-04-22	1	\N	1193	7	12	\N	f	\N	1047	5	17
Colgrain	of Everlands in the County of Kent	\N	\N	\N	1194	2	8	\N	f	\N	1048	5	4
Alanbrooke	of Brookeborough in the County of Fermanagh	2018-01-10	3	\N	1195	7	12	\N	f	\N	1049	5	2
Inman	of Knaresborough in the West Riding of the County of York	1979-08-26	1	\N	1196	2	8	\N	f	\N	1050	5	10
Montgomery of Alamein	of Hindhead in the County of Surrey	\N	\N	\N	1197	2	12	\N	f	\N	1051	5	14
Tovey	of Langton Matravers in the County of Dorset	1971-01-12	1	\N	1200	2	8	\N	f	\N	1052	5	21
du Parcq	of Grouville in the Island of Jersey	1949-04-27	1	du Parcq; vice L Goddard appointed LCJ	1198	1	8	\N	f	\N	1053	5	5
Gort	of Hamsterley in the County of Durham	1946-03-31	1	\N	1199	3	12	\N	f	\N	1054	5	8
Darwen	of Heys-in-Bowland in the West Riding of the County of York	\N	\N	?th L died 9 Dec 1988	1201	2	8	\N	f	\N	1055	5	5
Alexander of Tunis	of Errigal in the County of Donegal	\N	\N	cr E Alexander of Tunis 11 Mch 1952	1202	2	12	\N	f	\N	1056	5	2
Wilson	of Libya and of Stowlangtoft in the County of Suffolk	2009-02-01	2	\N	1203	2	8	\N	f	\N	1057	5	24
Beveridge	of Tuggal in the County of Northumberland	1963-03-16	1	\N	1205	2	8	\N	f	\N	1058	5	3
Inverchapel	of Loch Eck in the County of Argyll	1951-07-05	1	\N	1204	2	8	\N	f	\N	1059	5	10
Uvedale of North End	of North End in the County of Middlesex	1974-02-28	1	\N	1206	2	8	\N	f	\N	1060	5	22
Lucas of Chilworth	of Chilworth in the County of Southampton	\N	\N	\N	1207	2	8	\N	f	\N	1061	5	13
Citrine	of Wembley in the County of Middlesex	2006-08-05	3	\N	1209	2	8	\N	f	\N	1062	5	4
Brand	of Eydon in the County of Northampton	1963-08-23	1	\N	1210	2	8	\N	f	\N	1063	5	3
Newall	of Clifton-upon-Dunsmoor in the County of Warwick	\N	\N	\N	1211	2	8	\N	f	\N	1064	5	15
Fraser of North Cape	of Molesey in the County of Surrey	1981-02-12	1	\N	1213	2	8	\N	f	\N	1065	5	7
Oaksey	of Oaksey in the County of Wilts	\N	\N	succ as 3rd L Trevethin 25 Jne 1959	1216	2	8	\N	f	\N	1066	5	16
Hall	of Cynon Valley in the County of Glamorgan	1985-07-24	2	\N	1214	2	12	\N	f	\N	1067	5	9
Normand	of Aberdour in the County of Fife	1962-10-05	1	vice L Macmillan resigned	1215	1	8	\N	f	\N	1068	5	15
Ismay	of Wormington in the County of Gloucester	1965-12-17	1	\N	1217	2	8	\N	f	\N	1069	5	10
Rugby	of Rugby in the County of Warwick	\N	\N	\N	1218	2	8	\N	f	\N	1070	5	19
Layton	of Danehill in the County of Sussex	\N	\N	?th L died 23 Jan 1989	1219	2	8	\N	f	\N	1071	5	13
Simon of Wythenshawe	of Didsbury in the City of Manchester	\N	\N	\N	1220	2	8	\N	f	\N	1072	5	20
Jowitt	of Stevenage in the County of Hertford	1957-08-16	1	cr E Jowitt 24 Dec 1951	1221	7	12	\N	f	\N	1073	5	11
Kershaw	of Prestwich in the County Palatine of Lancaster	\N	\N	\N	1222	2	8	\N	f	\N	1074	5	12
Henderson	of Westgate in the City and County of Newcastle upon Tyne	1984-04-04	1	\N	1181	2	8	\N	f	\N	1038	5	9
Ammon	of Camberwell in the County of Surrey	1960-04-02	1	\N	1143	2	8	\N	f	\N	1039	5	2
Bruce of Melbourne	of Westminster Gardens in the City of Westminster	1967-08-25	1	\N	1224	2	12	\N	f	\N	1076	5	3
Lindsay of Birker	of Low Ground in the County of Cumberland	\N	\N	2nd L died 13 Feb 1994	1183	2	8	\N	f	\N	1077	5	13
Tedder	of Glenguin in the County of Stirling	\N	\N	2nd L died 18 Feb 1994	1190	2	8	\N	f	\N	1078	5	21
Piercy	of Burford in the County of Oxford	\N	\N	\N	1184	2	8	\N	f	\N	1079	5	17
Robinson	of Kielder Forest in the County of Northumberland and of Adelaide in the Commonwealth of Australia	1952-09-05	1	\N	1230	2	8	\N	f	\N	1080	5	19
Amwell	of Islington in the County of London	\N	\N	2nd L died 12 Oct 1990	1231	2	8	\N	f	\N	1081	5	2
Milverton	of Lagos and of Clifton in the City of Bristol	\N	\N	\N	1232	2	8	\N	f	\N	1082	5	14
Hyndley	of Meads in the County of Sussex	1963-01-05	1	\N	1235	7	12	\N	f	\N	1083	5	9
Mackintosh of Halifax	of Hethersett in the County of Norfolk	\N	\N	cr V Mackintosh of Halifax 10 Jly 1957	1236	2	8	\N	f	\N	1084	5	14
Douglas of Kirtleside	of Dornock in the County of Dumfries	1969-10-30	1	\N	1237	2	8	\N	f	\N	1085	5	5
Braintree	of Braintree in the County of Essex	1961-05-21	1	\N	1238	2	8	\N	f	\N	1086	5	3
Webb-Johnson	of Stoke-on-Trent in the County of Stafford	1958-05-28	1	\N	1240	2	8	\N	f	\N	1087	5	24
Maenan	of Ellesmere in the County of Salop	1951-09-22	1	\N	1241	2	8	\N	f	\N	1088	5	14
Williams	of Ynyshir in the County of Glamorgan	1966-02-18	1	\N	1242	2	8	\N	f	\N	1089	5	24
Adams	of Ennerdale in the County of Cumberland	1960-08-23	1	\N	1244	2	8	\N	f	\N	1090	5	2
Reid	of Drem in the County of East Lothian	1975-03-29	1	vice L Thankerton deceased	1243	1	8	\N	f	\N	1091	5	19
Boyd-Orr	of Brechin Mearn in the County of Angus	1971-06-25	1	\N	1245	2	8	\N	f	\N	1092	5	3
Badeley	of Badley in the County of Suffolk	1951-09-27	1	\N	1248	2	8	\N	f	\N	1093	5	3
Macdonald of Gwaenysgor	of Gwaenysgor in the County of Flint	2002-01-27	2	\N	1246	2	8	\N	f	\N	1094	5	14
Dugan of Victoria	of Lurgan in the County of Armagh	1951-08-17	1	\N	1249	2	8	\N	f	\N	1095	5	5
Wilmot of Selmeston	of Selmeston in the County of Sussex	1964-07-22	1	\N	1252	2	8	\N	f	\N	1097	5	24
Bilsland	of Kinrara in the County of Inverness	1970-12-10	1	\N	1253	2	8	\N	f	\N	1098	5	3
Burden	of Hazlebarrow in the County of Derby	\N	\N	\N	1254	2	8	\N	f	\N	1099	5	3
Henderson of Ardwick	of Morton Park in the City of Carlisle	1950-02-26	1	never introduced	1256	2	8	\N	f	\N	1101	5	9
Silkin	of Dulwich in the County of London	\N	\N	\N	1259	2	8	\N	f	\N	1102	5	20
Lawson	of Beamish in the County of Durham	1965-08-03	1	\N	1257	2	8	\N	f	\N	1103	5	13
Douglas of Barloch	of Maxfield in the County of Sussex	1980-03-31	1	\N	1258	2	8	\N	f	\N	1104	5	5
Hurcomb	of Campden Hill in the Royal Borough of Kensington	1975-08-07	1	\N	1260	2	8	\N	f	\N	1105	5	9
Campion	of Bowes in the County of Surrey	1958-04-06	1	\N	1261	2	8	\N	f	\N	1106	5	4
Hives	of Duffield in the County of Derby	\N	\N	\N	1262	2	8	\N	f	\N	1107	5	9
Greenhill	of Townhead in the City of Glasgow	2020-01-13	3	\N	1263	2	8	\N	f	\N	1108	5	8
Ogmore	of Bridgend in the County of Glamorgan	\N	\N	\N	1264	2	8	\N	f	\N	1109	5	16
Morris of Kenwood	of Kenwood in the City of Sheffield	\N	\N	\N	1265	2	8	\N	f	\N	1110	5	14
Tucker	of Great Bookham in the County of Surrey	1975-11-17	1	vice L Greene resigned	1266	1	8	\N	f	\N	1112	5	21
Hungarton	of Hungarton in the County of Leicester	1966-06-14	1	\N	1268	2	8	\N	f	\N	1113	5	9
Edinburgh	\N	\N	\N	\N	1234	2	4	\N	t	\N	1114	5	6
Trefgarne	of Cleddau in the County of Pembroke	\N	\N	\N	1223	2	8	\N	f	\N	1075	5	21
Wavell	\N	1953-12-24	2	\N	1228	7	6	\N	f	\N	1118	5	24
Cohen	of Walmer in the County of Kent	1973-05-09	1	vice L Simonds appointed Lord Chancellor	1273	1	8	\N	f	\N	1119	5	4
Ruffside	of Hexham in the County of Northumberland	1958-05-05	1	\N	1274	2	12	\N	f	\N	1120	5	19
Kirkwood	of Bearsden in the County of Dunbarton	\N	\N	\N	1276	2	8	\N	f	\N	1121	5	12
Jowitt	\N	1957-08-16	1	\N	1277	7	6	\N	f	\N	1122	5	11
Wise	of King's Lynn in the County of Norfolk	\N	\N	\N	1278	2	8	\N	f	\N	1123	5	24
Hudson	of Pewsey in the County of Wilts	1963-08-28	2	\N	1279	2	12	\N	f	\N	1124	5	9
Waverley	of Westdean in the County of Sussex	\N	\N	2nd V died 21 Feb 1990	1281	2	12	\N	f	\N	1125	5	24
Mathers	of Newtown St Boswells in the County of Roxburgh	1965-09-26	1	\N	1282	2	8	\N	f	\N	1126	5	14
Turnour	of Shillinglee in the County of Sussex	1962-08-26	1	\N	1283	3	8	\N	f	\N	1127	5	21
Thurso	of Ulbster in the County of Caithness	\N	\N	\N	1285	2	12	\N	f	\N	1128	5	21
Alexander of Tunis	\N	\N	\N	\N	1284	7	6	\N	f	\N	1129	5	2
Brookeborough	of Colebrooke in the County of Fermanagh	\N	\N	\N	1287	2	12	\N	f	\N	1131	5	3
Norwich	of Aldwick in the County of Sussex	\N	\N	\N	1288	2	12	\N	f	\N	1132	5	15
Jeffreys	of Burkham in the County of Southampton	\N	\N	\N	1289	2	8	\N	f	\N	1133	5	11
Rathcavan	of The Braid in the County of Antrim	\N	\N	\N	1290	2	8	\N	f	\N	1134	5	19
Percy of Newcastle	of Etchingham in the County of Sussex	1958-04-03	1	\N	1291	2	8	\N	f	\N	1135	5	17
Glyn	of Farnborough in the County of Berks	1960-05-01	1	\N	1293	2	8	\N	f	\N	1136	5	8
Grantchester	of Knightsbridge in the City of Westminster	\N	\N	2nd L died 12 Aug 1995	1294	2	8	\N	f	\N	1137	5	8
Bennett of Edgbaston	of Sutton Coldfield in the County of Warwick	1957-09-29	1	\N	1295	2	8	\N	f	\N	1138	5	3
Woolton	of Liverpool in the County Palatine of Lancaster	\N	\N	cr E of Woolton 1956	1296	7	12	\N	f	\N	1139	5	24
Hore-Belisha	of Devonport in the County of Devon	1957-02-16	1	\N	1299	2	8	\N	f	\N	1140	5	9
Strang	of Stonesfield in the County of Oxford	2014-12-19	2	\N	1300	2	8	\N	f	\N	1141	5	20
Salter	of Kidlington in the County of Oxford	1975-06-27	1	\N	1297	2	8	\N	f	\N	1142	5	20
Keith of Avonholm	of St Bernard's in the City of Edinburgh	1964-06-29	1	vice L Normand resigned	1298	1	8	\N	f	\N	1143	5	12
Leathers	of Purfleet in the County of Essex	\N	\N	2nd V died 21 Jan 1996	1301	7	12	\N	f	\N	1144	5	13
Dovercourt	of Harwich in the County of Essex	1961-04-22	1	\N	1302	2	8	\N	f	\N	1145	5	5
Moore	of Cobham in the County of Surrey	\N	\N	\N	1303	3	8	\N	f	\N	1146	5	14
Coleraine	of Haltemprice in the East Riding of the County of York	\N	\N	\N	1304	2	8	\N	f	\N	1147	5	4
Harvey of Tasburgh	of Tasburgh in the County of Norfolk	\N	\N	\N	1305	2	8	\N	f	\N	1148	5	9
Soulbury	of Soulbury in the County of Buckingham	\N	\N	\N	1306	7	12	\N	f	\N	1149	5	20
Cooper of Culross	of Dunnet in the County of Caithness	1955-07-15	1	\N	1308	2	8	\N	f	\N	1150	5	4
Kenswood	of Saint Marylebone in the County of London	\N	\N	\N	1271	2	8	\N	f	\N	1151	5	12
Chandos	of Aldershot in the County of Southampton	\N	\N	\N	1309	2	12	\N	f	\N	1153	5	4
MacDermott	of Belmont in the City of Belfast	1979-07-13	1	MacDermott; vice L Wright resigned	1227	1	8	\N	f	\N	1116	5	14
Crook	of Carshalton in the County of Surrey	\N	\N	\N	1229	2	8	\N	f	\N	1117	5	4
Wales	\N	\N	\N	\N	1353	7	11	\N	t	\N	1194	5	24
Milner of Leeds	of Roundhay in the City of Leeds	\N	\N	\N	1275	2	8	\N	f	\N	1156	5	14
Malvern	of Rhodesia and of Bexley in the County of Kent	\N	\N	\N	1316	2	12	\N	f	\N	1157	5	14
Strathclyde	of Barskimming in the County of Ayr	\N	\N	\N	1317	2	8	\N	f	\N	1158	5	20
Conesford	of Chelsea in the County of London	1974-08-28	1	\N	1319	2	8	\N	f	\N	1159	5	4
Heyworth	of Oxton in the County Palatine of Chester	1974-06-15	1	\N	1321	2	8	\N	f	\N	1160	5	9
McNair	of Gleniffer in the County of Renfrew	\N	\N	\N	1322	2	8	\N	f	\N	1161	5	14
Evershed	of Stapenhill in the County of Derby	1966-10-03	1	\N	1331	2	8	\N	f	\N	1162	5	6
Attlee	\N	\N	\N	2nd E died 27 July 1991	1324	2	6	\N	f	\N	1163	5	2
De L'Isle	of Penshurst in the County of Kent	\N	\N	\N	1326	7	12	\N	f	\N	1164	5	5
Crookshank	of Gainsborough in the County of Lincoln	1961-10-17	1	\N	1327	2	12	\N	f	\N	1165	5	4
Ingleby	of Snilesworth in the North Riding of the County of York	2008-10-14	2	\N	1328	2	12	\N	f	\N	1166	5	10
Cilcennin	of Hereford in the County of Hereford	1960-07-13	1	\N	1329	2	12	\N	f	\N	1167	5	4
Colyton	of Farway in the County of Devon and of Taunton in the County of Somerset	\N	\N	\N	1330	2	8	\N	f	\N	1168	5	4
Astor of Hever	of Hever Castle in the County of Kent	\N	\N	\N	1332	2	8	\N	f	\N	1169	5	2
Godber	of Mayfield in the County of Sussex	1976-04-10	1	\N	1333	2	8	\N	f	\N	1170	5	8
Cherwell	of Oxford in the County of Oxford	1957-07-03	1	\N	1334	7	12	\N	f	\N	1171	5	4
Weeks	of Ryton in the County Palatine of Durham	1960-08-19	1	\N	1335	2	8	\N	f	\N	1172	5	24
Cohen of Birkenhead	of Birkenhead in the County Palatine of Chester	1977-08-07	1	\N	1336	2	8	\N	f	\N	1173	5	4
Sinclair of Cleeve	of Cleeve in the County of Somerset	\N	\N	\N	1337	2	8	\N	f	\N	1174	5	20
Evans	of Merthyr Tydfil in the County of Glamorgan	1963-10-26	1	\N	1344	2	8	\N	f	\N	1175	5	6
Monckton of Brenchley	of Brenchley in the County of Kent	\N	\N	\N	1340	2	12	\N	f	\N	1176	5	14
Tenby	of Bulford in the County of Pembroke	\N	\N	\N	1341	2	12	\N	f	\N	1177	5	21
Hailes	of Prestonkirk in the County of East Lothian	1974-11-05	1	\N	1342	2	8	\N	f	\N	1178	5	9
Denning	of Whitchurch in the County of Southampton	1999-03-05	1	vice L Oaksey resigned	1343	1	8	\N	f	\N	1179	5	5
Rank	of Sutton Scotney in the County of Southampton	1972-03-29	1	\N	1345	2	8	\N	f	\N	1180	5	19
Birkett	of Ulverston in the County Palatine of Lancaster	\N	\N	\N	1349	2	8	\N	f	\N	1181	5	3
Brecon	of Llanfeigan in the County of Brecknock	1976-10-10	1	\N	1348	2	8	\N	f	\N	1182	5	3
Harding of Petherton	of Nether Compton in the County of Dorset	\N	\N	\N	1350	2	8	\N	f	\N	1183	5	9
Robins	of Rhodesia and of Chelsea in the County of London	1962-07-21	1	\N	1351	2	8	\N	f	\N	1184	5	19
Poole	of Aldgate in the City of London	\N	\N	\N	1352	2	8	\N	f	\N	1185	5	17
Fraser of Lonsdale	of Regent's Park in the County of London	1974-12-19	1	\N	1354	5	8	\N	f	\N	1186	5	7
Stonham	of Earl Stonham in the County of Suffolk	1971-12-22	1	\N	1355	5	8	\N	f	\N	1187	5	20
Geddes of Epsom	of Epsom in the County of Surrey	1983-05-02	1	\N	1356	5	8	\N	f	\N	1188	5	8
Granville-West	of Pontypool in the County of Monmouth	1984-09-23	1	\N	1358	5	8	\N	f	\N	1190	5	8
Taylor	of Harlow in the County of Essex	1988-02-01	1	\N	1359	5	8	\N	f	\N	1191	5	21
Adrian	of Cambridge in the County of Cambridge	1995-04-04	2	\N	1314	2	8	\N	f	\N	1192	5	2
Woolton	\N	\N	\N	\N	1325	7	6	\N	t	\N	1193	5	24
Swanborough	of Swanborough in the County of Sussex	1971-05-22	1	\N	1364	5	8	\N	f	\N	1233	5	20
Clitheroe	of Downham in the County Palatine of Lancaster	\N	\N	\N	1320	2	8	\N	f	\N	1196	5	4
Ferrier	of Culter in the County of Lanark	1992-06-04	1	\N	1365	5	8	\N	f	\N	1197	5	7
Parker of Waddington	of Lincoln's Inn in the Borough of Holborn	1972-09-15	1	same title as father	1367	5	8	\N	f	\N	1198	5	17
Shawcross	of Friston in the County of Sussex	2003-07-10	1	\N	1369	5	8	\N	f	\N	1199	5	20
Rootes	of Ramsbury in the County of Wilts	\N	\N	2nd L died 16 Jan 1992	1370	2	8	\N	f	\N	1200	5	19
Plowden	of Plowden in the County of Salop	2001-02-15	1	\N	1371	5	8	\N	f	\N	1201	5	17
James of Rusholme	of Fallowfield in the County Palatine of Lancaster	1992-05-16	1	\N	1372	5	8	\N	f	\N	1202	5	11
Netherthorpe	of Anston in the West Riding of the County of York	\N	\N	\N	1373	2	8	\N	f	\N	1203	5	15
Robbins	of Clare Market in the City of Westminster	1984-05-15	1	\N	1375	5	8	\N	f	\N	1204	5	19
Jenkins	of Ashley Gardens in the City of Westminster	1969-07-21	1	vice L Morton of Henryton resigned	1374	1	8	\N	f	\N	1205	5	11
Crathorne	of Crathorne in the North Riding of the County of York	\N	\N	\N	1376	2	8	\N	f	\N	1206	5	4
Forster of Harraby	of Beckenham in the County of Kent	1972-07-24	1	\N	1377	2	8	\N	f	\N	1207	5	7
Spens	of Blairsanquhar in the County of Fife	\N	\N	\N	1378	2	8	\N	f	\N	1208	5	20
Stuart of Findhorn	of Findhorn in the County of Moray	\N	\N	\N	1382	2	12	\N	f	\N	1210	5	20
Craigton	of Renfield in the County of the City of Glasgow	1993-07-28	1	\N	1380	5	8	\N	f	\N	1211	5	4
MacAndrew	of the Firth of Clyde	\N	\N	MacAndrew	1383	2	8	\N	f	\N	1212	5	14
Rochdale	of Rochdale in the County Palatine of Lancaster	\N	\N	\N	1386	7	12	\N	f	\N	1213	5	19
Nelson of Stafford	of Hilcote Hall in the County of Stafford	\N	\N	\N	1387	2	8	\N	f	\N	1214	5	15
Bossom	of Maidstone in the County of Kent	1965-09-04	1	\N	1389	5	8	\N	f	\N	1216	5	3
Howick of Glendale	of Howick in the County of Northumberland	\N	\N	\N	1390	2	8	\N	f	\N	1217	5	9
Sanderson of Ayot	of Welwyn in the County of Hertford	\N	\N	\N	1393	2	8	\N	f	\N	1218	5	20
Gladwyn	of Bramfield in the County of Suffolk	2017-08-15	2	\N	1391	2	8	\N	f	\N	1219	5	8
Slim	of Yarralumla in the Capital Territory of Australia and of Bishopston in the City and County of Bristol	\N	\N	\N	1394	2	12	\N	f	\N	1220	5	20
Shackleton	of Burley in the County of Southampton	1994-09-22	1	\N	1361	5	8	\N	f	\N	1221	5	20
Head	of Throope in the County of Wilts	\N	\N	\N	1395	2	12	\N	f	\N	1222	5	9
Nugent	of West Harling in the County of Norfolk	1973-04-27	1	\N	1396	2	8	\N	f	\N	1223	5	15
Amory	of Tiverton in the County of Devon	1981-01-19	1	\N	1397	2	12	\N	f	\N	1224	5	2
Boyd of Merton	of Merton-in-Penninghame in the County of Wigtown	\N	\N	\N	1398	2	12	\N	f	\N	1225	5	3
Hodson	of Rotherfield Greys in the County of Oxford	1984-03-11	1	vice L Cohen resigned	1399	1	8	\N	f	\N	1226	5	9
Ward of Witley	of Great Witley in the County of Worcester	1988-06-15	1	\N	1400	2	12	\N	f	\N	1227	5	24
Cobbold	of Knebworth in the County of Hertford	\N	\N	\N	1401	2	8	\N	f	\N	1228	5	4
Guest	of Graden in the County of Berwick	1984-09-25	1	vice L Keith of Avonholm resigned	1402	1	8	\N	f	\N	1229	5	8
Twining	of Tanganyika and of Godalming in the County of Surrey	1967-07-21	1	\N	1362	5	8	\N	f	\N	1230	5	21
Horsbrugh	of Horsbrugh in the County of Peebles	1969-12-06	1	\N	1384	5	8	\N	f	\N	1231	5	9
Strathalmond	of Pumpherston in the County of Midlothian	\N	\N	\N	1315	2	8	\N	f	\N	1195	5	20
Fairhaven	of Anglesey Abbey in the County of Cambridge	\N	\N	SR to brother	1418	8	8	\N	f	1	1273	5	7
Boothby	of Buchan and Rattray Head in the County of Aberdeen	1986-07-16	1	\N	1363	5	8	\N	f	\N	1234	5	3
Kilmuir	\N	1967-01-27	1	\N	1438	7	6	\N	t	\N	1271	5	12
Peddie	of the City and County of Kingston upon Hull	1978-04-13	1	\N	1407	5	8	\N	f	\N	1235	5	17
Lindgren	of Welwyn Garden City in the County of Hertford	1971-09-08	1	\N	1408	5	8	\N	f	\N	1236	5	13
Walston	of Newton in the County of Cambridge	1991-05-29	1	\N	1409	5	8	\N	f	\N	1237	5	24
Molson	of High Peak in the County of Derby	1991-10-13	1	\N	1411	5	8	\N	f	\N	1238	5	14
Alport	of Colchester in the County of Essex	1998-10-28	1	\N	1410	5	8	\N	f	\N	1239	5	2
Robens of Woldingham	of Woldingham in the County of Surrey	1999-06-27	1	\N	1413	5	8	\N	f	\N	1240	5	19
Fisher of Lambeth	of Lambeth in the County of London	1972-09-15	1	\N	1412	5	8	\N	f	\N	1241	5	7
Robertson of Oakridge	of Oakridge in the County of Gloucester	\N	\N	\N	1414	2	8	\N	f	\N	1242	5	19
Marks of Broughton	of Sunningdale in the Royal County of Berks	\N	\N	\N	1415	2	8	\N	f	\N	1243	5	14
Devlin	of West Wick in the County of Wilts	1992-08-09	1	\N	1420	1	8	\N	f	\N	1245	5	5
Brain	of Eynsham in the County of Oxford	\N	\N	\N	1422	2	8	\N	f	\N	1246	5	3
Lambury	of Northfield in the County of Warwick	1967-09-13	1	\N	1425	2	8	\N	f	\N	1247	5	13
Inchyra	of Saint Madoes in the County of Perth	\N	\N	\N	1424	2	8	\N	f	\N	1248	5	10
Francis-Williams	of Abinger in the County of Surrey	1970-06-05	1	\N	1427	5	8	\N	f	\N	1249	5	7
Todd	of Trumpington in the County of Cambridge	1997-01-10	1	\N	1428	5	8	\N	f	\N	1250	5	21
Sainsbury	of Drury Lane in the Borough of Holborn	1998-10-21	1	\N	1430	5	8	\N	f	\N	1251	5	20
Pearce	of Sweethaws in the County of Sussex	1990-11-26	1	\N	1429	1	8	\N	f	\N	1252	5	17
Franks	of Headington in the County of Oxford	1992-10-15	1	\N	1431	5	8	\N	f	\N	1253	5	7
Champion	of Pontypridd in the County of Glamorgan	1985-03-02	1	\N	1432	5	8	\N	f	\N	1254	5	4
Williamson	of Eccleston in the Borough of Saint Helens	1983-02-27	1	\N	1434	5	8	\N	f	\N	1256	5	24
Mabane	of Rye in the County of Sussex	1969-11-16	1	\N	1435	2	8	\N	f	\N	1257	5	14
Silsoe	of Silsoe in the County of Bedford	\N	\N	\N	1441	2	8	\N	f	\N	1259	5	20
Dilhorne	of Towcester in the County of Northampton	\N	\N	cr V Dilhorne 1964	1437	2	8	\N	f	\N	1260	5	5
Eccles	of Chute in the County of Wilts	\N	\N	cr V Eccles 1964	1439	2	8	\N	f	\N	1261	5	6
Mills	of Kensington in the County of London	\N	\N	?th V died 6 Dec 1988	1440	7	12	\N	f	\N	1262	5	14
Normanbrook	of Chelsea in the County of London	1967-06-15	1	\N	1442	2	8	\N	f	\N	1263	5	15
Alexander of Hillsborough	\N	1965-01-11	1	\N	1443	7	6	\N	f	\N	1264	5	2
Chelmer	of Margaretting in the County of Essex	1997-03-03	1	\N	1444	5	8	\N	f	\N	1265	5	4
Hill of Luton	of Harpenden in the County of Hertford	1989-08-22	1	\N	1445	5	8	\N	f	\N	1266	5	9
Balerno	of Currie in the County of Midlothian	1984-07-28	1	\N	1446	5	8	\N	f	\N	1267	5	3
Fleck	of Salcoats in the County of Ayr	1968-08-06	1	\N	1404	2	8	\N	f	\N	1268	5	7
Hughes	of Hawkhill in the County of the City of Dundee	1999-12-31	1	\N	1406	5	8	\N	f	\N	1269	5	9
Avon	\N	1985-08-17	2	& V Eden	1417	2	6	\N	t	\N	1270	5	2
Summerskill	of Ken Wood in the County of London	1980-02-04	1	surname also given as Samuel	1405	5	8	\N	f	\N	1272	5	20
Phillips	of Fulham in the County of London	1992-08-14	1	\N	1496	5	8	\N	f	\N	1312	5	17
Upjohn	of Little Tey in the County of Essex	1971-01-27	1	vice L Jenkins resigned	1450	1	8	\N	f	\N	1274	5	22
Gaitskell	of Egremont in the County of Cumberland	1989-07-01	1	\N	1461	5	8	\N	f	\N	1310	5	8
Donovan	of Winchester in the County of Southampton	1971-12-12	1	vice L Devlin resigned	1452	1	8	\N	f	\N	1275	5	5
Eccles	of Chute in the County of Wilts	\N	\N	\N	1454	7	12	\N	f	\N	1276	5	6
Gardiner	of Kittisford in the County of Somerset	1990-01-07	1	\N	1455	5	8	\N	f	\N	1277	5	8
Llewelyn-Davies	of Hastoe in the County of Hertford	1981-10-27	1	\N	1456	5	8	\N	f	\N	1278	5	13
Bowden	of Chesterfield in the County of Derby	1989-07-31	1	\N	1457	5	8	\N	f	\N	1279	5	3
Hobson	of Brent in the County of Middlesex	1966-02-17	1	\N	1458	5	8	\N	f	\N	1280	5	9
Willis	of Chislehurst in the County of Kent	1992-12-22	1	\N	1459	5	8	\N	f	\N	1281	5	24
Tangley	of Blackheath in the County of Surrey	1973-06-05	1	\N	1460	5	8	\N	f	\N	1282	5	21
Thomson of Fleet	of Northbridge in the City of Edinburgh	\N	\N	\N	1462	2	8	\N	f	\N	1283	5	21
Runcorn	of Heswall in the County Palatine of Chester	1968-01-20	1	\N	1463	5	8	\N	f	\N	1284	5	19
Martonmere	of Blackpool in the County Palatine of Lancaster	\N	\N	\N	1464	2	8	\N	f	\N	1285	5	14
Watkinson	of Woking in the County of Surrey	1995-12-19	1	\N	1465	2	12	\N	f	\N	1286	5	24
Muirshiel	of Kilmacolm in the County of Renfrew	1992-08-17	1	\N	1468	2	12	\N	f	\N	1287	5	14
Glendevon	of Midhope in the County of Linlithgow	\N	\N	\N	1469	2	8	\N	f	\N	1288	5	8
Bourne	of Atherstone in the County of Warwick	1982-06-26	1	\N	1471	5	8	\N	f	\N	1290	5	3
Hurd	of Newbury in the Royal County of Berks	1966-02-12	1	\N	1472	5	8	\N	f	\N	1291	5	9
Royle	of Pendleton in the City of Salford	1975-09-30	1	\N	1473	5	8	\N	f	\N	1292	5	19
Rhodes	of Saddleworth in the West Riding of the County of York	1987-09-11	1	\N	1475	5	8	\N	f	\N	1293	5	19
Erskine of Rerrick	of Rerrick in the Stewartry of Kirkcudbright	1995-06-07	2	\N	1474	2	8	\N	f	\N	1295	5	6
Wilberforce	of the City and County of Kingston-upon-Hull	2003-02-15	1	\N	1477	1	8	\N	f	\N	1296	5	24
Mitchison	of Carradale in the County of Argyll	1970-02-14	1	\N	1478	5	8	\N	f	\N	1297	5	14
Dilhorne	of Greens Norton in the County of Northampton	\N	\N	\N	1482	7	12	\N	f	\N	1298	5	5
Caradon	of St Cleer in the County of Cornwall	1990-09-05	1	\N	1479	5	8	\N	f	\N	1299	5	4
Snow	of the City of Leicester	1980-07-01	1	\N	1480	5	8	\N	f	\N	1300	5	20
Chalfont	of Llantarnam in the County of Monmouth	2020-01-10	1	\N	1481	5	8	\N	f	\N	1301	5	4
Grimston of Westbury	of Westbury in the County of Wilts	\N	\N	\N	1485	2	8	\N	f	\N	1302	5	8
Bowles	of Nuneaton in the County of Warwick	1970-12-29	1	\N	1486	5	8	\N	f	\N	1303	5	3
Collison	of Cheshunt in the County of Hertford	1995-12-29	1	\N	1487	5	8	\N	f	\N	1304	5	4
Sorensen	of Leyton in the County of Essex	1971-10-08	1	\N	1488	5	8	\N	f	\N	1305	5	20
Blyton	of South Shields in the County of Durham	1987-10-25	1	\N	1490	5	8	\N	f	\N	1306	5	3
Drumalbyn	of Whitesands in the Royal Burgh of Dumfries	1987-10-11	1	\N	1448	2	8	\N	f	\N	1307	5	5
Wakefield of Kendal	of Kendal in the County of Westmorland	1983-08-12	1	\N	1449	2	8	\N	f	\N	1308	5	24
Emmet of Amberley	of Amberley in the County of Sussex	1980-10-10	1	\N	1484	5	8	\N	f	\N	1309	5	6
Northchurch	of Chiswick in the County of Middlesex	1985-11-25	1	\N	1453	5	8	\N	f	\N	1311	5	15
Stocks	of the Royal Borough of Kensington and Chelsea	1975-07-06	1	\N	1533	5	8	\N	f	\N	1351	5	20
Byers	of Lingfield in the County of Surrey	1984-02-06	1	\N	1499	5	8	\N	f	\N	1314	5	3
Renwick	of Coombe in the County of Surrey	\N	\N	\N	1500	2	8	\N	f	\N	1315	5	19
Wade	of Huddersfield in the West Riding of the County of York	1988-11-06	1	\N	1501	5	8	\N	f	\N	1316	5	24
Arwyn	of Glais in the County of Glamorgan	1978-02-23	1	\N	1502	5	8	\N	f	\N	1317	5	2
Fraser of Allander	of Dineiddwg in the County of Stirling	1987-05-05	2	2nd L disclaimed 1966	1503	2	8	\N	f	\N	1318	5	7
St Helens	of St Helens in the County Palatine of Lancaster	\N	\N	St. Helens	1504	2	8	\N	f	\N	1319	5	20
Margadale	of Islay in the County of Argyll	\N	\N	\N	1505	2	8	\N	f	\N	1320	5	14
Chuter-Ede	of Epsom in the County of Surrey	1965-11-11	1	\N	1506	5	8	\N	f	\N	1321	5	4
Hinton of Bankside	of Dulwich in the County of London	1983-06-22	1	\N	1507	5	8	\N	f	\N	1322	5	9
Holford	of Kemp Town in the County of Sussex	1975-10-17	1	\N	1508	5	8	\N	f	\N	1323	5	9
Cole	of Blackfriars in the County of London	1979-11-29	1	\N	1512	5	8	\N	f	\N	1325	5	4
Pearson	of Minnedosa in Canada and of the Royal Borough of Kensington	1980-01-31	1	\N	1510	1	8	\N	f	\N	1326	5	17
Butler of Saffron Walden	of Halstead in the County of Essex	1982-03-08	1	\N	1511	5	8	\N	f	\N	1327	5	3
Wells-Pestell	of Combs in the County of Suffolk	1991-01-17	1	\N	1514	5	8	\N	f	\N	1328	5	24
Hilton of Upton	of Swaffham in the County of Norfolk	1977-05-03	1	\N	1516	5	8	\N	f	\N	1329	5	9
Caccia	of Abernant in the County of Brecknock	1990-10-31	1	\N	1515	5	8	\N	f	\N	1330	5	4
Simey	of Toxteth in the County Palatine of Lancaster	1969-12-27	1	\N	1518	5	8	\N	f	\N	1332	5	20
Haire of Whiteabbey	of Newtown Abbey in the County of Antrim	1966-10-07	1	\N	1519	5	8	\N	f	\N	1333	5	9
Cohen of Brighton	of Brighton in the County of Sussex	1966-10-21	1	\N	1520	5	8	\N	f	\N	1334	5	4
Winterbottom	of Clopton in the County of Northampton	1992-07-04	1	\N	1521	5	8	\N	f	\N	1335	5	24
Lloyd of Hampstead	of Hampstead in the London Borough of Camden	1992-12-31	1	\N	1522	5	8	\N	f	\N	1336	5	13
Kings Norton	of Wotton Underwood in the County of Buckingham	1997-12-21	1	\N	1524	5	8	\N	f	\N	1337	5	12
Brock	of Wimbledon in the London Borough of Merton	1980-09-03	1	\N	1525	5	8	\N	f	\N	1338	5	3
Kahn	of Hampstead in the London Borough of Camden	1989-06-06	1	\N	1526	5	8	\N	f	\N	1339	5	12
Beeching	of East Grinstead in the County of Sussex	1985-03-23	1	\N	1527	5	8	\N	f	\N	1340	5	3
Annan	of the Royal Burgh of Annan in the County of Dumfries	2000-02-21	1	\N	1528	5	8	\N	f	\N	1341	5	2
Goodman	of the City of Westminster	1995-05-12	1	\N	1529	5	8	\N	f	\N	1342	5	8
King-Hall	of Headley in the County of Southampton	1966-06-02	1	\N	1532	5	8	\N	f	\N	1344	5	12
Wynne-Jones	of Abergele in the County of Denbigh	1982-11-08	1	\N	1492	5	8	\N	f	\N	1345	5	24
Beswick	of Hucknall in the County of Nottingham	1987-08-17	1	\N	1493	5	8	\N	f	\N	1346	5	3
Segal	of Wytham in the Royal County of Berks	1985-06-04	1	\N	1494	5	8	\N	f	\N	1347	5	20
Popplewell	of Sherburn-in-Elmet in the West Riding of the County of York	1977-08-11	1	\N	1540	5	8	\N	f	\N	1348	5	17
Stow Hill	of Newport in the County of Monmouth	1979-01-01	1	\N	1541	5	8	\N	f	\N	1349	5	20
Plummer	of Toppesfield in the County of Essex	1972-06-13	1	\N	1513	5	8	\N	f	\N	1350	5	17
Brown	of Machrihanish in the County of Argyll	1985-03-17	1	\N	1498	5	8	\N	f	\N	1313	5	3
Pargiter	of Southall in the London Borough of Ealing	1982-01-16	1	\N	1542	5	8	\N	f	\N	1352	5	17
Serota	of Hampstead in Greater London	2002-10-21	1	\N	1558	5	8	\N	f	\N	1390	5	20
Redmayne	of Rushcliffe in the County of Nottingham	1983-04-28	1	\N	1543	5	8	\N	f	\N	1353	5	19
Monslow	of Barrow-in-Furness in the County Palatine of Lancaster	1966-10-12	1	\N	1545	5	8	\N	f	\N	1354	5	14
Buckton	of Settrington in the East Riding of the County of York	1978-01-17	1	\N	1546	5	8	\N	f	\N	1355	5	3
Moyle	of Llanidloes in the County of Montgomery	1974-12-23	1	\N	1547	5	8	\N	f	\N	1356	5	14
McFadzean	of Woldingham in the County of Surrey	1996-01-14	1	\N	1548	5	8	\N	f	\N	1357	5	14
Hunt	of Llanvair Waterdine in the County of Salop	1998-11-08	1	\N	1549	5	8	\N	f	\N	1358	5	9
Ritchie-Calder	of Balmashannar in the Royal Burgh of Forfar	1982-01-31	1	\N	1550	5	8	\N	f	\N	1359	5	19
Brooke of Cumnor	of Cumnor in the Royal County of Berks	1984-03-29	1	\N	1552	5	8	\N	f	\N	1361	5	3
Platt	of Grindleford in the County of Derby	1978-06-30	1	\N	1554	5	8	\N	f	\N	1362	5	17
Morris of Grasmere	of Grasmere in the County of Westmorland	1990-05-30	1	\N	1555	5	8	\N	f	\N	1363	5	14
Woolley	of Hatton in the County Palatine of Chester	1986-07-31	1	\N	1556	5	8	\N	f	\N	1364	5	24
Redcliffe-Maud	of the City and County of Bristol	1982-11-20	1	\N	1560	5	8	\N	f	\N	1365	5	19
Penney	of East Hendred in the Royal County of Berks	1991-03-03	1	\N	1561	5	8	\N	f	\N	1366	5	17
Heycock	of Taibach in the Borough of Port Talbot	1990-03-13	1	\N	1562	5	8	\N	f	\N	1367	5	9
Carron	of the City and County of Kingston upon Hull	1969-12-03	1	\N	1563	5	8	\N	f	\N	1368	5	4
Evans of Hungershall	of the Borough of Royal Tunbridge Wells	1982-08-28	1	\N	1564	5	8	\N	f	\N	1369	5	6
Mais	of Walbrook in the City of London	1993-11-28	1	\N	1565	5	8	\N	f	\N	1370	5	14
Hirshfield	of Holborn in Greater London	1993-12-06	1	\N	1567	5	8	\N	f	\N	1371	5	9
McLeavy	of the City of Bradford	1976-10-01	1	\N	1568	5	8	\N	f	\N	1372	5	14
Granville of Eye	of Eye in the County of Suffolk	1998-02-14	1	\N	1569	5	8	\N	f	\N	1373	5	8
Tayside	of Queens Well in the Royal Burgh of Forfar and County of Angus	1975-03-12	1	\N	1570	5	8	\N	f	\N	1374	5	21
Fiske	of Brent in Greater London	1975-01-13	1	\N	1572	5	8	\N	f	\N	1375	5	7
Garnsworthy	of Reigate in the County of Surrey	1974-09-05	1	\N	1573	5	8	\N	f	\N	1376	5	8
Aylestone	of Aylestone in the City of Leicester	1994-04-30	1	\N	1574	5	8	\N	f	\N	1377	5	2
Hill of Wivenhoe	of Wivenhoe in the County of Essex	1969-12-14	1	\N	1575	5	8	\N	f	\N	1378	5	9
Douglass of Cleveland	of Cleveland in the County of York	1978-04-05	1	\N	1576	5	8	\N	f	\N	1379	5	5
Delacourt-Smith	of New Windsor in the Royal County of Berks	1972-08-02	1	\N	1577	5	8	\N	f	\N	1380	5	5
Donaldson of Kingsbridge	of Kingsbridge in the County of Buckingham	1998-03-08	1	\N	1578	5	8	\N	f	\N	1381	5	5
Fulton	of Falmer in the County of Sussex	1986-03-14	1	\N	1535	5	8	\N	f	\N	1382	5	7
Rowley	of Rowley Regis in the County of Stafford	1968-08-28	1	\N	1536	5	8	\N	f	\N	1383	5	19
Wigg	of the Borough of Dudley	1983-08-11	1	\N	1579	5	8	\N	f	\N	1384	5	24
Taylor of Gryfe	of Bridge of Weir in the County of Renfrew	2001-07-13	1	\N	1587	5	8	\N	f	\N	1387	5	21
Trevelyan	of Saint Veep in the County of Cornwall	1985-02-08	1	\N	1588	5	8	\N	f	\N	1388	5	21
Llewelyn-Davies of Hastoe	of Hastoe in the County of Hertford	1997-11-06	1	\N	1566	5	8	\N	f	\N	1389	5	13
Sharp	of Hornsey in Greater London	1985-09-01	1	\N	1553	5	8	\N	f	\N	1391	5	20
Helsby	of Logmore in the County of Surrey	1978-12-05	1	\N	1589	5	8	\N	f	\N	1392	5	9
Tweedsmuir of Belhelvie	of Potterton in the County of Aberdeen	1978-03-11	1	\N	1613	5	8	\N	f	\N	1429	5	21
Balogh	of Hampstead in Greater London	1985-01-20	1	\N	1590	5	8	\N	f	\N	1393	5	3
Black	of Barrow in Furness in the County Palatine of Lancaster	1984-12-27	1	\N	1591	5	8	\N	f	\N	1394	5	3
Crowther	of Headingley in the West Riding of the County of York	1972-02-05	1	\N	1592	5	8	\N	f	\N	1395	5	4
Energlyn	of Caerphilly in the County of Glamorgan	1985-06-27	1	\N	1593	5	8	\N	f	\N	1396	5	6
Jacques	of Portsea Island in the County of Southampton	1995-12-20	1	\N	1594	5	8	\N	f	\N	1397	5	11
Grey of Naunton	of Naunton in the County of Gloucester	1999-10-17	1	\N	1595	5	8	\N	f	\N	1398	5	8
Diplock	of Wansford in the County of Huntingdon and Peterborough	1985-10-14	1	\N	1596	1	8	\N	f	\N	1399	5	5
Stokes	of Leyland in the County Palatine of Lancaster	2008-07-21	1	\N	1597	5	8	\N	f	\N	1400	5	20
Blackett	of Chelsea in Greater London	1974-07-13	1	\N	1598	5	8	\N	f	\N	1401	5	3
Garner	of Chiddingly in the County of Sussex	1983-12-10	1	\N	1599	5	8	\N	f	\N	1402	5	8
Gore-Booth	of Maltby in the West Riding of the County of York	1984-06-29	1	\N	1602	5	8	\N	f	\N	1404	5	8
Bernstein	of Leigh in the County of Kent	1993-02-05	1	\N	1603	5	8	\N	f	\N	1405	5	3
Clark	of Saltwood in the County of Kent	1983-05-21	1	\N	1604	5	8	\N	f	\N	1406	5	4
Ardwick	of Barnes in the London Borough of Richmond upon Thames	1994-08-18	1	\N	1606	5	8	\N	f	\N	1407	5	2
O'Neill of the Maine	of Ahoghill in the County of Antrim	1990-06-12	1	\N	1607	5	8	\N	f	\N	1408	5	16
Kearton	of Whitchurch in the County of Buckingham	1992-07-02	1	\N	1608	5	8	\N	f	\N	1409	5	12
Shinwell	of Easington in the County of Durham	1986-05-08	1	\N	1610	5	8	\N	f	\N	1410	5	20
Janner	of the City of Leicester	1982-05-04	1	\N	1611	5	8	\N	f	\N	1411	5	11
Reigate	of Outwood in the County of Surrey	1995-01-26	1	\N	1614	5	8	\N	f	\N	1413	5	19
Boyle of Handsworth	of Salehurst in the County of Sussex	1981-09-28	1	\N	1615	5	8	\N	f	\N	1414	5	3
Hoy	of Leith in the County of the City of Edinburgh	1976-08-07	1	\N	1616	5	8	\N	f	\N	1415	5	9
Hamnett	of Warrington in the County Palatine of Lancaster	1980-03-17	1	\N	1617	5	8	\N	f	\N	1416	5	9
Rhyl	of Holywell in the parish of Swanmore in the County of Southampton	1981-03-08	1	\N	1618	5	8	\N	f	\N	1417	5	19
Slater	of Ferryhill in the County of Durham	1977-04-21	1	\N	1619	5	8	\N	f	\N	1418	5	20
Fletcher	of Islington in Greater London	1990-06-09	1	\N	1620	5	8	\N	f	\N	1419	5	7
Wheatley	of Shettleston in the County of the City of Glasgow	1988-07-28	1	\N	1621	5	8	\N	f	\N	1420	5	24
Rosenheim	of the London Borough of Camden	1972-12-02	1	\N	1622	5	8	\N	f	\N	1421	5	19
Thorneycroft	of Dunston in the County of Stafford	1994-06-04	1	\N	1581	5	8	\N	f	\N	1422	5	21
Beaumont of Whitley	of Child's Hill in Greater London	2008-04-08	1	\N	1583	5	8	\N	f	\N	1423	5	3
Pilkington	of St Helens in the County Palatine of Lancaster	1983-12-22	1	\N	1584	5	8	\N	f	\N	1424	5	17
George-Brown	of Jevington in the County of Sussex	1985-06-02	1	\N	1630	5	8	\N	f	\N	1425	5	8
Thomas	of Remenham in the Royal County of Berkshire	1980-02-08	1	\N	1631	5	8	\N	f	\N	1426	5	21
Molloy	of Ealing in Greater London	2001-05-26	1	\N	1856	5	8	\N	f	\N	1427	5	14
White	of Rhymney in the County of Monmouth	1999-12-23	1	\N	1627	5	8	\N	f	\N	1430	5	24
Young	of Farnworth in the County Palatine of Lancaster	2002-09-06	1	\N	1643	5	8	\N	f	\N	1470	5	26
Maybray-King	of the City of Southampton	1986-09-03	1	\N	1634	5	8	\N	f	\N	1431	5	14
Seear	of Paddington in the City of Westminster	1997-04-23	1	\N	1641	5	8	\N	f	\N	1468	5	20
Olivier	of Brighton in the County of Sussex	1989-07-11	1	\N	1635	5	8	\N	f	\N	1432	5	16
Cross of Chelsea	of the Royal Borough of Kensington and Chelsea	1989-08-04	1	\N	1636	1	8	\N	f	\N	1433	5	4
Widgery	of South Molton in the County of Devon	1981-07-26	1	\N	1637	5	8	\N	f	\N	1434	5	24
Orr-Ewing	of Little Berkhamsted in the County of Hertford	1999-08-19	1	\N	1638	5	8	\N	f	\N	1435	5	16
Harvey of Prestbury	of Prestbury in the County Palatine of Chester	1994-04-05	1	\N	1639	5	8	\N	f	\N	1436	5	9
Blake	of Braydeston in the County of Norfolk	2003-09-20	1	\N	1640	5	8	\N	f	\N	1437	5	3
Tanlaw	of Tanlawhill in the County of Dumfries	\N	\N	\N	1642	5	8	\N	f	\N	1438	5	21
Zuckerman	of Burnham Thorpe in the County of Norfolk	1993-04-01	1	\N	1645	5	8	\N	f	\N	1439	5	27
Moyola	of Castledawson in the County of Londonderry	2002-05-17	1	\N	1646	5	8	\N	f	\N	1440	5	14
Kilbrandon	of Kilbrandon in the County of Argyll	1989-09-10	1	\N	1647	1	8	\N	f	\N	1441	5	12
Salmon	of Sandwich in the County of Kent	1991-11-07	1	\N	1648	1	8	\N	f	\N	1442	5	20
Adeane	of Stamfordham in the County of Northumberland	1984-04-30	1	\N	1649	5	8	\N	f	\N	1443	5	2
Hale	of Oldham in the County Palatine of Lancaster	1985-05-09	1	\N	1650	5	8	\N	f	\N	1444	5	9
Hewlett	of Swettenham in the County of Chester	1979-07-02	1	\N	1651	5	8	\N	f	\N	1445	5	9
Seebohm	of Hertford in the County of Hertford	1990-12-15	1	\N	1652	5	8	\N	f	\N	1446	5	20
Boyd-Carpenter	of Crux Easton in the County of Southampton	1998-07-11	1	\N	1653	5	8	\N	f	\N	1447	5	3
Elworthy	of Timaru in New Zealand and of Elworthy in the County of Somerset	1993-04-04	1	\N	1655	5	8	\N	f	\N	1448	5	6
Watkins	of Glyntawe in the County of Brecknock	1983-11-02	1	\N	1656	5	8	\N	f	\N	1449	5	24
Samuel of Wych Cross	of Wych Cross in the County of Sussex	1987-08-28	1	\N	1657	5	8	\N	f	\N	1450	5	20
Porritt	of Wanganui in New Zealand and of Hampstead in Greater London	1994-01-01	1	\N	1659	5	8	\N	f	\N	1452	5	17
O'Brien of Lothbury	of the City of London	1995-11-24	1	\N	1660	5	8	\N	f	\N	1453	5	16
Brayley	of the City of Cardiff in the County of Glamorgan	1977-03-16	1	\N	1662	5	8	\N	f	\N	1454	5	3
Hunt of Fawley	of Fawley in the County of Buckingham	1987-12-28	1	\N	1663	5	8	\N	f	\N	1455	5	9
Lloyd of Kilgerran	of Llanwenog in the County of Cardigan	1991-01-30	1	\N	1664	5	8	\N	f	\N	1456	5	13
Ashby	of Brandon in the County of Suffolk	1992-10-22	1	\N	1665	5	8	\N	f	\N	1457	5	2
Greenwood of Rossendale	of East Mersea in the County of Essex	1982-04-12	1	\N	1624	5	8	\N	f	\N	1459	5	8
Diamond	of the City of Gloucester	2004-04-03	1	\N	1625	5	8	\N	f	\N	1460	5	5
Davies of Leek	of Leek in the County of Stafford	1985-10-28	1	\N	1626	5	8	\N	f	\N	1461	5	5
Goronwy-Roberts	of Caernarvon and of Ogwen in the County of Caernarvon	1981-07-22	1	\N	1672	5	8	\N	f	\N	1462	5	8
Harris of Greenwich	of Greenwich in Greater London	2001-04-11	1	\N	1673	5	8	\N	f	\N	1463	5	9
Duncan-Sandys	of the City of Westminster	1987-11-26	1	\N	1674	5	8	\N	f	\N	1464	5	5
Glenkinglas	of Cairndow in the County of Argyll	1984-05-15	1	\N	1675	5	8	\N	f	\N	1465	5	8
Geoffrey-Lloyd	of Broomfield in the County of Kent	1984-09-12	1	\N	1676	5	8	\N	f	\N	1466	5	8
Elles	of the City of Westminster	2009-10-17	1	\N	1654	5	8	\N	f	\N	1467	5	6
Sharples	of Chawton in Hampshire	\N	\N	\N	1661	5	8	\N	f	\N	1469	5	20
Robson of Kiddington	of Kiddington in Oxfordshire	1999-02-09	1	\N	1682	5	8	\N	f	\N	1508	5	19
Stedman	of Longthorpe in the City of Peterborough	1996-06-08	1	\N	1691	5	8	\N	f	\N	1509	5	20
Marples	of Wallasey in the County of Merseyside	1978-07-06	1	\N	1678	5	8	\N	f	\N	1471	5	14
Hornsby-Smith	of Chislehurst in Greater London	1985-07-03	1	\N	1681	5	8	\N	f	\N	1506	5	9
Tranmire	of Upsall in the County of North Yorkshire	1994-01-17	1	\N	1679	5	8	\N	f	\N	1472	5	21
Mackie of Benshie	of Kirriemuir in the County of Angus	2015-02-17	1	\N	1680	5	8	\N	f	\N	1473	5	14
Wigoder	of Cheetham in the City of Manchester	2004-08-12	1	\N	1684	5	8	\N	f	\N	1474	5	24
Castle	of Islington in Greater London	1979-12-26	1	\N	1686	5	8	\N	f	\N	1476	5	4
Fisher of Camden	of Camden in Greater London	1979-10-12	1	\N	1687	5	8	\N	f	\N	1477	5	7
Houghton of Sowerby	of Sowerby in the County of West Yorkshire	1996-05-02	1	\N	1688	5	8	\N	f	\N	1478	5	9
Pannell	of the City of Leeds	1980-03-23	1	\N	1689	5	8	\N	f	\N	1479	5	17
Harvington	of Nantwich in Cheshire	1997-01-01	1	\N	1690	5	8	\N	f	\N	1480	5	9
Lovell-Davis	of Highgate in Greater London	2001-01-06	1	\N	1692	5	8	\N	f	\N	1481	5	13
Kissin	of Camden in Greater London	1997-11-22	1	\N	1693	5	8	\N	f	\N	1482	5	12
Lee of Newton	of Newton in the County of Merseyside	1984-02-04	1	\N	1695	5	8	\N	f	\N	1484	5	13
Darling of Hillsborough	of Crewe in Cheshire	1985-10-18	1	\N	1697	5	8	\N	f	\N	1485	5	5
Gordon-Walker	of Leyton in Greater London	1980-12-02	1	\N	1698	5	8	\N	f	\N	1486	5	8
Davies of Penrhys	of Rhondda in the County of Mid Glamorgan	1992-04-28	1	\N	1700	5	8	\N	f	\N	1487	5	5
Kaldor	of Newnham in the City of Cambridge	1986-09-30	1	\N	1701	5	8	\N	f	\N	1488	5	12
Allen of Fallowfield	of Fallowfield in Greater Manchester	1985-01-14	1	\N	1702	5	8	\N	f	\N	1489	5	2
Wolfenden	of Westcott in the County of Surrey	1985-01-18	1	\N	1704	5	8	\N	f	\N	1490	5	24
Edmund-Davies	of Aberpennar in the County of Mid Glamorgan	1992-12-27	1	\N	1706	1	8	\N	f	\N	1491	5	6
Ramsey of Canterbury	of Canterbury in the County of Kent	1988-04-23	1	\N	1707	5	8	\N	f	\N	1492	5	19
Paget of Northampton	of Lubenham in Leicestershire	1990-01-02	1	\N	1709	5	8	\N	f	\N	1493	5	17
Ashdown	of Chelwood in the County of East Sussex	1977-07-23	1	\N	1710	5	8	\N	f	\N	1494	5	2
Barber	of Wentbridge in West Yorkshire	2005-12-16	1	\N	1711	5	8	\N	f	\N	1495	5	3
Banks	of Kenton in Greater London	1997-06-15	1	\N	1712	5	8	\N	f	\N	1496	5	3
Feather	of the City of Bradford	1976-07-28	1	\N	1669	5	8	\N	f	\N	1497	5	7
Trend	of Greenwich in Greater London	1987-07-21	1	\N	1670	5	8	\N	f	\N	1498	5	21
Elwyn-Jones	of Llanelli in the County of Carmarthen and of Newham in Greater London	1989-12-04	1	\N	1671	5	8	\N	f	\N	1499	5	6
Wilson of Radcliffe	of Radcliffe in Lancashire	1983-01-25	1	\N	1717	5	8	\N	f	\N	1500	5	24
Briginshaw	of Southwark in Greater London	1992-03-27	1	\N	1719	5	8	\N	f	\N	1501	5	3
Wallace of Coslany	of Coslany in the City of Norwich	2003-11-11	1	\N	1720	5	8	\N	f	\N	1502	5	24
Bruce of Donington	of Rickmansworth in Hertfordshire	2005-04-18	1	\N	1721	5	8	\N	f	\N	1503	5	3
Greene of Harrow Weald	of Harrow in Greater London	2004-07-26	1	\N	1722	5	8	\N	f	\N	1504	5	8
Fisher of Rednal	of Rednal in the City of Birmingham	2005-12-18	1	\N	1696	5	8	\N	f	\N	1505	5	7
Pike	of Melton in Leicestershire	2004-01-11	1	\N	1683	5	8	\N	f	\N	1507	5	17
Lyons of Brighton	of Brighton in the County of East Sussex	1978-01-18	1	\N	1723	5	8	\N	f	\N	1511	5	13
Vickers	of Devonport in the County of Devon	1994-05-23	1	\N	1726	5	8	\N	f	\N	1549	5	23
Plurenden	of Plurenden Manor in the County of Kent	1978-01-05	1	\N	1727	5	8	\N	f	\N	1513	5	17
Armstrong of Sanderstead	of the City of Westminster	1980-07-12	1	\N	1728	5	8	\N	f	\N	1514	5	2
Pritchard	of West Haddon in Northamptonshire	1995-10-16	1	\N	1729	5	8	\N	f	\N	1515	5	17
Gibson	of Penn's Rocks in the County of East Sussex	2004-04-20	1	\N	1730	5	8	\N	f	\N	1516	5	8
Lever	of Ardwick in the City of Manchester	1977-07-26	1	never introduced	1732	5	8	\N	f	\N	1517	5	13
Gregson	of Stockport in Greater Manchester	2009-08-12	1	\N	1733	5	8	\N	f	\N	1518	5	8
Barnetson	of Crowborough in the County of East Sussex	1981-03-12	1	\N	1734	5	8	\N	f	\N	1519	5	3
Jacobson	of St Albans in Hertfordshire	1988-08-13	1	\N	1736	5	8	\N	f	\N	1521	5	11
Kirkhill	of Kirkhill in the District of the City of Aberdeen	\N	\N	\N	1737	5	8	\N	f	\N	1522	5	12
Russell of Killowen	of Killowen in the County of Down	1986-06-23	1	\N	1738	1	8	\N	f	\N	1523	5	19
Brookes	of West Bromwich in the County of West Midlands	2002-07-31	1	\N	1739	5	8	\N	f	\N	1524	5	3
Carr of Hadley	of Monken Hadley in Greater London	2012-02-17	1	\N	1740	5	8	\N	f	\N	1525	5	4
Bradwell	of Bradwell juxta Mare in the County of Essex	1976-08-12	1	\N	1741	5	8	\N	f	\N	1526	5	3
McCarthy	of Headington in the City of Oxford	2012-11-18	1	\N	1742	5	8	\N	f	\N	1527	5	14
Northfield	of Telford in the County of Salop	2013-04-18	1	\N	1743	5	8	\N	f	\N	1528	5	15
Parry	of Neyland in the County of Dyfed	2004-09-01	1	\N	1744	5	8	\N	f	\N	1529	5	17
Oram	of Brighton in the County of East Sussex	1999-09-04	1	\N	1745	5	8	\N	f	\N	1530	5	16
Winstanley	of Urmston in Greater Manchester	1993-07-18	1	\N	1746	5	8	\N	f	\N	1531	5	24
Schon	of Whitehaven in the County of Cumbria	1995-01-07	1	\N	1748	5	8	\N	f	\N	1532	5	20
Brimelow	of Tyldesley in the County of Lancashire	1995-08-02	1	\N	1749	5	8	\N	f	\N	1533	5	3
Bullock	of Leafield in the County of Oxfordshire	2004-02-02	1	\N	1750	5	8	\N	f	\N	1534	5	3
Wilson of High Wray	of Kendal in the County of Cumbria	1980-02-24	1	\N	1751	5	8	\N	f	\N	1535	5	24
Wall	of Coombe in Greater London	1980-12-29	1	\N	1752	5	8	\N	f	\N	1536	5	24
Selwyn-Lloyd	of Wirral in the County of Merseyside	1978-05-17	1	\N	1753	5	8	\N	f	\N	1537	5	20
Grade	of Elstree in the County of Hertfordshire	1998-12-13	1	\N	1754	5	8	\N	f	\N	1538	5	8
Vaizey	of Greenwich in Greater London	1984-07-19	1	\N	1755	5	8	\N	f	\N	1539	5	23
Stone	of Hendon in Greater London	1986-07-17	1	\N	1756	5	8	\N	f	\N	1540	5	20
Fraser of Tullybelton	of Bankfoot in the County of Perth	1989-02-17	1	\N	1716	1	8	\N	f	\N	1541	5	7
Britten	of Aldeburgh in the County of Suffolk	1976-12-04	1	never introduced	1762	5	8	\N	f	\N	1542	5	3
Allen of Abbeydale	of the City of Sheffield	2007-11-27	1	\N	1763	5	8	\N	f	\N	1543	5	2
Briggs	of Lewes in the County of East Sussex	2016-03-15	1	\N	1764	5	8	\N	f	\N	1544	5	3
Rayne	of Prince's Meadow in Greater London	2003-10-10	1	\N	1765	5	8	\N	f	\N	1545	5	19
Peart	of Workington in the County of Cumbria	1988-08-26	1	\N	1766	5	8	\N	f	\N	1546	5	17
Jackson of Lodsworth	of Lodsworth in the County of West Sussex	1981-05-31	1	\N	1768	5	8	\N	f	\N	1548	5	11
Ward of North Tyneside	of North Tyneside in the County of Tyne and Wear	1980-04-26	1	\N	1724	5	8	\N	f	\N	1550	5	24
Glenamara	of Glenridding in the County of Cumbria	2012-05-04	1	\N	1770	5	8	\N	f	\N	1551	5	8
Lockwood	of Dewsbury in the County of West Yorkshire	2019-04-29	1	\N	1784	5	8	\N	f	\N	1589	5	13
Baker	of Windrush in the County of Gloucestershire	1985-09-09	1	\N	1771	5	8	\N	f	\N	1552	5	3
Faulkner of Downpatrick	of Downpatrick in the County of Down	1977-03-03	1	\N	1772	5	8	\N	f	\N	1553	5	7
Saint Brides	of Hasguard in the County of Dyfed	1989-11-26	1	\N	1773	5	8	\N	f	\N	1554	5	20
Carver	of Shackleford in the County of Surrey	2001-12-09	1	\N	1775	5	8	\N	f	\N	1556	5	4
Roll of Ipsden	of Ipsden in the County of Oxfordshire	2005-03-30	1	\N	1777	5	8	\N	f	\N	1558	5	19
Wedderburn of Charlton	of Highgate in Greater London	2012-03-09	1	\N	1778	5	8	\N	f	\N	1559	5	24
Noel-Baker	of the City of Derby	1982-10-08	1	\N	1779	5	8	\N	f	\N	1560	5	15
Croham	of the London Borough of Croydon	2011-09-11	1	\N	1782	5	8	\N	f	\N	1561	5	4
Scarman	of Quatt in the County of Salop	2004-12-08	1	\N	1780	1	8	\N	f	\N	1562	5	20
McGregor of Durris	of Hampstead in Greater London	1997-11-10	1	\N	1783	5	8	\N	f	\N	1563	5	14
Young of Dartington	of Dartington in the County of Devon	2002-01-14	1	\N	1785	5	8	\N	f	\N	1564	5	26
Cockfield	of Dover in the County of Kent	2007-01-08	1	\N	1786	5	8	\N	f	\N	1565	5	4
Rawlinson of Ewell	of Ewell in the County of Surrey	2006-06-28	1	\N	1787	5	8	\N	f	\N	1566	5	19
Soames	of Fletching in the County of East Sussex	1987-09-16	1	\N	1788	5	8	\N	f	\N	1567	5	20
Howie of Troon	of Troon in the District of Kyle and Carrick	2018-05-26	1	\N	1789	5	8	\N	f	\N	1568	5	9
Evans of Claughton	of Claughton in the County of Merseyside	1992-03-22	1	\N	1790	5	8	\N	f	\N	1569	5	6
Whaddon	of Whaddon in the County of Cambridgeshire	2005-08-16	1	\N	1791	5	8	\N	f	\N	1570	5	24
Leonard	of the City of Cardiff in the County of South Glamorgan	1983-07-17	1	\N	1793	5	8	\N	f	\N	1571	5	13
Sefton of Garston	of Garston in the County of Merseyside	2001-09-09	1	\N	1794	5	8	\N	f	\N	1572	5	20
Taylor of Blackburn	of Blackburn in the County of Lancashire	2016-11-25	1	\N	1795	5	8	\N	f	\N	1573	5	21
Hatch of Lusby	of Oldfield in the County of West Yorkshire	1992-10-11	1	\N	1796	5	8	\N	f	\N	1574	5	9
Plant	of Benenden in the County of Kent	1986-08-09	1	\N	1797	5	8	\N	f	\N	1575	5	17
Mishcon	of Lambeth in Greater London	2006-01-27	1	\N	1798	5	8	\N	f	\N	1576	5	14
Donnet of Balgay	of Balgay in the District of the City of Dundee	1985-05-15	1	\N	1801	5	8	\N	f	\N	1577	5	5
Delfont	of Stepney in Greater London	1994-07-28	1	\N	1759	5	8	\N	f	\N	1578	5	5
Kagan	of Elland in the County of West Yorkshire	1995-01-17	1	\N	1760	5	8	\N	f	\N	1579	5	12
Boston of Faversham	of Faversham in the County of Kent	2011-07-23	1	\N	1761	5	8	\N	f	\N	1580	5	3
Richardson	of Lee in the County of Devon	2004-08-15	1	\N	1808	5	8	\N	f	\N	1581	5	19
Miles	of Blackfriars in the City of London	1991-06-14	1	\N	1810	5	8	\N	f	\N	1583	5	14
Scanlon	of Davyhulme in the County of Greater Manchester	2004-01-27	1	\N	1812	5	8	\N	f	\N	1584	5	20
Flowers	of Queen's Gate in the City of Westminster	2010-06-25	1	\N	1813	5	8	\N	f	\N	1585	5	7
Bellwin	of the City of Leeds	2001-02-11	1	\N	1814	5	8	\N	f	\N	1586	5	3
Lever of Manchester	of Cheetham in the City of Manchester	1995-08-06	1	\N	1815	5	8	\N	f	\N	1587	5	13
Denington	of Stevenage in the County of Hertfordshire	1998-08-22	1	\N	1802	5	8	\N	f	\N	1588	5	5
Ryder of Warsaw	of Warsaw in Poland and of Cavendish in the County of Suffolk	2000-11-02	1	\N	1807	5	8	\N	f	\N	1590	5	19
McFarlane of Llandaff	of Llandaff in the County of South Glamorgan	2012-05-13	1	\N	1832	5	8	\N	f	\N	1627	5	14
Skrimshire of Quarter	of Dunipace in the District of Falkirk	1979-11-07	1	\N	1838	5	8	\N	f	\N	1628	5	20
Trumpington	of Sandwich in the County of Kent	2018-11-26	1	\N	1840	5	8	\N	f	\N	1629	5	21
Stewart of Fulham	of Fulham in Greater London	1990-03-10	1	\N	1816	5	8	\N	f	\N	1591	5	20
Jeger	of St Pancras in Greater London	2007-02-26	1	\N	1821	5	8	\N	f	\N	1625	5	11
Mackay of Clashfern	of Eddrachillis in the District of Sutherland	\N	\N	\N	1817	5	8	\N	f	\N	1592	5	14
Irving of Dartford	of Dartford in the County of Kent	1989-12-18	1	\N	1819	5	8	\N	f	\N	1594	5	10
Galpern	of Shettleston in the District of the City of Glasgow	1993-09-23	1	\N	1820	5	8	\N	f	\N	1595	5	8
Renton	of Huntingdon in the County of Cambridgeshire	2007-05-24	1	\N	1822	5	8	\N	f	\N	1596	5	19
Godber of Willington	of Willington in the County of Bedfordshire	1980-08-25	1	\N	1823	5	8	\N	f	\N	1597	5	8
Underhill	of Leyton in Greater London	1993-03-12	1	\N	1824	5	8	\N	f	\N	1598	5	22
Cledwyn of Penrhos	of Holyhead in the Isle of Anglesey	2001-02-22	1	\N	1825	5	8	\N	f	\N	1599	5	4
Brooks of Tremorfa	of Tremorfa in the County of South Glamorgan	2016-03-04	1	\N	1826	5	8	\N	f	\N	1600	5	3
Harris of High Cross	of Tottenham in Greater London	2006-10-19	1	\N	1828	5	8	\N	f	\N	1601	5	9
Ross of Marnock	of Kilmarnock in the District of Kilmarnock and Loudoun	1988-06-10	1	\N	1829	5	8	\N	f	\N	1602	5	19
Murton of Lindisfarne	of Hexham in the County of Northumberland	2009-07-05	1	\N	1830	5	8	\N	f	\N	1603	5	14
Holderness	of Bishop Wilton in the County of Humberside	2002-08-11	1	\N	1834	5	8	\N	f	\N	1604	5	9
Gibson-Watt	of the Wye District of Radnor	2002-02-07	1	\N	1835	5	8	\N	f	\N	1605	5	8
Dacre of Glanton	of Glanton in the County of Northumberland	2003-01-26	1	\N	1836	5	8	\N	f	\N	1606	5	5
Lane	of St Ippollitts in the County of Hertfordshire	2005-08-21	1	\N	1837	1	8	\N	f	\N	1607	5	13
Coggan	of Canterbury and of Sissinghurst in the County of Kent	2000-05-17	1	\N	1839	5	8	\N	f	\N	1608	5	4
Keith of Castleacre	of Swaffham in the County of Norfolk	2004-09-01	1	\N	1841	5	8	\N	f	\N	1609	5	12
Hunt of Tanworth	of Stratford-upon-Avon in the County of Warwickshire	2008-07-17	1	\N	1842	5	8	\N	f	\N	1610	5	9
Emslie	of Potterton in the District of Gordon	2002-11-20	1	\N	1843	5	8	\N	f	\N	1611	5	6
Sieff of Brimpton	of Brimpton in the Royal County of Berkshire	2001-02-23	1	\N	1844	5	8	\N	f	\N	1612	5	20
Hunter of Newington	of Newington in the District of the City of Edinburgh	1994-03-24	1	\N	1804	5	8	\N	f	\N	1613	5	9
Roskill	of Newtown in the County of Hampshire	1996-10-04	1	\N	1846	1	8	\N	f	\N	1614	5	19
Reilly	of Brompton in the Royal Borough of Kensington and Chelsea	1990-10-11	1	\N	1805	5	8	\N	f	\N	1615	5	19
Blease	of Cromac in the City of Belfast	2008-05-16	1	\N	1806	5	8	\N	f	\N	1616	5	3
Swann	of Coln St Denys in the County of Gloucestershire	1990-09-22	1	\N	1854	5	8	\N	f	\N	1618	5	20
Tordoff	of Knutsford in the County of Cheshire	2019-06-22	1	\N	1855	5	8	\N	f	\N	1619	5	21
Jenkins of Putney	of Wandsworth in Greater London	2004-01-26	1	\N	1857	5	8	\N	f	\N	1620	5	11
John-Mackie	of Nazeing in the County of Essex	1994-05-26	1	surname changed from Mackie	1858	5	8	\N	f	\N	1621	5	11
Bishopston	of Newark in the County of Nottinghamshire	1984-04-19	1	\N	1860	5	8	\N	f	\N	1622	5	3
Beloff	of Wolvercote in the County of Oxfordshire	1999-03-22	1	\N	1862	5	8	\N	f	\N	1623	5	3
Ewart-Biggs	of Ellis Green in the County of Essex	1992-10-08	1	\N	1861	5	8	\N	f	\N	1624	5	6
Elystan-Morgan	of Aberteifi in the County of Dyfed	2021-07-07	1	\N	1863	5	8	\N	f	\N	1630	5	6
Nicol	of Newnham in the County of Cambridgeshire	2018-01-15	1	\N	1886	5	8	\N	f	\N	1668	5	15
Stodart of Leaston	of Humbie in the District of East Lothian	2003-05-31	1	\N	1866	5	8	\N	f	\N	1632	5	20
Thomas of Swynnerton	of Notting Hill in Greater London	2017-05-07	1	\N	1868	5	8	\N	f	\N	1633	5	21
Mayhew	of Wimbledon in Greater London	1997-01-07	1	\N	1870	5	8	\N	f	\N	1634	5	14
Marsh	of Mannington in the County of Wiltshire	2011-07-29	1	\N	1871	5	8	\N	f	\N	1635	5	14
Constantine of Stanmore	of Stanmore in Greater London	2004-02-13	1	\N	1872	5	8	\N	f	\N	1636	5	4
Kadoorie	of Kowloon in Kong Kong and of the City of Westminster	1993-08-25	1	\N	1873	5	8	\N	f	\N	1637	5	12
Forte	of Ripley in the County of Surrey	2007-02-28	1	\N	1875	5	8	\N	f	\N	1638	5	7
Cayzer	of St Mary Axe in the City of London	1999-04-16	1	\N	1876	5	8	\N	f	\N	1639	5	4
Brandon of Oakbrook	of Hammersmith in Greater London	1999-03-24	1	\N	1874	1	8	\N	f	\N	1640	5	3
Bancroft	of Coatham in the County of Cleveland	1996-11-19	1	\N	1877	5	8	\N	f	\N	1641	5	3
Brightman	of Ibthorpe in the County of Hampshire	2006-02-06	1	\N	1878	1	8	\N	f	\N	1642	5	3
MacLehose of Beoch	of Maybole in the District of Kyle and Carrick and of Victoria in Hong Kong	2000-05-27	1	MacLehose of Beoch	1879	5	8	\N	f	\N	1643	5	14
Pennock	of Norton in the County of Cleveland	1993-02-23	1	\N	1881	5	8	\N	f	\N	1644	5	17
Gormley	of Ashton-in-Makerfield in Greater Manchester	1993-05-27	1	\N	1882	5	8	\N	f	\N	1645	5	8
Templeman	of White Lackington in the County of Somerset	2014-06-04	1	retired 30 Sep 1994	1883	1	8	\N	f	\N	1646	5	21
Lewin	of Greenwich in Greater London	1999-01-23	1	\N	1884	5	8	\N	f	\N	1647	5	13
McIntosh of Haringey	of Haringey in Greater London	2010-08-27	1	\N	1885	5	8	\N	f	\N	1648	5	14
Taylor of Hadfield	of Hadfield in the County of Derbyshire	1995-02-15	1	\N	1888	5	8	\N	f	\N	1649	5	21
Ingrow	of Keighley in the County of West Yorkshire	2002-02-07	1	\N	1889	5	8	\N	f	\N	1650	5	10
Ezra	of Horsham in the County of West Sussex	2015-12-22	1	\N	1890	5	8	\N	f	\N	1651	5	6
Rayner	of Crowborough in the County of East Sussex	1998-06-26	1	\N	1891	5	8	\N	f	\N	1652	5	19
Marshall of Leeds	of Shadwell in the City of Leeds	1990-11-01	1	\N	1848	5	8	\N	f	\N	1653	5	14
Weinstock	of Bowden in the County of Wiltshire	2002-07-23	1	\N	1849	5	8	\N	f	\N	1654	5	24
Benson	of Drovers in the County of West Sussex	1995-03-05	1	\N	1853	5	8	\N	f	\N	1655	5	3
Gallacher	of Enfield in Greater London	2004-01-04	1	\N	1897	5	8	\N	f	\N	1656	5	8
Hanson	of Edgerton in the County of West Yorkshire	2004-11-01	1	\N	1899	5	8	\N	f	\N	1657	5	9
Whitelaw	of Penrith in the County of Cumbria	1999-07-01	1	\N	1898	2	12	\N	f	\N	1658	5	24
King of Wartnaby	of Wartnaby in the County of Leicestershire	2005-07-12	1	\N	1903	5	8	\N	f	\N	1660	5	12
Gray of Contin	of Contin in the District of Ross and Cromarty	2006-03-14	1	\N	1901	5	8	\N	f	\N	1661	5	8
Tonypandy	of Rhondda in the County of Mid Glamorgan	1997-09-22	1	\N	1902	2	12	\N	f	\N	1662	5	21
Blanch	of Bishopthorpe in the County of North Yorkshire	1994-06-03	1	\N	1904	5	8	\N	f	\N	1663	5	3
Stallard	of St Pancras in the London Borough of Camden	2008-03-29	1	\N	1905	5	8	\N	f	\N	1664	5	20
Ennals	of Norwich in the County of Norfolk	1995-06-17	1	\N	1906	5	8	\N	f	\N	1665	5	6
Graham of Edmonton	of Edmonton in Greater London	2020-03-20	1	\N	1907	5	8	\N	f	\N	1666	5	8
Cox	of Queensbury in Greater London	\N	\N	\N	1887	5	8	\N	f	\N	1667	5	4
Warnock	of Weeke in the City of Winchester	2019-03-20	1	\N	1930	5	8	\N	f	\N	1708	5	24
Wilson of Rievaulx	of Kirklees in the County of West Yorkshire	1995-05-24	1	\N	1909	5	8	\N	f	\N	1671	5	24
Maude of Stratford-upon-Avon	of Stratford-upon-Avon in the County of Warwickshire	1993-11-09	1	\N	1910	5	8	\N	f	\N	1672	5	14
Broxbourne	of Broxbourne in the County of Hertfordshire	1992-01-22	1	\N	1911	5	8	\N	f	\N	1673	5	3
Kaberry of Adel	of Adel in the City of Leeds	1991-03-13	1	\N	1912	5	8	\N	f	\N	1674	5	12
Fanshawe of Richmond	of South Cerney in the County of Gloucestershire	2001-12-28	1	\N	1913	5	8	\N	f	\N	1675	5	7
Dean of Beswick	of West Leeds in the County of West Yorkshire	1999-02-26	1	\N	1914	5	8	\N	f	\N	1676	5	5
Barnett	of Heywood and Royton in Greater Manchester	2014-11-01	1	\N	1915	5	8	\N	f	\N	1677	5	3
Eden of Winton	of Rushyford in the County of Durham	2020-05-23	1	\N	1916	5	8	\N	f	\N	1678	5	6
Bruce-Gardyne	of Kirkden in the District of Angus	1990-04-15	1	\N	1918	5	8	\N	f	\N	1680	5	3
Carmichael of Kelvingrove	of Camlachie in the District of the City of Glasgow	2001-07-19	1	\N	1919	5	8	\N	f	\N	1681	5	4
Grimond	of Firth in the County of Orkney	1993-10-24	1	\N	1920	5	8	\N	f	\N	1682	5	8
Fitt	of Bell's Hill in the County of Down	2005-08-26	1	\N	1921	5	8	\N	f	\N	1683	5	7
Mulley	of Manor Park in the City of Sheffield	1995-03-15	1	\N	1922	5	8	\N	f	\N	1684	5	14
Bottomley	of Middlesbrough in the County of Cleveland	1995-11-03	1	\N	1923	5	8	\N	f	\N	1685	5	3
Chapple	of Hoxton in Greater London	2004-10-19	1	\N	1929	5	8	\N	f	\N	1686	5	4
Cameron of Lochbroom	of Lochbroom in the District of Ross and Cromarty	\N	\N	\N	1927	5	8	\N	f	\N	1687	5	4
Young of Graffham	of Graffham in the County of West Sussex	\N	\N	\N	1928	5	8	\N	f	\N	1688	5	26
Vinson	of Roddam Dene in the County of Northumberland	\N	\N	\N	1931	5	8	\N	f	\N	1689	5	23
Kimball	of Easton in the County of Leicestershire	2014-03-27	1	\N	1933	5	8	\N	f	\N	1691	5	12
Silkin of Dulwich	of North Leigh in the County of Oxfordshire	1988-08-17	1	\N	1934	5	8	\N	f	\N	1692	5	20
Butterworth	of Warwick in the County of Warwickshire	2003-06-19	1	\N	1935	5	8	\N	f	\N	1693	5	3
Prys-Davies	of Llanegryn in the County of Gwynedd	2017-03-28	1	\N	1893	5	8	\N	f	\N	1694	5	17
Bauer	of Market Ward in the City of Cambridge	2002-05-03	1	\N	1894	5	8	\N	f	\N	1695	5	3
Cameron of Balhousie	of Balhousie in the District of Perth and Kinross	1985-01-29	1	\N	1896	5	8	\N	f	\N	1696	5	4
Griffiths	of Govilon in the County of Gwent	2015-05-30	1	\N	1940	1	8	\N	f	\N	1697	5	8
Morton of Shuna	of Stockbridge in the District of the City of Edinburgh	1995-04-26	1	\N	1942	5	8	\N	f	\N	1698	5	14
Sanderson of Bowden	of Melrose in the District of Ettrick and Lauderdale	\N	\N	\N	1943	5	8	\N	f	\N	1699	5	20
Wolfson	of Marylebone in the City of Westminster	2010-05-20	1	\N	1945	5	8	\N	f	\N	1700	5	24
Mellish	of Bermondsey in Greater London	1998-05-09	1	\N	1946	5	8	\N	f	\N	1701	5	14
Marshall of Goring	of South Stoke in the County of Oxfordshire	1996-02-20	1	\N	1947	5	8	\N	f	\N	1702	5	14
Dainton	of Hallam Moors in South Yorkshire	1997-12-05	1	\N	1951	5	8	\N	f	\N	1703	5	5
Ackner	of Sutton in the County of West Sussex	2006-03-21	1	resigned 30 Sep 1992	1948	1	8	\N	f	\N	1704	5	2
Oliver of Aylmerton	of Aylmerton in the County of Norfolk	2007-10-17	1	\N	1949	1	8	\N	f	\N	1705	5	16
Hooper	of Liverpool and of St James's in the City of Westminster	\N	\N	\N	1944	5	8	\N	f	\N	1706	5	9
Stoddart of Swindon	of Reading in the Royal County of Berkshire	2020-11-14	1	\N	1908	5	8	\N	f	\N	1670	5	20
Goff of Chieveley	of Chieveley in the Royal County of Berkshire	2016-08-14	1	\N	1950	1	8	\N	f	\N	1709	5	8
Blatch	of Hinchingbrooke in the County of Cambridgeshire	2005-05-31	1	\N	1967	5	8	\N	f	\N	1746	5	3
Bonham-Carter	of Yarnbury in the County of Wiltshire	1994-09-04	1	\N	1952	5	8	\N	f	\N	1710	5	3
Moore of Wolvercote	of Wolvercote in the City of Oxford	2009-04-07	1	\N	1953	5	8	\N	f	\N	1711	5	14
Deedes	of Aldington in the County of Kent	2007-08-17	1	\N	1955	5	8	\N	f	\N	1712	5	5
Wyatt of Weeford	of Weeford in the County of Staffordshire	1997-12-07	1	\N	1956	5	8	\N	f	\N	1713	5	24
Bramall	of Bushfield in the County of Hampshire	2019-11-12	1	\N	1957	5	8	\N	f	\N	1714	5	3
Carter	of Devizes in the County of Wiltshire	2006-12-18	1	\N	1959	5	8	\N	f	\N	1715	5	4
Peston	of Mile End in Greater London	2016-04-23	1	\N	1960	5	8	\N	f	\N	1716	5	17
Irvine of Lairg	of Lairg in the District of Sutherland	\N	\N	\N	1961	5	8	\N	f	\N	1717	5	10
Stevens of Ludgate	of Ludgate in the City of London	\N	\N	\N	1962	5	8	\N	f	\N	1718	5	20
Basnett	of Leatherhead in the County of Surrey	1989-01-25	1	\N	1964	5	8	\N	f	\N	1719	5	3
Trafford	of Falmer in the County of East Sussex	1989-09-16	1	\N	1965	5	8	\N	f	\N	1720	5	21
Plumb	of Coleshill in the County of Warwickshire	\N	\N	\N	1966	5	8	\N	f	\N	1721	5	17
Goold	of Waterfoot in the District of Eastwood	1997-07-27	1	\N	1968	5	8	\N	f	\N	1722	5	8
Chilver	of Cranfield in the County of Bedfordshire	2012-07-08	1	\N	1970	5	8	\N	f	\N	1723	5	4
Thomas of Gwydir	of Llanrwst in the County of Gwynedd	2008-02-04	1	\N	1974	5	8	\N	f	\N	1726	5	21
Jay	of Battersea in Greater London	1996-03-06	1	\N	1975	5	8	\N	f	\N	1727	5	11
Pym	of Sandy in the County of Bedfordshire	2008-03-07	1	\N	1976	5	8	\N	f	\N	1728	5	17
Joseph	of Portsoken in the City of London	1994-12-10	1	\N	1977	5	8	\N	f	\N	1729	5	11
Prior	of Brampton in the County of Suffolk	2016-12-12	1	\N	1979	5	8	\N	f	\N	1731	5	17
Crawshaw of Aintree	of Salford in the County of Greater Manchester	1986-07-16	1	\N	1937	5	8	\N	f	\N	1732	5	4
Donoughue	of Ashton in the County of Northamptonshire	\N	\N	\N	1938	5	8	\N	f	\N	1733	5	5
Williams of Elvel	of Llansantffraed in Elvel in the County of Powys	2019-12-30	1	\N	1939	5	8	\N	f	\N	1734	5	24
Jenkin of Roding	of Wanstead and Woodford in Greater London	2016-12-20	1	\N	1985	5	8	\N	f	\N	1735	5	11
Ross of Newport	of Newport in the County of the Isle of Wight	1993-05-10	1	\N	1986	5	8	\N	f	\N	1736	5	19
Callaghan of Cardiff	of the City of Cardiff in the County of South Glamorgan	2005-03-26	1	\N	1987	5	8	\N	f	\N	1737	5	4
Rees	of Goytre in the County of Gwent	2008-11-30	1	\N	1988	5	8	\N	f	\N	1738	5	19
Jenkins of Hillhead	of Pontypool in the County of Gwent	2003-01-05	1	\N	1989	5	8	\N	f	\N	1739	5	11
Jakobovits	of Regent's Park in Greater London	1999-10-31	1	\N	1990	5	8	\N	f	\N	1740	5	11
Donaldson of Lymington	of Lymington in the County of Hampshire	2005-08-31	1	\N	1993	5	8	\N	f	\N	1741	5	5
Jauncey of Tullichettle	of Comrie in the District of Perth and Kinross	2007-07-18	1	retired 30.9.1996	1992	1	8	\N	f	\N	1742	5	11
Armstrong of Ilminster	of Ashill in the County of Somerset	2020-04-03	1	\N	1994	5	8	\N	f	\N	1743	5	2
Alexander of Weedon	of Newcastle-under-Lyme in the County of Staffordshire	2005-11-06	1	\N	1995	5	8	\N	f	\N	1744	5	2
York	\N	\N	\N	\N	1954	2	4	\N	t	\N	1745	5	26
Hart of South Lanark	of Lanark in the County of Lanark	1991-12-08	1	\N	1991	5	8	\N	f	\N	1747	5	9
Hamwee	of Richmond upon Thames in the London Borough of Richmond upon Thames	\N	\N	\N	2040	5	8	\N	f	\N	1783	5	9
Hollis of Heigham	of Heigham in the City of Norwich	2018-10-13	1	\N	2021	5	8	\N	f	\N	1784	5	9
Oppenheim-Barnes	of Gloucester in the County of Gloucestershire	\N	\N	\N	2002	5	8	\N	f	\N	1785	5	16
Seccombe	of Kineton in the County of Warwickshire	\N	\N	\N	2037	5	8	\N	f	\N	1786	5	20
Rees-Mogg	of Hinton Blewitt in the County of Avon	2012-12-29	1	\N	1996	5	8	\N	f	\N	1748	5	19
Eccles of Moulton	of Moulton in the County of North Yorkshire	\N	\N	\N	2012	5	8	\N	f	\N	1781	5	6
Butterfield	of Stechford in the County of West Midlands	2000-07-22	1	\N	1997	5	8	\N	f	\N	1749	5	3
Mackenzie-Stuart	of Dean in the District of the City of Edinburgh	2000-04-01	1	\N	1998	5	8	\N	f	\N	1750	5	14
Macaulay of Bragar	of Bragar in the County of Ross and Cromarty	2014-06-12	1	\N	1999	5	8	\N	f	\N	1751	5	14
Sainsbury of Preston Candover	of Preston Candover in the County of Hampshire	\N	\N	\N	2000	5	8	\N	f	\N	1752	5	20
Lewis of Newnham	of Newnham in the County of Cambridgeshire	2014-07-17	1	\N	2001	5	8	\N	f	\N	1753	5	13
Sharp of Grimsdyke	of Stanmore in the London Borough of Harrow	1994-05-02	1	\N	2004	5	8	\N	f	\N	1754	5	20
Fraser of Carmyllie	of Carmyllie in the District of Angus	2013-06-22	1	\N	2003	5	8	\N	f	\N	1755	5	7
Walton of Detchant	of Detchant in the County of Northumberland	2016-04-21	1	\N	2005	5	8	\N	f	\N	1756	5	24
McColl of Dulwich	of Bermondsey in the London Borough of Southwark	\N	\N	\N	2006	5	8	\N	f	\N	1757	5	14
Fieldhouse	of Gosport in the County of Hampshire	1992-02-17	1	\N	2007	5	8	\N	f	\N	1758	5	7
Tombs	of Brailes in the County of Warwickshire	2020-04-11	1	\N	2009	5	8	\N	f	\N	1759	5	21
Morris of Castle Morris	of St Dogmaels in the County of Dyfed	2001-04-30	1	\N	2011	5	8	\N	f	\N	1760	5	14
Richard	of Ammanford in the County of Dyfed	2018-03-18	1	\N	2013	5	8	\N	f	\N	1761	5	19
Wade of Chorlton	of Chester in the County of Cheshire	2018-06-07	1	\N	2014	5	8	\N	f	\N	1762	5	24
Cavendish of Furness	of Cartmel in the County of Cumbria	\N	\N	\N	2015	5	8	\N	f	\N	1763	5	4
Varley	of Chesterfield in the County of Derbyshire	2008-07-29	1	\N	2020	5	8	\N	f	\N	1766	5	23
Mason of Barnsley	of Barnsley in South Yorkshire	2015-04-19	1	\N	1983	5	8	\N	f	\N	1767	5	14
Carlisle of Bucklow	of Mobberley in the County of Cheshire	2005-07-14	1	\N	1984	5	8	\N	f	\N	1768	5	4
Haslam	of Bolton in the County of Greater Manchester	2002-11-02	1	\N	2027	5	8	\N	f	\N	1769	5	9
Sterling of Plaistow	of Pall Mall in the City of Westminster	\N	\N	\N	2030	5	8	\N	f	\N	1770	5	20
Waddington	of Read in the County of Lancashire	2017-02-24	1	\N	2029	5	8	\N	f	\N	1771	5	24
White of Hull	of Hull in the County of Humberside	1995-08-23	1	\N	2031	5	8	\N	f	\N	1772	5	24
Runcie	of Cuddesdon in the County of Oxfordshire	2000-07-11	1	\N	2032	5	8	\N	f	\N	1773	5	19
Palumbo	of Walbrook in the City of London	\N	\N	\N	2033	5	8	\N	f	\N	1774	5	17
Griffiths of Fforestfach	of Fforestfach in the County of West Glamorgan	\N	\N	\N	2034	5	8	\N	f	\N	1775	5	8
Laing of Dunphail	of Dunphail in the District of Moray	2010-06-21	1	\N	2036	5	8	\N	f	\N	1776	5	13
Wolfson of Sunningdale	of Trevose in the County of Cornwall	2021-03-10	1	\N	2038	5	8	\N	f	\N	1777	5	24
Desai	of St Clement Danes in the City of Westminster	\N	\N	\N	2039	5	8	\N	f	\N	1778	5	5
Marlesford	of Marlesford in the County of Suffolk	\N	\N	\N	2041	5	8	\N	f	\N	1779	5	14
Cumberlege	of Newick in the County of East Sussex	\N	\N	\N	2016	5	8	\N	f	\N	1780	5	4
Flather	of Windsor and Maidenhead in the Royal County of Berkshire	\N	\N	\N	2022	5	8	\N	f	\N	1782	5	7
O'Cathain	of The Barbican in the City of London	2021-04-23	1	\N	2047	5	8	\N	f	\N	1823	5	16
Perry of Southwark	of Charlbury in the County of Oxfordshire	\N	\N	\N	2051	5	8	\N	f	\N	1824	5	17
Thatcher	of Kesteven in the County of Lincolnshire	2013-04-08	1	\N	2066	5	8	\N	f	\N	1825	5	21
Judd	of Portsea in the County of Hampshire	2021-04-17	1	\N	2042	5	8	\N	f	\N	1787	5	11
Hilton of Eggardon	of Eggardon in the County of Dorset	\N	\N	\N	2044	5	8	\N	f	\N	1821	5	9
Hollick	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2046	5	8	\N	f	\N	1788	5	9
Renfrew of Kaimsthorn	of Hurlet in the District of Renfrew	\N	\N	\N	2048	5	8	\N	f	\N	1789	5	19
Skidelsky	of Tilton in the County of East Sussex	\N	\N	\N	2050	5	8	\N	f	\N	1791	5	20
Cheshire	of Woodhall in the County of Lincolnshire	1992-07-31	1	\N	2052	5	8	\N	f	\N	1792	5	4
Craig of Radley	of Helhoughton in the County of Norfolk	\N	\N	\N	2054	5	8	\N	f	\N	1794	5	4
Browne-Wilkinson	of Camden in the London Borough of Camden	2018-07-25	1	\N	2055	1	8	\N	f	\N	1795	5	3
Mustill	of Pateley Bridge in the County of North Yorkshire	2015-04-24	1	\N	2056	1	8	\N	f	\N	1796	5	14
Rix	of Whitehall in the City of Westminster and of Hornsea in Yorkshire	2016-08-20	1	\N	2057	5	8	\N	f	\N	1797	5	19
Prentice	of Daventry in the County of Northamptonshire	2001-01-18	1	\N	2058	5	8	\N	f	\N	1798	5	17
Wilson of Tillyorn	of Finzean in the District of Kincardine and Deeside and of Fanling in Hong Kong	\N	\N	\N	2060	5	8	\N	f	\N	1799	5	24
Slynn of Hadley	of Eggington in the County of Bedfordshire	2009-04-07	1	vice L Bridge of Harwich resigned	2061	1	8	\N	f	\N	1800	5	20
Wakeham	of Maldon in the County of Essex	\N	\N	\N	2062	5	8	\N	f	\N	1801	5	24
Taylor of Gosforth	of Embleton in the County of Northumberland	1997-04-28	1	\N	2064	5	8	\N	f	\N	1802	5	21
Rodger of Earlsferry	of Earlsferry in the District of North East Fife	2011-06-26	1	\N	2065	5	8	\N	f	\N	1803	5	19
Porter of Luddenham	of Luddenham in the County of Kent	2002-08-31	1	\N	2024	5	8	\N	f	\N	1804	5	17
Lane of Horsell	of Woking in the County of Surrey	2009-01-09	1	\N	2026	5	8	\N	f	\N	1805	5	13
Lawson of Blaby	of Newnham in the County of Northamptonshire	\N	\N	\N	2072	5	8	\N	f	\N	1806	5	13
Howell	of Aston Manor in the City of Birmingham	1998-04-19	1	\N	2074	5	8	\N	f	\N	1807	5	9
Moore of Lower Marsh	of Lower Marsh in the London Borough of Lambeth	2019-05-20	1	\N	2075	5	8	\N	f	\N	1808	5	14
Tebbit	of Chingford in the London Borough of Waltham Forest	\N	\N	\N	2076	5	8	\N	f	\N	1809	5	21
Younger of Prestwick	of Ayr in the District of Kyle and Carrick	2003-01-26	1	succeeded 25 June 1997 as 4th V Younger of Leckie	2077	5	8	\N	f	\N	1810	5	26
Amery of Lustleigh	of Preston in the County of Lancashire and of Brighton in the County of East Sussex	1996-09-03	1	\N	2078	5	8	\N	f	\N	1811	5	2
Walker of Worcester	of Abbots Morton in the County of Hereford and Worcester	2010-06-23	1	\N	2079	5	8	\N	f	\N	1812	5	24
Archer of Sandwell	of Sandwell in the County of West Midlands	2012-06-14	1	\N	2080	5	8	\N	f	\N	1813	5	2
Ashley of Stoke	of Widnes in the County of Cheshire	2012-04-20	1	\N	2081	5	8	\N	f	\N	1814	5	2
Eatwell	of Stratton St Margaret in the County of Wiltshire	\N	\N	\N	2082	5	8	\N	f	\N	1815	5	6
Weatherill	of North East Croydon in the London Borough of Croydon	2007-05-06	1	\N	2083	5	8	\N	f	\N	1816	5	24
Ewing of Kirkford	of Cowdenbeath in the District of Dunfermline	2007-06-09	1	\N	2084	5	8	\N	f	\N	1817	5	6
Geraint	of Ponterwyd in the County of Dyfed	2004-04-17	1	\N	2085	5	8	\N	f	\N	1818	5	8
Chalker of Wallasey	of Leigh-on-Sea in the County of Essex	\N	\N	\N	2063	5	8	\N	f	\N	1819	5	4
Mallalieu	of Studdridge in the County of Buckinghamshire	\N	\N	\N	2045	5	8	\N	f	\N	1822	5	14
Thomas of Walliswood	of Dorking in the County of Surrey	\N	\N	\N	2128	5	8	\N	f	\N	1863	5	21
Williams of Crosby	of Stevenage in the County of Hertfordshire	2021-04-12	1	\N	2100	5	8	\N	f	\N	1864	5	24
Stewartby	of Portmoak in the District of Perth and Kinross	2018-03-03	1	\N	2086	5	8	\N	f	\N	1826	5	20
Jay of Paddington	of Paddington in the City of Westminster	\N	\N	dau of L Callaghan of Cardiff	2091	5	8	\N	f	\N	1861	5	11
Clark of Kempston	of Kempston in the County of Bedfordshire	2004-10-04	1	\N	2087	5	8	\N	f	\N	1827	5	4
Plant of Highfield	of Weelsby in the County of Humberside	\N	\N	\N	2088	5	8	\N	f	\N	1828	5	17
Archer of Weston-Super-Mare	of Mark in the County of Somerset	\N	\N	\N	2089	5	8	\N	f	\N	1829	5	2
Ridley of Liddesdale	of Willimontswick in the County of Northumberland	1993-03-04	1	\N	2090	5	8	\N	f	\N	1830	5	19
Williams of Mostyn	of Great Tew in the County of Oxfordshire	2003-09-20	1	\N	2092	5	8	\N	f	\N	1831	5	24
Braine of Wheatley	of Rayleigh in the County of Essex	2000-01-05	1	\N	2093	5	8	\N	f	\N	1832	5	3
Barber of Tewkesbury	of Gotherington in the County of Gloucestershire	2017-11-21	1	\N	2095	5	8	\N	f	\N	1834	5	3
Hayhoe	of Isleworth in the London Borough of Hounslow	2013-09-07	1	\N	2096	5	8	\N	f	\N	1835	5	9
Kingsdown	of Pemberton in the County of Lancashire	2013-11-24	1	\N	2101	5	8	\N	f	\N	1837	5	12
Dahrendorf	of Clare Market in the City of Westminster	2009-06-17	1	\N	2102	5	8	\N	f	\N	1838	5	5
Menuhin	of Stoke d'Abernon in the County of Surrey	1999-03-12	1	\N	2103	5	8	\N	f	\N	1839	5	14
Attenborough	of Richmond upon Thames in the London Borough of Richmond upon Thames	2014-08-24	1	\N	2104	5	8	\N	f	\N	1840	5	2
Lloyd of Berwick	of Ludlay in the County of East Sussex	\N	\N	vice L Griffiths	2105	1	8	\N	f	\N	1841	5	13
Haskel	of Higher Broughton in the County of Greater Manchester	\N	\N	\N	2106	5	8	\N	f	\N	1842	5	9
Dean of Harptree	of Wedmore in the County of Somerset	2009-04-01	1	\N	2107	5	8	\N	f	\N	1843	5	5
Dixon-Smith	of Bocking in the County of Essex	\N	\N	\N	2109	5	8	\N	f	\N	1844	5	5
Parkinson	of Carnforth in the County of Lancashire	2016-01-22	1	\N	2068	5	8	\N	f	\N	1845	5	17
Healey	of Riddlesden in the County of West Yorkshire	2015-10-03	1	\N	2069	5	8	\N	f	\N	1846	5	9
Owen	of the City of Plymouth	\N	\N	\N	2070	5	8	\N	f	\N	1847	5	16
Nolan	of Brasted in the County of Kent	2007-01-22	1	vice L Lowry resigned	2114	1	8	\N	f	\N	1848	5	15
Wright of Richmond	of Richmond upon Thames in the London Borough of Richmond upon Thames	2020-03-06	1	\N	2115	5	8	\N	f	\N	1849	5	24
Nickson	of Renagour in the District of Stirling	\N	\N	\N	2116	5	8	\N	f	\N	1850	5	15
Quirk	of Bloomsbury in the London Borough of Camden	2017-12-20	1	\N	2117	5	8	\N	f	\N	1851	5	18
Phillips of Ellesmere	of Ellesmere in the County of Shropshire	1999-02-23	1	\N	2118	5	8	\N	f	\N	1852	5	17
Sheppard of Didgemere	of Roydon in the County of Essex	2015-03-25	1	\N	2119	5	8	\N	f	\N	1853	5	20
Hambro	of Dixton and Dumbleton in the County of Gloucestershire	2002-11-07	1	\N	2120	5	8	\N	f	\N	1854	5	9
Dubs	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2121	5	8	\N	f	\N	1855	5	5
Shaw of Northstead	of Liversedge in the County of West Yorkshire	2021-01-08	1	\N	2124	5	8	\N	f	\N	1856	5	20
Tope	of Sutton in the London Borough of Sutton	\N	\N	\N	2126	5	8	\N	f	\N	1857	5	21
Kingsland	of Shrewsbury in the County of Shropshire	2009-07-12	1	\N	2129	5	8	\N	f	\N	1858	5	12
Gould of Potternewton	of Leeds in the County of West Yorkshire	\N	\N	\N	2108	5	8	\N	f	\N	1860	5	8
Rawlings	of Burnham Westgate in the County of Norfolk	\N	\N	\N	2127	5	8	\N	f	\N	1862	5	19
Miller of Hendon	of Gore in the London Borough of Barnet	2014-06-21	1	\N	2112	5	8	\N	f	\N	1901	5	14
Ramsay of Cartvale	of Langside in the City of Glasgow	\N	\N	\N	2169	5	8	\N	f	\N	1902	5	19
Smith of Gilmorehill	of Gilmorehill in the District of the City of Glasgow	\N	\N	\N	2134	5	8	\N	f	\N	1903	5	20
Symons of Vernham Dean	of Vernham Dean in the County of Hampshire	\N	\N	\N	2166	5	8	\N	f	\N	1904	5	20
Wilcox	of Plymouth in the County of Devon	\N	\N	\N	2151	5	8	\N	f	\N	1905	5	24
Steyn	of Swafield in the County of Norfolk	2017-11-28	1	\N	2131	1	8	\N	f	\N	1865	5	20
Hayman	of Dartmouth Park in the London Borough of Camden	\N	\N	\N	2146	5	8	\N	f	\N	1898	5	9
McConnell	of Lisburn in the County of Antrim	2000-10-25	1	\N	2133	5	8	\N	f	\N	1866	5	14
Hoffmann	of Chedworth in the County of Gloucestershire	\N	\N	\N	2135	1	8	\N	f	\N	1867	5	9
Blyth of Rowington	of Rowington in the County of Warwickshire	\N	\N	\N	2137	5	8	\N	f	\N	1868	5	3
Cuckney	of Millbank in the City of Westminster	2008-10-30	1	\N	2138	5	8	\N	f	\N	1869	5	4
Eames	of Armagh in the County of Armagh	\N	\N	\N	2139	5	8	\N	f	\N	1870	5	6
Habgood	of Calverton in the County of Buckinghamshire	2019-03-06	1	\N	2140	5	8	\N	f	\N	1871	5	9
Winston	of Hammersmith in the London Borough of Hammersmith and Fulham	\N	\N	\N	2142	5	8	\N	f	\N	1873	5	24
Wallace of Saltaire	of Shipley in the County of West Yorkshire	\N	\N	\N	2143	5	8	\N	f	\N	1874	5	24
McNally	of Blackpool in the County of Lancashire	\N	\N	\N	2144	5	8	\N	f	\N	1875	5	14
Sewel	of Gilcomstoun in the District of the City of Aberdeen	\N	\N	\N	2147	5	8	\N	f	\N	1877	5	20
Harris of Peckham	of Peckham in the London Borough of Southwark	\N	\N	\N	2148	5	8	\N	f	\N	1878	5	9
Blackwell	of Woodcote in the County of Surrey	\N	\N	\N	2224	5	8	\N	f	\N	1879	5	3
Feldman	of Frognal in the London Borough of Camden	2019-11-19	1	\N	2150	5	8	\N	f	\N	1880	5	7
Bowness	of Warlingham in the County of Surrey and of Croydon in the London Borough of Croydon	\N	\N	\N	2152	5	8	\N	f	\N	1881	5	3
Taverne	of Pimlico in the City of Westminster	\N	\N	\N	2153	5	8	\N	f	\N	1882	5	21
Lester of Herne Hill	of Herne Hill in the London Borough of Southwark	2020-08-08	1	\N	2111	5	8	\N	f	\N	1883	5	13
Tugendhat	of Widdington in the County of Essex	\N	\N	\N	2113	5	8	\N	f	\N	1884	5	21
Vincent of Coleshill	of Shrivenham in the County of Oxfordshire	2018-09-08	1	\N	2159	5	8	\N	f	\N	1885	5	23
Hussey of North Bradley	of North Bradley in the County of Wiltshire	2006-12-27	1	\N	2160	5	8	\N	f	\N	1886	5	9
Thomas of Gresford	of Gresford in the County Borough of Wrexham	\N	\N	\N	2161	5	8	\N	f	\N	1887	5	21
Clyde	of Briglands in Perthshire and Kinross	2009-03-06	1	vice L Jauncey of Tullichettle	2162	1	8	\N	f	\N	1888	5	4
Currie of Marylebone	of Marylebone in the City of Westminster	\N	\N	\N	2163	5	8	\N	f	\N	1889	5	4
Taylor of Warwick	of Warwick in the County of Warwickshire	\N	\N	\N	2164	5	8	\N	f	\N	1890	5	21
Saatchi	of Staplefield in the County of West Sussex	\N	\N	\N	2165	5	8	\N	f	\N	1891	5	20
Alderdice	of Knock in the City of Belfast	\N	\N	\N	2167	5	8	\N	f	\N	1892	5	2
Paul	of Marylebone in the City of Westminster	\N	\N	\N	2168	5	8	\N	f	\N	1893	5	17
Chadlington	of Dean in the County of Oxfordshire	\N	\N	\N	2172	5	8	\N	f	\N	1894	5	4
MacLaurin of Knebworth	of Knebworth in the County of Hertfordshire	\N	\N	\N	2174	5	8	\N	f	\N	1895	5	14
Whitty	of Camberwell in the London Borough of Southwark	\N	\N	\N	2175	5	8	\N	f	\N	1896	5	24
Byford	of Rothley in the County of Leicestershire	\N	\N	\N	2171	5	8	\N	f	\N	1897	5	3
Hogg	of Kettlethorpe in the County of Lincolnshire	\N	\N	\N	2132	5	8	\N	f	\N	1899	5	9
Lestor of Eccles	of Tooting Bec in the London Borough of Wandsworth	1998-03-27	1	\N	2186	5	8	\N	f	\N	1943	5	13
Ludford	of Clerkenwell in the London Borough of Islington	\N	\N	\N	2219	5	8	\N	f	\N	1944	5	13
Lloyd-Webber	of Sydmonton in the County of Hampshire	\N	\N	\N	2179	5	8	\N	f	\N	1907	5	13
Fookes	of Plymouth in the County of Devon	\N	\N	\N	2220	5	8	\N	f	\N	1941	5	7
Hoyle	of Warrington in the County of Cheshire	\N	\N	\N	2180	5	8	\N	f	\N	1908	5	9
Simon of Highbury	of Canonbury in the London Borough of Islington	\N	\N	\N	2182	5	8	\N	f	\N	1910	5	20
Gilbert	of Dudley in the County of West Midlands	2013-06-02	1	\N	2183	5	8	\N	f	\N	1911	5	8
Biffen	of Tanat in the County of Shropshire	2007-08-14	1	\N	2185	5	8	\N	f	\N	1912	5	3
Hardie	of Blackford in the City of Edinburgh	\N	\N	\N	2184	5	8	\N	f	\N	1913	5	9
Jopling	of Ainderby Quernhow in the County of North Yorkshire	\N	\N	\N	2187	5	8	\N	f	\N	1914	5	11
Shore of Stepney	of Stepney in the London Borough of Tower Hamlets	2001-09-24	1	\N	2188	5	8	\N	f	\N	1915	5	20
Howell of Guildford	of Penton Mewsey in the County of Hampshire	\N	\N	\N	2189	5	8	\N	f	\N	1916	5	9
Steel of Aikwood	of Ettrick Forest in The Scottish Borders	\N	\N	\N	2190	5	8	\N	f	\N	1917	5	20
Dixon	of Jarrow in the County of Tyne and Wear	2017-02-19	1	\N	2191	5	8	\N	f	\N	1918	5	5
Evans of Parkside	of St Helens in the County of Merseyside	2016-03-05	1	\N	2193	5	8	\N	f	\N	1920	5	6
Molyneaux of Killead	of Killead in the County of Antrim	2015-03-09	1	\N	2194	5	8	\N	f	\N	1921	5	14
Kelvedon	of Ongar in the County of Essex	2007-01-27	1	\N	2196	5	8	\N	f	\N	1922	5	12
Gillmore of Thamesfield	of Putney in the London Borough of Wandsworth	1999-03-20	1	\N	2155	5	8	\N	f	\N	1923	5	8
Cooke of Thorndon	of Wellington in New Zealand and of Cambridge in the County of Cambridgeshire	2006-08-30	1	New Zealand judge	2156	5	8	\N	f	\N	1924	5	4
Bingham of Cornhill	of Boughrood in the County of Powys	2010-09-11	1	\N	2157	5	8	\N	f	\N	1925	5	3
Inge	of Richmond in the County of North Yorkshire	\N	\N	\N	2203	5	8	\N	f	\N	1926	5	10
Russell-Johnston	of Minginish in Highland	2008-07-27	1	surname changed from "Johnston" after announcement	2204	5	8	\N	f	\N	1927	5	19
Levene of Portsoken	of Portsoken in the City of London	\N	\N	\N	2205	5	8	\N	f	\N	1928	5	13
Saville of Newdigate	of Newdigate in the County of Surrey	\N	\N	vice L Mustill resigned	2206	1	8	\N	f	\N	1929	5	20
Levy	of Mill Hill in the London Borough of Barnet	\N	\N	\N	2207	5	8	\N	f	\N	1930	5	13
Hogg of Cumbernauld	of Cumbernauld in North Lanarkshire	2008-10-08	1	\N	2210	5	8	\N	f	\N	1931	5	9
Newby	of Rothwell in the County of West Yorkshire	\N	\N	\N	2211	5	8	\N	f	\N	1932	5	15
Renwick of Clifton	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2213	5	8	\N	f	\N	1933	5	19
Walker of Doncaster	of Audenshaw in the County of Greater Manchester	2003-11-11	1	\N	2214	5	8	\N	f	\N	1934	5	24
Hardy of Wath	of Wath upon Dearne in the County of South Yorkshire	2003-12-16	1	\N	2215	5	8	\N	f	\N	1935	5	9
Hughes of Woodside	of Woodside in the City of Aberdeen	\N	\N	\N	2216	5	8	\N	f	\N	1936	5	9
Selkirk of Douglas	of Cramond in the City of Edinburgh	\N	\N	\N	2217	5	8	\N	f	\N	1937	5	20
Lang of Monkton	of Merrick and the Rhinns of Kells in Dumfries and Galloway	\N	\N	\N	2218	5	8	\N	f	\N	1938	5	13
Davies of Coity	of Penybont in the County of Mid Glamorgan	2019-03-04	1	\N	2221	5	8	\N	f	\N	1939	5	5
Emerton	of Tunbridge Wells in the County of Kent and of Clerkenwell in the London Borough of Islington	\N	\N	\N	2178	5	8	\N	f	\N	1940	5	6
Knight of Collingtree	of Collingtree in the County of Northamptonshire	\N	\N	\N	2208	5	8	\N	f	\N	1942	5	12
Young of Old Scone	of Old Scone in Perth and Kinross	\N	\N	\N	2258	5	8	\N	f	\N	1984	5	26
Roberts of Conwy	of Talyfan in the County of Gwynedd	2013-12-13	1	\N	2222	5	8	\N	f	\N	1945	5	19
Sandberg	of Passfield in the County of Hampshire	2017-07-02	1	\N	2223	5	8	\N	f	\N	1946	5	20
Davies of Oldham	of Broxbourne in the County of Hertfordshire	\N	\N	\N	2226	5	8	\N	f	\N	1948	5	5
Gordon of Strathblane	of Deil's Craig in Stirling	2020-03-31	1	\N	2227	5	8	\N	f	\N	1949	5	8
Cope of Berkeley	of Berkeley in the County of Gloucestershire	\N	\N	\N	2228	5	8	\N	f	\N	1950	5	4
Morris of Manchester	of Manchester in the County of Greater Manchester	2012-08-12	1	\N	2230	5	8	\N	f	\N	1951	5	14
Jacobs	of Belgravia in the City of Westminster	2014-06-21	1	\N	2231	5	8	\N	f	\N	1952	5	11
Hunt of Kings Heath	of Birmingham in the County of West Midlands	\N	\N	\N	2232	5	8	\N	f	\N	1953	5	9
Hunt of Wirral	of Wirral in the County of Merseyside	\N	\N	\N	2233	5	8	\N	f	\N	1954	5	9
Orme	of Salford in the County of Greater Manchester	2005-04-28	1	\N	2234	5	8	\N	f	\N	1955	5	16
Razzall	of Mortlake in the London Borough of Richmond	\N	\N	\N	2236	5	8	\N	f	\N	1957	5	19
Goodhart	of Youlbury in the County of Oxfordshire	2017-01-10	1	\N	2238	5	8	\N	f	\N	1958	5	8
Brooke of Alverthorpe	of Alverthorpe in the County of West Yorkshire	\N	\N	\N	2239	5	8	\N	f	\N	1959	5	3
Dholakia	of Waltham Brooks in the County of West Sussex	\N	\N	\N	2241	5	8	\N	f	\N	1960	5	5
Islwyn	of Casnewydd in the County of Gwent	2003-12-19	1	\N	2243	5	8	\N	f	\N	1961	5	10
Hurd of Westwell	of Westwell in the County of Oxfordshire	\N	\N	\N	2199	5	8	\N	f	\N	1962	5	9
Baker of Dorking	of Iford in the County of East Sussex	\N	\N	\N	2200	5	8	\N	f	\N	1963	5	3
Patten	of Wincanton in the County of Somerset	\N	\N	\N	2201	5	8	\N	f	\N	1964	5	17
Stone of Blackheath	of Blackheath in the London Borough of Greenwich	\N	\N	\N	2248	5	8	\N	f	\N	1965	5	20
Freeman	of Dingley in the County of Northamptonshire	\N	\N	\N	2249	5	8	\N	f	\N	1966	5	7
Onslow of Woking	of Woking in the County of Surrey	2001-03-13	1	\N	2252	5	8	\N	f	\N	1967	5	16
Montague of Oxford	of Oxford in the County of Oxfordshire	1999-11-05	1	\N	2254	5	8	\N	f	\N	1968	5	14
Bassam of Brighton	of Brighton in the County of East Sussex	\N	\N	\N	2256	5	8	\N	f	\N	1969	5	3
Smith of Clifton	of Mountsandel in the County of Londonderry	2021-04-24	1	\N	2259	5	8	\N	f	\N	1970	5	20
Thomas of Macclesfield	of Prestbury in the County of Cheshire	2018-07-01	1	\N	2260	5	8	\N	f	\N	1971	5	21
Simpson of Dunkeld	of Dunkeld in Perth and Kinross	\N	\N	\N	2261	5	8	\N	f	\N	1972	5	20
Filkin	of Pimlico in the City of Westminster	\N	\N	\N	2339	5	8	\N	f	\N	1973	5	7
Monro of Langholm	of Westerkirk in Dumfries and Galloway	2006-08-30	1	\N	2262	5	8	\N	f	\N	1974	5	14
Watson of Invergowrie	of Invergowrie in Perth and Kinross	\N	\N	\N	2263	5	8	\N	f	\N	1975	5	24
Ryder of Wensum	of Wensum in the County of Norfolk	\N	\N	\N	2264	5	8	\N	f	\N	1976	5	19
Hattersley	of Sparkbrook in the County of West Midlands	\N	\N	\N	2265	5	8	\N	f	\N	1977	5	9
Neill of Bladen	of Briantspuddle in the County of Dorset	2016-05-28	1	\N	2266	5	8	\N	f	\N	1978	5	15
Butler of Brockwell	of Herne Hill in the London Borough of Lambeth	\N	\N	\N	2267	5	8	\N	f	\N	1979	5	3
Hamlyn	of Edgeworth in the County of Gloucestershire	2001-08-31	1	\N	2270	5	8	\N	f	\N	1980	5	9
Pitkeathley	of Caversham in the Royal County of Berkshire	\N	\N	\N	2229	5	8	\N	f	\N	1981	5	17
Scotland of Asthal	of Asthal in the County of Oxfordshire	\N	\N	\N	2251	5	8	\N	f	\N	1983	5	20
Kennedy of The Shaws	of Cathcart in the City of Glasgow	\N	\N	\N	2245	5	8	\N	f	\N	2018	5	12
Miller of Chilthorne Domer	of Chilthorne Domer in the County of Somerset	\N	\N	\N	2287	5	8	\N	f	\N	2019	5	14
O'Neill of Bengarve	of The Braid in the County of Antrim	\N	\N	\N	2308	5	8	\N	f	\N	2020	5	16
Sharp of Guildford	of Guildford in the County of Surrey	\N	\N	\N	2296	5	8	\N	f	\N	2021	5	20
Stern	of Vauxhall in the London Borough of Lambeth	\N	\N	\N	2315	5	8	\N	f	\N	2022	5	20
Thornton	of Manningham in the County of West Yorkshire	\N	\N	\N	2280	5	8	\N	f	\N	2023	5	21
Uddin	of Bethnal Green in the London Borough of Tower Hamlets	\N	\N	\N	2274	5	8	\N	f	\N	2024	5	22
Warwick of Undercliffe	of Undercliffe in the County of West Yorkshire	\N	\N	\N	2312	5	8	\N	f	\N	2025	5	24
Mackenzie of Framwellgate	of Durham in the County of Durham	\N	\N	\N	2271	5	8	\N	f	\N	1985	5	14
Crawley	of Edgbaston in the County of West Midlands	\N	\N	\N	2282	5	8	\N	f	\N	2016	5	4
Alli	of Norbury in the London Borough of Croydon	\N	\N	\N	2273	5	8	\N	f	\N	1987	5	2
Marshall of Knightsbridge	of Knightsbridge in the City of Westminster	2012-07-05	1	\N	2275	5	8	\N	f	\N	1988	5	14
Burns	of Pitshanger in the London Borough of Ealing	\N	\N	\N	2276	5	8	\N	f	\N	1989	5	3
Tomlinson	of Walsall in the County of West Midlands	\N	\N	\N	2278	5	8	\N	f	\N	1990	5	21
Lamont of Lerwick	of Lerwick in the Shetland Islands	\N	\N	\N	2281	5	8	\N	f	\N	1991	5	13
Phillips of Sudbury	of Sudbury in the County of Suffolk	\N	\N	\N	2283	5	8	\N	f	\N	1992	5	17
Haskins	of Skidby in the County of the East Riding of Yorkshire	\N	\N	\N	2284	5	8	\N	f	\N	1993	5	9
Laming	of Tewin in the County of Hertfordshire	\N	\N	\N	2285	5	8	\N	f	\N	1994	5	13
Bach	of Lutterworth in the County of Leicestershire	\N	\N	\N	2286	5	8	\N	f	\N	1995	5	3
Evans of Watford	of Chipperfield in the County of Hertfordshire	\N	\N	\N	2288	5	8	\N	f	\N	1996	5	6
Naseby	of Sandy in the County of Bedfordshire	\N	\N	\N	2246	5	8	\N	f	\N	1997	5	15
Higgins	of Worthing in the County of West Sussex	\N	\N	\N	2247	5	8	\N	f	\N	1998	5	9
Hanningfield	of Chelmsford in the County of Essex	\N	\N	\N	2293	5	8	\N	f	\N	1999	5	9
Bell	of Belgravia in the City of Westminster	2019-08-25	1	\N	2294	5	8	\N	f	\N	2000	5	3
Norton of Louth	of Louth in the County of Lincolnshire	\N	\N	\N	2295	5	8	\N	f	\N	2001	5	15
Ahmed	of Rotherham in the County of South Yorkshire	\N	\N	\N	2298	5	8	\N	f	\N	2002	5	2
Bragg	of Wigton in the County of Cumbria	\N	\N	\N	2299	5	8	\N	f	\N	2003	5	3
Sawyer	of Darlington in the County of Durham	\N	\N	\N	2300	5	8	\N	f	\N	2004	5	20
Macdonald of Tradeston	of Tradeston in the City of Glasgow	\N	\N	appointed a Minister	2304	5	8	\N	f	\N	2007	5	14
Imbert	of New Romney in the County of Kent	2017-11-13	1	\N	2307	5	8	\N	f	\N	2008	5	10
Hobhouse of Woodborough	of Woodborough in the County of Wiltshire	2004-03-15	1	vice L Goff of Chieveley resigned	2302	1	8	\N	f	\N	2009	5	9
Millett	of St Marylebone in the City of Westminster	2021-05-27	1	vice L Nolan resigned	2303	1	8	\N	f	\N	2010	5	14
Patel	of Dunkeld in Perth and Kinross	\N	\N	\N	2309	5	8	\N	f	\N	2011	5	17
Trotman	of Osmotherley in the County of North Yorkshire	2005-04-25	1	\N	2310	5	8	\N	f	\N	2012	5	21
Fellowes	of Shotesham in the County of Norfolk	\N	\N	\N	2313	5	8	\N	f	\N	2013	5	7
Stevenson of Coddenham	of Coddenham in the County of Suffolk	\N	\N	\N	2314	5	8	\N	f	\N	2014	5	20
Buscombe	of Goring in the County of Oxfordshire	\N	\N	\N	2279	5	8	\N	f	\N	2015	5	3
Goudie	of Roundwood in the London Borough of Brent	\N	\N	\N	2277	5	8	\N	f	\N	2017	5	8
Hanham	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2319	5	8	\N	f	\N	2056	5	9
Harris of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2353	5	8	\N	f	\N	2057	5	9
Massey of Darwen	of Darwen in the County of Lancashire	\N	\N	\N	2333	5	8	\N	f	\N	2058	5	14
McIntosh of Hudnall	of Hampstead in the London Borough of Camden	\N	\N	\N	2346	5	8	\N	f	\N	2059	5	14
Prashar	of Runnymede in the County of Surrey	\N	\N	\N	2318	5	8	\N	f	\N	2060	5	17
Whitaker	of Beeston in the County of Nottinghamshire	\N	\N	\N	2351	5	8	\N	f	\N	2061	5	24
Wilkins	of Chesham Bois in the County of Buckinghamshire	\N	\N	\N	2341	5	8	\N	f	\N	2062	5	24
Forsyth of Drumlean	of Drumlean in Stirling	\N	\N	\N	2316	5	8	\N	f	\N	2026	5	7
Blood	of Blackwatertown in the County of Armagh	\N	\N	\N	2342	5	8	\N	f	\N	2054	5	3
Faulkner of Worcester	of Wimbledon in the London Borough of Merton	\N	\N	\N	2317	5	8	\N	f	\N	2027	5	7
Laird	of Artigarvan in the County of Tyrone	2018-07-10	1	\N	2320	5	8	\N	f	\N	2028	5	13
Rogan	of Lower Iveagh in the County of Down	\N	\N	\N	2321	5	8	\N	f	\N	2029	5	19
Elder	of Kirkcaldy in Fife	\N	\N	\N	2323	5	8	\N	f	\N	2030	5	6
Lea of Crondall	of Crondall in the County of Hampshire	\N	\N	\N	2324	5	8	\N	f	\N	2031	5	13
Brett	of Lydd in the County of Kent	2012-03-29	1	\N	2325	5	8	\N	f	\N	2032	5	3
Rennard	of Wavertree in the County of Merseyside	\N	\N	\N	2326	5	8	\N	f	\N	2033	5	19
Bradshaw	of Wallingford in the County of Oxfordshire	\N	\N	\N	2328	5	8	\N	f	\N	2034	5	3
Watson of Richmond	of Richmond in the London Borough of Richmond upon Thames	\N	\N	\N	2330	5	8	\N	f	\N	2036	5	24
Kirkham	of Old Cantley in the County of South Yorkshire	\N	\N	\N	2331	5	8	\N	f	\N	2037	5	12
Grabiner	of Aldwych in the City of Westminster	\N	\N	\N	2332	5	8	\N	f	\N	2038	5	8
Carlile of Berriew	of Berriew in the County of Powys	\N	\N	\N	2334	5	8	\N	f	\N	2039	5	4
Clarke of Hampstead	of Hampstead in the London Borough of Camden	\N	\N	\N	2290	5	8	\N	f	\N	2040	5	4
Christopher	of Leckhampton in the County of Gloucestershire	\N	\N	\N	2291	5	8	\N	f	\N	2041	5	4
Brookman	of Ebbw Vale in the County of Gwent	\N	\N	\N	2292	5	8	\N	f	\N	2042	5	3
Lipsey	of Tooting in the London Borough of Wandsworth	\N	\N	\N	2340	5	8	\N	f	\N	2043	5	13
Woolmer of Leeds	of Leeds in the County of West Yorkshire	\N	\N	\N	2347	5	8	\N	f	\N	2044	5	24
MacKenzie of Culkein	of Assynt in Highland	\N	\N	\N	2349	5	8	\N	f	\N	2045	5	14
Smith of Leigh	of Wigan in the County of Greater Manchester	\N	\N	\N	2350	5	8	\N	f	\N	2046	5	20
Gavron	of Highgate in the London Borough of Camden	2015-02-07	1	\N	2352	5	8	\N	f	\N	2047	5	8
Robertson of Port Ellen	of Islay in Argyll and Bute	\N	\N	\N	2354	5	8	\N	f	\N	2048	5	19
Erskine of Alloa Tower	of Alloa in Clackmannanshire	\N	\N	Succeeded as 14th E of Mar & 16th E of Kellie 1993; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2376	6	8	\N	f	\N	2051	5	6
Ponsonby of Roehampton	of Shulbrede in the County of West Sussex	\N	\N	Succeeded as 4th L Ponsonby of Shulbrede 1900; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 12 noon.	2377	6	8	\N	f	\N	2052	5	17
Barker	of Anagach in Highland	\N	\N	\N	2343	5	8	\N	f	\N	2053	5	3
Gale	of Blaenrhondda in the County of Mid Glamorgan	\N	\N	\N	2348	5	8	\N	f	\N	2055	5	8
Noakes	of Goudhurst in the County of Sussex	\N	\N	\N	2400	5	8	\N	f	\N	2093	5	15
Scott of Needham Market	of Needham Market in the County of Suffolk	\N	\N	\N	2391	5	8	\N	f	\N	2094	5	20
Walmsley	of West Derby in the County of Merseyside	\N	\N	\N	2395	5	8	\N	f	\N	2095	5	24
Jordan	of Bournville in the County of West Midlands	\N	\N	\N	2399	5	8	\N	f	\N	2063	5	11
Gibson of Market Rasen	of Market Rasen in the County of Lincolnshire	2018-04-20	1	\N	2387	5	8	\N	f	\N	2091	5	8
Morgan	of Aberdyfi in the County of Gwynedd	\N	\N	\N	2402	5	8	\N	f	\N	2065	5	14
Scott of Foscote	of Foscote in the County of Buckinghamshire	\N	\N	vice L Phillips of Worth Matravers, appointed MR	2403	1	8	\N	f	\N	2066	5	20
Luce	of Adur in the County of West Sussex	\N	\N	\N	2404	5	8	\N	f	\N	2067	5	13
Ashcroft	of Chichester in the County of West Sussex	\N	\N	\N	2405	5	8	\N	f	\N	2068	5	2
Oakeshott of Seagrove Bay	of Seagrove Bay in the County of Isle of Wight	\N	\N	\N	2379	5	8	\N	f	\N	2071	5	16
Armstrong-Jones	of Nymans in the County of West Sussex	2017-01-13	1	Cr 1st E of Snowdon 6 Oct 1961; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 3 p.m.	2357	6	8	\N	f	\N	2072	5	2
Harrison	of Chester in the County of Cheshire	\N	\N	\N	2336	5	8	\N	f	\N	2073	5	9
Waldegrave of North Hill	of Chewton Mendip in the County of Somerset	\N	\N	\N	2337	5	8	\N	f	\N	2074	5	24
Goldsmith	of Allerton in the County of Merseyside	\N	\N	\N	2338	5	8	\N	f	\N	2075	5	8
Ganzoni	of Ipswich in the County of Suffolk	2005-12-03	1	Succeeded as 2nd L Belstead 15 Aug 1958; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2362	6	8	\N	f	\N	2076	5	8
Gascoyne-Cecil	of Essendon in the County of Rutland	\N	\N	Son & heir of 6th M. of Salisbury; summoned in father's barony of Cecil 29.4.92; known as V. Cranborne; ceased to be a member of the House of Lords on enactment of House of Lords Act 1999 on 11.11.99; patent sealed 12 noon; succeeded father 11.7.03	2363	6	8	\N	f	\N	2077	5	8
Carington of Upton	of Upton in the County of Nottinghamshire	2018-07-09	1	Succeeded as 6th L Carrington1938; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 3 p.m.	2364	6	8	\N	f	\N	2078	5	4
Brittan of Spennithorne	of Spennithorne in the County of North Yorkshire	2015-01-21	1	\N	2365	5	8	\N	f	\N	2079	5	3
Birt	of Liverpool in the County of Merseyside	\N	\N	\N	2367	5	8	\N	f	\N	2080	5	3
Patel of Blackburn	of Langho in the County of Lancashire	2019-05-29	1	\N	2368	5	8	\N	f	\N	2081	5	17
Powell of Bayswater	of Canterbury in the County of Kent	\N	\N	\N	2369	5	8	\N	f	\N	2082	5	17
Joffe	of Liddington in the County of Wiltshire	2017-06-18	1	\N	2370	5	8	\N	f	\N	2083	5	11
Acton of Bridgnorth	of Aldenham in the County of Shropshire	2010-10-10	1	Succeeded as 4th L Acton 1989; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2371	6	8	\N	f	\N	2084	5	2
Mitchell	of Hampstead in the London Borough of Camden	\N	\N	\N	2389	5	8	\N	f	\N	2085	5	14
Parekh	of Kingston upon Hull in the East Riding of Yorkshire	\N	\N	\N	2390	5	8	\N	f	\N	2086	5	17
Evans of Temple Guiting	of Temple Guiting in the County of Gloucestershire	2016-07-06	1	\N	2392	5	8	\N	f	\N	2087	5	6
Shutt of Greetland	of Greetland and Stainland in the County of West Yorkshire	2020-10-30	1	\N	2393	5	8	\N	f	\N	2088	5	20
Roper	of Thorney Island in the City of Westminster	2016-01-29	1	\N	2394	5	8	\N	f	\N	2089	5	19
Boothroyd	of Sandwell in the County of West Midlands	\N	\N	\N	2406	5	8	\N	f	\N	2090	5	3
Greengross	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2366	5	8	\N	f	\N	2092	5	8
Michie of Gallanach	of Oban in Argyll and Bute	2008-05-06	1	dau of L Bannerman of Kildonan	2440	5	8	\N	f	\N	2134	5	14
Northover	of Cissbury in the County of West Sussex	\N	\N	Title = husband's surname	2378	5	8	\N	f	\N	2135	5	15
Fyfe of Fairfield	of Sauchie in the County of Clackmannanshire	2011-02-01	1	\N	2397	5	8	\N	f	\N	2097	5	7
Finlay of Llandaff	of Llandaff in the County of South Glamorgan	\N	\N	\N	2421	5	8	\N	f	\N	2132	5	7
Coe	of Ranmore in the County of Surrey	\N	\N	\N	2398	5	8	\N	f	\N	2098	5	4
Brennan	of Bibury in the County of Gloucestershire	\N	\N	\N	2381	5	8	\N	f	\N	2099	5	3
Layard	of Highgate in the London Borough of Haringey	\N	\N	\N	2383	5	8	\N	f	\N	2100	5	13
Greaves	of Pendle in the County of Lancashire	2021-03-23	1	\N	2384	5	8	\N	f	\N	2101	5	8
Turnberg	of Cheadle in the County of Cheshire	\N	\N	\N	2385	5	8	\N	f	\N	2102	5	21
Hunt of Chesterton	of Chesterton in the County of Cambridgeshire	\N	\N	\N	2386	5	8	\N	f	\N	2103	5	9
Chan	of Oxton in the County of Merseyside	2006-01-21	1	\N	2407	5	8	\N	f	\N	2104	5	4
Best	of Godmanstone in the County of Dorset	\N	\N	\N	2408	5	8	\N	f	\N	2105	5	3
Sheldon	of Ashton-under-Lyne in the County of Greater Manchester	2020-02-03	1	\N	2414	5	8	\N	f	\N	2107	5	20
Moser	of Regents Park in the London Borough of Camden	2015-09-04	1	\N	2416	5	8	\N	f	\N	2108	5	14
Ouseley	of Peckham Rye in the London Borough of Southwark	\N	\N	\N	2418	5	8	\N	f	\N	2109	5	16
Guthrie of Craigiebank	of Craigiebank in the City of Dundee	\N	\N	\N	2419	5	8	\N	f	\N	2110	5	8
Condon	of Langton Green in the County of Kent	\N	\N	\N	2420	5	8	\N	f	\N	2111	5	4
Browne of Madingley	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2422	5	8	\N	f	\N	2112	5	3
Sutherland of Houndwood	of Houndwood in the Scottish Borders	2018-01-29	1	\N	2424	5	8	\N	f	\N	2113	5	20
Adebowale	of Thornes in the County of West Yorkshire	\N	\N	\N	2425	5	8	\N	f	\N	2114	5	2
Grocott	of Telford in the County of Shropshire	\N	\N	\N	2426	5	8	\N	f	\N	2115	5	8
Clark of Windermere	of Windermere in the County of Cumbria	\N	\N	\N	2427	5	8	\N	f	\N	2116	5	4
Fowler	of Sutton Coldfield in the County of West Midlands	\N	\N	\N	2429	5	8	\N	f	\N	2117	5	7
Pendry	of Stalybridge in the County of Greater Manchester	\N	\N	\N	2430	5	8	\N	f	\N	2118	5	17
Campbell-Savours	of Allerdale in the County of Cumbria	\N	\N	\N	2431	5	8	\N	f	\N	2119	5	4
MacGregor of Pulham Market	of Pulham Market in the County of Norfolk	\N	\N	\N	2432	5	8	\N	f	\N	2120	5	14
Corbett of Castle Vale	of Erdington in the County of West Midlands	2012-02-19	1	\N	2433	5	8	\N	f	\N	2121	5	4
Jones	of Deeside in the County of Clwyd	\N	\N	\N	2434	5	8	\N	f	\N	2122	5	11
King of Bridgwater	of Bridgwater in the County of Somerset	\N	\N	\N	2435	5	8	\N	f	\N	2123	5	12
Fearn	of Southport in the County of Merseyside	\N	\N	\N	2437	5	8	\N	f	\N	2125	5	7
Heseltine	of Thenford in the County of Northamptonshire	\N	\N	\N	2438	5	8	\N	f	\N	2126	5	9
Radice	of Chester-le-Street in the County of Durham	\N	\N	\N	2441	5	8	\N	f	\N	2127	5	19
Kilclooney	of Armagh in the County of Armagh	\N	\N	\N	2442	5	8	\N	f	\N	2128	5	12
May of Oxford	of Oxford in the County of Oxfordshire	2020-04-28	1	\N	2443	5	8	\N	f	\N	2129	5	14
Maclennan of Rogart	of Rogart in Sutherland	2020-01-18	1	\N	2444	5	8	\N	f	\N	2130	5	14
Cohen of Pimlico	of Pimlico in the City of Westminster	\N	\N	\N	2382	5	8	\N	f	\N	2131	5	4
Howarth of Breckland	of Parson Cross in the County of South Yorkshire	\N	\N	\N	2417	5	8	\N	f	\N	2133	5	9
Morgan of Huyton	of Huyton in the County of Merseyside	\N	\N	\N	2413	5	8	\N	f	\N	2170	5	14
Murphy	of Aldgate in the City of London	\N	\N	\N	2482	5	8	\N	f	\N	2172	5	14
Neuberger	of Primrose Hill in the London Borough of Camden	\N	\N	\N	2478	5	8	\N	f	\N	2173	5	15
Prosser	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2474	5	8	\N	f	\N	2174	5	17
Wall of New Barnet	of New Barnet in the London Borough of Barnet	2017-01-25	1	\N	2473	5	8	\N	f	\N	2175	5	24
Young of Hornsey	of Hornsey in the London Borough of Haringey	\N	\N	\N	2488	5	8	\N	f	\N	2176	5	26
Maginnis of Drumglass	of Carnteel in the County of Tyrone	\N	\N	\N	2445	5	8	\N	f	\N	2136	5	14
Henig	of Lancaster in the County of Lancashire	\N	\N	\N	2468	5	8	\N	f	\N	2168	5	9
Livsey of Talgarth	of Talgarth in the County of Powys	2010-09-15	1	\N	2447	5	8	\N	f	\N	2137	5	13
Black of Crossharbour	of Crossharbour in the London Borough of Tower Hamlets	\N	\N	\N	2448	5	8	\N	f	\N	2138	5	3
Walker of Gestingthorpe	of Gestingthorpe in the County of Essex	\N	\N	vice L Slynn of Hadley resigned	2449	1	8	\N	f	\N	2139	5	24
Carey of Clifton	of Clifton in the City and County of Bristol	\N	\N	\N	2450	5	8	\N	f	\N	2140	5	4
Wilson of Dinton	of Dinton in the County of Buckinghamshire	\N	\N	\N	2451	5	8	\N	f	\N	2141	5	24
Boyce	of Pimlico in the City of Westminster	\N	\N	\N	2452	5	8	\N	f	\N	2142	5	3
Cullen of Whitekirk	of Whitekirk in East Lothian	\N	\N	\N	2453	5	8	\N	f	\N	2143	5	4
Triesman	of Tottenham in the London Borough of Haringey	\N	\N	\N	2454	5	8	\N	f	\N	2144	5	21
Drayson	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2459	5	8	\N	f	\N	2146	5	5
Tunnicliffe	of Bracknell in the Royal County of Berkshire	\N	\N	\N	2461	5	8	\N	f	\N	2147	5	21
Garden	of Hampstead in the London Borough of Camden	2007-08-09	1	\N	2463	5	8	\N	f	\N	2149	5	8
Howard of Rising	of Castle Rising in the County of Norfolk	\N	\N	\N	2464	5	8	\N	f	\N	2150	5	9
Hart of Chilton	of Chilton in the County of Suffolk	2017-08-03	1	\N	2465	5	8	\N	f	\N	2151	5	9
Leitch	of Oakley in Fife	\N	\N	\N	2466	5	8	\N	f	\N	2152	5	13
Gould of Brookwood	of Brookwood in the County of Surrey	2011-11-06	1	\N	2467	5	8	\N	f	\N	2153	5	8
Snape	of Wednesbury in the County of West Midlands	\N	\N	\N	2470	5	8	\N	f	\N	2154	5	20
Truscott	of St James's in the City of Westminster	\N	\N	\N	2472	5	8	\N	f	\N	2155	5	21
Rosser	of Ickenham in the London Borough of Hillingdon	\N	\N	\N	2477	5	8	\N	f	\N	2156	5	19
Roberts of Llandudno	of Llandudno in the County of Gwynedd	\N	\N	\N	2479	5	8	\N	f	\N	2157	5	19
Giddens	of Southgate in the London Borough of Enfield	\N	\N	\N	2480	5	8	\N	f	\N	2158	5	8
Rana	of Malone in the County of Antrim	\N	\N	\N	2481	5	8	\N	f	\N	2159	5	19
Maxton	of Blackwaterfoot in Ayrshire and Arran	\N	\N	\N	2483	5	8	\N	f	\N	2160	5	14
Ballyedmond	of Mourne in the County of Down	2014-03-13	1	\N	2484	5	8	\N	f	\N	2161	5	3
McKenzie of Luton	of Luton in the County of Bedfordshire	\N	\N	\N	2485	5	8	\N	f	\N	2162	5	14
Dykes	of Harrow Weald in the London Borough of Harrow	\N	\N	\N	2486	5	8	\N	f	\N	2163	5	5
Broers	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2487	5	8	\N	f	\N	2164	5	3
Vallance of Tummel	of Tummel in Perth and Kinross	\N	\N	\N	2489	5	8	\N	f	\N	2165	5	23
Steinberg	of Belfast in the County of Antrim	2009-11-02	1	\N	2490	5	8	\N	f	\N	2166	5	20
Greenfield	of Ot Moor in the County of Oxfordshire	\N	\N	\N	2411	5	8	\N	f	\N	2167	5	8
Morgan of Drefelin	of Drefelin in the County of Dyfed	\N	\N	\N	2475	5	8	\N	f	\N	2169	5	14
Corston	of St George in the County and City of Bristol	\N	\N	\N	2536	5	8	\N	f	\N	2212	5	4
Fritchie	of Gloucester in the County of Gloucestershire	\N	\N	\N	2510	5	8	\N	f	\N	2213	5	7
Morris of Yardley	of Yardley in the County of West Midlands	\N	\N	\N	2513	5	8	\N	f	\N	2214	5	14
Royall of Blaisdon	of Blaisdon in the County of Gloucestershire	\N	\N	\N	2495	5	8	\N	f	\N	2215	5	19
Taylor of Bolton	of Bolton in the County of Greater Manchester	\N	\N	\N	2512	5	8	\N	f	\N	2216	5	21
Tonge	of Kew in the London Borough of Richmond upon Thames	\N	\N	\N	2527	5	8	\N	f	\N	2217	5	21
Young of Norwood Green	of Norwood Green in the London Borough of Ealing	\N	\N	\N	2494	5	8	\N	f	\N	2177	5	26
Chapman	of Leeds in the County of West Yorkshire	2009-09-03	1	\N	2492	5	8	\N	f	\N	2210	5	4
Rowlands	of Merthyr Tydfil and of Rhymney in the County of Mid-Glamorgan	\N	\N	\N	2496	5	8	\N	f	\N	2178	5	19
Haworth	of Fisherfield in Ross and Cromarty	\N	\N	\N	2497	5	8	\N	f	\N	2179	5	9
George	of St Tudy in the County of Cornwall	2009-04-18	1	\N	2499	5	8	\N	f	\N	2181	5	8
Kerr of Kinlochard	of Kinlochard in Perth and Kinross	\N	\N	\N	2501	5	8	\N	f	\N	2182	5	12
Carswell	of Killeen in the County of Down	\N	\N	vice L Hutton resigned	2456	1	8	\N	f	\N	2183	5	4
Kalms	of Edgware in the London Borough of Barnet	\N	\N	\N	2458	5	8	\N	f	\N	2184	5	12
Hope of Thornes	of Thornes in the County of West Yorkshire	\N	\N	\N	2506	5	8	\N	f	\N	2185	5	9
Stevens of Kirkwhelpington	of Kirkwhelpington in the County of Northumberland	\N	\N	\N	2507	5	8	\N	f	\N	2186	5	20
Adonis	of Camden Town in the London Borough of Camden	\N	\N	\N	2508	5	8	\N	f	\N	2187	5	2
Ramsbotham	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2509	5	8	\N	f	\N	2188	5	19
Kirkwood of Kirkhope	of Kirkhope in Scottish Borders	\N	\N	\N	2511	5	8	\N	f	\N	2189	5	12
Howarth of Newport	of Newport in the County of Gwent	\N	\N	\N	2515	5	8	\N	f	\N	2190	5	9
Tyler	of Linkinhorne in the County of Cornwall	\N	\N	\N	2516	5	8	\N	f	\N	2191	5	21
Foulkes of Cumnock	of Cumnock in East Ayrshire	\N	\N	\N	2517	5	8	\N	f	\N	2192	5	7
Foster of Bishop Auckland	of Bishop Auckland in the County of Durham	2019-01-06	1	\N	2518	5	8	\N	f	\N	2193	5	7
Hamilton of Epsom	of West Anstey in the County of Devon	\N	\N	\N	2519	5	8	\N	f	\N	2194	5	9
Chidgey	of Hamble-le-Rice in the County of Hampshire	\N	\N	\N	2520	5	8	\N	f	\N	2195	5	4
Jones of Cheltenham	of Cheltenham in the County of Gloucestershire	\N	\N	\N	2521	5	8	\N	f	\N	2196	5	11
Bilston	of Bilston in the County of West Midlands	2014-02-25	1	\N	2522	5	8	\N	f	\N	2197	5	3
Moonie	of Bennochy in Fife	\N	\N	\N	2525	5	8	\N	f	\N	2198	5	14
Stratford	of Stratford in the London Borough of Newham	2006-01-08	1	\N	2528	5	8	\N	f	\N	2200	5	20
Cunningham of Felling	of Felling in the County of Tyne and Wear	\N	\N	\N	2531	5	8	\N	f	\N	2202	5	4
Anderson of Swansea	of Swansea in the County of West Glamorgan	\N	\N	\N	2533	5	8	\N	f	\N	2204	5	2
Soley	of Hammersmith in the London Borough of Hammersmith and Fulham	\N	\N	\N	2535	5	8	\N	f	\N	2205	5	20
Goodlad	of Lincoln in the County of Lincolnshire	\N	\N	\N	2537	5	8	\N	f	\N	2206	5	8
Rees of Ludlow	of Ludlow in the County of Shropshire	\N	\N	\N	2538	5	8	\N	f	\N	2207	5	19
Turner of Ecchinswell	of Ecchinswell in the County of Hampshire	\N	\N	\N	2539	5	8	\N	f	\N	2208	5	21
Bonham-Carter of Yarnbury	of Yarnbury in the County of Wiltshire	\N	\N	\N	2491	5	8	\N	f	\N	2209	5	3
Clark of Calton	of Calton in the City of Edinburgh	\N	\N	\N	2524	5	8	\N	f	\N	2211	5	4
Kidron	of Angel in the London Borough of Islington	\N	\N	\N	2744	5	8	\N	f	\N	2254	5	12
Kingsmill	of Holland Park in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2553	5	8	\N	f	\N	2255	5	12
Lane-Fox of Soho	of Soho in the City of Westminster	\N	\N	\N	2749	5	8	\N	f	\N	2256	5	13
Paisley of St George's	of St George's in the County of Antrim	\N	\N	\N	2571	5	8	\N	f	\N	2257	5	17
Valentine	of Putney in the London Borough of Wandsworth	\N	\N	\N	2542	5	8	\N	f	\N	2258	5	23
Verma	of Leicester in the County of Leicestershire	\N	\N	\N	2556	5	8	\N	f	\N	2259	5	23
Mance	of Frognal in the London Borough of Camden	\N	\N	\N	2540	1	8	\N	f	\N	2218	5	14
Grender	of Kingston upon Thames in the London Borough of Kingston upon Thames	\N	\N	\N	2754	5	8	\N	f	\N	2252	5	8
Turnbull	of Enfield in the London Borough of Enfield	\N	\N	\N	2543	5	8	\N	f	\N	2219	5	21
Davidson of Glen Clova	of Glen Clova in Angus	\N	\N	\N	2545	5	8	\N	f	\N	2221	5	5
Crisp	of Eaglescliffe in the County of Durham	\N	\N	\N	2546	5	8	\N	f	\N	2222	5	4
Alliance	of Manchester in the County of Greater Manchester	\N	\N	\N	2503	5	8	\N	f	\N	2223	5	2
Patten of Barnes	of Barnes in the London Borough of Richmond	\N	\N	\N	2504	5	8	\N	f	\N	2224	5	17
Kinnock	of Bedwellty in the County of Gwent	\N	\N	\N	2505	5	8	\N	f	\N	2225	5	12
Burnett	of Whitchurch in the County of Devon	\N	\N	\N	2552	5	8	\N	f	\N	2226	5	3
Teverson	of Tregony in the County of Cornwall	\N	\N	\N	2554	5	8	\N	f	\N	2227	5	21
Trimble	of Lisnagarvey in the County of Antrim	\N	\N	\N	2555	5	8	\N	f	\N	2228	5	21
Leach of Fairford	of Fairford in the County of Gloucestershire	2016-06-12	1	\N	2559	5	8	\N	f	\N	2229	5	13
Sheikh	of Cornhill in the City of London	\N	\N	\N	2560	5	8	\N	f	\N	2230	5	20
Morrow	of Clogher Valley in the County of Tyrone	\N	\N	\N	2561	5	8	\N	f	\N	2231	5	14
Marland	of Odstock in the County of Wiltshire	\N	\N	\N	2563	5	8	\N	f	\N	2232	5	14
Patel of Bradford	of Bradford in the County of West Yorkshire	\N	\N	\N	2564	5	8	\N	f	\N	2233	5	17
Bruce-Lockhart	of The Weald in the County of Kent	2008-08-14	1	\N	2565	5	8	\N	f	\N	2234	5	3
James of Blackheath	of Wildbrooks in the County of West Sussex	\N	\N	\N	2566	5	8	\N	f	\N	2235	5	11
Bradley	of Withington in the County of Greater Manchester	\N	\N	\N	2567	5	8	\N	f	\N	2236	5	3
Browne of Belmont	of Belmont in the County of Antrim	\N	\N	\N	2568	5	8	\N	f	\N	2237	5	3
Low of Dalston	of Dalston in the London Borough of Hackney	\N	\N	\N	2570	5	8	\N	f	\N	2238	5	13
Boyd of Duncansby	of Duncansby in Caithness	\N	\N	\N	2572	5	8	\N	f	\N	2239	5	3
Rowe-Beddoe	of Kilgetty in the County of Dyfed	\N	\N	\N	2573	5	8	\N	f	\N	2240	5	19
Trees	of The Ross in Perth and Kinross	\N	\N	\N	2745	5	8	\N	f	\N	2241	5	21
Deighton	of Carshalton in the County of Surrey	\N	\N	\N	2746	5	8	\N	f	\N	2242	5	5
Berkeley of Knighton	of Knighton in the County of Powys	\N	\N	\N	2750	5	8	\N	f	\N	2245	5	3
Livingston of Parkhead	of Parkhead in the City of Glasgow	\N	\N	\N	2751	5	8	\N	f	\N	2246	5	13
Horam	of Grimsargh in the County of Lancashire	\N	\N	\N	2753	5	8	\N	f	\N	2247	5	9
King of Lothbury	of Lothbury in the City of London	\N	\N	\N	2752	5	8	\N	f	\N	2248	5	12
Mendelsohn	of Finchley in the London Borough of Barnet	\N	\N	\N	2755	5	8	\N	f	\N	2249	5	14
Wrigglesworth	of Norton on Tees in the County of Durham	\N	\N	\N	2756	5	8	\N	f	\N	2250	5	24
Ford	of Cunninghame in North Ayrshire	\N	\N	\N	2558	5	8	\N	f	\N	2251	5	7
Jones of Whitchurch	of Whitchurch in the County of South Glamorgan	\N	\N	\N	2557	5	8	\N	f	\N	2253	5	11
Garden of Frognal	of Hampstead in the London Borough of Camden	\N	\N	\N	2595	5	8	\N	f	\N	2291	5	8
Lawrence of Clarendon	of Clarendon in the Commonwealth Realm of Jamaica	\N	\N	\N	2758	5	8	\N	f	\N	2293	5	13
Manningham-Buller	of Northampton in the County of Northamptonshire	\N	\N	\N	2601	5	8	\N	f	\N	2294	5	14
Manzoor	of Knightsbridge in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2757	5	8	\N	f	\N	2295	5	14
Neville-Jones	of Hutton Roof in the County of Cumbria	\N	\N	\N	2594	5	8	\N	f	\N	2296	5	15
Quin	of Gateshead in the County of Tyne and Wear	\N	\N	\N	2550	5	8	\N	f	\N	2297	5	18
Thomas of Winchester	of Winchester in the County of Hampshire	\N	\N	\N	2548	5	8	\N	f	\N	2298	5	21
Vadera	of Holland Park in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2590	5	8	\N	f	\N	2299	5	23
Warsi	of Dewsbury in the County of West Yorkshire	\N	\N	\N	2593	5	8	\N	f	\N	2300	5	24
Dear	of Willersey in the County of Gloucestershire	\N	\N	\N	2574	5	8	\N	f	\N	2260	5	5
Bilimoria	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2575	5	8	\N	f	\N	2261	5	3
Cotter	of Congresbury in the County of Somerset	\N	\N	\N	2549	5	8	\N	f	\N	2262	5	4
Bew	of Donegore in the County of Antrim	\N	\N	\N	2582	5	8	\N	f	\N	2264	5	3
Hameed	of Hampstead in the London Borough of Camden	\N	\N	\N	2583	5	8	\N	f	\N	2265	5	9
Krebs	of Wytham in the County of Oxfordshire	\N	\N	\N	2584	5	8	\N	f	\N	2266	5	12
Mawson	of Bromley-by-Bow in the London Borough of Tower Hamlets	\N	\N	\N	2585	5	8	\N	f	\N	2267	5	14
Malloch-Brown	of St Leonard's Forest in the County of West Sussex	\N	\N	\N	2587	5	8	\N	f	\N	2268	5	14
West of Spithead	of Seaview in the County of Isle of Wight	\N	\N	\N	2588	5	8	\N	f	\N	2269	5	24
Jones of Birmingham	of Alvechurch and of Bromsgrove in the County of Worcestershire	\N	\N	\N	2589	5	8	\N	f	\N	2270	5	11
Darzi of Denham	of Gerrards Cross in the County of Buckinghamshire	\N	\N	\N	2591	5	8	\N	f	\N	2271	5	5
Janvrin	of Chalford Hill in the County of Gloucestershire	\N	\N	\N	2592	5	8	\N	f	\N	2272	5	11
Wallace of Tankerness	of Tankerness in Orkney	\N	\N	\N	2596	5	8	\N	f	\N	2273	5	24
Mogg	of Queen's Park in the County of East Sussex	\N	\N	\N	2599	5	8	\N	f	\N	2274	5	14
Smith of Kelvin	of Kelvin in the City of Glasgow	\N	\N	\N	2600	5	8	\N	f	\N	2275	5	20
Bates	of Langbaurgh in the County of North Yorkshire	\N	\N	\N	2602	5	8	\N	f	\N	2276	5	3
Judge	of Draycote in the County of Warwickshire	\N	\N	\N	2603	5	8	\N	f	\N	2277	5	11
Mandelson	of Foy in the County of Herefordshire and of Hartlepool in the County of Durham	\N	\N	\N	2604	5	8	\N	f	\N	2278	5	14
Carter of Barnes	of Barnes in the London Borough of Richmond upon Thames	\N	\N	\N	2605	5	8	\N	f	\N	2279	5	4
Myners	of Truro in the County of Cornwall	\N	\N	\N	2606	5	8	\N	f	\N	2280	5	14
Pannick	of Radlett in the County of Hertfordshire	\N	\N	\N	2607	5	8	\N	f	\N	2281	5	17
Davies of Abersoch	of Abersoch in the County of Gwynedd	\N	\N	\N	2609	5	8	\N	f	\N	2282	5	5
Clarke of Stone-cum-Ebony	of Stone-cum-Ebony in the County of Kent	\N	\N	MR	2611	5	8	\N	f	\N	2283	5	4
Freud	of Eastry in the County of Kent	\N	\N	\N	2612	5	8	\N	f	\N	2284	5	7
Sugar	of Clapton in the London Borough of Hackney	\N	\N	\N	2615	5	8	\N	f	\N	2285	5	20
Sacks	of Aldgate in the City of London	2020-11-07	1	\N	2617	5	8	\N	f	\N	2286	5	20
Martin of Springburn	of Port Dundas in the City of Glasgow	2018-04-29	1	\N	2616	5	8	\N	f	\N	2287	5	14
Bakewell of Hardington Mandeville	of Hardington Mandeville in the County of Somerset	\N	\N	\N	2760	5	8	\N	f	\N	2288	5	3
Coussins	of Whitehall Park in the London Borough of Islington	\N	\N	\N	2581	5	8	\N	f	\N	2290	5	4
Drake	of Shene in the County of Surrey	\N	\N	\N	2633	5	8	\N	f	\N	2331	5	5
Grey-Thompson	of Eaglescliffe in the County of Durham	\N	\N	\N	2621	5	8	\N	f	\N	2332	5	8
Hayter of Kentish Town	of Kentish Town in the London Borough of Camden	\N	\N	\N	2637	5	8	\N	f	\N	2333	5	9
Hussein-Ece	of Highbury in the London Borough of Islington	\N	\N	\N	2643	5	8	\N	f	\N	2334	5	9
Liddell of Coatdyke	of Airdrie in Lanarkshire	\N	\N	\N	2654	5	8	\N	f	\N	2335	5	13
O'Loan	of Kirkinriola in the County of Antrim	\N	\N	\N	2618	5	8	\N	f	\N	2336	5	16
Smith of Basildon	of Basildon in the County of Essex	\N	\N	\N	2652	5	8	\N	f	\N	2338	5	20
Stedman-Scott	of Rolvenden in the County of Kent	\N	\N	\N	2661	5	8	\N	f	\N	2339	5	20
Wheeler	of Blackfriars in the City of London	\N	\N	\N	2634	5	8	\N	f	\N	2340	5	24
Wolf of Dulwich	of Dulwich in the London Borough of Southwark	\N	\N	\N	2807	5	8	\N	f	\N	2341	5	24
Hall of Birkenhead	of Birkenhead in the County of Cheshire	\N	\N	\N	2619	5	8	\N	f	\N	2301	5	9
Kakkar	of Loxbeare in the County of Devon	\N	\N	\N	2620	5	8	\N	f	\N	2302	5	12
Browning	of Whimple in the County of Devon	\N	\N	\N	2658	5	8	\N	f	\N	2329	5	3
Bichard	of Nailsworth in the County of Gloucestershire	\N	\N	\N	2622	5	8	\N	f	\N	2303	5	3
Jay of Ewelme	of Ewelme in the County of Oxfordshire	\N	\N	\N	2578	5	8	\N	f	\N	2304	5	11
Walker of Aldringham	of Aldringham in the County of Suffolk	\N	\N	\N	2579	5	8	\N	f	\N	2305	5	24
McFall of Alcluith	of Dumbarton in Dunbartonshire	\N	\N	\N	2627	5	8	\N	f	\N	2306	5	14
Wolfson of Aspley Guise	of Aspley Guise in the County of Bedfordshire	\N	\N	\N	2628	5	8	\N	f	\N	2307	5	24
Bannside	of North Antrim in the County of Antrim	2014-09-12	1	\N	2631	5	8	\N	f	\N	2309	5	3
Liddle	of Carlisle in the County of Cumbria	\N	\N	\N	2632	5	8	\N	f	\N	2310	5	13
Deben	of Winston in the County of Suffolk	\N	\N	\N	2635	5	8	\N	f	\N	2311	5	5
McAvoy	of Rutherglen in Lanarkshire	\N	\N	\N	2638	5	8	\N	f	\N	2312	5	14
Knight of Weymouth	of Weymouth in the County of Dorset	\N	\N	\N	2639	5	8	\N	f	\N	2313	5	12
Maples	of Stratford-upon-Avon in the County of Warwickshire	2012-06-09	1	\N	2641	5	8	\N	f	\N	2315	5	14
German	of Llanfrechfa in the County Borough of Torfaen	\N	\N	\N	2642	5	8	\N	f	\N	2316	5	8
Hutton of Furness	of Aldingham in the County of Cumbria	\N	\N	\N	2647	5	8	\N	f	\N	2317	5	9
McConnell of Glenscorrodale	of the Isle of Arran in Ayrshire and Arran	\N	\N	\N	2649	5	8	\N	f	\N	2318	5	14
Touhig	of Islwyn and Glansychan in the County of Gwent	\N	\N	\N	2650	5	8	\N	f	\N	2319	5	21
Davies of Stamford	of Stamford in the County of Lincolnshire	\N	\N	\N	2651	5	8	\N	f	\N	2320	5	5
Prescott	of Kingston upon Hull in the County of East Yorkshire	\N	\N	\N	2653	5	8	\N	f	\N	2321	5	17
Spicer	of Cropthorne in the County of Worcestershire	2019-05-29	1	\N	2655	5	8	\N	f	\N	2322	5	20
Boswell of Aynho	of Aynho in the County of Northamptonshire	\N	\N	\N	2656	5	8	\N	f	\N	2323	5	3
Black of Brentwood	of Brentwood in the County of Essex	\N	\N	\N	2657	5	8	\N	f	\N	2324	5	3
Popat	of Harrow in the London Borough of Harrow	\N	\N	\N	2660	5	8	\N	f	\N	2325	5	17
Green of Deddington	of Deddington in the County of Oxfordshire	\N	\N	\N	2806	5	8	\N	f	\N	2326	5	8
Evans of Weardale	of Toys Hill in Our County of Kent	\N	\N	\N	2808	5	8	\N	f	\N	2327	5	6
Benjamin	of Beckenham in the County of Kent	\N	\N	\N	2645	5	8	\N	f	\N	2328	5	3
Donaghy	of Peckham in the London Borough of Southwark	\N	\N	\N	2646	5	8	\N	f	\N	2330	5	5
Hughes of Stretford	of Ellesmere Port in the County of Cheshire	\N	\N	\N	2668	5	8	\N	f	\N	2375	5	9
Kramer	of Richmond Park in the London Borough of Richmond upon Thames	\N	\N	\N	2693	5	8	\N	f	\N	2376	5	12
Newlove	of Warrington in the County of Cheshire	\N	\N	\N	2666	5	8	\N	f	\N	2377	5	15
Nye	of Lambeth in the London Borough of Lambeth	\N	\N	\N	2671	5	8	\N	f	\N	2378	5	15
Parminter	of Godalming in the County of Surrey	\N	\N	\N	2667	5	8	\N	f	\N	2379	5	17
Shackleton of Belgravia	of Belgravia in the City of Westminster	\N	\N	\N	2691	5	8	\N	f	\N	2380	5	20
Sherlock	of Durham in the County of Durham	\N	\N	\N	2626	5	8	\N	f	\N	2381	5	20
Wheatcroft	of Blackheath in the London Borough of Greenwich	\N	\N	\N	2694	5	8	\N	f	\N	2382	5	24
Lisvane	of Blakemere in the County of Herefordshire	\N	\N	\N	2809	5	8	\N	f	\N	2342	5	13
Eaton	of Cottingley in the County of West Yorkshire	\N	\N	\N	2676	5	8	\N	f	\N	2373	5	6
Kerslake	of Endcliffe in the City of Sheffield	\N	\N	\N	2811	5	8	\N	f	\N	2343	5	12
Dunlop	of Helensburgh in the County of Dunbarton	\N	\N	\N	2813	5	8	\N	f	\N	2344	5	5
Wei	of Shoreditch in the London Borough of Hackney	\N	\N	\N	2624	5	8	\N	f	\N	2345	5	24
Sassoon	of Ashley Park in the County of Surrey	\N	\N	\N	2625	5	8	\N	f	\N	2346	5	20
Keen of Elie	of Elie in Fife	\N	\N	\N	2818	5	8	\N	f	\N	2347	5	12
Hayward	of Cumnor in the County of Oxfordshire	\N	\N	\N	2820	5	8	\N	f	\N	2349	5	9
Smith of Hindhead	of Hindhead in the County of Surrey	\N	\N	\N	2822	5	8	\N	f	\N	2350	5	20
Gilbert of Panteg	of Panteg in the County of Monmouthshire	\N	\N	\N	2823	5	8	\N	f	\N	2351	5	8
Stevenson of Balmacara	of Little Missenden in the County of Buckinghamshire	\N	\N	\N	2663	5	8	\N	f	\N	2353	5	20
Howard of Lympne	of Lympne in the County of Kent	\N	\N	\N	2664	5	8	\N	f	\N	2354	5	9
Shipley	of Gosforth in the County of Tyne and Wear	\N	\N	\N	2665	5	8	\N	f	\N	2355	5	20
Reid of Cardowan	of Stepps in Lanarkshire	\N	\N	\N	2670	5	8	\N	f	\N	2356	5	19
Blair of Boughton	of Boughton in the County of Cheshire	\N	\N	\N	2673	5	8	\N	f	\N	2357	5	3
Faulks	of Donnington in the Royal County of Berkshire	\N	\N	\N	2675	5	8	\N	f	\N	2359	5	7
Allan of Hallam	of Ecclesall in the County of South Yorkshire	\N	\N	\N	2677	5	8	\N	f	\N	2360	5	2
Browne of Ladyton	of Ladyton in Ayrshire and Arran	\N	\N	\N	2678	5	8	\N	f	\N	2361	5	3
Williams of Baglan	of Neath Port Talbot in Glamorgan	2017-04-23	1	\N	2679	5	8	\N	f	\N	2362	5	24
Monks	of Blackley in the County of Greater Manchester	\N	\N	\N	2680	5	8	\N	f	\N	2363	5	14
Hennessy of Nympsfield	of Nympsfield in the County of Gloucestershire	\N	\N	\N	2681	5	8	\N	f	\N	2364	5	9
Green of Hurstpierpoint	of Hurstpierpoint in the County of West Sussex	\N	\N	\N	2683	5	8	\N	f	\N	2365	5	8
Kerr of Monteviot	of Monteviot in Roxburghshire	\N	\N	\N	2684	6	8	\N	f	\N	2366	5	12
Lingfield	of Lingfield in the County of Surrey	\N	\N	\N	2685	5	8	\N	f	\N	2367	5	13
Feldman of Elstree	of Elstree in the County of Hertfordshire	\N	\N	\N	2686	5	8	\N	f	\N	2368	5	7
Dobbs	of Wylye in the County of Wiltshire	\N	\N	\N	2687	5	8	\N	f	\N	2369	5	5
Cormack	of Enville in the County of Staffordshire	\N	\N	\N	2688	5	8	\N	f	\N	2370	5	4
Sharkey	of Niton Undercliff in the County of the Isle of Wight	\N	\N	\N	2689	5	8	\N	f	\N	2371	5	20
Doocey	of Hampton in the London Borough of Richmond upon Thames	\N	\N	\N	2692	5	8	\N	f	\N	2372	5	5
Healy of Primrose Hill	of Primrose Hill in the London Borough of Camden	\N	\N	\N	2672	5	8	\N	f	\N	2374	5	9
Heyhoe Flint	of Wolverhampton in the County of West Midlands	2017-01-18	1	\N	2720	5	8	\N	f	\N	2416	5	9
Jenkin of Kennington	of Hatfield Peverel in the County of Essex	\N	\N	\N	2725	5	8	\N	f	\N	2417	5	11
Jolly	of Congdon's Shop in the County of Cornwall	\N	\N	\N	2697	5	8	\N	f	\N	2418	5	11
King of Bow	of Bow in the London Borough of Tower Hamlets	\N	\N	\N	2726	5	8	\N	f	\N	2419	5	12
Morgan of Ely	of Ely in the City of Cardiff	\N	\N	\N	2722	5	8	\N	f	\N	2420	5	14
Randerson	of Roath Park in the City of Cardiff	\N	\N	\N	2727	5	8	\N	f	\N	2421	5	19
Tyler of Enfield	of Enfield in the London Borough of Enfield	\N	\N	\N	2729	5	8	\N	f	\N	2422	5	21
True	of East Sheen in the County of Surrey	\N	\N	\N	2695	5	8	\N	f	\N	2383	5	21
Lexden	of Lexden in the County of Essex and of Strangford in the County of Down	\N	\N	\N	2696	5	8	\N	f	\N	2384	5	13
Berridge	of The Vale of Catmose in the County of Rutland	\N	\N	\N	2713	5	8	\N	f	\N	2414	5	3
O'Neill of Gatley	of Gatley in the County of Greater Manchester	\N	\N	\N	2815	5	8	\N	f	\N	2385	5	16
Bridges of Headley	of Headley Heath in the County of Surrey	\N	\N	\N	2816	5	8	\N	f	\N	2386	5	3
Prior of Brampton	of Swannington in the County of Norfolk	\N	\N	\N	2817	5	8	\N	f	\N	2387	5	17
Wasserman	of Pimlico in the City of Westminster	\N	\N	\N	2702	5	8	\N	f	\N	2388	5	24
Loomba	of Moor Park in the County of Hertfordshire	\N	\N	\N	2704	5	8	\N	f	\N	2389	5	13
Ahmad of Wimbledon	of Wimbledon in the London Borough of Merton	\N	\N	\N	2705	5	8	\N	f	\N	2390	5	2
Flight	of Worcester in the County of Worcestershire	\N	\N	\N	2706	5	8	\N	f	\N	2391	5	7
Edmiston	of Lapworth in the County of Warwickshire	\N	\N	\N	2707	5	8	\N	f	\N	2392	5	6
Framlingham	of Eye in the County of Suffolk	\N	\N	\N	2708	5	8	\N	f	\N	2393	5	7
Fink	of Northwood in the County of Middlesex	\N	\N	\N	2714	5	8	\N	f	\N	2395	5	7
Dannatt	of Keswick in the County of Norfolk	\N	\N	\N	2715	5	8	\N	f	\N	2396	5	5
Wigley	of Caernarfon in the County of Gwynedd	\N	\N	\N	2716	5	8	\N	f	\N	2397	5	24
Hussain	of Luton in the County of Bedfordshire	\N	\N	\N	2718	5	8	\N	f	\N	2399	5	9
Kestenbaum	of Foxcote in the County of Somerset	\N	\N	\N	2721	5	8	\N	f	\N	2400	5	12
Magan of Castletown	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2723	5	8	\N	f	\N	2401	5	14
Grade of Yarmouth	of Yarmouth in the County of Isle of Wight	\N	\N	\N	2724	5	8	\N	f	\N	2402	5	8
Noon	of St John's Wood in the London Borough of Camden	2015-10-27	1	\N	2728	5	8	\N	f	\N	2403	5	15
Stirrup	of Marylebone in the City of Westminster	\N	\N	\N	2730	5	8	\N	f	\N	2404	5	20
Glendonbrook	of Bowdon in the County of Cheshire	\N	\N	\N	2733	5	8	\N	f	\N	2405	5	8
Gold	of Westcliff-on-Sea in the County of Essex	\N	\N	\N	2734	5	8	\N	f	\N	2406	5	8
Storey	of Childwall in the City of Liverpool	\N	\N	\N	2735	5	8	\N	f	\N	2407	5	20
Stephen	of Lower Deeside in the City of Aberdeen	\N	\N	\N	2736	5	8	\N	f	\N	2408	5	20
Glasman	of Stoke Newington and of Stamford Hill in the London Borough of Hackney	\N	\N	\N	2737	5	8	\N	f	\N	2409	5	8
Blencathra	of Penrith in the County of Cumbria	\N	\N	\N	2739	5	8	\N	f	\N	2410	5	3
Singh of Wimbledon	of Wimbledon in the London Borough of Merton	\N	\N	\N	2741	5	8	\N	f	\N	2411	5	20
Curry of Kirkharle	of Kirkharle in the County of Northumberland	\N	\N	\N	2742	5	8	\N	f	\N	2412	5	4
Bakewell	of Stockport in the County of Greater Manchester	\N	\N	\N	2719	5	8	\N	f	\N	2413	5	3
Brinton	of Kenardington in the County of Kent	\N	\N	\N	2738	5	8	\N	f	\N	2415	5	3
Helic	of Millbank in the City of Westminster	\N	\N	\N	2796	5	8	\N	f	\N	2453	5	9
McGregor-Smith	of Sunninghill in the Royal County of Berkshire	\N	\N	\N	2848	5	8	\N	f	\N	2454	5	14
Mobarik	of Mearns in the County of Renfrewshire	\N	\N	\N	2798	5	8	\N	f	\N	2456	5	14
Mone	of Mayfair in the City of Westminster	\N	\N	\N	2824	5	8	\N	f	\N	2457	5	14
Rebuck	of Bloomsbury in the London Borough of Camden	\N	\N	\N	2797	5	8	\N	f	\N	2458	5	19
Rock	of Stratton in the County of Dorset	\N	\N	\N	2846	5	8	\N	f	\N	2459	5	19
Shields	of Maida Vale in the City of Westminster	\N	\N	\N	2793	5	8	\N	f	\N	2460	5	20
Smith of Newnham	of Crosby in the County of Merseyside	\N	\N	\N	2788	5	8	\N	f	\N	2461	5	20
Stowell of Beeston	of Beeston in Our County of Nottinghamshire	\N	\N	\N	2699	5	8	\N	f	\N	2462	5	20
Stroud	of Fulham in the London Borough of Hammersmith and Fulham	\N	\N	\N	2827	5	8	\N	f	\N	2463	5	20
Thornhill	of Watford in the County of Hertfordshire	\N	\N	\N	2854	5	8	\N	f	\N	2464	5	21
Lupton	of Lovington in the County of Hampshire	\N	\N	\N	2832	5	8	\N	f	\N	2424	5	13
Strasburger	of Langridge in Our County of Somerset	\N	\N	\N	2700	5	8	\N	f	\N	2425	5	20
Featherstone	of Highgate in the London Borough of Haringey	\N	\N	\N	2853	5	8	\N	f	\N	2450	5	7
Marks of Henley-on-Thames	of Henley-on-Thames in the County of Oxfordshire	\N	\N	\N	2701	5	8	\N	f	\N	2426	5	14
Hague of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2838	5	8	\N	f	\N	2427	5	9
Hailsham of Kettlethorpe	of Kettlethorpe in the County of Lincolnshire	\N	\N	\N	2840	6	8	\N	f	\N	2428	5	9
Barker of Battle	of Battle in the County of East Sussex	\N	\N	\N	2841	5	8	\N	f	\N	2429	5	3
Robathan	of Poultney in the County of Leicestershire	\N	\N	\N	2842	5	8	\N	f	\N	2430	5	19
Campbell of Pittenweem	of Pittenweem in the County of Fife	\N	\N	\N	2843	5	8	\N	f	\N	2431	5	4
Shinkwin	of Balham in the London Borough of Wandsworth	\N	\N	\N	2844	5	8	\N	f	\N	2432	5	20
Arbuthnot of Edrom	of Edrom in the County of Berwick	\N	\N	\N	2825	5	8	\N	f	\N	2433	5	2
O'Shaughnessy	of Maidenhead in the Royal County of Berkshire	\N	\N	\N	2826	5	8	\N	f	\N	2434	5	16
Polak	of Hertsmere in the County of Hertfordshire	\N	\N	\N	2828	5	8	\N	f	\N	2435	5	17
Lansley	of Orwell in the County of Cambridgeshire	\N	\N	\N	2830	5	8	\N	f	\N	2436	5	13
Oates	of Denby Grange in the County of West Yorkshire	\N	\N	\N	2831	5	8	\N	f	\N	2437	5	16
Bruce of Bennachie	of Torphins in the County of Aberdeen	\N	\N	\N	2850	5	8	\N	f	\N	2439	5	3
Beith	of Berwick upon Tweed in the County of Northumberland	\N	\N	\N	2851	5	8	\N	f	\N	2440	5	3
Murphy of Torfaen	of Abersychan in the County of Gwent	\N	\N	\N	2852	5	8	\N	f	\N	2441	5	14
Livermore	of Rotherhithe in the London Borough of Southwark	\N	\N	\N	2855	5	8	\N	f	\N	2442	5	13
Hain	of Neath in the County of West Glamorgan	\N	\N	\N	2856	5	8	\N	f	\N	2443	5	9
Farmer	of Bishopsgate in the City of London	\N	\N	\N	2785	5	8	\N	f	\N	2444	5	7
Fox	of Leominster in the County of Herefordshire	\N	\N	\N	2786	5	8	\N	f	\N	2445	5	7
Suri	of Ealing in the London Borough of Ealing	\N	\N	\N	2787	5	8	\N	f	\N	2446	5	20
Rose of Monewden	of Monewden in the County of Suffolk	\N	\N	\N	2794	5	8	\N	f	\N	2447	5	19
Cooper of Windrush	of Chipping Norton in the County of Oxfordshire	\N	\N	\N	2795	5	8	\N	f	\N	2448	5	4
Fall	of Ladbroke Grove in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2857	5	8	\N	f	\N	2449	5	7
Finn	of Swansea in the County of West Glamorgan	\N	\N	\N	2845	5	8	\N	f	\N	2451	5	7
Hodgson of Abinger	of Abinger in the County of Surrey	\N	\N	\N	2769	5	8	\N	f	\N	2495	5	9
Jones of Moulsecoomb	of Moulsecoomb in the County of East Sussex	\N	\N	\N	2778	5	8	\N	f	\N	2496	5	11
Neville-Rolfe	of Chilmark in the County of Wiltshire	\N	\N	\N	2761	5	8	\N	f	\N	2497	5	15
Pidding	of Amersham in the County of Buckinghamshire	\N	\N	\N	2836	5	8	\N	f	\N	2498	5	17
Pinnock	of Cleckheaton in the County of West Yorkshire	\N	\N	\N	2803	5	8	\N	f	\N	2499	5	17
Primarolo	of Windmill Hill in the City of Bristol	\N	\N	\N	2861	5	8	\N	f	\N	2500	5	17
Sugg	of Coldharbour in the London Borough of Lambeth	\N	\N	\N	2869	5	8	\N	f	\N	2501	5	20
Suttie	of Hawick in the Scottish Borders	\N	\N	\N	2772	5	8	\N	f	\N	2502	5	20
Vere of Norbiton	of Norbiton in the Royal Borough of Kingston upon Thames	\N	\N	\N	2870	5	8	\N	f	\N	2503	5	23
Watkins of Tavistock	of Buckland Monachorum in the County of Devon	\N	\N	\N	2866	5	8	\N	f	\N	2504	5	24
Scriven	of Hunters Bar in the City of Sheffield	\N	\N	\N	2799	5	8	\N	f	\N	2465	5	20
Brown of Cambridge	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2865	5	8	\N	f	\N	2493	5	3
Foster of Bath	of Bath in the County of Somerset	\N	\N	\N	2835	5	8	\N	f	\N	2466	5	7
Watts	of Ravenhead in the County of Merseyside	\N	\N	\N	2859	5	8	\N	f	\N	2467	5	24
Stunell	of Hazel Grove in the County of Greater Manchester	\N	\N	\N	2860	5	8	\N	f	\N	2468	5	20
Mair	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2863	5	8	\N	f	\N	2469	5	14
Bird	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2864	5	8	\N	f	\N	2470	5	3
Darling of Roulanish	Great Bernera in the County of Ross and Cromarty	\N	\N	\N	2867	5	8	\N	f	\N	2471	5	5
Price	of Sturminster Newton in the County of Dorset	\N	\N	\N	2868	5	8	\N	f	\N	2472	5	17
Gadhia	of Northwood in the County of Middlesex	\N	\N	\N	2872	5	8	\N	f	\N	2474	5	8
McInnes of Kilwinning	of Kilwinning in the County of Ayrshire	\N	\N	\N	2873	5	8	\N	f	\N	2475	5	14
Kirkhope of Harrogate	of Harrogate in the County of North Yorkshire	\N	\N	\N	2874	5	8	\N	f	\N	2476	5	12
Whitby	of Harborne in the City of Birmingham	\N	\N	\N	2762	5	8	\N	f	\N	2477	5	24
Finkelstein	of Pinner in the County of Middlesex	\N	\N	\N	2763	5	8	\N	f	\N	2478	5	7
Carrington of Fulham	of Fulham in the London Borough of Hammersmith and Fulham	\N	\N	\N	2764	5	8	\N	f	\N	2479	5	4
Sherbourne of Didsbury	of Didsbury in the City of Manchester	\N	\N	\N	2765	5	8	\N	f	\N	2480	5	20
Paddick	of Brixton in the London Borough of Lambeth	\N	\N	\N	2766	5	8	\N	f	\N	2481	5	17
Purvis of Tweed	of East March in the Scottish Borders	\N	\N	\N	2767	5	8	\N	f	\N	2482	5	17
Leigh of Hurley	of Hurley in the Royal County of Berkshire	\N	\N	\N	2770	5	8	\N	f	\N	2484	5	13
Verjee	of Portobello in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2771	5	8	\N	f	\N	2485	5	23
Haughey	of Hutchesontown in the City of Glasgow	\N	\N	\N	2774	5	8	\N	f	\N	2486	5	9
Balfe	of Dulwich in the London Borough of Southwark	\N	\N	\N	2775	5	8	\N	f	\N	2487	5	3
Allen of Kensington	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2779	5	8	\N	f	\N	2488	5	2
Palumbo of Southwark	of Southwark in the London Borough of Southwark	\N	\N	\N	2780	5	8	\N	f	\N	2489	5	17
Callanan	of Low Fell in the County of Tyne and Wear	\N	\N	\N	2804	5	8	\N	f	\N	2491	5	4
Brady	of Knightsbridge in the City of Westminster	\N	\N	\N	2801	5	8	\N	f	\N	2492	5	3
Goldie	of Bishopton in the County of Renfrewshire	\N	\N	\N	2782	5	8	\N	f	\N	2494	5	8
Bowles of Berkhamsted	of Bourne End in the County of Hertfordshire	\N	\N	\N	2858	5	8	\N	f	\N	2532	5	3
Bryan of Partick	of Partick in the City of Glasgow	\N	\N	\N	2899	5	8	\N	f	\N	2533	5	3
Bull	of Aldwych in the City of Westminster	\N	\N	\N	2907	5	8	\N	f	\N	2534	5	3
Cavendish of Little Venice	of Mells in the County of Somerset	\N	\N	\N	2880	5	8	\N	f	\N	2535	5	4
Chakrabarti	of Kennington in the London Borough of Lambeth	\N	\N	\N	2879	5	8	\N	f	\N	2536	5	4
Fairhead	of Yarm in the County of North Yorkshire	\N	\N	\N	2886	5	8	\N	f	\N	2537	5	7
Hallett	of Rye in the County of East Sussex	\N	\N	\N	2922	5	8	\N	f	\N	2538	5	9
Osamor	of Tottenham in the London Borough of Haringey and of Asaba in the Republic of Nigeria	\N	\N	\N	2910	5	8	\N	f	\N	2540	5	16
Penn	of Teddington in the London Borough of Richmond	\N	\N	\N	2920	5	8	\N	f	\N	2541	5	17
Sanderson of Welton	of Welton in the East Riding of Yorkshire	\N	\N	\N	2916	5	8	\N	f	\N	2542	5	20
Sater	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2898	5	8	\N	f	\N	2543	5	20
Wilcox of Newport	of Newport in the City of Newport	\N	\N	\N	2923	5	8	\N	f	\N	2544	5	24
Wyld	of Gosforth in the City of Newcastle upon Tyne	\N	\N	\N	2884	5	8	\N	f	\N	2545	5	24
Cashman	of Limehouse in the London Borough of Tower Hamlets	\N	\N	\N	2802	5	8	\N	f	\N	2505	5	4
Ricketts	of Shortlands in the County of Kent	\N	\N	\N	2882	5	8	\N	f	\N	2506	5	19
Blackwood of North Oxford	of North Oxford in the County of Oxfordshire	\N	\N	\N	2911	5	8	\N	f	\N	2530	5	3
Llewellyn of Steep	of Steep in the County of Hampshire	\N	\N	\N	2883	5	8	\N	f	\N	2507	5	13
Duncan of Springbank	of Springbank in the County of Perth	\N	\N	\N	2885	5	8	\N	f	\N	2508	5	5
Agnew of Oulton	of Oulton in the County of Norfolk	\N	\N	\N	2887	5	8	\N	f	\N	2509	5	2
Burnett of Maldon	of Maldon in the County of Essex	\N	\N	\N	2888	5	8	\N	f	\N	2510	5	3
Geidt	of Crobeg in the County of Ross and Cromarty	\N	\N	\N	2889	5	8	\N	f	\N	2512	5	8
Chartres	of Wilton in the County of Wiltshire	\N	\N	\N	2890	5	8	\N	f	\N	2513	5	4
Hogan-Howe	of Sheffield in the County of South Yorkshire	\N	\N	\N	2891	5	8	\N	f	\N	2514	5	9
Tyrie	of Chichester in the County of West Sussex	\N	\N	\N	2893	5	8	\N	f	\N	2515	5	21
Pickles	of Brentwood and Ongar in the County of Essex	\N	\N	\N	2894	5	8	\N	f	\N	2516	5	17
Lilley	of Offa in the County of Hertfordshire	\N	\N	\N	2895	5	8	\N	f	\N	2517	5	13
McNicol of West Kilbride	of West Kilbride in the County of Ayrshire	\N	\N	\N	2900	5	8	\N	f	\N	2518	5	14
Heywood of Whitehall	of Glossop in the County of Derbyshire	2018-11-04	1	never introduced	2909	5	8	\N	f	\N	2520	5	9
Barwell	of Croydon in the London Borough of Croydon	\N	\N	Theresa May's personal list	2914	5	8	\N	f	\N	2521	5	3
Parkinson of Whitley Bay	of Beyton in the County of Suffolk	\N	\N	\N	2915	5	8	\N	f	\N	2522	5	17
Choudrey	of Hampstead in the London Borough of Barnet	\N	\N	\N	2917	5	8	\N	f	\N	2523	5	4
Brownlow of Shurlock Row	of Shurlock Row in the Royal County of Berkshire	\N	\N	\N	2918	5	8	\N	f	\N	2524	5	3
Davies of Gower	of Gower in the County of Swansea	\N	\N	\N	2919	5	8	\N	f	\N	2525	5	5
Ranger	of Mayfair in the City of Westminster	\N	\N	\N	2921	5	8	\N	f	\N	2526	5	19
Woolley of Woodford	of Woodford in the London Borough of Redbridge	\N	\N	\N	2924	5	8	\N	f	\N	2527	5	24
Caine	of Temple Newsam in the City of Leeds	\N	\N	\N	2875	5	8	\N	f	\N	2528	5	4
Forfar	\N	\N	\N	\N	2912	8	6	\N	t	\N	2529	5	7
Bloomfield of Hinton Waldrist	of Hinton Waldrist in the County of Oxfordshire	\N	\N	\N	2878	5	8	\N	f	\N	2531	5	3
Fox of Buckley	of Buckley in the County of Flintshire	\N	\N	\N	2956	5	8	\N	f	\N	2578	5	7
Fullbrook	of Dogmersfield in the County of Hampshire	\N	\N	\N	2947	5	8	\N	f	\N	2579	5	7
Hayman of Ullock	of Ullock in the County of Cumbria	\N	\N	\N	2950	5	8	\N	f	\N	2580	5	9
Hoey	of Lylehill and Rathlin in the County of Antrim	\N	\N	\N	2957	5	8	\N	f	\N	2581	5	9
Morgan of Cotes	of Cotes in the County of Leicestershire	\N	\N	\N	2932	5	8	\N	f	\N	2583	5	14
Morrissey	of Chapel Green in the Royal County of Berkshire	\N	\N	\N	2942	5	8	\N	f	\N	2584	5	14
Ritchie of Downpatrick	of Downpatrick in the County of Down	\N	\N	\N	2928	5	8	\N	f	\N	2585	5	19
Stuart of Edgbaston	of Edgbaston in the City of Birmingham	\N	\N	\N	2946	5	8	\N	f	\N	2586	5	20
Carter of Haslemere	of Haslemere in the County of Surrey	\N	\N	\N	2930	5	8	\N	f	\N	2546	5	4
Couttie	of Downe in the County of Kent	\N	\N	\N	2877	5	8	\N	f	\N	2576	5	4
Darroch of Kew	of St Mawes in the County of Cornwall	\N	\N	\N	2931	5	8	\N	f	\N	2547	5	5
Reed of Allermuir	of Sundridge Park in the London Borough of Bromley	\N	\N	\N	2934	5	8	\N	f	\N	2548	5	19
Grimstone of Boscobel	of Belgravia in the City of Westminster	\N	\N	\N	2935	5	8	\N	f	\N	2549	5	8
Herbert of South Downs	of Arundel in the County of West Sussex	\N	\N	\N	2938	5	8	\N	f	\N	2551	5	9
Vaizey of Didcot	of Wantage in the County of Oxfordshire	\N	\N	\N	2939	5	8	\N	f	\N	2552	5	23
Frost	of Allenton in the County of Derbyshire	\N	\N	\N	2937	5	8	\N	f	\N	2553	5	7
Austin of Dudley	of Dudley in the County of West Midlands	\N	\N	\N	2941	5	8	\N	f	\N	2555	5	2
Walney	of the Isle of Walney in the County of Cumbria	\N	\N	\N	2944	5	8	\N	f	\N	2556	5	24
Clarke of Nottingham	of West Bridgford in the County of Nottingham	\N	\N	\N	2945	5	8	\N	f	\N	2557	5	4
McLoughlin	of Cannock Chase in the County of Staffordshire	\N	\N	\N	2949	5	8	\N	f	\N	2558	5	14
Moylan	of Kensington in the Royal London Borough of Kensington and Chelsea	\N	\N	\N	2951	5	8	\N	f	\N	2559	5	14
Botham	of Ravensworth in the County of North Yorkshire	\N	\N	\N	2952	5	8	\N	f	\N	2560	5	3
Sikka	of Kingswood in Basildon in the County of Essex	\N	\N	\N	2953	5	8	\N	f	\N	2561	5	20
Field of Birkenhead	of Birkenhead in the County of Merseyside	\N	\N	\N	2954	5	8	\N	f	\N	2562	5	7
Sedwill	of Sherborne in the County of Dorset	\N	\N	\N	2955	5	8	\N	f	\N	2563	5	20
Garnier	of Harborough in the County of of Leicestershire	\N	\N	\N	2903	5	8	\N	f	\N	2564	5	8
Randall of Uxbridge	of Uxbridge in the London Borough of Hillingdon	\N	\N	\N	2904	5	8	\N	f	\N	2565	5	19
Anderson of Ipswich	of Ipswich in the County of Suffolk	\N	\N	\N	2906	5	8	\N	f	\N	2566	5	2
Sharpe of Epsom	of Epsom in the County of Surrey	\N	\N	\N	2959	5	8	\N	f	\N	2567	5	20
Lancaster of Kimbolton	of Kimbolton in the County of Cambridgeshire	\N	\N	\N	2960	5	8	\N	f	\N	2568	5	13
Mendoza	of King's Reach in the City of London	\N	\N	\N	2961	5	8	\N	f	\N	2569	5	14
Moore of Etchingham	of Etchingham in the County of East Sussex	\N	\N	\N	2962	5	8	\N	f	\N	2570	5	14
Davies of Brixton	of Brixton in the London Borough of Lambeth	\N	\N	\N	2964	5	8	\N	f	\N	2571	5	5
Dodds of Duncairn	of Duncairn in the City of Belfast	\N	\N	\N	2965	5	8	\N	f	\N	2572	5	5
Hammond of Runnymede	of Runnymede in the County of Surrey	\N	\N	\N	2967	5	8	\N	f	\N	2573	5	9
Mann	of Holbeck Moor in the City of Leeds	\N	\N	\N	2929	5	8	\N	f	\N	2574	5	14
Clark of Kilwinning	of Kilwinning in the County of Ayrshire	\N	\N	\N	2943	5	8	\N	f	\N	2575	5	4
Fleet	of Hampstead in the London Borough of Camden	\N	\N	\N	2958	5	8	\N	f	\N	2577	5	7
Casey of Blackstock	of Finsbury in the London Borough of Islington	\N	\N	\N	2969	5	8	\N	f	\N	2617	5	4
Chapman of Darlington	of Darlington in the County of Durham	\N	\N	\N	2988	5	8	\N	f	\N	2618	5	4
Davidson of Lundin Links	of Lundin Links in the County of Fife	\N	\N	\N	2995	5	8	\N	f	\N	2619	5	5
Foster of Oxton	of Oxton in the County of Merseyside	\N	\N	\N	2986	5	8	\N	f	\N	2620	5	7
Fraser of Craigmaddie	of Craigmaddie in the County of Stirlingshire	\N	\N	\N	2980	5	8	\N	f	\N	2621	5	7
Merron	of Lincoln in the County of Lincolnshire	\N	\N	\N	2984	5	8	\N	f	\N	2622	5	14
Lebedev	of Hampton in the London Borough of Richmond upon Thames and of Siberia in the Russian Federation	\N	\N	\N	2974	5	8	\N	f	\N	2588	5	13
Stewart of Dirleton	of Dirleton in the County of East Lothian	\N	\N	appointed Advocate General for Scotland	2973	5	8	\N	f	\N	2589	5	20
Blake of Leeds	of Gledhow in the City of Leeds	\N	\N	\N	2987	5	8	\N	f	\N	2616	5	3
Etherton	of Marylebone in the City of Westminster	\N	\N	\N	2975	5	8	\N	f	\N	2590	5	6
Wolfson of Tredegar	of Tredegar in the County of Gwent	\N	\N	\N	2976	5	8	\N	f	\N	2591	5	24
Hannan of Kingsclere	of Kingsclere in the County of Hampshire	\N	\N	\N	2977	5	8	\N	f	\N	2592	5	9
Godson	of Thorney Island in the City of Westminster	\N	\N	\N	2978	5	8	\N	f	\N	2593	5	8
Benyon	of Englefield in the Royal County of Berkshire	\N	\N	\N	2979	5	8	\N	f	\N	2594	5	3
McDonald of Salford	of Pendleton in the City of Salford	\N	\N	\N	2981	5	8	\N	f	\N	2595	5	14
Cruddas	of Shoreditch in the London Borough of Hackney	\N	\N	\N	2982	5	8	\N	f	\N	2596	5	4
Kamall	of Edmonton in the London Borough of Enfield	\N	\N	\N	2983	5	8	\N	f	\N	2597	5	12
Parker of Minsmere	of Minsmere in the County of Suffolk	\N	\N	\N	2985	5	8	\N	f	\N	2598	5	17
Coaker	of Gedling in the County of Nottinghamshire	\N	\N	\N	2989	5	8	\N	f	\N	2599	5	4
Khan of Burnley	of Burnley in the County of Lancashire	\N	\N	\N	2990	5	8	\N	f	\N	2600	5	12
Morse	of Aldeburgh in the County of Suffolk	\N	\N	\N	2991	5	8	\N	f	\N	2601	5	14
Sentamu	of Lindisfarne in the County of Northumberland and of Masooli in the Republic of Uganda	\N	\N	\N	2993	5	8	\N	f	\N	2602	5	20
Stevens of Birmingham	of Richmond upon Thames in the London Borough of Richmond upon Thames	\N	\N	\N	2994	5	8	\N	f	\N	2603	5	20
Chesham	of Chesham in the County of Buckingham	\N	\N	\N	308	2	8	\N	f	\N	2604	5	4
Johnson of Marylebone	of Marylebone in the City of Westminster	\N	\N	\N	2968	5	8	\N	f	\N	2605	5	11
Metcalfe	of Fern Hill in the County of Berks	1846-09-12	1	never introduced	272	2	8	\N	f	\N	2606	5	14
Eddisbury	of Winnington in the County Palatine of Chester	\N	\N	succ 1850 as 2nd L Stanley of Alderley	280	2	8	\N	f	\N	2607	5	6
Skene	of Skene in the County of Aberdeen	1912-01-29	2	2nd L cr D of Fife	307	3	8	\N	f	\N	2608	5	20
Bridport	of Cricket Saint Thomas in the County of Somerset and of Bronté in the Kingdom of Italy	\N	\N	\N	358	3	12	\N	f	\N	2609	5	3
Robartes	of Lanhydrock and of Truro in the County of Cornwall	1974-12-22	6	2nd L succ as 6th V Clifden (I) & 2nd L Mendip	372	2	8	\N	f	\N	2610	5	19
Carlingford	of Carlingford in the County of Louth	1898-01-30	1	succ 1887 as 2nd L Clermont (I)	401	2	8	\N	f	\N	2611	5	4
Strathspey	of Strathspey in the Counties of Inverness and Moray	\N	\N	title separated from E of Seafield 1915	462	4	8	\N	f	\N	2612	5	20
Bellingham	of Congham in the County of Norfolk	\N	\N	\N	2971	5	8	\N	f	\N	2613	5	3
Morris	of Spiddal in the County of Galway	1901-09-08	1	vice L Fitzgerald deceased; cr L Killanin (hereditary) 1900	519	1	8	\N	f	\N	2614	5	14
Leicester	of Holkham in the County of Norfolk	\N	\N	6th E died 19 June 1994	232	2	6	\N	t	\N	2615	5	13
Udny-Lister	of Wandsworth in the London Borough of Wandsworth	\N	\N	\N	2972	5	8	\N	f	\N	2587	5	22
Grimthorpe	of Grimthorpe in the East Riding of the County of York	\N	\N	SR to father's heirs	491	2	8	\N	f	1	2657	5	8
Roberts of Kandahar	in Afghanistan and of the City of Waterford	1914-11-14	1	cr E Roberts (SR) 1901	529	2	8	\N	f	\N	2624	5	19
Iveagh	\N	\N	\N	3rd E died 18 June 1992	837	7	6	\N	t	\N	2655	5	10
Leighton	of Stretton in the County of Salop	1896-01-25	1	\N	574	2	8	\N	f	\N	2625	5	13
Malcolm of Poltalloch	in the County of Argyll	1902-03-06	1	\N	577	2	8	\N	f	\N	2626	5	14
Strathcona and Mount Royal	of Glencoe in the County of Argyll and of Mount Royal in the Province of Quebec and Dominion of Canada	1914-01-21	1	further patent (SR) 1900	588	2	8	\N	f	\N	2627	5	20
Hemphill	of Rathkenny and of Cashell in the County of Tipperary	\N	\N	\N	658	2	8	\N	f	\N	2628	5	9
Shaw	of Dunfermline in the County of Fife	1937-06-28	1	vice L Robertson deceased; cr L Craigmyle (hered.) 1929	683	1	8	\N	f	\N	2629	5	20
Mountgarret	of Nidd in the West Riding of the County of York	\N	\N	\N	704	3	8	\N	f	\N	2630	5	14
Allendale	of Allendale and Hexham in the County of Northumberland	\N	\N	\N	719	7	12	\N	f	\N	2631	5	2
Roundway	of Devizes in the County of Wilts	1944-03-29	2	\N	771	2	8	\N	f	\N	2632	5	19
Farquhar	of Saint Marylebone in the County of London	1923-08-30	1	cr E Farquhar 1922	787	7	12	\N	f	\N	2633	5	7
Gisborough	of Cleveland in the County of York	\N	\N	\N	792	2	8	\N	f	\N	2634	5	8
Beatty	\N	\N	\N	\N	835	2	6	\N	f	\N	2635	5	3
Manton	of Compton Verney in the County of Warwick	\N	\N	\N	879	2	8	\N	f	\N	2637	5	14
Bearsted	of Maidstone in the County of Kent	\N	\N	4th V died 9 June 1996	917	7	12	\N	f	\N	2638	5	3
Leverhulme	of the Western Isles in the Counties of Inverness and Ross and Cromarty	2000-07-04	3	\N	892	7	12	\N	f	\N	2639	5	13
Dunedin	of Stenton in the County of Perth	1942-08-21	1	\N	923	7	12	\N	f	\N	2640	5	5
Plumer	of Messines and of Bolton in the County of York	1944-02-24	2	\N	962	7	12	\N	f	\N	2641	5	17
Byng of Vimy	of Thorpe-le-Soken in the County of Essex	1935-06-06	1	\N	938	7	12	\N	f	\N	2642	5	3
Alvingham	of Woodfold in the County Palatine of Lancaster	\N	\N	\N	968	2	8	\N	f	\N	2643	5	2
Gladstone of Hawarden	of Hawarden in the County of Flint	1935-04-28	1	\N	1004	2	8	\N	f	\N	2644	5	8
Russell of Killowen	of Killowen in the County of Down	1946-12-20	1	vice L Carson resigned; 4th son of L Russell of Killowen cr 1894	974	1	8	\N	f	\N	2645	5	19
Buckmaster	of Cheddington in the County of Buckingham	\N	\N	\N	1012	7	12	\N	f	\N	2646	5	3
Blackford	of Compton Pauncefoot in the County of Somerset	1988-05-15	4	\N	1036	2	8	\N	f	\N	2647	5	3
Wardington	of Alnmouth in the County of Northumberland	2019-03-19	3	3rd L Wardington was a younger son of the 1st	1056	2	8	\N	f	\N	2648	5	24
Ennisdale	of Grateley in the County of Southampton	1963-08-17	1	\N	1097	2	8	\N	f	\N	2650	5	6
Cochrane of Cults	of Crawford Priory in the County of Fife	\N	\N	3rd L died 15 June 1990	830	2	8	\N	f	\N	2651	5	4
Addison	of Stallingborough in the County of Lincoln	\N	\N	\N	1155	7	12	\N	f	\N	2652	5	2
Shepherd	of Spalding in the County of Lincoln	\N	\N	2nd L. created L Shepherd of Spalding (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999, and died 5 Apr 2001	1208	2	8	\N	f	\N	2653	5	20
Cromer	in the County of Norfolk	\N	\N	3rd E died 16 March 1991	617	7	6	\N	t	\N	2654	5	4
Kitchener	of Khartoum and of Broome in the County of Kent	2011-12-16	3	SR to daughters then 2 named brothers	749	7	6	\N	f	2	2656	5	12
Uthwatt	of Lathbury in the County of Buckingham	1949-04-24	1	vice L Russell of Killowen resigned	1189	1	8	\N	f	\N	2659	5	22
Dukeston	of Warrington in the County Palatine of Lancaster	1948-05-14	1	\N	1225	2	8	\N	f	\N	2660	5	5
McEntee	of Walthamstow in the County of Essex	1953-02-11	1	\N	1270	2	8	\N	f	\N	2661	5	14
Bracken	of Christchurch in the County of Southampton	1958-08-08	1	apparently never introduced	1280	2	12	\N	f	\N	2664	5	3
Glassary	of Glassary in the County of Argyll	\N	\N	\N	1307	4	8	\N	f	\N	2665	5	8
Gridley	of Stockport in the County Palatine of Chester	\N	\N	2nd L died 15 June 1996	1313	2	8	\N	f	\N	2666	5	8
McCorquodale of Newton	of Newton-le-Willows in the County Palatine of Lancaster	1971-09-25	1	\N	1323	2	8	\N	f	\N	2667	5	14
Mackintosh of Halifax	of Hethersett in the County of Norfolk	\N	\N	\N	1346	7	12	\N	f	\N	2668	5	14
Williams of Barnburgh	of Barnburgh in the West Riding of the County of York	1967-03-29	1	\N	1403	5	8	\N	f	\N	2669	5	24
Morris of Borth-y-Gest	of Borth-y-Gest in the County of Caernarvon	1979-06-09	1	vice L Somervell of Harrow resigned	1385	1	8	\N	f	\N	2670	5	14
Coutanche	of Saint Brelade in the Island of Jersey	1973-12-18	1	\N	1416	5	8	\N	f	\N	2671	5	4
Blakenham	of Little Blakenham in the County of Suffolk	\N	\N	\N	1447	2	12	\N	f	\N	2672	5	3
Inglewood	of Hutton in the Forest in the County of Cumberland	\N	\N	\N	1467	2	8	\N	f	\N	2673	5	10
Leatherland	of Dunton in the County of Essex	1992-12-18	1	\N	1489	5	8	\N	f	\N	2674	5	13
Brockway	of Eton and of Slough in the County of Buckingham	1988-04-28	1	\N	1491	5	8	\N	f	\N	2675	5	3
Sieff	of Brimpton in the Royal County of Berks	1972-02-14	1	\N	1534	5	8	\N	f	\N	2676	5	20
Nugent of Guildford	of Dunsfold in the County of Surrey	1994-03-16	1	\N	1537	5	8	\N	f	\N	2677	5	15
Jackson of Burnley	of Burnley in the County Palatine of Lancaster	1970-02-17	1	\N	1557	5	8	\N	f	\N	2678	5	11
Foot	of Buckland Monachorum in the County of Devon	1999-10-11	1	\N	1580	5	8	\N	f	\N	2679	5	7
Wilson of Langside	of Broughton in the County and City of Edinburgh	1997-12-30	1	\N	1600	5	8	\N	f	\N	2680	5	24
Burntwood	of Burntwood in the County of Stafford	1982-01-24	1	\N	1623	5	8	\N	f	\N	2681	5	3
Crowther-Hunt	of Eccleshill in the West Riding of the County of York	1987-02-16	1	\N	1666	5	8	\N	f	\N	2683	5	4
Greenhill of Harrow	of the Royal Borough of Kensington and Chelsea	2000-11-08	1	\N	1668	5	8	\N	f	\N	2684	5	8
Chelwood	of Lewes in the County of East Sussex	1989-04-06	1	\N	1677	5	8	\N	f	\N	2685	5	4
Royden	of Frankby in the County Palatine of Chester	1950-11-06	1	\N	1141	2	8	\N	f	\N	2686	5	19
Bruntisfield	of Boroughmuir in the City of Edinburgh	\N	\N	\N	1128	2	8	\N	f	\N	2687	5	3
McCluskey	of Churchhill in the District of the City of Edinburgh	2017-07-20	1	\N	1767	5	8	\N	f	\N	2688	5	14
Buxton of Alsa	of Stiffkey in the County of Norfolk	2009-09-01	1	\N	1799	5	8	\N	f	\N	2689	5	3
Smith	of Marlow in the County of Buckinghamshire	1998-07-01	1	\N	1803	5	8	\N	f	\N	2690	5	20
Perry of Walton	of Walton in the County of Buckinghamshire	2003-07-17	1	\N	1811	5	8	\N	f	\N	2691	5	17
Hooson	of Montgomery in the County of Powys and of Colomendy in the County of Clwyd	2012-02-21	1	\N	1831	5	8	\N	f	\N	2692	5	9
Boardman	of Welford in the County of Northamptonshire	2003-03-10	1	\N	1847	5	8	\N	f	\N	2693	5	3
Wootton of Abinger	of Abinger Common in the County of Surrey	1988-07-11	1	\N	1360	5	8	\N	f	\N	2694	5	24
Mountevans	of Chelsea in the County of London	\N	\N	\N	1182	2	8	\N	f	\N	2658	5	14
McDonagh	of Mitcham and of Morden in the London Borough of Merton	\N	\N	\N	2493	5	8	\N	f	\N	2729	5	14
Richardson of Calow	of Calow in the County of Derbyshire	\N	\N	\N	2297	5	8	\N	f	\N	2730	5	19
Campbell of Alloway	of Ayr in the District of Kyle and Carrick	2013-06-30	1	\N	1867	5	8	\N	f	\N	2695	5	4
Dean of Thornton-le-Fylde	of Eccles in the County of Greater Manchester	2018-03-13	1	\N	2110	5	8	\N	f	\N	2726	5	5
Quinton	of Holywell in the City of Oxford and County of Oxfordshire	2010-06-19	1	\N	1892	5	8	\N	f	\N	2696	5	18
Henderson of Brompton	of Brompton in the Royal Borough of Kensington and Chelsea and of Brough in the County of Cumbria	2000-01-13	1	\N	1924	5	8	\N	f	\N	2698	5	9
Elliott of Morpeth	of Morpeth in the County of Northumberland and of the City of Newcastle upon Tyne	2011-05-20	1	\N	1936	5	8	\N	f	\N	2699	5	6
Crickhowell	of Pont Esgob in the Black Mountains and the County of Powys	2018-03-17	1	\N	1980	5	8	\N	f	\N	2700	5	4
Havers	of St Edmundsbury in the County of Suffolk	1992-04-01	1	apptd Lord Chancellor	1969	5	8	\N	f	\N	2701	5	9
St John of Fawsley	of Preston Capes in the County of Northamptonshire	2012-03-02	1	\N	1982	5	8	\N	f	\N	2702	5	20
Pearson of Rannoch	of Bridge of Gaur in the District of Perth and Kinross	\N	\N	\N	2023	5	8	\N	f	\N	2703	5	17
Finsberg	of Hampstead in the London Borough of Camden	1996-10-07	1	\N	2067	5	8	\N	f	\N	2704	5	7
Merlyn-Rees	of Morley and South Leeds in the County of West Yorkshire and of Cilfynydd in the County of Mid Glamorgan	2006-01-05	1	surname changed from "Rees" after announcement	2073	5	8	\N	f	\N	2705	5	14
Gladwin of Clee	of Great Grimsby in the County of Humberside	2003-04-10	1	\N	2122	5	8	\N	f	\N	2706	5	8
Pilkington of Oxenford	of West Dowlish in the County of Somerset	2011-02-14	1	\N	2149	5	8	\N	f	\N	2707	5	17
Kilpatrick of Kincraig	of Dysart in the District of Kirkcaldy	2015-09-16	1	\N	2154	5	8	\N	f	\N	2708	5	12
Rogers of Riverside	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2173	5	8	\N	f	\N	2709	5	19
Alton of Liverpool	of Mossley Hill in the County of Merseyside	\N	\N	\N	2197	5	8	\N	f	\N	2710	5	2
Mayhew of Twysden	of Kilndown in the County of Kent	2016-06-25	1	\N	2198	5	8	\N	f	\N	2711	5	14
Randall of St Budeaux	of St Budeaux in the County of Devon	2012-08-11	1	St. in writ	2212	5	8	\N	f	\N	2712	5	19
Garel-Jones	of Watford in the County of Hertfordshire	2020-03-24	1	\N	2237	5	8	\N	f	\N	2713	5	8
Puttnam	of Queensgate in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2244	5	8	\N	f	\N	2714	5	17
Dearing	of Kingston upon Hull in the County of the East Riding of Yorkshire	2009-02-19	1	\N	2268	5	8	\N	f	\N	2715	5	5
Warner	of Brockley in the London Borough of Lewisham	\N	\N	\N	2289	5	8	\N	f	\N	2716	5	24
Oxburgh	of Liverpool in the County of Merseyside	\N	\N	\N	2335	5	8	\N	f	\N	2717	5	16
Sharman	of Redlynch in the County of Wiltshire	\N	\N	\N	2344	5	8	\N	f	\N	2718	5	20
Weidenfeld	of Chelsea in Greater London	2016-01-20	1	\N	1757	5	8	\N	f	\N	2719	5	24
Murray of Gravesend	of Gravesend in the County of Kent	1980-02-10	1	\N	1758	5	8	\N	f	\N	2720	5	14
Rooker	of Perry Barr in the County of West Midlands	\N	\N	\N	2410	5	8	\N	f	\N	2721	5	19
Morris of Aberavon	of Aberavon in the County of West Glamorgan and of Ceredigion in the County of Dyfed	\N	\N	\N	2428	5	8	\N	f	\N	2722	5	14
Carter of Coles	of Westmill in the County of Hertfordshire	\N	\N	\N	2469	5	8	\N	f	\N	2723	5	4
Lee of Trafford	of Bowdon in the County of Cheshire	\N	\N	\N	2547	5	8	\N	f	\N	2724	5	13
D'Souza	of Wychwood in the County of Oxfordshire	\N	\N	\N	2502	5	8	\N	f	\N	2725	5	5
Maddock	of Christchurch in the County of Dorset	2020-06-26	1	\N	2250	5	8	\N	f	\N	2728	5	14
Humphreys	of Llanrwst in the County of Conwy	\N	\N	\N	2773	5	8	\N	f	\N	2761	5	9
Janke	of Clifton in the City and County of Bristol	\N	\N	\N	2805	5	8	\N	f	\N	2762	5	11
Jowell	of Brixton in the London Borough of Lambeth	2018-05-12	1	\N	2862	5	8	\N	f	\N	2763	5	11
Lister of Burtersett	of Nottingham in the County of Nottinghamshire	\N	\N	\N	2731	5	8	\N	f	\N	2764	5	13
Meacher	of Spitalfields in the London Borough of Tower Hamlets	\N	\N	\N	2576	5	8	\N	f	\N	2765	5	14
Redfern	of the Isle of Axholme in the County of Lincolnshire	\N	\N	\N	2834	5	8	\N	f	\N	2766	5	19
Taylor of Holbeach	of South Holland in the County of Lincolnshire	\N	\N	\N	2551	5	8	\N	f	\N	2731	5	21
Blower	of Starch Green in the London Borough of Hammersmith and Fulham	\N	\N	\N	2926	5	8	\N	f	\N	2759	5	3
O'Donnell	of Clapham in the London Borough of Wandsworth	\N	\N	\N	2743	5	8	\N	f	\N	2732	5	16
Bourne of Aberystwyth	of Aberystwyth in the County of Ceredigion and of Wethersfield in the County of Essex	\N	\N	\N	2759	5	8	\N	f	\N	2733	5	3
Collins of Mapesbury	of Hampstead Town in the London Borough of Camden	\N	\N	\N	2610	1	8	\N	f	\N	2734	5	4
Hill of Oareford	of Oareford in the County of Somerset	\N	\N	\N	2623	5	8	\N	f	\N	2735	5	9
Kennedy of Southwark	of Newington in the London Borough of  Southwark	\N	\N	\N	2636	5	8	\N	f	\N	2736	5	12
Wills	of North Swindon in the County of Wiltshire and of Woodside Park in the London Borough of Barnet	\N	\N	\N	2659	5	8	\N	f	\N	2737	5	24
Maude of Horsham	of Shipley in the County of West Sussex	\N	\N	\N	2814	5	8	\N	f	\N	2738	5	14
Taylor of Goss Moor	of Truro in the County of Cornwall	\N	\N	\N	2669	5	8	\N	f	\N	2739	5	21
Ribeiro	of Achimota in the Republic of Ghana and of Ovington in the County of Hampshire	\N	\N	\N	2690	5	8	\N	f	\N	2740	5	19
Risby	of Haverhill in the County of Suffolk	\N	\N	\N	2698	5	8	\N	f	\N	2741	5	19
Fellowes of West Stafford	of West Stafford in the County of Dorset	\N	\N	\N	2703	5	8	\N	f	\N	2742	5	7
Porter of Spalding	of Spalding in the County of Lincolnshire	\N	\N	\N	2847	5	8	\N	f	\N	2743	5	17
Lennie	of Longsands Tynemouth in the County of Tyne and Wear	\N	\N	\N	2800	5	8	\N	f	\N	2744	5	13
Thomas of Cwmgiedd	of Cwmgiedd in the County of Powys	\N	\N	LCJ from 1 Oct 2013; as a judge, disqualified from sitting in the House of Lords!	2783	5	8	\N	f	\N	2745	5	21
Macpherson of Earl's Court	of Earl's Court in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2881	5	8	\N	f	\N	2746	5	14
Hendy	of Hayes and Harlington in the London Borough of Hillingdon	\N	\N	\N	2925	5	8	\N	f	\N	2747	5	9
Sarfraz	of Kensington in the Royal London Borough of Kensington and Chelsea	\N	\N	\N	2948	5	8	\N	f	\N	2748	5	20
Spencer of Alresford	of Alresford in the County of Hampshire	\N	\N	\N	2963	5	8	\N	f	\N	2749	5	20
Bhatia	of Hampton in the London Borough of Richmond	\N	\N	\N	2409	5	8	\N	f	\N	2750	5	3
Loftus	of Long Loftus in the County of York	\N	\N	\N	2	3	8	\N	f	\N	2752	5	13
Ardrossan	of Ardrossan in the County of Ayr	\N	\N	2nd L cr E of Winton 1859	43	4	8	\N	f	\N	2753	5	2
Dalhousie	of Dalhousie Castle in the County of Edinburgh	1860-12-22	2	2nd L cr M of Dalhousie 1849	85	4	8	\N	f	\N	2754	5	5
Melbourne	of Melbourne in the County of Derby	1853-01-29	2	\N	91	3	8	\N	f	\N	2755	5	14
Harris	of Seringapatam and Mysore in the East Indies and of Belmont in the County of Kent	\N	\N	6th L died 17 Sep 1995; 7th L died 30 June 1996	92	2	8	\N	f	\N	2756	5	9
Oriel	of Ferrard in the County of Louth	\N	\N	wife cr Vss Ferrard (I); 2nd L succ her 1824; 3rd L succ his mother 1831 as V Massereene (I); ?th L died 27 Dec 1992	123	2	8	\N	f	\N	2757	5	16
Black of Strome	of Strome in the County of Ross-shire	\N	\N	\N	2992	5	8	\N	f	\N	2758	5	3
Evans of Bowes Park	of Bowes Park in the London Borough of Haringey	\N	\N	\N	2789	5	8	\N	f	\N	2760	5	6
Kinnaird	of Rossie in the County of Perth	1997-02-27	5	also 1st L Rossie (cr 1831); SR to brother	325	8	8	\N	f	1	2801	5	12
Dunmore	of Dunmore in the Forest of Athole in the County of Perth	1980-08-12	5	earldom not extinct with barony	180	4	8	\N	f	\N	2770	5	5
Segrave	of Berkeley Castle in the County of Gloucester	1857-10-10	1	cr E Fitzhardinge 17 Aug 1841	189	2	8	\N	f	\N	2771	5	20
Fitzgerald	of Desmond and of Clan Gibbon in the County of Cork	1843-05-11	1	\N	212	3	8	\N	f	\N	2772	5	7
Beauvale	of Beauvale in the County of Nottingham	1853-01-29	1	succ 1848 as 3rd V Melbourne (I) & L Melbourne	245	2	8	\N	f	\N	2773	5	3
Clandeboye	of Clandeboye in the County of Down	1988-05-29	5	cr E of Dufferin 1871, M of Dufferin and Ava 1888	285	3	8	\N	f	\N	2774	5	4
Lawrence	of the Punjaub and of Grately in the County of Southampton	\N	\N	\N	364	2	8	\N	f	\N	2775	5	13
Willingdon	of Ratton in the County of Sussex	1979-03-19	2	cr E of Willingdon 1931	912	7	12	\N	f	\N	2776	5	24
Iveagh	of Iveagh in the County of Down	\N	\N	cr V Iveagh 1905, E of Iveagh 1919	523	2	8	\N	f	\N	2777	5	10
Hood of Avalon	in the County of Somerset	1901-11-15	1	\N	530	2	8	\N	f	\N	2778	5	9
Hawkesbury	of Haselbech in the County of Northampton and of Ollerton, Sherwood Forest, in the County of Nottingham	\N	\N	cr E of Liverpool 1905	553	2	8	\N	f	\N	2779	5	9
Newlands	of Newlands and Barrowfield in the County of the City of Glasgow and of Mauldslie Castle in the County of Lanark	1929-09-05	2	\N	592	2	8	\N	f	\N	2780	5	15
Colville of Culross	in the County of Perth	\N	\N	also 10th L C of C (Sc)	620	7	12	\N	f	\N	2781	5	4
Colebrooke	of Stebunheath in the County of Middlesex	1939-02-28	1	\N	662	2	8	\N	f	\N	2782	5	4
Willingdon	of Ratton in the County of Sussex	1979-03-19	2	cr V Willingdon 1924, E of Willingdon 1931, M of Willingdon 1936	698	2	8	\N	f	\N	2783	5	24
St Audries	of St Audries in the County of Somerset	1971-10-16	2	St. Audries	706	2	8	\N	f	\N	2784	5	20
Ruthven of Gowrie	of Gowrie in the County of Perth	\N	\N	subsumed in E of Gowrie on death of 2nd L 1956-04-16	845	4	8	\N	f	\N	2785	5	19
Runciman	of Shoreston in the County of Northumberland	\N	\N	subsumed in V Runciman of Doxford 13.8.1937	1007	2	8	\N	f	\N	2786	5	19
Nuffield	of Nuffield in the County of Oxford	1963-08-22	1	cr V Nuffield 24 Jan 1938	1020	2	8	\N	f	\N	2787	5	15
Camrose	of Hackwood Park in the County of Southampton	\N	\N	2nd V died 1995; 3rd V (= L Hartwell (life peer)) disclaimed 1995 & died 3 April 2001	1110	7	12	\N	f	\N	2788	5	4
Woodley	of Wallasey in the Metropolitan Borough of Wirral	\N	\N	\N	2970	5	8	\N	f	\N	2789	5	24
Bridges	of Headley in the County of Surrey and of Saint Nicholas at Wade in the County of Kent	\N	\N	\N	1339	2	8	\N	f	\N	2790	5	3
Somervell of Harrow	of Ewelme in the County of Oxford	1960-11-18	1	vice L Asquith of Bishopstone deceased	1310	1	8	\N	f	\N	2791	5	20
Taylor of Mansfield	of Mansfield in the County of Nottingham	1991-04-11	1	\N	1538	5	8	\N	f	\N	2792	5	21
Dunrossil	of Vallaquie in the Isle of North Uist and County of Inverness	\N	\N	\N	1381	2	12	\N	f	\N	2793	5	5
Bannerman of Kildonan	of Kildonan in the County of Sutherland	1969-05-10	1	\N	1582	5	8	\N	f	\N	2794	5	3
Alexander of Potterhill	of Paisley in the County of Renfrew	1993-09-08	1	\N	1705	5	8	\N	f	\N	2795	5	2
Charteris of Amisfield	of Amisfield in the District of East Lothian	1999-12-23	1	\N	1781	5	8	\N	f	\N	2796	5	4
Lowry	of Crossgar in the County of Down	1999-01-15	1	cr Lord of Appeal in Ordinary 5 Aug 1988; resigned 7 Jan 1994	1827	5	8	\N	f	\N	2797	5	13
Matthews	of Southgate in the London Borough of Enfield	1995-12-05	1	\N	1850	5	8	\N	f	\N	2798	5	14
Howe of Idlicote	of Shipston-on-Stow in the County of Warwickshire	\N	\N	Lady Howe of Aberavon	2423	5	8	\N	f	\N	2800	5	9
Gifford	of Saint Leonard in the County of Devon	\N	\N	\N	135	2	8	\N	f	\N	2768	5	8
Shafik	of Camden in the London Borough of Camden and of Alexandria in the Arab Republic of Egypt	\N	\N	\N	2966	5	8	\N	f	\N	2828	5	20
Sheehan	of Wimbledon in the London Borough of Merton and of Tooting in the London Borough of Wandsworth	\N	\N	\N	2829	5	8	\N	f	\N	2829	5	20
Rivers	of Sudeley Castle in the County of Gloucester	1880-03-31	6	SR to (1) Wm Augustus Pitt (brother) & h m of b; (2) Wm Horace Beckford (son of deceased dau) & h m of b	26	8	8	\N	f	1	2830	5	19
Hutchinson	of Knocklofty in the County of Tipperary	\N	\N	SR to heirs male of his mother by his father; was 2nd L Donoughmore (I)	110	3	12	\N	f	1	2831	5	9
Johnston of Rockport	of Caversham in the Royal County of Berkshire	2002-04-30	1	\N	1963	5	8	\N	f	\N	2802	5	11
Hollins	of Wimbledon in the London Borough of Merton and of Grenoside in the County of South Yorkshire	\N	\N	\N	2682	5	8	\N	f	\N	2826	5	9
Clinton-Davis	of Hackney in the London Borough of Hackney	\N	\N	surname was "Davis" at time of announcement of the peerage	2010	5	8	\N	f	\N	2803	5	4
Howe of Aberavon	of Tandridge in the County of Surrey	2015-10-09	1	\N	2071	5	8	\N	f	\N	2804	5	9
Woolf	of Barnes in the London Borough of Richmond	\N	\N	vice L Ackner resigned; appointed Master of the Rolls 1996; appointed LCJ 17 July 2000	2099	1	8	\N	f	\N	2805	5	24
Hope of Craighead	of Bamff in the District of Perth and Kinross	\N	\N	appointed a Lord of Appeal in Ordinary 1 October 1996 vice L Keith of Kinkel	2136	5	8	\N	f	\N	2806	5	9
Janner of Braunstone	of Leicester in the County of Leicestershire	2015-12-19	1	\N	2242	5	8	\N	f	\N	2807	5	11
Newton of Braintree	of Coggeshall in the County of Essex	2012-03-25	1	\N	2253	5	8	\N	f	\N	2808	5	15
Gueterbock	of Cranford in the London Borough of Hilllingdon	\N	\N	Succeeded as 18th L Berkeley 1992; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2374	6	8	\N	f	\N	2809	5	8
Temple-Morris	of Llandaff in the County of South Glamorgan and of Leominster in the County of Herefordshire	2018-05-01	1	\N	2415	5	8	\N	f	\N	2810	5	21
Laidlaw	of Rothiemay in Banffshire	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2476	5	8	\N	f	\N	2811	5	13
O'Neill of Clackmannan	of Clackmannan in Clackmannanshire	2020-08-26	1	\N	2514	5	8	\N	f	\N	2812	5	16
Stern of Brentford	of Elsted in the County of West Sussex and of Wimbledon in the London Borough of Merton	\N	\N	\N	2597	5	8	\N	f	\N	2813	5	20
Boateng	of Akyem in the Republic of Ghana and of Wembley in the London Borough of Brent	\N	\N	\N	2648	5	8	\N	f	\N	2814	5	3
Wood of Anfield	of Tonbridge in the County of Kent	\N	\N	\N	2709	5	8	\N	f	\N	2815	5	24
Houghton of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2892	5	8	\N	f	\N	2816	5	9
Clydesmuir	of Braidwood in the County of Lanark	\N	\N	Gazette announcement says "as on the 14th August, 1947"; ?th L died 2 Oct 1996	1239	2	8	\N	f	\N	2817	5	4
Campbell	of Saint Andrews in the County of Fife	\N	\N	wife had been cr B Stratheden 1836; title passed to 2nd L Stratheden	261	2	8	\N	f	\N	2818	5	4
Brancepeth	of Brancepeth in the County Palatine of Durham	\N	\N	4th L died 14 Dec 1995	351	3	8	\N	f	\N	2819	5	3
Balinhard	of Farnell in the County of Forfar	\N	\N	title passed to D of Fife on death of 11th Earl (16 Feb 1992)	367	4	8	\N	f	\N	2820	5	3
Blackburn	of Killearn in the County of Stirling	1896-01-08	1	1st Lord of Appeal in Ordinary; lost seat by resignation Dec 1886, reinstated by Act of 1887.	423	1	8	\N	f	\N	2821	5	3
Mount Stephen	of Mount Stephen in the Province of British Columbia and Dominion of Canada and of Dufftown in the County of Banff	1921-11-29	1	\N	525	2	8	\N	f	\N	2822	5	14
Redesdale	of Redesdale in the County of Northumberland	\N	\N	5th L died 3 March 1991	629	2	8	\N	f	\N	2823	5	19
Inchcape	of Strathnaver in the County of Sutherland	\N	\N	cr V Inchcape 1924, E of Inchcape 1929	709	2	8	\N	f	\N	2824	5	10
Aberdeen and Temair	in the County of Aberdeen and in the County of Meath and in the County of Argyll	\N	\N	\N	753	4	9	\N	t	\N	2825	5	2
Howells of St Davids	of Charlton in the London Borough of Greenwich	\N	\N	\N	2327	5	8	\N	f	\N	2827	5	9
Dunn	of Hong Kong Island in Hong Kong and of Knightsbridge in the Royal Borough of Kensington and Chelsea	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2028	5	8	\N	f	\N	2860	5	5
Mountbatten of Burma	of Romsey in the County of Southampton	\N	\N	SR to daus; cr E Mountbatten of Burma 18 Oct 1947	1212	2	12	\N	f	2	2861	5	14
Kitchener of Khartoum	and of the Vaal in the Colony of Transvaal, and of Aspall in the County of Suffolk	2011-12-16	3	SR to daughters & brothers; cr E Kitchener 1914	619	7	12	\N	f	1	2862	5	12
Northcliffe	of St Peter in the County of Kent	1922-08-14	1	\N	799	7	12	\N	f	\N	2833	5	15
Asquith of Yarnbury	of Yarnbury in the County of Wilts	1969-02-19	1	dau of 1st E of Oxford & Asquith	1497	5	8	\N	f	\N	2858	5	2
Casey	of Berwick in the State of Victoria and Commonwealth of Australia and of the City of Westminster	1976-06-17	1	\N	1392	5	8	\N	f	\N	2834	5	4
Tredegar	of Tredegar in the County of Monmouth	1962-11-17	6	2nd & 3rd L both cr V Tredegar - title extant 1905-13 & 1926-49	316	2	8	\N	f	\N	2835	5	21
Elphinstone	of Elphinstone in the County of Haddington	\N	\N	\N	486	4	8	\N	f	\N	2836	5	6
Reith	of Stonehaven in the County of Kincardine	\N	\N	2nd L disclaimed	1108	2	8	\N	f	\N	2837	5	19
Cudlipp	of Aldingbourne in the County of West Sussex	1998-05-17	1	\N	1713	5	8	\N	f	\N	2838	5	4
Pitt of Hampstead	of Hampstead in Greater London and of Hampstead in Grenada	1994-12-18	1	\N	1731	5	8	\N	f	\N	2839	5	17
Sumner	of Ibstone in the County of Buckingham	1934-05-24	1	\N	932	7	12	\N	f	\N	2842	5	20
D'Abernon	of Esher and of Stoke D'Abernon in the County of Surrey	1941-11-01	1	\N	924	7	12	\N	f	\N	2843	5	5
Bingham	of Melcombe Bingham in the County of Dorset	\N	\N	elected I. rep peer 1914	1023	3	8	\N	f	\N	2844	5	3
Alexander of Hillsborough	of Hillsborough in the City of Sheffield	1965-01-11	1	cr E Alexander of Hillsborough 30 Jan 1963	1251	2	12	\N	f	\N	2845	5	2
Norrie	of Wellington, New Zealand, and of Hawkesbury Upton in the County of Gloucester	\N	\N	\N	1347	2	8	\N	f	\N	2846	5	15
Cunningham of Hyndhope	of Kirkhope in the County of Selkirk	1963-06-12	1	cr V Cunningham of Hyndhope 26 Jan 1946	1176	2	8	\N	f	\N	2847	5	4
Stuart de Decies	of Dromana within the Decies in the County of Waterford	1874-01-23	1	son failed to establish his legitimacy	248	2	8	\N	f	\N	2848	5	20
Egremont	of Petworth in the County of Sussex	\N	\N	succ as 6th L Leconfield 1967	1451	2	8	\N	f	\N	2849	5	6
Maelor	of Rhosllanerchrugog in the County of Denbigh	1984-11-18	1	\N	1544	5	8	\N	f	\N	2850	5	14
Hartwell	of Peterborough Court in the City of London	2001-04-03	1	succ 15 Feb 1995 as 3rd V Camrose; disclaimed that year	1585	5	8	\N	f	\N	2851	5	9
Home of the Hirsel	of Coldstream in the County of Berwick	1995-10-09	1	had disclaimed Earldom of Home	1708	5	8	\N	f	\N	2852	5	9
Harmar-Nicholls	of Peterborough in Cambridgeshire	2000-09-15	1	\N	1715	5	8	\N	f	\N	2853	5	9
Campbell of Croy	of Croy in the County of Nairn	2005-04-26	1	\N	1714	5	8	\N	f	\N	2854	5	4
Hutchinson of Lullington	of Lullington in the County of East Sussex	2017-11-13	1	\N	1800	5	8	\N	f	\N	2855	5	9
McAlpine of Moffat	of Medmenham in the County of Buckinghamshire	1990-01-07	1	\N	1845	5	8	\N	f	\N	2856	5	14
Cambridge	\N	1981-04-16	2	full names: Adolphus Charles Alexander Albert Edward George Philip Louis Ladislaus	793	2	9	\N	t	\N	2857	5	4
St Vincent	of Meaford in the County of Stafford	\N	\N	SR to (1) William Henry Ricketts & h m of b; (2) Edward Jervis Ricketts (bro of (1)) & h m of b; (3) Mary C of Northesk & h m of b	7	8	12	\N	f	\N	2863	5	20
Bacon	of the City of Leeds and of Normanton in the West Riding of the County of York	1993-03-24	1	\N	1628	5	8	\N	f	\N	2859	5	3
Portal of Hungerford	of Hungerford in the County of Berks	1990-09-29	2	created V Portal of Hungerford (usual remainder) 28 Jan 1946; special remainder in default of male issue to eldest dau Rosemary Ann Portal & heirs male & in default to every other dau by seniority	1177	2	8	\N	f	2	2895	5	17
McFadzean of Kelvinside	of Kelvinside in the District of the City of Glasgow	1992-05-23	1	\N	1851	5	8	\N	f	\N	2864	5	14
Nicholson of Winterbourne	of Winterbourne in the Royal County of Berkshire	\N	\N	\N	2257	5	8	\N	f	\N	2893	5	15
Rippon of Hexham	of Hesleyside in the County of Northumberland	1997-01-28	1	\N	1972	5	8	\N	f	\N	2865	5	19
Colnbrook	of Waltham St Lawrence in the Royal County of Berkshire	1996-10-04	1	\N	1981	5	8	\N	f	\N	2866	5	4
Rodgers of Quarry Bank	of Kentish Town in the London Borough of Camden	\N	\N	\N	2059	5	8	\N	f	\N	2867	5	19
Griffiths of Burry Port	of Pembrey and Burry Port in the County of Dyfed	\N	\N	\N	2500	5	8	\N	f	\N	2868	5	8
Kerr of Tonaghmore	of Tonaghmore in the County of Down	2020-12-01	1	LCJ of Northern Ireland	2613	1	8	\N	f	\N	2869	5	12
Hay of Ballyore	of Ballyore in the City of Londonderry	\N	\N	\N	2810	5	8	\N	f	\N	2870	5	9
Palmer of Childs Hill	of Childs Hill in the London Borough of Barnet	\N	\N	\N	2711	5	8	\N	f	\N	2871	5	17
Goddard of Stockport	of Stockport in the County of Greater Manchester	\N	\N	\N	2790	5	8	\N	f	\N	2872	5	8
McCrea of Magherafelt and Cookstown	of Magherafelt in the County of Londonderry and Cookstown in the County of Tyrone	\N	\N	\N	2896	5	8	\N	f	\N	2873	5	14
Foster of Thames Bank	of Reddish in the County of Greater Manchester	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2322	5	8	\N	f	\N	2874	5	7
Belstead	of Ipswich in the County of Suffolk	2005-12-03	2	2nd L. created L. Ganzoni (life peer) 17 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1084	2	8	\N	f	\N	2875	5	3
Russell of Liverpool	in the County Palatine of Lancaster	\N	\N	\N	843	2	8	\N	f	\N	2876	5	19
Greenwood	of Llanbister in the County of Radnor	2003-07-07	3	cr V Greenwood 16 Feb 1937	972	2	8	\N	f	\N	2877	5	8
Hanworth	of Hanworth in the County of Middlesex	\N	\N	2nd V died 31 Aug 1996	1047	7	12	\N	f	\N	2878	5	9
Cherwell	of Oxford in the County of Oxford	1957-07-03	1	cr V Cherwell 26 June 1956	1117	2	8	\N	f	\N	2879	5	4
Baillieu	of Sefton in the Commonwealth of Australia and of Parkwood in the County of Surrey	\N	\N	\N	1292	2	8	\N	f	\N	2880	5	3
Sherfield	of Sherfield-on-Loddon in the County of Southampton	\N	\N	\N	1466	2	8	\N	f	\N	2881	5	20
MacLeod of Fuinary	of Fuinary in Morven in the County of Argyll	1991-06-27	1	\N	1559	5	8	\N	f	\N	2882	5	14
Roberthall	of Silverspur in the State of Queensland and Commonwealth of Australia and of Trenance in the County of Cornwall	1988-09-17	1	\N	1605	5	8	\N	f	\N	2883	5	19
Maclean	of Duart and Morven in the County of Argyll	1990-02-08	1	\N	1633	5	8	\N	f	\N	2884	5	14
Gilmour of Craigmillar	of Craigmillar in the District of the City of Edinburgh	2007-09-21	1	\N	2097	5	8	\N	f	\N	2885	5	8
Nicholls of Birkenhead	of Stoke D'Abernon in the County of Surrey	2019-09-25	1	vice L Templeman resigned	2125	1	8	\N	f	\N	2886	5	15
Lofthouse of Pontefract	of Pontefract in the County of West Yorkshire	2012-11-01	1	\N	2195	5	8	\N	f	\N	2887	5	13
Cowdrey of Tonbridge	of Tonbridge in the County of Kent	2000-12-04	1	\N	2202	5	8	\N	f	\N	2888	5	4
Harris of Haringey	of Hornsey in the London Borough of Haringey	\N	\N	\N	2301	5	8	\N	f	\N	2890	5	9
Kennedy of Cradley	of Cradley in the Metropolitan Borough of Dudley	\N	\N	\N	2776	5	8	\N	f	\N	2892	5	12
Spencer-Churchill	of Chartwell in the County of Kent	1977-12-12	1	\N	1523	5	8	\N	f	\N	2894	5	20
Bath	in the County of Somerset	1808-07-14	1	\N	33	7	6	\N	t	\N	2926	5	3
Fife	\N	\N	\N	SR to 2 named daus	604	8	4	\N	t	2	2927	5	7
Brooke of Sutton Mandeville	of Sutton Mandeville in the County of Wiltshire	\N	\N	\N	2446	5	8	\N	f	\N	2896	5	3
Tipperary	\N	1904-03-17	2	\N	2996	2	6	\N	t	\N	26	5	21
Brown of Eaton-under-Heywood	of Eaton-under-Heywood in the County of Shropshire	\N	\N	vice L Hobhouse of Woodborough resigned	2457	1	8	\N	f	\N	2897	5	3
Morris of Handsworth	of Handsworth in the County of West Midlands	\N	\N	\N	2562	5	8	\N	f	\N	2898	5	14
Harries of Pentregarth	of Ceinewydd in the County of Dyfed	\N	\N	\N	2577	5	8	\N	f	\N	2899	5	9
Young of Cookham	of Cookham in the Royal County of Berkshire	\N	\N	\N	2821	5	8	\N	f	\N	2900	5	26
Empey	of Shandon in the City and County Borough of Belfast	\N	\N	\N	2710	5	8	\N	f	\N	2901	5	6
Goldsmith of Richmond Park	of Richmond Park in the London Borough of Richmond upon Thames	\N	\N	\N	2933	5	8	\N	f	\N	2902	5	8
Aldington	of Bispham in the County of the Borough of Blackpool	\N	\N	subsequently created L Low (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1423	2	8	\N	f	\N	2905	5	2
Pakenham of Cowley	of Cowley in the County of Oxfordshire	2001-08-03	1	Cr 1st L Pakenham 25 Sep 1945; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 p.m.\n(had also succeeded as 7th E of Longford (I) and L Silchester 1961)	2358	6	8	\N	f	\N	2906	5	17
Hutton	of Bresagh in the County of Down	2020-07-14	1	No Downing St announcement: mentioned in Lord Chancellor's Dept announcement of appointment of successor as LCJ of NI; appointed vice L Woolf MR	2176	1	8	\N	f	\N	2907	5	9
Albany	\N	1919-03-28	2	2nd L struck from roll 28 Mch 1919	447	2	4	\N	t	\N	2908	5	2
Argyll	in Scotland	\N	\N	already 4th L Sundridge (GB) cr 1766, succ 1847	532	8	4	\N	t	\N	2909	5	2
Buckingham and Chandos	\N	1889-03-26	3	SR for E Temple of Stowe (extant 2006)	130	7	4	\N	t	\N	2910	5	3
Cambridge	\N	\N	\N	not introduced as not a member of the House of Lords	2740	2	4	\N	t	\N	2911	5	4
Cleveland	\N	1891-08-21	4	\N	204	7	4	\N	t	\N	2912	5	4
Connaught and Strathearn	\N	1943-04-26	2	\N	408	2	4	\N	t	\N	2913	5	4
Kent	\N	\N	\N	\N	1028	2	4	\N	t	\N	2914	5	12
Sussex	\N	\N	\N	not introduced as not a member of the House of Lords	2908	2	4	\N	t	\N	2915	5	20
Wellington	in the County of Somerset	\N	\N	\N	71	7	4	\N	t	\N	2916	5	24
Windsor	\N	1972-05-28	1	\N	1062	2	4	\N	t	\N	2917	5	24
York	\N	1936-12-11	1	merged in Crown 11 Dec 1936	855	2	4	\N	t	\N	2918	5	26
Ancaster	in the County of Lincoln	1983-03-29	3	\N	540	7	6	\N	t	\N	2919	5	2
Beaconsfield	in the County of Buckingham	1881-04-19	1	\N	421	2	6	\N	t	\N	2920	5	3
Bessborough	\N	1993-12-05	2	\N	1066	8	6	\N	t	\N	2921	5	3
Burlington	\N	\N	\N	2nd E succ as 7th D of Devonshire 1858	177	2	6	\N	t	\N	2922	5	3
Chisholm of Owlpen	of Owlpen in the County of Gloucestershire	\N	\N	\N	2792	5	8	\N	f	\N	2923	5	4
Brecknock	\N	\N	0	\N	2997	7	6	\N	t	\N	53	5	3
Rocksavage	in the County Palatine of Chester	\N	0	\N	2998	7	6	\N	t	\N	2948	5	19
Rawdon	\N	1868-11-01	4	\N	2999	7	6	\N	t	\N	120	5	19
Ormelie	\N	1862-11-08	2	\N	3000	7	6	\N	t	\N	206	5	16
Cromartie	\N	\N	\N	SR to younger children, inc daughters, but to be separate from earldom of Sutherland	330	2	6	\N	t	\N	2929	5	4
Williams of Trafford	of Hale in the County of Greater Manchester	\N	\N	\N	2777	5	8	\N	f	\N	2925	5	24
Ellenborough	in the County of Cumberland	1871-12-22	1	\N	271	7	6	\N	t	\N	2933	5	6
Fife	\N	1912-01-29	1	was already 2nd L Skene (cr 1857, succ 1879); cr D of Fife 1889 & (SR) 1900	480	8	6	\N	t	\N	2934	5	7
Gowrie	\N	\N	\N	\N	1151	7	6	\N	t	\N	2935	5	8
Halifax	\N	\N	\N	had been cr 1st L Irwin (1925)	1147	7	6	\N	t	\N	2936	5	9
Inchcape	\N	\N	\N	3rd E died 17 March 1994	959	7	6	\N	t	\N	2937	5	10
Lathom	in the County Palatine of Lancaster	1930-02-06	3	\N	437	7	6	\N	t	\N	2938	5	13
Liverpool	\N	\N	\N	\N	644	7	6	\N	t	\N	2939	5	13
Midlothian	\N	\N	\N	grantee was also 2nd L Rosebery (cr 1828)	714	7	6	\N	t	\N	2940	5	14
Ravensworth	of Ravensworth Castle in the County Palatine of Durham	1904-02-07	3	\N	407	7	6	\N	t	\N	2941	5	19
Reading	\N	\N	\N	cr M of Reading 1926	798	7	6	\N	t	\N	2942	5	19
Stockton	\N	\N	\N	\N	1926	2	6	\N	t	\N	2945	5	20
Swinton	\N	\N	\N	2nd E. died 24 March 2006	1318	7	6	\N	t	\N	2946	5	20
Wessex	\N	\N	\N	created also E of Forfar 10 March 2019	2311	2	6	\N	t	\N	2947	5	24
Cholmondeley	in the County Palatine of Chester	\N	\N	?th M died 13 March 1990	94	7	9	\N	t	\N	2948	5	4
Adams of Craigielea	of Craigielea in Renfrewshire	\N	\N	\N	2534	5	8	\N	f	\N	2949	5	2
Afshar	of Heslington in the County of North Yorkshire	\N	\N	\N	2598	5	8	\N	f	\N	2950	5	2
Airey of Abingdon	of Abingdon in the County of Oxford	1992-11-27	1	\N	1833	5	8	\N	f	\N	2951	5	2
Altmann	of Tottenham in the London Borough of Haringey	\N	\N	\N	2812	5	8	\N	f	\N	2952	5	2
Amos	of Brondesbury in the London Borough of Brent	\N	\N	\N	2209	5	8	\N	f	\N	2953	5	2
Andrews	of Southover in the County of East Sussex	\N	\N	\N	2388	5	8	\N	f	\N	2954	5	2
Anelay of St Johns	of St Johns in the County of Surrey	\N	\N	\N	2170	5	8	\N	f	\N	2955	5	2
Armstrong of Hill Top	of Crook in the County of Durham	\N	\N	\N	2630	5	8	\N	f	\N	2956	5	2
Ashton of Upholland	of St Albans in the County of Hertfordshire	\N	\N	\N	2345	5	8	\N	f	\N	2957	5	2
Barran	of Bathwick in the City of Bath	\N	\N	\N	2901	5	8	\N	f	\N	2958	5	3
Bennett of Manor Castle	of Camden in the London Borough of Camden	\N	\N	\N	2913	5	8	\N	f	\N	2959	5	3
Bertin	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2876	5	8	\N	f	\N	2960	5	3
Billingham	of Banbury in the County of Oxfordshire	\N	\N	\N	2380	5	8	\N	f	\N	2961	5	3
Birk	of Regent's Park in Greater London	1996-12-29	1	\N	1571	5	8	\N	f	\N	2962	5	3
Blackstone	of Stoke Newington in Greater London	\N	\N	\N	1958	5	8	\N	f	\N	2963	5	3
Boycott	of Whitefield in the County of Somerset	\N	\N	\N	2905	5	8	\N	f	\N	2965	5	3
Brigstocke	of Kensington in the Royal Borough of Kensington and Chelsea	2004-04-30	1	\N	2017	5	8	\N	f	\N	2966	5	3
Brooke of Ystradfellte	of Ystradfellte in the County of Brecknock	2000-09-01	1	\N	1483	5	8	\N	f	\N	2967	5	3
Burt of Solihull	of Solihull in the County of West Midlands	\N	\N	\N	2839	5	8	\N	f	\N	2968	5	3
Burton of Coventry	of Coventry in the County of Warwick	1991-10-06	1	\N	1426	5	8	\N	f	\N	2969	5	3
Chester	\N	1901-01-22	1	\N	3001	7	6	\N	t	\N	246	5	4
Kent	\N	1900-07-30	1	\N	3002	2	6	\N	t	\N	322	5	12
Ulster	\N	1900-07-30	1	\N	3003	2	6	\N	t	\N	322	5	22
Chandos	\N	1889-03-26	3	\N	3004	7	9	\N	t	\N	2910	5	4
Crewe	of Crewe in the County Palatine of Chester	1945-06-20	1	cr M of Crewe 1911	563	7	6	\N	t	\N	2932	5	4
David	of Romsey in the City of Cambridge	2009-11-29	1	\N	1792	5	8	\N	f	\N	2974	5	5
Deech	of Cumnor in the County of Oxfordshire	\N	\N	\N	2541	5	8	\N	f	\N	2975	5	5
Delacourt-Smith of Alteryn	of Alteryn in the County of Gwent	2010-06-08	1	\N	1699	5	8	\N	f	\N	2976	5	5
Elliot of Harwood	of Rulewater in the County of Roxburgh	1994-01-03	1	\N	1366	5	8	\N	f	\N	2977	5	6
Faithfull	of Wolvercote in the County of Oxfordshire	1996-03-13	1	\N	1747	5	8	\N	f	\N	2978	5	7
Falkender	of West Haddon in Northamptonshire	2019-02-06	1	\N	1703	5	8	\N	f	\N	2979	5	7
Falkner of Margravine	of Barons Court in the London Borough of Hammersmith and Fulham	\N	\N	\N	2460	5	8	\N	f	\N	2980	5	7
Farrington of Ribbleton	of Fulwood in the County of Lancashire	2018-03-30	1	\N	2123	5	8	\N	f	\N	2981	5	7
Gardner of Parkes	of Southgate in Greater London and of Parkes in the State of New South Wales and Commonwealth of Australia	\N	\N	\N	1869	5	8	\N	f	\N	2982	5	8
Golding	of Newcastle-under-Lyme in the County of Staffordshire	\N	\N	\N	2439	5	8	\N	f	\N	2983	5	8
Hylton-Foster	of the City of Westminster	2002-10-31	1	\N	1530	5	8	\N	f	\N	2984	5	9
James of Holland Park	of Southwold in the County of Suffolk	2014-11-27	1	James = maiden surname; also described as "(Mrs White)" in Gazette announcement of 31.12.90.	2035	5	8	\N	f	\N	2985	5	11
Lee of Asheridge	of the City of Westminster	1988-11-16	1	\N	1629	5	8	\N	f	\N	2986	5	13
Linklater of Butterstone	of Riemore in Perth and Kinross	\N	\N	\N	2255	5	8	\N	f	\N	2987	5	13
Macleod of Borve	of Borve in the Isle of Lewis	1999-11-17	1	\N	1644	5	8	\N	f	\N	2988	5	14
Park of Monmouth	of Broadway in the County of Hereford and Worcester	2010-03-24	1	\N	2008	5	8	\N	f	\N	2989	5	17
Scott of Bybrook	of Upper Wraxall in the County of Wiltshire	\N	\N	\N	2837	5	8	\N	f	\N	2990	5	20
Cave of Richmond	\N	1938-01-07	1	husband died before LP	944	2	6	\N	f	\N	2991	5	4
Mountbatten of Burma	\N	\N	\N	SR to daughters	1233	7	6	\N	f	2	2994	5	14
Brougham and Vaux	of Brougham in the County of Westmorland and of Highhead Castle in the County of Cumberland	\N	\N	SR to brother	324	8	8	\N	f	1	2995	5	3
Bowes	of Streatlam Castle in the County of Durham and of Lunedale in the County of York	1820-07-03	1	\N	84	4	8	\N	f	\N	65	5	3
Carnegy of Lour	of Lour in the District of Angus	2010-11-09	1	\N	1880	5	8	\N	f	\N	2972	5	4
De Grey	of Wrest in the County of Bedford	1923-09-22	4	SR to sister & her male issue; 3rd E cr M of Ripon 1871	103	7	6	\N	f	2	121	5	5
Wharncliffe	of Wortley in the County of York	\N	\N	3rd L cr E of Wharncliffe 1876	144	2	8	\N	f	\N	127	5	24
Panmure	of Brechin and Navar in the County of Forfar	1874-07-06	2	2nd L succ as 11th E of Dalhousie 22 Dec 1860	184	2	8	\N	f	\N	158	5	17
Lovat	of Lovat in the County of Inverness	\N	\N	was L Lovat (S) but for attainder, which was reversed 1857	227	2	8	\N	f	\N	192	5	13
Sydenham	of Sydenham in the County of Kent and of Toronto in Canada	1841-09-19	1	\N	260	2	8	\N	f	\N	225	5	20
Wensleydale	of Wensleydale in the North Riding of the County of York	1868-02-25	1	life peerage created under prerogative; cr L Wensleydale (hereditary) 23 July 1856	296	5	8	\N	f	\N	258	5	24
Hare	of Convamore in the County of Cork	\N	\N	5th E of Listowel died 12 March 1997	368	3	8	\N	f	\N	317	5	9
Bloomfield	of Ciamhalltha in the County of Tipperary	1879-08-17	1	\N	382	3	8	\N	f	\N	333	5	3
Howth	of Howth in the County of Dublin	1909-03-09	1	\N	449	3	8	\N	f	\N	388	5	9
Campbell of Surbiton	of Surbiton in the Royal Borough of Kingston upon Thames	\N	\N	\N	2586	5	8	\N	f	\N	2971	5	4
Onslow	of Onslow in the County of Salop	\N	\N	had been cr 1st L Cranley 1776 before succeeding as 4th L Onslow	12	7	6	Q1277380	t	\N	30	5	16
Ashton	of Ashton in the County Palatine of Lancaster	1930-05-27	1	\N	566	2	8	\N	f	\N	498	5	2
Farquhar	of Saint Marylebone in the County of London	1923-08-30	1	cr V Farquhar 1917, E Farquhar 1922	593	2	8	\N	f	\N	518	5	7
Alverstone	of Alverstone in the Isle of Wight and County of Southampton	1915-12-15	1	cr V Alverstone 1913	611	2	8	\N	f	\N	536	5	2
Linlithgow	in the County of Linlithgow or West Lothian	\N	\N	already also 5th L Hopetoun (cr 1809)	630	7	9	\N	t	\N	558	5	13
Northcliffe	of the Isle of Thanet in the County of Kent	1922-08-14	1	cr V Northcliffe 1918	648	2	8	\N	f	\N	569	5	15
Furness	of Grantley in the West Riding of the County of York	1995-05-01	3	2nd L cr V Furness 1918	697	2	8	\N	f	\N	612	5	7
Whitburgh	of Whitburgh in the County of Midlothian	1967-09-29	1	father died 31.7.12, before LP	733	2	8	\N	f	\N	643	5	24
French of Ypres	and of High Lake in the County of Roscommon	1988-03-04	3	cr E of Ypres 1922	757	2	12	\N	f	\N	666	5	7
Leverhulme	of Bolton-le-Moors in the County Palatine of Lancaster	2000-07-04	3	cr V Leverhulme 1922	788	2	8	\N	f	\N	695	5	13
Sinha	of Raipur in the Presidency of Bengal	\N	\N	3rd L died 6 Jan 1989; 4th L died 25 July 1992	825	2	8	\N	f	\N	728	5	20
Seaforth	of Brahan in Urray, in the County of Ross and Cromarty	1923-03-03	1	\N	862	2	8	\N	f	\N	754	5	20
Lawrence of Kingsgate	of Holland House, Kingsgate, in the County of Kent	1927-12-17	1	\N	899	2	8	\N	f	\N	780	5	13
Cornwallis	of Linton in the County of Kent	\N	\N	\N	933	2	8	\N	f	\N	819	5	4
Dulverton	of Batsford in the County of Gloucester	\N	\N	2nd L died 17 Feb 1992	965	2	8	\N	f	\N	848	5	5
Milne	of Salonika and of Rubislaw in the County of Aberdeen	\N	\N	\N	1010	2	8	\N	f	\N	887	5	14
St Just	of St Just in Penwith in the County of Cornwall	1984-10-14	2	St. Just	1039	2	8	\N	f	\N	911	5	20
Marchwood	of Penang and of Marchwood in the County of Southampton	\N	\N	cr V Marchwood 13 Sep 1945	1072	2	8	\N	f	\N	937	5	14
Fairfield	of Caldy in the County Palatine of Chester	1945-02-04	1	\N	1091	2	8	\N	f	\N	958	5	7
Bennett	of Mickleham in the County of Surrey and of Calgary and Hopewell in the Dominion of Canada	1947-06-27	1	\N	1118	2	12	\N	f	\N	981	5	3
Chetwode	of Chetwode in the County of Buckingham	\N	\N	\N	1162	2	8	\N	f	\N	1019	5	4
Westwood	of Gosforth in the County of Northumberland	\N	\N	2nd L died 8 Nov 1991	1142	2	8	\N	f	\N	1036	5	24
Pakenham	of Cowley in the City of Oxford	\N	\N	succ 4 Feb 1961 as L Silchester & E Longford (I); subsequently created L Pakenham of Cowley (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1180	2	8	\N	f	\N	1037	5	17
Haden-Guest	of Saling in the County of Essex	\N	\N	4th L died 8 April 1996	1255	2	8	\N	f	\N	1100	5	9
Asquith of Bishopstone	of Bishopstone in the County of Sussex	1954-08-24	1	vice L MacDermott appointed LCJ of Northern Ireland	1269	1	8	\N	f	\N	1115	5	2
Freyberg	of Wellington New Zealand and of Munstead in the County of Surrey	\N	\N	2nd L died 26 May 1993	1272	2	8	\N	f	\N	1152	5	7
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	originally cr life baron	1311	7	12	\N	f	\N	1154	5	20
Stopford of Fallowfield	of Hindley Green in the County Palatine of Lancaster	1961-03-06	1	\N	1357	5	8	\N	f	\N	1189	5	20
Morrison of Lambeth	of Lambeth in the County of London	1965-03-06	1	\N	1379	5	8	\N	f	\N	1209	5	14
Ravensdale of Kedleston	of Kedleston in the County of Derby	1966-02-09	1	peeress in her own right	1368	6	8	\N	f	\N	1232	5	19
Ilford	of Bury in the County Palatine of Lancaster	1974-08-20	1	\N	1433	5	8	\N	f	\N	1255	5	10
Colville of Culross	in the County of Perth	\N	\N	cr V Colville of Culross 1902	487	4	8	\N	f	\N	459	5	4
Cooper of Stockton Heath	of Stockton Heath in the County Palatine of Chester	1988-09-02	1	\N	1551	5	8	\N	f	\N	1360	5	4
Kilmany	of Kilmany in the County of Fife	1985-08-06	1	\N	1539	5	8	\N	f	\N	1385	5	12
Constantine	of Maraval in Trinidad and Tobago and of Nelson in the County Palatine of Lancaster	1971-07-01	1	\N	1601	5	8	\N	f	\N	1403	5	4
Ballantrae	of Auchairne in the County of Ayr and of the Bay of Islands in New Zealand	1980-11-28	1	\N	1658	5	8	\N	f	\N	1451	5	3
Wallace of Campsie	of Newlands in the County of the City of Glasgow	1997-12-23	1	\N	1694	5	8	\N	f	\N	1483	5	24
Stewart of Alvechurch	of Fulham in Greater London	1984-12-28	1	\N	1718	5	8	\N	f	\N	1510	5	20
Balniel	of Pitcorthie in the County of Fife	\N	\N	succ as E of Crawford & Balcarres 1975	1725	5	8	\N	f	\N	1512	5	3
Thomson of Monifieth	of Monifieth in the District of the City of Dundee	2008-10-03	1	\N	1774	5	8	\N	f	\N	1555	5	21
Hill-Norton	of South Nutfield in the County of Surrey	2004-05-16	1	\N	1809	5	8	\N	f	\N	1582	5	9
Strauss	of Vauxhall in the London Borough of Lambeth	1993-06-05	1	\N	1818	5	8	\N	f	\N	1593	5	20
Bridge of Harwich	of Harwich in the County of Essex	2007-11-20	1	vice V Dilhorne resigned & since died	1852	1	8	\N	f	\N	1617	5	3
Plummer of St. Marylebone	of the City of Westminster	2009-10-02	1	\N	1865	5	8	\N	f	\N	1631	5	17
Howard of Henderskelfe	of Henderskelfe in the County of North Yorkshire	1984-11-27	1	\N	1900	5	8	\N	f	\N	1659	5	9
Peyton of Yeovil	of Yeovil in the County of Somerset	2006-11-22	1	\N	1917	5	8	\N	f	\N	1679	5	17
Turner of Camden	of Camden in Greater London	2018-02-26	1	some sources give date of birth as 18 Sep 1927	1941	5	8	\N	f	\N	1707	5	21
Cocks of Hartcliffe	of Chinnor in the County of Oxfordshire	2001-03-26	1	\N	1973	5	8	\N	f	\N	1725	5	4
Soulsby of Swaffham Prior	of Swaffham Prior in the County of Cambridgeshire	2017-05-08	1	\N	2018	5	8	\N	f	\N	1764	5	20
Macfarlane of Bearsden	of Bearsden in the District of Bearsden and Milngavie	\N	\N	\N	2053	5	8	\N	f	\N	1793	5	14
Denton of Wakefield	of Wakefield in the County of West Yorkshire	2001-02-05	1	\N	2043	5	8	\N	f	\N	1820	5	5
Cooke of Islandreagh	of Islandreagh in the County of Antrim	2007-11-13	1	\N	2094	5	8	\N	f	\N	1833	5	4
Blaker	of Blackpool in the County of Lancashire and of Lindfield in the County of West Sussex	2009-07-05	1	\N	2130	5	8	\N	f	\N	1859	5	3
Borrie	of Abbots Morton in the County of Hereford and Worcester	2016-09-30	1	\N	2145	5	8	\N	f	\N	1876	5	3
Lloyd of Highbury	of Highbury in the London Borough of Islington	2006-06-28	1	\N	2158	5	8	\N	f	\N	1900	5	13
Bagri	of Regent's Park in the City of Westminster	2017-04-26	1	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2177	5	8	\N	f	\N	1906	5	3
Burlison	of Rowlands Gill in the County of Tyne and Wear	2008-05-20	1	\N	2235	5	8	\N	f	\N	1956	5	3
Clement-Jones	of Clapham in the London Borough of Lambeth	\N	\N	\N	2272	5	8	\N	f	\N	1986	5	4
Williamson of Horton	of Horton in the County of Somerset	2015-08-30	1	\N	2306	5	8	\N	f	\N	2005	5	24
King of West Bromwich	of West Bromwich in the County of West Midlands	2013-01-09	1	\N	2329	5	8	\N	f	\N	2035	5	12
Hodgson of Astley Abbotts	of Nash in the County of Shropshire	\N	\N	\N	2401	5	8	\N	f	\N	2064	5	9
Low	of Bispham in the County of Lancashire	2000-12-07	1	Cr 1st L Aldington 29 Jan 1962; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2355	6	8	\N	f	\N	2069	5	13
Bernstein of Craigweil	of Craigweil in the County of West Sussex	2010-04-12	1	\N	2396	5	8	\N	f	\N	2096	5	3
Soper	of Kingsway in the London Borough of Camden	1998-12-22	1	\N	1517	5	8	\N	f	\N	1331	5	20
Morris of Bolton	of Bolton in the County of Greater Manchester	\N	\N	born 1953	2471	5	8	\N	f	\N	2171	5	14
Cameron of Dillington	of Dillington in the County of Somerset	\N	\N	\N	2498	5	8	\N	f	\N	2180	5	4
Smith of Finsbury	of Finsbury in the London Borough of Islington	\N	\N	\N	2526	5	8	\N	f	\N	2199	5	20
Hastings of Scarisbrick	of Scarisbrick in the County of Lancashire	\N	\N	\N	2544	5	8	\N	f	\N	2220	5	9
Williams of Oystermouth	of Oystermouth in the City and County of Swansea	\N	\N	\N	2747	5	8	\N	f	\N	2243	5	24
Neuberger of Abbotsbury	of Abbotsbury in the County of Dorset	\N	\N	vice L Nicholls of Birkenhead	2580	1	8	\N	f	\N	2263	5	15
Kinnock of Holyhead	of Holyhead in the County of Ynys Môn	\N	\N	wife of Lord Kinnock	2614	5	8	\N	f	\N	2292	5	12
Gardiner of Kimble	of Kimble in the County of Buckinghamshire	\N	\N	\N	2640	5	8	\N	f	\N	2314	5	8
Beecham	of Benwell and Newcastle upon Tyne in the County of Tyne and Wear	\N	\N	\N	2674	5	8	\N	f	\N	2358	5	3
Stoneham of Droxford	of the Meon Valley in the County of Hampshire	\N	\N	\N	2712	5	8	\N	f	\N	2394	5	20
Willetts	of Havant in the County of Hampshire	\N	\N	\N	2849	5	8	\N	f	\N	2438	5	24
Holmes of Richmond	of Richmond in the London Borough of Richmond upon Thames	\N	\N	\N	2768	5	8	\N	f	\N	2483	5	9
Haselhurst	of Saffron Walden in the County of Essex	\N	\N	\N	2902	5	8	\N	f	\N	2519	5	9
Wharton of Yarm	of Yarm in the County of North Yorkshire	\N	\N	\N	2940	5	8	\N	f	\N	2554	5	24
Hunt of Bethnal Green	of Bethnal Green in the London Borough of Tower Hamlets	\N	\N	\N	2927	5	8	\N	f	\N	2582	5	9
Riddell	of Walton Heath in the County of Surrey	1934-12-05	1	described by John Grigg as first divorced man to be created a peer (Sunday Telegraph, 2 Feb 1997; date wringly given as 1917)	851	2	8	\N	f	\N	2636	5	19
Radcliffe	of Werneth in the County Palatine of Lancaster	1977-04-01	1	vice L du Parcq deceased; cr V Radcliffe 11 Jly 1962	1247	1	8	\N	f	\N	2663	5	19
Hale of Richmond	of Easby in the County of North Yorkshire	\N	\N	vice L Millett resigned	2455	1	8	\N	f	\N	2727	5	9
Lyons	of Christ Church in the County of Southampton	1887-12-05	1	said to have died while a patent for an earldom was in preparation	454	7	12	\N	f	\N	2751	5	13
Seaford	of Seaford in the County of Sussex	\N	\N	2nd L was already 6th L Howard de Walden; title separated again on death of 9th L Howard de Walden & 5th L Seaford on 9 July 1999.	146	2	8	\N	f	\N	2769	5	20
McAlpine of West Green	of West Green in the County of Hampshire	2014-01-17	1	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	1925	5	8	\N	f	\N	2799	5	14
Grenfell of Kilvey	of Kilvey in the County of Swansea	\N	\N	Succeeded as 3rd L Grenfell 1976; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2372	6	8	\N	f	\N	2840	5	8
Sheppard of Liverpool	of West Kirby in the County of Merseyside	2005-03-05	1	previously a member of HL as Bp of Liverpool	2269	5	8	\N	f	\N	2889	5	20
Erroll of Hale	of Kilmun in the County of Argyll	2000-09-14	1	subsequently created L Erroll of Kilmun (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1495	2	8	\N	f	\N	2903	5	6
Camperdown	of Lundie in the County of Forfar and of Gleneagles in the County of Perth	1933-12-05	4	\N	193	7	6	\N	t	\N	2930	5	4
Snowdon	\N	\N	\N	subsequently created L. Armstrong-Jones (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1419	2	6	\N	t	\N	2944	5	20
Butler-Sloss	of Marsh Green in the County of Devon	\N	\N	\N	2569	5	8	\N	f	\N	2970	5	3
Castle of Blackburn	of Ibstone in the County of Buckinghamshire	2002-05-03	1	\N	2025	5	8	\N	f	\N	2973	5	4
Hill	of Almaraz and of Hawkstone and Hardwicke in the County of Salop	\N	\N	SR in default of h m of b to issue of late brother John Hill; cr V Hill 1842 with similar remainder	102	8	8	\N	f	1	2993	5	9
Bhattacharyya	of Moseley in the County of West Midlands	2019-03-01	1	\N	2462	5	8	\N	f	\N	2148	5	3
Uffington	in the County of Berks	\N	0	\N	3007	7	12	\N	f	\N	29	5	22
Macleod	of Castle Leod in the County of Cromartie	\N	0	\N	3009	2	8	\N	f	\N	2929	5	14
Marsham	of the Mote in the County of Kent	\N	0	\N	3010	7	12	\N	f	\N	32	5	14
Grey de Wilton	\N	\N	0	\N	3011	7	12	\N	f	\N	33	5	8
Arklow	\N	1843-04-21	1	\N	3012	2	8	\N	f	\N	27	5	2
Culloden	\N	1904-03-17	2	\N	3013	2	8	\N	f	\N	26	5	4
Clive	of Ludlow in the County of Salop	\N	0	\N	3015	7	12	\N	f	\N	31	5	4
Herbert	of Chirbury in the County of Salop	\N	0	\N	3016	7	8	\N	f	\N	31	5	9
Soberton	of Soberton in the County of Southampton	\N	0	\N	3018	2	8	\N	f	\N	21	5	20
Howick	in the County of Northumberland	\N	0	\N	3019	7	12	\N	f	\N	44	5	9
Greenock	of Greenock in the County of Renfrew	\N	0	\N	3020	4	8	\N	f	\N	50	5	8
Douro	of Wellesley in the County of Somerset	\N	0	\N	3021	2	8	\N	f	\N	52	5	5
Lascelles	\N	\N	0	\N	3022	7	12	\N	f	\N	73	5	13
Compton	of Compton in the County of Warwick	\N	0	\N	3023	7	6	\N	f	\N	82	5	4
Melgund	of Melgund in the County of Forfar	\N	0	\N	3025	7	12	\N	f	\N	76	5	14
Douro	\N	\N	0	\N	3026	7	9	\N	f	\N	2916	5	5
Grimston	\N	\N	0	\N	3027	7	12	\N	f	\N	79	5	8
Adbaston	of Adbaston in the County of Stafford	1825-05-12	1	\N	3028	7	8	\N	f	\N	72	5	2
Alford	\N	1921-03-17	3	\N	3029	7	12	\N	f	\N	84	5	2
Newport	in the County of Salop	\N	0	\N	3030	7	12	\N	f	\N	112	5	15
Elmley	in the County of Worcester	1979-01-03	8	\N	3031	7	12	\N	f	\N	85	5	6
Loudoun	\N	1868-11-01	4	\N	3032	7	12	\N	f	\N	120	5	13
Encombe	of Encombe in the County of Dorset	\N	0	\N	3033	7	12	\N	f	\N	113	5	6
Bruce	of Whorlton in the County of York	\N	0	\N	3034	7	6	\N	f	\N	118	5	3
Savernake	of Savernake Forest, Wilts	\N	0	\N	3035	7	12	\N	f	\N	118	5	20
Dunwich	in the County of Suffolk	\N	0	\N	3036	7	12	\N	f	\N	117	5	5
Seaham	of Seaham in the County Palatine of Durham	\N	0	\N	3037	8	12	\N	f	\N	123	5	20
Jermyn	of Horningsherth in the County of Suffolk	\N	0	\N	3038	7	6	\N	f	\N	119	5	11
Holmesdale	in the County of Kent	1993-03-04	5	\N	3039	7	12	\N	f	\N	129	5	9
Ednam	of Ednam in the County of Roxburgh	1833-03-06	1	\N	3040	7	12	\N	f	\N	163	5	6
Emlyn	of Emlyn in the County of Carmarthen	\N	0	\N	3041	7	12	\N	f	\N	136	5	6
FitzClarence	\N	2000-12-30	7	\N	3042	2	12	\N	f	\N	167	5	7
Tewkesbury	\N	2000-12-30	7	\N	3043	2	8	\N	f	\N	167	5	21
Lambton	\N	\N	0	\N	3045	7	12	\N	f	\N	201	5	13
Leveson	of Stone in the County of Stafford	\N	0	\N	3046	7	8	\N	f	\N	177	5	13
Moreton	of Tortworth in the County of Gloucester	\N	0	\N	3048	7	8	\N	f	\N	200	5	14
Worsley	of Apuldurcombe in the Isle of Wight	\N	0	\N	3049	7	8	\N	f	\N	243	5	24
Coke	\N	\N	0	\N	3050	2	12	\N	f	\N	2615	5	4
Ockham	of Ockham in the County of Surrey	\N	0	\N	3051	7	12	\N	f	\N	204	5	16
Campden	of Campden in the County of Gloucester	\N	0	\N	3052	7	12	\N	f	\N	241	5	4
Southam	of Southam in the County of Gloucester	1871-12-22	1	\N	3053	7	12	\N	f	\N	2933	5	20
Brackley	of Brackley in the County of Northampton	\N	0	\N	3054	2	12	\N	f	\N	240	5	3
Enfield	of Enfield in the County of Middlesex	\N	0	\N	3055	7	12	\N	f	\N	242	5	6
Crowhurst	of Crowhurst in the County of Surrey	\N	0	\N	3056	7	12	\N	f	\N	2931	5	4
Dangan	in the County of Meath	\N	0	\N	3057	7	12	\N	f	\N	265	5	5
Helmsley	of Helmsley in the North Riding of the County of York	1963-09-04	3	\N	3059	7	12	\N	f	\N	361	5	9
Inverness	\N	1843-04-21	1	\N	3060	2	6	\N	t	\N	27	5	10
Lewes	in the County of Sussex	\N	0	\N	3061	7	6	\N	t	\N	362	5	13
Clarence	\N	1919-03-28	2	\N	3062	2	6	\N	t	\N	2908	5	4
Ormelie	in the County of Caithness	1922-10-19	1	\N	3063	7	6	\N	t	\N	440	5	16
Ava	in the province of Burma	1988-05-29	5	\N	3064	7	6	\N	t	\N	475	5	2
Athlone	\N	1892-01-14	1	\N	3065	2	6	\N	t	\N	470	5	2
Inverness	\N	1910-05-06	1	\N	3066	2	6	\N	t	\N	472	5	10
Ronaldshay	in the County of Orkney and Zetland	\N	0	\N	3067	7	6	\N	t	\N	476	5	19
Chester	\N	1910-05-06	1	\N	3068	7	6	\N	t	\N	600	5	4
Eslington	of Eslington Park in the County of Northumberland	1904-02-07	3	\N	3069	7	8	\N	f	\N	2941	5	6
Madeley	\N	1945-06-20	1	\N	3070	7	6	\N	t	\N	639	5	14
Haddo	in the County of Aberdeen	\N	0	\N	3071	4	6	\N	t	\N	2825	5	9
Eltham	\N	1981-04-16	2	\N	3072	2	6	\N	t	\N	2857	5	6
Medina	\N	\N	0	\N	3073	2	6	\N	t	\N	758	5	14
Berkhampsted	\N	1960-02-23	1	\N	3074	2	6	\N	t	\N	718	5	3
Inverness	\N	1936-12-11	0	\N	3075	2	6	\N	t	\N	2918	5	10
Ulster	\N	\N	0	\N	3077	2	6	\N	t	\N	838	5	22
Macduff	in the County of Banff	1912-01-29	1	\N	3078	7	9	\N	t	\N	471	5	14
St Pierre	\N	1955-02-21	3	\N	3079	7	12	\N	f	2	560	5	20
Broome	of Broome in the County of Kent	2011-12-16	3	\N	3080	7	12	\N	f	2	2656	5	3
Temple of Stowe	in the County of Buckingham	\N	0	\N	3008	7	6	\N	f	\N	2910	5	21
Merton	of Trafalgar and of Merton in the County of Surrey	\N	0	\N	3006	7	12	\N	f	1	39	5	14
Macduff	in the County of Banff	\N	0	\N	3083	8	6	\N	t	2	2927	5	14
Baring	of Lee in the County of Kent	1929-04-12	2	\N	3084	7	12	\N	f	\N	399	5	3
Hughenden	of Hughenden in the County of Buckingham	1881-04-19	1	\N	3085	2	12	\N	f	\N	2920	5	9
Garmoyle	in the County of Antrim	\N	0	\N	3086	7	12	\N	f	\N	373	5	8
Throwley	in the County of Kent	\N	0	\N	3087	7	12	\N	f	\N	379	5	21
Arklow	\N	1919-03-28	2	\N	3088	2	8	\N	f	\N	2908	5	2
Wolmer	of Blackmoor in the County of Southampton	\N	0	\N	3089	7	12	\N	f	\N	401	5	24
Raincliffe	of Raincliffe in the North Riding of the County of York	1937-04-17	4	\N	3091	7	12	\N	f	\N	474	5	19
Killarney	\N	1910-05-06	1	\N	3092	2	8	\N	f	\N	472	5	12
Medway	\N	\N	0	\N	3093	7	8	\N	f	\N	473	5	14
Salford	in the County Palatine of Lancaster	1909-03-16	1	\N	3094	7	12	\N	f	\N	511	5	20
Wensleydale	of Blagdon and Blyth, both in the County of Northumberland	\N	0	\N	3095	2	8	\N	f	\N	538	5	24
Errington	of Hexham in the County of Northumberland	\N	0	\N	3096	7	12	\N	f	\N	2654	5	6
Windsor	of Saint Fagans in the County of Glamorgan	\N	0	\N	3097	7	12	\N	f	\N	557	5	24
Hawkesbury	of Kirkham in the County of York and of Mansfield in the County of Nottingham	\N	0	\N	3098	7	12	\N	f	\N	2939	5	9
Mentmore	of Mentmore in the County of Buckingham	\N	0	\N	3099	7	12	\N	f	\N	2940	5	14
Epsom	of Epsom in the County of Surrey	\N	0	\N	3100	7	8	\N	f	\N	2940	5	6
Hythe	of Hythe in the County of Kent	1919-11-12	2	\N	3101	7	12	\N	f	\N	628	5	9
Douglas of Baads	in the County of Midlothian	\N	0	\N	3102	2	8	\N	f	\N	629	5	5
Quenington	of Quenington in the County of Gloucester	\N	0	\N	3103	7	12	\N	f	\N	700	5	18
Nuneham	of Nuneham Courtenay in the County of Oxford	1979-01-03	2	\N	3104	2	8	\N	f	\N	686	5	15
Northallerton	in the County of York	1981-04-16	2	\N	3105	2	12	\N	f	\N	2857	5	15
Trematon	in the County of Cambridge	1957-01-16	1	\N	3106	2	12	\N	f	\N	756	5	21
Alderney	in the County of Southampton	\N	0	\N	3107	2	12	\N	f	\N	758	5	2
Erleigh	of Erleigh in the County of Berks	\N	0	\N	3108	7	12	\N	f	\N	2942	5	6
Dawick	\N	\N	0	\N	3111	2	12	\N	f	\N	775	5	5
Haig	of Bemersyde in the County of Berwick	\N	0	\N	3112	2	8	\N	f	\N	775	5	9
Dunsford	of Dunsford in the County of Surrey	1979-11-02	2	\N	3113	7	12	\N	f	\N	757	5	5
Killarney	\N	1936-12-11	0	\N	3114	2	8	\N	f	\N	2918	5	12
Furneaux	of Charlton in the County of Northampton	1985-02-18	3	\N	3115	7	12	\N	f	\N	798	5	7
Asquith	of Morley in the West Riding of the County of York	\N	0	\N	3116	2	12	\N	f	\N	839	5	2
Brocas	of Southampton in the County of Southampton	\N	0	\N	3117	7	12	\N	f	\N	2841	5	3
Culloden	\N	\N	0	\N	3118	2	8	\N	f	\N	838	5	4
Glenapp	of Strathnaver in the County of Sutherland	\N	0	\N	3119	7	12	\N	f	\N	2937	5	8
Cranley	of Cranley in the County of Surrey	\N	0	\N	3120	7	12	\N	f	\N	30	5	4
Sandon	of Sandon in the County of Stafford	\N	0	\N	3121	7	12	\N	f	\N	74	5	20
Sussex	\N	1943-04-26	2	\N	3122	2	6	\N	t	\N	2913	5	20
Scarsdale	of Scarsdale in the County of Derby	\N	0	SR to his father & heirs male of his body	3123	3	12	\N	f	1	630	5	20
Romsey	of Romsey in the County of Southampton	\N	0	\N	3124	7	8	\N	f	2	2994	5	19
Normanby	of Normanby in the County of York	\N	0	\N	3126	7	12	\N	f	\N	77	5	15
Eastnor	of Eastnor Castle in the County of Hereford	1883-09-26	3	\N	3127	7	12	\N	f	\N	90	5	6
Eden	of Norwood in the County of Surrey	1849-01-01	1	\N	3128	7	8	\N	f	\N	239	5	6
Tiverton	of Tiverton in the County of Devon	\N	0	\N	3130	7	12	\N	f	\N	521	5	21
Launceston	in the County of Cornwall	1960-02-23	1	\N	3131	2	12	\N	f	\N	718	5	13
Clanfield	of Clanfield in the County of Southampton	\N	0	\N	3132	7	12	\N	f	\N	850	5	4
Boringdon	of North Molton in the County of Devon	\N	0	\N	3134	7	12	\N	f	\N	115	5	3
Cavendish	of Keighley in the County of York	\N	0	\N	3135	2	8	\N	f	\N	2922	5	4
Noel	of Ridlington in the County of Rutland	\N	0	\N	3136	7	8	\N	f	\N	241	5	15
Clandeboye	of Clandeboye in the County of Down	1988-05-29	5	\N	3137	7	12	\N	f	\N	360	5	4
Knebworth	of Knebworth in the County of Hertford	\N	0	\N	3138	7	12	\N	f	\N	398	5	12
Wendover	of Chepping Wycombe in the County of Buckingham	1928-06-13	1	\N	3139	7	12	\N	f	\N	495	5	24
Elveden	of Elveden in the County of Suffolk	\N	0	\N	3140	7	12	\N	f	\N	2655	5	6
Ratendone	of Willingdon in the County of Sussex	1979-03-19	2	\N	3141	7	12	\N	f	\N	877	5	19
Downpatrick	\N	\N	0	\N	3142	2	8	\N	f	\N	2914	5	5
Corvedale	of Corvedale in the County of Salop	\N	0	\N	3143	2	12	\N	f	\N	935	5	4
Ruthven of Canberra	of Dirleton in the County of East Lothian	\N	0	\N	3144	7	12	\N	f	\N	2935	5	19
Gwynedd	of Dwyfor in the County of Caernarvon	\N	0	\N	3145	2	12	\N	f	\N	1011	5	8
Greenwich	of Greenwich in the County of London	\N	0	\N	3147	2	8	\N	f	\N	1114	5	8
Castlehaven	of Castlehaven in the County of Cromartie	\N	0	\N	3125	2	8	\N	f	\N	2929	5	4
Traprain	of Whittingehame in the County of Haddington	\N	0	\N	3082	2	12	\N	f	1	2928	5	21
Rideau	of Ottawa and of Castle Derg in the County of Tyrone	\N	0	\N	3149	7	8	\N	f	\N	1129	5	19
Masham	of Ellington in the County of York	\N	0	\N	3150	7	8	\N	f	\N	2946	5	14
Prestwood	of Walthamstow in the County of Essex	\N	0	\N	3151	2	12	\N	f	\N	1163	5	17
Warbleton	of Warbleton in the County of Sussex	\N	0	\N	3152	7	12	\N	f	\N	1193	5	24
Eden	of Royal Leamington Spa in the County of Warwick	1985-08-17	2	\N	3153	2	12	\N	f	\N	1270	5	6
Linley	of Nymans in the County of Sussex	\N	0	\N	3154	2	12	\N	f	\N	2944	5	13
Fyfe of Dornoch	of Dornoch in the County of Sutherland	1967-01-27	1	\N	3155	7	8	\N	f	\N	1271	5	7
Weston-super-Mare	of Weston-super-Mare in the County of Somerset	1965-01-11	1	\N	3156	7	8	\N	f	\N	1264	5	24
Killyleagh	\N	\N	0	\N	3158	2	8	\N	f	\N	1745	5	12
Severn	\N	\N	0	\N	3159	2	12	\N	f	\N	2947	5	20
Carrickfergus	\N	\N	\N	\N	3160	2	8	\N	f	\N	2911	5	4
Kilkeel	\N	\N	\N	\N	3161	2	8	\N	f	\N	2915	5	12
Kinrara	in the County of Inverness	\N	0	\N	3162	8	6	\N	t	\N	358	5	12
St Andrews	\N	\N	0	\N	3163	2	6	\N	t	\N	2914	5	20
Merioneth	\N	\N	0	\N	3164	2	6	\N	t	\N	1114	5	14
Chester	\N	\N	0	\N	3165	7	6	\N	t	\N	1194	5	4
Inverness	\N	\N	0	\N	3166	2	6	\N	t	\N	1745	5	10
Strathearn	\N	\N	\N	\N	3167	2	6	\N	t	\N	2911	5	20
Dumbarton	\N	\N	\N	\N	3168	2	6	\N	t	\N	2915	5	5
Carlton	of Carlton in the West Riding of the County of York	\N	0	\N	3169	7	12	\N	f	1	2623	5	4
Campbell of Eskan	of Camis Eskan in the County of Dumbarton	1994-12-26	1	\N	1531	5	8	\N	f	\N	1343	5	4
Breadalbane	of Taymouth Castle in the County of Perth	1862-11-08	2	cr M of Breadalbane 12 Sep 1831	53	4	8	\N	f	\N	46	5	3
Rossie	of Rossie in the County of Perth	1878-01-07	1	further cr L Kinnaird 1860 with SR	174	4	8	\N	f	\N	151	5	19
Cottenham	of Cottenham in the County of Cambridge	\N	\N	cr E of Cottenham 1850	221	2	8	\N	f	\N	189	5	4
Dalhousie	of Dalhousie Castle in the County of Edinburgh and of the Punjaub	1860-12-22	1	\N	282	7	9	\N	t	\N	244	5	5
Churston	of Churston Ferrers and Lupton in the County of Devon	\N	\N	4th L died 9 April 1991	310	2	8	\N	f	\N	270	5	4
Elphinstone	of Elphinstone in the County of Stirling	1860-07-19	1	\N	318	4	8	\N	f	\N	312	5	6
Dufferin	in the County of Down	1988-05-29	5	cr M of Dufferin and Ava 1888	384	7	6	\N	t	\N	360	5	5
Bolsover	of Bolsover Castle in the County of Derby	1990-07-30	5	SR to sons of late husband; 2nd L = 6th D of Portland	431	2	8	\N	f	3	404	5	3
Bowes	of Streatlam Castle in the County of Durham and of Lunedale in the County of York	\N	\N	\N	506	4	8	\N	f	\N	445	5	3
Ritchie of Dundee	of Welders in the parish of Chalfont St Giles in the County of Buckingham	\N	\N	\N	645	2	8	\N	f	\N	566	5	19
Mersey	of Toxteth in the County Palatine of Lancaster	\N	\N	4th V succeeded as 13th L Nairne 20 Oct 1995	758	7	12	\N	f	\N	667	5	14
Plumer	of Messines and of Bilton in the County of York	1944-02-24	2	cr V Plumer 1929	838	2	8	\N	f	\N	776	5	17
Bradbury	of Winsford in the County of Chester	\N	\N	2nd L died 31 March 1994	914	2	8	\N	f	\N	805	5	3
Hailsham	of Hailsham in the County of Sussex	\N	\N	2nd V. disclaimed 1963 & died 12 Oct 2001	963	7	12	\N	f	\N	844	5	9
Maugham	of Hartfield in the County of Sussex	1958-03-23	1	vice L Tomlin deceased; cr V Maugham 22 Sep 1939	1041	1	8	\N	f	\N	914	5	14
Hailey	of Sharpur in the Punjab and of Newport Pagnell in the County of Buckingham	1969-06-01	1	\N	1054	2	8	\N	f	\N	924	5	9
Winster	of Witherslack in the County of Westmorland	1961-06-07	1	\N	1126	2	8	\N	f	\N	989	5	24
Archibald	of Woodside in the City of Glasgow	1996-02-27	2	2nd L disclaimed	1250	2	8	\N	f	\N	1096	5	2
Leighton of Saint Mellons	of Saint Mellons in the County of Monmouth	\N	\N	\N	1421	2	8	\N	f	\N	1244	5	13
Oakshott	of Bebington in the County Palatine of Chester	1975-02-01	1	\N	1470	5	8	\N	f	\N	1289	5	16
Florey	of Adelaide in the Commonwealth of Australia and of Marston in the County of Oxford	1968-02-21	1	\N	1509	5	8	\N	f	\N	1324	5	7
Stevenage	of Stevenage in the County of Hertford	1957-08-16	1	\N	3148	7	12	\N	f	\N	1122	5	20
Hailsham of Saint Marylebone	of Herstmonceux in the County of Sussex	2001-10-12	1	had disclaimed viscounty 1963	1612	5	8	\N	f	\N	1412	5	9
Allan of Kilmahew	of Cardross in the County of Dunbarton	1979-04-04	1	\N	1667	5	8	\N	f	\N	1458	5	2
Knights	of Edgbaston in the County of West Midlands	2014-12-11	1	\N	1971	5	8	\N	f	\N	1724	5	12
Holme of Cheltenham	of Cheltenham in the County of Gloucestershire	2008-05-04	1	\N	2019	5	8	\N	f	\N	1765	5	9
Falconer of Thoroton	of Thoroton in the County of Nottinghamshire	\N	\N	\N	2181	5	8	\N	f	\N	1909	5	7
Rendell of Babergh	of Aldeburgh in the County of Suffolk	2015-05-02	1	\N	2240	5	8	\N	f	\N	1982	5	19
Phillips of Worth Matravers	of Belsize Park in the London Borough of Camden	\N	\N	vice L Lloyd of Berwick resigned; appointed MR 17 July 2000	2305	1	8	\N	f	\N	2006	5	17
Lyell of Markyate	of Markyate in the County of Hertfordshire	2010-08-30	1	\N	2532	5	8	\N	f	\N	2203	5	13
Nash	of Ewelme in the County of Oxfordshire	\N	\N	appointed as a minister	2748	5	8	\N	f	\N	2244	5	15
Ritchie of Brompton	of Brompton in the Royal Borough of Kensington and Chelsea	2012-04-24	1	\N	2644	5	8	\N	f	\N	2337	5	19
Blunkett	of Brightside and Hillsborough in the City of Sheffield	\N	\N	\N	2819	5	8	\N	f	\N	2348	5	3
Worthington	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2732	5	8	\N	f	\N	2423	5	24
Harding of Winscombe	of Nether Compton in the County of Dorset	\N	\N	\N	2791	5	8	\N	f	\N	2452	5	9
Fraser of Corriegarth	of Corriegarth in the County of Inverness	2021-02-08	1	\N	2871	5	8	\N	f	\N	2473	5	7
Meyer	of Nine Elms in the London Borough of Wandsworth	\N	\N	\N	2897	5	8	\N	f	\N	2539	5	14
Wharncliffe	in the West Riding of the County of York	\N	\N	SR to brother	416	7	6	\N	t	1	2623	5	24
Morton of Henryton	of Henryton in the County of Ayr	1973-07-18	1	pursuant to Appellate Jurisdiction Act 1947	1226	1	8	\N	f	\N	2662	5	14
Jellicoe of Southampton	of Southampton in the County of Hampshire	2007-02-22	1	Succeeded as 2nd E Jellicoe 20 Nov 1935; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 a.m.	2361	6	8	\N	f	\N	2891	5	11
Shephard of Northwold	of Northwold in the County of Norfolk	\N	\N	\N	2523	5	8	\N	f	\N	2924	5	20
Balfour	\N	\N	\N	SR to named brother & heirs male, then 2 named nephews & heirs male	882	2	6	\N	t	1	2928	5	3
Shepherd of Spalding	of Spalding in the County of Lincolnshire	2001-04-05	1	Succeeded as 2nd L Shepherd 4 Dec 1954;  ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 p.m.	2359	6	8	\N	f	\N	2904	5	20
Cottenham	of Cottenham in the County of Cambridge	\N	\N	\N	288	7	6	\N	t	\N	2931	5	4
Ripon	in the County of York	1923-09-22	3	2nd E succ as 3rd E de Grey 1859 & was cr M of Ripon 1871	206	7	6	\N	t	\N	2943	5	19
Burton	of Rangemore and of Burton-upon-Trent both in the County of Stafford	1909-02-01	1	further patent with SR 1897	496	2	8	\N	f	\N	432	5	3
Curzon of Kedleston	in the County of Derby	1925-03-20	1	NB 2 different special remainders for subsidiary titles	721	3	6	\N	f	\N	630	5	4
Murray of Newhaven	of Newhaven in the County of the City of Edinburgh	1993-10-10	1	\N	1476	5	8	\N	f	\N	1294	5	14
Keith of Kinkel	of Strathtummel in the District of Perth and Kinross	2002-06-21	1	vice L Kilbrandon; retired 30.9.1996	1769	1	8	\N	f	\N	1547	5	12
Mitford	of Redesdale in the County of Northumberland	\N	\N	Succeeded as 6th L Redesdale 1991; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2373	6	8	\N	f	\N	2049	5	14
Hennessy	of Windlesham in the County of Surrey	2010-12-21	1	Succeeded as 3rd L Windlesham 1962; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 11 p.m.	2360	6	8	\N	f	\N	2106	5	9
Harewood	in the County of York	\N	\N	Earldom of Mulgrave created same day	67	7	6	\N	t	\N	73	5	9
Ormonde	of Lanthony in the County of Monmouth	1997-10-25	7	SR to brother; cr M of Ormonde (I) 1825	116	3	8	\N	f	1	122	5	16
Kintore	of Kintore in the County of Aberdeen	1966-05-25	4	\N	236	4	8	\N	f	\N	194	5	12
Ennishowen and Carrickfergus	of Ennishowen in the County of Donegal and of Carrickfergus in the County of Antrim	1883-10-20	1	succ as 3rd M of Donegall (I) & L Fisherwick	266	2	8	\N	f	\N	228	5	6
Gough	of Chinkeangfoo in China and of Maharajpore and the Sutlej in the East Indies	\N	\N	cr V Gough 15 June 1849, introduced as such	273	2	8	\N	f	\N	276	5	8
Somerton	of Somerley in the County of Southampton	\N	\N	4th L succ 1974 as 9th L Mendip (cr 1794)	391	3	8	\N	f	\N	341	5	20
Wolseley	of Wolseley in the County of Stafford	1936-12-24	2	SR to daughter	483	7	12	\N	f	2	441	5	24
Burton	of Burton-on-Trent and of Rangemore both in the County of Stafford	\N	\N	SR to dau	590	8	8	\N	f	2	522	5	3
Burnham	of Hall Barn in the parish of Beaconsfield in the County of Buckingham	\N	\N	subsumed in viscounty 1919-33; 5th L died 18 June 1993	631	2	8	\N	f	\N	549	5	3
Allendale	of Allendale and Hexham in the County of Northumberland	\N	\N	2nd L cr V Allendale 1911	668	2	8	\N	f	\N	586	5	2
Elibank	of Elibank in the County of Selkirk	1962-12-05	3	\N	715	4	12	\N	f	\N	625	5	6
Sandhurst	of Sandhurst in the County of Berks	1921-11-02	1	barony passed to brother	774	7	12	\N	f	\N	682	5	20
St Davids	of Lydstep Haven in the County of Pembroke	\N	\N	2nd V died 10 June 1991	808	7	12	\N	f	\N	736	5	20
Kylsant	of Carmarthen in the County of Carmarthen and of Amroth in the County of Pembroke	1937-06-05	1	\N	897	2	8	\N	f	\N	788	5	12
Daresbury	of Walton in the County of Chester	\N	\N	2nd L died 15 Feb 1990; ?th L died 9 Sep 1996	934	2	8	\N	f	\N	820	5	5
Allen of Hurtwood	of Hurtwood in the County of Surrey	1939-03-03	1	\N	996	2	8	\N	f	\N	873	5	2
Gowrie	of Canberra in the Commonwealth of Australia and of Dirleton in the County of East Lothian	\N	\N	cr E of Gowrie 8 Jan 1945	1045	2	8	\N	f	\N	918	5	8
Brassey of Apethorpe	of Apethorpe in the County of Northampton	\N	\N	\N	1083	2	8	\N	f	\N	949	5	3
Alanbrooke	of Brookeborough in the County of Fermanagh	2018-01-10	3	cr V Alanbrooke 29 Jan 1946 (intro as such)	1178	2	8	\N	f	\N	1033	5	2
Cunningham of Hyndhope	of Kirkhope in the County of Selkirk	1963-06-12	1	\N	1192	7	12	\N	f	\N	1046	5	4
Macpherson of Drumochter	of Great Warley in the County of Essex	\N	\N	\N	1267	2	8	\N	f	\N	1111	5	14
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	already a life peer; cr V Simonds 1954	1286	8	8	\N	f	\N	1130	5	20
Kilmuir	of Creich in the County of Sutherland	1967-01-27	1	cr E of Kilmuir 1962	1312	2	12	\N	f	\N	1155	5	12
Dalton	of Forest and Frith in the County Palatine of Durham	1962-02-13	1	\N	1388	5	8	\N	f	\N	1215	5	5
Radcliffe	of Hampton Lucy in the County of Warwick	1977-04-01	1	\N	1436	7	12	\N	f	\N	1258	5	19
Dunira	in the County of Perth	\N	0	\N	3014	2	8	\N	f	\N	15	5	5
Wilmington	of Wilmington in the County of Sussex	\N	0	\N	3024	7	8	\N	f	\N	82	5	24
Raby	of Raby Castle in the County of Durham	1891-08-21	4	\N	3044	7	8	\N	f	\N	2912	5	19
Ednam	of Ednam in the County of Roxburgh	\N	0	\N	3058	7	12	\N	f	\N	286	5	6
Kedleston	in the County of Derby	1925-03-20	1	\N	3076	7	6	\N	t	\N	766	5	12
Denton	of Denton in the County of Kent	2011-12-16	3	\N	3081	7	8	\N	f	2	2656	5	5
Saint Cyres	of Newton Saint Cyres in the County of Devon	\N	0	\N	3090	2	12	\N	f	\N	439	5	20
Beatty	of the North Sea and of Brooksby in the County of Leicester	\N	0	\N	3110	2	8	\N	f	\N	2635	5	3
Amberley	of Amberley in the County of Gloucester and of Ardsalla in the County of Meath	\N	0	\N	3129	2	12	\N	f	\N	283	5	2
Keren	of Eritrea and of Winchester in the County of Southampton	1953-12-24	2	\N	3146	7	12	\N	f	\N	1118	5	12
Macmillan of Ovenden	of Chelwood Gate in the County of East Sussex and Stockton-on-Tees in the County of Cleveland	\N	0	\N	3157	2	12	\N	f	\N	2945	5	14
Tarbat	of Tarbat in the County of Cromartie	\N	0	\N	3005	2	12	\N	f	\N	2929	5	21
Masham of Ilton	of Masham in the North Riding of the County of York	\N	\N	\N	1609	5	8	\N	f	\N	1428	5	14
Fraser of Kilmorack	of Rubislaw in the County of the City of Aberdeen	1996-07-01	1	\N	1685	5	8	\N	f	\N	1475	5	7
Ryder of Eaton Hastings	of Eaton Hastings in the County of Oxfordshire	2003-05-12	1	\N	1735	5	8	\N	f	\N	1520	5	19
Chitnis	of Ryedale in the County of North Yorkshire	2013-07-12	1	\N	1776	5	8	\N	f	\N	1557	5	4
Lane-Fox	of Bramham in the County of West Yorkshire	1988-04-17	1	\N	1859	5	8	\N	f	\N	1626	5	13
Platt of Writtle	of Writtle in the County of Essex	2015-02-01	1	\N	1864	5	8	\N	f	\N	1669	5	17
Murray of Epping Forest	of Telford in the County of Shropshire	2004-05-20	1	\N	1932	5	8	\N	f	\N	1690	5	14
Dormand of Easington	of Easington in the County of Durham	2003-12-18	1	\N	1978	5	8	\N	f	\N	1730	5	5
Mackay of Ardbrecknish	of Tayvallich in the District of Argyll and Bute	2001-02-21	1	\N	2049	5	8	\N	f	\N	1790	5	14
Elis-Thomas	of Nant Conwy in the County of Gwynedd	\N	\N	surname changed from Thomas after peerage announced	2098	5	8	\N	f	\N	1836	5	6
Mackay of Drumadoon	of Blackwaterfoot in the District of Cunninghame	2018-08-21	1	\N	2141	5	8	\N	f	\N	1872	5	14
Renton of Mount Harry	of Offham in the County of East Sussex	2020-08-25	1	\N	2192	5	8	\N	f	\N	1919	5	19
Sainsbury of Turville	of Turville in the County of Buckinghamshire	\N	\N	\N	2225	5	8	\N	f	\N	1947	5	20
Lyttelton of Aldershot	of Aldershot in the County of Hampshire	\N	\N	Succeeded as 3rd V Chandos 1980; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 a.m.	2375	6	8	\N	f	\N	2050	5	13
Erroll of Kilmun	of Kilmun in Argyll and Bute	2000-09-14	1	Cr 1st L Erroll of Hale 19 Dec 1964; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 12 noon	2356	6	8	\N	f	\N	2070	5	6
Ashdown of Norton-sub-Hamdon	of Norton-sub-Hamdon in the County of Somerset	2018-12-22	1	\N	2436	5	8	\N	f	\N	2124	5	2
Hannay of Chiswick	of Bedford Park in the London Borough of Ealing	\N	\N	\N	2412	5	8	\N	f	\N	2145	5	9
Mawhinney	of Peterborough in the County of Cambridgeshire	2019-11-09	1	\N	2530	5	8	\N	f	\N	2201	5	14
Campbell of Loughborough	of Loughborough in the County of Leicestershire	\N	\N	\N	2608	5	8	\N	f	\N	2289	5	4
Willis of Knaresborough	of Harrogate in the County of North Yorkshire	\N	\N	\N	2629	5	8	\N	f	\N	2308	5	24
Macdonald of River Glaven	of Cley-next-the-Sea in the County of Norfolk	\N	\N	\N	2662	5	8	\N	f	\N	2352	5	14
Collins of Highbury	of Highbury in the London Borough of Islington	\N	\N	\N	2717	5	8	\N	f	\N	2398	5	4
McIntosh of Pickering	of the Vale of York in the County of North Yorkshire	\N	\N	\N	2833	5	8	\N	f	\N	2455	5	14
Bamford	of Daylesford in the County of Gloucestershire and of Wootton in the County of Staffordshire	\N	\N	\N	2781	5	8	\N	f	\N	2490	5	3
Richards of Herstmonceux	of Emsworth in the County of Hampshire	\N	\N	\N	2784	5	8	\N	f	\N	2511	5	19
Greenhalgh	of Fulham in the London Borough of Hammersmith and Fulham	\N	\N	\N	2936	5	8	\N	f	\N	2550	5	8
Simon of Glaisdale	of Glaisdale in the North Riding of the County of York	2006-05-07	1	apptd L of Appeal in Ord 19 April 1971	1632	5	8	\N	f	\N	2682	5	20
Richardson of Duntisbourne	of Duntisbourne in the County of Gloucestershire	2010-01-22	1	\N	1895	5	8	\N	f	\N	2697	5	19
Hopetoun	of Hopetoun in the County of Linlithgow	\N	\N	SR to heirs of father; 5th L cr M of Linlithgow	60	4	8	\N	f	1	2767	5	9
Jellicoe	\N	\N	\N	2nd E. created L. Jellicoe of Southampton (life peer) 17 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999; he died 22 Feb 2007	918	7	6	\N	f	\N	2841	5	11
Bottomley of Nettlestone	of St Helens in the County of Isle of Wight	\N	\N	\N	2529	5	8	\N	f	\N	2964	5	3
Nelson	of the Nile and of Hilborough in the County of Norfolk	\N	\N	SR to (1) his father; (2) h m of his sister Susanna; (3) h m of his sister Catherine; 2nd L cr E Nelson 1805	18	8	8	\N	f	1	2992	5	15
Jellicoe	of Scapa in the County of Orkney	\N	\N	cr E Jellicoe 1925 (no SR)\nNB SR not needed as son born 1918\n2nd V cr L Jellicoe of Southampton 1999 & died 22 Feb 2007	800	2	12	\N	f	2	719	5	11
Powis	of Powis Castle in the County of Montgomery	\N	0	\N	3017	7	8	\N	f	\N	31	5	17
Bottesford	of Bottesford in the County of Leicester	1941-02-26	6	\N	3047	2	8	\N	f	\N	183	5	3
Borodale	of Wexford in the County of Wexford	\N	0	\N	3109	2	12	\N	f	\N	2635	5	3
Ravensdale	of Ravensdale in the County of Derby	\N	0	SR to his daughters & heirs male of their bodies	3133	3	8	\N	f	2	630	5	19
Nelson	of Trafalgar and of Merton in the County of Surrey	\N	\N	SR to heirs male of the bodies of Susanna wife of Thomas Bolton Esquire and of Catharine wife of George Matcham Esquire (both sisters of late Horatio Viscount Nelson)	38	7	6	\N	f	1	39	5	15
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	vice L Romer resigned; cr hereditary L 24 Jne 1952, V 18 Oct 1954	1145	1	8	\N	f	\N	1006	5	20
Wright of Ashton under Lyne	of Ashton under Lyne in the County Palatine of Lancaster	1974-09-15	1	\N	1586	5	8	\N	f	\N	1386	5	24
Windlesham	of Windlesham in the County of Surrey	\N	\N	3rd L. created L Hennessy (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1059	2	8	\N	f	\N	2649	5	24
Strathcona and Mount Royal	of Mount Royal in the Province of Quebec and Dominion of Canada and of Glencoe in the County of Argyll	\N	\N	SR to dau	612	8	8	\N	f	2	2832	5	20
Bindon	\N	\N	\N	\N	3170	2	6	\N	f	\N	2996	1	3
Chesterford	\N	\N	\N	\N	3171	2	8	\N	f	\N	2996	1	4
Cholmondeley	\N	\N	\N	\N	3172	7	6	\N	f	1	2997	1	4
Malpas	\N	\N	\N	\N	3173	7	12	\N	f	1	2997	1	14
Godolphin	\N	\N	\N	\N	3174	7	6	\N	f	\N	2998	1	8
Rialton	\N	\N	\N	\N	3175	7	12	\N	f	\N	2998	1	19
Poulett	\N	\N	\N	\N	3176	7	6	\N	f	\N	2999	1	17
Hinton	\N	\N	\N	\N	3177	7	12	\N	f	\N	2999	1	9
Wharton	\N	\N	\N	\N	3178	7	6	\N	f	\N	3000	1	24
Winchendon	\N	\N	\N	\N	3179	7	12	\N	f	\N	3000	1	24
Dorchester	\N	\N	\N	\N	3180	7	9	\N	f	1	3001	1	5
Lindsey	\N	\N	\N	\N	3181	7	9	\N	f	3	3002	1	13
Pelham	\N	\N	\N	\N	3182	2	8	\N	f	\N	3003	1	17
Cowper	\N	\N	\N	\N	3183	2	8	\N	f	\N	3004	1	4
Malmesbury	\N	\N	\N	\N	3184	7	6	\N	f	\N	3005	4	14
Fitzharris	\N	\N	\N	\N	3185	7	12	\N	f	\N	3005	4	7
Cadogan	\N	\N	\N	\N	3186	7	6	\N	f	\N	3006	4	4
Chelsea	\N	\N	\N	\N	3187	7	12	\N	f	\N	3006	4	4
Bridport	\N	\N	\N	\N	3188	7	12	\N	f	\N	3007	4	3
Fitzgibbon	\N	\N	\N	\N	3189	3	8	\N	f	\N	3008	4	7
Eldon	\N	\N	\N	\N	3190	2	8	\N	f	\N	3009	4	6
Curzon of Kedleston	\N	\N	\N	\N	3191	2	8	\N	f	\N	3010	3	4
Rathdonnell	\N	\N	\N	\N	3192	2	8	\N	f	1	3011	3	19
Abercorn	\N	\N	\N	\N	3193	7	4	\N	f	\N	3012	3	2
Hamilton	\N	\N	\N	\N	3194	7	9	\N	f	\N	3012	3	9
Athlumney	\N	\N	\N	\N	3195	2	8	\N	f	\N	3013	3	2
Fermoy	\N	\N	\N	\N	3196	2	8	\N	f	\N	3014	3	7
Clermont	\N	\N	\N	\N	3197	2	8	\N	f	1	3015	3	4
Bellew	\N	\N	\N	\N	3198	2	8	\N	f	\N	3016	3	3
Kent	\N	\N	\N	\N	3199	7	9	\N	f	\N	3017	1	12
Harold	\N	\N	\N	\N	3200	7	6	\N	f	\N	3017	1	9
Goderich	\N	\N	\N	\N	3201	7	12	\N	f	\N	3017	1	8
Cambridge	\N	\N	\N	\N	3202	2	4	\N	f	\N	3018	1	4
Cambridge	\N	\N	\N	\N	3203	2	9	\N	f	\N	3018	1	4
Milford Haven	\N	\N	\N	\N	3204	2	6	\N	f	\N	3018	1	14
Northallerton	\N	\N	\N	\N	3205	2	12	\N	f	\N	3018	1	15
Tewkesbury	\N	\N	\N	\N	3206	2	8	\N	f	\N	3018	1	21
Greenwich	\N	\N	\N	\N	3207	4	6	\N	f	\N	3019	1	8
Chatham	\N	\N	\N	\N	3208	4	8	\N	f	\N	3019	1	4
Montagu	\N	\N	\N	\N	3209	7	4	\N	f	\N	3020	1	14
Monthermer	\N	\N	\N	\N	3210	7	9	\N	f	\N	3020	1	14
Rutland	\N	\N	\N	\N	3211	7	4	\N	f	\N	3021	1	19
Granby	\N	\N	\N	\N	3212	7	9	\N	f	\N	3021	1	8
Buckingham and Normanby	\N	\N	\N	\N	3213	7	4	\N	f	\N	3022	1	3
Hervey	\N	\N	\N	\N	3214	2	8	\N	f	\N	3023	1	9
Conway	\N	\N	\N	\N	3215	2	8	\N	f	1	3024	1	4
Gower	\N	\N	\N	\N	3216	2	8	\N	f	\N	3025	1	8
Cumberland and Teviotdale	\N	\N	\N	\N	3217	2	4	\N	f	\N	3026	4	4
Armagh	\N	\N	\N	\N	3218	2	6	\N	f	\N	3026	4	2
Kent and Strathearn	\N	\N	\N	\N	3219	2	4	\N	f	\N	3027	4	12
Dublin	\N	\N	\N	\N	3220	2	6	\N	f	\N	3027	4	5
Nelson	\N	\N	\N	\N	3221	2	8	\N	f	\N	3028	4	15
Basset	\N	\N	\N	\N	3222	8	8	\N	f	2	3029	4	3
Duncan	\N	\N	\N	\N	3223	2	12	\N	f	\N	3030	4	5
Duncan	\N	\N	\N	\N	3224	2	8	\N	f	\N	3030	4	5
Seaforth	\N	\N	\N	\N	3225	2	8	\N	f	\N	3031	4	20
Perth	\N	\N	\N	\N	3226	2	8	\N	f	\N	3032	4	17
Ribblesdale	\N	\N	\N	\N	3227	2	8	\N	f	\N	3033	4	19
Lilford	\N	\N	\N	\N	3228	2	8	\N	f	\N	3034	4	13
Dunsandle and Clanconal	\N	\N	\N	\N	3229	2	8	\N	f	\N	3035	3	5
Oranmore and Browne	\N	\N	\N	\N	3230	2	8	\N	f	\N	3036	3	16
Carew	\N	\N	\N	\N	3231	2	8	\N	f	\N	3037	3	4
Ranfurly	\N	\N	\N	\N	3232	7	6	\N	f	\N	3038	3	19
Talbot de Malahide	\N	\N	\N	\N	3233	2	8	\N	f	3	3039	3	21
Guillamore	\N	\N	\N	\N	3234	2	12	\N	f	\N	3040	3	8
O'Grady	\N	\N	\N	\N	3235	2	8	\N	f	\N	3040	3	16
Norbury	\N	\N	\N	\N	3236	7	6	\N	f	3	3041	3	15
Glandine	\N	\N	\N	\N	3237	7	12	\N	f	3	3041	3	8
Fitzgerald and Vesey	\N	\N	\N	\N	3238	2	8	\N	f	\N	3042	3	7
\.


--
-- Name: peerages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerages_id_seq', 3238, true);


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY people (id, forenames, surname, date_of_birth, date_of_death, notes, letter_id, gender_id, wikidata_id, mnis_id, rush_id) FROM stdin;
2846	Dudley Jaffray Hynman	Allenby	1903-01-08	1984-07-17	\N	2	1	\N	\N	\N
3	Horatio	Nelson	1758-09-29	1805-10-21	\N	15	1	\N	\N	\N
4	Richard Pepper	Arden	1745-05-20	1804-03-19	\N	2	1	\N	\N	\N
5	Mary Anne	Abercromby	\N	1821-02-11	\N	2	2	\N	\N	\N
6	Charles	Grey	1729-10-23	1807-11-14	\N	8	1	\N	\N	\N
8	Murrough	O'Brien	\N	1808-02-10	\N	16	1	\N	\N	\N
10	John	Hely Hutchinson	1757-05-15	1832-06-29	\N	9	1	\N	\N	\N
11	John	Mitford	1748-08-18	1830-01-16	\N	14	1	\N	\N	\N
12	Asheton	Curzon	1730-02-02	1820-03-21	\N	4	1	\N	\N	\N
13	Edward	Law	1750-11-16	1818-12-13	\N	13	1	\N	\N	\N
14	Mary	Hill	\N	1836-08-01	\N	9	2	\N	\N	\N
15	Charles George	Percival	1756-10-01	1840-07-05	\N	17	1	\N	\N	\N
16	John	Baker Holroyd	1735-12-21	1821-05-30	\N	3	1	\N	\N	\N
17	Henry	Dundas	1742-04-28	1811-05-29	\N	5	1	\N	\N	\N
18	Gerard	Lake	1744-07-27	1808-02-20	\N	13	1	\N	\N	\N
19	Henry	Addington	1757-05-30	1844-02-15	\N	2	1	\N	\N	\N
20	Charles	Middleton	1726-10-14	1813-06-17	\N	14	1	\N	\N	\N
22	William	Nelson	1757-04-20	1835-02-28	\N	15	1	\N	\N	\N
23	Cuthbert	Collingwood	1750-09-26	1810-03-07	\N	4	1	\N	\N	\N
24	Thomas	Erskine	1750-01-10	1823-11-17	\N	6	1	\N	\N	\N
25	Thomas	Anson	1767-02-14	1818-07-31	\N	2	1	\N	\N	\N
27	Charles	Moore	1730-06-29	1822-12-22	\N	14	1	\N	\N	\N
28	George	Forbes	1760-06-14	1837-06-09	\N	7	1	\N	\N	\N
29	John	Crewe	1742-09-27	1829-04-28	\N	4	1	\N	\N	\N
30	Adolphus Frederick	-	1774-02-24	1850-07-08	\N	1	1	\N	\N	\N
31	Augustus Frederick	-	1773-01-27	1843-04-21	\N	1	1	\N	\N	\N
32	Thomas	Pelham	1728-02-28	1805-01-08	\N	17	1	\N	\N	\N
34	George	Onslow	1731-10-13	1814-05-17	\N	16	1	\N	\N	\N
35	Edward	Clive	1754-03-07	1839-05-16	\N	4	1	\N	\N	\N
36	Charles	Marsham	1744-09-28	1811-03-01	\N	14	1	\N	\N	\N
38	Thomas Grey	Egerton	\N	1814-09-23	\N	6	1	\N	\N	\N
39	Henry	Cecil	1754-03-14	1804-05-01	\N	4	1	\N	\N	\N
40	William	Lygon	1747-07-25	1816-10-21	\N	13	1	\N	\N	\N
41	William Brabazon	Ponsonby	1744-09-15	1806-11-05	\N	17	1	\N	\N	\N
42	Charles	Pierrepont	1737-11-14	1816-06-17	\N	17	1	\N	\N	\N
43	Archibald	Kennedy	1770-02-01	1846-09-08	\N	12	1	\N	\N	\N
45	Alan	Gardner	1742-02-12	1809-01-01	\N	8	1	\N	\N	\N
46	Thomas	Manners Sutton	1756-02-24	1842-05-31	\N	14	1	\N	\N	\N
47	William	Cathcart	1755-08-01	1843-06-16	\N	4	1	\N	\N	\N
48	James	Gambier	1756-10-13	1833-04-19	\N	8	1	\N	\N	\N
49	Arthur	Wellesley	1769-04-29	1852-09-14	\N	24	1	\N	\N	\N
50	John Jeffreys	Pratt	1759-02-11	1840-10-08	\N	17	1	\N	\N	\N
51	Charles	Whitworth	1752-05-29	1825-05-12	\N	24	1	\N	\N	\N
52	John	Hope	1765-08-17	1823-08-27	\N	9	1	\N	\N	\N
54	Stapleton	Cotton	1773-11-14	1865-02-21	\N	4	1	\N	\N	\N
55	Rowland	Hill	1772-08-11	1842-12-10	\N	9	1	\N	\N	\N
56	William Carr	Beresford	1768-10-02	1854-01-08	\N	3	1	\N	\N	\N
57	Edward	Pellew	1757-04-19	1833-01-23	\N	17	1	\N	\N	\N
59	George	Gordon	1784-01-28	1860-12-14	\N	8	1	\N	\N	\N
61	John	Bowes	1769-04-14	1820-07-03	\N	3	1	\N	\N	\N
62	George	Gordon	1761-06-28	1853-06-17	\N	8	1	\N	\N	\N
63	George	Boyle	1765-03-26	1843-07-03	\N	3	1	\N	\N	\N
64	John Willoughby	Cole	1768-03-23	1840-03-31	\N	4	1	\N	\N	\N
65	Edmund Henry	Pery	1758-01-08	1844-12-07	\N	17	1	\N	\N	\N
66	Francis Almeric	Spencer	1779-12-26	1845-03-10	\N	20	1	\N	\N	\N
67	James	Maitland	1759-01-26	1839-09-15	\N	14	1	\N	\N	\N
68	Edward	Lascelles	1740-01-07	1820-04-03	\N	13	1	\N	\N	\N
69	Dudley	Ryder	1762-12-22	1847-12-26	\N	19	1	\N	\N	\N
70	William	Lowther	1757-12-29	1844-03-19	\N	13	1	\N	\N	\N
72	Henry	Phipps	1755-02-14	1831-04-07	\N	17	1	\N	\N	\N
73	Horatio	Walpole	1723-06-12	1809-02-24	\N	24	1	\N	\N	\N
74	James Walter	Grimston	1775-09-26	1845-11-17	\N	8	1	\N	\N	\N
75	Henry William	Paget	1768-05-17	1854-04-29	\N	17	1	\N	\N	\N
76	Charles	Compton	1760-03-24	1828-05-24	\N	4	1	\N	\N	\N
77	John	Cust	1779-08-19	1853-09-15	\N	4	1	\N	\N	\N
78	Amabell	Hume-Campbell	1750-01-22	1833-05-04	\N	9	2	\N	\N	\N
79	Algernon	Percy	1792-12-15	1865-02-12	\N	17	1	\N	\N	\N
80	Charles	Abbot	1757-10-14	1829-05-08	\N	2	1	\N	\N	\N
83	William	Ker	1763-10-04	1824-04-27	\N	12	1	\N	\N	\N
84	Henry	Conyngham	1766-12-26	1832-12-28	\N	4	1	\N	\N	\N
85	Thomas	Hamilton	1780-06-21	1858-12-01	\N	9	1	\N	\N	\N
86	James Wandesford	Butler	1777-07-15	1838-05-18	\N	3	1	\N	\N	\N
87	Francis Charteris Wemyss	Douglas	1772-04-15	1853-06-28	\N	5	1	\N	\N	\N
88	Robert	Jocelyn	1788-10-27	1870-03-20	\N	11	1	\N	\N	\N
89	George	King	1771-04-08	1839-10-18	\N	12	1	\N	\N	\N
91	James	Murray	1782-05-29	1837-10-12	\N	14	1	\N	\N	\N
92	William Wellesley	Pole	1763-05-20	1845-02-22	\N	17	1	\N	\N	\N
93	William	Scott	1745-10-17	1836-01-28	\N	20	1	\N	\N	\N
94	Thomas Henry	Liddell	1775-02-08	1855-03-07	\N	13	1	\N	\N	\N
95	Thomas	Cholmondeley	1767-08-09	1855-10-30	\N	4	1	\N	\N	\N
96	Cecil Weld	Forester	\N	1828-05-23	\N	7	1	\N	\N	\N
97	Charlotte Mary Gertrude	Strutt	1758-05-29	1836-09-01	\N	20	2	\N	\N	\N
98	Nicholas	Vansittart	1766-04-29	1851-02-08	\N	23	1	\N	\N	\N
99	Charles William	Vane	1778-05-18	1854-03-06	\N	23	1	\N	\N	\N
101	Granville Leveson	Gower	1773-10-12	1846-01-08	\N	8	1	\N	\N	\N
102	William	O'Bryen	\N	1846-08-21	\N	16	1	\N	\N	\N
104	James	Lindsay	1783-04-24	1869-12-15	\N	13	1	\N	\N	\N
105	Thomas	Knox	1754-08-05	1840-04-26	\N	12	1	\N	\N	\N
106	Orlando	Bridgeman	1762-03-19	1825-09-07	\N	3	1	\N	\N	\N
107	John	Scott	1751-06-04	1838-01-13	\N	20	1	\N	\N	\N
108	Edward	Boscawen	1787-05-10	1841-12-29	\N	3	1	\N	\N	\N
109	John	Parker	1772-05-03	1840-03-14	\N	17	1	\N	\N	\N
110	John	Eliot	1761-09-28	1823-11-17	\N	6	1	\N	\N	\N
111	John	Rous	1750-05-30	1827-08-27	\N	19	1	\N	\N	\N
113	Frederick William	Hervey	1769-10-02	1859-02-15	\N	9	1	\N	\N	\N
114	Francis	Rawdon-Hastings	1754-12-07	1826-11-28	\N	19	1	\N	\N	\N
115	Charles	Long	\N	1838-01-17	\N	13	1	\N	\N	\N
2	John Joshua	Proby	1751-08-12	1828-04-07	\N	17	1	\N	\N	\N
2847	Michael Jaffray Hynman	Allenby	1931-04-20	2014-10-03	\N	2	1	\N	\N	\N
118	Charles	Duncombe	1764-12-05	1841-07-16	\N	5	1	\N	\N	\N
119	William Pitt	Amherst	1773-01-14	1857-03-13	\N	2	1	\N	\N	\N
120	John Singleton	Copley	1772-05-21	1863-10-12	\N	4	1	\N	\N	\N
121	Frederick John	Robinson	1782-11-01	1859-01-28	\N	19	1	\N	\N	\N
122	James	Duff	1776-10-06	1857-03-09	\N	5	1	\N	\N	\N
124	William Conyngham	Plunket	1765-07-01	1854-01-05	\N	17	1	\N	\N	\N
125	John Frederick	Campbell	1790-11-08	1860-11-07	\N	4	1	\N	\N	\N
126	Henry	Wellesley	1773-01-20	1847-04-27	\N	24	1	\N	\N	\N
127	Joan	Canning	\N	1837-03-15	\N	4	2	\N	\N	\N
128	Charles	Stuart	1779-01-02	1845-11-06	\N	20	1	\N	\N	\N
130	Archibald John	Primrose	1783-10-14	1868-03-04	\N	17	1	\N	\N	\N
131	Richard	Meade	1795-08-15	1879-10-07	\N	14	1	\N	\N	\N
132	John George	Lambton	1792-04-12	1840-07-28	\N	13	1	\N	\N	\N
133	Edward Bootle	Wilbraham	1771-03-07	1853-04-03	\N	24	1	\N	\N	\N
134	Thomas	Wallace	\N	1844-02-23	\N	24	1	\N	\N	\N
135	William Draper	Best	1767-12-13	1845-03-03	\N	3	1	\N	\N	\N
136	Henry	Brougham	1778-09-19	1868-05-07	\N	3	1	\N	\N	\N
137	William George	Hay Carr	1801-02-21	1846-04-19	\N	9	1	\N	\N	\N
139	William Philip	Molyneux	1772-09-18	1838-11-20	\N	14	1	\N	\N	\N
140	Nathaniel	Clements	1768-05-09	1854-12-31	\N	4	1	\N	\N	\N
141	George William Fox	Kinnaird	1807-04-14	1878-01-07	\N	12	1	\N	\N	\N
142	George James Welbore	Agar Ellis	1797-01-17	1833-07-10	\N	2	1	\N	\N	\N
143	Thomas	Taylour	1787-05-04	1870-12-06	\N	21	1	\N	\N	\N
144	John Chambre	Brabazon	1772-04-09	1851-03-15	\N	3	1	\N	\N	\N
145	George James	Ludlow	1758-12-12	1842-04-16	\N	13	1	\N	\N	\N
146	Percy Clinton Sydney	Smythe	1780-08-31	1855-05-29	\N	20	1	\N	\N	\N
147	John Francis	Cradock	1762-08-12	1839-07-26	\N	4	1	\N	\N	\N
148	William	Maule	1771-10-27	1852-04-13	\N	14	1	\N	\N	\N
149	George	Cadogan	1783-05-05	1864-09-15	\N	4	1	\N	\N	\N
151	Robert	Lawley	\N	1834-04-10	\N	13	1	\N	\N	\N
153	John William	Ward	1781-08-09	1833-03-06	\N	24	1	\N	\N	\N
154	George	FitzClarence	1794-01-29	1842-03-20	\N	7	1	\N	\N	\N
155	William Harry	Vane	1766-07-27	1842-01-29	\N	23	1	\N	\N	\N
156	Arthur	Chichester	1797-01-08	1837-09-26	\N	4	1	\N	\N	\N
157	William Lewis	Hughes	1767-11-10	1852-02-10	\N	9	1	\N	\N	\N
158	Valentine Browne	Lawless	1773-08-19	1853-10-28	\N	13	1	\N	\N	\N
159	James	Saumarez	1757-03-11	1836-10-09	\N	20	1	\N	\N	\N
161	Lucius Bentinck	Cary	1803-11-05	1884-03-12	\N	4	1	\N	\N	\N
162	Charles	Dundas	1751-04-05	1832-06-30	\N	5	1	\N	\N	\N
163	Edward	Smith Stanley	1775-04-21	1851-06-30	\N	20	1	\N	\N	\N
164	Charles Callis	Western	1767-08-09	1844-11-04	\N	24	1	\N	\N	\N
165	Granville	Leveson Gower	1773-10-12	1846-01-08	\N	13	1	\N	\N	\N
166	Charles	Douglas	\N	1837-12-03	\N	5	1	\N	\N	\N
167	Thomas	Denman	1779-02-23	1854-09-22	\N	5	1	\N	\N	\N
168	Sophia Elizabeth	Wykam	1790-03-10	1870-08-09	\N	24	2	\N	\N	\N
170	James	Scarlett	1769-12-13	1844-04-07	\N	20	1	\N	\N	\N
171	Philip Charles	Sidney	1800-03-11	1851-03-04	\N	20	1	\N	\N	\N
172	Charles	Manners Sutton	1780-01-29	1845-07-21	\N	14	1	\N	\N	\N
173	Alexander	Baring	1774-10-27	1848-05-12	\N	3	1	\N	\N	\N
174	Charles	Grant	1778-10-26	1866-04-23	\N	8	1	\N	\N	\N
176	John	Byng	\N	1860-06-03	\N	3	1	\N	\N	\N
177	Archibald	Acheson	1776-08-01	1849-03-27	\N	2	1	\N	\N	\N
179	Mary Elizabeth	Campbell	\N	1860-03-25	\N	4	2	\N	\N	\N
180	Henry	Bickersteth	1783-06-18	1851-04-18	\N	3	1	\N	\N	\N
181	Edward Berkeley	Portman	1799-07-09	1888-11-19	\N	17	1	\N	\N	\N
182	Thomas Alexander	Fraser	1802-06-17	1875-06-28	\N	7	1	\N	\N	\N
183	Robert Montgomery	Hamilton	\N	1868-12-22	\N	9	1	\N	\N	\N
184	Anthony Adrian	Keith Falconer	1794-04-20	1844-07-11	\N	12	1	\N	\N	\N
185	Cornelius	O'Callaghan	1775-10-02	1857-05-30	\N	16	1	\N	\N	\N
186	Warner William	Westenra	1765-10-14	1842-08-10	\N	24	1	\N	\N	\N
187	Robert Shapland	Carew	1787-03-09	1856-06-02	\N	4	1	\N	\N	\N
189	George Granville	Leveson Gower	1758-01-09	1833-07-19	\N	13	1	\N	\N	\N
190	Thomas	Moreton	1776-08-31	1840-06-22	\N	14	1	\N	\N	\N
191	Kenneth Alexander	Howard	1767-11-29	1845-02-13	\N	9	1	\N	\N	\N
192	Thomas William	Anson	1795-10-20	1854-03-18	\N	2	1	\N	\N	\N
193	William	King	1805-02-20	1893-12-29	\N	12	1	\N	\N	\N
194	Lawrence	Dundas	1766-04-10	1839-02-19	\N	5	1	\N	\N	\N
195	Robert	Grosvenor	1767-03-22	1845-02-17	\N	8	1	\N	\N	\N
196	John	Wrottesley	1771-10-25	1841-03-16	\N	24	1	\N	\N	\N
197	Charles	Hanbury Tracy	1777-12-28	1858-02-10	\N	9	1	\N	\N	\N
198	Paul	Methuen	1779-06-21	1849-09-11	\N	14	1	\N	\N	\N
199	John	Ponsonby	\N	1855-02-21	\N	17	1	\N	\N	\N
202	Chandos	Leigh	1791-06-27	1850-09-27	\N	13	1	\N	\N	\N
203	Paul Beilby	Thompson	\N	1852-05-09	\N	21	1	\N	\N	\N
204	Charles	Brownlow	1795-04-17	1847-04-30	\N	3	1	\N	\N	\N
206	Arthur	French	\N	1856-09-29	\N	7	1	\N	\N	\N
207	James	Abercromby	1776-11-07	1858-04-17	\N	2	1	\N	\N	\N
208	Thomas Spring	Rice	1790-02-08	1866-02-07	\N	19	1	\N	\N	\N
209	John	Colborne	1778-02-16	1863-04-17	\N	4	1	\N	\N	\N
210	John	Keane	1781-02-06	1844-08-26	\N	12	1	\N	\N	\N
211	Charles	Poulett Thomson	1799-09-13	1841-09-19	\N	17	1	\N	\N	\N
212	John	Dalrymple	1771-06-15	1853-01-10	\N	5	1	\N	\N	\N
213	William Fitzhardinge	Berkeley	1786-09-26	1857-10-10	\N	3	1	\N	\N	\N
214	Valentine	Browne	1788-01-15	1853-10-31	\N	3	1	\N	\N	\N
215	George Hamilton	Chichester	1797-02-10	1883-10-20	\N	4	1	\N	\N	\N
216	Richard Hussey	Vivian	1775-07-28	1842-08-20	\N	23	1	\N	\N	\N
217	Henry Brooke	Parnell	1776-07-03	1842-06-08	\N	17	1	\N	\N	\N
218	William	Hanbury	1780-06-24	1845-07-22	\N	9	1	\N	\N	\N
221	Archibald	Acheson	1806-08-20	1864-06-15	\N	2	1	\N	\N	\N
222	Richard	Dawson	1817-09-07	1897-05-12	\N	5	1	\N	\N	\N
223	Richard Bulkeley Philipps	Philipps	1801-06-07	1857-01-03	\N	17	1	\N	\N	\N
224	Hugh	Gough	1779-11-03	1869-03-02	\N	8	1	\N	\N	\N
225	James	Bruce	1811-07-20	1863-11-20	\N	3	1	\N	\N	\N
226	Cecilia Letitia	Underwood	\N	1873-08-01	\N	22	2	\N	\N	\N
2848	Henry Jaffray Hynman	Allenby	1968-07-29	\N	\N	2	1	\N	\N	\N
229	Charles Noel	Noel	1781-10-02	1866-06-10	\N	15	1	\N	\N	\N
230	Charles	Pelham	1781-08-08	1846-09-05	\N	17	1	\N	\N	\N
232	Constantine Henry	Phipps	1797-05-15	1863-07-28	\N	17	1	\N	\N	\N
233	Albert Edward	-	1841-11-09	1910-05-06	\N	1	1	\N	\N	\N
234	Albert Denison	Denison	1805-10-21	1860-01-15	\N	5	1	\N	\N	\N
235	Samuel Jones	Loyd	1796-09-25	1883-11-17	\N	13	1	\N	\N	\N
236	Thomas	Wilde	1782-07-07	1855-11-11	\N	24	1	\N	\N	\N
237	Robert Monsey	Rolfe	1790-12-18	1868-07-26	\N	19	1	\N	\N	\N
238	John Cam	Hobhouse	1786-06-27	1869-06-03	\N	9	1	\N	\N	\N
240	Stratford	Canning	1786-11-04	1880-08-14	\N	4	1	\N	\N	\N
241	FitzRoy James Henry	Somerset	1788-09-30	1855-06-28	\N	20	1	\N	\N	\N
242	James	Parke	1782-03-22	1868-02-25	\N	17	1	\N	\N	\N
243	Gilbert John	Heathcote	1795-01-16	1867-09-06	\N	9	1	\N	\N	\N
244	Thomas	Browne	1789-01-15	1871-12-26	\N	3	1	\N	\N	\N
245	Edmund	Lyons	1790-11-21	1858-11-23	\N	13	1	\N	\N	\N
246	Edward	Strutt	1801-10-26	1880-06-30	\N	20	1	\N	\N	\N
247	James	Talbot	1805-11-22	1883-04-14	\N	21	1	\N	\N	\N
248	Henry Richard Charles	Wellesley	1804-06-17	1884-07-15	\N	24	1	\N	\N	\N
249	Charles	Shaw Lefevre	1794-02-22	1888-12-28	\N	20	1	\N	\N	\N
250	Robert	Grosvenor	1801-04-24	1893-11-18	\N	8	1	\N	\N	\N
252	Frederic	Thesiger	1794-07-15	1878-10-05	\N	21	1	\N	\N	\N
253	John	Buller Yarde Buller	1799-04-12	1871-09-04	\N	3	1	\N	\N	\N
254	John Charles	Grant	1815-09-04	1881-02-18	\N	8	1	\N	\N	\N
255	Colin	Campbell	1792-10-20	1863-08-14	\N	4	1	\N	\N	\N
257	George	Wyndham	1787-06-05	1869-03-18	\N	24	1	\N	\N	\N
259	Henry	Hardinge	1785-03-30	1856-09-24	\N	9	1	\N	\N	\N
260	Robert Vernon	Smith	1800-02-01	1873-11-10	\N	20	1	\N	\N	\N
261	Benjamin	Hall	1802-11-08	1867-04-27	\N	9	1	\N	\N	\N
262	Henry	Labouchere	1798-08-15	1869-07-13	\N	13	1	\N	\N	\N
263	Sidney	Herbert	1810-09-16	1861-08-02	\N	9	1	\N	\N	\N
264	Richard	Bethell	1800-06-30	1873-07-20	\N	3	1	\N	\N	\N
265	John	Russell	1792-08-18	1878-05-28	\N	19	1	\N	\N	\N
267	William	Ward	1817-03-27	1885-05-07	\N	24	1	\N	\N	\N
268	Archibald William	Montgomerie	1812-09-29	1861-10-04	\N	14	1	\N	\N	\N
269	Edward Adolphus	Seymour	1804-12-20	1885-11-28	\N	20	1	\N	\N	\N
270	Henry	White	\N	1873-09-01	\N	24	1	\N	\N	\N
271	Richard Monckton	Milnes	1809-06-19	1885-08-11	\N	14	1	\N	\N	\N
272	Elizabeth	Sackville West	\N	1870-01-01	\N	20	2	\N	\N	\N
273	John	Romilly	1802-01-10	1874-12-23	\N	19	1	\N	\N	\N
274	Francis Thornhill	Baring	1796-04-20	1866-09-06	\N	3	1	\N	\N	\N
275	Charles	Wood	1800-12-20	1885-08-08	\N	24	1	\N	\N	\N
276	James	Sinclair	1821-12-16	1881-03-28	\N	20	1	\N	\N	\N
277	Thomas	Fortescue	1815-03-09	1887-07-29	\N	7	1	\N	\N	\N
278	William Meredyth	Somerville	\N	1873-12-07	\N	20	1	\N	\N	\N
280	Charles Stanley	Monck	1819-10-10	1894-11-29	\N	14	1	\N	\N	\N
281	John	Henniker-Major	1801-02-03	1870-04-16	\N	9	1	\N	\N	\N
283	William George Hylton	Jolliffe	1800-12-07	1876-06-01	\N	11	1	\N	\N	\N
284	Hugh Henry	Rose	1801-04-06	1885-10-16	\N	19	1	\N	\N	\N
285	Edward Gordon	Douglas Pennant	1800-06-20	1886-03-31	\N	5	1	\N	\N	\N
286	Duncan	McNeill	1793-08-20	1874-01-31	\N	14	1	\N	\N	\N
287	Hugh MacCalmont	Cairns	1819-12-27	1885-04-02	\N	4	1	\N	\N	\N
288	John	Trollope	1800-05-05	1874-12-17	\N	21	1	\N	\N	\N
289	John Benn	Walsh	1798-12-09	1881-02-03	\N	24	1	\N	\N	\N
291	William	O'Neill	1813-03-04	1883-04-18	\N	16	1	\N	\N	\N
292	Charles John	Canning	1812-12-14	1862-06-17	\N	4	1	\N	\N	\N
293	John	Elphinstone	1807-06-23	1860-07-19	\N	6	1	\N	\N	\N
294	Mary Anne	Disraeli	1792-11-11	1872-12-15	\N	5	2	\N	\N	\N
295	Edward Anthony John	Preston	1796-06-03	1876-09-28	\N	17	1	\N	\N	\N
296	William Page	Wood	1801-11-29	1881-07-10	\N	24	1	\N	\N	\N
297	James Plaisted	Wilde	1816-07-12	1899-12-09	\N	24	1	\N	\N	\N
298	John	Rogerson Rollo	1835-10-24	1916-10-02	\N	19	1	\N	\N	\N
299	William	Hare	1833-05-29	1924-06-05	\N	9	1	\N	\N	\N
301	John Wilson	FitzPatrick	1811-09-23	1883-01-22	\N	7	1	\N	\N	\N
302	John Emerich Edward	Dalberg-Acton	1834-01-10	1902-06-19	\N	5	1	\N	\N	\N
303	George Carr	Glyn	1797-04-27	1873-07-24	\N	8	1	\N	\N	\N
304	Alfred Ernest Albert	-	1844-08-06	1900-07-30	\N	1	1	\N	\N	\N
305	John	Wodehouse	1826-01-07	1902-04-08	\N	24	1	\N	\N	\N
306	Fulke Southwell	Greville-Nugent	1821-02-17	1883-01-25	\N	8	1	\N	\N	\N
307	Charles William	Fitzgerald	1819-03-30	1887-02-10	\N	7	1	\N	\N	\N
308	Thomas	O'Hagan	1812-05-29	1885-02-01	\N	16	1	\N	\N	\N
309	John	Young	1807-08-31	1876-10-06	\N	26	1	\N	\N	\N
311	William Rose	Mansfield	1819-06-21	1876-06-23	\N	14	1	\N	\N	\N
312	Angela Georgina	Burdett-Coutts	1814-04-21	1906-12-30	\N	3	2	\N	\N	\N
313	John Arthur Douglas	Bloomfield	1802-11-12	1879-08-17	\N	3	1	\N	\N	\N
314	Frederic	Rogers	1811-01-31	1889-11-21	\N	19	1	\N	\N	\N
315	John Evelyn	Denison	1800-01-27	1873-03-07	\N	5	1	\N	\N	\N
316	Francis	Napier	1819-09-15	1898-12-19	\N	15	1	\N	\N	\N
317	John	Hanmer	1809-12-22	1881-03-08	\N	9	1	\N	\N	\N
318	Roundell	Palmer	1812-11-27	1895-05-04	\N	17	1	\N	\N	\N
321	Robert Alexander Shafto	Adair	1811-08-25	1886-02-05	\N	2	1	\N	\N	\N
322	David	Robertson	1797-04-02	1873-06-19	\N	19	1	\N	\N	\N
323	Henry Austin	Bruce	1815-04-16	1895-02-25	\N	3	1	\N	\N	\N
324	Edward Granville George	Howard	1809-12-23	1880-10-08	\N	9	1	\N	\N	\N
325	James	Moncreiff	1811-11-29	1895-04-27	\N	14	1	\N	\N	\N
326	John Duke	Coleridge	1820-12-03	1894-06-14	\N	4	1	\N	\N	\N
327	William	Monsell	1812-09-21	1894-04-20	\N	14	1	\N	\N	\N
329	Robert Cornelis	Napier	1810-12-05	1890-01-14	\N	15	1	\N	\N	\N
330	Edward	Cardwell	1813-07-24	1886-02-15	\N	4	1	\N	\N	\N
331	John Somerset	Pakington	1799-02-20	1880-04-09	\N	17	1	\N	\N	\N
332	John	Wilson Patten	1802-04-26	1892-07-11	\N	24	1	\N	\N	\N
333	Cospatrick Alexander	Home	1799-10-27	1881-07-04	\N	9	1	\N	\N	\N
334	George	Ramsay	1806-04-26	1880-07-20	\N	19	1	\N	\N	\N
336	John	Crichton	1802-07-30	1885-10-03	\N	4	1	\N	\N	\N
228	Francis	Egerton	1800-01-01	1857-02-18	\N	6	1	\N	\N	\N
2849	Gerald William	Balfour	1853-04-09	1945-01-14	\N	3	1	\N	\N	\N
339	Hugh Lupus	Grosvenor	1825-10-13	1899-12-22	\N	8	1	\N	\N	\N
341	William Ernest	Duncombe	1829-01-28	1915-01-13	\N	5	1	\N	\N	\N
342	William	Nevill	1826-09-16	1915-12-12	\N	15	1	\N	\N	\N
343	George Frederick Samuel	Robinson	1827-10-24	1900-07-09	\N	19	1	\N	\N	\N
344	Henry Gerard	Sturt	1825-05-16	1904-02-17	\N	20	1	\N	\N	\N
345	John	Tollemache	1805-12-05	1890-12-09	\N	21	1	\N	\N	\N
346	Robert Tolver	Gerard	1808-05-12	1887-03-15	\N	8	1	\N	\N	\N
347	Mortimer	Sackville-West	1820-09-22	1888-10-01	\N	20	1	\N	\N	\N
348	Edward Strathearn	Gordon	1814-04-10	1879-08-21	\N	8	1	\N	\N	\N
349	Richard	Airey	1803-04-01	1881-09-13	\N	2	1	\N	\N	\N
351	Gathorne	Hardy	1814-10-01	1906-10-30	\N	9	1	\N	\N	\N
352	George William	Barrington	1824-02-14	1886-11-07	\N	3	1	\N	\N	\N
353	Augusta Mary Elizabeth	Cavendish-Bentinck	1834-11-08	1893-08-07	\N	4	2	\N	\N	\N
354	William	Watson	1827-08-25	1899-09-14	\N	24	1	\N	\N	\N
355	Lawrence	Palk	1818-01-05	1883-03-22	\N	17	1	\N	\N	\N
356	Ivor Bertie	Guest	1835-08-29	1914-02-22	\N	8	1	\N	\N	\N
358	Alexander Dundas Ross	Cochrane Wishart Baillie	1816-11-24	1890-02-15	\N	4	1	\N	\N	\N
359	George Watson	Milles	1824-10-02	1894-09-10	\N	14	1	\N	\N	\N
360	Charles Frederick	Abney Hastings	1822-06-17	1895-07-24	\N	2	1	\N	\N	\N
361	Arthur Edwin	Hill-Trevor	1819-11-04	1894-12-25	\N	9	1	\N	\N	\N
362	Montague William	Lowry Corry	1838-10-08	1903-11-09	\N	13	1	\N	\N	\N
363	Robert	Lowe	1811-12-04	1892-07-27	\N	13	1	\N	\N	\N
364	Thomas Francis	Fremantle	1798-03-11	1890-12-03	\N	7	1	\N	\N	\N
365	Edmund	Hammond	1802-06-25	1890-04-29	\N	9	1	\N	\N	\N
367	William Montagu	Hay	1826-01-27	1911-11-25	\N	9	1	\N	\N	\N
369	Donald James	Mackay	1839-12-22	1921-08-01	\N	14	1	\N	\N	\N
370	Harcourt	Van den Bempde-Johnstone	1829-01-03	1916-03-01	\N	23	1	\N	\N	\N
371	Henry James	Tufton	1844-06-04	1926-10-29	\N	21	1	\N	\N	\N
372	Dudley Coutts	Marjoribanks	1820-12-29	1894-03-04	\N	14	1	\N	\N	\N
373	George William Wilshere	Bramwell	1808-06-12	1892-05-09	\N	3	1	\N	\N	\N
374	John David	FitzGerald	1816-05-01	1889-10-16	\N	7	1	\N	\N	\N
375	Frederick Beauchamp Paget	Seymour	1821-04-12	1895-03-30	\N	20	1	\N	\N	\N
376	Garnet Joseph	Wolseley	1833-06-04	1913-03-25	\N	24	1	\N	\N	\N
377	Alfred	Tennyson	1809-08-06	1892-10-06	\N	21	1	\N	\N	\N
379	Thomas George	Baring	1826-01-22	1904-11-15	\N	3	1	\N	\N	\N
380	John Thomas	Freeman-Mitford	1805-09-09	1886-05-02	\N	7	1	\N	\N	\N
381	Henry Bouverie William	Brand	1814-12-24	1892-03-14	\N	3	1	\N	\N	\N
382	John George	Dodson	1825-10-18	1897-05-25	\N	5	1	\N	\N	\N
383	Walter Charles	James	1816-06-03	1893-02-04	\N	11	1	\N	\N	\N
384	Arthur Saunders William Charles Fox	Gore	1839-01-06	1901-03-14	\N	8	1	\N	\N	\N
385	John Robert William	Vesey	1844-05-21	1903-07-06	\N	23	1	\N	\N	\N
386	Marmaduke Francis	Constable Maxwell	1837-10-04	1908-10-05	\N	4	1	\N	\N	\N
387	Hardinge Stanley	Giffard	1823-09-03	1921-12-11	\N	8	1	\N	\N	\N
388	Mervyn Edward	Wingfield	1836-10-13	1904-06-05	\N	24	1	\N	\N	\N
389	Anthony Henley	Henley	1825-04-12	1898-11-27	\N	9	1	\N	\N	\N
391	Edward Charles	Baring	1828-04-13	1897-07-17	\N	3	1	\N	\N	\N
393	Arthur	Hobhouse	1819-11-10	1904-12-06	\N	9	1	\N	\N	\N
394	Ralph Robert Wheeler	Lingen	1819-02-19	1905-07-22	\N	13	1	\N	\N	\N
395	Edward	Gibson	1837-09-04	1913-05-22	\N	8	1	\N	\N	\N
396	Rowland	Winn	1820-02-19	1893-01-20	\N	24	1	\N	\N	\N
397	Robert James	Loyd-Lindsay	1832-04-16	1901-06-10	\N	13	1	\N	\N	\N
398	William Baliol	Brett	1815-08-13	1899-05-24	\N	3	1	\N	\N	\N
399	Thomas	Bateson	1819-06-04	1890-12-01	\N	3	1	\N	\N	\N
400	Henry John	Montagu-Douglas-Scott	1832-11-05	1905-11-04	\N	14	1	\N	\N	\N
401	William Francis	Cowper-Temple	1811-12-13	1888-10-17	\N	4	1	\N	\N	\N
403	Charles Henry	Mills	1830-04-26	1898-04-03	\N	14	1	\N	\N	\N
404	Henry	Allsopp	1811-02-19	1887-04-03	\N	2	1	\N	\N	\N
405	Richard de Aquila	Grosvenor	1837-01-28	1912-05-18	\N	8	1	\N	\N	\N
406	William	Edwardes	1835-05-11	1896-10-07	\N	6	1	\N	\N	\N
407	Thomas Erskine	May	1815-02-08	1886-05-17	\N	14	1	\N	\N	\N
408	William John	Monson	1829-02-18	1898-04-16	\N	14	1	\N	\N	\N
410	John Glencairn Carter	Hamilton	1829-11-16	1900-10-15	\N	9	1	\N	\N	\N
411	Thomas	Brassey	1836-02-11	1918-02-23	\N	3	1	\N	\N	\N
412	Henry	Thring	1818-11-03	1907-02-04	\N	21	1	\N	\N	\N
413	Richard Assheton	Cross	1823-05-30	1914-01-08	\N	4	1	\N	\N	\N
414	Frederick Arthur	Stanley	1841-01-15	1908-06-14	\N	20	1	\N	\N	\N
415	Cornwallis	Maude	1817-04-04	1905-01-09	\N	14	1	\N	\N	\N
417	Edward	Macnaghten	1830-02-03	1913-02-17	\N	14	1	\N	\N	\N
418	Robert	Bourke	1827-06-11	1902-09-03	\N	3	1	\N	\N	\N
419	Claude	Bowes Lyon	1824-07-21	1904-02-16	\N	3	1	\N	\N	\N
420	George Edmund Milnes	Monckton-Arundell	1844-11-18	1931-03-07	\N	14	1	\N	\N	\N
421	John	St Aubyn	1829-10-23	1908-05-14	\N	20	1	\N	\N	\N
422	James Macnaghten	McGarel-Hogg	1823-05-03	1890-06-27	\N	14	1	\N	\N	\N
423	William George	Armstrong	1810-11-26	1900-12-27	\N	2	1	\N	\N	\N
424	George	Sclater-Booth	1826-05-19	1894-10-22	\N	20	1	\N	\N	\N
425	Edward	Fellowes	1809-04-14	1887-08-09	\N	7	1	\N	\N	\N
427	John Gellibrand	Hubbard	1805-03-21	1889-08-28	\N	9	1	\N	\N	\N
428	Henry Thurstan	Holland	1825-08-03	1914-01-29	\N	9	1	\N	\N	\N
429	John	Savile	1818-01-06	1896-11-28	\N	20	1	\N	\N	\N
430	William Ventris	Field	1813-08-21	1907-01-23	\N	7	1	\N	\N	\N
431	Francis Richard	Sandford	1824-05-14	1893-12-31	\N	20	1	\N	\N	\N
432	James	Hannen	1821-03-19	1894-03-29	\N	9	1	\N	\N	\N
433	Samuel	Cunliffe Lister	1815-01-01	1906-02-02	\N	4	1	\N	\N	\N
434	Susan Agnes	Macdonald	\N	1920-09-05	\N	14	2	\N	\N	\N
435	Emily	Smith	\N	1913-08-13	\N	20	2	\N	\N	\N
437	Farrer	Herschell	1837-11-02	1899-03-01	\N	9	1	\N	\N	\N
439	Evelyn	Baring	1841-02-26	1917-01-29	\N	3	1	\N	\N	\N
440	Alexander Burns	Shand	1828-12-13	1904-03-06	\N	20	1	\N	\N	\N
441	George	Cubitt	1828-06-04	1917-02-26	\N	4	1	\N	\N	\N
442	Rainald	Knightley	1819-10-22	1895-12-19	\N	12	1	\N	\N	\N
873	Stanley	Baldwin	1867-08-03	1947-12-14	\N	3	1	\N	\N	\N
447	John	Mulholland	1819-12-16	1895-12-11	\N	14	1	\N	\N	\N
448	John Allan	Rolls	1837-02-19	1912-09-24	\N	19	1	\N	\N	\N
449	Albert Victor Christian Edward	-	1864-01-08	1892-01-14	\N	1	1	\N	\N	\N
450	Alexander William George	Duff	1849-11-10	1912-01-29	\N	5	1	\N	\N	\N
451	George Frederick Ernest Albert	-	1865-06-03	1936-01-20	\N	1	1	\N	\N	\N
452	Gathorne	Gathorne-Hardy	1814-10-01	1906-10-30	\N	8	1	\N	\N	\N
454	Lawrence	Dundas	1844-08-16	1929-03-11	\N	5	1	\N	\N	\N
455	Lyon	Playfair	1818-05-21	1898-05-29	\N	17	1	\N	\N	\N
456	Cyril	Flower	1843-08-30	1907-11-27	\N	7	1	\N	\N	\N
457	Henry Hussey	Vivian	1821-07-06	1894-11-28	\N	23	1	\N	\N	\N
458	Thomas Henry	Farrer	1819-06-24	1899-10-11	\N	7	1	\N	\N	\N
459	John Campbell	White	1843-11-21	1908-02-15	\N	24	1	\N	\N	\N
460	Francis Archibald	Douglas	1867-02-03	1894-10-19	\N	5	1	\N	\N	\N
461	Arthur	Hamilton-Gordon	1829-11-26	1912-01-30	\N	9	1	\N	\N	\N
462	Charles Synge Christopher	Bowen	1831-08-29	1894-04-10	\N	3	1	\N	\N	\N
463	Stuart	Rendel	1834-07-02	1913-06-04	\N	19	1	\N	\N	\N
464	Reginald Earle	Welby	1832-08-03	1915-10-29	\N	24	1	\N	\N	\N
465	Charles	Russell	1832-11-10	1900-08-10	\N	19	1	\N	\N	\N
466	Horace	Davey	1833-08-29	1907-02-20	\N	5	1	\N	\N	\N
469	Henry Brougham	Loch	1827-05-23	1900-06-20	\N	13	1	\N	\N	\N
470	Sydney James	Stern	\N	1912-02-10	\N	20	1	\N	\N	\N
471	James	Williamson	1842-12-31	1930-05-27	\N	24	1	\N	\N	\N
472	Herbert Coulstoun	Gardner	1846-06-09	1921-05-06	\N	8	1	\N	\N	\N
473	Henry	Matthews	1826-01-13	1913-04-03	\N	14	1	\N	\N	\N
474	Henry	James	1828-10-30	1911-08-18	\N	11	1	\N	\N	\N
475	David Robert	Plunket	1838-12-03	1919-08-22	\N	17	1	\N	\N	\N
476	Henry	de Worms	1840-10-20	1903-01-09	\N	5	1	\N	\N	\N
478	William	Thomson	1824-06-26	1907-12-17	\N	21	1	\N	\N	\N
479	John James Robert	Manners	1818-12-13	1906-08-04	\N	14	1	\N	\N	\N
480	Hercules George Robert	Robinson	1824-12-19	1897-10-28	\N	19	1	\N	\N	\N
481	Alexander Smith	Kinnear	1833-11-03	1917-12-20	\N	12	1	\N	\N	\N
482	Joseph	Lister	1827-04-05	1912-02-10	\N	13	1	\N	\N	\N
483	Wilbraham	Egerton	1832-01-17	1909-03-16	\N	6	1	\N	\N	\N
484	David	Boyle	1833-05-31	1915-12-13	\N	3	1	\N	\N	\N
485	Hugh Richard	Dawnay	1844-07-20	1924-01-21	\N	5	1	\N	\N	\N
487	Ion Trant	Hamilton	1839-07-14	1898-03-06	\N	9	1	\N	\N	\N
488	John	Burns	1829-06-24	1901-02-12	\N	3	1	\N	\N	\N
490	Josslyn Francis	Pennington	1834-12-25	1917-03-30	\N	17	1	\N	\N	\N
491	Arthur Lawrence	Haliburton	1832-09-26	1907-04-21	\N	9	1	\N	\N	\N
492	Horatio Herbert	Kitchener	1850-06-24	1916-06-05	\N	12	1	\N	\N	\N
493	Philip Henry Wodehouse	Currie	1834-10-13	1906-05-12	\N	4	1	\N	\N	\N
494	Joseph Russell	Bailey	1840-04-07	1906-01-06	\N	3	1	\N	\N	\N
495	Henry	Hawkins	1817-09-14	1907-10-06	\N	9	1	\N	\N	\N
496	Robert Thornhaugh	Gurdon	1829-06-18	1902-10-13	\N	8	1	\N	\N	\N
497	Henrietta Anne	Carleton	\N	1925-03-02	\N	4	2	\N	\N	\N
498	Julian	Pauncefote	1828-09-13	1902-05-24	\N	17	1	\N	\N	\N
500	Henry Stafford	Northcote	1846-11-18	1911-09-29	\N	15	1	\N	\N	\N
501	John	Lubbock	1834-04-30	1913-05-28	\N	13	1	\N	\N	\N
502	Nathaniel	Lindley	1828-11-29	1921-12-09	\N	13	1	\N	\N	\N
503	Michael	Morris	1826-11-14	1901-09-08	\N	14	1	\N	\N	\N
504	Peter	O'Brien	1842-06-29	1914-09-07	\N	16	1	\N	\N	\N
505	Richard Everard	Webster	1842-12-22	1915-12-15	\N	24	1	\N	\N	\N
506	George Joachim	Goschen	1831-08-10	1907-02-07	\N	8	1	\N	\N	\N
507	Matthew White	Ridley	1842-07-25	1904-11-28	\N	19	1	\N	\N	\N
509	Alfred	Milner	1854-03-23	1925-05-13	\N	14	1	\N	\N	\N
510	Henry Hucks	Gibbs	1819-08-31	1907-09-13	\N	8	1	\N	\N	\N
511	Edward	Heneage	1840-03-29	1922-08-10	\N	9	1	\N	\N	\N
512	John Blair	Balfour	1837-07-11	1905-01-22	\N	3	1	\N	\N	\N
514	William Lawies	Jackson	1840-02-16	1917-04-04	\N	11	1	\N	\N	\N
515	Arthur Hugh	Smith-Barry	1843-01-17	1925-02-22	\N	20	1	\N	\N	\N
517	Francis	Knollys	1837-07-16	1924-08-15	\N	12	1	\N	\N	\N
518	Edward	Levy-Lawson	1833-12-28	1916-01-09	\N	13	1	\N	\N	\N
519	Michael	Biddulph	1834-02-17	1923-04-06	\N	3	1	\N	\N	\N
520	George Thomas John	Sotheron-Estcourt	1839-01-21	1915-01-12	\N	20	1	\N	\N	\N
521	William Henry Armstrong Fitzpatrick	Watson-Armstrong	1863-05-03	1941-10-16	\N	24	1	\N	\N	\N
522	Francis Henry	Jeune	1843-03-17	1905-04-09	\N	11	1	\N	\N	\N
523	Andrew Graham	Murray	1849-11-21	1942-08-21	\N	14	1	\N	\N	\N
524	William Court	Gully	1835-08-29	1909-11-06	\N	8	1	\N	\N	\N
525	Edward Cecil	Guinness	1847-11-10	1927-10-07	\N	8	1	\N	\N	\N
526	Robert George	Windsor-Clive	1857-08-27	1923-03-06	\N	24	1	\N	\N	\N
527	John Adrian Louis	Hope	1860-09-25	1908-02-29	\N	9	1	\N	\N	\N
529	Angus	Holden	1833-03-16	1912-03-25	\N	9	1	\N	\N	\N
530	Charles Robert	Spencer	1857-10-30	1922-09-26	\N	20	1	\N	\N	\N
531	John	Atkinson	1844-12-13	1932-03-13	\N	2	1	\N	\N	\N
532	Thomas Henry	Sanderson	1841-01-11	1923-03-21	\N	20	1	\N	\N	\N
533	Charles Thomson	Ritchie	1838-11-19	1906-01-09	\N	19	1	\N	\N	\N
534	William Hood	Walrond	1849-02-26	1925-05-17	\N	24	1	\N	\N	\N
536	Alfred Charles William	Harmsworth	1865-07-15	1922-08-14	\N	9	1	\N	\N	\N
537	Godfrey Charles	Morgan	1831-04-28	1913-03-11	\N	14	1	\N	\N	\N
538	Herbert	Stern	1851-09-28	1919-01-07	\N	20	1	\N	\N	\N
539	Edmund Beckett	Faber	1847-02-09	1920-09-17	\N	7	1	\N	\N	\N
541	Michael Edward	Hicks-Beach	1837-10-23	1916-04-30	\N	9	1	\N	\N	\N
542	Robert Threshie	Reid	1846-04-03	1923-11-30	\N	19	1	\N	\N	\N
543	Philip James	Stanhope	1847-02-08	1923-03-01	\N	20	1	\N	\N	\N
544	Arthur Dyvett	Hayter	1835-08-09	1917-05-10	\N	9	1	\N	\N	\N
545	Edmond George Petty	Fitzmaurice	1846-06-19	1935-06-21	\N	7	1	\N	\N	\N
546	Victor Albert Francis Charles	Spencer	1864-10-23	1934-01-03	\N	20	1	\N	\N	\N
547	William Henry	Wills	1830-09-01	1911-01-29	\N	24	1	\N	\N	\N
548	Leonard Henry	Courtney	1832-07-06	1918-05-11	\N	4	1	\N	\N	\N
549	George John	Shaw-Lefevre	1831-06-12	1928-04-19	\N	20	1	\N	\N	\N
550	William James	Pirrie	1847-05-31	1924-06-06	\N	17	1	\N	\N	\N
444	Thomas	Brooks	1825-05-15	1908-02-05	\N	3	1	\N	\N	\N
2850	Robert Arthur Lytton	Balfour	1902-12-31	1968-11-27	\N	3	1	\N	\N	\N
554	Richard Henn	Collins	1842-01-01	1911-01-03	\N	4	1	\N	\N	\N
555	James	Kitson	1835-09-22	1911-03-16	\N	12	1	\N	\N	\N
556	Montagu	Samuel-Montagu	1832-12-21	1911-01-12	\N	20	1	\N	\N	\N
557	James	Blyth	1841-09-10	1925-02-08	\N	3	1	\N	\N	\N
558	Alexander	Peckover	1830-08-16	1919-10-21	\N	17	1	\N	\N	\N
559	John	Morley	1838-12-24	1923-09-23	\N	14	1	\N	\N	\N
561	Edmund	Robertson	1845-10-28	1911-09-13	\N	19	1	\N	\N	\N
562	Antony Patrick	MacDonnell	1844-03-07	1925-06-09	\N	14	1	\N	\N	\N
564	John Wynford	Philipps	1860-05-30	1938-03-28	\N	17	1	\N	\N	\N
565	John Gorell	Barnes	1848-05-16	1913-04-22	\N	3	1	\N	\N	\N
566	Hamilton John Agmondesham	Cuffe	1848-08-30	1934-11-04	\N	4	1	\N	\N	\N
567	John Arbuthnot	Fisher	1841-01-25	1920-07-10	\N	7	1	\N	\N	\N
568	Arthur	Godley	1847-06-17	1932-06-27	\N	8	1	\N	\N	\N
569	Herbert John	Gladstone	1854-01-07	1930-03-06	\N	8	1	\N	\N	\N
570	Ivor Churchill	Guest	1873-01-16	1939-06-14	\N	8	1	\N	\N	\N
571	John Charles	Bigham	1840-08-03	1929-09-03	\N	3	1	\N	\N	\N
572	John Poynder	Dickson-Poynder	1866-10-31	1936-12-06	\N	5	1	\N	\N	\N
573	Richard Knight	Causton	1843-09-25	1929-02-23	\N	4	1	\N	\N	\N
575	Hudson Ewbanke	Kearley	1856-09-01	1934-09-05	\N	12	1	\N	\N	\N
576	Weetman Dickinson	Pearson	1856-07-15	1927-05-01	\N	17	1	\N	\N	\N
577	William Henry	Holland	1849-12-15	1927-12-26	\N	9	1	\N	\N	\N
578	Christopher	Furness	1852-04-23	1912-11-10	\N	7	1	\N	\N	\N
579	Charles	Hardinge	1858-06-20	1944-08-02	\N	9	1	\N	\N	\N
581	William Snowdon	Robson	1852-09-10	1918-09-11	\N	19	1	\N	\N	\N
583	Edward Priaulx	Tennant	1859-05-31	1920-11-21	\N	21	1	\N	\N	\N
584	James	Joicey	1846-04-04	1936-11-21	\N	11	1	\N	\N	\N
585	Charles Henry	Wilson	1833-04-22	1907-10-27	\N	24	1	\N	\N	\N
586	John	Sinclair	1860-07-07	1925-01-11	\N	20	1	\N	\N	\N
587	William Thomas	Lewis	1837-08-05	1914-08-27	\N	13	1	\N	\N	\N
588	Archibald Cameron	Corbett	1856-05-23	1933-03-19	\N	4	1	\N	\N	\N
589	Thomas Gair	Ashton	1855-02-05	1933-05-01	\N	2	1	\N	\N	\N
590	Godfrey Rathbone	Benson	1864-11-06	1945-02-03	\N	3	1	\N	\N	\N
591	Montolieu Fox	Murray	1840-04-27	1927-02-20	\N	14	1	\N	\N	\N
592	Aretas	Akers-Douglas	1851-10-21	1926-01-15	\N	2	1	\N	\N	\N
593	George Nathaniel	Curzon	1859-01-11	1925-03-20	\N	4	1	\N	\N	\N
594	Alfred	Emmott	1858-05-08	1926-12-13	\N	6	1	\N	\N	\N
596	Alfred	Thomas	1840-09-16	1927-12-14	\N	21	1	\N	\N	\N
597	Samuel Hope	Morley	1845-07-03	1929-02-18	\N	14	1	\N	\N	\N
599	Francis Allston	Channing	1841-03-21	1926-02-20	\N	4	1	\N	\N	\N
600	William Gustavus	Nicholson	1845-03-02	1918-09-13	\N	15	1	\N	\N	\N
601	Alexander William Charles Oliphant	Murray	1870-04-12	1920-09-13	\N	14	1	\N	\N	\N
602	Robert Offley Ashburton	Crewe-Milnes	1858-01-12	1945-06-20	\N	4	1	\N	\N	\N
604	Edward Albert Christian George Andrew Patrick David	-	1894-06-23	1972-05-28	\N	1	1	\N	\N	\N
605	John Fletcher	Moulton	1844-11-18	1921-03-09	\N	14	1	\N	\N	\N
606	Thomas Banks	Borthwick	1874-08-21	1967-09-29	\N	3	1	\N	\N	\N
607	George Sydenham	Clarke	1848-07-04	1933-02-07	\N	4	1	\N	\N	\N
608	George	Kemp	1866-06-09	1945-03-24	\N	12	1	\N	\N	\N
609	Robert John	Parker	1857-02-25	1918-07-12	\N	17	1	\N	\N	\N
610	John Andrew	Hamilton	1859-02-03	1934-05-24	\N	9	1	\N	\N	\N
611	Rufus Daniel	Isaacs	1860-10-10	1935-12-30	\N	10	1	\N	\N	\N
612	Alexander	Ure	1853-02-24	1928-10-02	\N	22	1	\N	\N	\N
613	Charles Alfred	Cripps	1852-10-03	1941-06-30	\N	4	1	\N	\N	\N
614	Harold Sidney	Harmsworth	1868-04-26	1940-11-26	\N	9	1	\N	\N	\N
615	James	Bryce	1838-05-10	1922-01-22	\N	3	1	\N	\N	\N
616	Sydney Charles	Buxton	1853-10-25	1934-10-15	\N	3	1	\N	\N	\N
618	Edgar	Vincent	1857-08-19	1941-11-01	\N	23	1	\N	\N	\N
619	John Fielden	Brocklehurst	1852-05-13	1921-02-28	\N	3	1	\N	\N	\N
620	Leonard	Lyell	1850-10-21	1926-09-18	\N	13	1	\N	\N	\N
622	Thomas David	Gibson-Carmichael	1859-03-18	1926-01-16	\N	8	1	\N	\N	\N
623	Arthur John	Bigge	1849-06-18	1931-03-31	\N	3	1	\N	\N	\N
624	Henry Burton	Buckley	1845-09-15	1935-10-27	\N	3	1	\N	\N	\N
625	Stanley Owen	Buckmaster	1861-01-09	1934-12-05	\N	3	1	\N	\N	\N
626	Francis Leveson	Bertie	1844-08-17	1919-09-26	\N	3	1	\N	\N	\N
627	Kenneth Augustus	Muir Mackenzie	1845-06-01	1930-05-22	\N	14	1	\N	\N	\N
628	John Denton Pinkstone	French	1852-09-28	1925-05-22	\N	7	1	\N	\N	\N
630	Alexander	Henderson	1850-09-28	1934-03-17	\N	9	1	\N	\N	\N
631	Thomas George	Shaughnessy	1853-10-06	1923-12-10	\N	20	1	\N	\N	\N
632	William Waldorf	Astor	1848-03-31	1919-10-18	\N	2	1	\N	\N	\N
633	Cecil William	Norton	1850-06-23	1930-12-07	\N	15	1	\N	\N	\N
634	David Alfred	Thomas	1856-03-26	1918-07-03	\N	21	1	\N	\N	\N
635	Henry	Chaplin	1840-12-22	1923-05-29	\N	4	1	\N	\N	\N
636	Savile Brinton	Crossley	1857-06-14	1935-02-25	\N	4	1	\N	\N	\N
637	Arthur	Nicolson	1849-09-19	1928-11-05	\N	15	1	\N	\N	\N
638	Tonman	Mosley	1850-01-16	1933-08-20	\N	14	1	\N	\N	\N
639	George	Coats	1849-02-11	1918-11-26	\N	4	1	\N	\N	\N
641	Robert Bannatyne	Finlay	1842-07-11	1929-03-09	\N	7	1	\N	\N	\N
642	William	Mansfield	1855-08-31	1921-11-02	\N	14	1	\N	\N	\N
644	William Maxwell	Aitken	1879-05-25	1964-06-09	\N	2	1	\N	\N	\N
645	Lewis	Harcourt	1863-01-31	1922-02-24	\N	9	1	\N	\N	\N
646	Joseph Albert	Pease	1860-01-17	1943-02-15	\N	17	1	\N	\N	\N
647	John Alexander	Dewar	1856-06-06	1929-11-23	\N	5	1	\N	\N	\N
648	Thomas	Roe	1832-07-13	1923-06-07	\N	19	1	\N	\N	\N
649	Edward	Partington	\N	1925-01-05	\N	17	1	\N	\N	\N
650	Hugh	Graham	1848-07-18	1938-01-28	\N	8	1	\N	\N	\N
651	Arthur	Annesley	1843-08-23	1927-01-20	\N	2	1	\N	\N	\N
652	Amelius Richard Mark	Lockwood	1847-08-17	1928-12-26	\N	13	1	\N	\N	\N
653	Ivor John Caradoc	Herbert	1851-07-15	1933-10-18	\N	9	1	\N	\N	\N
654	William Hesketh	Lever	1851-09-19	1925-05-07	\N	13	1	\N	\N	\N
656	Walter	Cunliffe	1855-12-04	1920-01-06	\N	4	1	\N	\N	\N
658	John Rushworth	Jellicoe	1859-12-05	1935-11-20	\N	11	1	\N	\N	\N
553	Wentworth Blackett	Beaumont	1829-04-11	1907-02-13	\N	3	1	\N	\N	\N
2851	Gerald Arthur James	Balfour	1925-12-23	2003-06-27	\N	3	1	\N	\N	\N
662	John Brownlee	Lonsdale	1850-03-23	1924-06-08	\N	13	1	\N	\N	\N
663	Almeric Hugh	Paget	1861-03-14	1949-09-22	\N	17	1	\N	\N	\N
665	Matthew	Arthur	1852-03-09	1928-09-23	\N	2	1	\N	\N	\N
666	William Douglas	Weir	1877-05-12	1959-07-02	\N	24	1	\N	\N	\N
667	William James	Tatem	1868-03-06	1942-06-28	\N	21	1	\N	\N	\N
668	George Denison	Faber	1851-12-14	1931-02-01	\N	7	1	\N	\N	\N
670	Ignatius John	O'Brien	1857-07-31	1930-09-10	\N	16	1	\N	\N	\N
671	Walter George Frank	Phillimore	1845-11-21	1929-03-13	\N	17	1	\N	\N	\N
672	Arthur Hamilton	Lee	1868-11-08	1947-07-21	\N	13	1	\N	\N	\N
673	Alexander Albert	Mountbatten	1886-11-23	1960-02-23	\N	14	1	\N	\N	\N
674	Charles	Bathurst	1867-09-21	1958-07-03	\N	3	1	\N	\N	\N
675	George	Cave	1856-02-23	1928-03-29	\N	4	1	\N	\N	\N
676	William	Pickford	1848-10-01	1923-08-17	\N	17	1	\N	\N	\N
677	William Hayes	Fisher	1853-03-18	1920-07-02	\N	7	1	\N	\N	\N
678	Frederick Edwin	Smith	1872-07-12	1930-09-30	\N	20	1	\N	\N	\N
679	Rowland Edmund	Prothero	1851-09-06	1937-07-01	\N	17	1	\N	\N	\N
680	Andrew	Weir	1865-04-24	1955-09-17	\N	24	1	\N	\N	\N
682	George Ranken	Askwith	1861-02-17	1942-06-02	\N	2	1	\N	\N	\N
684	Robert Trotter	Hermon-Hodge	1851-09-23	1937-06-03	\N	9	1	\N	\N	\N
685	John Herbert	Roberts	1863-08-08	1955-12-19	\N	19	1	\N	\N	\N
686	Thomas Robert	Dewar	1864-01-06	1930-04-11	\N	5	1	\N	\N	\N
687	Henry Seymour	Rawlinson	1864-02-20	1925-03-28	\N	19	1	\N	\N	\N
688	Edmund Henry Hynman	Allenby	1861-04-23	1936-05-14	\N	2	1	\N	\N	\N
689	Julian Hedworth George	Byng	1862-09-11	1935-06-06	\N	3	1	\N	\N	\N
690	Henry Sinclair	Horne	1861-02-19	1929-08-14	\N	9	1	\N	\N	\N
691	William Hall	Walker	1856-12-25	1933-02-02	\N	24	1	\N	\N	\N
692	Albert Henry	Stanley	1874-11-08	1948-11-04	\N	20	1	\N	\N	\N
693	Charles Swinfen	Eady	1851-07-31	1919-11-15	\N	6	1	\N	\N	\N
695	James Scorgie	Meston	1865-06-12	1943-10-07	\N	14	1	\N	\N	\N
697	Bertrand Edward	Dawson	1864-03-09	1945-03-07	\N	5	1	\N	\N	\N
698	Brien Ibrican	Cokayne	1864-07-12	1932-11-03	\N	4	1	\N	\N	\N
699	Horace Brooks	Marshall	1865-08-05	1936-03-29	\N	14	1	\N	\N	\N
700	Ronald Craufurd	Munro-Ferguson	1860-03-06	1934-03-30	\N	14	1	\N	\N	\N
701	William	Beardmore	1856-10-16	1936-04-09	\N	3	1	\N	\N	\N
702	Ernest	Cable	1859-12-01	1927-03-28	\N	4	1	\N	\N	\N
703	Mathew Lewis	Vaughan-Davies	1840-12-17	1935-08-21	\N	23	1	\N	\N	\N
705	Alexander Augustus Frederick William Alfred George	-	1874-04-14	1957-01-16	\N	1	1	\N	\N	\N
706	William St John Fremantle	Brodrick	1856-12-14	1942-02-13	\N	3	1	\N	\N	\N
707	Louis Alexander	Mountbatten	1854-05-24	1921-09-11	\N	14	1	\N	\N	\N
708	Edmund Bernard	Talbot	1855-06-01	1947-05-18	\N	21	1	\N	\N	\N
709	Edward Henry	Carson	1854-02-09	1935-10-22	\N	4	1	\N	\N	\N
711	Walter Hume	Long	1854-07-13	1924-09-26	\N	13	1	\N	\N	\N
712	Albert Holden	Illingworth	1865-05-25	1942-01-23	\N	10	1	\N	\N	\N
713	Marcus	Samuel	1853-11-05	1927-01-17	\N	20	1	\N	\N	\N
714	James Henry	Dalziel	1868-04-24	1935-07-15	\N	5	1	\N	\N	\N
715	Ailwyn Edward	Fellowes	1855-11-10	1924-09-23	\N	7	1	\N	\N	\N
716	Robert	Nivison	1849-07-03	1930-06-14	\N	15	1	\N	\N	\N
717	James William	Lowther	1855-04-01	1949-03-27	\N	13	1	\N	\N	\N
718	James Henry Mussen	Campbell	1851-04-04	1931-03-22	\N	4	1	\N	\N	\N
719	Alfred Tristram	Lawrence	1843-11-24	1936-08-03	\N	13	1	\N	\N	\N
720	James	Buchanan	1849-08-16	1935-08-09	\N	3	1	\N	\N	\N
721	Douglas	Haig	1861-06-19	1928-01-29	\N	9	1	\N	\N	\N
723	William	Vestey	1859-01-21	1940-12-10	\N	23	1	\N	\N	\N
724	Samuel James	Waring	1860-04-19	1940-01-09	\N	24	1	\N	\N	\N
725	Robert Hudson	Borwick	1845-01-21	1936-01-27	\N	3	1	\N	\N	\N
726	Charles Napier	Lawrence	1855-05-27	1927-12-17	\N	13	1	\N	\N	\N
727	Francis Bingham	Mildmay	1861-04-26	1947-02-08	\N	14	1	\N	\N	\N
728	Joseph Paton	Maclay	1857-09-06	1951-04-24	\N	14	1	\N	\N	\N
729	Edward Alfred	Goulding	1862-11-05	1936-07-17	\N	8	1	\N	\N	\N
730	John Henry	Bethell	1861-09-23	1945-05-27	\N	3	1	\N	\N	\N
731	Herbert Pike	Pease	1867-05-07	1949-05-10	\N	17	1	\N	\N	\N
732	Owen Cosby	Philipps	1863-03-25	1937-06-05	\N	17	1	\N	\N	\N
733	George	Younger	1851-10-13	1929-04-29	\N	26	1	\N	\N	\N
736	Robert	Younger	1861-09-12	1946-08-17	\N	26	1	\N	\N	\N
737	Edgar Algernon Robert	Gascoyne-Cecil	1864-09-14	1958-11-24	\N	8	1	\N	\N	\N
738	Charles John	Darling	1849-12-06	1936-05-29	\N	5	1	\N	\N	\N
739	James Lyle	Mackay	1852-09-11	1932-05-23	\N	14	1	\N	\N	\N
740	Frederick George	Banbury	1850-12-02	1936-08-13	\N	3	1	\N	\N	\N
741	John George	Butcher	1853-11-15	1935-06-30	\N	3	1	\N	\N	\N
742	John Denton Pinkstan	French	1852-09-28	1925-05-22	\N	7	1	\N	\N	\N
743	Sydney Haldane	Olivier	1859-04-16	1943-02-15	\N	16	1	\N	\N	\N
745	Sydney	Arnold	1878-01-13	1945-08-03	\N	2	1	\N	\N	\N
746	James	Stevenson	1873-04-02	1926-06-10	\N	20	1	\N	\N	\N
747	Henry Edward	Duke	1855-11-05	1939-05-20	\N	5	1	\N	\N	\N
748	John Swanwick	Bradbury	1872-09-23	1950-05-03	\N	3	1	\N	\N	\N
749	Geoffrey Henry	Browne	1861-01-06	1927-06-30	\N	3	1	\N	\N	\N
750	John Lawrence	Baird	1874-04-27	1941-08-20	\N	3	1	\N	\N	\N
751	George Ambrose	Lloyd	1879-09-19	1941-02-04	\N	13	1	\N	\N	\N
753	Ernest Murray	Pollock	1861-11-25	1936-10-22	\N	17	1	\N	\N	\N
754	Francis	Willey	1841-02-27	1929-02-16	\N	24	1	\N	\N	\N
755	Archibald	Williamson	1860-09-13	1931-10-29	\N	24	1	\N	\N	\N
756	Gordon	Hewart	1870-01-07	1943-05-05	\N	9	1	\N	\N	\N
758	Charles	Greenway	1857-06-13	1934-12-17	\N	8	1	\N	\N	\N
759	Thomas Rolls	Warrington	1851-05-29	1937-10-26	\N	24	1	\N	\N	\N
760	James	Craig	1871-01-08	1940-11-24	\N	4	1	\N	\N	\N
761	George Hayter	Chubb	1848-08-29	1946-11-07	\N	4	1	\N	\N	\N
762	Fiennes Stanley Wykeham	Cornwallis	1864-05-27	1935-09-26	\N	4	1	\N	\N	\N
763	Gilbert	Greenall	1867-03-30	1938-10-24	\N	8	1	\N	\N	\N
764	Davison Alexander	Dalziel	1852-10-17	1928-04-18	\N	5	1	\N	\N	\N
765	George Abraham	Gibbs	1873-07-06	1931-10-28	\N	8	1	\N	\N	\N
660	Marmaduke	Furness	1883-10-29	1940-10-06	\N	7	1	\N	\N	\N
2852	Roderick Francis Arthur	Balfour	1948-12-09	\N	\N	3	1	\N	\N	\N
2853	Sholto Douglas	Campbell	1839-06-28	1916-09-30	\N	4	1	\N	\N	\N
768	Frederick John Dealtry	Lugard	1858-01-22	1945-04-11	\N	13	1	\N	\N	\N
769	James Richard	Atkin	1867-11-28	1944-06-25	\N	2	1	\N	\N	\N
770	Alfred Moritz	Mond	1868-10-23	1930-12-27	\N	14	1	\N	\N	\N
771	Douglas McGarel	Hogg	1872-02-28	1950-08-16	\N	9	1	\N	\N	\N
773	James Farquharson	Remnant	1862-02-13	1933-01-30	\N	19	1	\N	\N	\N
774	George Rowland	Blades	1868-04-15	1953-05-24	\N	3	1	\N	\N	\N
775	Jesse	Boot	1850-06-02	1931-06-13	\N	3	1	\N	\N	\N
776	Randall Thomas	Davidson	1848-04-07	1930-05-25	\N	5	1	\N	\N	\N
778	Berkeley George Andrew	Moynihan	1865-10-02	1936-09-07	\N	14	1	\N	\N	\N
779	Urban Huttleston Rogers	Broughton	1896-08-31	1966-08-20	\N	3	1	\N	\N	\N
780	Edward Allen	Brotherton	1856-04-01	1930-10-21	\N	3	1	\N	\N	\N
781	William	Watson	1873-12-08	1948-06-13	\N	24	1	\N	\N	\N
783	Herbert Henry	Asquith	1852-09-12	1928-02-15	\N	2	1	\N	\N	\N
784	Thomas, L	Shaw	1850-05-23	1937-06-28	\N	20	1	\N	\N	\N
785	William Clive	Bridgeman	1864-12-31	1935-08-14	\N	3	1	\N	\N	\N
786	Robert Arthur	Sanders	1867-06-20	1940-02-24	\N	20	1	\N	\N	\N
787	William Ewert	Berry	1879-06-23	1954-06-15	\N	3	1	\N	\N	\N
788	John	Sankey	1866-10-26	1948-02-06	\N	20	1	\N	\N	\N
789	Sidney James	Webb	1859-07-13	1947-10-13	\N	24	1	\N	\N	\N
790	William	Joynson-Hicks	1865-06-23	1932-06-08	\N	11	1	\N	\N	\N
791	Gilbert Alan Hamilton	Wills	1880-03-28	1956-12-01	\N	24	1	\N	\N	\N
792	George	Lawson-Johnston	1873-09-09	1943-02-23	\N	13	1	\N	\N	\N
794	Henry Seymour	Berry	1877-09-17	1928-05-23	\N	3	1	\N	\N	\N
795	Dudley Leigh	Aman	1884-05-16	1952-02-29	\N	2	1	\N	\N	\N
796	Arthur Augustus William Harry	Ponsonby	1871-02-16	1946-03-24	\N	17	1	\N	\N	\N
797	Robert Stephenson Smyth	Baden-Powell	1857-02-22	1941-01-08	\N	3	1	\N	\N	\N
798	Willoughby Hyett	Dickinson	1859-04-09	1943-05-31	\N	5	1	\N	\N	\N
799	Charles Cheers	Wakefield	1859-12-12	1941-01-15	\N	24	1	\N	\N	\N
800	William Joseph	Noble	1863-01-13	1935-09-11	\N	15	1	\N	\N	\N
801	Hugh Montague	Trenchard	1873-02-03	1956-02-10	\N	21	1	\N	\N	\N
802	Noel Edward	Buxton	1869-01-09	1948-09-12	\N	3	1	\N	\N	\N
805	Esme William	Howard	1863-09-15	1939-08-01	\N	9	1	\N	\N	\N
806	William	Plender	1861-08-20	1946-01-19	\N	17	1	\N	\N	\N
807	John Scott	Hindley	1883-10-24	1963-01-05	\N	9	1	\N	\N	\N
808	Ernest	Rutherford	1871-08-30	1937-10-19	\N	19	1	\N	\N	\N
809	Ernest Henry	Lamb	1876-09-04	1955-01-13	\N	13	1	\N	\N	\N
810	Philip	Snowden	1864-07-18	1937-05-15	\N	20	1	\N	\N	\N
812	Henry	Snell	1865-04-01	1944-04-21	\N	20	1	\N	\N	\N
813	William Martin	Conway	1856-04-12	1937-04-19	\N	4	1	\N	\N	\N
814	Wilfrid William	Ashley	1867-09-13	1939-07-03	\N	2	1	\N	\N	\N
815	William Lowson	Mitchell-Thomson	1877-04-15	1938-12-24	\N	14	1	\N	\N	\N
816	Reginald Clifford	Allen	1889-05-09	1939-03-03	\N	2	1	\N	\N	\N
817	Walter Edward	Guinness	1880-03-29	1944-11-06	\N	8	1	\N	\N	\N
818	Leifchild Stratten	Jones	1862-01-16	1939-09-26	\N	11	1	\N	\N	\N
819	Freeman	Freeman-Thomas	1866-09-12	1941-08-12	\N	7	1	\N	\N	\N
820	Arthur Charles	Churchman	1867-09-07	1949-02-03	\N	4	1	\N	\N	\N
821	Frederick William	Lewis	1870-05-25	1944-06-24	\N	13	1	\N	\N	\N
822	Robert Alderson	Wright	1869-10-15	1964-06-27	\N	24	1	\N	\N	\N
823	David	Davies	1880-05-11	1944-06-16	\N	5	1	\N	\N	\N
825	Robert	Hutchison	1873-09-05	1950-06-13	\N	9	1	\N	\N	\N
826	Charles Alexander	Nall-Cain	1866-05-29	1934-11-21	\N	15	1	\N	\N	\N
827	Thomas Jeeves	Horder	1871-01-07	1955-08-13	\N	9	1	\N	\N	\N
828	George Francis	Milne	1866-11-05	1948-03-23	\N	14	1	\N	\N	\N
829	Joseph	Duveen	1869-10-14	1939-05-25	\N	5	1	\N	\N	\N
830	George Croydon	Marks	1858-06-09	1938-09-24	\N	14	1	\N	\N	\N
832	William George	Tyrrell	1866-08-17	1947-03-14	\N	21	1	\N	\N	\N
833	Samuel Ernest	Palmer	1858-03-28	1948-12-08	\N	17	1	\N	\N	\N
834	George Richard	Lane-Fox	1870-12-15	1947-12-11	\N	13	1	\N	\N	\N
835	Evelyn	Cecil	1865-05-30	1941-04-01	\N	4	1	\N	\N	\N
837	George Douglas Cochrane	Newton	1879-07-14	1942-09-02	\N	15	1	\N	\N	\N
838	Godfrey	Elton	1892-03-29	1973-04-18	\N	6	1	\N	\N	\N
839	Robert	Munro	1868-05-28	1955-10-06	\N	14	1	\N	\N	\N
840	Hugo	Hirst	1863-11-26	1943-01-22	\N	9	1	\N	\N	\N
841	Gerald Walter Erskine	Loder	1861-10-25	1936-04-30	\N	13	1	\N	\N	\N
842	Henry Bucknall	Betterton	1872-08-15	1949-11-18	\N	3	1	\N	\N	\N
843	Thomas	Fermor-Hesketh	1881-11-17	1944-07-20	\N	7	1	\N	\N	\N
844	Wyndham Raymond	Portal	1885-04-09	1949-05-06	\N	17	1	\N	\N	\N
845	John	Buchan	1875-08-26	1940-02-11	\N	3	1	\N	\N	\N
847	Clive	Wigram	1873-07-05	1960-09-03	\N	24	1	\N	\N	\N
848	Arthur	Balfour	1873-01-09	1957-07-07	\N	3	1	\N	\N	\N
849	George Ernest	May	1871-06-20	1946-04-10	\N	14	1	\N	\N	\N
850	Edward Charles	Grenfell	1870-05-29	1941-11-26	\N	8	1	\N	\N	\N
851	James Ian	Macpherson	1880-05-14	1937-08-14	\N	14	1	\N	\N	\N
853	Frederic Herbert	Maugham	1866-10-21	1958-03-23	\N	14	1	\N	\N	\N
854	Alexander Adair	Roche	1871-07-24	1956-12-22	\N	19	1	\N	\N	\N
855	Philip	Cunliffe-Lister	1884-05-01	1972-07-27	\N	4	1	\N	\N	\N
856	Bolton Meredith	Eyres-Monsell	1881-02-22	1969-03-21	\N	6	1	\N	\N	\N
858	Arthur Shirley	Benn	1858-12-20	1937-06-13	\N	3	1	\N	\N	\N
859	James Gomer	Berry	1883-05-07	1968-02-06	\N	3	1	\N	\N	\N
860	Thomas Sivewright	Catto	1879-03-15	1959-08-23	\N	4	1	\N	\N	\N
861	Henry Strother	Cautley	1863-12-09	1946-09-21	\N	4	1	\N	\N	\N
862	William Malcolm	Hailey	1872-02-15	1969-06-01	\N	9	1	\N	\N	\N
863	Herbert	Austin	1866-11-08	1941-05-23	\N	2	1	\N	\N	\N
864	James Rennell	Rodd	1858-11-09	1941-07-26	\N	19	1	\N	\N	\N
865	John Edward Bernard	Seely	1868-05-31	1947-11-07	\N	20	1	\N	\N	\N
866	Edward Mauger	Iliffe	1877-05-17	1960-07-25	\N	10	1	\N	\N	\N
867	Harry Duncan	McGowan	1874-06-03	1961-07-13	\N	14	1	\N	\N	\N
868	Christopher	Addison	1869-06-19	1951-12-11	\N	2	1	\N	\N	\N
870	Walter Russell	Rea	1873-05-18	1948-05-26	\N	19	1	\N	\N	\N
872	John	Cadman	1877-09-07	1941-05-31	\N	4	1	\N	\N	\N
767	Gerald	Strickland	1861-05-24	1940-08-22	\N	20	1	\N	\N	\N
2854	Barrington Bulkeley Douglas	Campbell	1845-02-18	1918-03-13	\N	4	1	\N	\N	\N
877	Walter	Runciman	1870-11-19	1949-11-14	\N	19	1	\N	\N	\N
878	John Davenport	Siddeley	1866-08-05	1953-11-03	\N	20	1	\N	\N	\N
879	John Colin Campbell	Davidson	1889-02-23	1970-12-11	\N	5	1	\N	\N	\N
880	Julius Salter	Elias	1873-01-05	1946-04-10	\N	6	1	\N	\N	\N
881	John Cuthbert	Denison-Pender	1882-05-11	1949-12-04	\N	5	1	\N	\N	\N
882	William Richard	Morris	1877-10-10	1963-08-22	\N	14	1	\N	\N	\N
883	Mark Lemon	Romer	1866-08-09	1944-08-19	\N	19	1	\N	\N	\N
884	Henry Yarde Buller	Lopes	1859-03-24	1938-04-14	\N	13	1	\N	\N	\N
886	Percy Herbert	Mills	1890-01-04	1968-09-10	\N	14	1	\N	\N	\N
887	Henry Leonard Campbell	Brassey	1870-03-07	1958-10-22	\N	3	1	\N	\N	\N
888	Percival Lea Dewhurst	Perry	1878-03-18	1956-06-17	\N	17	1	\N	\N	\N
889	Samuel Lowry	Porter	1877-02-07	1956-02-13	\N	17	1	\N	\N	\N
890	Josiah Charles	Stamp	1880-06-21	1941-04-16	\N	20	1	\N	\N	\N
891	Vivian Hugh	Smith	1867-12-09	1956-02-17	\N	20	1	\N	\N	\N
892	Claude George	Bowes-Lyon	1855-03-14	1944-11-07	\N	3	1	\N	\N	\N
893	Frederick Arthur	Greer	1863-10-01	1945-02-04	\N	8	1	\N	\N	\N
896	Cecil Bisshopp	Harmsworth	1869-09-28	1948-08-13	\N	9	1	\N	\N	\N
897	Arthur Richard de Capell	Brooke	1869-10-12	1944-11-17	\N	3	1	\N	\N	\N
898	Herbert Robin	Cayzer	1881-07-23	1958-03-17	\N	4	1	\N	\N	\N
899	Hamar	Greenwood	1870-02-07	1948-09-10	\N	8	1	\N	\N	\N
900	Arthur Michael	Samuel	1872-12-06	1942-08-17	\N	20	1	\N	\N	\N
901	Thomas Walker Hobart	Inskip	1876-03-05	1947-10-11	\N	10	1	\N	\N	\N
902	George Clement	Tryon	1871-05-15	1940-11-24	\N	21	1	\N	\N	\N
903	John Allsebrook	Simon	1873-02-28	1954-01-11	\N	20	1	\N	\N	\N
904	Henry Page	Croft	1881-06-22	1947-12-07	\N	4	1	\N	\N	\N
905	Charles Iain	Kerr	1874-05-03	1968-01-07	\N	12	1	\N	\N	\N
907	Hugh Richard Heathcote	Gascoyne-Cecil	1869-10-14	1956-12-10	\N	8	1	\N	\N	\N
908	Frank Boyd	Merriman	1880-04-28	1962-01-18	\N	14	1	\N	\N	\N
909	Robert Molesworth	Kindersley	1871-11-21	1954-07-20	\N	12	1	\N	\N	\N
910	William Edmund	Ironside	1880-05-06	1959-09-22	\N	10	1	\N	\N	\N
911	Robert Gilbert	Vansittart	1881-06-25	1957-02-14	\N	23	1	\N	\N	\N
912	Frederick James	Leathers	1883-11-21	1965-03-18	\N	13	1	\N	\N	\N
913	Richard Bedford	Bennett	1870-07-03	1947-06-27	\N	3	1	\N	\N	\N
914	Wilfred Arthur	Greene	1883-12-30	1952-04-16	\N	8	1	\N	\N	\N
915	William Wedgwood	Benn	1877-05-10	1960-11-17	\N	3	1	\N	\N	\N
917	Herwald	Ramsbotham	1887-03-06	1971-01-31	\N	19	1	\N	\N	\N
919	Josiah Clement	Wedgwood	1872-03-16	1943-07-26	\N	24	1	\N	\N	\N
920	Auckland Campbell	Geddes	1879-06-21	1954-01-08	\N	8	1	\N	\N	\N
921	Reginald Thomas Herbert	Fletcher	1885-03-27	1961-06-07	\N	7	1	\N	\N	\N
922	Albert Charles	Clauson	1870-01-14	1946-03-15	\N	4	1	\N	\N	\N
923	John Maynard	Keynes	1883-06-05	1946-04-21	\N	12	1	\N	\N	\N
925	Cosmo Gordon	Lang	1864-10-31	1945-12-05	\N	13	1	\N	\N	\N
926	Henry David	Margesson	1890-07-26	1965-12-24	\N	14	1	\N	\N	\N
927	John Theodore Cuthbert	Moore-Brabazon	1884-02-08	1964-05-17	\N	14	1	\N	\N	\N
928	Charles McMoran	Wilson	1882-11-10	1977-04-12	\N	24	1	\N	\N	\N
929	Miles Wedderburn	Lampson	1880-08-24	1964-09-18	\N	13	1	\N	\N	\N
930	Dennis Henry	Herbert	1869-02-25	1947-12-10	\N	9	1	\N	\N	\N
931	Hugh Caswall Tremenheere	Dowding	1882-04-24	1970-02-15	\N	5	1	\N	\N	\N
932	Muriel	FitzRoy	1869-08-08	1962-07-08	\N	7	2	\N	\N	\N
933	John	Gretton	1867-09-01	1947-06-02	\N	8	1	\N	\N	\N
935	Archibald Percival	Wavell	1883-05-05	1950-05-24	\N	24	1	\N	\N	\N
936	Herbert	Dixon	1880-01-23	1950-07-20	\N	5	1	\N	\N	\N
937	Charles Coupar	Barrie	\N	1940-12-06	\N	3	1	\N	\N	\N
938	Claud	Schuster	1869-08-22	1956-06-28	\N	20	1	\N	\N	\N
939	Gavin Turnbull	Simonds	1881-11-28	1971-06-28	\N	20	1	\N	\N	\N
940	Samuel John Gurney	Hoare	1880-02-24	1959-05-07	\N	9	1	\N	\N	\N
941	Rayner	Goddard	1877-04-10	1971-05-29	\N	8	1	\N	\N	\N
943	David	Lloyd-George	1863-01-17	1945-03-26	\N	13	1	\N	\N	\N
944	Arthur Grey	Hazlerigg	1878-11-17	1949-05-25	\N	9	1	\N	\N	\N
945	Douglas Hewitt	Hacking	1884-08-04	1950-07-29	\N	9	1	\N	\N	\N
946	George Loyd	Courthope	1877-06-12	1955-09-02	\N	4	1	\N	\N	\N
948	William Frederick	Jackson	1893-11-29	1954-05-02	\N	11	1	\N	\N	\N
949	David John Kinsley	Quibell	1879-12-21	1962-04-16	\N	18	1	\N	\N	\N
950	Alexander George	Walkden	1873-05-11	1951-04-25	\N	24	1	\N	\N	\N
952	William	Cope	1870-08-18	1946-07-15	\N	4	1	\N	\N	\N
953	Eugene Joseph Squire Hargreaves	Ramsden	1883-02-02	1955-08-09	\N	19	1	\N	\N	\N
954	William	Brass	1886-02-11	1945-08-24	\N	3	1	\N	\N	\N
955	Albert James	Edmondson	1886-06-29	1959-05-16	\N	6	1	\N	\N	\N
956	George	Lambert	1866-06-25	1958-02-17	\N	13	1	\N	\N	\N
957	Edward William Macleay	Grigg	1879-09-08	1955-12-01	\N	8	1	\N	\N	\N
958	William Allen	Jowitt	1885-04-15	1957-08-16	\N	11	1	\N	\N	\N
959	Frederick William	Pethick-Lawrence	1871-12-28	1961-09-17	\N	17	1	\N	\N	\N
960	John Jestyn	Llewellin	1893-02-06	1957-01-24	\N	13	1	\N	\N	\N
961	Charles Ernest Leonard	Lyle	1882-07-22	1954-03-06	\N	13	1	\N	\N	\N
962	George Thomas	Broadbridge	1869-02-13	1952-04-17	\N	3	1	\N	\N	\N
964	William Henry	Davison	\N	1953-01-19	\N	5	1	\N	\N	\N
965	William	Westwood	1880-08-28	1953-09-13	\N	24	1	\N	\N	\N
966	Francis Aungier	Pakenham	1905-12-05	2001-08-03	\N	17	1	\N	\N	\N
967	William Watson	Henderson	1891-08-08	1984-04-04	\N	9	1	\N	\N	\N
968	Charles George	Ammon	1873-04-22	1960-04-02	\N	2	1	\N	\N	\N
970	Robert Craigmyle	Morrison	1881-10-29	1953-12-25	\N	14	1	\N	\N	\N
972	George	Muff	1877-02-10	1955-09-20	\N	14	1	\N	\N	\N
973	Robert Alexander	Palmer	1890-11-29	1977-08-18	\N	17	1	\N	\N	\N
974	Andrew Browne	Cunningham	1883-01-07	1963-06-12	\N	4	1	\N	\N	\N
975	Charles Frederick Algernon	Portal	1893-05-21	1971-04-22	\N	17	1	\N	\N	\N
976	Colin Frederick	Campbell	1866-06-13	1954-11-03	\N	4	1	\N	\N	\N
977	Philip Albert	Inman	1892-06-12	1979-08-26	\N	10	1	\N	\N	\N
978	Bernard Law	Montgomery	1887-11-17	1976-03-24	\N	14	1	\N	\N	\N
979	John Cronyn	Tovey	1885-03-07	1971-01-12	\N	21	1	\N	\N	\N
980	Herbert	du Parcq	1880-08-05	1949-04-27	\N	5	1	\N	\N	\N
2855	Archibald	Campbell	1870-04-25	1929-11-14	\N	4	1	\N	\N	\N
984	Henry Maitland	Wilson	1881-09-05	1964-12-31	\N	24	1	\N	\N	\N
985	William Henry	Beveridge	1879-03-05	1963-03-16	\N	3	1	\N	\N	\N
986	Archibald John Kerr	Clark Kerr	1882-03-17	1951-07-05	\N	4	1	\N	\N	\N
987	Ambrose Edgar	Woodall	1885-04-24	1974-02-28	\N	24	1	\N	\N	\N
988	George William	Lucas	1896-03-29	1967-10-11	\N	13	1	\N	\N	\N
990	Robert Henry	Brand	1878-10-30	1963-08-23	\N	3	1	\N	\N	\N
991	Cyril Louis Norton	Newall	1886-02-15	1963-11-30	\N	15	1	\N	\N	\N
992	Bruce Austin	Fraser	1888-02-05	1981-02-12	\N	7	1	\N	\N	\N
993	Geoffrey	Lawrence	1880-12-02	1971-08-28	\N	13	1	\N	\N	\N
994	George Henry	Hall	1881-12-31	1965-11-08	\N	9	1	\N	\N	\N
995	Wilfrid Guild	Normand	1884-05-06	1962-10-05	\N	15	1	\N	\N	\N
996	Hastings Lionel	Ismay	1887-06-21	1965-12-17	\N	10	1	\N	\N	\N
997	John Loader	Maffey	1877-07-01	1969-04-20	\N	14	1	\N	\N	\N
998	Walter Thomas	Layton	1884-03-15	1966-02-14	\N	13	1	\N	\N	\N
999	Ernest Darwin	Simon	1879-10-09	1960-10-03	\N	20	1	\N	\N	\N
1000	Fred	Kershaw	1881-11-06	1961-02-05	\N	12	1	\N	\N	\N
1001	George Morgan	Garro-Jones	1894-09-14	1960-09-27	\N	8	1	\N	\N	\N
1003	Alexander Dunlop	Lindsay	1879-05-14	1952-03-18	\N	13	1	\N	\N	\N
1004	Arthur William	Tedder	1890-07-11	1967-06-03	\N	21	1	\N	\N	\N
1005	William	Piercy	1886-02-07	1966-07-07	\N	17	1	\N	\N	\N
1006	Roy Lister	Robinson	1883-03-08	1952-09-05	\N	19	1	\N	\N	\N
1008	Arthur Frederick	Richards	1885-02-21	1978-10-27	\N	19	1	\N	\N	\N
1010	Harold Vincent	Mackintosh	1891-06-08	1964-12-27	\N	14	1	\N	\N	\N
1011	William Sholto	Douglas	1893-12-23	1969-10-30	\N	5	1	\N	\N	\N
1012	Valentine George	Crittall	1884-06-28	1961-05-21	\N	4	1	\N	\N	\N
1013	Alfred Edward	Webb-Johnson	1880-09-04	1958-05-28	\N	24	1	\N	\N	\N
1014	William Francis Kyffin	Taylor	1854-07-09	1951-09-22	\N	21	1	\N	\N	\N
1015	Thomas Edward	Williams	1892-07-26	1966-02-18	\N	24	1	\N	\N	\N
1016	John Jackson	Adams	1890-10-12	1960-08-23	\N	2	1	\N	\N	\N
1017	James Scott Cumberland	Reid	1890-07-30	1975-03-29	\N	19	1	\N	\N	\N
1018	John	Boyd-Orr	1880-09-23	1971-06-25	\N	3	1	\N	\N	\N
1019	Henry John Fanshawe	Badeley	1874-06-27	1951-09-27	\N	3	1	\N	\N	\N
1020	Gordon	Macdonald	1888-05-27	1966-01-20	\N	14	1	\N	\N	\N
1021	Winston Joseph	Dugan	1877-05-08	1951-08-17	\N	5	1	\N	\N	\N
1022	George	Archibald	1898-07-21	1975-02-25	\N	2	1	\N	\N	\N
1023	John	Wilmot	1895-04-02	1964-07-22	\N	24	1	\N	\N	\N
1024	Alexander Steven	Bilsland	1892-09-13	1970-12-10	\N	3	1	\N	\N	\N
1025	Thomas William	Burden	1885-01-29	1970-05-27	\N	3	1	\N	\N	\N
1027	Joseph	Henderson	\N	1950-02-26	\N	9	1	\N	\N	\N
1029	John James	Lawson	1881-10-16	1965-08-03	\N	13	1	\N	\N	\N
1030	Francis Campbell Ross	Douglas	1889-10-21	1980-03-31	\N	5	1	\N	\N	\N
1031	Cyril William	Hurcomb	1883-02-18	1975-08-07	\N	9	1	\N	\N	\N
1032	Gilbert Francis Montriou	Campion	1882-05-11	1958-04-06	\N	4	1	\N	\N	\N
1033	Ernest Walter	Hives	1886-04-21	1965-04-24	\N	9	1	\N	\N	\N
1034	Ernest	Greenhill	1887-04-23	1967-02-18	\N	8	1	\N	\N	\N
1035	David Rees	Rees-Williams	1903-11-22	1976-08-30	\N	19	1	\N	\N	\N
1036	Harry	Morris	1893-10-07	1954-07-01	\N	14	1	\N	\N	\N
1038	Frederick James	Tucker	1888-05-22	1975-11-17	\N	21	1	\N	\N	\N
1039	Archibald	Crawford	1890-09-12	1966-06-14	\N	4	1	\N	\N	\N
1040	Philip	Mountbatten	1921-06-10	2021-04-09	\N	14	1	\N	\N	\N
1041	Cyril	Asquith	1890-02-05	1954-08-24	\N	2	1	\N	\N	\N
1043	Reginald Douglas	Crook	1901-03-02	1989-03-10	\N	4	1	\N	\N	\N
1044	Lionel Leonard	Cohen	1888-03-01	1973-05-09	\N	4	1	\N	\N	\N
1045	Douglas Clifton	Brown	1879-08-16	1958-05-05	\N	3	1	\N	\N	\N
1046	David	Kirkwood	1872-07-08	1955-04-16	\N	12	1	\N	\N	\N
1048	Robert Spear	Hudson	1886-08-15	1957-02-02	\N	9	1	\N	\N	\N
1049	John	Anderson	1882-07-08	1958-01-04	\N	2	1	\N	\N	\N
1050	George	Mathers	1886-02-28	1965-09-26	\N	14	1	\N	\N	\N
1051	Edward	Turnour	1883-04-04	1962-08-26	\N	21	1	\N	\N	\N
1052	Archibald Henry Macdonald	Sinclair	1890-10-22	1970-06-15	\N	20	1	\N	\N	\N
1053	Basil Stanlake	Brooke	1888-06-09	1973-08-18	\N	3	1	\N	\N	\N
1054	Alfred Duff	Cooper	1890-02-22	1954-01-01	\N	4	1	\N	\N	\N
1055	George Darell	Jeffreys	1878-03-08	1960-12-19	\N	11	1	\N	\N	\N
1056	Robert William Hugh	O'Neill	1883-06-08	1982-11-28	\N	16	1	\N	\N	\N
1058	Ralph George Campbell	Glyn	1885-03-03	1960-05-01	\N	8	1	\N	\N	\N
1060	Peter Frederick Blaker	Bennett	1880-04-16	1957-09-29	\N	3	1	\N	\N	\N
1061	Leslie	Hore-Belisha	1893-09-07	1957-02-16	\N	9	1	\N	\N	\N
1062	William	Strang	1893-01-02	1978-05-27	\N	20	1	\N	\N	\N
1063	James Arthur	Salter	1881-03-15	1975-06-27	\N	20	1	\N	\N	\N
1064	James	Keith	1886-05-20	1964-06-29	\N	12	1	\N	\N	\N
1065	Joseph Stanley	Holmes	1878-10-31	1961-04-22	\N	9	1	\N	\N	\N
1066	Henry Charles Ponsonby	Moore	1884-04-21	1957-11-22	\N	14	1	\N	\N	\N
1067	Richard Kidston	Law	1901-02-27	1980-11-15	\N	13	1	\N	\N	\N
1068	Oliver Charles	Harvey	1893-11-26	1968-11-29	\N	9	1	\N	\N	\N
1069	Thomas Mackay	Cooper	1892-09-24	1955-07-15	\N	4	1	\N	\N	\N
1070	Ernest Albert	Whitfield	1887-09-15	1963-04-21	\N	24	1	\N	\N	\N
1071	Bernard	Freyberg	1889-03-21	1963-07-04	\N	7	1	\N	\N	\N
1073	David Patrick Maxwell	Fyfe	1900-05-29	1967-01-27	\N	7	1	\N	\N	\N
1074	James	Milner	1889-08-12	1967-06-16	\N	14	1	\N	\N	\N
1075	Godfrey Martin	Huggins	1883-07-06	1971-05-08	\N	9	1	\N	\N	\N
1076	Thomas Dunlop	Galbraith	1891-03-20	1985-07-12	\N	8	1	\N	\N	\N
1077	Henry George	Strauss	1892-06-24	1974-08-28	\N	20	1	\N	\N	\N
1078	Geoffrey	Heyworth	1894-10-18	1974-06-15	\N	9	1	\N	\N	\N
1080	Francis Raymond	Evershed	1899-08-08	1966-10-03	\N	6	1	\N	\N	\N
1082	William Philip	Sidney	1909-05-23	1991-04-05	\N	20	1	\N	\N	\N
1083	Harry Frederick Comfort	Crookshank	1893-05-27	1961-10-17	\N	4	1	\N	\N	\N
1084	Osbert	Peake	1897-12-30	1966-10-11	\N	17	1	\N	\N	\N
1085	James Purdon Lewes	Thomas	1903-10-13	1960-07-13	\N	21	1	\N	\N	\N
1086	Henry Lennox d'Aubigné	Hopkinson	1902-01-03	1996-01-06	\N	9	1	\N	\N	\N
1087	John Jacob	Astor	1886-05-20	1971-07-19	\N	2	1	\N	\N	\N
982	John Percival	Davies	1885-03-28	1950-12-26	\N	5	1	\N	\N	\N
2856	Barrington Sholto	Campbell	1877-07-15	1937-03-03	\N	4	1	\N	\N	\N
1090	Ronald Morce	Weeks	1890-11-13	1960-08-19	\N	24	1	\N	\N	\N
1091	Henry	Cohen	1900-02-21	1977-08-07	\N	4	1	\N	\N	\N
1093	Horace	Evans	1903-01-01	1963-10-26	\N	6	1	\N	\N	\N
1094	Walter Turner	Monckton	1891-01-17	1965-01-09	\N	14	1	\N	\N	\N
1095	Gwilym	Lloyd-George	1894-12-04	1967-02-14	\N	13	1	\N	\N	\N
1097	Alfred Thompson	Denning	1899-01-23	1999-03-05	\N	5	1	\N	\N	\N
1098	Joseph Arthur	Rank	1888-12-22	1972-03-29	\N	19	1	\N	\N	\N
1099	William Norman	Birkett	1883-09-06	1962-02-10	\N	3	1	\N	\N	\N
1100	David Vivian Penrose	Lewis	1905-08-14	1976-10-10	\N	13	1	\N	\N	\N
1101	Allan Francis	Harding	1896-02-10	1989-01-20	\N	9	1	\N	\N	\N
1102	Thomas Ellis	Robins	1884-10-31	1962-07-21	\N	19	1	\N	\N	\N
1104	William Jocelyn Ian	Fraser	1897-08-30	1974-12-19	\N	7	1	\N	\N	\N
1105	Victor John	Collins	1903-07-01	1971-12-22	\N	4	1	\N	\N	\N
1106	Charles John	Geddes	1897-03-01	1983-05-02	\N	8	1	\N	\N	\N
1107	John Sebastian Bach	Stopford	1888-06-25	1961-03-06	\N	20	1	\N	\N	\N
1108	Daniel Granville	West	1904-03-17	1984-09-23	\N	24	1	\N	\N	\N
1109	Stephen James Lake	Taylor	1910-12-30	1988-02-01	\N	21	1	\N	\N	\N
1110	Edgar Douglas	Adrian	1889-11-30	1977-08-04	\N	2	1	\N	\N	\N
1112	William	Fraser	1888-11-03	1970-04-01	\N	7	1	\N	\N	\N
1113	Ralph	Assheton	1901-02-24	1984-09-20	\N	2	1	\N	\N	\N
1114	Stella	Isaacs	1894-01-06	1971-05-22	\N	10	2	\N	\N	\N
1115	Victor Ferrier	Noel-Paton	1900-01-29	1992-06-04	\N	15	1	\N	\N	\N
1116	Katharine	Elliot	1903-01-15	1994-01-03	\N	6	2	\N	\N	\N
1118	Hubert Lister	Parker	1900-05-28	1972-09-15	\N	17	1	\N	\N	\N
1119	William Hartley	Shawcross	1902-02-04	2003-07-10	\N	20	1	\N	\N	\N
1120	William Edward	Rootes	1894-08-17	1964-12-12	\N	19	1	\N	\N	\N
1121	Edwin Noel	Plowden	1907-01-06	2001-02-15	\N	17	1	\N	\N	\N
1122	Eric John Francis	James	1909-04-13	1992-05-16	\N	11	1	\N	\N	\N
1123	James	Turner	1908-01-06	1980-11-08	\N	21	1	\N	\N	\N
1124	Lionel Charles	Robbins	1898-11-22	1984-05-15	\N	19	1	\N	\N	\N
1126	Thomas Lionel	Dugdale	1897-07-20	1977-03-26	\N	5	1	\N	\N	\N
1127	John	Forster	1888-09-15	1972-07-24	\N	7	1	\N	\N	\N
1128	William Patrick	Spens	1885-08-09	1973-11-15	\N	20	1	\N	\N	\N
1129	Herbert Stanley	Morrison	1888-01-03	1965-03-06	\N	14	1	\N	\N	\N
1130	James Gray	Stuart	1897-02-09	1971-02-20	\N	20	1	\N	\N	\N
1131	Jack Nixon	Browne	1904-09-03	1993-07-28	\N	3	1	\N	\N	\N
1132	Charles Glen	MacAndrew	1888-01-13	1979-11-11	\N	14	1	\N	\N	\N
1133	Florence Gertrude	Horsbrugh	1889-10-13	1969-12-06	\N	9	2	\N	\N	\N
1134	John Durival	Kemp	1906-06-05	1993-05-24	\N	12	1	\N	\N	\N
1135	George Horatio	Nelson	1887-10-26	1962-07-16	\N	15	1	\N	\N	\N
1137	Alfred Charles	Bossom	1881-10-16	1965-09-04	\N	3	1	\N	\N	\N
1138	Evelyn	Baring	1903-09-29	1973-03-10	\N	3	1	\N	\N	\N
1140	Hubert Miles Gladwyn	Jebb	1900-04-25	1996-10-24	\N	11	1	\N	\N	\N
1141	William Joseph	Slim	1891-08-06	1970-12-14	\N	20	1	\N	\N	\N
1142	Edward Arthur Alexander	Shackleton	1911-07-15	1994-09-22	\N	20	1	\N	\N	\N
1143	Antony Henry	Head	1906-12-19	1983-03-29	\N	9	1	\N	\N	\N
1144	Terence Edmund Gascoigne	Nugent	1895-08-11	1973-04-27	\N	15	1	\N	\N	\N
1145	Derick Heathcoat	Amory	1899-12-26	1981-01-19	\N	2	1	\N	\N	\N
1147	Francis Lord Charlton	Hodson	1895-09-17	1984-03-11	\N	9	1	\N	\N	\N
1148	George Reginald	Ward	1907-11-20	1988-06-15	\N	24	1	\N	\N	\N
1149	Cameron Fromanteel	Cobbold	1904-09-14	1987-11-01	\N	4	1	\N	\N	\N
1150	Christopher William Graham	Guest	1901-11-07	1984-09-25	\N	8	1	\N	\N	\N
1151	Edward Francis	Twining	1899-06-24	1967-07-21	\N	21	1	\N	\N	\N
1152	Robert John Graham	Boothby	1900-02-12	1986-07-16	\N	3	1	\N	\N	\N
1153	James Mortimer	Peddie	1905-04-04	1978-04-13	\N	17	1	\N	\N	\N
1154	George Samuel	Lindgren	1900-11-11	1971-09-08	\N	13	1	\N	\N	\N
1156	Arthur Hugh Elsdale	Molson	1903-06-29	1991-10-13	\N	14	1	\N	\N	\N
1157	Cuthbert James McCall	Alport	1912-03-22	1998-10-28	\N	2	1	\N	\N	\N
1158	Alfred	Robens	1910-12-18	1999-06-27	\N	19	1	\N	\N	\N
1160	Brian Hubert	Robertson	1896-07-22	1974-04-29	\N	19	1	\N	\N	\N
1161	Simon	Marks	1888-07-09	1964-12-08	\N	14	1	\N	\N	\N
1162	George Leighton	Seager	1896-01-11	1963-10-17	\N	20	1	\N	\N	\N
1163	Patrick Arthur	Devlin	1905-11-25	1992-08-09	\N	5	1	\N	\N	\N
1164	Walter Russell	Brain	1895-10-23	1966-12-29	\N	3	1	\N	\N	\N
1165	Leonard Percy	Lord	1896-11-15	1967-09-13	\N	13	1	\N	\N	\N
1166	Frederick Robert Hoyer	Millar	1900-06-06	1989-10-16	\N	14	1	\N	\N	\N
1167	Elaine Frances	Burton	1904-03-02	1991-10-06	\N	3	2	\N	\N	\N
1168	Edward Francis	Williams	1903-03-10	1970-06-05	\N	24	1	\N	\N	\N
1169	Alexander Robertus	Todd	1907-10-02	1997-01-10	\N	21	1	\N	\N	\N
1170	Alan John	Sainsbury	1902-08-13	1998-10-21	\N	20	1	\N	\N	\N
1172	Oliver Shewell	Franks	1905-02-16	1992-10-15	\N	7	1	\N	\N	\N
1173	Arthur Joseph	Champion	1897-07-26	1985-03-02	\N	4	1	\N	\N	\N
1174	Geoffrey Clegg	Hutchinson	1893-10-14	1974-08-20	\N	9	1	\N	\N	\N
1175	Thomas	Williamson	1897-09-02	1983-02-27	\N	24	1	\N	\N	\N
1176	William	Mabane	1895-01-12	1969-11-16	\N	14	1	\N	\N	\N
1177	Cyril John	Radcliffe	1899-03-30	1977-04-01	\N	19	1	\N	\N	\N
1180	David McAdam	Eccles	1904-09-18	1999-02-24	\N	6	1	\N	\N	\N
1181	Norman Craven	Brook	1902-04-29	1967-06-15	\N	3	1	\N	\N	\N
1182	Albert Victor	Alexander	1885-05-01	1965-01-11	\N	2	1	\N	\N	\N
1183	Eric Cyril Boyd	Edwards	1914-10-09	1997-03-03	\N	6	1	\N	\N	\N
1184	Charles	Hill	1904-01-15	1989-08-22	\N	9	1	\N	\N	\N
1185	Alick Drummond	Buchanan-Smith	1898-10-09	1984-07-28	\N	3	1	\N	\N	\N
1186	Alexander	Fleck	1889-11-11	1968-08-06	\N	7	1	\N	\N	\N
1187	Edith Clara	Summerskill	1901-04-19	1980-02-04	\N	20	2	\N	\N	\N
1188	William	Hughes	1911-01-22	1999-12-31	\N	9	1	\N	\N	\N
1189	Robert Anthony	Eden	1897-06-12	1977-01-14	\N	6	1	\N	\N	\N
1190	Gerald Ritchie	Upjohn	1903-02-25	1971-01-27	\N	22	1	\N	\N	\N
1192	Gerald Austin	Gardiner	1900-05-30	1990-01-07	\N	8	1	\N	\N	\N
1193	Richard	Llewelyn-Davies	1912-12-24	1981-10-27	\N	13	1	\N	\N	\N
1194	Bertram Vivian	Bowden	1910-01-18	1989-07-31	\N	3	1	\N	\N	\N
1089	Frederick Alexander	Lindemann	1886-04-05	1957-07-03	\N	13	1	\N	\N	\N
1197	Edwin Savory	Herbert	1899-06-29	1973-06-05	\N	9	1	\N	\N	\N
1198	Anna Dora	Gaitskell	1901-04-25	1989-07-01	\N	8	2	\N	\N	\N
1199	Roy Herbert	Thomson	1894-06-05	1976-08-04	\N	21	1	\N	\N	\N
1201	John Roland	Robinson	1907-02-22	1989-05-03	\N	19	1	\N	\N	\N
1202	Harold Arthur	Watkinson	1910-01-25	1995-12-19	\N	24	1	\N	\N	\N
1203	John Scott	Maclay	1905-10-26	1992-08-17	\N	14	1	\N	\N	\N
1204	John Adrian	Hope	1912-04-07	1996-01-18	\N	9	1	\N	\N	\N
1206	Geoffrey Kemp	Bourne	1902-10-05	1982-06-26	\N	3	1	\N	\N	\N
1207	Anthony Richard	Hurd	1901-05-02	1966-02-12	\N	9	1	\N	\N	\N
1208	Charles	Royle	1896-01-23	1975-09-30	\N	19	1	\N	\N	\N
1209	Hervey	Rhodes	1895-08-12	1987-09-11	\N	19	1	\N	\N	\N
1210	Keith Anderson Hope	Murray	1903-07-28	1993-10-10	\N	14	1	\N	\N	\N
1211	John Maxwell	Erskine	1893-12-14	1980-12-14	\N	6	1	\N	\N	\N
1212	Richard Orme	Wilberforce	1907-03-11	2003-02-15	\N	24	1	\N	\N	\N
1213	Gilbert Richard	Mitchison	1894-03-23	1970-02-14	\N	14	1	\N	\N	\N
1214	Barbara Muriel	Brooke	1908-01-14	2000-09-01	\N	3	2	\N	\N	\N
1215	Hugh Mackintosh	Foot	1907-10-08	1990-09-05	\N	7	1	\N	\N	\N
1217	Arthur Gwynne	Jones	1919-12-05	2020-01-10	\N	11	1	\N	\N	\N
1219	Robert Villiers	Grimston	1897-06-08	1979-12-08	\N	8	1	\N	\N	\N
1220	Francis George	Bowles	1902-05-02	1970-12-29	\N	3	1	\N	\N	\N
1221	Harold Francis	Collison	1909-05-10	1995-12-29	\N	4	1	\N	\N	\N
1222	Reginald William	Sorensen	1891-06-19	1971-10-08	\N	20	1	\N	\N	\N
1223	William Reid	Blyton	1899-05-02	1987-10-25	\N	3	1	\N	\N	\N
1224	Niall Malcolm Stewart	Macpherson	1908-08-03	1987-10-11	\N	14	1	\N	\N	\N
1225	Frances Joan	Davidson	1894-05-29	1985-11-25	\N	5	2	\N	\N	\N
1226	William Wavell	Wakefield	1898-03-10	1983-08-12	\N	24	1	\N	\N	\N
1227	Norah	Phillips	1910-08-12	1992-08-14	\N	17	2	\N	\N	\N
1229	Charles Frank	Byers	1915-07-24	1984-02-06	\N	3	1	\N	\N	\N
1230	Robert Burnham	Renwick	1904-10-04	1973-09-30	\N	19	1	\N	\N	\N
1231	Donald William	Wade	1904-06-16	1988-11-06	\N	24	1	\N	\N	\N
1232	Arwyn Randall	Davies	1897-04-17	1978-02-23	\N	5	1	\N	\N	\N
1233	Hugh	Fraser	1903-01-15	1966-11-06	\N	7	1	\N	\N	\N
1235	John Granville	Morrison	1906-12-16	1996-05-25	\N	14	1	\N	\N	\N
1236	James Chuter	Ede	1882-09-11	1965-11-11	\N	6	1	\N	\N	\N
1237	Christopher	Hinton	1901-05-12	1983-06-22	\N	9	1	\N	\N	\N
1238	William Graham	Holford	1907-03-22	1975-10-17	\N	9	1	\N	\N	\N
1239	Howard Walter	Florey	1898-09-24	1968-02-21	\N	7	1	\N	\N	\N
1241	Colin Hargreaves	Pearson	1899-07-28	1980-01-31	\N	17	1	\N	\N	\N
1242	Richard Austen	Butler	1902-12-09	1982-03-08	\N	3	1	\N	\N	\N
1243	Beatrice	Plummer	1903-04-14	1972-06-13	\N	17	2	\N	\N	\N
1244	Reginald Alfred	Wells-Pestell	1910-01-27	1991-01-17	\N	24	1	\N	\N	\N
1245	Albert Victor	Hilton	1908-02-14	1977-05-03	\N	9	1	\N	\N	\N
1246	Harold Anthony	Caccia	1905-12-21	1990-10-31	\N	4	1	\N	\N	\N
1247	Donald Oliver	Soper	1903-01-31	1998-12-22	\N	20	1	\N	\N	\N
1248	Thomas Spensley	Simey	1906-11-25	1969-12-27	\N	20	1	\N	\N	\N
1249	John Edwin	Haire	1908-11-14	1966-10-07	\N	9	1	\N	\N	\N
1250	Lewis Coleman	Cohen	1897-03-28	1966-10-21	\N	4	1	\N	\N	\N
1252	Dennis	Lloyd	1915-10-22	1992-12-31	\N	13	1	\N	\N	\N
1253	Harold Roxbee	Cox	1902-06-06	1997-12-21	\N	4	1	\N	\N	\N
1254	Russell Claude	Brock	1903-10-24	1980-09-03	\N	3	1	\N	\N	\N
1255	Richard Ferdinand	Kahn	1905-08-10	1989-06-06	\N	12	1	\N	\N	\N
1256	Richard	Beeching	1913-04-21	1985-03-23	\N	3	1	\N	\N	\N
1257	Noel Gilroy	Annan	1916-12-25	2000-02-21	\N	2	1	\N	\N	\N
1259	John Middleton	Campbell	1912-08-08	1994-12-26	\N	4	1	\N	\N	\N
1261	Audrey Pellew	Hylton-Foster	1908-05-19	2002-10-31	\N	9	2	\N	\N	\N
1262	Mary Danvers	Stocks	1891-07-25	1975-07-06	\N	20	2	\N	\N	\N
1263	William Francis Kenrick	Wynne-Jones	1903-05-08	1982-11-08	\N	24	1	\N	\N	\N
1264	Frank	Beswick	1911-08-21	1987-08-17	\N	3	1	\N	\N	\N
1265	Samuel	Segal	1902-04-02	1985-06-04	\N	20	1	\N	\N	\N
1266	Ernest	Popplewell	1899-12-10	1977-08-11	\N	17	1	\N	\N	\N
1267	Frank	Soskice	1902-07-23	1979-01-01	\N	20	1	\N	\N	\N
1268	George Albert	Pargiter	1897-03-16	1982-01-16	\N	17	1	\N	\N	\N
1269	Martin	Redmayne	1910-11-16	1983-04-28	\N	19	1	\N	\N	\N
1271	Samuel	Storey	1896-01-18	1978-01-17	\N	20	1	\N	\N	\N
1272	Arthur	Moyle	1894-09-25	1974-12-23	\N	14	1	\N	\N	\N
1273	William Hunter	McFadzean	1903-12-17	1996-01-14	\N	14	1	\N	\N	\N
1274	Henry Cecil John	Hunt	1910-06-22	1998-11-08	\N	9	1	\N	\N	\N
1275	Peter Ritchie	Calder	1906-07-01	1982-01-31	\N	4	1	\N	\N	\N
1276	John	Cooper	1908-06-07	1988-09-02	\N	4	1	\N	\N	\N
1277	Henry	Brooke	1903-04-09	1984-03-29	\N	3	1	\N	\N	\N
1279	Robert	Platt	1900-04-16	1978-06-30	\N	17	1	\N	\N	\N
1280	Charles Richard	Morris	1898-01-25	1990-05-30	\N	14	1	\N	\N	\N
1281	Harold	Woolley	1905-02-06	1986-07-31	\N	24	1	\N	\N	\N
1283	John Primatt Redcliffe	Redcliffe-Maud	1906-02-03	1982-11-20	\N	19	1	\N	\N	\N
1284	William George	Penney	1909-06-24	1991-03-03	\N	17	1	\N	\N	\N
1285	Llewellyn	Heycock	1905-08-12	1990-03-13	\N	9	1	\N	\N	\N
1286	William John	Carron	1902-11-19	1969-12-03	\N	4	1	\N	\N	\N
1287	Benjamin Ifor	Evans	1899-08-19	1982-08-28	\N	6	1	\N	\N	\N
1288	Alan Raymond	Mais	1911-07-07	1993-11-28	\N	14	1	\N	\N	\N
1290	Desmond Barel	Hirshfield	1913-05-17	1993-12-06	\N	9	1	\N	\N	\N
1291	Frank	McLeavy	1899-01-01	1976-10-01	\N	14	1	\N	\N	\N
1292	Edgar Louis	Granville	1898-02-12	1998-02-14	\N	8	1	\N	\N	\N
1293	David Lauchlan	Urquhart	1912-09-13	1975-03-12	\N	22	1	\N	\N	\N
1294	Alma	Birk	1917-09-22	1996-12-29	\N	3	2	\N	\N	\N
1295	William Geoffrey	Fiske	1905-07-03	1975-01-13	\N	7	1	\N	\N	\N
1296	Charles James	Garnsworthy	1906-12-10	1974-09-05	\N	8	1	\N	\N	\N
1297	Herbert William	Bowden	1905-01-20	1994-04-30	\N	3	1	\N	\N	\N
1298	Edward James	Hill	1899-08-20	1969-12-14	\N	9	1	\N	\N	\N
1299	Harry	Douglass	1902-01-01	1978-04-05	\N	5	1	\N	\N	\N
1301	John George Stuart	Donaldson	1907-10-09	1998-03-08	\N	5	1	\N	\N	\N
1302	John Scott	Fulton	1902-05-27	1986-03-14	\N	7	1	\N	\N	\N
1303	Arthur	Henderson	1893-08-27	1968-08-28	\N	9	1	\N	\N	\N
1196	Edward Henry	Willis	1918-01-13	1992-12-22	\N	24	1	\N	\N	\N
2857	Leopold Colin Henry Douglas	Campbell	1881-03-05	1940-02-08	\N	4	1	\N	\N	\N
1307	Thomas Johnston	Taylor	1912-04-27	2001-07-13	\N	21	1	\N	\N	\N
1308	Humphrey	Trevelyan	1905-11-27	1985-02-08	\N	21	1	\N	\N	\N
1309	Laurence Norman	Helsby	1908-04-27	1978-12-05	\N	9	1	\N	\N	\N
1310	Thomas	Balogh	1905-11-02	1985-01-20	\N	3	1	\N	\N	\N
1311	William Rushton	Black	1893-01-12	1984-12-27	\N	3	1	\N	\N	\N
1312	Geoffrey	Crowther	1907-05-13	1972-02-05	\N	4	1	\N	\N	\N
1313	William David	Evans	1912-12-25	1985-06-27	\N	6	1	\N	\N	\N
1315	Ralph Francis Alnwick	Grey	1910-04-15	1999-10-17	\N	8	1	\N	\N	\N
1316	William John Kenneth	Diplock	1907-12-08	1985-10-14	\N	5	1	\N	\N	\N
1317	Donald Gresham	Stokes	1914-03-22	2008-07-21	\N	20	1	\N	\N	\N
1318	Patrick Maynard Stuart	Blackett	1897-11-18	1974-07-13	\N	3	1	\N	\N	\N
1320	Learie Nicholas	Constantine	1901-09-21	1971-07-01	\N	4	1	\N	\N	\N
1321	Paul Henry	Gore-Booth	1909-02-03	1984-06-29	\N	8	1	\N	\N	\N
1322	Sidney Lewis	Bernstein	1899-01-30	1993-02-05	\N	3	1	\N	\N	\N
1323	Kenneth Mackenzie	Clark	1903-07-13	1983-05-21	\N	4	1	\N	\N	\N
1324	John Cowburn	Beavan	1910-04-29	1994-08-18	\N	3	1	\N	\N	\N
1325	Terence Marne	O'Neill	1914-09-10	1990-06-12	\N	16	1	\N	\N	\N
1326	Christopher Frank	Kearton	1911-02-17	1992-07-02	\N	12	1	\N	\N	\N
1327	Susan Lilian Primrose	Cunliffe-Lister	1935-04-14	\N	\N	4	2	\N	\N	\N
1328	Emanuel	Shinwell	1884-10-18	1986-05-08	\N	20	1	\N	\N	\N
1329	Barnett	Janner	1892-06-20	1982-05-04	\N	11	1	\N	\N	\N
1331	Priscilla Jean Fortescue	Buchan	1915-01-25	1978-03-11	\N	3	2	\N	\N	\N
1332	John Kenyon	Vaughan-Morgan	1905-02-02	1995-01-26	\N	23	1	\N	\N	\N
1334	James Hutchison	Hoy	1909-01-21	1976-08-07	\N	9	1	\N	\N	\N
1335	Cyril	Hamnett	1906-05-20	1980-03-17	\N	9	1	\N	\N	\N
1336	Evelyn Nigel Chetwode	Birch	1906-11-18	1981-03-08	\N	3	1	\N	\N	\N
1337	Joseph	Slater	1904-06-13	1977-04-21	\N	20	1	\N	\N	\N
1338	Eric George Molyneux	Fletcher	1903-03-26	1990-06-09	\N	7	1	\N	\N	\N
1339	John	Wheatley	1908-01-17	1988-07-28	\N	24	1	\N	\N	\N
1340	Max Leonard	Rosenheim	1908-03-15	1972-12-02	\N	19	1	\N	\N	\N
1341	George Edward Peter	Thorneycroft	1909-07-26	1994-06-04	\N	21	1	\N	\N	\N
1342	Timothy Wentworth	Beaumont	1928-11-22	2008-04-08	\N	3	1	\N	\N	\N
1344	Eirene Lloyd	White	1909-11-07	1999-12-23	\N	24	2	\N	\N	\N
1345	Janet	Bevan	1904-11-03	1988-11-16	\N	3	2	\N	\N	\N
1346	George Alfred	Brown	1914-09-02	1985-06-02	\N	3	1	\N	\N	\N
1348	William John	Molloy	1918-10-26	2001-05-26	\N	14	1	\N	\N	\N
1349	Horace Maybray	Maybray-King	1901-05-25	1986-09-03	\N	14	1	\N	\N	\N
1350	Laurence Kerr	Olivier	1907-05-22	1989-07-11	\N	16	1	\N	\N	\N
1351	Arthur Geoffrey Neale	Cross	1904-12-01	1989-08-04	\N	4	1	\N	\N	\N
1352	John Passmore	Widgery	1911-07-24	1981-07-26	\N	24	1	\N	\N	\N
1353	Charles Ian	Orr-Ewing	1912-02-10	1999-08-19	\N	16	1	\N	\N	\N
1354	Arthur Vere	Harvey	1906-01-31	1994-04-05	\N	9	1	\N	\N	\N
1355	Robert Norman William	Blake	1916-12-23	2003-09-20	\N	3	1	\N	\N	\N
1356	Beatrice Nancy	Seear	1913-08-07	1997-04-23	\N	20	2	\N	\N	\N
1357	Simon Brooke	Mackay	1934-03-30	\N	\N	14	1	\N	\N	\N
1358	Janet Mary	Young	1926-10-23	2002-09-06	\N	26	2	\N	\N	\N
1359	Evelyn Hester	Macleod	1915-02-19	1999-11-17	\N	14	2	\N	\N	\N
1362	Charles James Dalrymple	Shaw	1906-08-15	1989-09-10	\N	20	1	\N	\N	\N
1363	Cyril Barnet	Salmon	1903-12-28	1991-11-07	\N	20	1	\N	\N	\N
1364	Michael Edward	Adeane	1910-09-30	1984-04-30	\N	2	1	\N	\N	\N
1365	Charles Leslie	Hale	1902-07-13	1985-05-09	\N	9	1	\N	\N	\N
1366	Thomas Clyde	Hewlett	1923-08-04	1979-07-02	\N	9	1	\N	\N	\N
1367	Frederic	Seebohm	1909-01-18	1990-12-15	\N	20	1	\N	\N	\N
1368	John Archibald	Boyd-Carpenter	1908-06-02	1998-07-11	\N	3	1	\N	\N	\N
1369	Diana Louie	Elles	1921-07-19	2009-10-17	\N	6	2	\N	\N	\N
1370	Samuel Charles	Elworthy	1911-03-23	1993-04-04	\N	6	1	\N	\N	\N
1372	Harold	Samuel	1912-04-23	1987-08-28	\N	20	1	\N	\N	\N
1373	Bernard Edward	Fergusson	1911-05-06	1980-11-28	\N	7	1	\N	\N	\N
1374	Arthur Espie	Porritt	1900-08-10	1994-01-01	\N	17	1	\N	\N	\N
1375	Leslie Kenneth	O'Brien	1908-02-08	1995-11-24	\N	16	1	\N	\N	\N
1376	Pamela	Sharples	1923-02-11	\N	\N	20	2	\N	\N	\N
1377	John Desmond	Brayley	1917-01-29	1977-03-16	\N	3	1	\N	\N	\N
1379	Rhys Gerran	Lloyd	1907-08-12	1991-01-30	\N	13	1	\N	\N	\N
1380	Eric	Ashby	1904-08-24	1992-10-22	\N	2	1	\N	\N	\N
1381	Robert Alexander	Allan	1914-07-11	1979-04-04	\N	2	1	\N	\N	\N
1383	John	Diamond	1907-04-30	2004-04-03	\N	5	1	\N	\N	\N
1384	Harold	Davies	1904-07-31	1985-10-28	\N	5	1	\N	\N	\N
1385	Goronwy Owen	Goronwy-Roberts	1913-09-20	1981-07-22	\N	8	1	\N	\N	\N
1386	John Henry	Harris	1930-04-05	2001-04-11	\N	9	1	\N	\N	\N
1387	Duncan Edwin	Sandys	1908-01-24	1987-11-26	\N	20	1	\N	\N	\N
1388	Michael Antony Cristobal	Noble	1913-03-19	1984-05-15	\N	15	1	\N	\N	\N
1389	Geoffrey William	Lloyd	1902-01-17	1984-09-12	\N	13	1	\N	\N	\N
1390	Alfred Ernest	Marples	1907-12-09	1978-07-06	\N	14	1	\N	\N	\N
1391	Robert Hugh	Turton	1903-08-08	1994-01-17	\N	21	1	\N	\N	\N
1392	George Yull	Mackie	1919-07-10	2015-02-17	\N	14	1	\N	\N	\N
1394	Inga-Stina	Robson	1919-08-20	1999-02-09	\N	19	2	\N	\N	\N
1396	Basil Thomas	Wigoder	1921-02-12	2004-08-12	\N	24	1	\N	\N	\N
1397	Richard Michael	Fraser	1915-10-28	1996-07-01	\N	7	1	\N	\N	\N
1398	Edward Cyril	Castle	1907-05-05	1979-12-26	\N	4	1	\N	\N	\N
1399	Samuel	Fisher	1905-01-20	1979-10-12	\N	7	1	\N	\N	\N
1400	Arthur Leslie Noel Douglas	Houghton	1898-08-11	1996-05-02	\N	9	1	\N	\N	\N
1401	Thomas Charles	Pannell	1902-09-10	1980-03-23	\N	17	1	\N	\N	\N
1402	Robert Grant	Grant-Ferris	1907-12-30	1997-01-01	\N	8	1	\N	\N	\N
1403	Phyllis	Stedman	1916-07-14	1996-06-08	\N	20	2	\N	\N	\N
1404	Peter Lovell	Davis	1924-07-08	2001-01-06	\N	5	1	\N	\N	\N
1405	Harry	Kissin	1912-08-23	1997-11-22	\N	12	1	\N	\N	\N
1406	George	Wallace	1915-02-13	1997-12-23	\N	24	1	\N	\N	\N
1407	Frederick	Lee	1906-08-03	1984-02-04	\N	13	1	\N	\N	\N
1409	George	Darling	1905-07-01	1985-10-18	\N	5	1	\N	\N	\N
1410	Patrick Chrestien	Gordon-Walker	1907-04-07	1980-12-02	\N	8	1	\N	\N	\N
1306	Lewis Tatham	Wright	1903-10-11	1974-09-15	\N	24	1	\N	\N	\N
2858	Philip Archibald Douglas	Campbell	1919-02-19	1940-09-14	\N	4	1	\N	\N	\N
1413	Alfred Walter Henry	Allen	1914-07-07	1985-01-14	\N	2	1	\N	\N	\N
1414	Marcia Matilda	Williams	1932-03-10	2019-02-06	\N	24	2	\N	\N	\N
1415	John Frederick	Wolfenden	1906-06-26	1985-01-18	\N	24	1	\N	\N	\N
1416	Herbert Edmund	Davies	1906-07-15	1992-12-27	\N	5	1	\N	\N	\N
1417	Arthur Michael	Ramsey	1904-11-14	1988-04-23	\N	19	1	\N	\N	\N
1419	Arnold	Silverstone	1911-09-28	1977-07-23	\N	20	1	\N	\N	\N
1420	Anthony Perrinott Lysberg	Barber	1920-07-04	2005-12-16	\N	3	1	\N	\N	\N
1421	Desmond Anderson Harvie	Banks	1918-10-23	1997-06-15	\N	3	1	\N	\N	\N
1422	Victor Grayson Hardie	Feather	1908-04-10	1976-07-28	\N	7	1	\N	\N	\N
1423	Burke St. John	Trend	1914-01-02	1987-07-21	\N	21	1	\N	\N	\N
1425	Alfred	Wilson	1909-06-10	1983-01-25	\N	24	1	\N	\N	\N
1426	Mary Elizabeth Henderson	Stewart	1903-05-08	1984-12-28	\N	20	2	\N	\N	\N
1427	Richard William	Briginshaw	1908-05-15	1992-03-27	\N	3	1	\N	\N	\N
1428	George Douglas	Wallace	1906-04-18	2003-11-11	\N	24	1	\N	\N	\N
1430	Sidney Francis	Greene	1910-02-12	2004-07-26	\N	8	1	\N	\N	\N
1431	Braham Jack Dennis	Lyons	1918-09-11	1978-01-18	\N	13	1	\N	\N	\N
1432	Irene Mary Bewick	Ward	1895-02-23	1980-04-26	\N	24	2	\N	\N	\N
1433	Robert Alexander	Lindsay	1927-03-05	\N	\N	13	1	\N	\N	\N
1434	Joan Helen	Vickers	1907-06-03	1994-05-23	\N	23	2	\N	\N	\N
1435	Rudy	Sternberg	1917-04-17	1978-01-05	\N	20	1	\N	\N	\N
1436	William	Armstrong	1915-03-03	1980-07-12	\N	2	1	\N	\N	\N
1437	Derek Wilbraham	Pritchard	1910-06-08	1995-10-16	\N	17	1	\N	\N	\N
1439	Leslie Maurice	Lever	1905-04-29	1977-07-26	\N	13	1	\N	\N	\N
1440	John	Gregson	1924-01-29	2009-08-12	\N	8	1	\N	\N	\N
1441	William Denholm	Barnetson	1917-03-21	1981-03-12	\N	3	1	\N	\N	\N
1442	Sydney Thomas Franklin	Ryder	1916-09-16	2003-05-12	\N	19	1	\N	\N	\N
1443	Sydney	Jacobson	1908-10-26	1988-08-13	\N	11	1	\N	\N	\N
1444	John Farquharson	Smith	1930-05-07	\N	\N	20	1	\N	\N	\N
1446	Raymond Percival	Brookes	1909-04-10	2002-07-31	\N	3	1	\N	\N	\N
1447	Leonard Robert	Carr	1916-11-11	2012-02-17	\N	4	1	\N	\N	\N
1448	Thomas Edward Neil	Driberg	1905-05-22	1976-08-12	\N	5	1	\N	\N	\N
1449	William Edward John	McCarthy	1925-07-30	2012-11-18	\N	14	1	\N	\N	\N
1450	William Donald	Chapman	1923-11-25	2013-04-18	\N	4	1	\N	\N	\N
1452	Albert Edward	Oram	1913-08-13	1999-09-04	\N	16	1	\N	\N	\N
1453	Michael Platt	Winstanley	1918-08-27	1993-07-18	\N	24	1	\N	\N	\N
1454	Lucy	Faithfull	1910-12-26	1996-03-13	\N	7	2	\N	\N	\N
1455	Frank	Schon	1912-05-18	1995-01-07	\N	20	1	\N	\N	\N
1456	Thomas	Brimelow	1915-10-25	1995-08-02	\N	3	1	\N	\N	\N
1457	Alan Louis Charles	Bullock	1914-12-13	2004-02-02	\N	3	1	\N	\N	\N
1458	Paul Norman	Wilson	1908-10-24	1980-02-24	\N	24	1	\N	\N	\N
1459	John Edward	Wall	1913-02-15	1980-12-29	\N	24	1	\N	\N	\N
1460	John Selwyn Brooke	Lloyd	1904-07-28	1978-05-17	\N	13	1	\N	\N	\N
1461	Lew	Grade	1906-12-25	1998-12-13	\N	8	1	\N	\N	\N
1463	Joseph Ellis	Stone	1903-05-27	1986-07-17	\N	20	1	\N	\N	\N
1464	Walter Ian Reid	Fraser	1911-02-03	1989-02-17	\N	7	1	\N	\N	\N
1465	Edward Benjamin	Britten	1913-11-22	1976-12-04	\N	3	1	\N	\N	\N
1466	Philip	Allen	1912-07-08	2007-11-27	\N	2	1	\N	\N	\N
1467	Asa	Briggs	1921-05-07	2016-03-15	\N	3	1	\N	\N	\N
1468	Max	Rayne	1918-02-08	2003-10-10	\N	19	1	\N	\N	\N
1470	Barbara Mary	Jackson	1914-05-23	1981-05-31	\N	11	2	\N	\N	\N
1472	Edward Watson	Short	1912-12-17	2012-05-04	\N	20	1	\N	\N	\N
1473	John Fleetwood	Baker	1901-03-19	1985-09-09	\N	3	1	\N	\N	\N
1474	Arthur Brian Deane	Faulkner	1921-02-18	1977-03-03	\N	7	1	\N	\N	\N
1475	Morrice	James	1916-04-30	1989-11-26	\N	11	1	\N	\N	\N
1476	George Morgan	Thomson	1921-01-16	2008-10-03	\N	21	1	\N	\N	\N
1477	Richard Michael Power	Carver	1915-04-24	2001-12-09	\N	4	1	\N	\N	\N
1478	Pratap Chidamber	Chitnis	1936-05-01	2013-07-12	\N	4	1	\N	\N	\N
1479	Eric	Roll	1907-12-01	2005-03-30	\N	19	1	\N	\N	\N
1480	Kenneth William	Wedderburn	1927-04-13	2012-03-09	\N	24	1	\N	\N	\N
1481	Philip John	Noel-Baker	1889-11-01	1982-10-08	\N	15	1	\N	\N	\N
1483	Leslie George	Scarman	1911-07-29	2004-12-08	\N	20	1	\N	\N	\N
1484	Oliver Ross	McGregor	1921-08-25	1997-11-10	\N	14	1	\N	\N	\N
1485	Betty	Lockwood	1924-01-22	2019-04-29	\N	13	2	\N	\N	\N
1486	Michael	Young	1915-08-09	2002-01-14	\N	26	1	\N	\N	\N
1488	Peter Anthony Grayson	Rawlinson	1919-06-26	2006-06-28	\N	19	1	\N	\N	\N
1489	Arthur Christopher John	Soames	1920-10-12	1987-09-16	\N	20	1	\N	\N	\N
1490	William	Howie	1924-03-02	2018-05-26	\N	9	1	\N	\N	\N
1491	David Thomas Gruffydd	Evans	1928-02-09	1992-03-22	\N	6	1	\N	\N	\N
1492	John Derek	Page	1927-08-14	2005-08-16	\N	17	1	\N	\N	\N
1493	Nora Ratcliff	David	1913-09-23	2009-11-29	\N	5	2	\N	\N	\N
1494	John Denis	Leonard	1909-10-19	1983-07-17	\N	13	1	\N	\N	\N
1496	Thomas	Taylor	1929-06-10	2016-11-25	\N	21	1	\N	\N	\N
1497	John Charles	Hatch	1917-11-01	1992-10-11	\N	9	1	\N	\N	\N
1498	Cyril Thomas Howe	Plant	1910-08-27	1986-08-09	\N	17	1	\N	\N	\N
1499	Victor	Mishcon	1915-08-14	2006-01-27	\N	14	1	\N	\N	\N
1500	Alexander Mitchell	Donnet	1916-06-26	1985-05-15	\N	5	1	\N	\N	\N
1501	Evelyn Joyce	Denington	1907-08-09	1998-08-22	\N	5	2	\N	\N	\N
1502	Bernard	Delfont	1909-09-05	1994-07-28	\N	5	1	\N	\N	\N
1503	Joseph	Kagan	1915-06-06	1995-01-17	\N	12	1	\N	\N	\N
1505	Margaret Susan	Ryder	1923-07-03	2000-11-02	\N	19	2	\N	\N	\N
1506	John Samuel	Richardson	1910-06-16	2004-08-15	\N	19	1	\N	\N	\N
1507	Peter John	Hill-Norton	1915-02-08	2004-05-16	\N	9	1	\N	\N	\N
1508	Bernard James	Miles	1907-09-27	1991-06-14	\N	14	1	\N	\N	\N
1509	Hugh Parr	Scanlon	1913-10-26	2004-01-27	\N	20	1	\N	\N	\N
1511	Irwin Norman	Bellow	1923-02-07	2001-02-11	\N	3	1	\N	\N	\N
1512	Norman Harold	Lever	1914-01-15	1995-08-06	\N	13	1	\N	\N	\N
1514	James Peter Hymers	Mackay	1927-07-02	\N	\N	14	1	\N	\N	\N
1515	George Russell	Strauss	1901-07-18	1993-06-05	\N	20	1	\N	\N	\N
1516	Sydney	Irving	1918-07-01	1989-12-18	\N	10	1	\N	\N	\N
1517	Myer	Galpern	1903-01-01	1993-09-23	\N	8	1	\N	\N	\N
1518	Lena May	Jeger	1915-11-19	2007-02-26	\N	11	2	\N	\N	\N
1412	Nicholas	Kaldor	1908-05-12	1986-09-30	\N	12	1	\N	\N	\N
1521	Henry Reginall	Underhill	1914-05-08	1993-03-12	\N	22	1	\N	\N	\N
1522	Cledwyn	Hughes	1916-09-14	2001-02-22	\N	9	1	\N	\N	\N
1523	John Edward	Brooks	1927-04-12	2016-03-04	\N	3	1	\N	\N	\N
1524	Ralph	Harris	1924-12-10	2006-10-19	\N	9	1	\N	\N	\N
1525	William	Ross	1911-04-07	1988-06-10	\N	19	1	\N	\N	\N
1527	Jean Kennedy	McFarlane	1926-04-01	2012-05-13	\N	14	2	\N	\N	\N
1528	Diana Josceline Barbara	Neave	1919-07-07	1992-11-27	\N	15	2	\N	\N	\N
1529	Richard Frederick	Wood	1920-10-05	2002-08-11	\N	24	1	\N	\N	\N
1530	James David	Gibson-Watt	1918-09-11	2002-02-07	\N	8	1	\N	\N	\N
1531	Hugh Redwald	Trevor-Roper	1914-01-15	2003-01-26	\N	21	1	\N	\N	\N
1533	Geoffrey Dawson	Lane	1918-07-17	2005-08-21	\N	13	1	\N	\N	\N
1534	Frederick Donald	Coggan	1909-10-09	2000-05-17	\N	4	1	\N	\N	\N
1535	Jean Alys	Barker	1922-10-23	2018-11-26	\N	3	2	\N	\N	\N
1536	Kenneth Alexander	Keith	1916-08-30	2004-09-01	\N	12	1	\N	\N	\N
1537	John Joseph Benedict	Hunt	1919-10-23	2008-07-17	\N	9	1	\N	\N	\N
1538	George Carlyle	Emslie	1919-12-06	2002-11-20	\N	6	1	\N	\N	\N
1539	Marcus Joseph	Sieff	1913-07-02	2001-02-23	\N	20	1	\N	\N	\N
1540	Robert Brockie	Hunter	1915-07-14	1994-03-24	\N	9	1	\N	\N	\N
1541	Eustace Wentworth	Roskill	1911-02-06	1996-10-04	\N	19	1	\N	\N	\N
1542	Paul	Reilly	1912-05-29	1990-10-11	\N	19	1	\N	\N	\N
1544	Nigel Cyprian	Bridge	1917-02-26	2007-11-20	\N	3	1	\N	\N	\N
1546	Geoffrey Johnson	Tordoff	1928-10-11	2019-06-22	\N	21	1	\N	\N	\N
1547	Hugh Gater	Jenkins	1908-07-27	2004-01-26	\N	11	1	\N	\N	\N
1548	John	John-Mackie	1909-11-24	1994-05-26	\N	11	1	\N	\N	\N
1549	Felicity	Lane-Fox	1918-06-22	1988-04-17	\N	13	2	\N	\N	\N
1550	Edward Stanley	Bishop	1920-10-03	1984-04-19	\N	3	1	\N	\N	\N
1551	Felicity Jane	Ewart-Biggs	1929-08-22	1992-10-08	\N	6	2	\N	\N	\N
1552	Max	Beloff	1913-07-02	1999-03-22	\N	3	1	\N	\N	\N
1553	Dafydd Elystan	Morgan	1932-12-07	2021-07-07	\N	14	1	\N	\N	\N
1554	Beryl Catherine	Platt	1923-04-18	2015-02-01	\N	17	2	\N	\N	\N
1555	Arthur Desmond Herne	Plummer	1914-05-25	2009-10-02	\N	17	1	\N	\N	\N
1556	James Anthony	Stodart	1916-06-06	2003-05-31	\N	20	1	\N	\N	\N
1558	Christopher Paget	Mayhew	1915-06-12	1997-01-07	\N	14	1	\N	\N	\N
1559	Richard William	Marsh	1928-03-14	2011-07-29	\N	14	1	\N	\N	\N
1561	Lawrence	Kadoorie	1899-06-02	1993-08-25	\N	12	1	\N	\N	\N
1562	Charles	Forte	1908-11-26	2007-02-28	\N	7	1	\N	\N	\N
1563	William Nicholas	Cayzer	1910-01-21	1999-04-16	\N	4	1	\N	\N	\N
1564	Henry Vivian	Brandon	1920-06-03	1999-03-24	\N	3	1	\N	\N	\N
1565	Ian Powell	Bancroft	1922-12-23	1996-11-19	\N	3	1	\N	\N	\N
1566	John Anson	Brightman	1911-06-20	2006-02-06	\N	3	1	\N	\N	\N
1567	Crawford Murray	MacLehose	1917-10-16	2000-05-27	\N	14	1	\N	\N	\N
1569	Raymond William	Pennock	1920-06-16	1993-02-23	\N	17	1	\N	\N	\N
1570	Joseph	Gormley	1917-07-05	1993-05-27	\N	8	1	\N	\N	\N
1571	Sydney William	Templeman	1920-03-03	2014-06-04	\N	21	1	\N	\N	\N
1572	Terence Thornton	Lewin	1920-11-19	1999-01-23	\N	13	1	\N	\N	\N
1573	Andrew Robert	McIntosh	1933-04-30	2010-08-27	\N	14	1	\N	\N	\N
1574	Olive Mary Wendy	Nicol	1923-03-21	2018-01-15	\N	15	2	\N	\N	\N
1575	Caroline Anne	Cox	1937-07-06	\N	\N	4	2	\N	\N	\N
1576	Francis	Taylor	1905-01-07	1995-02-15	\N	21	1	\N	\N	\N
1578	Derek	Ezra	1919-02-23	2015-12-22	\N	6	1	\N	\N	\N
1579	Derek George	Rayner	1926-03-30	1998-06-26	\N	19	1	\N	\N	\N
1580	Frank Shaw	Marshall	1915-09-26	1990-11-01	\N	14	1	\N	\N	\N
1581	Arnold	Weinstock	1924-07-29	2002-07-23	\N	24	1	\N	\N	\N
1582	Henry Alexander	Benson	1909-08-02	1995-03-05	\N	3	1	\N	\N	\N
1583	John	Gallacher	1920-05-07	2004-01-04	\N	8	1	\N	\N	\N
1584	James Edward	Hanson	1922-01-20	2004-11-01	\N	9	1	\N	\N	\N
1587	John Leonard	King	1918-08-29	2005-07-12	\N	12	1	\N	\N	\N
1588	James Hector Northey (Hamish)	Gray	1927-06-28	2006-03-14	\N	8	1	\N	\N	\N
1589	Thomas George	Thomas	1909-01-29	1997-09-22	\N	21	1	\N	\N	\N
1590	Stuart Yarworth	Blanch	1918-02-02	1994-06-03	\N	3	1	\N	\N	\N
1591	Albert William	Stallard	1921-11-05	2008-03-29	\N	20	1	\N	\N	\N
1592	David Hedley	Ennals	1922-08-19	1995-06-17	\N	6	1	\N	\N	\N
1593	Thomas Edward	Graham	1925-03-26	2020-03-20	\N	8	1	\N	\N	\N
1594	David Leonard	Stoddart	1926-05-04	2020-11-14	\N	20	1	\N	\N	\N
1595	James Harold	Wilson	1916-03-11	1995-05-24	\N	24	1	\N	\N	\N
1597	Derek Colclough	Walker-Smith	1910-04-13	1992-01-22	\N	24	1	\N	\N	\N
1598	Donald	Kaberry	1907-08-18	1991-03-13	\N	12	1	\N	\N	\N
1599	Anthony Henry Fanshawe	Royle	1927-03-27	2001-12-28	\N	19	1	\N	\N	\N
1600	Joseph Jabez	Dean	1922-06-03	1999-02-26	\N	5	1	\N	\N	\N
1601	Joel	Barnett	1923-10-14	2014-11-01	\N	3	1	\N	\N	\N
1602	John Benedict	Eden	1925-09-15	2020-05-23	\N	6	1	\N	\N	\N
1603	John Wynne William	Peyton	1919-02-13	2006-11-22	\N	17	1	\N	\N	\N
1604	John	Bruce-Gardyne	1930-04-12	1990-04-15	\N	3	1	\N	\N	\N
1605	Neil George	Carmichael	1921-10-10	2001-07-19	\N	4	1	\N	\N	\N
1606	Joseph	Grimond	1913-07-29	1993-10-24	\N	8	1	\N	\N	\N
1607	Gerard	Fitt	1926-04-09	2005-08-26	\N	7	1	\N	\N	\N
1610	Francis Joseph	Chapple	1921-08-08	2004-10-19	\N	4	1	\N	\N	\N
1611	Kenneth John	Cameron	1931-06-11	\N	\N	4	1	\N	\N	\N
1612	David Ivor	Young	1932-02-27	\N	\N	26	1	\N	\N	\N
1613	Helen Mary	Warnock	1924-04-14	2019-03-20	\N	24	2	\N	\N	\N
1614	Nigel	Vinson	1931-01-27	\N	\N	23	1	\N	\N	\N
1615	Lionel	Murray	1922-08-02	2004-05-20	\N	14	1	\N	\N	\N
1617	Samuel Charles	Silkin	1918-03-06	1988-08-17	\N	20	1	\N	\N	\N
1618	John Blackstock	Butterworth	1918-03-13	2003-06-19	\N	3	1	\N	\N	\N
1619	Gwilym Prys	Davies	1923-12-08	2017-03-28	\N	5	1	\N	\N	\N
1620	Peter Thomas	Bauer	1915-11-06	2002-05-03	\N	3	1	\N	\N	\N
1621	Neil	Cameron	1920-07-08	1985-01-29	\N	4	1	\N	\N	\N
1622	Muriel Winifred	Turner	1922-09-18	2018-02-26	\N	21	2	\N	\N	\N
1623	William Hugh	Griffiths	1923-09-26	2015-05-30	\N	8	1	\N	\N	\N
1624	Hugh Drennan Baird	Morton	1930-04-10	1995-04-26	\N	14	1	\N	\N	\N
1625	Charles Russell	Sanderson	1933-04-30	\N	\N	20	1	\N	\N	\N
1626	Gloria	Hooper	1939-05-25	\N	\N	9	2	\N	\N	\N
1520	Joseph Bradshaw	Godber	1914-03-17	1980-08-25	\N	8	1	\N	\N	\N
2859	William	Brougham	1795-09-26	1886-01-03	\N	3	1	\N	\N	\N
1632	Peter Raymond	Oliver	1921-03-07	2007-10-17	\N	16	1	\N	\N	\N
1633	Robert Lionel Archibald	Goff	1926-11-12	2016-08-14	\N	8	1	\N	\N	\N
1634	Mark Raymond	Bonham Carter	1922-02-11	1994-09-04	\N	3	1	\N	\N	\N
1635	Philip Brian Cecil	Moore	1921-04-06	2009-04-07	\N	14	1	\N	\N	\N
1636	William Francis	Deedes	1913-06-01	2007-08-17	\N	5	1	\N	\N	\N
1637	Woodrow Lyle	Wyatt	1918-07-04	1997-12-07	\N	24	1	\N	\N	\N
1638	Edwin Noel Westby	Bramall	1923-12-18	2019-11-12	\N	3	1	\N	\N	\N
1640	Denis Victor	Carter	1932-01-17	2006-12-18	\N	4	1	\N	\N	\N
1641	Maurice Harry	Peston	1931-03-19	2016-04-23	\N	17	1	\N	\N	\N
1642	Alexander Andrew Mackay	Irvine	1940-06-23	\N	\N	10	1	\N	\N	\N
1643	David Robert	Stevens	1936-05-26	\N	\N	20	1	\N	\N	\N
1644	David	Basnett	1924-02-09	1989-01-25	\N	3	1	\N	\N	\N
1645	Joseph Anthony Porteous	Trafford	1932-07-20	1989-09-16	\N	21	1	\N	\N	\N
1646	Charles Henry	Plumb	1925-03-27	\N	\N	17	1	\N	\N	\N
1647	Emily May	Blatch	1937-07-24	2005-05-31	\N	3	2	\N	\N	\N
1648	James Duncan	Goold	1934-05-28	1997-07-27	\N	8	1	\N	\N	\N
1649	Amos Henry	Chilver	1926-10-30	2012-07-08	\N	4	1	\N	\N	\N
1652	Peter John Mitchell	Thomas	1920-07-31	2008-02-04	\N	21	1	\N	\N	\N
1653	Douglas Patrick Thomas	Jay	1907-03-23	1996-03-06	\N	11	1	\N	\N	\N
1654	Francis Leslie	Pym	1922-02-13	2008-03-07	\N	17	1	\N	\N	\N
1655	Keith Sinjohn	Joseph	1918-01-17	1994-12-10	\N	11	1	\N	\N	\N
1656	John Donkin	Dormand	1919-08-27	2003-12-18	\N	5	1	\N	\N	\N
1657	James Michael Leathes	Prior	1927-10-11	2016-12-12	\N	17	1	\N	\N	\N
1658	Richard	Crawshaw	1917-09-25	1986-07-16	\N	4	1	\N	\N	\N
1659	Bernard	Donoughue	1934-09-08	\N	\N	5	1	\N	\N	\N
1660	Charles Cuthbert Powell	Williams	1933-02-09	2019-12-30	\N	24	1	\N	\N	\N
1661	Charles Patrick Fleeming	Jenkin	1926-09-07	2016-12-20	\N	11	1	\N	\N	\N
1662	Stephen Sherlock	Ross	1926-07-06	1993-05-10	\N	19	1	\N	\N	\N
1664	Peter Wynford Innes	Rees	1926-12-09	2008-11-30	\N	19	1	\N	\N	\N
1665	Roy Harris	Jenkins	1920-11-11	2003-01-05	\N	11	1	\N	\N	\N
1666	Immanuel	Jakobovits	1921-02-08	1999-10-31	\N	11	1	\N	\N	\N
1668	John Francis	Donaldson	1920-10-06	2005-08-31	\N	5	1	\N	\N	\N
1669	Charles Eliot	Jauncey	1925-05-08	2007-07-18	\N	11	1	\N	\N	\N
1670	Robert Temple	Armstrong	1927-03-30	2020-04-03	\N	2	1	\N	\N	\N
1671	Robert Scott	Alexander	1936-09-05	2005-11-06	\N	2	1	\N	\N	\N
1672	Andrew Albert Christian Edward	-	1960-02-19	\N	\N	1	1	\N	\N	\N
1673	William	Rees-Mogg	1928-07-14	2012-12-29	\N	19	1	\N	\N	\N
1675	Alexander John	Mackenzie Stuart	1924-11-18	2000-04-01	\N	14	1	\N	\N	\N
1676	Donald	Macaulay	1933-11-14	2014-06-12	\N	14	1	\N	\N	\N
1677	John Davan	Sainsbury	1927-11-02	\N	\N	20	1	\N	\N	\N
1678	Jack	Lewis	1928-02-13	2014-07-17	\N	13	1	\N	\N	\N
1679	Sally	Oppenheim-Barnes	1930-07-26	\N	\N	16	2	\N	\N	\N
1680	Eric	Sharp	1916-08-17	1994-05-02	\N	20	1	\N	\N	\N
1681	Peter Lovat	Fraser	1945-05-29	2013-06-22	\N	7	1	\N	\N	\N
1682	John Nicholas	Walton	1922-09-16	2016-04-21	\N	24	1	\N	\N	\N
1683	Ian	McColl	1933-01-06	\N	\N	14	1	\N	\N	\N
1684	John David Elliott	Fieldhouse	1928-02-12	1992-02-17	\N	7	1	\N	\N	\N
1685	Francis Leonard	Tombs	1924-05-17	2020-04-11	\N	21	1	\N	\N	\N
1686	Brian Robert	Morris	1930-12-04	2001-04-30	\N	14	1	\N	\N	\N
1689	William Oulton	Wade	1932-12-24	2018-06-07	\N	24	1	\N	\N	\N
1690	Richard Hugh	Cavendish	1941-11-02	\N	\N	4	1	\N	\N	\N
1691	Julia Frances	Cumberlege	1943-01-27	\N	\N	4	2	\N	\N	\N
1692	Heather Renwick	Brigstocke	1929-09-02	2004-04-30	\N	3	2	\N	\N	\N
1693	Ernest Jackson Lawson	Soulsby	1926-06-23	2017-05-08	\N	20	1	\N	\N	\N
1694	Richard Gordon	Holme	1936-05-27	2008-05-04	\N	9	1	\N	\N	\N
1695	Eric Graham	Varley	1932-08-11	2008-07-29	\N	23	1	\N	\N	\N
1696	Patricia Lesley	Hollis	1941-05-24	2018-10-13	\N	9	2	\N	\N	\N
1697	Shreela	Flather	1934-02-13	\N	\N	7	2	\N	\N	\N
1698	Roy	Mason	1924-04-18	2015-04-19	\N	14	1	\N	\N	\N
1699	Mark	Carlisle	1929-07-07	2005-07-14	\N	4	1	\N	\N	\N
1700	Robert	Haslam	1923-02-04	2002-11-02	\N	9	1	\N	\N	\N
1703	Vincent Gordon Lindsay	White	1923-05-11	1995-08-23	\N	24	1	\N	\N	\N
1704	Robert Alexander Kennedy	Runcie	1921-10-02	2000-07-11	\N	19	1	\N	\N	\N
1705	Peter Garth	Palumbo	1935-07-20	\N	\N	17	1	\N	\N	\N
1706	Brian	Griffiths	1941-12-27	\N	\N	8	1	\N	\N	\N
1707	Hector	Laing	1923-05-12	2010-06-21	\N	13	1	\N	\N	\N
1708	Joan Anna Dalziel	Seccombe	1930-05-03	\N	\N	20	2	\N	\N	\N
1709	David	Wolfson	1935-11-09	2021-03-10	\N	24	1	\N	\N	\N
1710	Meghnad Jagdishchandra	Desai	1940-07-10	\N	\N	5	1	\N	\N	\N
1711	Sally Rachel	Hamwee	1947-01-12	\N	\N	9	2	\N	\N	\N
1713	Frank Ashcroft	Judd	1935-03-28	2021-04-17	\N	11	1	\N	\N	\N
1714	Jean	Denton	1935-12-29	2001-02-05	\N	5	2	\N	\N	\N
1715	Jennifer	Hilton	1936-01-12	\N	\N	9	2	\N	\N	\N
1716	Ann	Mallalieu	1945-11-27	\N	\N	14	2	\N	\N	\N
1717	Clive Richard	Hollick	1945-05-20	\N	\N	9	1	\N	\N	\N
1718	Detta	O'Cathain	1938-02-03	2021-04-23	\N	16	2	\N	\N	\N
1719	Andrew Colin	Renfrew	1937-07-25	\N	\N	19	1	\N	\N	\N
1720	John Jackson	Mackay	1938-11-15	2001-02-21	\N	14	1	\N	\N	\N
1722	Pauline	Perry	1931-10-15	\N	\N	17	2	\N	\N	\N
1724	Norman Somerville	Macfarlane	1926-03-05	\N	\N	14	1	\N	\N	\N
1725	David Brownrigg	Craig	1929-09-17	\N	\N	4	1	\N	\N	\N
1726	Nicolas Christopher Henry	Browne-Wilkinson	1930-03-30	2018-07-25	\N	3	1	\N	\N	\N
1727	Michael John	Mustill	1931-05-10	2015-04-24	\N	14	1	\N	\N	\N
1728	Brian Norman Roger	Rix	1924-01-27	2016-08-20	\N	19	1	\N	\N	\N
1729	Reginald Ernest	Prentice	1923-07-16	2001-01-18	\N	17	1	\N	\N	\N
1730	David Clive	Wilson	1935-02-14	\N	\N	24	1	\N	\N	\N
1732	John	Wakeham	1932-06-22	\N	\N	24	1	\N	\N	\N
1733	Lynda	Chalker	1942-04-29	\N	\N	4	2	\N	\N	\N
1734	Peter Murray	Taylor	1930-05-01	1997-04-28	\N	21	1	\N	\N	\N
1735	Alan Ferguson	Rodger	1944-09-18	2011-06-26	\N	19	1	\N	\N	\N
1736	Margaret Hilda	Thatcher	1925-10-13	2013-04-08	\N	21	2	\N	\N	\N
1630	Frederick Sydney	Dainton	1914-11-11	1997-12-05	\N	5	1	\N	\N	\N
1739	Peter Stewart	Lane	1925-01-29	2009-01-09	\N	13	1	\N	\N	\N
1740	Nigel	Lawson	1932-03-11	\N	\N	13	1	\N	\N	\N
1742	John Edward Michael	Moore	1937-11-26	2019-05-20	\N	14	1	\N	\N	\N
1743	Norman Beresford	Tebbit	1931-03-29	\N	\N	21	1	\N	\N	\N
1744	George Kenneth Hotson	Younger	1931-09-22	2003-01-26	\N	26	1	\N	\N	\N
1745	Julian	Amery	1919-03-27	1996-09-03	\N	2	1	\N	\N	\N
1746	Peter Edward	Walker	1932-03-25	2010-06-23	\N	24	1	\N	\N	\N
1747	Peter Kingsley	Archer	1926-11-20	2012-06-14	\N	2	1	\N	\N	\N
1748	Jack	Ashley	1922-12-06	2012-04-20	\N	2	1	\N	\N	\N
1750	Bruce Bernard	Weatherill	1920-11-25	2007-05-06	\N	24	1	\N	\N	\N
1751	Harry	Ewing	1931-01-20	2007-06-09	\N	6	1	\N	\N	\N
1752	Geraint Wyn	Howells	1925-04-15	2004-04-17	\N	9	1	\N	\N	\N
1754	William Gibson Haig	Clark	1917-10-18	2004-10-04	\N	4	1	\N	\N	\N
1755	Raymond	Plant	1945-03-19	\N	\N	17	1	\N	\N	\N
1756	Jeffrey Howard	Archer	1940-04-15	\N	\N	2	1	\N	\N	\N
1757	Nicholas	Ridley	1929-02-17	1993-03-04	\N	19	1	\N	\N	\N
1758	Margaret Ann	Jay	1939-11-18	\N	\N	11	2	\N	\N	\N
1759	Gareth Wyn	Williams	1941-02-05	2003-09-20	\N	24	1	\N	\N	\N
1760	Bernard Richard	Braine	1914-06-24	2000-01-05	\N	3	1	\N	\N	\N
1761	Victor Alexander	Cooke	1920-10-18	2007-11-13	\N	4	1	\N	\N	\N
1763	Bernard John	Hayhoe	1925-08-08	2013-09-07	\N	9	1	\N	\N	\N
1764	Dafydd Elis	Elis-Thomas	1946-10-18	\N	\N	6	1	\N	\N	\N
1766	Robert	Leigh-Pemberton	1927-01-05	2013-11-24	\N	13	1	\N	\N	\N
1767	Ralf	Dahrendorf	1929-05-01	2009-06-17	\N	5	1	\N	\N	\N
1768	Yehudi	Menuhin	1916-04-22	1999-03-12	\N	14	1	\N	\N	\N
1769	Richard Samuel	Attenborough	1923-08-29	2014-08-24	\N	2	1	\N	\N	\N
1770	Anthony John Leslie	Lloyd	1929-05-09	\N	\N	13	1	\N	\N	\N
1771	Simon	Haskel	1934-10-09	\N	\N	9	1	\N	\N	\N
1773	Joyce Brenda	Gould	1932-10-29	\N	\N	8	2	\N	\N	\N
1774	Robert William	Dixon-Smith	1934-09-30	\N	\N	5	1	\N	\N	\N
1775	Cecil Edward	Parkinson	1931-09-01	2016-01-22	\N	17	1	\N	\N	\N
1776	Denis Winston	Healey	1917-08-30	2015-10-03	\N	9	1	\N	\N	\N
1777	David Anthony Llewellyn	Owen	1938-07-02	\N	\N	16	1	\N	\N	\N
1778	Michael Patrick	Nolan	1928-09-10	2007-01-22	\N	15	1	\N	\N	\N
1780	David Wigley	Nickson	1929-11-27	\N	\N	15	1	\N	\N	\N
1781	Charles Randolph	Quirk	1920-07-12	2017-12-20	\N	18	1	\N	\N	\N
1782	David Chilton	Phillips	1924-03-07	1999-02-23	\N	17	1	\N	\N	\N
1783	Allen John George	Sheppard	1932-12-25	2015-03-25	\N	20	1	\N	\N	\N
1784	Charles Eric Alexander	Hambro	1930-07-24	2002-11-07	\N	9	1	\N	\N	\N
1785	Alfred	Dubs	1932-12-05	\N	\N	5	1	\N	\N	\N
1786	Josephine	Farrington	1940-06-29	2018-03-30	\N	7	2	\N	\N	\N
1787	Michael Norman	Shaw	1920-10-09	2021-01-08	\N	20	1	\N	\N	\N
1788	Graham Norman	Tope	1943-11-30	\N	\N	21	1	\N	\N	\N
1790	Susan Petronella	Thomas	1935-12-20	\N	\N	21	2	\N	\N	\N
1791	Christopher James	Prout	1942-01-01	2009-07-12	\N	17	1	\N	\N	\N
1792	Peter Allan Renshaw	Blaker	1922-10-04	2009-07-05	\N	3	1	\N	\N	\N
1793	Johan van Zyl	Steyn	1932-08-15	2017-11-28	\N	20	1	\N	\N	\N
1794	Sarah Elizabeth Mary	Hogg	1946-05-14	\N	\N	9	2	\N	\N	\N
1795	Robert William Brian	McConnell	1922-11-25	2000-10-25	\N	14	1	\N	\N	\N
1796	Elizabeth Margaret	Smith	1940-06-04	\N	\N	20	2	\N	\N	\N
1797	Leonard Hubert	Hoffmann	1934-05-08	\N	\N	9	1	\N	\N	\N
1798	James	Blyth	1940-05-08	\N	\N	3	1	\N	\N	\N
1800	Robert Henry Alexander	Eames	1937-04-27	\N	\N	6	1	\N	\N	\N
1802	Donald Sage	Mackay	1946-01-30	2018-08-21	\N	14	1	\N	\N	\N
1803	Robert Maurice Lipson	Winston	1940-07-15	\N	\N	24	1	\N	\N	\N
1804	William John Lawrence	Wallace	1941-03-12	\N	\N	24	1	\N	\N	\N
1805	Tom	McNally	1943-02-20	\N	\N	14	1	\N	\N	\N
1806	Gordon Johnson	Borrie	1931-03-13	2016-09-30	\N	3	1	\N	\N	\N
1807	Helene Valerie	Hayman	1949-03-26	\N	\N	9	2	\N	\N	\N
1808	John Buttifant	Sewel	1946-01-15	\N	\N	20	1	\N	\N	\N
1809	Philip Charles	Harris	1942-09-15	\N	\N	9	1	\N	\N	\N
1811	Basil	Feldman	1926-09-23	2019-11-19	\N	7	1	\N	\N	\N
1812	Judith Ann	Wilcox	1940-10-31	\N	\N	24	2	\N	\N	\N
1813	Peter Spencer	Bowness	1943-05-19	\N	\N	3	1	\N	\N	\N
1814	Dick	Taverne	1928-10-18	\N	\N	21	1	\N	\N	\N
1815	Anthony Paul	Lester	1936-07-03	2020-08-08	\N	13	1	\N	\N	\N
1816	Doreen	Miller	1933-06-13	2014-06-21	\N	14	2	\N	\N	\N
1817	Christopher Samuel	Tugendhat	1937-02-23	\N	\N	21	1	\N	\N	\N
1818	June Kathleen	Lloyd	1928-01-01	2006-06-28	\N	13	2	\N	\N	\N
1820	Marmaduke James	Hussey	1923-08-29	2006-12-27	\N	9	1	\N	\N	\N
1821	Donald Martin	Thomas	1937-03-13	\N	\N	21	1	\N	\N	\N
1822	James John	Clyde	1932-01-29	2009-03-06	\N	4	1	\N	\N	\N
1823	David Anthony	Currie	1946-12-09	\N	\N	4	1	\N	\N	\N
1824	John David Beckett	Taylor	1952-09-21	\N	\N	21	1	\N	\N	\N
1825	Maurice	Saatchi	1946-06-21	\N	\N	20	1	\N	\N	\N
1827	John	Alderdice	1955-03-28	\N	\N	2	1	\N	\N	\N
1828	Swraj	Paul	1931-02-18	\N	\N	17	1	\N	\N	\N
1829	Meta	Ramsay	1936-07-12	\N	\N	19	2	\N	\N	\N
1831	Hazel	Byford	1941-01-14	\N	\N	3	2	\N	\N	\N
1832	Peter Selwyn	Gummer	1942-08-24	\N	\N	8	1	\N	\N	\N
1833	Ian Charter	MacLaurin	1937-03-30	\N	\N	14	1	\N	\N	\N
1834	John Lawrence	Whitty	1943-06-15	\N	\N	24	1	\N	\N	\N
1835	Raj Kumar	Bagri	1930-08-24	2017-04-26	\N	3	1	\N	\N	\N
1837	Andrew	Lloyd Webber	1948-03-22	\N	\N	13	1	\N	\N	\N
1838	Eric Douglas Harvey	Hoyle	1930-02-17	\N	\N	9	1	\N	\N	\N
1839	Charles Leslie	Falconer	1951-11-19	\N	\N	7	1	\N	\N	\N
1840	David Alec Gwyn	Simon	1939-07-24	\N	\N	20	1	\N	\N	\N
1841	John William	Gilbert	1927-04-05	2013-06-02	\N	8	1	\N	\N	\N
1842	William John	Biffen	1930-11-10	2007-08-14	\N	3	1	\N	\N	\N
1843	Andrew Rutherford	Hardie	1946-01-08	\N	\N	9	1	\N	\N	\N
1844	Joan	Lestor	1931-11-13	1998-03-27	\N	13	2	\N	\N	\N
1845	Thomas Michael	Jopling	1930-12-10	\N	\N	11	1	\N	\N	\N
1846	Peter David	Shore	1924-05-20	2001-09-24	\N	20	1	\N	\N	\N
1848	David Martin Scott	Steel	1938-03-31	\N	\N	20	1	\N	\N	\N
1738	Barbara Anne	Castle	1910-10-06	2002-05-03	\N	4	2	\N	\N	\N
2860	Henry Charles	Brougham	1836-09-02	1927-05-24	\N	3	1	\N	\N	\N
1851	John	Evans	1930-10-19	2016-03-05	\N	6	1	\N	\N	\N
1852	James Henry	Molyneaux	1920-08-27	2015-03-09	\N	14	1	\N	\N	\N
1854	David Howe	Gillmore	1934-08-16	1999-03-20	\N	8	1	\N	\N	\N
1856	Thomas Henry	Bingham	1933-10-13	2010-09-11	\N	3	1	\N	\N	\N
1857	Peter Anthony	Inge	1935-08-05	\N	\N	10	1	\N	\N	\N
1858	David Russell	Russell-Johnston	1932-07-28	2008-07-27	\N	19	1	\N	\N	\N
1859	Peter Keith	Levene	1941-12-08	\N	\N	13	1	\N	\N	\N
1860	Mark Oliver	Saville	1936-03-20	\N	\N	20	1	\N	\N	\N
1861	Michael Abraham	Levy	1944-07-11	\N	\N	13	1	\N	\N	\N
1862	Joan Christabel Jill	Knight	1927-07-09	\N	\N	12	2	\N	\N	\N
1863	Valerie Ann	Amos	1954-03-13	\N	\N	2	2	\N	\N	\N
1864	Norman	Hogg	1938-03-12	2008-10-08	\N	9	1	\N	\N	\N
1866	Robin William	Renwick	1937-12-13	\N	\N	19	1	\N	\N	\N
1867	Harold	Walker	1927-07-12	2003-11-11	\N	24	1	\N	\N	\N
1868	Peter	Hardy	1931-07-17	2003-12-16	\N	9	1	\N	\N	\N
1869	Robert	Hughes	1932-01-03	\N	\N	9	1	\N	\N	\N
1870	James Alexander	Douglas-Hamilton	1942-07-31	\N	\N	5	1	\N	\N	\N
1871	Ian Bruce	Lang	1940-06-27	\N	\N	13	1	\N	\N	\N
1872	Sarah Ann	Ludford	1951-03-14	\N	\N	13	2	\N	\N	\N
1873	Janet Evelyn	Fookes	1936-02-21	\N	\N	7	2	\N	\N	\N
1874	David Garfield	Davies	1935-06-24	2019-03-04	\N	5	1	\N	\N	\N
1877	David John	Sainsbury	1940-10-24	\N	\N	20	1	\N	\N	\N
1878	Bryan	Davies	1939-11-09	\N	\N	5	1	\N	\N	\N
1879	James Stuart	Gordon	1936-05-17	2020-03-31	\N	8	1	\N	\N	\N
1880	John Ambrose	Cope	1937-05-13	\N	\N	4	1	\N	\N	\N
1881	Jill Elizabeth	Pitkeathley	1940-01-04	\N	\N	17	2	\N	\N	\N
1882	Alfred	Morris	1928-03-23	2012-08-12	\N	14	1	\N	\N	\N
1883	David Anthony	Jacobs	1931-11-13	2014-06-21	\N	11	1	\N	\N	\N
1884	Philip Alexander	Hunt	1949-05-19	\N	\N	9	1	\N	\N	\N
1885	David James Fletcher	Hunt	1942-05-21	\N	\N	9	1	\N	\N	\N
1886	Stanley	Orme	1923-04-05	2005-04-28	\N	16	1	\N	\N	\N
1888	Edward Timothy	Razzall	1943-06-12	\N	\N	19	1	\N	\N	\N
1889	William Howard	Goodhart	1933-01-18	2017-01-10	\N	8	1	\N	\N	\N
1890	Clive	Brooke	1942-06-21	\N	\N	3	1	\N	\N	\N
1891	Ruth Barbara	Rendell	1930-02-17	2015-05-02	\N	19	2	\N	\N	\N
1892	Navnit	Dholakia	1937-03-04	\N	\N	5	1	\N	\N	\N
1893	Royston John	Hughes	1925-06-09	2003-12-19	\N	9	1	\N	\N	\N
1894	Douglas Richard	Hurd	1930-03-08	\N	\N	9	1	\N	\N	\N
1895	Kenneth Wilfred	Baker	1934-11-03	\N	\N	3	1	\N	\N	\N
1897	Andrew Zelig	Stone	1942-09-07	\N	\N	20	1	\N	\N	\N
1898	Roger Norman	Freeman	1942-05-27	\N	\N	7	1	\N	\N	\N
1899	Patricia Janet	Scotland	1955-08-19	\N	\N	20	2	\N	\N	\N
1901	Michael Jacob	Montague	1932-03-10	1999-11-05	\N	14	1	\N	\N	\N
1902	Veronica	Linklater	1943-04-15	\N	\N	13	2	\N	\N	\N
1903	John Steven	Bassam	1953-06-11	\N	\N	3	1	\N	\N	\N
1904	Barbara Scott	Young	1948-04-08	\N	\N	26	2	\N	\N	\N
1906	Terence James	Thomas	1937-10-19	2018-07-01	\N	21	1	\N	\N	\N
1907	George	Simpson	1942-07-02	\N	\N	20	1	\N	\N	\N
1908	David Geoffrey Nigel	Filkin	1944-07-01	\N	\N	7	1	\N	\N	\N
1909	Hector Seymour Peter	Monro	1922-10-04	2006-08-30	\N	14	1	\N	\N	\N
1910	Michael Goodall	Watson	1949-05-01	\N	\N	24	1	\N	\N	\N
1911	Richard Andrew	Ryder	1949-02-04	\N	\N	19	1	\N	\N	\N
1912	Roy Sydney George	Hattersley	1932-12-28	\N	\N	9	1	\N	\N	\N
1913	Francis Patrick	Neill	1926-08-08	2016-05-28	\N	15	1	\N	\N	\N
1914	Frederick Edward Robin	Butler	1938-01-03	\N	\N	3	1	\N	\N	\N
1916	Brian	Mackenzie	1943-03-21	\N	\N	14	1	\N	\N	\N
1917	Timothy Francis	Clement-Jones	1949-10-26	\N	\N	4	1	\N	\N	\N
1918	Waheed	Alli	1964-11-16	\N	\N	2	1	\N	\N	\N
1919	Manzila Pola	Uddin	1959-07-17	\N	\N	22	2	\N	\N	\N
1920	Colin Marsh	Marshall	1933-11-16	2012-07-05	\N	14	1	\N	\N	\N
1921	Terence	Burns	1944-03-13	\N	\N	3	1	\N	\N	\N
1922	Mary Teresa	Goudie	1946-09-02	\N	\N	8	2	\N	\N	\N
1923	John Edward	Tomlinson	1939-08-01	\N	\N	21	1	\N	\N	\N
1925	Dorothea Glenys	Thornton	1952-10-16	\N	\N	21	2	\N	\N	\N
1926	Norman Stewart Hughson	Lamont	1942-05-08	\N	\N	13	1	\N	\N	\N
1927	Christine Mary	Crawley	1950-01-01	\N	\N	4	2	\N	\N	\N
1928	Andrew Wyndham	Phillips	1939-03-15	\N	\N	17	1	\N	\N	\N
1930	William Herbert	Laming	1936-07-19	\N	\N	13	1	\N	\N	\N
1931	William Stephen Goulden	Bach	1946-12-25	\N	\N	3	1	\N	\N	\N
1932	Susan Elizabeth	Miller	1954-01-01	\N	\N	14	2	\N	\N	\N
1933	David Charles	Evans	1942-11-30	\N	\N	6	1	\N	\N	\N
1935	Michael Wolfgang Laurence	Morris	1936-11-25	\N	\N	14	1	\N	\N	\N
1936	Terence Langley	Higgins	1928-01-18	\N	\N	9	1	\N	\N	\N
1937	Paul Edward Winston	White	1940-09-16	\N	\N	24	1	\N	\N	\N
1938	Timothy John Leigh	Bell	1941-10-18	2019-08-25	\N	3	1	\N	\N	\N
1939	Philip	Norton	1951-03-05	\N	\N	15	1	\N	\N	\N
1940	Margaret Lucy	Sharp	1938-11-21	\N	\N	20	2	\N	\N	\N
1941	Nazir	Ahmed	1957-04-24	\N	\N	2	1	\N	\N	\N
1942	Melvyn	Bragg	1939-10-06	\N	\N	3	1	\N	\N	\N
1944	David Francis	Williamson	1934-05-08	2015-08-30	\N	24	1	\N	\N	\N
1945	Nicholas Addison	Phillips	1938-01-21	\N	\N	17	1	\N	\N	\N
1946	Angus John	Macdonald	1940-08-20	\N	\N	14	1	\N	\N	\N
1947	Peter Michael	Imbert	1933-04-27	2017-11-13	\N	10	1	\N	\N	\N
1948	John Stewart	Hobhouse	1932-01-31	2004-03-15	\N	9	1	\N	\N	\N
1949	Peter Julian	Millett	1932-06-23	2021-05-27	\N	14	1	\N	\N	\N
1950	Onora Sylvia	O'Neill	1941-08-23	\N	\N	16	2	\N	\N	\N
1953	Diana Mary	Warwick	1945-07-16	\N	\N	24	2	\N	\N	\N
1954	Robert	Fellowes	1941-12-11	\N	\N	7	1	\N	\N	\N
1955	Henry Dennistoun	Stevenson	1945-07-19	\N	\N	20	1	\N	\N	\N
1956	Vivien Helen	Stern	1941-09-25	\N	\N	20	2	\N	\N	\N
1957	Michael Bruce	Forsyth	1954-10-16	\N	\N	7	1	\N	\N	\N
1958	Richard Oliver	Faulkner	1946-03-22	\N	\N	7	1	\N	\N	\N
1959	Usha Kumari	Prashar	1948-06-29	\N	\N	17	2	\N	\N	\N
1961	John Dunn	Laird	1944-04-23	2018-07-10	\N	13	1	\N	\N	\N
1850	Ronald Timothy	Renton	1932-05-28	2020-08-25	\N	19	1	\N	\N	\N
2861	Victor Henry Peter	Brougham	1909-10-23	1967-06-20	\N	3	1	\N	\N	\N
1964	David Edward	Lea	1937-11-02	\N	\N	13	1	\N	\N	\N
1965	William Henry	Brett	1942-03-06	2012-03-29	\N	3	1	\N	\N	\N
1967	William Peter	Bradshaw	1936-09-09	\N	\N	3	1	\N	\N	\N
1968	Tarsem	King	1937-04-24	2013-01-09	\N	12	1	\N	\N	\N
1969	Alan John	Watson	1941-02-03	\N	\N	24	1	\N	\N	\N
1970	Graham	Kirkham	1944-12-14	\N	\N	12	1	\N	\N	\N
1972	Doreen Elizabeth	Massey	1938-09-05	\N	\N	14	2	\N	\N	\N
1973	Alexander Charles	Carlile	1948-02-12	\N	\N	4	1	\N	\N	\N
1974	Anthony James	Clarke	1932-04-17	\N	\N	4	1	\N	\N	\N
1975	Anthony Martin Grosvenor	Christopher	1925-04-25	\N	\N	4	1	\N	\N	\N
1976	David Keith	Brookman	1937-01-03	\N	\N	3	1	\N	\N	\N
1977	David Lawrence	Lipsey	1948-04-21	\N	\N	13	1	\N	\N	\N
1979	May	Blood	1938-05-26	\N	\N	3	2	\N	\N	\N
1980	Elizabeth Jean	Barker	1961-01-31	\N	\N	3	2	\N	\N	\N
1981	Catherine Margaret	Ashton	1956-03-20	\N	\N	2	2	\N	\N	\N
1982	Genista Mary	McIntosh	1946-09-23	\N	\N	14	2	\N	\N	\N
1983	Kenneth John	Woolmer	1940-04-25	\N	\N	24	1	\N	\N	\N
1984	Anita	Gale	1940-11-28	\N	\N	8	2	\N	\N	\N
1985	Hector Uisdean	MacKenzie	1940-02-25	\N	\N	14	1	\N	\N	\N
1987	Janet Alison	Whitaker	1936-02-20	\N	\N	24	2	\N	\N	\N
1988	Robert	Gavron	1930-09-13	2015-02-07	\N	8	1	\N	\N	\N
1989	Angela Felicity	Harris	1944-01-04	\N	\N	9	2	\N	\N	\N
1990	George Islay MacNeill	Robertson	1946-04-12	\N	\N	19	1	\N	\N	\N
1991	Rupert Bertram	Mitford	1967-07-18	\N	\N	14	1	\N	\N	\N
1993	James Thorne	Erskine	1949-03-10	\N	\N	6	1	\N	\N	\N
1994	Frederick Matthew Thomas	Ponsonby	1958-10-27	\N	\N	17	1	\N	\N	\N
1995	William Brian	Jordan	1936-01-28	\N	\N	11	1	\N	\N	\N
1996	Sheila Valerie	Masters	1949-06-23	\N	\N	14	2	\N	\N	\N
1997	Robin Granville	Hodgson	1942-04-25	\N	\N	9	1	\N	\N	\N
1998	Kenneth Owen	Morgan	1934-05-16	\N	\N	14	1	\N	\N	\N
2000	Richard Napier	Luce	1936-10-14	\N	\N	13	1	\N	\N	\N
2001	Michael Anthony	Ashcroft	1946-03-04	\N	\N	2	1	\N	\N	\N
2002	Betty	Boothroyd	1929-10-08	\N	\N	3	2	\N	\N	\N
2003	Austin Richard William	Low	1914-05-25	2000-12-07	\N	13	1	\N	\N	\N
2004	Frederick James	Erroll	1914-05-27	2000-09-14	\N	6	1	\N	\N	\N
2005	Matthew Alan	Oakeshott	1947-01-10	\N	\N	16	1	\N	\N	\N
2007	Lyndon Henry Arthur	Harrison	1947-09-28	\N	\N	9	1	\N	\N	\N
2008	William Arthur	Waldegrave	1946-08-15	\N	\N	24	1	\N	\N	\N
2009	Peter Henry	Goldsmith	1950-01-05	\N	\N	8	1	\N	\N	\N
2010	John Julian	Ganzoni	1932-09-30	2005-12-03	\N	8	1	\N	\N	\N
2012	Peter Alexander Rupert	Carington	1919-06-06	2018-07-09	\N	4	1	\N	\N	\N
2013	Leon	Brittan	1939-09-25	2015-01-21	\N	3	1	\N	\N	\N
2014	Sally Ralea	Greengross	1935-06-29	\N	\N	8	2	\N	\N	\N
2015	John	Birt	1944-12-10	\N	\N	3	1	\N	\N	\N
2016	Adam Hafejee	Patel	1940-06-07	2019-05-29	\N	17	1	\N	\N	\N
2017	Charles David	Powell	1941-07-06	\N	\N	17	1	\N	\N	\N
2018	Joel Goodman	Joffe	1932-05-12	2017-06-18	\N	11	1	\N	\N	\N
2019	Richard Gerald	Lyon-Dalberg-Acton	1941-07-30	2010-10-10	\N	13	1	\N	\N	\N
2020	Anne	Gibson	1940-12-10	2018-04-20	\N	8	2	\N	\N	\N
2021	Elizabeth Kay	Andrews	1943-05-16	\N	\N	2	2	\N	\N	\N
2022	Parry Andrew	Mitchell	1943-05-06	\N	\N	14	1	\N	\N	\N
2024	Rosalind Carol	Scott	1957-08-10	\N	\N	20	2	\N	\N	\N
2025	Matthew	Evans	1941-08-07	2016-07-06	\N	6	1	\N	\N	\N
2026	David Trevor	Shutt	1942-03-16	2020-10-30	\N	20	1	\N	\N	\N
2027	John Francis Hodgess	Roper	1935-09-10	2016-01-29	\N	19	1	\N	\N	\N
2028	Joan Margaret	Walmsley	1943-04-12	\N	\N	24	2	\N	\N	\N
2029	Alexander	Bernstein	1936-03-15	2010-04-12	\N	3	1	\N	\N	\N
2031	Sebastian Newbold	Coe	1956-09-29	\N	\N	4	1	\N	\N	\N
2032	Lindsay Patricia	Granshaw	1954-08-21	\N	\N	8	2	\N	\N	\N
2033	Angela Theodora	Billingham	1939-07-31	\N	\N	3	2	\N	\N	\N
2034	Daniel Joseph	Brennan	1942-03-19	\N	\N	3	1	\N	\N	\N
2035	Janet	Cohen	1940-07-04	\N	\N	4	2	\N	\N	\N
2037	Anthony Robert	Greaves	1942-07-27	2021-03-23	\N	8	1	\N	\N	\N
2038	Leslie Arnold	Turnberg	1934-03-22	\N	\N	21	1	\N	\N	\N
2039	Julian Charles Roland	Hunt	1941-09-05	\N	\N	9	1	\N	\N	\N
2040	Michael Chew Koon	Chan	1940-03-06	2006-01-21	\N	4	1	\N	\N	\N
2041	Richard Stuart	Best	1945-06-22	\N	\N	3	1	\N	\N	\N
2042	David James George	Hennessy	1932-01-28	2010-12-21	\N	9	1	\N	\N	\N
2043	Robert Edward	Sheldon	1923-09-13	2020-02-03	\N	20	1	\N	\N	\N
2044	Claus Adolf	Moser	1922-11-24	2015-09-04	\N	14	1	\N	\N	\N
2046	Herman George	Ouseley	1945-03-24	\N	\N	16	1	\N	\N	\N
2047	Charles Ronald Llewelyn	Guthrie	1938-11-17	\N	\N	8	1	\N	\N	\N
2049	Ilora Gillian	Finlay	1949-02-23	\N	\N	7	2	\N	\N	\N
2050	Edmund John Phillip	Browne	1948-02-20	\N	\N	3	1	\N	\N	\N
2051	Stewart Ross	Sutherland	1941-02-25	2018-01-29	\N	20	1	\N	\N	\N
2053	Bruce Joseph	Grocott	1940-11-01	\N	\N	8	1	\N	\N	\N
2054	David George	Clark	1939-10-19	\N	\N	4	1	\N	\N	\N
2055	Peter Norman	Fowler	1938-02-02	\N	\N	7	1	\N	\N	\N
2056	Thomas	Pendry	1934-06-10	\N	\N	17	1	\N	\N	\N
2057	Dale Norman	Campbell-Savours	1943-08-23	\N	\N	4	1	\N	\N	\N
2058	John Roddick Russell	MacGregor	1937-02-14	\N	\N	14	1	\N	\N	\N
2059	Robin	Corbett	1933-12-22	2012-02-19	\N	4	1	\N	\N	\N
2060	Stephen Barry	Jones	1937-06-26	\N	\N	11	1	\N	\N	\N
2062	Jeremy John Durham	Ashdown	1941-02-27	2018-12-22	\N	2	1	\N	\N	\N
2063	Ronald Cyril	Fearn	1931-02-06	\N	\N	7	1	\N	\N	\N
2064	Michael Ray Dibdin	Heseltine	1933-03-21	\N	\N	9	1	\N	\N	\N
2065	Janet Ray	Michie	1934-02-04	2008-05-06	\N	14	2	\N	\N	\N
2066	Giles Heneage	Radice	1936-10-04	\N	\N	19	1	\N	\N	\N
2067	John David	Taylor	1937-12-24	\N	\N	21	1	\N	\N	\N
2070	Llinos	Golding	1933-03-21	\N	\N	8	2	\N	\N	\N
2071	Kenneth Wiggins	Maginnis	1938-01-21	\N	\N	14	1	\N	\N	\N
2072	Richard Arthur Lloyd	Livsey	1935-05-02	2010-09-15	\N	13	1	\N	\N	\N
1963	Thomas Murray	Elder	1950-05-09	\N	\N	6	1	\N	\N	\N
2862	Michael John	Brougham	1938-08-02	\N	\N	3	1	\N	\N	\N
2077	Michael Cecil	Boyce	1943-04-02	\N	\N	3	1	\N	\N	\N
2078	William Douglas	Cullen	1935-11-18	\N	\N	4	1	\N	\N	\N
2079	David Maxim	Triesman	1943-10-30	\N	\N	21	1	\N	\N	\N
2080	Susan Adele	Greenfield	1950-10-01	\N	\N	8	2	\N	\N	\N
2081	David Hugh Alexander	Hannay	1935-09-28	\N	\N	9	1	\N	\N	\N
2082	Sally	Morgan	1959-06-28	\N	\N	14	2	\N	\N	\N
2084	Denis	Tunnicliffe	1943-01-17	\N	\N	21	1	\N	\N	\N
2085	Sushantha Kumar	Bhattacharyya	1940-06-06	2019-03-01	\N	3	1	\N	\N	\N
2086	Timothy	Garden	1944-04-23	2007-08-09	\N	8	1	\N	\N	\N
2087	Greville Patrick Charles	Howard	1941-04-22	\N	\N	9	1	\N	\N	\N
2088	Garry Richard Rushby	Hart	1940-06-29	2017-08-03	\N	9	1	\N	\N	\N
2089	Alexander Park	Leitch	1947-10-20	\N	\N	13	1	\N	\N	\N
2090	Philip	Gould	1950-03-30	2011-11-06	\N	8	1	\N	\N	\N
2092	Peter Charles	Snape	1942-02-12	\N	\N	20	1	\N	\N	\N
2093	Patricia	Morris	1953-01-16	\N	\N	14	2	\N	\N	\N
2094	Peter Derek	Truscott	1959-03-20	\N	\N	21	1	\N	\N	\N
2095	Margaret Mary	Wall	1941-11-14	2017-01-25	\N	24	2	\N	\N	\N
2096	Margaret Theresa	Prosser	1937-08-22	\N	\N	17	2	\N	\N	\N
2097	Delyth Jane	Morgan	1961-08-30	\N	\N	14	2	\N	\N	\N
2098	Richard Andrew	Rosser	1944-10-05	\N	\N	19	1	\N	\N	\N
2100	John Roger	Roberts	1935-10-23	\N	\N	19	1	\N	\N	\N
2101	Anthony	Giddens	1938-01-18	\N	\N	8	1	\N	\N	\N
2103	Elaine	Murphy	1947-01-16	\N	\N	14	2	\N	\N	\N
2104	John Alston	Maxton	1936-05-05	\N	\N	14	1	\N	\N	\N
2105	Edward Enda	Haughey	1944-01-05	2014-03-13	\N	9	1	\N	\N	\N
2106	William David	McKenzie	1946-07-24	\N	\N	14	1	\N	\N	\N
2107	Hugh John Maxwell	Dykes	1939-05-17	\N	\N	5	1	\N	\N	\N
2108	Alec Nigel	Broers	1938-09-17	\N	\N	3	1	\N	\N	\N
2109	Margaret Omolola	Young	1951-06-01	\N	\N	26	2	\N	\N	\N
2110	Iain David Thomas	Vallance	1943-05-20	\N	\N	23	1	\N	\N	\N
2112	Jane	Bonham Carter	1957-10-20	\N	\N	3	2	\N	\N	\N
2113	Nicola Jane	Chapman	1961-08-03	2009-09-03	\N	4	2	\N	\N	\N
2114	Anthony Ian	Young	1942-04-16	\N	\N	26	1	\N	\N	\N
2115	Janet Anne	Royall	1955-08-20	\N	\N	19	2	\N	\N	\N
2117	Alan Robert	Haworth	1948-04-26	\N	\N	9	1	\N	\N	\N
2118	Ewen James Hanning	Cameron	1949-11-24	\N	\N	4	1	\N	\N	\N
2119	Edward Alan John	George	1938-09-11	2009-04-18	\N	8	1	\N	\N	\N
2120	John Olav	Kerr	1942-02-22	\N	\N	12	1	\N	\N	\N
2122	Harold Stanley	Kalms	1931-11-21	\N	\N	12	1	\N	\N	\N
2123	David Michael	Hope	1940-04-14	\N	\N	9	1	\N	\N	\N
2124	John Arthur	Stevens	1942-10-21	\N	\N	20	1	\N	\N	\N
2125	Andrew	Adonis	1963-02-22	\N	\N	2	1	\N	\N	\N
2126	David John	Ramsbotham	1934-11-06	\N	\N	19	1	\N	\N	\N
2127	Irene Tordoff	Fritchie	1942-04-29	\N	\N	7	2	\N	\N	\N
2129	Winifred Ann	Taylor	1947-07-02	\N	\N	21	2	\N	\N	\N
2130	Estelle	Morris	1952-06-17	\N	\N	14	2	\N	\N	\N
2131	Alan Thomas	Howarth	1944-06-11	\N	\N	9	1	\N	\N	\N
2132	Paul Archer	Tyler	1941-10-29	\N	\N	21	1	\N	\N	\N
2133	George	Foulkes	1942-01-21	\N	\N	7	1	\N	\N	\N
2134	Derek	Foster	1937-06-15	2019-01-06	\N	7	1	\N	\N	\N
2135	Archibald Gavin	Hamilton	1941-12-30	\N	\N	9	1	\N	\N	\N
2137	Nigel David	Jones	1948-03-30	\N	\N	11	1	\N	\N	\N
2138	Dennis	Turner	1942-08-26	2014-02-25	\N	21	1	\N	\N	\N
2139	Lynda Margaret	Clark	1949-02-26	\N	\N	4	2	\N	\N	\N
2141	Christopher Robert	Smith	1951-07-24	\N	\N	20	1	\N	\N	\N
2142	Jennifer Louise	Tonge	1941-02-19	\N	\N	21	2	\N	\N	\N
2143	Anthony Louis	Banks	1943-04-08	2006-01-08	\N	3	1	\N	\N	\N
2144	Brian Stanley	Mawhinney	1940-07-26	2019-11-09	\N	14	1	\N	\N	\N
2145	John Anderson	Cunningham	1939-08-04	\N	\N	4	1	\N	\N	\N
2146	Nicholas Walter	Lyell	1938-12-06	2010-08-30	\N	13	1	\N	\N	\N
2147	Donald	Anderson	1939-06-17	\N	\N	2	1	\N	\N	\N
2148	Katherine Patricia Irene	Adams	1947-12-27	\N	\N	2	2	\N	\N	\N
2149	Clive Stafford	Soley	1939-05-07	\N	\N	20	1	\N	\N	\N
2150	Jean Ann	Corston	1942-05-05	\N	\N	4	2	\N	\N	\N
2152	Martin John	Rees	1942-06-23	\N	\N	19	1	\N	\N	\N
2153	Jonathan Adair	Turner	1955-10-05	\N	\N	21	1	\N	\N	\N
2154	Jonathan Hugh	Mance	1943-06-06	\N	\N	14	1	\N	\N	\N
2155	Ruth Lynn	Deech	1943-04-29	\N	\N	5	2	\N	\N	\N
2157	Andrew	Turnbull	1945-01-21	\N	\N	21	1	\N	\N	\N
2158	Michael John	Hastings	1958-01-29	\N	\N	9	1	\N	\N	\N
2159	Neil Forbes	Davidson	1950-09-13	\N	\N	5	1	\N	\N	\N
2160	Edmund Nigel Ramsay	Crisp	1952-01-14	\N	\N	4	1	\N	\N	\N
2161	David	Alliance	1932-06-15	\N	\N	2	1	\N	\N	\N
2163	Neil Gordon	Kinnock	1942-03-28	\N	\N	12	1	\N	\N	\N
2164	John Patrick Aubone	Burnett	1945-09-19	\N	\N	3	1	\N	\N	\N
2165	Denise Patricia Byrne	Kingsmill	1947-04-24	\N	\N	12	2	\N	\N	\N
2166	Robin	Teverson	1952-03-31	\N	\N	21	1	\N	\N	\N
2167	William David	Trimble	1944-10-15	\N	\N	21	1	\N	\N	\N
2168	Sandip	Verma	1959-06-30	\N	\N	23	2	\N	\N	\N
2169	Margaret Beryl	Jones	1955-05-22	\N	\N	11	2	\N	\N	\N
2170	Margaret Anne	Ford	1957-12-16	\N	\N	7	2	\N	\N	\N
2172	Mohamed Iltaf	Sheikh	1941-06-13	\N	\N	20	1	\N	\N	\N
2173	Maurice George	Morrow	1948-09-27	\N	\N	14	1	\N	\N	\N
2174	Jonathan Peter	Marland	1956-08-14	\N	\N	14	1	\N	\N	\N
2175	Kamlesh Kumar	Patel	1960-09-28	\N	\N	17	1	\N	\N	\N
2176	Alexander John	Bruce-Lockhart	1942-05-04	2008-08-14	\N	3	1	\N	\N	\N
2177	David Noel	James	1937-12-07	\N	\N	11	1	\N	\N	\N
2179	Wallace Hamilton	Browne	1947-10-29	\N	\N	3	1	\N	\N	\N
2181	Eileen Emily	Paisley	1931-11-02	\N	\N	17	2	\N	\N	\N
2182	Colin David	Boyd	1953-06-07	\N	\N	3	1	\N	\N	\N
2183	David Sydney	Rowe-Beddoe	1937-12-19	\N	\N	19	1	\N	\N	\N
2184	Beeban Tania	Kidron	1961-05-02	\N	\N	12	2	\N	\N	\N
2185	Alexander John	Trees	1946-06-12	\N	\N	21	1	\N	\N	\N
2186	Paul Clive	Deighton	1956-01-18	\N	\N	5	1	\N	\N	\N
2187	Rowan Douglas	Williams	1950-06-14	\N	\N	24	1	\N	\N	\N
2074	Robert	Walker	1938-03-17	\N	\N	24	1	\N	\N	\N
2190	Michael Fitzhardinge	Berkeley	1948-05-29	\N	\N	3	1	\N	\N	\N
2191	Ian Paul	Livingston	1964-07-28	\N	\N	13	1	\N	\N	\N
2192	John Rhodes	Horam	1939-03-07	\N	\N	9	1	\N	\N	\N
2193	Rosalind Mary	Grender	1962-08-19	\N	\N	8	2	\N	\N	\N
2195	Jonathan Neil	Mendelsohn	1966-12-30	\N	\N	14	1	\N	\N	\N
2196	Ian William	Wrigglesworth	1939-12-08	\N	\N	24	1	\N	\N	\N
2198	Doreen Delceita	Lawrence	1952-10-24	\N	\N	13	2	\N	\N	\N
2199	Catherine Mary	Bakewell	1949-03-07	\N	\N	3	2	\N	\N	\N
2200	Geoffrey James	Dear	1937-09-20	\N	\N	5	1	\N	\N	\N
2201	Karan Faridoon	Bilimoria	1961-11-26	\N	\N	3	1	\N	\N	\N
2202	Celia Marjorie	Thomas	1945-10-14	\N	\N	21	2	\N	\N	\N
2204	Joyce Gwendolen	Quin	1944-11-26	\N	\N	18	2	\N	\N	\N
2205	David Edmond	Neuberger	1948-01-10	\N	\N	15	1	\N	\N	\N
2206	Jean Elizabeth	Coussins	1950-10-26	\N	\N	4	2	\N	\N	\N
2207	Paul Anthony Elliott	Bew	1950-01-22	\N	\N	3	1	\N	\N	\N
2208	Khalid	Hameed	1941-07-01	\N	\N	9	1	\N	\N	\N
2209	John Richard	Krebs	1945-04-11	\N	\N	12	1	\N	\N	\N
2210	Andrew	Mawson	1954-11-08	\N	\N	14	1	\N	\N	\N
2211	George Mark	Malloch Brown	1953-09-16	\N	\N	14	1	\N	\N	\N
2212	Alan William John	West	1948-04-21	\N	\N	24	1	\N	\N	\N
2213	Shriti	Vadera	1962-06-23	\N	\N	23	2	\N	\N	\N
2215	Ara Warkes	Darzi	1960-05-07	\N	\N	5	1	\N	\N	\N
2216	Robin Berry	Janvrin	1946-09-20	\N	\N	11	1	\N	\N	\N
2217	Sayeeda Hussain	Warsi	1971-03-28	\N	\N	24	2	\N	\N	\N
2219	Susan Elizabeth	Garden	1944-02-22	\N	\N	8	2	\N	\N	\N
2220	James Robert	Wallace	1954-08-25	\N	\N	24	1	\N	\N	\N
2221	Haleh	Afshar	1944-05-21	\N	\N	2	2	\N	\N	\N
2223	Robert Haldane	Smith	1944-08-08	\N	\N	20	1	\N	\N	\N
2224	Elizabeth Lydia	Manningham-Buller	1948-07-14	\N	\N	14	2	\N	\N	\N
2225	Michael Walton	Bates	1961-05-22	\N	\N	3	1	\N	\N	\N
2226	Igor	Judge	1941-05-19	\N	\N	11	1	\N	\N	\N
2227	Peter Benjamin	Mandelson	1953-10-21	\N	\N	14	1	\N	\N	\N
2228	Stephen Andrew	Carter	1964-02-12	\N	\N	4	1	\N	\N	\N
2229	Paul	Myners	1948-04-01	\N	\N	14	1	\N	\N	\N
2231	Susan Catherine	Campbell	1948-10-10	\N	\N	4	2	\N	\N	\N
2232	Evan Mervyn	Davies	1952-11-21	\N	\N	5	1	\N	\N	\N
2233	Anthony Peter	Clarke	1943-05-13	\N	\N	4	1	\N	\N	\N
2234	David Anthony	Freud	1950-06-24	\N	\N	7	1	\N	\N	\N
2235	Glenys Elizabeth	Kinnock	1944-07-07	\N	\N	12	2	\N	\N	\N
2236	Alan Michael	Sugar	1947-03-24	\N	\N	20	1	\N	\N	\N
2238	Michael John	Martin	1945-07-03	2018-04-29	\N	14	1	\N	\N	\N
2239	Nuala Patricia	O'Loan	1951-12-20	\N	\N	16	2	\N	\N	\N
2240	Anthony William	Hall	1951-03-03	\N	\N	9	1	\N	\N	\N
2241	Ajay Kumar	Kakkar	1964-04-28	\N	\N	12	1	\N	\N	\N
2242	Carys Davina	Grey-Thompson	1969-07-26	\N	\N	8	2	\N	\N	\N
2243	Michael George	Bichard	1947-01-31	\N	\N	3	1	\N	\N	\N
2244	Michael Hastings	Jay	1946-06-19	\N	\N	11	1	\N	\N	\N
2245	Michael John Dawson	Walker	1944-07-07	\N	\N	24	1	\N	\N	\N
2247	Simon Adam	Wolfson	1967-10-27	\N	\N	24	1	\N	\N	\N
2248	George Philip	Willis	1941-11-30	\N	\N	24	1	\N	\N	\N
2249	Hilary Jane	Armstrong	1945-11-30	\N	\N	2	2	\N	\N	\N
2250	Ian Richard Kyle	Paisley	1926-04-06	2014-09-12	\N	17	1	\N	\N	\N
2251	Roger John	Liddle	1947-06-14	\N	\N	13	1	\N	\N	\N
2252	Jean Lesley Patricia	Drake	1948-01-16	\N	\N	5	2	\N	\N	\N
2254	John Selwyn	Gummer	1939-11-26	\N	\N	8	1	\N	\N	\N
2255	Dianne	Hayter	1949-09-07	\N	\N	9	2	\N	\N	\N
2256	Thomas McLaughlin	McAvoy	1943-12-14	\N	\N	14	1	\N	\N	\N
2257	James Philip	Knight	1965-03-06	\N	\N	12	1	\N	\N	\N
2258	John Eric	Gardiner	1956-03-17	\N	\N	8	1	\N	\N	\N
2260	Michael James	German	1945-05-08	\N	\N	8	1	\N	\N	\N
2261	Meral	Hussein Ece	1953-10-10	\N	\N	9	2	\N	\N	\N
2263	Floella Karen Yunies	Benjamin	1949-09-23	\N	\N	3	2	\N	\N	\N
2264	Rita Margaret	Donaghy	1944-10-09	\N	\N	5	2	\N	\N	\N
2265	John Matthew Patrick	Hutton	1955-05-06	\N	\N	9	1	\N	\N	\N
2266	Jack Wilson	McConnell	1960-06-30	\N	\N	14	1	\N	\N	\N
2267	James Donnelly	Touhig	1947-12-05	\N	\N	21	1	\N	\N	\N
2268	John Quentin	Davies	1944-05-29	\N	\N	5	1	\N	\N	\N
2270	John Leslie	Prescott	1938-05-31	\N	\N	17	1	\N	\N	\N
2271	Helen Lawrie	Liddell	1950-12-06	\N	\N	13	2	\N	\N	\N
2272	William Michael Hardy	Spicer	1943-01-22	2019-05-29	\N	20	1	\N	\N	\N
2273	Timothy Eric	Boswell	1942-12-02	\N	\N	3	1	\N	\N	\N
2274	Guy Vaughan	Black	1964-08-06	\N	\N	3	1	\N	\N	\N
2275	Angela Frances	Browning	1946-12-04	\N	\N	3	2	\N	\N	\N
2276	Dolar Amarshi	Popat	1953-06-14	\N	\N	17	1	\N	\N	\N
2277	Deborah	Stedman-Scott	1955-11-23	\N	\N	20	2	\N	\N	\N
2279	Alison Margaret	Wolf	1949-10-31	\N	\N	24	2	\N	\N	\N
2280	Jonathan Douglas	Evans	1958-02-17	\N	\N	6	1	\N	\N	\N
2281	Robert James	Rogers	1950-02-05	\N	\N	19	1	\N	\N	\N
2282	Robert Walter	Kerslake	1955-02-28	\N	\N	12	1	\N	\N	\N
2283	Rosalind Miriam	Altmann	1956-04-08	\N	\N	2	2	\N	\N	\N
2284	Andrew James	Dunlop	1959-06-21	\N	\N	5	1	\N	\N	\N
2285	Nathanael Ming-Yan	Wei	1977-01-19	\N	\N	24	1	\N	\N	\N
2286	James Meyer	Sassoon	1955-09-11	\N	\N	20	1	\N	\N	\N
2288	Richard Sanderson	Keen	1954-03-29	\N	\N	12	1	\N	\N	\N
2289	David	Blunkett	1947-06-06	\N	\N	3	1	\N	\N	\N
2291	Philip Roland	Smith	1966-02-16	\N	\N	20	1	\N	\N	\N
2292	Stephen	Gilbert	1963-07-24	\N	\N	8	1	\N	\N	\N
2293	Kenneth Donald John	Macdonald	1953-01-04	\N	\N	14	1	\N	\N	\N
2294	Robert Wilfrid	Stevenson	1947-04-19	\N	\N	20	1	\N	\N	\N
2295	Michael	Howard	1941-07-07	\N	\N	9	1	\N	\N	\N
2296	John Warren	Shipley	1946-07-05	\N	\N	20	1	\N	\N	\N
2298	Kathryn Jane	Parminter	1964-06-24	\N	\N	17	2	\N	\N	\N
2299	Beverley June	Hughes	1950-03-30	\N	\N	9	2	\N	\N	\N
2300	John	Reid	1947-05-08	\N	\N	19	1	\N	\N	\N
2301	Susan Jane	Nye	1955-05-17	\N	\N	15	2	\N	\N	\N
2302	Anna Mary	Healy	1955-05-10	\N	\N	9	2	\N	\N	\N
2189	Martha	Lane Fox	1973-02-10	\N	\N	13	2	\N	\N	\N
2306	Ellen Margaret	Eaton	1942-06-01	\N	\N	6	2	\N	\N	\N
2307	Richard Beecroft	Allan	1966-02-11	\N	\N	2	1	\N	\N	\N
2308	Desmond Henry	Browne	1952-03-22	\N	\N	3	1	\N	\N	\N
2310	John Stephen	Monks	1945-08-05	\N	\N	14	1	\N	\N	\N
2311	Peter John	Hennessy	1947-03-28	\N	\N	9	1	\N	\N	\N
2312	Stephen Keith	Green	1948-11-07	\N	\N	8	1	\N	\N	\N
2313	Michael Andrew Foster Jude	Kerr	1945-07-07	\N	\N	12	1	\N	\N	\N
2314	Robert George Alexander	Balchin	1942-07-31	\N	\N	3	1	\N	\N	\N
2315	Andrew Simon	Feldman	1966-02-25	\N	\N	7	1	\N	\N	\N
2316	Michael John	Dobbs	1948-11-14	\N	\N	5	1	\N	\N	\N
2318	John Kevin	Sharkey	1947-09-24	\N	\N	20	1	\N	\N	\N
2319	Fiona Sara	Shackleton	1956-05-26	\N	\N	20	2	\N	\N	\N
2320	Elizabeth Deirdre	Doocey	1948-05-02	\N	\N	5	2	\N	\N	\N
2321	Susan Veronica	Kramer	1950-07-21	\N	\N	12	2	\N	\N	\N
2322	Patience Jane	Wheatcroft	1951-09-28	\N	\N	24	2	\N	\N	\N
2323	Nicholas Edward	True	1951-07-31	\N	\N	21	1	\N	\N	\N
2324	Alistair Basil	Cooke	1945-04-20	\N	\N	4	1	\N	\N	\N
2325	Judith Anne	Jolly	1951-04-27	\N	\N	11	2	\N	\N	\N
2327	James George Robert	Bridges	1970-07-15	\N	\N	3	1	\N	\N	\N
2328	David Gifford Leathes	Prior	1954-12-03	\N	\N	17	1	\N	\N	\N
2329	Gordon Joshua	Wasserman	1938-07-26	\N	\N	24	1	\N	\N	\N
2330	Rajinder Paul	Loomba	1943-11-13	\N	\N	13	1	\N	\N	\N
2331	Tariq Mahmood	Ahmad	1968-04-03	\N	\N	2	1	\N	\N	\N
2332	Howard Emerson	Flight	1948-06-16	\N	\N	7	1	\N	\N	\N
2334	Michael Nicholson	Lord	1938-10-17	\N	\N	13	1	\N	\N	\N
2336	Elizabeth Rose	Berridge	1972-03-22	\N	\N	3	2	\N	\N	\N
2337	Stanley	Fink	1957-09-15	\N	\N	7	1	\N	\N	\N
2338	Francis Richard	Dannatt	1950-12-23	\N	\N	5	1	\N	\N	\N
2339	Dafydd Wynne	Wigley	1943-04-01	\N	\N	24	1	\N	\N	\N
2340	Raymond Edward Harry	Collins	1954-12-21	\N	\N	4	1	\N	\N	\N
2341	Qurban	Hussain	1956-03-27	\N	\N	9	1	\N	\N	\N
2342	Joan Dawson	Bakewell	1933-04-16	\N	\N	3	2	\N	\N	\N
2344	Jonathan Andrew	Kestenbaum	1961-08-05	\N	\N	12	1	\N	\N	\N
2345	Mair Eluned	Morgan	1967-02-16	\N	\N	14	2	\N	\N	\N
2346	George Morgan	Magan	1945-11-14	\N	\N	14	1	\N	\N	\N
2347	Michael Ian	Grade	1943-03-08	\N	\N	8	1	\N	\N	\N
2348	Anne Caroline	Jenkin	1955-12-08	\N	\N	11	2	\N	\N	\N
2349	Oona Tamsyn	King	1967-10-22	\N	\N	12	2	\N	\N	\N
2350	Jennifer Elizabeth	Randerson	1948-05-26	\N	\N	19	2	\N	\N	\N
2352	Claire	Tyler	1957-06-04	\N	\N	21	2	\N	\N	\N
2353	Graham Eric	Stirrup	1949-12-04	\N	\N	20	1	\N	\N	\N
2354	Bryony Katherine	Worthington	1971-09-19	\N	\N	24	2	\N	\N	\N
2355	Michael David	Bishop	1942-02-10	\N	\N	3	1	\N	\N	\N
2356	David Laurence	Gold	1951-03-01	\N	\N	8	1	\N	\N	\N
2357	Michael John	Storey	1949-05-25	\N	\N	20	1	\N	\N	\N
2359	Maurice Mark	Glasman	1961-03-08	\N	\N	8	1	\N	\N	\N
2360	Sarah Virginia	Brinton	1955-04-01	\N	\N	3	2	\N	\N	\N
2361	David John	Maclean	1953-05-16	\N	\N	14	1	\N	\N	\N
2362	Indarjit	Singh	1932-09-17	\N	\N	20	1	\N	\N	\N
2363	Donald Thomas Younger	Curry	1944-04-04	\N	\N	4	1	\N	\N	\N
2364	James Roger Crompton	Lupton	1955-06-15	\N	\N	13	1	\N	\N	\N
2366	Tina Wendy	Stowell	1967-07-02	\N	\N	20	2	\N	\N	\N
2367	Paul Cline	Strasburger	1946-07-31	\N	\N	20	1	\N	\N	\N
2368	Jonathan Clive	Marks	1952-10-19	\N	\N	14	1	\N	\N	\N
2369	William Jefferson	Hague	1961-03-26	\N	\N	9	1	\N	\N	\N
2370	Lorely Jane	Burt	1954-09-10	\N	\N	3	2	\N	\N	\N
2371	Douglas Martin	Hogg	1945-02-05	\N	\N	9	1	\N	\N	\N
2372	Gregory Leonard George	Barker	1966-03-08	\N	\N	3	1	\N	\N	\N
2373	Andrew Robert George	Robathan	1951-07-17	\N	\N	19	1	\N	\N	\N
2374	Walter Menzies	Campbell	1941-05-22	\N	\N	4	1	\N	\N	\N
2376	Simone Jari	Finn	1968-06-10	\N	\N	7	2	\N	\N	\N
2378	Ruby	McGregor-Smith	1963-02-22	\N	\N	14	2	\N	\N	\N
2379	Michelle Georgina	Mone	1971-10-07	\N	\N	14	2	\N	\N	\N
2380	James Norwich	Arbuthnot	1952-08-04	\N	\N	2	1	\N	\N	\N
2381	James Richard	O'Shaughnessy	1976-03-26	\N	\N	16	1	\N	\N	\N
2382	Philippa Claire	Stroud	1965-04-02	\N	\N	20	2	\N	\N	\N
2383	Stuart	Polak	1961-03-28	\N	\N	17	1	\N	\N	\N
2384	Andrew David	Lansley	1956-12-11	\N	\N	13	1	\N	\N	\N
2385	Jonathan	Oates	1969-12-28	\N	\N	16	1	\N	\N	\N
2386	David Lindsay	Willetts	1956-03-09	\N	\N	24	1	\N	\N	\N
2387	Malcolm Gray	Bruce	1944-11-17	\N	\N	3	1	\N	\N	\N
2388	Alan James	Beith	1943-04-20	\N	\N	3	1	\N	\N	\N
2390	Lynne Choona	Featherstone	1951-12-20	\N	\N	7	2	\N	\N	\N
2391	Dorothy	Thornhill	1955-05-26	\N	\N	21	2	\N	\N	\N
2392	Spencer Elliot	Livermore	1975-06-12	\N	\N	13	1	\N	\N	\N
2393	Peter Gerald	Hain	1950-02-16	\N	\N	9	1	\N	\N	\N
2394	Catherine Susan	Fall	1967-10-02	\N	\N	7	2	\N	\N	\N
2395	Michael Stahel	Farmer	1944-12-17	\N	\N	7	1	\N	\N	\N
2397	Ranbir Singh	Suri	1935-02-10	\N	\N	20	1	\N	\N	\N
2398	Julie Elizabeth	Smith	1969-06-01	\N	\N	20	2	\N	\N	\N
2400	Joanna	Shields	1962-07-12	\N	\N	20	2	\N	\N	\N
2401	Stuart Alan Ransom	Rose	1949-03-17	\N	\N	19	1	\N	\N	\N
2402	Andrew Timothy	Cooper	1963-06-09	\N	\N	4	1	\N	\N	\N
2403	Arminka	Helic	1968-04-20	\N	\N	9	2	\N	\N	\N
2404	Gail Ruth	Rebuck	1952-02-10	\N	\N	19	2	\N	\N	\N
2405	Nosheena Shaheen	Mobarik	1957-10-16	\N	\N	14	2	\N	\N	\N
2406	Paul James	Scriven	1966-02-07	\N	\N	20	1	\N	\N	\N
2408	Emma Samantha	Pidding	1966-01-13	\N	\N	17	2	\N	\N	\N
2409	Jane Antoinette	Scott	1955-06-15	\N	\N	20	2	\N	\N	\N
2410	David Leonard	Watts	1951-08-26	\N	\N	24	1	\N	\N	\N
2411	Robert Andrew	Stunell	1942-11-24	\N	\N	20	1	\N	\N	\N
2412	Dawn	Primarolo	1954-05-02	\N	\N	17	2	\N	\N	\N
2413	Robert James	Mair	1950-04-20	\N	\N	14	1	\N	\N	\N
2414	John Anthony	Bird	1946-01-30	\N	\N	3	1	\N	\N	\N
2415	Julia Elizabeth	King	1954-07-11	\N	\N	12	2	\N	\N	\N
2416	Mary Jane	Watkins	1955-03-05	\N	\N	24	2	\N	\N	\N
2304	Jeremy Hugh	Beecham	1944-11-17	\N	\N	3	1	\N	\N	\N
2863	Francis John	Montagu-Stuart-Wortley	1856-06-09	1926-05-08	\N	14	1	\N	\N	\N
2419	Elizabeth Grace	Sugg	1977-05-02	\N	\N	20	2	\N	\N	\N
2420	Charlotte Sarah Emily	Vere	1969-03-09	\N	\N	23	2	\N	\N	\N
2421	Alexander Andrew Macdonell	Fraser	1946-12-02	2021-02-08	\N	7	1	\N	\N	\N
2422	Jitesh Kishorekumar	Gadhia	1970-05-27	\N	\N	8	1	\N	\N	\N
2423	Mark	McInnes	1976-11-04	\N	\N	14	1	\N	\N	\N
2425	Lucy Jeanne	Neville-Rolfe	1953-01-02	\N	\N	15	2	\N	\N	\N
2426	Michael John	Whitby	1948-02-06	\N	\N	24	1	\N	\N	\N
2427	Daniel William	Finkelstein	1962-08-30	\N	\N	7	1	\N	\N	\N
2429	Stephen Ashley	Sherbourne	1945-10-15	\N	\N	20	1	\N	\N	\N
2430	Brian Leonard	Paddick	1958-04-24	\N	\N	17	1	\N	\N	\N
2431	Jeremy	Purvis	1974-01-15	\N	\N	17	1	\N	\N	\N
2433	Fiona Ferelith	Hodgson	1954-11-07	\N	\N	9	2	\N	\N	\N
2434	Howard Darryl	Leigh	1959-04-03	\N	\N	13	1	\N	\N	\N
2435	Rumi	Verjee	1957-06-26	\N	\N	23	1	\N	\N	\N
2436	Alison Mary	Suttie	1968-08-27	\N	\N	20	2	\N	\N	\N
2437	William	Haughey	1956-07-02	\N	\N	9	1	\N	\N	\N
2438	Richard Andrew	Balfe	1944-05-14	\N	\N	3	1	\N	\N	\N
2440	Jennifer Helen	Jones	1949-12-23	\N	\N	11	2	\N	\N	\N
2441	Charles Lamb	Allen	1957-01-04	\N	\N	2	1	\N	\N	\N
2442	James Rudolph	Palumbo	1963-06-06	\N	\N	17	1	\N	\N	\N
2443	Anthony Paul	Bamford	1945-10-23	\N	\N	3	1	\N	\N	\N
2444	Annabel MacNicoll	Goldie	1950-02-27	\N	\N	8	2	\N	\N	\N
2445	Kathryn Mary	Pinnock	1946-09-25	\N	\N	17	2	\N	\N	\N
2446	Martin John	Callanan	1961-08-08	\N	\N	4	1	\N	\N	\N
2447	Karren Rita	Brady	1969-04-04	\N	\N	3	2	\N	\N	\N
2448	Michael Maurice	Cashman	1950-12-17	\N	\N	4	1	\N	\N	\N
2449	Sharon Margaret	Bowles	1953-06-12	\N	\N	3	2	\N	\N	\N
2451	Hilary Camilla	Cavendish	1968-08-20	\N	\N	4	2	\N	\N	\N
2452	Sharmishta	Chakrabarti	1969-06-16	\N	\N	4	2	\N	\N	\N
2453	Peter Forbes	Ricketts	1952-09-30	\N	\N	19	1	\N	\N	\N
2454	Edward David Gerard	Llewellyn	1965-09-23	\N	\N	13	1	\N	\N	\N
2455	Laura Lee	Wyld	1978-01-13	\N	\N	24	2	\N	\N	\N
2456	Ian James	Duncan	1973-02-13	\N	\N	5	1	\N	\N	\N
2457	Rona Alison	Fairhead	1961-08-28	\N	\N	7	2	\N	\N	\N
2458	Theodore Thomas More	Agnew	1961-01-17	\N	\N	2	1	\N	\N	\N
2459	Ian Duncan	Burnett	1958-02-28	\N	\N	3	1	\N	\N	\N
2462	Richard John Carew	Chartres	1947-07-11	\N	\N	4	1	\N	\N	\N
2463	Bernard	Hogan-Howe	1957-10-25	\N	\N	9	1	\N	\N	\N
2464	Andrew Guy	Tyrie	1957-01-15	\N	\N	21	1	\N	\N	\N
2465	Eric Jack	Pickles	1952-04-20	\N	\N	17	1	\N	\N	\N
2466	Peter Bruce	Lilley	1943-08-23	\N	\N	13	1	\N	\N	\N
2468	Amanda Jacqueline	Sater	1963-06-21	\N	\N	20	2	\N	\N	\N
2469	Pauline Christina	Bryan	\N	\N	\N	3	2	\N	\N	\N
2470	Iain Mackenzie	McNicol	1969-08-17	\N	\N	14	1	\N	\N	\N
2471	Alan Gordon Barraclough	Haselhurst	1937-06-23	\N	\N	9	1	\N	\N	\N
2472	Deborah Clare	Bull	1963-03-22	\N	\N	3	2	\N	\N	\N
2473	Jeremy John	Heywood	1961-12-31	2018-11-04	\N	9	1	\N	\N	\N
2474	Martha Otito	Osamor	\N	\N	\N	16	2	\N	\N	\N
2475	Gavin Laurence	Barwell	1972-01-23	\N	\N	3	1	\N	\N	\N
2476	Nicola Claire	Blackwood	1979-10-16	\N	\N	3	2	\N	\N	\N
2477	Stephen Graeme	Parkinson	1983-06-30	\N	\N	17	1	\N	\N	\N
2478	Elizabeth Jenny Rosemary	Sanderson	\N	\N	\N	20	2	\N	\N	\N
2479	Zameer Mohammed	Choudrey	\N	\N	\N	4	1	\N	\N	\N
2480	David Ellis	Brownlow	1963-09-16	\N	\N	3	1	\N	\N	\N
2482	Joanna Carolyn	Penn	\N	\N	\N	17	2	\N	\N	\N
2483	Raminder Singh	Ranger	1948-05-28	\N	\N	19	1	\N	\N	\N
2484	Heather Carol	Hallett	1949-12-16	\N	\N	9	2	\N	\N	\N
2485	Deborah Ann	Wilcox	1957-06-15	\N	\N	24	2	\N	\N	\N
2486	Simon Andrew	Woolley	1961-12-24	\N	\N	24	1	\N	\N	\N
2487	Jonathan Michael	Caine	1966-04-11	\N	\N	4	1	\N	\N	\N
2489	Edward Antony Richard Louis	-	1964-03-10	\N	\N	1	1	\N	\N	\N
2490	Philippa Marion	Roe	1962-09-25	\N	\N	19	2	\N	\N	\N
2491	Harold Mark	Carter	1958-09-21	\N	\N	4	1	\N	\N	\N
2492	Nigel Kim	Darroch	1954-04-30	\N	\N	5	1	\N	\N	\N
2493	Nicola Ann	Morgan	1972-10-01	\N	\N	14	2	\N	\N	\N
2495	Gerald Edgar	Grimstone	1949-08-27	\N	\N	8	1	\N	\N	\N
2496	Stephen John	Greenhalgh	1967-09-04	\N	\N	8	1	\N	\N	\N
2497	Nicholas Le Quesne	Herbert	1963-04-07	\N	\N	9	1	\N	\N	\N
2499	David George Hamilton	Frost	1965-02-21	\N	\N	7	1	\N	\N	\N
2500	James Stephen	Wharton	1984-02-16	\N	\N	24	1	\N	\N	\N
2501	Ian Christopher	Austin	1965-03-06	\N	\N	2	1	\N	\N	\N
2502	Helena Louise	Morrissey	1966-03-22	\N	\N	14	2	\N	\N	\N
2503	Kathryn Sloan	Clark	1967-07-03	\N	\N	4	2	\N	\N	\N
2504	John Zak	Woodcock	1978-10-14	\N	\N	24	1	\N	\N	\N
2505	Kenneth Harry	Clarke	1940-07-02	\N	\N	4	1	\N	\N	\N
2506	Gisela	Stuart	1955-11-26	\N	\N	20	2	\N	\N	\N
2507	Lorraine	Fullbrook	1959-07-28	\N	\N	7	2	\N	\N	\N
2509	Susan Mary	Hayman	1962-07-28	\N	\N	9	2	\N	\N	\N
2510	Daniel Michael Gerald	Moylan	1956-03-01	\N	\N	14	1	\N	\N	\N
2511	Ian Terence	Botham	1955-11-24	\N	\N	3	1	\N	\N	\N
2512	Prem Nath	Sikka	1951-08-01	\N	\N	20	1	\N	\N	\N
2513	Frank	Field	1942-07-16	\N	\N	7	1	\N	\N	\N
2514	Mark Philip	Sedwill	1964-10-21	\N	\N	20	1	\N	\N	\N
2515	Claire Regina	Fox	1960-06-05	\N	\N	7	2	\N	\N	\N
2518	Edward Henry	Garnier	1952-10-26	\N	\N	8	1	\N	\N	\N
2519	Alexander John	Randall	1955-08-05	\N	\N	19	1	\N	\N	\N
2520	Rosel Marie	Boycott	1951-05-13	\N	\N	3	2	\N	\N	\N
2521	David William Kinloch	Anderson	1961-07-05	\N	\N	2	1	\N	\N	\N
2522	Andrew Michael Gordon	Sharpe	1962-06-15	\N	\N	20	1	\N	\N	\N
2523	John Mark	Lancaster	1970-05-12	\N	\N	13	1	\N	\N	\N
2524	Neil Francis Jeremy	Mendoza	1959-11-02	\N	\N	14	1	\N	\N	\N
2525	Charles Hilary	Moore	1956-10-31	\N	\N	14	1	\N	\N	\N
2527	Nigel Alexander	Dodds	1958-08-20	\N	\N	5	1	\N	\N	\N
2528	Philip	Hammond	1955-12-04	\N	\N	9	1	\N	\N	\N
2529	Ruth Elizabeth	Hunt	1980-03-12	\N	\N	9	2	\N	\N	\N
2418	Mark Ian	Price	1961-03-02	\N	\N	17	1	\N	\N	\N
2532	Edward Julian	Udny-Lister	1949-10-25	\N	\N	22	1	\N	\N	\N
2533	Evgeny Alexandrovich	Lebedev	1980-05-08	\N	\N	13	1	\N	\N	\N
2534	Keith Douglas	Stewart	\N	\N	\N	20	1	\N	\N	\N
2535	Terence Michael Elkan Barnet	Etherton	1951-06-21	\N	\N	6	1	\N	\N	\N
2536	David	Wolfson	1968-07-19	\N	\N	24	1	\N	\N	\N
2537	Daniel John	Hannan	1971-09-01	\N	\N	9	1	\N	\N	\N
2538	Dean Aaron	Godson	1962-08-26	\N	\N	8	1	\N	\N	\N
2540	Stephanie Mary	Fraser	1968-09-04	\N	\N	7	2	\N	\N	\N
2541	Simon Gerard	McDonald	1961-03-09	\N	\N	14	1	\N	\N	\N
2542	Peter Andrew	Cruddas	1953-09-30	\N	\N	4	1	\N	\N	\N
2543	Syed Salah	Kamall	1967-02-15	\N	\N	12	1	\N	\N	\N
2544	Gillian Joanna	Merron	1959-04-12	\N	\N	14	2	\N	\N	\N
2545	Andrew David	Parker	\N	\N	\N	17	1	\N	\N	\N
2547	Judith Vivienne	Blake	\N	\N	\N	3	2	\N	\N	\N
2548	Jennifer	Chapman	1973-09-25	\N	\N	4	2	\N	\N	\N
2550	Wajid Iltaf	Khan	1979-10-15	\N	\N	12	1	\N	\N	\N
2551	Amyas Charles Edward	Morse	2049-06-28	\N	\N	14	1	\N	\N	\N
2552	John Tucker Mugabi	Sentamu	2049-06-10	\N	\N	20	1	\N	\N	\N
2553	Simon Laurence	Stevens	1966-08-04	\N	\N	20	1	\N	\N	\N
2554	Ruth Elizabeth	Davidson	1978-11-10	\N	\N	5	2	\N	\N	\N
2555	Louise	Casey	1965-03-29	\N	\N	4	2	\N	\N	\N
2556	Charles Compton	Cavendish	1793-08-28	1863-11-10	\N	4	1	\N	\N	\N
2558	Charles Theophilus	Metcalfe	1785-01-30	1846-09-12	\N	14	1	\N	\N	\N
2559	Edward John	Stanley	1802-11-13	1869-06-16	\N	20	1	\N	\N	\N
2560	James	Duff	1814-07-06	1879-08-07	\N	5	1	\N	\N	\N
2562	Thomas James	Agar-Robartes	1808-03-18	1882-03-09	\N	2	1	\N	\N	\N
2563	Chichester Samuel	Parkinson Fortescue	1823-01-18	1898-01-30	\N	17	1	\N	\N	\N
2564	James	Ogilvie Grant	1817-12-27	1888-06-05	\N	16	1	\N	\N	\N
2565	Henry Campbell	Bellingham	1955-03-29	\N	\N	3	1	\N	\N	\N
2566	Thomas William	Coke	1754-05-06	1842-06-30	\N	4	1	\N	\N	\N
2568	Frederic	Leighton	1830-12-03	1896-01-25	\N	13	1	\N	\N	\N
2569	John Wingfield	Malcolm	1833-05-16	1902-03-06	\N	14	1	\N	\N	\N
2570	Donald Alexander	Smith	1818-08-06	1914-01-21	\N	20	1	\N	\N	\N
2571	Charles Hare	Hemphill	\N	1908-03-04	\N	9	1	\N	\N	\N
2572	Thomas	Shaw	1850-05-23	1937-06-28	\N	20	1	\N	\N	\N
2573	Henry Edmund	Butler	1844-12-18	1912-10-02	\N	3	1	\N	\N	\N
2575	Charles Edward Hungerford Atholl	Colston	1854-05-16	1925-06-17	\N	4	1	\N	\N	\N
2576	Richard Godolphin Walmesley	Chaloner	1856-10-12	1938-01-23	\N	4	1	\N	\N	\N
2577	David	Beatty	1871-01-17	1936-03-11	\N	3	1	\N	\N	\N
2578	George Allardice	Riddell	1865-05-25	1934-12-05	\N	19	1	\N	\N	\N
2579	Joseph	Watson	1873-02-10	1922-03-13	\N	24	1	\N	\N	\N
2580	Robert Daniel Thwaites	Yerburgh	1889-12-10	1955-11-27	\N	26	1	\N	\N	\N
2581	Henry Neville	Gladstone	1852-04-02	1935-04-28	\N	8	1	\N	\N	\N
2582	Frank	Russell	1867-07-02	1946-12-20	\N	19	1	\N	\N	\N
2584	John William Beaumont	Pease	1869-07-04	1950-08-07	\N	17	1	\N	\N	\N
2585	George Richard James	Hennessy	1877-03-23	1953-10-08	\N	9	1	\N	\N	\N
2586	Henry Edward	Lyons	1878-08-29	1963-08-17	\N	13	1	\N	\N	\N
2587	Thomas Horatio Arthur Ernest	Cochrane	1857-04-02	1951-01-17	\N	4	1	\N	\N	\N
2588	Edmund	Beckett	1816-05-12	1905-04-29	\N	3	1	\N	\N	\N
2589	George Robert	Shepherd	1881-08-19	1954-12-04	\N	20	1	\N	\N	\N
2590	Edward Ratcliffe Garth Russell	Evans	1881-10-28	1957-08-20	\N	6	1	\N	\N	\N
2591	Augustus Andrewes	Uthwatt	1879-04-25	1949-04-24	\N	22	1	\N	\N	\N
2592	Charles	Dukes	1881-10-28	1948-05-14	\N	5	1	\N	\N	\N
2593	Valentine La Touche	McEntee	1871-01-16	1953-02-11	\N	14	1	\N	\N	\N
2594	Fergus Dunlop	Morton	1887-10-17	1973-07-18	\N	14	1	\N	\N	\N
2595	Brendan	Bracken	1901-02-15	1958-08-08	\N	3	1	\N	\N	\N
2598	Malcolm Stewart	McCorquodale	1901-03-29	1971-09-25	\N	14	1	\N	\N	\N
2599	Barbara Frances	Wright	1897-04-14	1988-07-11	\N	24	2	\N	\N	\N
2600	Thomas	Williams	1888-03-18	1967-03-29	\N	24	1	\N	\N	\N
2601	John William	Morris	1896-09-11	1979-06-09	\N	14	1	\N	\N	\N
2602	Alexander Moncrieff	Coutanche	1892-05-09	1973-12-18	\N	4	1	\N	\N	\N
2603	John Hugh	Hare	1911-01-22	1982-03-07	\N	9	1	\N	\N	\N
2604	William Morgan	Fletcher-Vane	1909-04-12	1989-06-22	\N	7	1	\N	\N	\N
2605	Charles Edward	Leatherland	1898-04-18	1992-12-18	\N	13	1	\N	\N	\N
2606	Archibald Fenner	Brockway	1888-11-01	1988-04-28	\N	3	1	\N	\N	\N
2607	Israel Moses	Sieff	1889-05-04	1972-02-14	\N	20	1	\N	\N	\N
2609	Willis	Jackson	1904-10-29	1970-02-17	\N	11	1	\N	\N	\N
2610	John Mackintosh	Foot	1909-02-17	1999-10-11	\N	7	1	\N	\N	\N
2611	Henry Stephen	Wilson	1916-03-21	1997-11-23	\N	24	1	\N	\N	\N
2612	Julian Ward	Snow	1910-02-24	1982-01-24	\N	20	1	\N	\N	\N
2614	Norman Crowther	Hunt	1920-03-13	1987-02-16	\N	9	1	\N	\N	\N
2615	Denis Arthur	Greenhill	1913-11-07	2000-11-08	\N	8	1	\N	\N	\N
2616	Tufton Victor Hamilton	Beamish	1917-01-27	1989-04-06	\N	3	1	\N	\N	\N
2617	Margaret Rosalind	Delacourt-Smith	1916-04-05	2010-06-08	\N	5	2	\N	\N	\N
2618	Thomas	Royden	1871-05-22	1950-11-06	\N	19	1	\N	\N	\N
2620	John Herbert	McCluskey	1929-06-12	2017-07-20	\N	14	1	\N	\N	\N
2621	Aubrey Leland Oakes	Buxton	1918-07-15	2009-09-01	\N	3	1	\N	\N	\N
2622	Edwin Rodney	Smith	1914-05-10	1998-07-01	\N	20	1	\N	\N	\N
2623	Walter Laing Macdonald	Perry	1921-06-16	2003-07-17	\N	17	1	\N	\N	\N
2624	Hugh Emlyn	Hooson	1925-03-26	2012-02-21	\N	9	1	\N	\N	\N
2625	Thomas Gray	Boardman	1919-01-12	2003-03-10	\N	3	1	\N	\N	\N
2626	Alan Robertson	Campbell	1917-05-24	2013-06-30	\N	4	1	\N	\N	\N
2627	Anthony Meredith	Quinton	1925-03-25	2010-06-19	\N	18	1	\N	\N	\N
2628	Gordon William Humphreys	Richardson	1915-11-25	2010-01-22	\N	19	1	\N	\N	\N
2629	Peter Gordon	Henderson	1922-09-16	2000-01-13	\N	9	1	\N	\N	\N
2630	Robert William	Elliott	1920-12-11	2011-05-20	\N	6	1	\N	\N	\N
2632	Robert Michael Oldfield	Havers	1923-03-10	1992-04-01	\N	9	1	\N	\N	\N
2633	Norman Antony Francis	St John-Stevas	1929-05-18	2012-03-02	\N	20	1	\N	\N	\N
2634	Daphne Margaret Sybil Désirée	Park	1921-09-01	2010-03-24	\N	17	2	\N	\N	\N
2635	Malcolm Everard MacLaren	Pearson	1942-07-20	\N	\N	17	1	\N	\N	\N
2531	John	Mann	1960-01-10	\N	\N	14	1	\N	\N	\N
2864	Archibald Ralph	Montagu-Stuart-Wortley-Mackenzie	1892-04-17	1953-05-16	\N	14	1	\N	\N	\N
2638	Brenda	Dean	1943-04-29	2018-03-13	\N	5	2	\N	\N	\N
2640	Peter	Pilkington	1933-09-05	2011-02-14	\N	17	1	\N	\N	\N
2642	Richard George	Rogers	1933-07-23	\N	\N	19	1	\N	\N	\N
2643	David Patrick Paul	Alton	1951-03-15	\N	\N	2	1	\N	\N	\N
2644	Patrick Barnabas Burke	Mayhew	1929-09-11	2016-06-25	\N	14	1	\N	\N	\N
2645	Stuart Jeffrey	Randall	1938-06-22	2012-08-11	\N	19	1	\N	\N	\N
2647	David Terence	Puttnam	1941-02-25	\N	\N	17	1	\N	\N	\N
2648	Diana Margaret	Maddock	1945-05-19	2020-06-26	\N	14	2	\N	\N	\N
2649	Ronald Ernest	Dearing	1930-07-27	2009-02-19	\N	5	1	\N	\N	\N
2650	Norman Reginald	Warner	1940-09-08	\N	\N	24	1	\N	\N	\N
2651	Kathleen Margaret	Richardson	1938-02-24	\N	\N	19	2	\N	\N	\N
2652	Ernest Ronald	Oxburgh	1934-11-02	\N	\N	16	1	\N	\N	\N
2653	Colin Morven	Sharman	1943-02-19	\N	\N	20	1	\N	\N	\N
2654	Arthur George	Weidenfeld	1919-09-13	2016-01-20	\N	24	1	\N	\N	\N
2655	Albert James	Murray	1930-01-09	1980-02-10	\N	14	1	\N	\N	\N
2656	Jeffrey William	Rooker	1941-06-05	\N	\N	19	1	\N	\N	\N
2657	John	Morris	1931-11-05	\N	\N	14	1	\N	\N	\N
2658	Brenda Marjorie	Hale	1945-01-31	\N	\N	9	2	\N	\N	\N
2660	Margaret Josephine	McDonagh	1961-06-26	\N	\N	14	2	\N	\N	\N
2661	Frances Gertrude Claire	D'Souza	1944-04-18	\N	\N	5	2	\N	\N	\N
2663	John Robert Louis	Lee	1942-06-21	\N	\N	13	1	\N	\N	\N
2664	John Derek	Taylor	1943-11-12	\N	\N	21	1	\N	\N	\N
2665	Augustine Thomas	O'Donnell	1952-10-01	\N	\N	16	1	\N	\N	\N
2666	Nicholas Henry	Bourne	1952-01-01	\N	\N	3	1	\N	\N	\N
2667	Molly Christine	Meacher	1940-05-15	\N	\N	14	2	\N	\N	\N
2669	Lawrence Antony	Collins	1941-05-07	\N	\N	4	1	\N	\N	\N
2670	Jonathan Hopkin	Hill	1960-07-24	\N	\N	9	1	\N	\N	\N
2671	Roy Francis	Kennedy	1962-11-09	\N	\N	12	1	\N	\N	\N
2672	Michael David	Wills	1952-05-20	\N	\N	24	1	\N	\N	\N
2673	Francis Anthony Aylmer	Maude	1953-07-04	\N	\N	14	1	\N	\N	\N
2674	Matthew Owen John	Taylor	1963-01-03	\N	\N	21	1	\N	\N	\N
2675	Bernard Francisco	Ribeiro	1944-01-20	\N	\N	19	1	\N	\N	\N
2677	Julian Alexander	Fellowes	1949-08-17	\N	\N	7	1	\N	\N	\N
2678	Margot Ruth Aline	Lister	1949-05-03	\N	\N	13	2	\N	\N	\N
2679	Elizabeth Marie	Redfern	1947-09-25	\N	\N	19	2	\N	\N	\N
2680	Gary Andrew	Porter	1960-09-08	\N	\N	17	1	\N	\N	\N
2681	Natalie Jessica	Evans	1975-11-29	\N	\N	6	2	\N	\N	\N
2682	Christopher John	Lennie	1953-02-22	\N	\N	13	1	\N	\N	\N
2683	Tessa Jane Helen Douglas	Jowell	1947-09-17	2018-05-12	\N	11	2	\N	\N	\N
2684	Christine Mary	Humphreys	1947-05-26	\N	\N	9	2	\N	\N	\N
2685	Roger John Laugharne	Thomas	1947-10-22	\N	\N	21	1	\N	\N	\N
2686	Barbara Lilian	Janke	1947-06-05	\N	\N	11	2	\N	\N	\N
2688	Natalie Louise	Bennett	1966-02-10	\N	\N	3	2	\N	\N	\N
2689	John	Hendy	1948-04-11	\N	\N	9	1	\N	\N	\N
2690	Christine	Blower	1951-04-20	\N	\N	3	2	\N	\N	\N
2691	Aamer Ahmad	Sarfraz	1981-09-25	\N	\N	20	1	\N	\N	\N
2692	Michael Alan	Spencer	1955-05-30	\N	\N	20	1	\N	\N	\N
2694	Richard Bickerton Pemell	Lyons	1817-04-26	1887-12-05	\N	13	1	\N	\N	\N
2695	Susan Margaret	Black	1961-05-07	\N	\N	3	2	\N	\N	\N
2697	Hugh	Montgomery	1739-11-05	1819-12-14	\N	14	1	\N	\N	\N
2698	James	Hope	1741-08-23	1816-05-29	\N	9	1	\N	\N	\N
2699	George	Ramsay	1770-10-23	1838-03-21	\N	19	1	\N	\N	\N
2700	Peniston	Lamb	1748-01-29	1828-07-22	\N	13	1	\N	\N	\N
2701	George	Harris	1746-03-18	1829-05-19	\N	9	1	\N	\N	\N
2702	John	Foster	\N	1828-08-16	\N	7	1	\N	\N	\N
2703	Robert	Gifford	1779-02-24	1826-09-04	\N	8	1	\N	\N	\N
2704	Charles Rose	Ellis	1771-12-19	1845-07-01	\N	6	1	\N	\N	\N
2705	George	Murray	1762-04-30	1836-11-11	\N	14	1	\N	\N	\N
2707	Frederick James	Lamb	1782-04-17	1853-01-29	\N	13	1	\N	\N	\N
2708	John Laird Mair	Lawrence	1811-03-04	1879-06-27	\N	13	1	\N	\N	\N
2709	Arthur William Acland	Hood	1824-07-14	1901-11-15	\N	9	1	\N	\N	\N
2711	William Wallace	Hozier	1825-02-24	1906-01-30	\N	9	1	\N	\N	\N
2712	Edward Arthur	Colebrooke	1861-10-12	1939-02-28	\N	4	1	\N	\N	\N
2713	Alexander	Fuller-Acland-Hood	1853-09-26	1917-06-04	\N	7	1	\N	\N	\N
2714	Walter James	Hore-Ruthven	1838-06-14	1921-02-28	\N	9	1	\N	\N	\N
2715	Walter	Runciman	1847-07-06	1937-08-13	\N	19	1	\N	\N	\N
2716	Anthony Jonathan	Woodley	1948-01-02	\N	\N	24	1	\N	\N	\N
2718	Edward Ettingdean	Bridges	1892-08-04	1969-08-27	\N	3	1	\N	\N	\N
2719	Donald Bradley	Somervell	1889-08-24	1960-11-18	\N	20	1	\N	\N	\N
2720	Harry Bernard	Taylor	1895-09-18	1991-04-11	\N	21	1	\N	\N	\N
2721	William Shepherd	Morrison	1893-08-10	1961-02-03	\N	14	1	\N	\N	\N
2722	John MacDonald	Bannerman	1901-09-01	1969-05-10	\N	3	1	\N	\N	\N
2723	William Picken	Alexander	1905-12-13	1993-09-08	\N	2	1	\N	\N	\N
2725	Robert Lynd Erskine	Lowry	1919-01-30	1999-01-15	\N	13	1	\N	\N	\N
2726	Victor Collin	Matthews	1919-12-05	1995-12-05	\N	14	1	\N	\N	\N
2727	Robert Alistair	McAlpine	1942-05-14	2014-01-17	\N	14	1	\N	\N	\N
2728	Charles Collier	Johnston	1915-03-04	2002-04-30	\N	11	1	\N	\N	\N
2729	Stanley Clinton	Clinton-Davis	1928-12-06	\N	\N	4	1	\N	\N	\N
2730	Phyllis Dorothy	James	1920-08-03	2014-11-27	\N	11	2	\N	\N	\N
2731	Richard Edward Geoffrey	Howe	1926-12-20	2015-10-09	\N	9	1	\N	\N	\N
2732	Harry Kenneth	Woolf	1933-05-02	\N	\N	24	1	\N	\N	\N
2733	James Arthur David	Hope	1938-06-27	\N	\N	9	1	\N	\N	\N
2734	Greville Ewan	Janner	1928-07-11	2015-12-19	\N	11	1	\N	\N	\N
2735	Antony Harold	Newton	1937-08-29	2012-03-25	\N	15	1	\N	\N	\N
2737	Anthony Fitzhardinge	Gueterbock	1939-09-20	\N	\N	8	1	\N	\N	\N
2738	Peter	Temple-Morris	1938-02-12	2018-05-01	\N	21	1	\N	\N	\N
2739	Irvine Alan Stewart	Laidlaw	1942-12-22	\N	\N	13	1	\N	\N	\N
2740	Martin John	O'Neill	1945-01-06	2020-08-26	\N	16	1	\N	\N	\N
2742	Paul Yaw	Boateng	1951-06-14	\N	\N	3	1	\N	\N	\N
2743	Sheila Clare	Hollins	1946-06-22	\N	\N	9	2	\N	\N	\N
2744	Stewart Martin	Wood	1968-03-25	\N	\N	24	1	\N	\N	\N
2745	Shaista Ahmad	Sheehan	1959-07-29	\N	\N	20	2	\N	\N	\N
2637	Merlyn	Merlyn-Rees	1920-12-18	2006-01-05	\N	14	1	\N	\N	\N
2865	Alan James	Montagu-Stuart-Wortley-Mackenzie	1935-03-23	1987-06-03	\N	14	1	\N	\N	\N
2748	David John	Colville	1894-02-13	1954-10-31	\N	4	1	\N	\N	\N
2749	George	Pitt	1721-05-01	1803-05-07	\N	17	1	\N	\N	\N
2751	John	Campbell	1779-09-15	1861-06-23	\N	4	1	\N	\N	\N
2753	James	Carnegie	1827-11-16	1905-02-21	\N	4	1	\N	\N	\N
2754	Colin	Blackburn	1813-05-18	1896-01-08	\N	3	1	\N	\N	\N
2755	George	Stephen	1829-06-05	1921-11-29	\N	20	1	\N	\N	\N
2756	Algernon Bertram	Freeman-Mitford	1837-02-24	1916-08-17	\N	7	1	\N	\N	\N
2757	John Campbell	Gordon	1847-08-03	1934-03-07	\N	8	1	\N	\N	\N
2758	Richard Gardiner	Casey	1890-08-29	1976-06-17	\N	4	1	\N	\N	\N
2760	William Buller Fullerton	Elphinstone	1828-11-18	1893-01-18	\N	6	1	\N	\N	\N
2761	John Charles Walsham	Reith	1889-07-20	1971-06-16	\N	19	1	\N	\N	\N
2762	Hugh Kinsman	Cudlipp	1913-08-28	1998-05-17	\N	4	1	\N	\N	\N
2763	David Thomas	Pitt	1913-10-03	1994-12-18	\N	17	1	\N	\N	\N
2764	Lydia Selina	Dunn	1940-02-29	\N	\N	5	2	\N	\N	\N
2765	Julian Pascoe Francis St Leger	Grenfell	1935-05-23	\N	\N	8	1	\N	\N	\N
2766	George Charles	Bingham	1860-12-13	1949-04-20	\N	3	1	\N	\N	\N
2767	Charles Willoughby Moke	Norrie	1893-09-26	1977-05-25	\N	15	1	\N	\N	\N
2768	Henry	Villiers Stuart	1803-06-08	1874-01-23	\N	23	1	\N	\N	\N
2769	John	Jervis	1734-01-19	1823-03-13	\N	11	1	\N	\N	\N
2770	John Edward Reginald	Wyndham	1920-06-05	1972-06-06	\N	24	1	\N	\N	\N
2771	Helen Violet	Bonham Carter	1887-04-15	1969-02-19	\N	3	2	\N	\N	\N
2772	Thomas William	Jones	1898-02-10	1984-11-18	\N	11	1	\N	\N	\N
2773	William Michael	Berry	1911-05-18	2001-04-03	\N	3	1	\N	\N	\N
2776	Harmar	Nicholls	1912-11-01	2000-09-15	\N	15	1	\N	\N	\N
2777	Gordon Thomas Calthrop	Campbell	1921-06-08	2005-04-26	\N	4	1	\N	\N	\N
2778	Jeremy Nicolas	Hutchinson	1915-03-28	2017-11-13	\N	9	1	\N	\N	\N
2779	Robert Edwin	McAlpine	1907-04-23	1990-01-07	\N	14	1	\N	\N	\N
2781	Francis Scott	McFadzean	1915-11-26	1992-05-23	\N	14	1	\N	\N	\N
2782	Aubrey Geoffrey Frederick	Rippon	1924-05-28	1997-01-28	\N	19	1	\N	\N	\N
2783	Humphrey Edward Gregory	Atkins	1922-08-12	1996-10-04	\N	2	1	\N	\N	\N
2784	William Thomas	Rodgers	1928-10-28	\N	\N	19	1	\N	\N	\N
2785	Emma Harriet	Nicholson	1941-10-16	\N	\N	15	2	\N	\N	\N
2786	Leslie John	Griffiths	1942-02-15	\N	\N	8	1	\N	\N	\N
2787	Ann Elizabeth Oldfield	Butler-Sloss	1933-08-10	\N	\N	3	2	\N	\N	\N
2788	Brian Francis	Kerr	1948-02-22	2020-12-01	\N	12	1	\N	\N	\N
2789	William Alexander	Hay	1950-04-16	\N	\N	9	1	\N	\N	\N
2790	Monroe Edward	Palmer	1938-11-30	\N	\N	17	1	\N	\N	\N
2791	David	Goddard	1952-10-02	\N	\N	8	1	\N	\N	\N
2792	Alicia Pamela	Kennedy	1969-03-22	\N	\N	12	2	\N	\N	\N
2793	Robert Thomas William	McCrea	1948-08-06	\N	\N	14	1	\N	\N	\N
2794	Norman Robert	Foster	1935-06-01	\N	\N	7	1	\N	\N	\N
2795	Francis John Childs	Ganzoni	1882-01-19	1958-08-15	\N	8	1	\N	\N	\N
2796	Edward Richard	Russell	1834-08-09	1920-02-20	\N	19	1	\N	\N	\N
2797	Clive Latham	Baillieu	1889-09-24	1967-06-18	\N	3	1	\N	\N	\N
2799	Clementine Ogilvy	Spencer-Churchill	1885-04-01	1977-12-12	\N	20	2	\N	\N	\N
2800	George Fielden	MacLeod	1895-06-17	1991-06-27	\N	14	1	\N	\N	\N
2801	Robert Lowe	Hall	1901-03-06	1988-09-17	\N	9	1	\N	\N	\N
2802	Charles Hector Fitzroy	Maclean	1916-05-05	1990-02-08	\N	14	1	\N	\N	\N
2803	Rachel Trixie Anne	Gardner	1927-07-17	\N	\N	8	2	\N	\N	\N
2804	Ian Hedworth John Little	Gilmour	1926-07-08	2007-09-21	\N	8	1	\N	\N	\N
2805	Donald James	Nicholls	1933-01-25	2019-09-25	\N	15	1	\N	\N	\N
2806	Geoffrey	Lofthouse	1925-12-18	2012-11-01	\N	13	1	\N	\N	\N
2809	Jonathan Toby	Harris	1953-10-11	\N	\N	9	1	\N	\N	\N
2810	George Patrick John Rushworth	Jellicoe	1918-04-04	2007-02-22	\N	11	1	\N	\N	\N
2811	Peter Leonard	Brooke	1934-03-03	\N	\N	3	1	\N	\N	\N
2812	Kishwer	Falkner	1955-03-09	\N	\N	7	2	\N	\N	\N
2813	Simon Denis	Brown	1937-04-09	\N	\N	3	1	\N	\N	\N
2814	Gillian Patricia	Shephard	1940-01-22	\N	\N	20	2	\N	\N	\N
2815	William Manuel	Morris	1938-10-19	\N	\N	14	1	\N	\N	\N
2816	Richard Douglas	Harries	1936-06-02	\N	\N	9	1	\N	\N	\N
2818	Reginald Norman Morgan	Empey	1947-10-26	\N	\N	6	1	\N	\N	\N
2819	Caroline Elizabeth	Chisholm	1951-12-23	\N	\N	4	2	\N	\N	\N
2820	Susan Frances Maria	Williams	1967-05-16	\N	\N	24	2	\N	\N	\N
2821	Frank Zacharias Robin	Goldsmith	1975-01-20	\N	\N	8	1	\N	\N	\N
2822	Malcolm Newton	Shepherd	1918-09-27	2001-04-05	\N	20	1	\N	\N	\N
2823	James Brian Edward	Hutton	1931-06-29	2020-07-14	\N	9	1	\N	\N	\N
2824	Henrietta Laura	Murray-Pulteney	1766-12-26	1808-07-14	\N	14	2	\N	\N	\N
2826	Leopold George Duncan Albert	-	1853-04-07	1884-03-28	\N	1	1	\N	\N	\N
2827	George Douglas	Campbell	1823-04-30	1900-04-24	\N	4	1	\N	\N	\N
2828	Richard	Nugent-Temple-Grenville	1776-05-29	1839-01-17	\N	15	1	\N	\N	\N
2829	William Arthur Philip Louis	-	1982-06-21	\N	\N	1	1	\N	\N	\N
2830	Arthur William Patrick Albert	-	1850-05-01	1942-01-16	\N	1	1	\N	\N	\N
2831	George Edward Alexander Edmund	-	1902-12-20	1942-08-25	\N	1	1	\N	\N	\N
2832	Henry Charles Albert David	-	1984-09-15	\N	\N	1	1	\N	\N	\N
2833	Albert Frederick Arthur George	-	1895-12-14	1952-02-06	\N	1	1	\N	\N	\N
2835	Arthur James	Balfour	1848-07-25	1930-03-19	\N	3	1	\N	\N	\N
2836	Benjamin	Disraeli	1804-12-21	1881-04-19	\N	5	1	\N	\N	\N
2837	Vere Brabazon	Ponsonby	1880-10-27	1956-03-10	\N	17	1	\N	\N	\N
2838	George Augustus Henry	Cavendish	1754-03-21	1834-05-04	\N	4	1	\N	\N	\N
2839	Robert Dundas	Haldane-Duncan	1785-03-21	1859-12-22	\N	9	1	\N	\N	\N
2840	Edward	Law	1790-09-08	1871-12-22	\N	13	1	\N	\N	\N
2841	Edward	Bootle-Wilbraham	1837-12-12	1898-11-19	\N	3	1	\N	\N	\N
2842	Archibald Philip	Primrose	1847-05-07	1929-05-21	\N	17	1	\N	\N	\N
2843	Henry Thomas	Liddell	1797-03-10	1878-03-19	\N	13	1	\N	\N	\N
2845	George James	Cholmondeley	1749-05-11	1827-04-10	\N	4	1	\N	\N	\N
1	Walter	Butler	1770-02-05	1820-08-10	\N	3	1	\N	\N	\N
21	George	Elphinstone	1746-01-07	1823-03-10	\N	6	1	\N	\N	\N
33	William	Craven	1770-09-01	1825-07-30	\N	4	1	\N	\N	\N
44	John	Campbell	1762-03-30	1834-03-29	\N	4	1	\N	\N	\N
2747	Nemat Talaat	Shafik	1962-08-13	\N	\N	20	2	\N	\N	\N
2866	Richard Alan Montagu Stuart	Wortley	1953-05-26	\N	\N	24	1	\N	\N	\N
71	Gilbert	Elliot Murray Kynynmound	1751-04-23	1814-06-21	\N	6	1	\N	\N	\N
82	John Somers	Cocks	1760-05-06	1841-01-05	\N	4	1	\N	\N	\N
90	Thomas	Pakenham	1774-05-14	1835-05-24	\N	17	1	\N	\N	\N
100	Richard	Trench	1767-05-18	1837-11-24	\N	21	1	\N	\N	\N
112	Charles	Brudenell-Bruce	1773-02-14	1856-01-04	\N	3	1	\N	\N	\N
116	John Fleming	Leicester	1762-04-04	1827-06-18	\N	13	1	\N	\N	\N
123	Charles	Abbott	1762-10-07	1832-11-04	\N	2	1	\N	\N	\N
129	William	A'Court	1779-07-11	1860-05-31	\N	2	1	\N	\N	\N
138	Arthur James	Plunkett	1759-09-09	1836-07-30	\N	17	1	\N	\N	\N
150	George Warwick	Bampfylde	1786-03-23	1858-12-19	\N	3	1	\N	\N	\N
160	Francis Godolphin	Osborne	1777-10-18	1850-02-15	\N	16	1	\N	\N	\N
169	John William	Ponsonby	1781-08-31	1847-05-16	\N	17	1	\N	\N	\N
178	Charles Christopher	Pepys	1781-04-29	1851-04-29	\N	17	1	\N	\N	\N
200	Richard Wogan	Talbot	\N	1849-10-29	\N	21	1	\N	\N	\N
205	Nicholas William	Ridley Colborne	1779-04-14	1854-05-03	\N	19	1	\N	\N	\N
219	Francis William	Caulfeild	1775-01-03	1863-12-26	\N	4	1	\N	\N	\N
227	George	Eden	1784-08-25	1849-01-01	\N	6	1	\N	\N	\N
231	James Andrew	Ramsay	1812-04-22	1860-12-22	\N	19	1	\N	\N	\N
239	Edward Burtenshaw	Sugden	1781-02-12	1875-01-29	\N	20	1	\N	\N	\N
251	Thomas Babington	Macaulay	1800-10-25	1859-12-28	\N	14	1	\N	\N	\N
258	William Tatton	Egerton	1806-12-30	1883-02-21	\N	6	1	\N	\N	\N
266	Maurice Frederick Fitzhardinge	Berkeley	1788-01-03	1867-10-17	\N	3	1	\N	\N	\N
279	Edwin Richard Windham	Windham-Quin	1812-05-19	1871-10-06	\N	24	1	\N	\N	\N
290	Brook William	Bridges	1801-06-02	1875-12-06	\N	3	1	\N	\N	\N
300	Edward George	Fitz-alan Howard	1818-01-20	1883-12-01	\N	7	1	\N	\N	\N
310	William Henry Lytton Earle	Bulwer	1801-02-13	1872-05-23	\N	3	1	\N	\N	\N
319	Gavin	Campbell	1851-04-09	1922-10-19	\N	4	1	\N	\N	\N
328	John Robert	Townshend	1805-08-09	1890-02-14	\N	21	1	\N	\N	\N
337	John Ralph	Ormsby-Gore	1816-06-03	1876-06-15	\N	16	1	\N	\N	\N
340	Frederick Temple	Blackwood	1826-06-21	1902-02-12	\N	3	1	\N	\N	\N
350	Charles Bowyer	Adderley	1814-08-02	1905-03-28	\N	2	1	\N	\N	\N
357	Arthur Edward	Guinness	1840-11-01	1915-01-20	\N	8	1	\N	\N	\N
366	Odo William Leopold	Russell	1829-02-20	1884-08-25	\N	19	1	\N	\N	\N
378	Edward Robert Lytton	Bulwer-Lytton	1831-11-08	1891-11-24	\N	3	1	\N	\N	\N
392	Robert Porrett	Collier	1817-06-21	1886-10-27	\N	4	1	\N	\N	\N
402	Edward Hugessen	Knatchbull-Hugessen	1829-04-29	1893-02-06	\N	12	1	\N	\N	\N
416	Stafford Henry	Northcote	1818-10-27	1887-01-12	\N	15	1	\N	\N	\N
426	Henry William	Eaton	1816-03-13	1891-10-02	\N	6	1	\N	\N	\N
443	Archibald Campbell	Campbell	1835-02-22	1908-07-08	\N	4	1	\N	\N	\N
445	William Amhurst	Tyssen Amherst	1835-04-25	1909-01-16	\N	21	1	\N	\N	\N
453	William Henry Forester	Denison	1834-06-19	1900-04-19	\N	5	1	\N	\N	\N
468	Charles Robert	Carington	1843-05-16	1928-06-13	\N	4	1	\N	\N	\N
477	Algernon	Borthwick	1830-12-27	1908-11-24	\N	3	1	\N	\N	\N
486	Henry Charles	Lopes	1828-10-03	1899-12-25	\N	13	1	\N	\N	\N
499	James Patrick Bannerman	Robertson	1845-08-10	1909-02-02	\N	19	1	\N	\N	\N
508	Frederick Sleigh	Roberts	1832-09-30	1914-11-14	\N	19	1	\N	\N	\N
516	Francis Wallace	Grenfell	1841-04-29	1925-01-27	\N	8	1	\N	\N	\N
528	Alexander John	Forbes-Leith	1847-08-06	1925-11-14	\N	7	1	\N	\N	\N
551	John Jones	Jenkins	1835-05-10	1915-07-27	\N	11	1	\N	\N	\N
552	George	Armitstead	1824-02-28	1915-12-07	\N	2	1	\N	\N	\N
563	George	Whiteley	1855-08-30	1925-10-21	\N	24	1	\N	\N	\N
574	Balthazar Walter	Foster	1840-07-17	1913-01-31	\N	7	1	\N	\N	\N
582	Richard Burdon	Haldane	1856-07-30	1928-08-19	\N	9	1	\N	\N	\N
595	Edward	Strachey	1858-10-30	1936-07-25	\N	20	1	\N	\N	\N
603	Charles Robert	Wynn-Carrington	1843-05-16	1928-06-13	\N	24	1	\N	\N	\N
621	Charles Benjamin Bright	McLaren	1850-05-12	1934-01-23	\N	14	1	\N	\N	\N
629	Charles William de la Poer	Beresford	1846-02-10	1919-09-06	\N	3	1	\N	\N	\N
643	Charles Beilby	Stuart-Wortley	1851-09-15	1926-04-24	\N	20	1	\N	\N	\N
657	Francis John Stephens	Hopwood	1860-12-02	1947-01-17	\N	9	1	\N	\N	\N
659	Edward Patrick	Morris	1858-05-08	1935-10-24	\N	14	1	\N	\N	\N
669	Harry Lawson Webster	Levy-Lawson	1862-12-18	1933-07-20	\N	13	1	\N	\N	\N
683	Robert	Chalmers	1858-08-18	1938-11-17	\N	4	1	\N	\N	\N
696	Henry William	Forster	1866-01-31	1936-01-15	\N	7	1	\N	\N	\N
704	James Alexander Francis Humberston	Stewart-Mackenzie	1847-10-09	1923-03-03	\N	20	1	\N	\N	\N
722	Herbert Charles Onslow	Plumer	1857-03-13	1932-07-16	\N	17	1	\N	\N	\N
734	Herbert Cokayne	Gibbs	1854-05-14	1935-05-22	\N	8	1	\N	\N	\N
757	Courtenay Charles Evan	Morgan	1867-04-10	1934-05-03	\N	14	1	\N	\N	\N
766	Ronald John	McNeill	1861-04-30	1934-10-12	\N	14	1	\N	\N	\N
772	Anne Estella Sarah Penfold	Cave	\N	1938-01-07	\N	4	2	\N	\N	\N
782	Henry William Frederick Albert	-	1900-03-31	1974-06-10	\N	1	1	\N	\N	\N
793	William Robert Wellesley	Peel	1867-01-07	1937-09-28	\N	17	1	\N	\N	\N
804	Hugh Pattison	Macmillan	1873-02-20	1952-09-05	\N	14	1	\N	\N	\N
811	Robert Hunt Stapylton Dudley Lydston	Newman	1871-10-27	1945-11-02	\N	15	1	\N	\N	\N
824	James Fitzalan	Hope	1870-12-11	1949-02-14	\N	9	1	\N	\N	\N
836	Bertram Godfray	Falle	1859-11-21	1948-11-01	\N	7	1	\N	\N	\N
857	Alexander Gore Arkwright	Hore-Ruthven	1872-07-06	1955-05-02	\N	9	1	\N	\N	\N
869	George Edward Wentworth	Bowyer	1886-01-16	1948-11-30	\N	3	1	\N	\N	\N
874	Herbert Louis	Samuel	1870-11-06	1963-02-05	\N	20	1	\N	\N	\N
876	Robert Stevenson	Horne	1871-02-28	1940-09-03	\N	9	1	\N	\N	\N
885	William Riddell	Birdwood	1865-09-13	1951-05-17	\N	3	1	\N	\N	\N
894	Laurence Richard	Philipps	1874-01-24	1962-12-07	\N	17	1	\N	\N	\N
906	Harry Louis	Nathan	1889-02-02	1963-10-23	\N	15	1	\N	\N	\N
916	Charles	Latham	1888-12-26	1970-03-31	\N	13	1	\N	\N	\N
924	Roger John Brownlow	Keyes	1872-10-04	1945-12-26	\N	12	1	\N	\N	\N
934	Frederick James	Marquis	1883-08-24	1964-12-14	\N	14	1	\N	\N	\N
942	Montagu Collet	Norman	1871-09-06	1950-02-04	\N	15	1	\N	\N	\N
951	Philip Walhouse	Chetwode	1869-09-21	1950-07-06	\N	4	1	\N	\N	\N
963	Alan Francis	Brooke	1883-07-23	1963-06-17	\N	3	1	\N	\N	\N
2867	Mary Rothes Margaret	Cecil	1857-04-25	1919-12-27	\N	4	2	\N	\N	\N
989	Walter McLennan	Citrine	1887-08-22	1983-01-22	\N	4	1	\N	\N	\N
1002	Stanley Melbourne	Bruce	1883-04-15	1967-08-25	\N	3	1	\N	\N	\N
1026	Leslie Haden	Haden-Guest	1877-03-10	1960-08-20	\N	9	1	\N	\N	\N
1037	Thomas	Macpherson	1888-07-09	1965-06-13	\N	14	1	\N	\N	\N
1047	Frederick John	Wise	1887-04-10	1968-11-20	\N	24	1	\N	\N	\N
1057	Eustace Sutherland Campbell	Percy	1887-03-21	1958-04-03	\N	17	1	\N	\N	\N
1072	Oliver	Lyttelton	1893-03-15	1972-01-21	\N	13	1	\N	\N	\N
1081	Clement Richard	Attlee	1883-01-03	1967-10-08	\N	2	1	\N	\N	\N
1088	Frederick	Godber	1888-11-06	1976-04-10	\N	8	1	\N	\N	\N
1092	Robert John	Sinclair	1893-07-29	1979-03-04	\N	20	1	\N	\N	\N
1103	Oliver Brian Sanderson	Poole	1911-08-11	1993-01-28	\N	17	1	\N	\N	\N
1117	Mary Irene	Curzon	1896-01-20	1966-02-09	\N	4	2	\N	\N	\N
1125	David Llewelyn	Jenkins	1899-04-08	1969-07-21	\N	11	1	\N	\N	\N
1136	Edward Hugh John Neale	Dalton	1887-08-26	1962-02-13	\N	5	1	\N	\N	\N
1146	Alan Tindal	Lennox-Boyd	1904-11-18	1983-03-08	\N	13	1	\N	\N	\N
1159	Geoffrey Francis	Fisher	1887-05-05	1972-09-15	\N	7	1	\N	\N	\N
1171	Edward Holroyd	Pearce	1901-02-09	1990-11-26	\N	17	1	\N	\N	\N
1179	Reginald Edward	Manningham-Buller	1905-08-01	1980-09-07	\N	14	1	\N	\N	\N
1191	Terence Norbert	Donovan	1898-06-13	1971-12-12	\N	5	1	\N	\N	\N
1195	Charles Rider	Hobson	1903-02-18	1966-02-17	\N	9	1	\N	\N	\N
1218	Evelyn Violet Elizabeth	Emmet	1899-03-18	1980-10-10	\N	6	2	\N	\N	\N
1228	Wilfred Banks Duncan	Brown	1908-11-29	1985-03-17	\N	3	1	\N	\N	\N
1240	George James	Cole	1906-02-03	1979-11-29	\N	4	1	\N	\N	\N
1251	Ian	Winterbottom	1913-04-06	1992-07-04	\N	24	1	\N	\N	\N
1258	Arnold Abraham	Goodman	1913-08-21	1995-05-12	\N	8	1	\N	\N	\N
1270	Walter	Monslow	1895-01-26	1966-10-12	\N	14	1	\N	\N	\N
1282	Beatrice	Serota	1919-10-15	2002-10-21	\N	20	2	\N	\N	\N
1289	Annie Patricia	Llewelyn-Davies	1915-07-16	1997-11-06	\N	13	2	\N	\N	\N
1300	Charles George Percy	Smith	1917-04-25	1972-08-02	\N	20	1	\N	\N	\N
1304	George Edward Cecil	Wigg	1900-11-28	1983-08-11	\N	24	1	\N	\N	\N
1319	Joseph John Saville	Garner	1908-02-14	1983-12-10	\N	8	1	\N	\N	\N
1330	Quintin McGarel	Hogg	1907-10-09	2001-10-12	\N	9	1	\N	\N	\N
1343	William Henry	Pilkington	1905-04-19	1983-12-22	\N	17	1	\N	\N	\N
1360	Solly	Zuckerman	1904-05-30	1993-04-01	\N	27	1	\N	\N	\N
1371	Tudor Elwyn	Watkins	1903-05-09	1983-11-02	\N	24	1	\N	\N	\N
1382	Arthur William James	Greenwood	1911-09-14	1982-04-12	\N	8	1	\N	\N	\N
1393	Margaret Patricia	Hornsby-Smith	1914-03-17	1985-07-03	\N	9	2	\N	\N	\N
1408	Doris Mary Gertrude	Fisher	1919-09-13	2005-12-18	\N	7	2	\N	\N	\N
1411	Gwilym Elfed	Davies	1913-10-09	1992-04-28	\N	5	1	\N	\N	\N
1418	Reginald Thomas	Paget	1908-09-02	1990-01-02	\N	17	1	\N	\N	\N
1429	Donald William Trevor	Bruce	1912-10-03	2005-04-18	\N	3	1	\N	\N	\N
1438	Richard Patrick Tallentyre	Gibson	1916-02-05	2004-04-20	\N	8	1	\N	\N	\N
1451	Gordon Samuel David	Parry	1925-11-30	2004-09-01	\N	17	1	\N	\N	\N
1462	John Ernest	Vaizey	1929-10-01	1984-07-19	\N	23	1	\N	\N	\N
1482	Douglas Albert Vivian	Allen	1917-12-15	2011-09-11	\N	2	1	\N	\N	\N
1495	William Henry	Sefton	1915-08-05	2001-09-09	\N	20	1	\N	\N	\N
1504	Terence George	Boston	1930-03-21	2011-07-23	\N	3	1	\N	\N	\N
1513	Robert Michael Maitland	Stewart	1906-11-06	1990-03-10	\N	20	1	\N	\N	\N
1519	David Lockhart-Mure	Renton	1908-08-12	2007-05-24	\N	19	1	\N	\N	\N
1526	Henry Oscar	Murton	1914-05-08	2009-07-05	\N	14	1	\N	\N	\N
1545	Michael Meredith	Swann	1920-03-01	1990-09-22	\N	20	1	\N	\N	\N
1557	Hugh Swynnerton	Thomas	1931-10-21	2017-05-07	\N	21	1	\N	\N	\N
1568	Elizabeth Patricia	Carnegy	1925-04-25	2010-11-09	\N	4	2	\N	\N	\N
1577	John Aked	Taylor	1917-08-15	2002-02-07	\N	21	1	\N	\N	\N
1585	William Stephen Ian	Whitelaw	1918-06-28	1999-07-01	\N	24	1	\N	\N	\N
1596	Angus Edmund Upton	Maude	1912-09-08	1993-11-09	\N	14	1	\N	\N	\N
1608	Frederick William	Mulley	1918-07-03	1995-03-15	\N	14	1	\N	\N	\N
1616	Marcus Richard	Kimball	1928-10-18	2014-03-27	\N	12	1	\N	\N	\N
1627	Leonard Gordon	Wolfson	1927-11-11	2010-05-20	\N	24	1	\N	\N	\N
1628	Robert Joseph	Mellish	1913-03-03	1998-05-09	\N	14	1	\N	\N	\N
1629	Walter Charles	Marshall	1932-03-05	1996-02-20	\N	14	1	\N	\N	\N
1639	Tessa Ann Vosper	Blackstone	1942-09-27	\N	\N	3	2	\N	\N	\N
1650	Philip Douglas	Knights	1920-10-03	2014-12-11	\N	12	1	\N	\N	\N
1663	Leonard James	Callaghan	1912-03-27	2005-03-26	\N	4	1	\N	\N	\N
1687	Diana Catherine	Eccles	1933-10-04	\N	\N	6	2	\N	\N	\N
1702	David Charles	Waddington	1929-08-02	2017-02-24	\N	24	1	\N	\N	\N
1712	Mark Shuldham	Schreiber	1931-09-11	\N	\N	20	1	\N	\N	\N
1721	Robert Jacob Alexander	Skidelsky	1939-04-25	\N	\N	20	1	\N	\N	\N
1731	Gordon	Slynn	1930-02-17	2009-04-07	\N	20	1	\N	\N	\N
1737	George	Porter	1920-12-06	2002-08-31	\N	17	1	\N	\N	\N
1741	Denis Herbert	Howell	1923-09-04	1998-04-19	\N	9	1	\N	\N	\N
1753	Bernard Harold Ian Halley	Stewart	1935-08-10	2018-03-03	\N	20	1	\N	\N	\N
1762	Derek Coates	Barber	1918-06-17	2017-11-21	\N	3	1	\N	\N	\N
1772	Arthur Paul	Dean	1924-09-14	2009-04-01	\N	5	1	\N	\N	\N
1789	Patricia Elizabeth	Rawlings	1939-01-27	\N	\N	19	2	\N	\N	\N
1801	John Stapylton	Habgood	1927-06-23	2019-03-06	\N	9	1	\N	\N	\N
1810	Norman Roy	Blackwell	1952-07-29	\N	\N	3	1	\N	\N	\N
1819	Richard Frederick	Vincent	1931-08-23	2018-09-08	\N	23	1	\N	\N	\N
1830	Joyce Anne	Anelay	1947-07-17	\N	\N	2	2	\N	\N	\N
1836	Audrey Caroline	Emerton	1935-09-10	\N	\N	6	2	\N	\N	\N
1847	David Arthur Russell	Howell	1936-01-18	\N	\N	9	1	\N	\N	\N
1849	Donald	Dixon	1929-03-06	2017-02-19	\N	5	1	\N	\N	\N
1853	Henry Paul Guinness	Channon	1935-10-09	2007-01-27	\N	4	1	\N	\N	\N
1865	Richard Mark	Newby	1953-02-14	\N	\N	15	1	\N	\N	\N
1887	Thomas Henry	Burlison	1936-05-23	2008-05-20	\N	3	1	\N	\N	\N
1896	John Haggitt Charles	Patten	1945-07-17	\N	\N	17	1	\N	\N	\N
1905	Trevor Arthur	Smith	1937-06-14	2021-04-24	\N	20	1	\N	\N	\N
1915	Paul Bertrand	Hamlyn	1926-02-12	2001-08-31	\N	9	1	\N	\N	\N
1924	Peta Jane	Buscombe	1954-03-12	\N	\N	3	2	\N	\N	\N
1934	Helena Ann	Kennedy	1950-05-12	\N	\N	12	2	\N	\N	\N
1943	Lawrence	Sawyer	1943-05-12	\N	\N	20	1	\N	\N	\N
2868	William Alexander Evering	Cecil	1912-05-31	1980-07-22	\N	4	1	\N	\N	\N
2869	William Hugh Amherst	Cecil	1940-12-28	2009-04-02	\N	4	1	\N	\N	\N
7	Alleyne	Fitzherbert	1753-03-01	1839-02-19	\N	7	1	\N	\N	\N
1960	Joan Brownlow	Hanham	1939-09-23	\N	\N	9	2	\N	\N	\N
1962	Dennis Robert David	Rogan	1942-06-30	\N	\N	19	1	\N	\N	\N
1966	Christopher John	Rennard	1960-07-08	\N	\N	19	1	\N	\N	\N
1978	Rosalie Catherine	Wilkins	1946-05-06	\N	\N	24	2	\N	\N	\N
1999	Richard Rashleigh Folliott	Scott	1934-10-02	\N	\N	20	1	\N	\N	\N
2011	Robert Michael James	Gascoyne-Cecil	1946-09-30	\N	\N	8	1	\N	\N	\N
2023	Bhikhu Chotalal	Parekh	1935-01-04	\N	\N	17	1	\N	\N	\N
2036	Peter Richard Grenville	Layard	1934-03-15	\N	\N	13	1	\N	\N	\N
2045	Valerie Georgina	Howarth	1940-09-05	\N	\N	9	2	\N	\N	\N
2052	Victor Olufemi	Adebowale	1962-07-21	\N	\N	2	1	\N	\N	\N
2061	Thomas Jeremy	King	1933-07-13	\N	\N	12	1	\N	\N	\N
2068	Robert McCredie	May	1936-01-08	2020-04-28	\N	14	1	\N	\N	\N
2075	George Leonard	Carey	1935-11-13	\N	\N	4	1	\N	\N	\N
2083	Paul Rudd	Drayson	1960-03-05	\N	\N	5	1	\N	\N	\N
2091	Ruth Beatrice	Henig	1943-11-10	\N	\N	9	2	\N	\N	\N
2099	Julia Babette Sarah	Neuberger	1950-02-27	\N	\N	15	2	\N	\N	\N
2111	Leonard	Steinberg	1936-08-01	2009-11-02	\N	20	1	\N	\N	\N
2121	Robert Douglas	Carswell	1934-06-28	\N	\N	4	1	\N	\N	\N
2128	Archibald Johnstone	Kirkwood	1946-04-22	\N	\N	12	1	\N	\N	\N
2140	Lewis George	Moonie	1947-02-25	\N	\N	14	1	\N	\N	\N
2151	Alastair Robertson	Goodlad	1943-07-04	\N	\N	8	1	\N	\N	\N
2162	Christopher Francis	Patten	1944-05-12	\N	\N	17	1	\N	\N	\N
2171	Charles Guy Rodney	Leach	1934-06-01	2016-06-12	\N	13	1	\N	\N	\N
2180	Colin MacKenzie	Low	1942-09-23	\N	\N	13	1	\N	\N	\N
2194	Mervyn Allister	King	1948-03-30	\N	\N	12	1	\N	\N	\N
2203	Brian Joseph Michael	Cotter	1936-08-24	\N	\N	4	1	\N	\N	\N
2214	Digby Marritt	Jones	1955-10-28	\N	\N	11	1	\N	\N	\N
2222	John Frederick	Mogg	1943-10-05	\N	\N	14	1	\N	\N	\N
2230	David Philip	Pannick	1956-03-07	\N	\N	17	1	\N	\N	\N
2237	Jonathan Henry	Sacks	1948-03-08	2020-11-07	\N	20	1	\N	\N	\N
2246	John Francis	McFall	1944-10-04	\N	\N	14	1	\N	\N	\N
2253	Margaret Eileen Joyce	Wheeler	1949-03-25	\N	\N	24	2	\N	\N	\N
2262	Shireen Olive	Ritchie	1945-06-22	2012-04-24	\N	19	2	\N	\N	\N
2269	Angela Evans	Smith	1959-01-07	\N	\N	20	2	\N	\N	\N
2278	Andrew Fleming	Green	1941-08-06	\N	\N	8	1	\N	\N	\N
2287	Maeve Christina Mary	Sherlock	1960-11-10	\N	\N	20	2	\N	\N	\N
2297	Helen Margaret	Newlove	1961-12-28	\N	\N	15	2	\N	\N	\N
2303	Ian Warwick	Blair	1953-03-19	\N	\N	3	1	\N	\N	\N
2317	Patrick Thomas	Cormack	1939-05-18	\N	\N	4	1	\N	\N	\N
2326	Terence James	O'Neill	1957-03-17	\N	\N	16	1	\N	\N	\N
2333	Robert Norman	Edmiston	1946-10-06	\N	\N	6	1	\N	\N	\N
2343	Rachael	Heyhoe Flint	1939-06-11	2017-01-18	\N	9	2	\N	\N	\N
2351	Gulam Kaderbhoy	Noon	1936-01-24	2015-10-27	\N	15	1	\N	\N	\N
2358	Nicol Ross	Stephen	1960-03-23	\N	\N	20	1	\N	\N	\N
2377	Kate Harriet Alexandra	Rock	1968-10-09	\N	\N	19	2	\N	\N	\N
2389	Paul Peter	Murphy	1948-11-25	\N	\N	14	1	\N	\N	\N
2399	Diana Mary	Harding	1967-11-09	\N	\N	9	2	\N	\N	\N
2407	Donald Michael Ellison	Foster	1947-03-31	\N	\N	7	1	\N	\N	\N
2417	Alistair Maclean	Darling	1953-11-28	\N	\N	5	1	\N	\N	\N
2424	Timothy John Robert	Kirkhope	1945-04-29	\N	\N	12	1	\N	\N	\N
2432	Christopher	Holmes	1971-10-15	\N	\N	9	1	\N	\N	\N
2439	Diana Francesca Caroline	Barran	1959-02-10	\N	\N	3	2	\N	\N	\N
2450	Olivia Caroline	Bloomfield	1960-06-30	\N	\N	3	2	\N	\N	\N
2460	David Julian	Richards	1952-03-04	\N	\N	19	1	\N	\N	\N
2467	Catherine Irene Jacqueline	Meyer	1953-01-26	\N	\N	14	2	\N	\N	\N
2481	Henry Byron	Davies	1952-09-04	\N	\N	5	1	\N	\N	\N
2488	Gabrielle Louise	Bertin	1978-03-14	\N	\N	3	2	\N	\N	\N
2508	Patrick Alan	McLoughlin	1957-11-30	\N	\N	14	1	\N	\N	\N
2517	Veronica Judith Colleton	Wadley	1952-02-28	\N	\N	24	2	\N	\N	\N
2526	Brinley Howard	Davies	1944-05-17	\N	\N	5	1	\N	\N	\N
2530	Margaret Mary	Ritchie	1958-03-25	\N	\N	19	2	\N	\N	\N
2539	Richard Henry Ronald	Benyon	1960-10-21	\N	\N	3	1	\N	\N	\N
2549	Vernon Rodney	Coaker	1953-06-17	\N	\N	4	1	\N	\N	\N
2557	Joseph Edmund	Johnson	1971-12-23	\N	\N	11	1	\N	\N	\N
2583	William James Peake	Mason	1862-11-11	1947-07-21	\N	14	1	\N	\N	\N
2596	Henry James	Scrymgeour-Wedderburn	1902-05-03	1983-06-29	\N	20	1	\N	\N	\N
2608	George Richard Hodges	Nugent	1907-06-06	1994-03-16	\N	15	1	\N	\N	\N
2619	Victor Alexander George Anthony	Warrender	1899-06-23	1993-01-14	\N	24	1	\N	\N	\N
2631	Roger Nicholas	Edwards	1934-02-25	2018-03-17	\N	6	1	\N	\N	\N
2636	Geoffrey	Finsberg	1926-06-13	1996-10-07	\N	7	1	\N	\N	\N
2641	Robert	Kilpatrick	1926-07-29	2015-09-16	\N	12	1	\N	\N	\N
2646	William Armand Thomas Tristan	Garel-Jones	1941-02-28	2020-03-24	\N	8	1	\N	\N	\N
2659	Patrick Robert	Carter	1946-02-09	\N	\N	4	1	\N	\N	\N
2668	Jane Susan	Campbell	1959-04-19	\N	\N	4	2	\N	\N	\N
2676	Richard John Grenville	Spring	1946-09-24	\N	\N	20	1	\N	\N	\N
2687	Nicholas Ian	Macpherson	1959-07-14	\N	\N	14	1	\N	\N	\N
2696	Charles	Tottenham Loftus	1738-01-23	1806-03-22	\N	21	1	\N	\N	\N
2706	William Fitz Gerald	Vesey-FitzGerald	\N	1843-05-11	\N	23	1	\N	\N	\N
2717	Elspeth Rosamund Morton	Howe	1932-02-08	\N	\N	9	2	\N	\N	\N
2724	Martin Michael Charles	Charteris	1913-09-07	1999-12-23	\N	4	1	\N	\N	\N
2736	Rosalind Patricia-Anne	Howells	1931-01-10	\N	\N	9	2	\N	\N	\N
2746	John Nicholas Reynolds	Houghton	1954-10-18	\N	\N	9	1	\N	\N	\N
2750	Richard	Hely-Hutchinson	1756-01-29	1825-08-22	\N	9	1	\N	\N	\N
2759	Charles Morgan Robinson	Morgan	1792-04-10	1875-04-16	\N	14	1	\N	\N	\N
2775	Alexander Frederick	Douglas-Home	1903-07-02	1995-10-09	\N	5	1	\N	\N	\N
2798	Roger Mellor	Makins	1904-02-03	1996-11-09	\N	14	1	\N	\N	\N
2807	Michael Colin	Cowdrey	1932-12-24	2000-12-04	\N	4	1	\N	\N	\N
2817	George Samuel Knatchbull	Young	1941-07-16	\N	\N	26	1	\N	\N	\N
2825	Anne Hay-Mackenzie	Sutherland-Leveson-Gower	1829-04-21	1888-11-25	\N	20	2	\N	\N	\N
2834	Gilbert Henry	Heathcote-Drummond-Willoughby	1830-10-01	1910-12-24	\N	9	1	\N	\N	\N
26	John Denis	Brown	1756-06-11	1809-06-02	\N	3	1	\N	\N	\N
37	Alexander	Wedderburn	1733-02-13	1805-01-03	\N	24	1	\N	\N	\N
58	Charles William	Stewart	1778-05-18	1854-03-06	\N	20	1	\N	\N	\N
81	Richard William Penn	Howe	1796-12-11	1870-05-12	\N	9	1	\N	\N	\N
103	Ulick John	de Burgh	1802-12-20	1874-04-10	\N	5	1	\N	\N	\N
117	James Archibald Stuart Wortley	Mackenzie	1776-10-06	1845-12-19	\N	14	1	\N	\N	\N
152	Edward Pryce	Lloyd	1768-09-17	1854-04-03	\N	13	1	\N	\N	\N
175	Edward John	Littleton	1791-03-18	1863-05-04	\N	13	1	\N	\N	\N
201	John Thomas	Stanley	1766-11-26	1850-10-02	\N	20	1	\N	\N	\N
220	James Henry Robert	Innes-Ker	1816-07-12	1879-04-23	\N	10	1	\N	\N	\N
256	Thomas	Pemberton Leigh	1793-02-11	1867-10-07	\N	17	1	\N	\N	\N
282	Edward George Earle Lytton	Bulwer Lytton	1803-05-25	1873-01-18	\N	3	1	\N	\N	\N
320	John Charles Herbert Welbore Ellis	Agar	1818-09-17	1896-12-19	\N	2	1	\N	\N	\N
338	Charles Henry	Gordon-Lennox	1818-02-27	1903-09-27	\N	8	1	\N	\N	\N
368	William Ulick Tristram	St Lawrence	1827-06-25	1909-03-09	\N	20	1	\N	\N	\N
390	Nathaniel Mayer	Rothschild	1840-11-08	1915-03-31	\N	19	1	\N	\N	\N
409	Michael Arthur	Bass	1837-11-12	1909-02-01	\N	3	1	\N	\N	\N
438	Henry John Selwyn	Ibbetson	1826-09-26	1902-01-15	\N	10	1	\N	\N	\N
446	William John	Legh	1828-12-19	1898-12-15	\N	13	1	\N	\N	\N
467	Arthur Wellesley	Peel	1829-08-03	1912-10-24	\N	17	1	\N	\N	\N
489	Horace Brand	Townsend-Farquhar	1844-05-18	1923-08-30	\N	21	1	\N	\N	\N
513	Ughtred James	Kay-Shuttleworth	1844-12-18	1939-12-20	\N	12	1	\N	\N	\N
535	Henry Meysey	Meysey-Thompson	1845-08-30	1929-03-03	\N	14	1	\N	\N	\N
560	Henry Hartley	Fowler	1830-05-16	1911-02-25	\N	7	1	\N	\N	\N
580	John Henry	de Villiers	1842-06-15	1914-09-02	\N	5	1	\N	\N	\N
598	Charles Ernest Alfred French Somerset	Butler	1873-11-15	1931-11-02	\N	3	1	\N	\N	\N
617	Herbert Hardy	Cozens-Hardy	1838-11-22	1920-06-18	\N	4	1	\N	\N	\N
640	Edward	Grey	1862-04-25	1933-09-07	\N	8	1	\N	\N	\N
655	Frederick Henry	Smith	1859-01-24	1946-01-26	\N	20	1	\N	\N	\N
664	James Thomas	Woodhouse	1852-07-16	1921-02-08	\N	24	1	\N	\N	\N
681	Satyendra Prasanna	Sinha	1864-06-01	1928-03-05	\N	20	1	\N	\N	\N
694	Rosslyn Erskine	Wemyss	1864-04-12	1933-05-24	\N	24	1	\N	\N	\N
710	Frederic John Napier	Thesiger	1868-08-12	1933-04-01	\N	21	1	\N	\N	\N
735	Herbert Merton	Jessel	1866-10-27	1950-11-01	\N	11	1	\N	\N	\N
752	Edward Frederick Lindley	Wood	1881-04-16	1959-12-23	\N	24	1	\N	\N	\N
777	Thomas James Chesshyre	Tomlin	1867-05-06	1935-08-12	\N	21	1	\N	\N	\N
803	Henry Sanderson	Furniss	1868-10-01	1939-03-25	\N	7	1	\N	\N	\N
831	William Warrender	Mackenzie	1860-08-19	1942-05-05	\N	14	1	\N	\N	\N
852	Edward Hilton	Young	1879-03-20	1960-07-11	\N	26	1	\N	\N	\N
871	Alfred Ernle Montacute	Chatfield	1873-09-27	1967-11-15	\N	4	1	\N	\N	\N
875	Frederick George	Penny	1876-03-10	1955-01-01	\N	17	1	\N	\N	\N
895	Maurice Paschal Alers	Hankey	1877-04-01	1963-01-25	\N	9	1	\N	\N	\N
918	Hugh Michael	Seely	1898-10-02	1970-04-01	\N	20	1	\N	\N	\N
947	Harold Harington	Balfour	1897-11-01	1988-09-21	\N	3	1	\N	\N	\N
969	Courtauld Greenwood	Courtauld-Thomson	1865-08-16	1954-11-01	\N	4	1	\N	\N	\N
983	Harold Rupert Leofric George	Alexander	1891-12-10	1969-06-16	\N	2	1	\N	\N	\N
1007	Frederick	Montague	1876-10-08	1966-10-15	\N	14	1	\N	\N	\N
1028	Lewis	Silkin	1889-11-14	1972-05-11	\N	20	1	\N	\N	\N
1042	John Clarke	MacDermott	1896-04-12	1979-07-13	\N	14	1	\N	\N	\N
1059	Alfred Jesse	Suenson-Taylor	1893-08-14	1976-07-02	\N	20	1	\N	\N	\N
1079	Arnold Duncan	McNair	1885-03-04	1975-05-22	\N	14	1	\N	\N	\N
1096	Patrick George Thomas	Buchan-Hepburn	1901-04-02	1974-11-05	\N	3	1	\N	\N	\N
1111	Charles Philip Arthur George	-	1948-11-14	\N	\N	1	1	\N	\N	\N
1139	Basil	Sanderson	1894-06-19	1971-08-15	\N	20	1	\N	\N	\N
1155	Henry David Leonard George	Walston	1912-06-16	1991-05-29	\N	24	1	\N	\N	\N
1178	Arthur Malcolm Trustram	Eve	1894-04-08	1976-12-03	\N	6	1	\N	\N	\N
1200	Dennis Forwood	Vosper	1916-01-02	1968-01-20	\N	23	1	\N	\N	\N
1216	Charles Percy	Snow	1905-10-15	1980-07-01	\N	20	1	\N	\N	\N
1234	Michael Henry Colin	Hughes-Young	1912-10-28	1980-12-27	\N	9	1	\N	\N	\N
1260	William Stephen Richard	King-Hall	1893-01-21	1966-06-02	\N	12	1	\N	\N	\N
1278	Evelyn Adelaide	Sharp	1903-05-25	1985-09-01	\N	20	2	\N	\N	\N
1314	John Henry	Jacques	1905-01-11	1995-12-20	\N	11	1	\N	\N	\N
1333	Edward Charles Gurney	Boyle	1923-08-31	1981-09-28	\N	3	1	\N	\N	\N
1347	William Miles Webster	Thomas	1897-03-02	1980-02-08	\N	21	1	\N	\N	\N
1361	James Dawson	Chichester-Clark	1923-02-12	2002-05-17	\N	4	1	\N	\N	\N
1378	John Henderson	Hunt	1905-07-03	1987-12-28	\N	9	1	\N	\N	\N
1395	Irene Mervyn Parnicott	Pike	1918-09-16	2004-01-11	\N	17	2	\N	\N	\N
1424	Frederick Elwyn	Jones	1909-10-24	1989-12-04	\N	11	1	\N	\N	\N
1445	Charles Ritchie	Russell	1908-01-12	1986-06-23	\N	19	1	\N	\N	\N
1469	Thomas Frederick	Peart	1914-04-30	1988-08-26	\N	17	1	\N	\N	\N
1487	Francis Arthur	Cockfield	1916-09-28	2007-01-08	\N	4	1	\N	\N	\N
1510	Brian Hilton	Flowers	1924-09-13	2010-06-25	\N	7	1	\N	\N	\N
1543	William John	Blease	1914-05-28	2008-05-16	\N	3	1	\N	\N	\N
1560	Theodore	Constantine	1910-03-15	2004-02-13	\N	4	1	\N	\N	\N
1586	George Anthony Geoffrey	Howard	1920-05-22	1984-11-27	\N	9	1	\N	\N	\N
1609	Arthur George	Bottomley	1907-02-07	1995-11-03	\N	3	1	\N	\N	\N
1631	Desmond James Conrad	Ackner	1920-09-18	2006-03-21	\N	2	1	\N	\N	\N
1651	Michael Francis Lovell	Cocks	1929-08-19	2001-03-26	\N	4	1	\N	\N	\N
1667	Judith Constance Mary	Hart	1924-09-18	1991-12-08	\N	9	2	\N	\N	\N
1688	Ivor Seward	Richard	1932-05-30	2018-03-18	\N	19	1	\N	\N	\N
1701	Jeffrey Maurice	Sterling	1934-12-27	\N	\N	20	1	\N	\N	\N
1723	Geoffrey Leonard	Cheshire	1917-09-07	1992-07-31	\N	4	1	\N	\N	\N
1749	John Leonard	Eatwell	1945-02-02	\N	\N	6	1	\N	\N	\N
1765	Shirley Vivien Teresa Brittain	Williams	1930-07-27	2021-04-12	\N	24	2	\N	\N	\N
1799	John Graham	Cuckney	1925-07-12	2008-10-30	\N	4	1	\N	\N	\N
1826	Elizabeth Conway	Symons	1951-04-14	\N	\N	20	2	\N	\N	\N
1855	Robin Brunskill	Cooke	1926-05-09	2006-08-30	\N	4	1	\N	\N	\N
1876	Michael Graham Ruddock	Sandberg	1927-05-31	2017-07-02	\N	20	1	\N	\N	\N
1900	Cranley Gordon Douglas	Onslow	1926-06-08	2001-03-13	\N	16	1	\N	\N	\N
1929	Christopher Robin	Haskins	1937-05-30	\N	\N	9	1	\N	\N	\N
1952	Alexander James	Trotman	1933-07-22	2005-04-25	\N	21	1	\N	\N	\N
1971	Anthony Stephen	Grabiner	1945-03-21	\N	\N	8	1	\N	\N	\N
1992	Thomas Orlando	Lyttelton	1953-02-12	\N	\N	13	1	\N	\N	\N
2006	Antony Charles Robert	Armstrong-Jones	1930-03-07	2017-01-13	\N	2	1	\N	\N	\N
2030	George Lennox	Fyfe	1941-04-10	2011-02-01	\N	7	1	\N	\N	\N
2069	Robert Adam Ross	Maclennan	1936-06-26	2020-01-18	\N	14	1	\N	\N	\N
2076	Richard Thomas James	Wilson	1942-10-11	\N	\N	24	1	\N	\N	\N
2102	Diljit Singh	Rana	1938-09-20	\N	\N	19	1	\N	\N	\N
2116	Edward	Rowlands	1940-01-23	\N	\N	19	1	\N	\N	\N
2136	David William George	Chidgey	1942-07-09	\N	\N	4	1	\N	\N	\N
2156	Josephine Clare	Valentine	1958-12-08	\N	\N	23	2	\N	\N	\N
2178	Keith John Charles	Bradley	1950-05-17	\N	\N	3	1	\N	\N	\N
2197	Zahida Parveen	Manzoor	1958-05-25	\N	\N	14	2	\N	\N	\N
2218	Lilian Pauline	Neville-Jones	1939-11-02	\N	\N	15	2	\N	\N	\N
2259	John Cradock	Maples	1943-04-22	2012-06-09	\N	14	1	\N	\N	\N
2290	Robert Antony	Hayward	1949-03-11	\N	\N	9	1	\N	\N	\N
2305	Edward Peter Lawless	Faulks	1950-08-19	\N	\N	7	1	\N	\N	\N
2335	Benjamin Russell Mackintosh	Stoneham	1948-08-24	\N	\N	20	1	\N	\N	\N
2375	Kevin Joseph Maximilian	Shinkwin	1971-06-07	\N	\N	20	1	\N	\N	\N
2396	Christopher Francis	Fox	1957-09-27	\N	\N	7	1	\N	\N	\N
2428	Matthew Hadrian Marshall	Carrington	1947-10-19	\N	\N	4	1	\N	\N	\N
2461	Christopher Edward Wollaston MacKenzie	Geidt	1961-08-17	\N	\N	8	1	\N	\N	\N
2494	Robert John	Reed	1956-09-07	\N	\N	19	1	\N	\N	\N
2516	Catharine Letitia	Hoey	1946-06-21	\N	\N	9	2	\N	\N	\N
2546	Jacqueline	Foster	1947-12-30	\N	\N	7	2	\N	\N	\N
2561	Alexander Nelson	Hood	1814-12-23	1904-06-04	\N	9	1	\N	\N	\N
2574	Wentworth Canning Blackett	Beaumont	1860-12-02	1923-12-12	\N	3	1	\N	\N	\N
2597	Arnold Babb	Gridley	1878-07-16	1965-07-27	\N	8	1	\N	\N	\N
2613	Jocelyn Edward Salis	Simon	1911-01-15	2006-05-07	\N	20	1	\N	\N	\N
2639	Derek Oliver	Gladwin	1930-06-06	2003-04-10	\N	8	1	\N	\N	\N
2662	Virginia Hilda Brunette Maxwell	Bottomley	1948-03-12	\N	\N	3	2	\N	\N	\N
2693	Amirali Alibhai	Bhatia	1932-03-18	\N	\N	3	1	\N	\N	\N
2710	Cecil George Savile	Foljambe	1846-11-07	1907-03-23	\N	7	1	\N	\N	\N
2741	Nicholas Herbert	Stern	1946-04-22	\N	\N	20	1	\N	\N	\N
9	George Keith	Elphinstone	1746-01-07	1823-03-10	\N	6	1	\N	\N	\N
2752	Gustavus Frederick	Hamilton Russell	1797-05-11	1872-10-27	\N	9	1	\N	\N	\N
2774	Alice Martha	Bacon	1909-09-10	1993-03-24	\N	3	2	\N	\N	\N
2808	David Stuart	Sheppard	1929-03-06	2005-03-05	\N	20	1	\N	\N	\N
2844	Maurice Harold	Macmillan	1894-02-10	1986-12-29	\N	14	1	\N	\N	\N
53	Thomas	Graham	1748-10-19	1843-12-18	\N	8	1	\N	\N	\N
60	Richard	Trench Le Poer	1767-05-18	1837-11-24	\N	21	1	\N	\N	\N
188	William Francis Spencer	Ponsonby	1787-07-31	1855-05-16	\N	17	1	\N	\N	\N
335	Arthur Edward Holland Grey	Egerton	1833-11-25	1885-01-18	\N	6	1	\N	\N	\N
436	Charles John	Colville	1818-11-23	1903-07-01	\N	4	1	\N	\N	\N
540	William Henry	Grenfell	1855-10-30	1945-01-09	\N	8	1	\N	\N	\N
661	Frederick	Cawley	1850-10-09	1937-03-30	\N	4	1	\N	\N	\N
744	Christopher Birdwood	Thomson	1875-04-13	1930-10-05	\N	21	1	\N	\N	\N
846	Frederick Edward Grey	Ponsonby	1867-09-16	1935-10-20	\N	17	1	\N	\N	\N
971	Robert Samuel Theodore	Chorley	1895-05-29	1978-01-27	\N	4	1	\N	\N	\N
981	John Standish Surtees Prendergast	Vereker	1886-07-10	1946-03-31	\N	23	1	\N	\N	\N
1009	Louis Francis Albert Victor Nicholas	Mountbatten	1900-06-25	1979-08-27	\N	14	1	\N	\N	\N
1205	Hendrie Dudley	Oakshott	1904-11-08	1975-02-01	\N	16	1	\N	\N	\N
1305	William John St. Clair	Anstruther-Gray	1905-03-05	1985-08-06	\N	2	1	\N	\N	\N
1471	Henry Shanks	Keith	1922-02-07	2002-06-21	\N	12	1	\N	\N	\N
1532	Margaret Betty	Harvie Anderson	1915-08-01	1979-11-07	\N	9	2	\N	\N	\N
1674	William John Hughes	Butterfield	1920-03-28	2000-07-22	\N	3	1	\N	\N	\N
1779	Patrick Richard Henry	Wright	1931-06-28	2020-03-06	\N	24	1	\N	\N	\N
1875	Ieuan Wyn Pritchard	Roberts	1930-07-10	2013-12-13	\N	19	1	\N	\N	\N
1951	Narendra Babubhai	Patel	1938-05-11	\N	\N	17	1	\N	\N	\N
1986	Peter Richard Charles	Smith	1945-07-24	\N	\N	20	1	\N	\N	\N
2073	Conrad Moffat	Black	1944-08-25	\N	\N	3	1	\N	\N	\N
2188	John Alfred Stoddard	Nash	1949-03-22	\N	\N	15	1	\N	\N	\N
2309	Michael Charles	Williams	1949-06-11	2017-04-23	\N	24	1	\N	\N	\N
2365	Anne Caroline Ballingall	McIntosh	1954-09-20	\N	\N	14	2	\N	\N	\N
2498	Edward Henry Butler	Vaizey	1968-06-05	\N	\N	23	1	\N	\N	\N
2567	Edward Montagu Stuart Granville	Stuart-Wortley-Mackenzie	1827-12-15	1899-05-13	\N	20	1	\N	\N	\N
2780	Adolphus Charles Alexander Albert Edward George Philip Louis Ladislaus	-	1868-08-13	1927-10-24	\N	1	1	\N	\N	\N
2870	Hugh William Amherst	Cecil	1968-07-17	\N	\N	4	1	\N	\N	\N
2871	Henry Elliott Chevallier	Kitchener	1846-10-05	1937-03-27	\N	12	1	\N	\N	\N
2872	Henry Herbert	Kitchener	1919-02-24	2011-12-16	\N	12	1	\N	\N	\N
2873	Nellie Lisa	Melles	1873-12-27	1962-05-28	\N	14	2	\N	\N	\N
2874	Michael Evan Victor	Baillie	1924-06-27	2013-05-30	\N	3	1	\N	\N	\N
2875	Evan Michael Ronald	Baillie	1949-03-19	\N	\N	3	1	\N	\N	\N
2876	William John Arthur Charles James	Cavendish-Bentinck	1857-12-28	1943-04-26	\N	4	1	\N	\N	\N
2877	William Arthur Henry	Cavendish-Bentinck	1893-03-16	1977-03-21	\N	4	1	\N	\N	\N
2878	Francis	Mackenzie	1852-08-03	1893-11-24	\N	14	1	\N	\N	\N
2879	Sibel Lilian	Mackenzie	1878-08-14	1962-05-20	\N	14	2	\N	\N	\N
2880	Roderick Grant Francis	Mackenzie	1904-10-24	1989-12-13	\N	14	1	\N	\N	\N
2881	John Ruaridh Grant	Mackenzie	1948-06-12	\N	\N	14	1	\N	\N	\N
2882	Stephen Michael Wedgwood	Benn	1951-08-21	\N	\N	3	1	\N	\N	\N
2883	Anthony Ulick David Dundas	Grigg	1934-01-12	2020-08-01	\N	8	1	\N	\N	\N
2884	Edward Sebastian	Grigg	1965-12-18	\N	\N	8	1	\N	\N	\N
2885	Henry Duncan	McLaren	1879-04-16	1953-05-23	\N	14	1	\N	\N	\N
2886	Charles Melville	McLaren	1913-04-16	2003-02-04	\N	14	1	\N	\N	\N
2887	Henry Charles	McLaren	1948-05-26	\N	\N	14	1	\N	\N	\N
2888	Henry Campbell	Bruce	1851-06-19	1929-02-20	\N	3	1	\N	\N	\N
2889	Clarence Napier	Bruce	1885-08-02	1957-10-04	\N	3	1	\N	\N	\N
2890	Morys George Lyndhurst	Bruce	1919-06-16	\N	\N	3	1	\N	\N	\N
2891	Alaster John Lyndhurst	Bruce	1947-05-02	\N	\N	3	1	\N	\N	\N
2892	George	Gordon	1879-01-20	1965-01-06	\N	8	1	\N	\N	\N
2893	Dudley Gladstone	Gordon	1883-05-06	1972-04-16	\N	8	1	\N	\N	\N
2894	David George Ian Alexander	Gordon	1908-01-21	1974-09-13	\N	8	1	\N	\N	\N
2895	Archibald Victor Dudley	Gordon	1913-07-09	\N	\N	8	1	\N	\N	\N
2896	Alastair Ninian John	Gordon	1920-07-20	2002-08-19	\N	8	1	\N	\N	\N
2897	Alexander George	Gordon	1955-03-31	2020-03-12	\N	8	1	\N	\N	\N
2898	George Ian Alastair	Gordon	1983-05-04	\N	\N	8	1	\N	\N	\N
2899	Reginald William Bransby	Nevill	1853-03-04	1927-10-13	\N	15	1	\N	\N	\N
2900	Henry Gilbert Ralph	Nevill	1854-09-02	1938-01-10	\N	15	1	\N	\N	\N
2901	Guy Temple Montacute	Nevill	1883-07-15	1954-03-30	\N	15	1	\N	\N	\N
2902	John Henry Guy	Nevill	1914-11-08	2000-02-23	\N	15	1	\N	\N	\N
2903	Christopher George Charles	Nevill	1955-04-23	\N	\N	15	1	\N	\N	\N
2904	Henry	Howard	\N	\N	Henry Howard styled Lord Walden, eldest son of Henry Earl of Suffolk	9	1	\N	\N	\N
2905	Hugh	\N	\N	\N	Hugh Viscount Cholmondeley (I) and Lord Cholmondeley (E)	\N	1	\N	\N	\N
2906	Sidney	\N	\N	\N	\N	\N	1	\N	\N	\N
2907	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2908	Thomas	\N	\N	\N	\N	\N	1	\N	\N	\N
2909	Evelyn	\N	\N	\N	\N	\N	1	\N	\N	\N
2910	Robert	\N	\N	\N	\N	\N	1	\N	\N	\N
2911	Thomas	Pelham	\N	\N	\N	17	1	\N	\N	\N
2912	William	Cowper	\N	\N	\N	4	1	\N	\N	\N
2913	James	\N	\N	\N	\N	\N	1	\N	\N	\N
2914	Charles Sloane	\N	\N	\N	\N	\N	1	\N	\N	\N
2915	Alexander	\N	\N	\N	Alexander Lord Bridport (I & GB)	\N	1	\N	\N	\N
2916	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2917	John	McClintock	\N	\N	\N	14	1	\N	\N	\N
2918	James	\N	\N	\N	James Marquess of Abercorn (GB) and Viscount Strabane	\N	1	\N	\N	\N
2919	Edmund Burke	Roche	\N	\N	\N	19	1	\N	\N	\N
2920	Patrick	Bellew	\N	\N	\N	3	1	\N	\N	\N
2921	Henry	\N	\N	\N	\N	\N	1	\N	\N	\N
2922	George Lewis	\N	\N	\N	\N	\N	1	\N	\N	\N
2923	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2924	Ralph	\N	\N	\N	\N	\N	1	\N	\N	\N
2925	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2926	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2927	John	Hervey	\N	\N	\N	9	1	\N	\N	\N
2928	Francis	Seymour Conway	\N	\N	\N	20	1	\N	\N	\N
2929	John	Leveson Gower	\N	\N	\N	13	1	\N	\N	\N
2930	Ernest Augustus	\N	\N	\N	\N	\N	1	\N	\N	\N
2931	Edward	\N	\N	\N	\N	\N	1	\N	\N	\N
2932	Francis	\N	\N	\N	\N	\N	1	\N	\N	\N
2933	Adam	Duncan	\N	\N	\N	5	1	\N	\N	\N
2934	Francis Humberstone	MacKenzie	\N	\N	\N	14	1	\N	\N	\N
2935	James	Drummond	\N	\N	\N	5	1	\N	\N	\N
2936	Thomas	Lister	\N	\N	\N	13	1	\N	\N	\N
2937	Thomas	Powys	\N	\N	\N	17	1	\N	\N	\N
2938	James	Daly	\N	\N	\N	5	1	\N	\N	\N
2939	Dominick	Browne	\N	\N	\N	3	1	\N	\N	\N
2940	Margaret	Talbot	\N	\N	\N	21	2	\N	\N	\N
2941	Standish	O'Grady	\N	\N	\N	16	1	\N	\N	\N
2942	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2943	Catherine	Fitzgerald	\N	\N	\N	7	2	\N	\N	\N
2048	Paul Leslie	Condon	1947-03-10	\N	\N	4	1	Q332919	315	289
\.


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('people_id_seq', 2943, true);


--
-- Data for Name: rank_labels; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY rank_labels (id, label, rank_id, gender_id) FROM stdin;
3	Earl	6	1
4	Lord	8	1
5	Marquess	9	1
6	Viscount	12	1
8	Duke	4	1
10	Prince	11	1
1	Baroness	8	2
2	Countess	6	2
7	Viscountess	12	2
9	Duchess	4	2
11	Lady	14	2
\.


--
-- Name: rank_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('rank_labels_id_seq', 11, true);


--
-- Data for Name: ranks; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY ranks (degree, label, id, is_peerage_rank) FROM stdin;
3	Earldom	6	t
5	Barony	8	t
2	Marquessate	9	t
4	Viscountcy	12	t
1	Dukedom	4	t
0	Prince	11	f
5	Lordship	14	t
\.


--
-- Name: ranks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('ranks_id_seq', 14, true);


--
-- Data for Name: reigning_monarchs; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY reigning_monarchs (id, reign_id, monarch_id) FROM stdin;
1	1	1
2	2	2
3	3	3
4	4	4
5	5	5
6	6	6
7	7	7
8	8	8
9	9	9
10	10	9
11	11	9
12	12	10
13	13	10
14	14	11
15	15	11
16	16	12
17	17	12
18	18	12
19	19	12
20	20	13
21	21	13
22	22	13
23	23	13
24	23	14
25	24	13
26	24	14
27	25	13
28	25	14
29	26	15
30	27	15
31	28	15
32	29	16
33	30	16
34	31	16
35	32	17
36	33	17
37	34	17
38	35	18
39	36	18
40	37	18
\.


--
-- Name: reigning_monarchs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('reigning_monarchs_id_seq', 40, true);


--
-- Data for Name: reigns; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY reigns (id, title, start_on, end_on, kingdom_id) FROM stdin;
1	Elizabeth II	1952-02-06	\N	5
2	George VI	1936-12-11	1952-02-06	5
3	Edward VIII	1936-01-20	1936-12-11	5
4	George V	1910-05-06	1936-01-20	5
5	Edward VII	1901-01-22	1910-05-06	5
6	Victoria	1837-06-20	1901-01-22	5
7	William IV	1830-06-26	1837-06-20	5
8	George IV	1820-01-29	1830-06-26	5
9	George III	1760-10-25	1801-01-01	4
10	George III	1760-10-25	1801-01-01	3
11	George III	1801-01-01	1820-01-29	5
12	George II	1727-06-11	1760-10-25	4
13	George II	1727-06-11	1760-10-25	3
14	George I	1714-08-01	1727-06-11	4
15	George I	1714-08-01	1727-06-11	3
16	Anne	1702-03-08	1707-05-01	1
17	Anne	1702-03-08	1707-05-01	2
18	Anne	1707-05-01	1714-08-01	4
19	Anne	1702-03-08	1714-08-01	3
20	William III	1694-12-28	1702-03-08	1
21	William III	1694-12-28	1702-03-08	2
22	William III	1694-12-28	1702-03-08	3
23	William III and Mary II	1689-02-13	1694-12-28	1
24	William III and Mary II	1689-04-11	1694-12-28	2
25	William III and Mary II	1689-02-13	1694-12-28	3
26	James II	1685-02-06	1688-12-23	1
27	James II	1685-02-06	1689-04-11	2
28	James II	1685-02-06	1688-12-23	3
29	Charles II	1649-01-30	1685-02-06	1
30	Charles II	1649-01-30	1685-02-06	2
31	Charles II	1649-01-30	1685-02-06	3
32	Charles I	1625-03-27	1649-01-30	1
33	Charles I	1625-03-27	1649-01-30	2
34	Charles I	1625-03-27	1649-01-30	3
35	James I	1603-03-24	1625-03-27	1
36	James I	1567-07-24	1625-03-27	2
37	James I	1603-03-24	1625-03-27	3
\.


--
-- Name: reigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('reigns_id_seq', 37, true);


--
-- Data for Name: special_remainders; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY special_remainders (id, description) FROM stdin;
1	Peerages which may be inherited by a male indirect descendant of the first holder, for example: a brother or a male cousin.
2	Peerages which may be inherited by a female direct descendant.
3	Peerages with rules of limited inheritance, for example: the 1st Baroness Abercromby, whose peerage was limited to male descendants of her late husband.
\.


--
-- Name: special_remainders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('special_remainders_id_seq', 4, true);


--
-- Name: administrations_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY administrations
    ADD CONSTRAINT administrations_pkey PRIMARY KEY (id);


--
-- Name: announcement_types_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcement_types
    ADD CONSTRAINT announcement_types_pkey PRIMARY KEY (id);


--
-- Name: announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: genders_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY genders
    ADD CONSTRAINT genders_pkey PRIMARY KEY (id);


--
-- Name: jurisdictions_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY jurisdictions
    ADD CONSTRAINT jurisdictions_pkey PRIMARY KEY (id);


--
-- Name: kingdom_ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT kingdom_ranks_pkey PRIMARY KEY (id);


--
-- Name: kingdoms_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdoms
    ADD CONSTRAINT kingdoms_pkey PRIMARY KEY (id);


--
-- Name: law_lord_incumbencies_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies
    ADD CONSTRAINT law_lord_incumbencies_pkey PRIMARY KEY (id);


--
-- Name: letters_patent_times_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patent_times
    ADD CONSTRAINT letters_patent_times_pkey PRIMARY KEY (id);


--
-- Name: letters_patents_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT letters_patents_pkey PRIMARY KEY (id);


--
-- Name: letters_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters
    ADD CONSTRAINT letters_pkey PRIMARY KEY (id);


--
-- Name: monarchs_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY monarchs
    ADD CONSTRAINT monarchs_pkey PRIMARY KEY (id);


--
-- Name: peerage_holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT peerage_holdings_pkey PRIMARY KEY (id);


--
-- Name: peerage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_types
    ADD CONSTRAINT peerage_types_pkey PRIMARY KEY (id);


--
-- Name: peerages_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT peerages_pkey PRIMARY KEY (id);


--
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: rank_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT rank_labels_pkey PRIMARY KEY (id);


--
-- Name: ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY ranks
    ADD CONSTRAINT ranks_pkey PRIMARY KEY (id);


--
-- Name: reigning_monarchs_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigning_monarchs
    ADD CONSTRAINT reigning_monarchs_pkey PRIMARY KEY (id);


--
-- Name: reigns_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns
    ADD CONSTRAINT reigns_pkey PRIMARY KEY (id);


--
-- Name: special_remainders_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY special_remainders
    ADD CONSTRAINT special_remainders_pkey PRIMARY KEY (id);


--
-- Name: announcement_type; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements
    ADD CONSTRAINT announcement_type FOREIGN KEY (announcement_type_id) REFERENCES announcement_types(id);


--
-- Name: fk_announcement; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_announcement FOREIGN KEY (announcement_id) REFERENCES announcements(id);


--
-- Name: fk_gender; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT fk_gender FOREIGN KEY (gender_id) REFERENCES genders(id);


--
-- Name: fk_gender; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT fk_gender FOREIGN KEY (gender_id) REFERENCES genders(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_letter; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT fk_letter FOREIGN KEY (letter_id) REFERENCES letters(id);


--
-- Name: fk_letters_patent_time; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_letters_patent_time FOREIGN KEY (letters_patent_time_id) REFERENCES letters_patent_times(id);


--
-- Name: fk_monarch; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigning_monarchs
    ADD CONSTRAINT fk_monarch FOREIGN KEY (monarch_id) REFERENCES monarchs(id);


--
-- Name: fk_peerage; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT fk_peerage FOREIGN KEY (peerage_id) REFERENCES peerages(id);


--
-- Name: fk_person; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT fk_person FOREIGN KEY (person_id) REFERENCES people(id);


--
-- Name: fk_person; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_person FOREIGN KEY (person_id) REFERENCES people(id);


--
-- Name: fk_previous_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_previous_kingdom FOREIGN KEY (previous_kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT fk_rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: fk_rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT fk_rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: fk_reign; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigning_monarchs
    ADD CONSTRAINT fk_reign FOREIGN KEY (reign_id) REFERENCES reigns(id);


--
-- Name: fk_reign; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_reign FOREIGN KEY (reign_id) REFERENCES reigns(id);


--
-- Name: peerage; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies
    ADD CONSTRAINT peerage FOREIGN KEY (peerage_id) REFERENCES peerages(id);


--
-- Name: peerage_type; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT peerage_type FOREIGN KEY (peerage_type_id) REFERENCES peerage_types(id);


--
-- Name: rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

