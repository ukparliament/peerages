--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.0
-- Dumped by pg_dump version 9.5.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: administrations; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE administrations (
    number integer,
    prime_minister text NOT NULL,
    start_date date,
    end_date date,
    colour_code text,
    id integer NOT NULL
);


ALTER TABLE administrations OWNER TO michaelsmethurst;

--
-- Name: administrations_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE administrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE administrations_id_seq OWNER TO michaelsmethurst;

--
-- Name: administrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE administrations_id_seq OWNED BY administrations.id;


--
-- Name: announcement_types; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE announcement_types (
    name text,
    id integer NOT NULL
);


ALTER TABLE announcement_types OWNER TO michaelsmethurst;

--
-- Name: announcement_types_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE announcement_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE announcement_types_id_seq OWNER TO michaelsmethurst;

--
-- Name: announcement_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE announcement_types_id_seq OWNED BY announcement_types.id;


--
-- Name: announcements; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE announcements (
    announced_on date NOT NULL,
    in_gazette boolean,
    notes text,
    announcement_type_id integer,
    gazette_url character varying(255),
    id integer NOT NULL,
    administration_id integer
);


ALTER TABLE announcements OWNER TO michaelsmethurst;

--
-- Name: announcements_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE announcements_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE announcements_id_seq OWNER TO michaelsmethurst;

--
-- Name: announcements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE announcements_id_seq OWNED BY announcements.id;


--
-- Name: genders; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE genders (
    id integer NOT NULL,
    label character varying(10) NOT NULL
);


ALTER TABLE genders OWNER TO michaelsmethurst;

--
-- Name: genders_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE genders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE genders_id_seq OWNER TO michaelsmethurst;

--
-- Name: genders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE genders_id_seq OWNED BY genders.id;


--
-- Name: jurisdictions; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE jurisdictions (
    id integer NOT NULL,
    label character varying(100) NOT NULL
);


ALTER TABLE jurisdictions OWNER TO michaelsmethurst;

--
-- Name: jurisdictions_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE jurisdictions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE jurisdictions_id_seq OWNER TO michaelsmethurst;

--
-- Name: jurisdictions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE jurisdictions_id_seq OWNED BY jurisdictions.id;


--
-- Name: kingdom_ranks; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE kingdom_ranks (
    id integer NOT NULL,
    rank_id integer NOT NULL,
    kingdom_id integer NOT NULL
);


ALTER TABLE kingdom_ranks OWNER TO michaelsmethurst;

--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE kingdom_ranks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kingdom_ranks_id_seq OWNER TO michaelsmethurst;

--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE kingdom_ranks_id_seq OWNED BY kingdom_ranks.id;


--
-- Name: kingdoms; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE kingdoms (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    start_on date,
    end_on date
);


ALTER TABLE kingdoms OWNER TO michaelsmethurst;

--
-- Name: kingdoms_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE kingdoms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE kingdoms_id_seq OWNER TO michaelsmethurst;

--
-- Name: kingdoms_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE kingdoms_id_seq OWNED BY kingdoms.id;


--
-- Name: law_lord_incumbencies; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE law_lord_incumbencies (
    appointed_on date NOT NULL,
    vice text,
    end_on date,
    notes text,
    old_office text,
    annuity_from date,
    annuity_london_gazette_issue integer,
    annuity_london_gazette_page integer,
    appointment_london_gazette_issue integer,
    appointment_london_gazette_page integer,
    id integer NOT NULL,
    peerage_id integer,
    jurisdiction_id integer
);


ALTER TABLE law_lord_incumbencies OWNER TO michaelsmethurst;

--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE law_lord_incumbencies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE law_lord_incumbencies_id_seq OWNER TO michaelsmethurst;

--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE law_lord_incumbencies_id_seq OWNED BY law_lord_incumbencies.id;


--
-- Name: letters; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters (
    id integer NOT NULL,
    letter character varying(100) NOT NULL,
    url_key character(1) NOT NULL
);


ALTER TABLE letters OWNER TO michaelsmethurst;

--
-- Name: letters_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_id_seq OWNED BY letters.id;


--
-- Name: letters_patent_times; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters_patent_times (
    id integer NOT NULL,
    label character varying(20) NOT NULL
);


ALTER TABLE letters_patent_times OWNER TO michaelsmethurst;

--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_patent_times_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_patent_times_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_patent_times_id_seq OWNED BY letters_patent_times.id;


--
-- Name: letters_patents; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE letters_patents (
    id integer NOT NULL,
    patent_on date NOT NULL,
    person_prefix character varying(20),
    person_suffix character varying(20),
    previous_of_title boolean DEFAULT false,
    previous_title character varying(255),
    previous_rank character varying(255),
    ordinality_on_date integer,
    citations text,
    announcement_id integer,
    letters_patent_time_id integer,
    person_id integer,
    kingdom_id integer,
    previous_kingdom_id integer,
    reign_id integer
);


ALTER TABLE letters_patents OWNER TO michaelsmethurst;

--
-- Name: letters_patents_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE letters_patents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE letters_patents_id_seq OWNER TO michaelsmethurst;

--
-- Name: letters_patents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE letters_patents_id_seq OWNED BY letters_patents.id;


--
-- Name: monarchs; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE monarchs (
    id integer NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE monarchs OWNER TO michaelsmethurst;

--
-- Name: monarchs_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE monarchs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE monarchs_id_seq OWNER TO michaelsmethurst;

--
-- Name: monarchs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE monarchs_id_seq OWNED BY monarchs.id;


--
-- Name: peerage_holdings; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerage_holdings (
    id integer NOT NULL,
    ordinality integer NOT NULL,
    start_on date,
    end_on date,
    notes character varying(2000),
    person_id integer NOT NULL,
    peerage_id integer NOT NULL,
    introduced_on date
);


ALTER TABLE peerage_holdings OWNER TO michaelsmethurst;

--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerage_holdings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerage_holdings_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerage_holdings_id_seq OWNED BY peerage_holdings.id;


--
-- Name: peerage_types; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerage_types (
    name text,
    id integer NOT NULL
);


ALTER TABLE peerage_types OWNER TO michaelsmethurst;

--
-- Name: peerage_types_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerage_types_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerage_types_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerage_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerage_types_id_seq OWNED BY peerage_types.id;


--
-- Name: peerages; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE peerages (
    title text,
    territorial_designation text,
    extinct_on date,
    last_number integer,
    notes text,
    id integer NOT NULL,
    peerage_type_id integer,
    rank_id integer,
    wikidata_id character varying(20),
    of_title boolean DEFAULT false,
    special_remainder_id integer,
    letters_patent_id integer,
    kingdom_id integer,
    letter_id integer
);


ALTER TABLE peerages OWNER TO michaelsmethurst;

--
-- Name: peerages_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE peerages_id_seq
    START WITH 2935
    INCREMENT BY 1
    MINVALUE 2935
    NO MAXVALUE
    CACHE 1;


ALTER TABLE peerages_id_seq OWNER TO michaelsmethurst;

--
-- Name: peerages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE peerages_id_seq OWNED BY peerages.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE people (
    id integer NOT NULL,
    forenames character varying(200) NOT NULL,
    surname character varying(100),
    date_of_birth date,
    date_of_death date,
    notes text,
    letter_id integer,
    gender_id integer,
    wikidata_id character varying(20),
    mnis_id character varying(20),
    rush_id character varying(20)
);


ALTER TABLE people OWNER TO michaelsmethurst;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE people_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE people_id_seq OWNER TO michaelsmethurst;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE people_id_seq OWNED BY people.id;


--
-- Name: rank_labels; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE rank_labels (
    id integer NOT NULL,
    label character varying(100) NOT NULL,
    rank_id integer NOT NULL,
    gender_id integer NOT NULL
);


ALTER TABLE rank_labels OWNER TO michaelsmethurst;

--
-- Name: rank_labels_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE rank_labels_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE rank_labels_id_seq OWNER TO michaelsmethurst;

--
-- Name: rank_labels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE rank_labels_id_seq OWNED BY rank_labels.id;


--
-- Name: ranks; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE ranks (
    degree integer,
    label character varying(100),
    id integer NOT NULL,
    is_peerage_rank boolean DEFAULT true
);


ALTER TABLE ranks OWNER TO michaelsmethurst;

--
-- Name: ranks_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE ranks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ranks_id_seq OWNER TO michaelsmethurst;

--
-- Name: ranks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE ranks_id_seq OWNED BY ranks.id;


--
-- Name: reigns; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE reigns (
    id integer NOT NULL,
    start_on date,
    end_on date,
    kingdom_id integer NOT NULL,
    monarch_id integer NOT NULL
);


ALTER TABLE reigns OWNER TO michaelsmethurst;

--
-- Name: reigns_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE reigns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE reigns_id_seq OWNER TO michaelsmethurst;

--
-- Name: reigns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE reigns_id_seq OWNED BY reigns.id;


--
-- Name: special_remainders; Type: TABLE; Schema: public; Owner: michaelsmethurst
--

CREATE TABLE special_remainders (
    id integer NOT NULL,
    description character varying(500) NOT NULL
);


ALTER TABLE special_remainders OWNER TO michaelsmethurst;

--
-- Name: special_remainders_id_seq; Type: SEQUENCE; Schema: public; Owner: michaelsmethurst
--

CREATE SEQUENCE special_remainders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE special_remainders_id_seq OWNER TO michaelsmethurst;

--
-- Name: special_remainders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: michaelsmethurst
--

ALTER SEQUENCE special_remainders_id_seq OWNED BY special_remainders.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY administrations ALTER COLUMN id SET DEFAULT nextval('administrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcement_types ALTER COLUMN id SET DEFAULT nextval('announcement_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements ALTER COLUMN id SET DEFAULT nextval('announcements_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY genders ALTER COLUMN id SET DEFAULT nextval('genders_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY jurisdictions ALTER COLUMN id SET DEFAULT nextval('jurisdictions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks ALTER COLUMN id SET DEFAULT nextval('kingdom_ranks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdoms ALTER COLUMN id SET DEFAULT nextval('kingdoms_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies ALTER COLUMN id SET DEFAULT nextval('law_lord_incumbencies_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters ALTER COLUMN id SET DEFAULT nextval('letters_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patent_times ALTER COLUMN id SET DEFAULT nextval('letters_patent_times_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents ALTER COLUMN id SET DEFAULT nextval('letters_patents_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY monarchs ALTER COLUMN id SET DEFAULT nextval('monarchs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings ALTER COLUMN id SET DEFAULT nextval('peerage_holdings_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_types ALTER COLUMN id SET DEFAULT nextval('peerage_types_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages ALTER COLUMN id SET DEFAULT nextval('peerages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people ALTER COLUMN id SET DEFAULT nextval('people_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels ALTER COLUMN id SET DEFAULT nextval('rank_labels_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY ranks ALTER COLUMN id SET DEFAULT nextval('ranks_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns ALTER COLUMN id SET DEFAULT nextval('reigns_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY special_remainders ALTER COLUMN id SET DEFAULT nextval('special_remainders_id_seq'::regclass);


--
-- Data for Name: administrations; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY administrations (number, prime_minister, start_date, end_date, colour_code, id) FROM stdin;
34	Aberdeen	1852-12-19	\N	CCFFFF	1
17	Addington	1801-03-17	\N	CCCCFF	2
52	Asquith	1908-04-07	1916-12-07	FFCCCC	3
62	Attlee	1945-07-26	1951-10-26	FFCCCC	4
55	Baldwin (1)	1923-05-22	1924-01-22	CCFFFF	5
57	Baldwin (2)	1924-11-04	1929-06-05	CCFFFF	6
59	Baldwin (3)	1935-06-07	1937-05-28	CCFFFF	7
50	Balfour	1902-07-12	1905-12-05	CCCCFF	8
73	Blair	1997-05-02	2007-06-27	FFCCCC	9
54	Bonar Law	1922-10-23	1923-05-22	CCCCFF	10
70	Callaghan	1976-04-05	1979-05-04	FFFFCC	11
51	Campbell-Bannerman	1905-12-05	1908-04-07	FFFFCC	12
23	Canning	1827-04-10	1827-08-08	CCFFFF	13
60	Chamberlain	1937-05-28	1940-05-10	CCCCFF	14
61	Churchill (1)	1940-05-10	1945-07-26	CCFFFF	15
63	Churchill (2)	1951-10-26	1955-04-06	CCFFFF	16
33	Derby (1)	1852-02-23	\N	CCCCFF	17
36	Derby (2)	1858-02-20	\N	CCCCFF	18
39	Derby (3)	1866-06-28	1868-02-27	CCCCFF	19
40	Disraeli (1)	1868-02-27	1868-12-03	CCFFFF	20
42	Disraeli (2)	1874-02-20	1880-04-23	CCFFFF	21
66	Douglas-Home	1963-10-19	1964-10-16	CCCCFF	22
64	Eden	1955-04-06	1957-01-10	CCCCFF	23
41	Gladstone (1)	1868-12-03	1874-02-20	FFFFCC	24
43	Gladstone (2)	1880-04-23	1885-06-23	FFFFCC	25
45	Gladstone (3)	1886-02-01	1886-07-25	FFFFCC	26
47	Gladstone (4)	1892-08-15	1894-03-05	FFFFCC	27
24	Goderich	1827-08-31	\N	CCCCFF	28
19	Grenville	1806-02-11	\N	FFFFCC	29
26	Grey	1830-11-22	\N	CCCCFF	30
68	Heath	1970-06-19	1974-03-04	CCFFFF	31
22	Liverpool	1812-06-08	\N	CCCCFF	32
53	Lloyd George	1916-12-07	1922-10-23	FFFFCC	33
56	MacDonald (1)	1924-01-22	1924-11-04	FFCCCC	34
58	MacDonald (2)	1929-06-05	1935-06-07	FFCCCC	35
65	Macmillan	1957-01-10	1963-10-19	CCFFFF	36
72	Major	1990-11-28	1997-05-02	CCCCFF	37
27	Melbourne (1)	1834-07-16	\N	FFFFCC	38
30	Melbourne (2)	1835-04-18	\N	FFFFCC	39
35	Palmerston (1)	1855-02-06	\N	FFCCCC	40
37	Palmerston (2)	1859-06-12	1865-10-13	FFCCCC	41
29	Peel (1)	1834-12-10	\N	CCCCFF	42
31	Peel (2)	1841-08-30	\N	CCCCFF	43
21	Perceval	1809-10-04	1812-05-11	CCFFFF	44
16	Pitt (1)	1783-12-19	\N	CCFFFF	45
18	Pitt (2)	1804-05-10	1806-01-23	CCFFFF	46
20	Portland (2)	1807-03-31	\N	CCCCFF	47
48	Rosebery	1894-03-05	1895-06-25	FFCCCC	48
32	Russell (1)	1846-06-30	\N	FFFFCC	49
38	Russell (2)	1865-10-29	1866-06-28	FFFFCC	50
44	Salisbury (1)	1885-06-23	1886-02-01	CCFFFF	51
46	Salisbury (2)	1886-07-25	1892-08-15	CCFFFF	52
49	Salisbury (3)	1895-06-25	1902-07-12	CCFFFF	53
71	Thatcher	1979-05-04	1990-11-28	CCFFFF	54
25	Wellington (1)	1828-01-22	\N	CCFFFF	55
28	Wellington (2)	1834-11-17	\N	CCFFFF	56
67	Wilson (1)	1964-10-16	1970-06-19	FFCCCC	57
69	Wilson (2)	1974-03-04	1976-04-05	FFCCCC	58
74	Brown	2007-06-27	2010-05-11	FFFFCC	59
75	Cameron	2010-05-11	2016-07-13	CCFFFF	60
76	May	2016-07-13	2019-07-24	CCCCFF	61
77	Johnson	2019-07-24	\N	CCFFFF	62
\.


--
-- Name: administrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('administrations_id_seq', 62, true);


--
-- Data for Name: announcement_types; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY announcement_types (name, id) FROM stdin;
Appointments Commission list of Crossbench peers	1
Birthday Honours List	2
Coronation Honours List	3
Dissolution Honours List	4
London Gazette Notice	5
New Year Honours List	6
Office holder nominated by PM post 2001	7
Press Notice	8
Resignation Honours List	9
Times report	10
Victory Honours List	11
List of "Working Peers"	12
Initial peerages created under the Life Peerages Act 1958	13
\.


--
-- Name: announcement_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('announcement_types_id_seq', 13, true);


--
-- Data for Name: announcements; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY announcements (announced_on, in_gazette, notes, announcement_type_id, gazette_url, id, administration_id) FROM stdin;
1919-04-29	f	\N	6	\N	4	33
1919-08-12	f	\N	2	\N	5	33
1920-01-01	f	\N	6	\N	6	33
1921-01-01	f	\N	6	\N	8	33
1921-06-04	f	\N	2	\N	9	33
1922-01-02	f	\N	6	\N	10	33
1922-06-03	f	\N	2	\N	11	33
1924-01-01	f	\N	6	\N	13	5
1924-02-08	f	\N	5	\N	14	34
1924-04-22	f	\N	5	\N	15	34
1924-05-30	f	\N	5	\N	16	34
1925-06-03	f	\N	2	\N	18	6
1926-01-01	f	\N	6	\N	19	6
1926-07-03	f	\N	2	\N	20	6
1927-01-01	f	\N	6	\N	21	6
1928-01-02	f	\N	6	\N	23	6
1928-06-04	f	\N	2	\N	24	6
1929-03-01	f	\N	5	\N	25	6
1929-06-03	f	\N	2	\N	26	6
1930-01-01	f	\N	6	\N	28	35
1930-06-03	f	\N	2	\N	29	35
1931-01-01	f	\N	6	\N	30	35
1931-11-17	t	\N	5	\N	31	35
1932-06-03	f	\N	2	\N	33	35
1933-01-02	f	\N	6	\N	34	35
1933-06-03	f	\N	2	\N	35	35
1934-01-01	f	\N	6	\N	36	35
1934-10-09	t	\N	5	\N	38	35
1935-01-01	f	\N	6	\N	39	35
1935-06-03	f	\N	2	\N	40	35
1936-01-01	f	\N	6	\N	41	7
1937-02-01	f	\N	6	\N	43	7
1937-05-11	f	\N	3	\N	44	7
1937-05-28	f	\N	5	\N	45	14
1938-01-01	f	\N	6	\N	46	14
1939-01-02	f	\N	6	\N	48	14
1939-06-08	f	\N	2	\N	49	14
1940-06-13	f	\N	8	\N	50	15
1941-01-01	f	\N	6	\N	51	15
1941-12-22	f	\N	8	\N	53	15
1942-01-01	f	\N	6	\N	54	15
1942-06-11	f	\N	2	\N	55	15
1943-01-01	f	\N	6	\N	56	15
1944-01-01	f	\N	6	\N	58	15
1944-06-08	f	\N	2	\N	59	15
1945-01-01	f	\N	6	\N	60	15
1945-06-08	f	\N	4	\N	61	15
1945-08-14	f	\N	4	\N	63	4
1945-08-17	f	\N	4	\N	64	4
1946-01-01	f	\N	6	\N	65	4
1946-06-13	f	\N	2	\N	66	4
1947-06-12	f	\N	2	\N	68	4
1948-01-01	f	\N	6	\N	69	4
1948-06-10	f	\N	2	\N	70	4
1949-01-01	f	\N	6	\N	71	4
1950-01-02	f	\N	6	\N	73	4
1950-06-08	f	\N	2	\N	74	4
1951-01-01	f	\N	6	\N	75	4
1951-06-07	f	\N	2	\N	76	4
1952-01-01	f	\N	6	\N	78	16
1952-06-05	f	\N	2	\N	79	16
1953-01-01	f	\N	6	\N	80	16
1953-06-01	f	\N	3	\N	81	16
1954-06-10	f	\N	2	\N	83	16
1955-01-01	f	\N	6	\N	84	16
1955-06-09	f	\N	2	\N	85	23
1956-01-01	f	\N	6	\N	86	23
1957-01-01	f	\N	6	\N	88	23
1957-06-13	f	\N	2	\N	89	36
1958-01-01	f	\N	6	\N	90	36
1958-06-12	f	\N	2	\N	91	36
1959-01-23	f	\N	5	\N	93	36
1959-06-13	f	\N	2	\N	94	36
1959-09-19	f	\N	4	\N	95	36
1960-01-01	f	\N	6	\N	96	36
1960-12-31	f	\N	6	\N	98	36
1961-01-16	f	\N	12	\N	99	36
1961-06-10	f	\N	2	\N	100	36
1962-01-01	f	\N	6	\N	101	36
1962-06-02	f	\N	2	\N	103	36
1963-01-01	f	\N	6	\N	104	36
1963-06-08	f	\N	2	\N	105	36
1963-10-22	f	\N	9	\N	106	22
1964-01-01	f	\N	6	\N	108	22
1964-03-31	f	\N	8	\N	109	22
1964-05-05	f	\N	8	\N	110	22
1964-06-13	f	\N	2	\N	111	22
1964-08-05	f	\N	5	\N	113	22
1964-12-01	f	\N	4	\N	114	57
1964-12-04	f	\N	4	\N	115	57
1965-01-01	f	\N	6	\N	116	57
1965-05-01	f	\N	12	\N	118	57
1965-06-12	f	\N	2	\N	119	57
1966-01-01	f	\N	6	\N	120	57
1966-05-19	f	\N	4	\N	121	57
1967-01-01	f	\N	6	\N	123	57
1967-06-10	f	\N	2	\N	124	57
1967-08-03	f	\N	12	\N	125	57
1967-08-28	f	\N	8	\N	126	57
1968-01-01	f	\N	6	\N	128	57
1968-05-01	f	\N	8	\N	129	57
1968-05-31	f	\N	2	\N	130	57
1968-07-25	f	\N	8	\N	131	57
1969-01-01	f	\N	6	\N	133	57
1969-01-31	f	\N	8	\N	134	57
1969-06-14	f	\N	2	\N	135	57
1970-01-01	f	\N	6	\N	136	57
1970-06-13	f	\N	2	\N	138	31
1970-06-20	f	\N	8	\N	139	31
1970-08-07	f	\N	4	\N	140	31
1971-01-01	f	\N	6	\N	141	31
1971-02-18	f	\N	8	\N	143	31
1971-02-27	f	\N	8	\N	144	31
1971-04-08	f	\N	5	\N	145	31
1971-06-12	f	\N	2	\N	146	31
1972-01-03	f	\N	8	\N	148	31
1972-03-30	f	\N	5	\N	149	31
1972-06-03	f	\N	2	\N	150	31
1973-01-01	f	\N	6	\N	151	31
1973-05-31	f	\N	5	\N	153	31
1974-01-01	f	\N	6	\N	154	31
1974-01-02	f	\N	6	\N	155	31
1974-03-05	f	\N	8	\N	156	58
1918-06-03	f	\N	2	\N	3	33
1974-04-11	f	\N	5	\N	160	58
1974-05-24	f	\N	5	\N	161	58
1974-06-15	f	\N	2	\N	162	58
1974-11-07	f	\N	8	\N	164	58
1974-11-25	f	\N	8	\N	165	58
1974-12-06	f	\N	4	\N	166	58
1975-01-01	f	\N	6	\N	167	58
1975-08-07	f	\N	8	\N	169	58
1975-12-18	f	\N	12	\N	170	58
1976-01-01	f	\N	6	\N	171	58
1976-02-04	f	\N	8	\N	172	58
1976-06-12	f	\N	2	\N	174	11
1976-09-10	f	\N	8	\N	175	11
1976-10-27	f	\N	8	\N	176	11
1976-12-31	f	\N	6	\N	177	11
1977-12-31	f	\N	6	\N	179	11
1978-03-21	f	\N	12	\N	180	11
1978-06-03	f	\N	2	\N	181	11
1978-12-30	f	\N	6	\N	182	11
1979-06-05	f	\N	8	\N	184	54
1979-06-15	f	\N	4	\N	185	54
1979-06-26	f	\N	2	\N	186	54
1980-01-08	f	\N	6	\N	187	54
1980-12-31	f	\N	6	\N	189	54
1981-04-14	f	\N	12	\N	190	54
1981-06-13	f	\N	2	\N	191	54
1981-12-31	f	\N	6	\N	192	54
1982-06-12	f	\N	2	\N	194	54
1982-07-16	f	\N	8	\N	195	54
1982-10-11	f	\N	11	\N	196	54
1982-12-15	f	\N	12	\N	197	54
1983-06-11	f	\N	2	\N	199	54
1983-07-22	f	\N	4	\N	200	54
1983-12-31	f	\N	6	\N	201	54
1984-12-31	f	\N	6	\N	202	54
1985-06-15	f	\N	2	\N	204	54
1985-12-31	f	\N	6	\N	205	54
1986-06-14	f	\N	2	\N	206	54
1986-12-31	f	\N	6	\N	207	54
1987-06-13	f	\N	2	\N	209	54
1987-07-30	f	\N	4	\N	210	54
1987-07-31	f	\N	4	\N	211	54
1987-12-31	f	\N	6	\N	212	54
1988-11-18	f	\N	5	\N	214	54
1988-12-31	f	\N	6	\N	215	54
1989-06-17	f	\N	2	\N	216	54
1989-12-30	f	\N	6	\N	217	54
1990-06-16	f	\N	2	\N	219	54
1990-12-21	f	\N	9	\N	220	37
1990-12-31	f	\N	6	\N	221	37
1991-04-30	f	\N	12	\N	222	37
1991-06-29	f	\N	11	\N	224	37
1991-09-23	f	\N	8	\N	225	37
1991-12-31	f	\N	6	\N	226	37
1992-03-23	f	\N	8	\N	227	37
1992-04-14	f	\N	8	\N	229	37
1992-06-06	f	\N	4	\N	230	37
1992-06-13	f	\N	2	\N	231	37
1992-06-13	f	\N	12	\N	232	37
1992-12-31	f	\N	6	\N	234	37
1993-06-12	f	\N	2	\N	235	37
1993-07-22	f	\N	8	\N	236	37
1993-08-13	f	\N	12	\N	237	37
1994-06-11	f	\N	2	\N	239	37
1994-07-27	f	\N	8	\N	240	37
1994-08-20	f	\N	12	\N	241	37
1994-12-16	f	\N	8	\N	242	37
1995-01-23	f	\N	8	\N	244	37
1995-06-17	f	\N	2	\N	245	37
1995-11-08	f	\N	8	\N	246	37
1995-11-18	f	\N	12	\N	247	37
1995-12-30	f	\N	6	\N	249	37
1996-06-03	f	\N	8	\N	250	37
1996-06-15	f	\N	2	\N	251	37
1996-07-19	f	\N	8	\N	252	37
1996-11-29	f	\N	8	\N	254	37
1996-12-31	f	\N	6	\N	255	37
1997-04-19	f	\N	4	\N	256	37
1997-05-05	f	\N	8	\N	257	9
1997-06-14	f	\N	2	\N	259	9
1997-08-02	f	\N	9	\N	260	9
1997-08-02	f	\N	12	\N	261	9
1997-10-31	f	\N	5	\N	262	9
1998-06-13	f	\N	2	\N	264	9
1998-06-20	f	\N	12	\N	265	9
1998-08-03	f	\N	8	\N	266	9
1998-12-31	f	\N	6	\N	267	9
1999-06-19	f	\N	8	\N	269	9
1999-06-19	f	\N	12	\N	270	9
1999-08-24	f	\N	8	\N	271	9
1999-11-02	f	\N	8	\N	272	9
2000-03-31	f	\N	12	\N	274	9
2000-04-18	f	\N	8	\N	275	9
2000-08-15	f	\N	8	\N	276	9
2000-10-24	f	\N	8	\N	277	9
2001-06-11	f	Morgan apptd Minister	8	\N	281	9
2001-04-26	f	Guthrie	8	\N	279	\N
1881-11-17	t	\N	5	\N	1	25
1912-01-01	f	\N	6	\N	2	3
1920-06-03	f	\N	5	\N	7	33
1923-06-29	f	\N	2	\N	12	5
1925-01-01	f	\N	6	\N	17	6
1927-06-03	f	\N	2	\N	22	6
1929-06-28	t	\N	5	\N	27	35
1932-01-01	f	\N	6	\N	32	35
1934-06-04	f	\N	2	\N	37	35
1936-06-23	f	\N	2	\N	42	7
1938-06-09	f	\N	2	\N	47	14
1941-06-12	f	\N	2	\N	52	15
1943-06-02	f	\N	2	\N	57	15
1947-01-01	f	\N	6	\N	67	4
1949-06-09	f	\N	2	\N	72	4
1951-11-30	f	\N	4	\N	77	16
1954-01-01	f	\N	6	\N	82	16
1956-05-31	f	\N	2	\N	87	23
1959-01-01	f	\N	6	\N	92	36
1960-06-11	f	\N	2	\N	97	36
1962-03-29	f	\N	5	\N	102	36
1963-12-23	f	\N	5	\N	107	22
1964-07-27	f	\N	8	\N	112	22
1965-05-01	f	\N	5	\N	117	57
1966-06-11	f	\N	2	\N	122	57
1974-04-05	f	\N	4	\N	159	58
1945-06-14	f	\N	2	\N	62	15
2001-06-02	t	Pre-election dissolution list	4	\N	280	9
1967-11-16	f	\N	5	\N	127	57
1968-08-14	f	\N	8	\N	132	57
1970-06-02	f	\N	5	\N	137	31
1971-01-26	f	\N	8	\N	142	31
1971-07-09	f	\N	8	\N	147	31
1973-02-08	f	\N	8	\N	152	31
1974-03-08	f	\N	8	\N	157	58
1974-03-11	f	\N	8	\N	158	58
1974-08-01	f	\N	8	\N	163	58
1975-06-14	f	\N	2	\N	168	58
1976-06-02	f	\N	9	\N	173	11
1977-06-11	f	\N	2	\N	178	11
1979-05-07	f	\N	8	\N	183	54
1980-06-14	f	\N	2	\N	188	54
1982-02-24	f	\N	8	\N	193	54
1982-12-31	f	\N	6	\N	198	54
1985-04-03	f	\N	12	\N	203	54
1987-02-13	f	\N	12	\N	208	54
1988-06-11	f	\N	2	\N	213	54
1990-04-05	f	\N	12	\N	218	54
1991-06-15	f	\N	2	\N	223	37
1992-04-11	f	\N	8	\N	228	37
1992-09-10	f	\N	8	\N	233	37
1993-12-31	f	\N	6	\N	238	37
1994-12-31	f	\N	6	\N	243	37
1995-11-27	f	\N	8	\N	248	37
1996-08-21	f	\N	12	\N	253	37
1997-05-07	f	\N	8	\N	258	9
1997-12-31	f	\N	6	\N	263	9
1999-06-12	f	\N	2	\N	268	9
1999-12-31	f	\N	6	\N	273	9
2001-04-26	f	Appointments Commission 1st list	1	\N	278	9
1905-12-30	f	\N	10	\N	282	12
1909-01-28	f	\N	10	\N	283	3
1958-07-24	f	\N	13	\N	284	36
1997-07-14	f	\N	10	\N	285	9
2001-04-26	f	\N	7	\N	286	9
2001-09-11	f	\N	12	\N	287	9
2002-07-30	f	\N	8	\N	288	9
2002-05-28	f	\N	7	\N	289	9
2002-09-13	f	\N	7	\N	290	9
2003-05-09	f	\N	7	\N	291	9
2003-05-02	f	\N	7	\N	292	9
2003-12-19	f	\N	8	\N	293	9
2003-12-11	f	\N	8	\N	294	9
2004-05-01	f	\N	12	\N	295	9
2004-05-01	f	\N	1	\N	296	9
2004-05-01	f	\N	7	\N	297	9
2004-10-30	f	\N	8	\N	298	9
2005-05-09	f	\N	8	\N	299	9
2005-03-22	f	\N	1	\N	300	9
2005-05-13	f	\N	4	\N	301	9
2005-07-22	f	\N	1	\N	302	9
2005-07-22	f	\N	8	\N	303	9
2005-07-28	f	\N	7	\N	304	9
2006-03-21	f	\N	8	\N	305	9
2006-03-07	f	\N	7	\N	306	9
2006-04-11	f	\N	8	\N	307	9
2005-01-25	f	\N	7	\N	308	9
2005-01-31	f	\N	7	\N	309	9
2006-05-03	f	\N	1	\N	310	9
2012-10-11	f	\N	7	\N	311	60
2012-05-17	f	\N	1	\N	312	60
2012-09-04	f	\N	8	\N	313	60
2013-01-10	f	\N	8	\N	314	60
2013-02-27	f	\N	1	\N	315	60
2013-06-19	f	\N	8	\N	316	60
2013-08-01	f	\N	8	\N	317	60
2006-05-26	f	\N	7	\N	318	9
2006-07-21	f	\N	7	\N	319	9
2006-11-24	f	\N	7	\N	320	9
2007-02-15	f	\N	1	\N	321	9
2007-06-28	f	\N	8	\N	322	59
2007-06-29	f	\N	8	\N	323	59
2007-07-24	f	\N	7	\N	324	59
2007-09-13	f	\N	8	\N	325	59
2007-10-18	f	\N	1	\N	326	59
2008-04-18	f	\N	1	\N	327	59
2008-05-22	f	\N	5	\N	328	59
2008-09-04	f	\N	5	\N	329	59
2008-10-05	f	\N	8	\N	330	59
2008-09-29	f	\N	1	\N	331	59
2009-01-14	f	\N	8	\N	332	59
2009-04-08	f	\N	8	\N	333	59
2009-06-02	f	\N	8	\N	335	59
2009-06-08	f	\N	8	\N	336	59
2009-07-20	f	\N	8	\N	337	59
2009-07-13	f	\N	1	\N	338	59
2010-05-19	f	\N	8	\N	340	60
2010-05-18	f	\N	8	\N	341	60
2010-05-28	f	\N	8	\N	342	60
2010-11-19	f	\N	8	\N	343	60
2014-08-08	f	\N	8	\N	345	60
2015-02-26	f	\N	7	\N	346	60
2015-05-11	f	\N	8	\N	347	60
2015-05-14	f	\N	8	\N	348	60
2010-05-28	f	\N	7	\N	350	60
2010-07-22	f	\N	8	\N	351	60
2010-10-05	f	\N	1	\N	352	60
2010-09-07	f	\N	8	\N	353	60
2015-05-29	f	\N	8	\N	355	60
2010-10-27	f	\N	7	\N	356	60
2011-04-29	f	\N	8	\N	357	60
2011-09-05	f	\N	1	\N	358	60
2016-02-10	f	\N	8	\N	360	60
2016-08-04	f	\N	9	\N	361	61
2013-09-26	f	\N	7	\N	362	60
2017-06-20	f	\N	8	\N	363	61
2017-10-12	f	\N	7	\N	365	61
2014-01-24	f	\N	7	\N	366	60
2018-05-18	f	\N	8	\N	367	61
2018-06-08	f	\N	1	\N	368	61
2018-10-24	f	\N	8	\N	370	61
2019-09-10	f	\N	9	\N	371	62
2019-09-10	f	\N	8	\N	372	62
2019-09-10	f	\N	7	\N	373	62
2019-12-19	f	\N	8	\N	375	62
2019-07-24	f	\N	8	\N	376	61
2019-12-16	f	\N	8	\N	377	62
1963-10-21	f	\N	10	\N	378	22
2006-12-13	f	\N	8	\N	380	9
2008-10-03	f	\N	8	\N	381	59
2012-12-26	f	\N	7	\N	382	60
2009-04-15	f	\N	8	\N	334	59
2010-02-05	f	\N	1	\N	339	59
2014-10-21	f	\N	7	\N	344	60
2015-08-27	f	\N	8	\N	349	60
2010-10-21	f	\N	8	\N	354	60
2015-10-13	f	\N	1	\N	359	60
2017-09-28	f	\N	8	\N	364	61
2018-05-19	f	\N	8	\N	369	61
2016-08-04	f	\N	7	\N	374	61
2003-10-21	f	\N	8	\N	379	9
\.


--
-- Name: announcements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('announcements_id_seq', 382, true);


--
-- Data for Name: genders; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY genders (id, label) FROM stdin;
1	Male
2	Female
\.


--
-- Name: genders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('genders_id_seq', 2, true);


--
-- Data for Name: jurisdictions; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY jurisdictions (id, label) FROM stdin;
1	Scotland
2	Ireland
3	England and Wales
4	Northern Ireland
\.


--
-- Name: jurisdictions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('jurisdictions_id_seq', 4, true);


--
-- Data for Name: kingdom_ranks; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY kingdom_ranks (id, rank_id, kingdom_id) FROM stdin;
1	6	1
2	6	2
3	6	3
4	6	4
5	6	5
6	8	1
7	8	3
8	8	4
9	8	5
10	9	1
11	9	2
12	9	3
13	9	4
14	9	5
15	12	1
16	12	2
17	12	3
18	12	4
19	12	5
20	4	1
21	4	2
22	4	3
23	4	4
24	4	5
25	11	1
26	11	2
27	11	3
28	11	4
29	11	5
30	14	2
\.


--
-- Name: kingdom_ranks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('kingdom_ranks_id_seq', 30, true);


--
-- Data for Name: kingdoms; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY kingdoms (id, name, start_on, end_on) FROM stdin;
1	Kingdom of England	\N	1707-05-01
2	Kingdom of Scotland	\N	1707-05-01
3	Kingdom of Ireland	\N	1801-01-01
4	Kingdom of Great Britain	1707-05-01	1801-01-01
5	United Kingdom	1801-01-01	\N
\.


--
-- Name: kingdoms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('kingdoms_id_seq', 5, true);


--
-- Data for Name: law_lord_incumbencies; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY law_lord_incumbencies (appointed_on, vice, end_on, notes, old_office, annuity_from, annuity_london_gazette_issue, annuity_london_gazette_page, appointment_london_gazette_issue, appointment_london_gazette_page, id, peerage_id, jurisdiction_id) FROM stdin;
1880-04-28	L Gordon of Drumearn deceased	\N	\N	MP, Lord Advocate	\N	\N	\N	24838	2725	3	433	1
1882-06-23	\N	\N	\N	J (Queen's Bench Division, Ireland)	\N	\N	\N	25119	2848	4	456	2
1887-01-25	L Blackburn resigned	\N	\N	QC MP	\N	\N	\N	25669	533	5	503	3
1889-12-05	L FitzGerald deceased	1900-05-09	\N	LCJ(I)	1900-05-10	27193	3142	25999	7014	6	519	3
1891-01-28	\N	1893-09-02	\N	President of the PDA Division	\N	26438	5056	26130	561	7	524	3
1893-09-23	L Hannen	\N	\N	LJ	\N	\N	\N	26444	5431	8	556	3
1894-05-07	L Bowen	1894-07-02	Appointed LCJ 3 July 1894	Attorney-General	\N	\N	\N	26511	2783	9	559	3
1894-08-13	\N	\N	\N	\N	\N	\N	\N	26543	4808	10	560	3
1899-11-14	L Watson deceased	\N	\N	\N	\N	\N	\N	27135	6814	11	605	1
1900-05-10	L Morris resigned	1905-12-01	\N	\N	1905-12-02	27860	8737	27192	3070	12	608	3
1913-10-14	\N	1932-04-05	appointed pursuant to 1913 Act	\N	1932-04-06	33815	2289	28765	7241	13	636	1
1905-12-19	L Lindley resigned	1928-02-08	\N	AG in Ireland	\N	\N	\N	27866	9173	14	642	3
1907-03-06	L Davey deceased	1910-10-06	\N	MR	1910-10-07	28425	7321	28002	1663	15	669	3
1910-10-07	L Collins resigned	\N	MP on appointment	\N	1912-08-01	28636	6099	28425	7321	17	701	3
1912-10-01	L Robson	\N	\N	LJ	\N	\N	\N	28650	7291	18	732	3
1913-03-04	L Macnaghten	\N	\N	J	\N	\N	\N	28697	1756	19	736	3
1913-10-20	\N	1930-01-26	appointed pursuant to 1913 Act	LJ	1930-01-27	33575	645	28766	7335	20	737	3
1919-01-15	\N	\N	\N	\N	\N	\N	\N	31123	714	21	819	3
1923-10-12	Cave	1937-04-26	\N	LJ	1937-04-27	34400	3296	32880	7852	23	901	3
1928-02-06	L Atkinson	\N	\N	LJ	\N	\N	\N	33356	1045	24	940	3
1929-02-11	\N	\N	appointed under 1929 Act	J	\N	\N	\N	33466	1039	25	949	3
1929-05-01	L Shaw	\N	\N	Lord Advocate	\N	\N	\N	33491	2919	26	953	1
1929-11-18	L Carson	1946-01-05	\N	LJ	1946-01-06	37432	459	33553	7453	27	974	3
1941-07-18	\N	1947-01-05	\N	\N	1947-01-06	37855	341	35225	4212	29	981	1
1932-04-11	V Dunedin	\N	\N	J	\N	\N	\N	33816	23917	30	1000	3
1937-04-27	\N	1947-04-05	\N	MR	1947-04-06	37940	1825	34392	2713	31	1000	3
1935-10-07	L Tomlin	\N	\N	LJ	\N	\N	\N	34208	6470	32	1041	3
1935-10-14	L Wright	1938-01-04	\N	LJ	1938-01-05	34476	512	34209	6541	33	1042	3
1938-01-05	L Roche	1944-04-05	\N	LJ	1944-04-06	36496	2013	34472	189	34	1079	3
1938-03-28	Maugham	1954-10-15	\N	J	\N	\N	\N	34497	2083	35	1086	3
1939-10-05	\N	\N	\N	\N	\N	\N	\N	34705	6794	36	1101	3
1949-06-01	\N	1950-05-05	\N	MR	1950-05-06	38914	2432	38627	2748	37	1119	3
1944-04-18	L Romer	1951-10-30	resigned on appointment as Lord Chancellor	J	\N	\N	\N	36481	1841	38	1145	3
1944-07-19	L Atkin	1946-01-21	\N	LJ	\N	\N	\N	36620	3415	39	1149	3
1946-01-09	L Russell of Killowen	\N	\N	J	\N	\N	\N	37429	415	40	1189	3
1946-02-05	L Goddard	\N	\N	LJ	\N	\N	\N	37461	863	41	1198	3
1947-01-06	L Macmillan	1953-10-05	\N	Lord Justice General	1953-10-06	39988	5497	37849	225	42	1215	1
1947-04-15	\N	1957-04-05	\N	LJ	1957-04-06	41082	3181	37934	1721	43	1216	3
1947-04-18	Admin of Justice Act 1947	1959-04-05	\N	LJ	1959-04-06	41676	2264	37938	1775	44	1226	3
1947-04-23	L Wright	1951-04-06	\N	J(NI)	\N	\N	\N	37940	1825	45	1227	4
1948-10-06	L Thankerton	1975-01-10	\N	KC, ex-Lord Advocate	\N	\N	\N	38425	5331	46	1243	1
1949-06-01	L du Parcq	1964-09-30	\N	KC	1964-10-01	43461	8651	38627	2748	47	1247	3
1950-09-29	L Greene	1961-10-05	\N	LJ	\N	\N	\N	39047	5243	48	1266	3
1951-04-23	L MacDermott	\N	\N	LJ	\N	\N	\N	39212	2327	49	1269	3
1951-11-12	L Simonds	1960-09-30	\N	LJ	1960-10-01	42159	6701	39382	5919	50	1273	3
1953-11-04	L Normand	1961-01-05	\N	Senator of the College of Justice	\N	\N	\N	40008	5921	51	1298	1
1954-10-04	L Asquith of Bishopstone	1960-01-05	\N	LJ	1960-01-06	41933	551	\N	\N	52	1310	3
1954-10-19	\N	1962-03-31	\N	ex-Lord Chancellor	1962-04-01	42641	2803	\N	\N	53	1311	3
1962-04-19	\N	1965-01-10	\N	MR	1965-01-11	43562	1009	42654	3277	54	1331	3
1959-04-06	L Morton of Henryton	1963-11-16	\N	LJ	1963-11-17	43180	10099	41676	2264	56	1374	3
1960-01-07	L Somervell of Harrow	1975-01-10	\N	LJ	\N	\N	\N	41924	251	57	1385	3
1960-10-01	L Cohen	1971-04-19	\N	LJ	\N	\N	\N	42159	6701	58	1399	3
1961-10-11	L Tucker	1964-01-10	\N	LJ	1964-01-11	43237	1061	42486	7353	60	1420	3
1962-04-19	L Denning appointed MR	1969-06-02	\N	LJ	\N	\N	\N	42654	3277	61	1429	3
1963-11-26	L Jenkins	\N	\N	LJ	\N	\N	\N	43169	9713	62	1450	3
1964-01-11	L Devlin	\N	\N	LJ	\N	\N	\N	43219	385	63	1452	3
1964-10-01	V Radcliffe	1982-03-10	\N	J	\N	\N	\N	43451	8292	64	1477	3
1969-06-09	\N	1980-07-31	\N	ex-Lord Chancellor	\N	\N	\N	44872	6025	65	1482	3
1965-02-18	L Evershed	1974-09-30	\N	LJ	\N	\N	\N	43580	1759	66	1510	3
1968-09-30	no one	\N	\N	LJ	\N	\N	\N	44687	10537	67	1596	3
1971-03-12	L Upjohn	1975-09-30	\N	LJ	\N	\N	\N	45323	2278	69	1636	3
1971-10-04	L Guest	1976-12-31	\N	Senator of the College of Justice	\N	\N	\N	45489	10769	70	1647	1
1972-01-10	L Donovan	1980-09-30	\N	LJ	\N	\N	\N	45572	449	71	1648	3
1974-10-01	L Pearson	1981-09-30	\N	LJ	\N	\N	\N	46361	8348	72	1706	3
1975-01-13	L Reid	1985-09-30	\N	Senator of the College of Justice	\N	\N	\N	46466	633	73	1716	1
1975-09-30	L Cross of Chelsea	1982-06-27	\N	LJ	\N	\N	\N	46701	12332	74	1738	3
1977-01-10	L Kilbrandon	1996-09-30	\N	Senator of the College of Justice	\N	\N	\N	47120	471	75	1769	1
1977-09-30	L Simon of Glaisdale	1986-01-13	\N	LJ	\N	\N	\N	47342	12509	76	1780	3
1988-08-05	[increase in number]	1994-01-07	\N	LCJ of NI	\N	\N	\N	51439	9161	78	1827	4
1979-09-28	\N	1980-04-15	\N	LJ	\N	\N	\N	47968	12353	79	1837	3
1980-04-15	\N	1985-12-31	\N	LJ	\N	\N	\N	48160	5816	80	1846	3
1980-09-29	V Dilhorne resigned & since died	1992-02-26	\N	LJ	\N	\N	\N	48326	13737	81	1852	3
1981-09-24	\N	1991-09-30	\N	LJ	\N	\N	\N	48749	12329	82	1874	3
1982-03-12	L Wilberforce	1986-06-19	\N	LJ	\N	\N	\N	48924	3707	83	1878	3
1982-09-30	L Russell of Killowen	1994-09-30	\N	LJ	\N	\N	\N	49131	12953	84	1883	3
1985-05-23	\N	1993-09-30	\N	LJ	\N	\N	\N	\N	\N	85	1940	3
1986-01-30	\N	1992-09-30	\N	LJ	\N	\N	\N	50421	1627	86	1948	3
1986-01-31	\N	1991-12-31	\N	LJ	\N	\N	\N	50422	1671	87	1949	3
1876-10-17	pursuant to Appellate Jurisdiction Act 1876	\N	\N	QC MP, Lord Advocate	\N	\N	\N	24372	5457	2	424	1
2000-07-17	L Phillips of Worth Matravers	\N	\N	Vice-Chancellor	\N	\N	\N	55920	8034	108	2403	3
2002-10-01	L Slynn of Hadley	\N	\N	LJ	\N	\N	\N	56712	11976	109	2449	3
2004-01-12	L Millett	\N	\N	LJ	\N	\N	\N	57179	503	110	2455	3
2004-01-12	L Hutton	2009-06-28	\N	LCJ of NI	\N	\N	\N	57179	503	111	2456	4
2004-01-13	L Hobhouse of Woodborough	\N	\N	LJ	\N	\N	\N	57180	591	112	2457	3
2005-10-03	L Steyn	\N	\N	LJ	\N	\N	\N	57779	12971	113	2540	3
2007-01-11	L Nicholls of Birkenhead	\N	\N	LJ	\N	\N	\N	58222	601	114	2580	3
2008-10-01	L Bingham of Cornhill	\N	reappointment	LCJ	\N	0	0	58843	15222	115	2305	3
2009-04-21	L Hoffmann	\N	\N	LJ	\N	0	0	59045	7037	116	2610	3
2009-06-29	L Carswell	\N	\N	LCJ of NI	\N	0	0	59117	11331	117	2613	4
1921-06-01	L Moulton	\N	MP at time of appointment	KC	1929-11-01	33549	7065	32344	4425	22	864	3
1961-01-20	L Keith of Avonholm	1971-09-30	\N	Senator of the College of Justice	\N	\N	\N	42257	499	59	1402	1
1876-10-16	pursuant to Appellate Jurisdiction Act 1876	1887-01-06	\N	J (Queen's Bench Division)	\N	\N	\N	24370	5347	1	423	3
1909-02-20	L Robertson deceased	1929-04-30	MP on appointment	Lord Advocate	\N	\N	\N	28238	2589	16	683	1
1930-02-03	L Sumner	\N	Resigned 1939 on appointment as Minister of Information. Reappointed 18 July 1941.	Lord Advocate	\N	\N	\N	33576	719	28	981	1
1957-04-24	L Oaksey	1962-04-19	appointed MR 19 April 1962	LJ	\N	\N	\N	41055	2519	55	1343	3
1971-04-19	\N	1977-09-30	\N	President of Family Division	\N	\N	\N	45347	3901	68	1632	3
1985-10-01	L Fraser of Tullybelton	1987-10-28	Resigned on appointment as Lord Chancellor	Senator of the College of Justice	\N	\N	\N	\N	\N	77	1817	1
1986-02-06	\N	1998-09-30	Senior Lord of Appeal in Ordinary from 1996	LJ	\N	\N	\N	50427	1981	88	1950	3
1988-02-09	\N	1996-09-30	\N	Senator of the College of Justice	\N	\N	\N	51239	1661	89	1992	1
1991-10-01	L Brandon of Oakbrook	2000-06-05	Senior Lord of Appeal in Ordinary from 1 Oct 1998	LJ	\N	\N	\N	52677	15091	90	2055	3
1992-01-10	L Oliver of Aylmerton	1997-03-21	\N	LJ	\N	\N	\N	52794	577	91	2056	3
1992-03-11	L Bridge of Harwich	2002-09-30	\N	LJ	\N	\N	\N	52861	4553	92	2061	3
2001-10-01	L Clyde	\N	\N	Lord Justice General	\N	\N	\N	56350	11695	93	2065	1
1992-10-01	L Ackner	1996-06-04	appointed Master of the Rolls June 1996; appointed Lord Chief Justice 2001 (retired 2006)	LJ	\N	\N	\N	53070	16751	94	2099	3
1993-10-01	L Griffiths	1998-12-31	\N	LJ	\N	\N	\N	53448	16099	95	2105	3
1994-01-11	L Lowry	1998-09-30	\N	LJ	\N	\N	\N	53547	553	96	2114	3
1994-10-03	L Templeman	2007-01-10	\N	LJ	\N	\N	\N	53811	14001	97	2125	3
1995-01-11	[increase in number]	2005-10-01	\N	LJ	\N	\N	\N	53914	551	98	2131	3
1995-02-21	[increase in number]	2009-04-20	\N	LJ	\N	\N	\N	53965	3079	99	2135	3
1996-10-01	L Keith of Kinkel	\N	\N	Lord Justice General	\N	\N	\N	54543	13211	100	2136	1
2000-06-06	L Browne-Wilkinson	2008-09-30	\N	LCJ	\N	\N	\N	55870	6307	101	2157	3
1996-10-01	L Jauncey of Tullichettle	2001-09-30	\N	Senator of the College of Justice	\N	\N	\N	54543	13211	102	2162	1
1997-01-06	L Woolf	2004-01-11	\N	LCJ	\N	\N	\N	54647	421	103	2176	4
1997-07-28	L Mustill	\N	\N	LJ	\N	\N	\N	54849	8779	104	2206	3
1998-10-01	L Goff of Chieveley resigned	2004-01-11	Announcement of appointment leaked in The Guardian 18 July 1998.	LJ	\N	\N	\N	55286	\N	105	2302	3
1998-10-01	L Nolan	2004-01-11	Announcement of appointment leaked in The Guardian 18 July 1998.	LJ	\N	\N	\N	55286	\N	106	2303	3
1999-01-12	L Lloyd of Berwick	2000-06-05	appointed Master of the Rolls 2001; Lord Chief Justice 2006	LJ	\N	\N	\N	55376	\N	107	2305	3
\.


--
-- Name: law_lord_incumbencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('law_lord_incumbencies_id_seq', 117, true);


--
-- Data for Name: letters; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters (id, letter, url_key) FROM stdin;
1	Without surname	-
2	A	a
3	B	b
4	C	c
5	D	d
6	E	e
7	F	f
8	G	g
9	H	h
10	I	i
11	J	j
12	K	k
13	L	l
14	M	m
15	N	n
16	O	o
17	P	p
18	Q	q
19	R	r
20	S	s
21	T	t
22	U	u
23	V	v
24	W	w
25	X	x
26	Y	y
27	Z	z
\.


--
-- Name: letters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_id_seq', 27, true);


--
-- Data for Name: letters_patent_times; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters_patent_times (id, label) FROM stdin;
1	1 p.m.
2	Morning
3	Afternoon
4	6 a.m.
5	12 noon
6	9 a.m.
7	3 p.m.
8	11 p.m.
9	2 p.m.
10	9 p.m.
11	6 p.m.
\.


--
-- Name: letters_patent_times_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_patent_times_id_seq', 11, true);


--
-- Data for Name: letters_patents; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY letters_patents (id, patent_on, person_prefix, person_suffix, previous_of_title, previous_title, previous_rank, ordinality_on_date, citations, announcement_id, letters_patent_time_id, person_id, kingdom_id, previous_kingdom_id, reign_id) FROM stdin;
56	1814-05-17	\N	\N	f	\N	\N	4	\N	\N	\N	54	5	\N	11
57	1814-05-17	\N	\N	f	\N	\N	5	\N	\N	\N	55	5	\N	11
18	1814-06-01	\N	\N	f	\N	\N	2	\N	\N	\N	22	5	\N	11
34	1801-02-04	\N	\N	t	Exeter	10th Earl	1	\N	\N	\N	39	5	\N	11
13	1802-07-28	\N	\N	f	Arden	2nd Lord 	1	\N	\N	\N	16	5	3	11
69	1815-08-11	\N	\N	f	\N	\N	6	\N	\N	\N	66	5	\N	11
2	1801-01-21	\N	\N	t	Carysfort	1st Earl 	1	\N	\N	\N	2	5	3	11
108	1815-08-12	\N	\N	f	\N	\N	1	\N	\N	\N	103	5	\N	11
14	1802-07-29	\N	\N	f	Sheffield	1st Lord 	1	\N	\N	\N	17	5	3	11
4	1801-05-22	\N	\N	f	\N	\N	2	\N	\N	\N	4	5	\N	11
33	1801-05-28	\N	\N	f	\N	\N	1	\N	\N	\N	5	5	\N	11
11	1802-02-27	\N	\N	f	Curzon	1st Lord	1	\N	\N	\N	12	5	\N	11
27	1801-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	32	5	\N	11
9	1801-12-16	\N	\N	f	\N	\N	1	\N	\N	\N	10	5	\N	11
10	1802-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	11	5	\N	11
43	1806-11-12	\N	\N	t	Cassillis	12th Earl 	1	\N	\N	\N	41	5	2	11
8	1801-12-15	\N	\N	f	Keith	1st Lord 	1	\N	\N	\N	9	5	3	11
37	1803-09-17	\N	\N	f	Keith	1st Lord	1	\N	\N	\N	9	5	\N	11
15	1802-12-24	\N	\N	f	\N	\N	1	\N	\N	\N	18	5	\N	11
44	1806-11-13	\N	\N	t	Breadalbane	4th Earl 	1	\N	\N	\N	42	5	2	11
17	1805-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	20	5	\N	11
38	1805-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	21	5	\N	11
59	1814-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	57	5	\N	11
20	1806-02-10	\N	\N	f	\N	\N	1	\N	\N	\N	25	5	\N	11
21	1806-02-17	\N	\N	f	\N	\N	1	\N	\N	\N	26	5	\N	11
24	1806-02-25	\N	\N	f	\N	\N	1	\N	\N	\N	29	5	\N	11
77	1806-04-10	\N	\N	f	Walpole	2nd Lord	1	\N	\N	\N	73	5	\N	11
83	1809-02-03	\N	\N	t	Hopetoun	3rd Earl 	1	\N	\N	\N	47	5	2	11
30	1801-06-19	\N	\N	f	Onslow	4th Lord	1	\N	\N	\N	35	5	\N	11
26	1801-11-27	\N	\N	f	\N	\N	2	\N	\N	\N	31	5	\N	11
5	1801-06-23	\N	\N	f	\N	\N	2	\N	\N	\N	6	5	\N	11
28	1801-06-23	\N	\N	f	Pelham	2nd Lord	1	\N	\N	\N	33	5	\N	11
29	1801-06-18	\N	\N	f	Craven	7th Lord	1	\N	\N	\N	34	5	\N	11
40	1801-04-21	\N	\N	f	Loughborough	1st Lord	1	\N	\N	\N	38	5	\N	11
42	1806-04-11	\N	\N	f	Grey	1st Lord	1	\N	\N	\N	6	5	\N	11
16	1804-09-01	\N	\N	f	\N	\N	1	\N	\N	\N	19	5	\N	11
12	1802-04-19	\N	\N	f	\N	\N	1	\N	\N	\N	14	5	\N	11
19	1805-11-20	\N	\N	f	\N	\N	1	\N	\N	\N	24	5	\N	11
3	1801-05-22	\N	\N	f	Nelson	1st Lord	1	\N	\N	\N	3	5	\N	11
48	1807-11-09	\N	\N	f	Cathcart	10th Lord 	1	\N	\N	\N	45	5	2	11
94	1821-07-17	\N	\N	t	Roden	3rd Earl 	6	\N	\N	\N	88	5	3	8
74	1807-04-07	\N	\N	f	Lowther	2nd Viscount	1	\N	\N	\N	70	5	\N	11
92	1821-07-17	\N	\N	f	Conyngham	1st Marquess 	3	\N	\N	\N	85	5	3	8
46	1807-04-20	\N	\N	f	\N	\N	1	\N	\N	\N	44	5	\N	11
82	1812-10-03	\N	\N	t	Wellington	1st Earl	1	\N	\N	\N	48	5	\N	11
49	1807-11-09	\N	\N	f	\N	\N	2	\N	\N	\N	46	5	\N	11
73	1809-07-19	\N	\N	f	Harrowby	2nd Lord	1	\N	\N	\N	69	5	\N	11
95	1821-07-17	\N	\N	t	Kingston	3rd Earl 	7	\N	\N	\N	89	5	3	8
53	1814-05-17	\N	\N	f	\N	\N	1	\N	\N	\N	51	5	\N	11
96	1821-07-17	\N	\N	t	Longford	2nd Earl 	8	\N	\N	\N	90	5	3	8
62	1815-08-04	\N	\N	t	Clancarty	2nd Earl 	1	\N	\N	\N	59	5	3	11
63	1815-08-07	\N	\N	t	Strathmore	10th Earl 	1	\N	\N	\N	60	5	2	11
79	1815-07-04	\N	\N	t	Uxbridge	2nd Earl	1	\N	\N	\N	75	5	\N	11
80	1815-11-22	\N	\N	t	Cholmondeley	4th Earl	1	\N	\N	\N	76	5	\N	11
52	1813-06-14	\N	\N	f	Whitworth	1st Lord 	1	\N	\N	\N	50	5	3	11
78	1815-11-24	\N	\N	f	Grimston	4th Viscount 	1	\N	\N	\N	74	5	3	11
84	1815-11-27	\N	\N	f	Brownlow	2nd Lord	1	\N	\N	\N	78	5	\N	11
75	1813-02-24	\N	\N	f	Minto	1st Lord	1	\N	\N	\N	71	5	\N	11
97	1821-07-17	\N	\N	f	\N	\N	9	\N	\N	\N	91	5	\N	8
98	1821-07-17	\N	\N	f	\N	\N	10	\N	\N	\N	92	5	\N	8
99	1821-07-17	\N	\N	f	\N	\N	11	\N	\N	\N	93	5	\N	8
100	1821-07-17	\N	\N	f	\N	\N	12	\N	\N	\N	94	5	\N	8
101	1821-07-17	\N	\N	f	\N	\N	13	\N	\N	\N	95	5	\N	8
102	1821-07-17	\N	\N	f	\N	\N	14	\N	\N	\N	96	5	\N	8
103	1821-07-17	\N	\N	f	\N	\N	15	\N	\N	\N	97	5	\N	8
50	1809-09-04	\N	\N	f	\N	\N	1	\N	\N	\N	48	5	\N	11
118	1821-07-18	\N	\N	f	Rous	1st Lord	1	\N	\N	\N	113	5	\N	8
124	1823-07-08	\N	\N	t	Londonderry	3rd Marquess 	1	\N	\N	\N	100	5	3	8
72	1815-11-25	\N	\N	f	Whitworth	1st Viscount	1	\N	\N	\N	50	5	\N	11
117	1815-11-29	\N	\N	f	Boringdon	2nd Lord	1	\N	\N	\N	112	5	\N	11
85	1815-12-01	\N	\N	f	Beauchamp	1st Lord	1	\N	\N	\N	30	5	\N	11
122	1816-10-25	\N	\N	f	Lucas	Baroness	1	\N	\N	\N	79	5	\N	11
87	1816-12-10	\N	\N	f	Exmouth	1st Lord	1	\N	\N	\N	22	5	\N	11
115	1821-07-07	\N	\N	f	Eldon	1st Lord	1	\N	\N	\N	110	5	\N	8
86	1816-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	80	5	\N	11
89	1821-07-16	\N	\N	f	Curzon	2nd Viscount	1	\N	\N	\N	82	5	\N	8
88	1817-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	81	5	\N	11
106	1823-12-08	\N	\N	t	Clancarty	2nd Earl 	1	\N	\N	\N	101	5	3	8
109	1826-07-03	\N	\N	t	Thomond	2nd Marquess 	1	\N	\N	\N	104	5	3	8
105	1823-04-22	\N	\N	f	Beresford	1st Lord	1	\N	\N	\N	55	5	\N	8
125	1821-07-18	\N	\N	f	\N	\N	2	\N	\N	\N	98	5	\N	8
104	1823-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	99	5	\N	8
132	1827-04-28	\N	\N	t	Fife	4th Earl 	2	\N	\N	\N	122	5	3	8
65	1815-08-11	\N	\N	t	Aboyne	5th Earl 	2	\N	\N	\N	62	5	2	11
68	1815-08-11	\N	\N	t	Limerick	1st Earl 	5	\N	\N	\N	65	5	3	11
107	1824-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	102	5	\N	8
128	1826-12-19	\N	\N	f	Amherst	2nd Lord	1	\N	\N	\N	119	5	\N	8
129	1827-02-08	\N	\N	f	Combermere	1st Lord	1	\N	\N	\N	53	5	\N	8
112	1826-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	107	5	\N	8
113	1826-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	108	5	\N	8
126	1826-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	117	5	\N	8
127	1826-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	118	5	\N	8
130	1827-04-25	\N	\N	f	\N	\N	1	\N	\N	\N	120	5	\N	8
131	1827-04-28	\N	\N	f	\N	\N	1	\N	\N	\N	121	5	\N	8
54	1814-05-17	\N	\N	f	\N	\N	2	\N	\N	\N	52	5	\N	11
55	1814-05-17	\N	\N	f	\N	\N	3	\N	\N	\N	53	5	\N	11
151	1831-06-20	\N	\N	f	\N	\N	5	\N	\N	\N	142	5	\N	7
208	1831-09-13	\N	\N	f	Grosvenor	2nd Earl	1	\N	\N	\N	196	5	\N	7
157	1831-09-10	\N	\N	f	\N	\N	10	\N	\N	\N	148	5	\N	7
158	1831-09-10	\N	\N	f	\N	\N	11	\N	\N	\N	149	5	\N	7
159	1831-09-10	\N	\N	f	\N	\N	12	\N	\N	\N	150	5	\N	7
161	1831-09-10	\N	\N	f	\N	\N	14	\N	\N	\N	152	5	\N	7
162	1831-09-10	\N	\N	f	\N	\N	15	\N	\N	\N	153	5	\N	7
163	1831-09-10	\N	\N	f	\N	\N	16	\N	\N	\N	154	5	\N	7
166	1826-06-30	\N	\N	t	Bristol	5th Earl	1	\N	\N	\N	156	5	\N	8
141	1828-01-28	\N	\N	t	Clanwilliam	3rd Earl 	1	\N	\N	\N	132	5	3	8
135	1827-07-24	\N	\N	f	Binning	Lord	1	\N	\N	\N	125	5	\N	8
148	1831-06-20	\N	\N	t	Sefton	2nd Earl 	2	\N	\N	\N	139	5	3	7
137	1828-01-21	\N	\N	f	\N	\N	1	\N	\N	\N	127	5	\N	8
164	1828-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	128	5	\N	8
139	1828-01-23	\N	\N	f	\N	\N	1	\N	\N	\N	130	5	\N	8
175	1833-06-07	\N	\N	t	Queensberry	6th Marquess 	1	\N	\N	\N	164	5	2	7
142	1828-01-29	\N	\N	f	\N	\N	1	\N	\N	\N	133	5	\N	8
143	1828-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	134	5	\N	8
144	1828-02-02	\N	\N	f	\N	\N	1	\N	\N	\N	135	5	\N	8
145	1829-06-05	\N	\N	f	\N	\N	1	\N	\N	\N	136	5	\N	8
146	1830-11-22	\N	\N	f	\N	\N	1	\N	\N	\N	137	5	\N	7
198	1833-01-28	\N	\N	t	Stafford	2nd Marquess	2	\N	\N	\N	188	5	\N	7
134	1827-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	124	5	\N	8
138	1828-01-22	\N	\N	f	\N	\N	2	\N	\N	\N	129	5	\N	8
202	1831-09-15	\N	\N	f	Anson	2nd Viscount	1	\N	\N	\N	191	5	\N	7
245	1838-06-25	\N	\N	t	Mulgrave	2nd Earl	1	\N	\N	\N	231	5	\N	6
169	1831-09-15	\N	\N	f	\N	\N	2	\N	\N	\N	158	5	\N	7
170	1832-05-14	\N	\N	f	\N	\N	1	\N	\N	\N	159	5	\N	7
172	1832-12-22	\N	\N	f	\N	\N	1	\N	\N	\N	161	5	\N	7
173	1833-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	162	5	\N	7
174	1833-05-10	\N	\N	f	Granville	1st Viscount	1	\N	\N	\N	163	5	\N	7
193	1838-07-07	\N	\N	f	Rossmore	2nd Lord 	1	\N	\N	\N	184	5	3	6
199	1837-01-28	\N	\N	f	Ducie	4th Lord	2	\N	\N	\N	189	5	\N	7
176	1834-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	165	5	\N	7
209	1834-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	166	5	\N	7
177	1834-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	167	5	\N	7
179	1835-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	169	5	\N	7
180	1835-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	170	5	\N	7
181	1835-03-10	\N	\N	f	\N	\N	1	\N	\N	\N	171	5	\N	7
182	1835-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	172	5	\N	7
183	1835-05-08	\N	\N	f	\N	\N	1	\N	\N	\N	173	5	\N	7
184	1835-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	174	5	\N	7
187	1836-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	177	5	\N	7
210	1836-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	178	5	\N	7
188	1836-01-23	\N	\N	f	\N	\N	1	\N	\N	\N	179	5	\N	7
189	1837-01-27	\N	\N	f	\N	\N	1	\N	\N	\N	180	5	\N	7
190	1837-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	181	5	\N	7
191	1837-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	182	5	\N	7
228	1841-08-17	\N	\N	t	Kenmare	2nd Earl 	2	\N	\N	\N	214	5	3	6
203	1838-06-30	\N	\N	f	King	8th Lord	1	\N	\N	\N	192	5	\N	6
206	1838-07-02	\N	\N	f	Dundas	2nd Lord	1	\N	\N	\N	194	5	\N	6
194	1838-07-09	\N	\N	f	Carew	1st Lord 	1	\N	\N	\N	185	5	3	6
268	1857-10-01	\N	\N	t	Fife	5th Earl 	1	\N	\N	\N	251	5	3	6
213	1839-04-20	\N	\N	f	Ponsonby	2nd Lord	1	\N	\N	\N	199	5	\N	6
195	1838-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	186	5	\N	6
196	1838-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	187	5	\N	6
211	1838-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	197	5	\N	6
212	1838-07-13	\N	\N	f	\N	\N	1	\N	\N	\N	198	5	\N	6
240	1839-12-21	\N	\N	f	Auckland	2nd Lord	1	\N	\N	\N	226	5	\N	6
215	1839-05-09	\N	\N	f	\N	\N	1	\N	\N	\N	201	5	\N	6
216	1839-05-10	\N	\N	f	\N	\N	1	\N	\N	\N	202	5	\N	6
217	1839-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	203	5	\N	6
218	1839-05-13	\N	\N	f	\N	\N	1	\N	\N	\N	204	5	\N	6
219	1839-05-14	\N	\N	f	\N	\N	1	\N	\N	\N	205	5	\N	6
221	1839-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	207	5	\N	6
222	1839-06-07	\N	\N	f	\N	\N	1	\N	\N	\N	208	5	\N	6
224	1839-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	210	5	\N	6
246	1841-12-08	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	232	5	\N	6
225	1839-12-23	\N	\N	f	\N	\N	1	\N	\N	\N	211	5	\N	6
247	1840-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	225	5	\N	6
226	1840-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	212	5	\N	6
149	1831-06-20	\N	\N	t	Leitrim	2nd Earl 	3	\N	\N	\N	140	5	3	7
229	1841-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	215	5	\N	6
230	1841-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	216	5	\N	6
248	1842-09-27	\N	\N	f	Hill	1st Lord	1	\N	\N	\N	54	5	\N	6
237	1849-06-15	\N	\N	f	Gough	1st Lord	1	\N	\N	\N	218	5	\N	6
231	1845-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	217	5	\N	6
232	1846-04-25	\N	\N	f	\N	\N	1	\N	\N	\N	218	5	\N	6
233	1847-09-18	\N	\N	f	\N	\N	2	\N	\N	\N	220	5	\N	6
235	1847-09-21	\N	\N	f	\N	\N	1	\N	\N	\N	222	5	\N	6
236	1848-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	223	5	\N	6
241	1850-01-17	\N	\N	t	Wales	Prince	1	\N	\N	\N	227	5	\N	6
261	1856-07-23	\N	\N	f	Wensleydale	Lord	1	\N	\N	\N	244	5	\N	6
154	1831-09-10	\N	\N	t	Dunmore	5th Earl 	5	\N	\N	\N	145	5	2	7
250	1850-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	233	5	\N	6
251	1850-03-05	\N	\N	f	\N	\N	1	\N	\N	\N	234	5	\N	6
252	1850-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	235	5	\N	6
253	1850-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	236	5	\N	6
254	1851-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	237	5	\N	6
255	1852-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	238	5	\N	6
256	1852-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	239	5	\N	6
257	1852-10-20	\N	\N	f	\N	\N	1	\N	\N	\N	240	5	\N	6
260	1856-06-25	\N	\N	f	\N	\N	1	\N	\N	\N	243	5	\N	6
264	1857-04-11	\N	\N	f	Cowley	2nd Lord	1	\N	\N	\N	247	5	\N	6
262	1856-08-29	\N	\N	f	\N	\N	1	\N	\N	\N	245	5	\N	6
153	1831-09-10	\N	\N	t	Meath	10th Earl 	4	\N	\N	\N	144	5	3	7
265	1857-04-11	\N	\N	f	\N	\N	2	\N	\N	\N	248	5	\N	6
266	1857-09-15	\N	\N	f	\N	\N	1	\N	\N	\N	249	5	\N	6
267	1857-09-16	\N	\N	f	\N	\N	1	\N	\N	\N	250	5	\N	6
269	1858-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	252	5	\N	6
140	1828-01-26	\N	\N	t	Rosebery	4th Earl 	1	\N	\N	\N	131	5	2	8
312	1859-05-21	\N	\N	f	Canning	2nd Viscount	1	\N	\N	\N	293	5	\N	6
272	1858-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	255	5	\N	6
273	1858-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	256	5	\N	6
276	1859-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	259	5	\N	6
298	1866-05-03	\N	\N	f	Athlumney	1st Lord 	1	\N	\N	\N	279	5	3	6
285	1860-02-17	\N	\N	f	Ward	11th Lord	1	\N	\N	\N	267	5	\N	6
277	1859-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	260	5	\N	6
278	1859-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	261	5	\N	6
319	1869-12-08	\N	\N	t	Listowel	3rd Earl 	1	\N	\N	\N	301	5	3	6
280	1861-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	263	5	\N	6
281	1861-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	264	5	\N	6
282	1861-07-30	\N	\N	f	\N	\N	1	\N	\N	\N	265	5	\N	6
300	1866-07-12	\N	\N	f	Monck	4th Viscount 	2	\N	\N	\N	281	5	3	6
291	1863-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	271	5	\N	6
293	1866-01-03	\N	\N	f	\N	\N	1	\N	\N	\N	274	5	\N	6
294	1866-01-04	\N	\N	f	\N	\N	1	\N	\N	\N	275	5	\N	6
295	1866-02-21	\N	\N	f	\N	\N	1	\N	\N	\N	276	5	\N	6
335	1872-02-13	\N	\N	f	\N	\N	1	\N	\N	\N	316	5	\N	6
325	1866-06-01	\N	\N	f	Wodehouse	3rd Lord	1	\N	\N	\N	306	5	\N	6
301	1866-07-13	\N	\N	f	Henniker	4th Lord 	1	\N	\N	\N	282	5	3	6
314	1868-12-08	\N	\N	f	Gormanston	13th Viscount 	1	\N	\N	\N	296	5	3	6
360	1868-07-25	\N	\N	f	Feversham	3rd Lord	1	\N	\N	\N	341	5	\N	6
302	1866-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	283	5	\N	6
303	1866-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	284	5	\N	6
304	1866-07-31	\N	\N	f	\N	\N	1	\N	\N	\N	285	5	\N	6
306	1867-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	287	5	\N	6
307	1867-02-27	\N	\N	f	\N	\N	1	\N	\N	\N	288	5	\N	6
308	1868-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	289	5	\N	6
309	1868-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	290	5	\N	6
349	1868-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	329	5	\N	6
363	1871-06-23	\N	\N	t	Ripon	2nd Earl	1	\N	\N	\N	344	5	\N	6
326	1868-11-30	\N	\N	f	\N	\N	1	\N	\N	\N	295	5	\N	6
336	1872-07-16	\N	\N	f	Napier	10th Lord 	1	\N	\N	\N	317	5	2	6
315	1868-12-09	\N	\N	f	\N	\N	1	\N	\N	\N	297	5	\N	6
316	1869-04-03	\N	\N	f	\N	\N	1	\N	\N	\N	298	5	\N	6
317	1869-04-06	\N	\N	f	\N	\N	1	\N	\N	\N	299	5	\N	6
320	1869-12-09	\N	\N	f	\N	\N	1	\N	\N	\N	302	5	\N	6
321	1869-12-10	\N	\N	f	\N	\N	1	\N	\N	\N	303	5	\N	6
322	1869-12-11	\N	\N	f	\N	\N	1	\N	\N	\N	304	5	\N	6
323	1869-12-13	\N	\N	f	\N	\N	1	\N	\N	\N	305	5	\N	6
327	1869-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	307	5	\N	6
328	1869-12-15	\N	\N	f	\N	\N	1	\N	\N	\N	308	5	\N	6
329	1870-05-03	\N	\N	f	\N	\N	1	\N	\N	\N	309	5	\N	6
330	1870-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	310	5	\N	6
332	1871-03-23	\N	\N	f	\N	\N	1	\N	\N	\N	312	5	\N	6
333	1871-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	313	5	\N	6
359	1874-02-27	\N	\N	t	Westminster	3rd Marquess	1	\N	\N	\N	340	5	\N	6
271	1871-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	254	5	\N	6
340	1873-03-28	\N	\N	f	Portman	1st Lord	1	\N	\N	\N	180	5	\N	6
337	1872-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	318	5	\N	6
338	1872-10-23	\N	\N	f	\N	\N	1	\N	\N	\N	319	5	\N	6
385	1881-10-07	\N	\N	t	Howth	4th Earl 	1	\N	\N	\N	366	5	3	6
341	1873-04-10	\N	\N	f	\N	\N	1	\N	\N	\N	321	5	\N	6
342	1873-06-12	\N	\N	f	\N	\N	1	\N	\N	\N	322	5	\N	6
344	1874-01-08	\N	\N	f	\N	\N	1	\N	\N	\N	324	5	\N	6
345	1874-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	325	5	\N	6
346	1874-01-10	\N	\N	f	\N	\N	1	\N	\N	\N	326	5	\N	6
347	1874-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	327	5	\N	6
362	1876-01-14	\N	\N	t	Abergavenny	5th Earl	1	\N	\N	\N	343	5	\N	6
382	1874-03-05	\N	\N	f	\N	\N	1	\N	\N	\N	363	5	\N	6
350	1874-03-06	\N	\N	f	\N	\N	1	\N	\N	\N	330	5	\N	6
351	1874-03-16	\N	\N	f	\N	\N	1	\N	\N	\N	331	5	\N	6
400	1877-01-03	\N	\N	f	Redesdale	2nd Lord	1	\N	\N	\N	381	5	\N	6
353	1875-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	333	5	\N	6
398	1880-04-28	\N	\N	f	Lytton	2nd Lord	1	\N	\N	\N	379	5	\N	6
365	1876-01-14	\N	\N	f	\N	\N	2	\N	\N	\N	335	5	\N	6
355	1876-01-15	\N	\N	f	\N	\N	2	\N	\N	\N	336	5	\N	6
356	1876-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	337	5	\N	6
357	1876-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	338	5	\N	6
402	1876-10-02	\N	\N	f	\N	\N	1	\N	\N	\N	345	5	\N	6
366	1876-10-17	\N	\N	f	\N	\N	1	\N	\N	\N	346	5	\N	6
367	1876-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	347	5	\N	6
397	1880-05-03	\N	\N	f	Skelmersdale	2nd Lord	1	\N	\N	\N	378	5	\N	6
368	1878-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	348	5	\N	6
369	1878-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	349	5	\N	6
404	1880-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	351	5	\N	6
408	1884-11-10	\N	\N	f	Herries	11th Lord 	1	\N	\N	\N	385	5	2	6
371	1880-04-28	\N	\N	f	\N	\N	2	\N	\N	\N	352	5	\N	6
372	1880-04-29	\N	\N	f	\N	\N	1	\N	\N	\N	353	5	\N	6
373	1880-04-30	\N	\N	f	\N	\N	1	\N	\N	\N	354	5	\N	6
374	1880-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	355	5	\N	6
401	1882-12-30	\N	\N	f	Selborne	1st Lord	1	\N	\N	\N	319	5	\N	6
375	1880-05-03	\N	\N	f	\N	\N	2	\N	\N	\N	356	5	\N	6
377	1880-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	358	5	\N	6
378	1880-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	359	5	\N	6
379	1880-05-06	\N	\N	f	\N	\N	1	\N	\N	\N	360	5	\N	6
380	1880-05-25	\N	\N	f	\N	\N	1	\N	\N	\N	361	5	\N	6
381	1880-05-25	\N	\N	f	\N	\N	2	\N	\N	\N	362	5	\N	6
290	1863-06-19	\N	\N	t	Somerset	12th Duke	1	\N	\N	\N	270	5	\N	6
387	1881-10-10	\N	\N	f	\N	\N	1	\N	\N	\N	368	5	\N	6
388	1881-10-11	\N	\N	f	\N	\N	1	\N	\N	\N	369	5	\N	6
389	1881-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	370	5	\N	6
390	1882-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	371	5	\N	6
391	1882-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	372	5	\N	6
392	1882-11-24	\N	\N	f	\N	\N	1	\N	\N	\N	373	5	\N	6
393	1882-11-25	\N	\N	f	\N	\N	1	\N	\N	\N	374	5	\N	6
395	1884-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	376	5	\N	6
396	1884-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	377	5	\N	6
289	1851-04-05	\N	\N	f	de Freyne	1st Lord	1	\N	\N	\N	207	5	\N	6
405	1884-11-05	\N	\N	f	\N	\N	1	\N	\N	\N	382	5	\N	6
287	1847-09-18	\N	\N	f	Strafford	1st Lord	1	\N	\N	\N	175	5	\N	6
286	1846-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	268	5	\N	6
413	1885-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	390	5	\N	6
414	1885-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	391	5	\N	6
415	1885-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	392	5	\N	6
438	1885-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	417	5	\N	6
416	1885-07-03	\N	\N	f	\N	\N	2	\N	\N	\N	393	5	\N	6
417	1885-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	394	5	\N	6
437	1887-07-02	\N	\N	f	Galway	7th Viscount 	1	\N	\N	\N	416	5	3	6
420	1885-07-24	\N	\N	f	\N	\N	1	\N	\N	\N	397	5	\N	6
441	1885-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	398	5	\N	6
421	1885-12-29	\N	\N	f	\N	\N	1	\N	\N	\N	399	5	\N	6
458	1886-02-08	\N	\N	f	\N	\N	1	\N	\N	\N	437	5	\N	6
459	1886-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	438	5	\N	6
424	1886-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	402	5	\N	6
425	1886-03-22	\N	\N	f	\N	\N	1	\N	\N	\N	404	5	\N	6
428	1886-08-13	\N	\N	f	Monson	7th Lord	1	\N	\N	\N	407	5	\N	6
427	1886-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	406	5	\N	6
439	1887-07-01	\N	\N	f	Londesborough	2nd Lord	1	\N	\N	\N	418	5	\N	6
429	1886-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	408	5	\N	6
430	1886-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	409	5	\N	6
431	1886-08-17	\N	\N	f	\N	\N	1	\N	\N	\N	410	5	\N	6
434	1887-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	413	5	\N	6
435	1887-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	414	5	\N	6
508	1897-07-23	\N	\N	t	Glasgow	7th Earl 	1	\N	\N	\N	483	5	2	6
478	1892-08-22	\N	\N	t	Zetland	3rd Earl	1	\N	\N	\N	458	5	\N	6
443	1887-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	419	5	\N	6
444	1887-07-05	\N	\N	f	\N	\N	1	\N	\N	\N	420	5	\N	6
445	1887-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	421	5	\N	6
447	1887-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	423	5	\N	6
448	1887-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	424	5	\N	6
449	1887-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	425	5	\N	6
450	1888-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	426	5	\N	6
480	1888-10-27	\N	\N	f	\N	\N	1	\N	\N	\N	427	5	\N	6
538	1896-06-17	\N	\N	t	Rutland	7th Duke	1	\N	\N	\N	510	5	\N	6
452	1890-04-14	\N	\N	f	\N	\N	1	\N	\N	\N	429	5	\N	6
453	1891-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	430	5	\N	6
454	1891-01-21	\N	\N	f	\N	\N	1	\N	\N	\N	431	5	\N	6
455	1891-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	432	5	\N	6
479	1891-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	434	5	\N	6
482	1891-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	435	5	\N	6
457	1892-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	436	5	\N	6
503	1892-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	478	5	\N	6
460	1892-06-18	\N	\N	f	\N	\N	1	\N	\N	\N	439	5	\N	6
462	1892-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	441	5	\N	6
520	1895-07-17	\N	\N	f	Houghton	2nd Lord	1	\N	\N	\N	494	5	\N	6
463	1892-08-22	\N	\N	f	\N	\N	3	\N	\N	\N	442	5	\N	6
464	1892-08-23	\N	\N	f	\N	\N	2	\N	\N	\N	443	5	\N	6
465	1892-08-25	\N	\N	f	\N	\N	1	\N	\N	\N	444	5	\N	6
467	1892-08-29	\N	\N	f	\N	\N	1	\N	\N	\N	447	5	\N	6
468	1892-08-30	\N	\N	f	\N	\N	1	\N	\N	\N	448	5	\N	6
469	1892-09-03	\N	\N	f	\N	\N	1	\N	\N	\N	449	5	\N	6
470	1892-09-05	\N	\N	f	\N	\N	1	\N	\N	\N	450	5	\N	6
472	1893-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	452	5	\N	6
483	1893-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	459	5	\N	6
485	1893-08-21	\N	\N	f	\N	\N	1	\N	\N	\N	461	5	\N	6
487	1894-03-30	\N	\N	f	\N	\N	1	\N	\N	\N	463	5	\N	6
488	1894-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	464	5	\N	6
490	1894-08-13	\N	\N	f	\N	\N	1	\N	\N	\N	466	5	\N	6
491	1895-05-09	\N	\N	f	\N	\N	1	\N	\N	\N	467	5	\N	6
509	1897-07-24	\N	\N	f	Downe	8th Viscount 	1	\N	\N	\N	484	5	3	6
493	1895-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	469	5	\N	6
494	1895-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	470	5	\N	6
495	1895-07-25	\N	\N	f	\N	\N	1	\N	\N	\N	471	5	\N	6
497	1895-08-03	\N	\N	f	\N	\N	2	\N	\N	\N	472	5	\N	6
498	1895-08-05	\N	\N	f	\N	\N	1	\N	\N	\N	473	5	\N	6
499	1895-08-05	\N	\N	f	\N	\N	2	\N	\N	\N	474	5	\N	6
501	1895-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	476	5	\N	6
502	1895-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	477	5	\N	6
537	1896-06-08	\N	\N	f	\N	\N	1	\N	\N	\N	509	5	\N	6
426	1886-03-23	\N	\N	f	Kensington	4th Lord 	1	\N	\N	\N	405	5	3	6
504	1896-08-11	\N	\N	f	\N	\N	1	\N	\N	\N	479	5	\N	6
506	1897-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	481	5	\N	6
515	1898-06-11	\N	\N	f	Muncaster	5th Lord 	1	\N	\N	\N	490	5	3	6
513	1897-11-11	\N	\N	f	Esher	1st Lord	1	\N	\N	\N	397	5	\N	6
510	1897-07-26	\N	\N	f	\N	\N	1	\N	\N	\N	485	5	\N	6
512	1897-07-28	\N	\N	f	\N	\N	1	\N	\N	\N	487	5	\N	6
522	1897-11-29	\N	\N	f	Burton	1st Lord	1	\N	\N	\N	488	5	\N	6
473	1889-07-29	\N	\N	t	Fife	6th Earl 	1	\N	\N	\N	453	5	3	6
514	1898-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	489	5	\N	6
531	1900-06-15	\N	\N	f	Morris	Lord	1	\N	\N	\N	428	5	\N	6
516	1898-06-13	\N	\N	f	\N	\N	1	\N	\N	\N	491	5	\N	6
517	1898-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	492	5	\N	6
519	1899-01-25	\N	\N	f	\N	\N	2	\N	\N	\N	493	5	\N	6
523	1899-01-26	\N	\N	f	\N	\N	1	\N	\N	\N	495	5	\N	6
524	1899-01-27	\N	\N	f	\N	\N	1	\N	\N	\N	496	5	\N	6
527	1899-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	500	5	\N	6
528	1900-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	501	5	\N	6
529	1900-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	502	5	\N	6
553	1905-12-18	\N	\N	f	Iveagh	1st Lord	2	\N	\N	\N	431	5	\N	5
532	1900-06-16	\N	\N	f	\N	\N	1	\N	\N	\N	504	5	\N	6
533	1900-06-18	\N	\N	f	\N	\N	1	\N	\N	\N	505	5	\N	6
534	1900-12-18	\N	\N	f	\N	\N	1	\N	\N	\N	506	5	\N	6
539	1902-07-15	\N	\N	f	\N	\N	2	\N	\N	\N	511	5	\N	5
541	1902-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	513	5	\N	5
542	1902-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	514	5	\N	5
543	1902-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	515	5	\N	5
544	1902-07-21	\N	\N	f	\N	\N	1	\N	\N	\N	516	5	\N	5
546	1903-07-31	\N	\N	f	\N	\N	1	\N	\N	\N	518	5	\N	5
547	1903-08-01	\N	\N	f	\N	\N	1	\N	\N	\N	519	5	\N	5
549	1903-08-04	\N	\N	f	\N	\N	1	\N	\N	\N	521	5	\N	5
551	1905-03-09	\N	\N	f	\N	\N	1	\N	\N	\N	523	5	\N	5
552	1905-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	524	5	\N	5
554	1905-12-18	\N	\N	f	\N	\N	3	\N	\N	\N	525	5	\N	5
423	1881-03-11	\N	\N	f	\N	\N	1	\N	\N	\N	401	5	\N	6
412	1885-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	389	5	\N	6
557	1905-12-18	\N	\N	f	Windsor	14th Lord	1	\N	\N	\N	527	5	\N	5
625	1911-07-04	\N	\N	f	Loreburn	1st Lord	1	\N	\N	\N	540	5	\N	4
561	1905-12-19	\N	\N	f	\N	\N	2	\N	\N	\N	529	5	\N	5
562	1905-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	530	5	\N	5
565	1905-12-26	\N	\N	f	\N	\N	1	\N	\N	\N	533	5	\N	5
566	1905-12-27	\N	\N	f	\N	\N	1	\N	\N	\N	534	5	\N	5
568	1905-12-28	\N	\N	f	\N	\N	2	\N	\N	\N	536	5	\N	5
569	1905-12-29	\N	\N	f	\N	\N	1	\N	\N	\N	537	5	\N	5
570	1905-12-30	\N	\N	f	\N	\N	1	\N	\N	\N	538	5	\N	5
571	1906-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	539	5	\N	5
572	1906-01-08	\N	\N	f	\N	\N	1	\N	\N	\N	540	5	\N	5
573	1906-01-10	\N	\N	f	\N	\N	1	\N	\N	\N	541	5	\N	5
575	1906-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	543	5	\N	5
576	1906-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	544	5	\N	5
616	1906-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	584	5	\N	5
579	1906-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	547	5	\N	5
580	1906-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	548	5	\N	5
581	1906-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	549	5	\N	5
582	1906-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	550	5	\N	5
584	1906-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	552	5	\N	5
585	1907-03-06	\N	\N	f	\N	\N	1	\N	\N	\N	553	5	\N	5
587	1907-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	555	5	\N	5
588	1907-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	556	5	\N	5
589	1907-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	557	5	\N	5
590	1908-05-02	\N	\N	f	\N	\N	1	\N	\N	\N	558	5	\N	5
592	1908-05-22	\N	\N	f	\N	\N	1	\N	\N	\N	560	5	\N	5
594	1908-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	562	5	\N	5
595	1908-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	563	5	\N	5
618	1909-02-15	\N	\N	f	\N	\N	1	\N	283	\N	586	5	\N	5
597	1909-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	565	5	\N	5
599	1909-12-07	\N	\N	f	\N	\N	1	\N	\N	\N	567	5	\N	5
600	1909-12-08	\N	\N	f	\N	\N	1	\N	\N	\N	568	5	\N	5
601	1910-03-15	\N	\N	f	\N	\N	1	\N	\N	\N	569	5	\N	5
603	1910-03-16	\N	\N	f	\N	\N	1	\N	\N	\N	571	5	\N	5
605	1910-07-13	\N	\N	f	\N	\N	1	\N	\N	\N	573	5	\N	4
606	1910-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	574	5	\N	4
608	1910-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	576	5	\N	4
609	1910-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	577	5	\N	4
610	1910-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	578	5	\N	4
611	1910-07-21	\N	\N	f	\N	\N	1	\N	\N	\N	579	5	\N	4
613	1910-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	581	5	\N	4
615	1911-04-03	\N	\N	f	\N	\N	1	\N	\N	\N	583	5	\N	4
655	1911-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	619	5	\N	4
657	1911-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	621	5	\N	4
619	1911-06-24	\N	\N	f	\N	\N	1	\N	\N	\N	587	5	\N	4
620	1911-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	588	5	\N	4
621	1911-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	589	5	\N	4
623	1911-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	591	5	\N	4
626	1911-07-04	\N	\N	f	Knollys	1st Lord	2	\N	\N	\N	516	5	\N	4
628	1911-07-05	\N	\N	f	Allendale	2nd Lord	2	\N	\N	\N	593	5	\N	4
644	1913-11-24	\N	\N	f	Alverstone	1st Lord	1	\N	\N	\N	505	5	\N	4
629	1911-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	594	5	\N	4
630	1911-11-02	\N	\N	f	\N	\N	2	\N	\N	\N	595	5	\N	4
631	1911-11-03	\N	\N	f	\N	\N	1	\N	\N	\N	596	5	\N	4
656	1912-02-07	\N	\N	f	\N	\N	1	\N	2	\N	620	5	\N	4
632	1912-02-08	\N	\N	f	\N	\N	1	\N	2	\N	597	5	\N	4
633	1912-02-09	\N	\N	f	\N	\N	1	\N	2	\N	598	5	\N	4
635	1912-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	600	5	\N	4
636	1912-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	601	5	\N	4
637	1912-08-13	\N	\N	f	\N	\N	1	\N	\N	\N	602	5	\N	4
638	1912-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	603	5	\N	4
640	1913-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	605	5	\N	4
642	1913-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	607	5	\N	4
643	1913-10-20	\N	\N	f	\N	\N	1	\N	\N	\N	608	5	\N	4
662	1916-01-22	\N	\N	f	Mersey	1st Lord	1	\N	\N	\N	571	5	\N	4
645	1914-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	609	5	\N	4
646	1914-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	610	5	\N	4
647	1914-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	611	5	\N	4
650	1914-05-11	\N	\N	f	\N	\N	1	\N	\N	\N	614	5	\N	4
651	1914-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	615	5	\N	4
652	1914-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	616	5	\N	4
653	1914-07-03	\N	\N	f	\N	\N	1	\N	\N	\N	617	5	\N	4
695	1914-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	653	5	\N	4
696	1915-04-12	\N	\N	f	\N	\N	1	\N	\N	\N	654	5	\N	4
658	1915-06-14	\N	\N	f	\N	\N	1	\N	\N	\N	622	5	\N	4
661	1916-01-01	\N	\N	f	\N	\N	1	\N	\N	\N	625	5	\N	4
689	1917-06-21	\N	\N	f	Farquhar	1st Lord	1	\N	\N	\N	489	5	\N	4
663	1916-01-22	\N	\N	f	\N	\N	2	\N	\N	\N	626	5	\N	4
664	1916-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	627	5	\N	4
666	1916-01-26	\N	\N	f	\N	\N	1	\N	\N	\N	629	5	\N	4
667	1916-01-27	\N	\N	f	\N	\N	1	\N	\N	\N	630	5	\N	4
668	1916-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	631	5	\N	4
669	1916-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	632	5	\N	4
672	1916-06-27	\N	\N	f	\N	\N	1	\N	\N	\N	634	5	\N	4
673	1916-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	635	5	\N	4
674	1916-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	636	5	\N	4
675	1916-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	637	5	\N	4
676	1916-07-27	\N	\N	f	\N	\N	1	\N	\N	\N	638	5	\N	4
679	1917-01-02	\N	\N	f	\N	\N	2	\N	\N	\N	640	5	\N	4
680	1917-01-03	\N	\N	f	\N	\N	1	\N	\N	\N	641	5	\N	4
681	1917-01-03	\N	\N	f	\N	\N	2	\N	\N	\N	642	5	\N	4
683	1917-01-05	\N	\N	f	\N	\N	1	\N	\N	\N	644	5	\N	4
684	1917-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	645	5	\N	4
685	1917-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	646	5	\N	4
687	1917-06-19	\N	\N	f	\N	\N	1	\N	\N	\N	648	5	\N	4
688	1917-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	649	5	\N	4
690	1917-06-21	\N	\N	f	\N	\N	2	\N	\N	\N	650	5	\N	4
692	1917-06-22	\N	\N	f	\N	\N	2	\N	\N	\N	651	5	\N	4
694	1917-06-23	\N	\N	f	\N	\N	2	\N	\N	\N	652	5	\N	4
697	1917-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	655	5	\N	4
699	1918-01-15	\N	\N	f	\N	\N	2	\N	\N	\N	656	5	\N	4
701	1918-01-16	\N	\N	f	\N	\N	2	\N	\N	\N	658	5	\N	4
558	1902-10-27	\N	\N	t	Hopetoun	7th Earl 	1	\N	\N	\N	528	5	2	5
702	1918-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	659	5	\N	4
559	1899-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	498	5	\N	6
721	1918-06-19	\N	\N	f	Rhondda	1st Lord	1	\N	3	\N	631	5	\N	4
725	1919-03-27	\N	\N	f	Finlay	1st Lord	1	\N	\N	\N	679	5	\N	4
707	1918-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	663	5	\N	4
706	1918-06-27	\N	\N	f	\N	\N	1	\N	3	\N	662	5	\N	4
708	1918-06-28	\N	\N	f	\N	\N	1	\N	3	\N	664	5	\N	4
709	1918-06-29	\N	\N	f	\N	\N	1	\N	3	\N	665	5	\N	4
711	1918-07-01	\N	\N	f	\N	\N	1	\N	\N	\N	667	5	\N	4
712	1918-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	668	5	\N	4
713	1918-07-09	\N	\N	f	\N	\N	1	\N	\N	\N	669	5	\N	4
715	1918-10-15	\N	\N	f	\N	\N	1	\N	\N	\N	670	5	\N	4
716	1918-11-14	\N	\N	f	\N	\N	2	\N	\N	\N	671	5	\N	4
718	1919-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	673	5	\N	4
722	1919-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	676	5	\N	4
723	1919-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	677	5	\N	4
726	1919-04-24	\N	\N	f	\N	\N	1	\N	\N	\N	680	5	\N	4
754	1921-06-03	\N	\N	f	Chelmsford	3rd Lord	1	\N	\N	\N	705	5	\N	4
728	1919-05-17	\N	\N	f	\N	\N	2	\N	4	\N	681	5	\N	4
729	1919-05-19	\N	\N	f	\N	\N	1	\N	4	\N	682	5	\N	4
730	1919-05-20	\N	\N	f	\N	\N	1	\N	4	\N	683	5	\N	4
731	1919-09-27	\N	\N	f	\N	\N	1	\N	\N	\N	684	5	\N	4
770	1919-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	719	5	\N	4
771	1919-10-04	\N	\N	f	\N	\N	1	\N	\N	\N	720	5	\N	4
760	1919-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	686	5	\N	4
734	1919-10-07	\N	\N	f	\N	\N	2	\N	\N	\N	687	5	\N	4
735	1919-10-08	\N	\N	f	\N	\N	1	\N	\N	\N	688	5	\N	4
772	1919-10-09	\N	\N	f	\N	\N	1	\N	5	\N	721	5	\N	4
736	1919-10-27	\N	\N	f	\N	\N	1	\N	5	\N	689	5	\N	4
737	1919-11-01	\N	\N	f	\N	\N	1	\N	\N	\N	690	5	\N	4
738	1919-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	691	5	\N	4
739	1919-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	692	5	\N	4
741	1920-02-09	\N	\N	f	\N	\N	1	\N	6	\N	694	5	\N	4
743	1920-04-21	\N	\N	f	\N	\N	1	\N	\N	\N	696	5	\N	4
746	1920-12-06	\N	\N	f	\N	\N	1	\N	\N	\N	698	5	\N	4
742	1921-01-14	\N	\N	f	\N	\N	1	\N	8	\N	695	5	\N	4
744	1921-01-15	\N	\N	f	\N	\N	1	\N	8	\N	697	5	\N	4
747	1921-01-17	\N	\N	f	\N	\N	1	\N	8	\N	699	5	\N	4
749	1921-01-19	\N	\N	f	\N	\N	1	\N	8	\N	701	5	\N	4
752	1921-04-28	\N	\N	f	\N	\N	1	\N	\N	\N	703	5	\N	4
753	1921-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	704	5	\N	4
755	1921-06-04	\N	\N	f	\N	\N	1	\N	\N	\N	706	5	\N	4
800	1922-11-28	\N	\N	f	Birkenhead	1st Viscount	1	\N	\N	\N	673	5	\N	4
751	1921-06-15	\N	\N	f	\N	\N	2	\N	9	\N	702	5	\N	4
762	1921-06-28	\N	\N	f	\N	\N	2	\N	9	\N	712	5	\N	4
763	1921-07-01	\N	\N	f	\N	\N	1	\N	9	\N	713	5	\N	4
766	1921-07-08	\N	\N	f	\N	\N	1	\N	\N	\N	716	5	\N	4
768	1921-07-26	\N	\N	f	\N	\N	1	\N	\N	\N	717	5	\N	4
769	1921-08-24	\N	\N	f	\N	\N	1	\N	\N	\N	718	5	\N	4
764	1922-01-23	\N	\N	f	\N	\N	1	\N	10	\N	714	5	\N	4
765	1922-01-24	\N	\N	f	\N	\N	1	\N	10	\N	715	5	\N	4
807	1922-01-26	\N	\N	f	\N	\N	1	\N	10	\N	752	5	\N	4
809	1922-03-24	\N	\N	f	\N	\N	1	\N	\N	\N	754	5	\N	4
808	1922-06-19	\N	\N	f	\N	\N	1	\N	11	\N	753	5	\N	4
774	1922-07-18	\N	\N	f	\N	\N	1	\N	11	\N	723	5	\N	4
775	1922-07-20	\N	\N	f	\N	\N	1	\N	11	\N	724	5	\N	4
777	1922-11-20	\N	\N	f	\N	\N	1	\N	\N	\N	726	5	\N	4
778	1922-11-21	\N	\N	f	\N	\N	1	\N	\N	\N	727	5	\N	4
779	1922-11-22	\N	\N	f	\N	\N	1	\N	\N	\N	728	5	\N	4
780	1922-11-23	\N	\N	f	\N	\N	1	\N	\N	\N	729	5	\N	4
810	1926-08-04	\N	\N	f	Tredegar	3rd Lord	1	\N	20	\N	755	5	\N	4
783	1923-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	730	5	\N	4
784	1923-02-14	\N	\N	f	\N	\N	1	\N	\N	\N	731	5	\N	4
785	1923-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	732	5	\N	4
776	1923-07-23	\N	\N	f	\N	\N	1	\N	12	\N	725	5	\N	4
788	1923-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	735	5	\N	4
789	1923-12-24	\N	\N	f	\N	\N	1	\N	\N	\N	736	5	\N	4
787	1924-01-08	\N	\N	f	\N	\N	1	\N	13	\N	734	5	\N	4
792	1924-01-21	\N	\N	f	\N	\N	2	\N	13	\N	738	5	\N	4
794	1924-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	740	5	\N	4
795	1924-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	741	5	\N	4
796	1924-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	742	5	\N	4
793	1924-02-19	\N	\N	f	\N	\N	1	\N	14	\N	739	5	\N	4
797	1924-05-07	\N	\N	f	\N	\N	1	\N	15	\N	743	5	\N	4
799	1925-01-28	\N	\N	f	\N	\N	1	\N	17	\N	745	5	\N	4
840	1925-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	784	5	\N	4
803	1925-06-12	\N	\N	f	\N	\N	1	\N	\N	\N	748	5	\N	4
804	1925-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	749	5	\N	4
806	1926-01-28	\N	\N	f	\N	\N	1	\N	19	\N	751	5	\N	4
834	1929-05-07	\N	\N	f	Shaw	Lord	1	\N	\N	\N	780	5	\N	4
812	1926-10-25	\N	\N	f	\N	\N	1	\N	\N	\N	757	5	\N	4
811	1927-01-18	\N	\N	f	\N	\N	1	\N	21	\N	756	5	\N	4
814	1927-01-29	\N	\N	f	\N	\N	1	\N	21	\N	759	5	\N	4
815	1927-01-31	\N	\N	f	\N	\N	2	\N	21	\N	760	5	\N	4
816	1927-06-21	\N	\N	f	\N	\N	1	\N	22	\N	761	5	\N	4
819	1927-11-07	\N	\N	f	\N	\N	1	\N	\N	\N	764	5	\N	4
818	1928-01-11	\N	\N	f	\N	\N	1	\N	23	\N	763	5	\N	4
820	1928-01-19	\N	\N	f	\N	\N	1	\N	23	\N	765	5	\N	4
822	1928-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	767	5	\N	4
821	1928-03-16	\N	\N	f	\N	\N	1	\N	23	\N	766	5	\N	4
824	1928-04-05	\N	\N	f	\N	\N	1	\N	\N	\N	769	5	\N	4
825	1928-06-26	\N	\N	f	\N	\N	1	\N	24	\N	771	5	\N	4
826	1928-07-05	\N	\N	f	\N	\N	1	\N	24	\N	772	5	\N	4
828	1928-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	774	5	\N	4
829	1929-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	775	5	\N	4
827	1929-03-18	\N	\N	f	\N	\N	1	\N	25	\N	773	5	\N	4
831	1929-03-20	\N	\N	f	\N	\N	1	\N	25	\N	777	5	\N	4
833	1929-05-01	\N	\N	f	\N	\N	1	\N	\N	\N	779	5	\N	4
835	1929-06-18	\N	\N	f	\N	\N	1	\N	26	\N	781	5	\N	4
836	1929-06-18	\N	\N	f	\N	\N	2	\N	26	\N	782	5	\N	4
837	1929-06-19	\N	\N	f	\N	\N	1	\N	26	\N	783	5	\N	4
842	1929-06-21	\N	\N	f	\N	\N	1	\N	\N	\N	785	5	\N	4
757	1917-07-16	\N	\N	f	\N	\N	2	\N	\N	\N	708	5	\N	4
759	1917-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	710	5	\N	4
845	1929-07-08	\N	\N	f	\N	\N	1	\N	27	\N	788	5	\N	4
846	1929-07-09	\N	\N	f	\N	\N	1	\N	27	\N	789	5	\N	4
885	1929-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	826	5	\N	4
886	1929-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	827	5	\N	4
851	1929-09-17	\N	\N	f	\N	\N	1	\N	\N	\N	794	5	\N	4
849	1930-01-16	\N	\N	f	\N	\N	1	\N	28	\N	792	5	\N	4
852	1930-01-18	\N	\N	f	\N	\N	1	\N	28	\N	795	5	\N	4
853	1930-01-20	\N	\N	f	\N	\N	1	\N	28	\N	796	5	\N	4
855	1930-01-23	\N	\N	f	\N	\N	1	\N	28	\N	798	5	\N	4
858	1930-02-03	\N	\N	f	\N	\N	1	\N	\N	\N	801	5	\N	4
857	1930-06-18	\N	\N	f	\N	\N	1	\N	29	\N	800	5	\N	4
859	1930-07-10	\N	\N	f	\N	\N	1	\N	29	\N	802	5	\N	4
860	1931-01-20	\N	\N	f	\N	\N	1	\N	30	\N	803	5	\N	4
861	1931-01-21	\N	\N	f	\N	\N	1	\N	30	\N	804	5	\N	4
863	1931-01-23	\N	\N	f	\N	\N	1	\N	30	\N	806	5	\N	4
866	1931-03-23	\N	\N	f	\N	\N	1	\N	\N	\N	809	5	\N	4
865	1931-12-05	\N	\N	f	\N	\N	1	\N	31	\N	808	5	\N	4
868	1932-01-13	\N	\N	f	\N	\N	1	\N	32	\N	811	5	\N	4
869	1932-01-14	\N	\N	f	\N	\N	1	\N	32	\N	812	5	\N	4
870	1932-01-18	\N	\N	f	\N	\N	1	\N	32	\N	813	5	\N	4
871	1932-01-21	\N	\N	f	\N	\N	1	\N	32	\N	814	5	\N	4
895	1934-06-28	\N	\N	f	Wakefield	1st Lord	1	\N	37	\N	796	5	\N	4
876	1932-04-11	\N	\N	f	\N	\N	1	\N	\N	\N	818	5	\N	4
874	1932-06-17	\N	\N	f	\N	\N	1	\N	33	\N	816	5	\N	4
875	1932-06-20	\N	\N	f	\N	\N	1	\N	33	\N	817	5	\N	4
878	1932-06-28	\N	\N	f	\N	\N	1	\N	33	\N	820	5	\N	4
881	1933-01-19	\N	\N	f	\N	\N	1	\N	34	\N	822	5	\N	4
882	1933-01-23	\N	\N	f	\N	\N	1	\N	34	\N	823	5	\N	4
883	1933-01-26	\N	\N	f	\N	\N	1	\N	34	\N	824	5	\N	4
922	1933-03-01	\N	\N	f	\N	\N	1	\N	34	\N	860	5	\N	4
923	1933-06-21	\N	\N	f	\N	\N	1	\N	35	\N	861	5	\N	4
924	1933-06-22	\N	\N	f	\N	\N	1	\N	35	\N	862	5	\N	4
888	1933-06-24	\N	\N	f	\N	\N	1	\N	35	\N	829	5	\N	4
889	1933-07-24	\N	\N	f	\N	\N	1	\N	35	\N	830	5	\N	4
891	1934-01-12	\N	\N	f	\N	\N	1	\N	36	\N	832	5	\N	4
893	1934-01-16	\N	\N	f	\N	\N	1	\N	36	\N	834	5	\N	4
894	1934-06-27	\N	\N	f	\N	\N	1	\N	37	\N	835	5	\N	4
961	1936-10-30	\N	\N	f	Dawson of Penn	1st Lord	1	\N	42	\N	694	5	\N	3
896	1934-06-28	\N	\N	f	\N	\N	2	\N	37	\N	836	5	\N	4
897	1934-06-29	\N	\N	f	\N	\N	1	\N	37	\N	837	5	\N	4
898	1935-01-24	\N	\N	f	\N	\N	1	\N	39	\N	838	5	\N	4
899	1935-01-25	\N	\N	f	\N	\N	1	\N	39	\N	839	5	\N	4
902	1935-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	841	5	\N	4
904	1935-06-25	\N	\N	f	\N	\N	1	\N	40	\N	843	5	\N	4
905	1935-06-27	\N	\N	f	\N	\N	1	\N	40	\N	844	5	\N	4
906	1935-06-28	\N	\N	f	\N	\N	1	\N	40	\N	845	5	\N	4
907	1935-06-29	\N	\N	f	\N	\N	1	\N	40	\N	846	5	\N	4
909	1935-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	848	5	\N	4
910	1935-10-07	\N	\N	f	\N	\N	1	\N	\N	\N	849	5	\N	4
912	1935-11-29	\N	\N	f	\N	\N	1	\N	\N	\N	851	5	\N	4
913	1935-11-30	\N	\N	f	\N	\N	1	\N	\N	\N	852	5	\N	4
908	1936-01-11	\N	\N	f	\N	\N	1	\N	41	\N	847	5	\N	4
916	1936-02-01	\N	\N	f	\N	\N	1	\N	41	\N	854	5	\N	3
917	1936-02-03	\N	\N	f	\N	\N	1	\N	41	\N	855	5	\N	3
918	1936-02-24	\N	\N	f	\N	\N	1	\N	41	\N	856	5	\N	3
920	1936-07-15	\N	\N	f	\N	\N	1	\N	42	\N	858	5	\N	3
921	1936-07-16	\N	\N	f	\N	\N	1	\N	42	\N	859	5	\N	3
962	1937-02-16	\N	\N	f	Greenwood	1st Lord	1	\N	43	\N	897	5	\N	2
948	1938-06-27	\N	\N	f	Stonehaven	1st Lord	1	\N	47	\N	748	5	\N	2
963	1937-02-23	\N	\N	f	\N	\N	1	\N	43	\N	898	5	\N	2
925	1937-02-24	\N	\N	f	\N	\N	1	\N	43	\N	863	5	\N	2
926	1937-05-22	\N	\N	f	\N	\N	1	\N	44	\N	864	5	\N	2
927	1937-05-24	\N	\N	f	\N	\N	1	\N	44	\N	865	5	\N	2
928	1937-06-03	\N	\N	f	\N	\N	1	\N	44	\N	866	5	\N	2
930	1937-06-07	\N	\N	f	\N	\N	1	\N	44	\N	868	5	\N	2
931	1937-06-08	\N	\N	f	\N	\N	1	\N	45	\N	869	5	\N	2
932	1937-06-08	\N	\N	f	\N	\N	2	\N	44	\N	870	5	\N	2
933	1937-06-08	\N	\N	f	\N	\N	3	\N	44	\N	871	5	\N	2
934	1937-06-09	\N	\N	f	\N	\N	1	\N	44	\N	872	5	\N	2
936	1937-06-10	\N	\N	f	\N	\N	2	\N	44	\N	874	5	\N	2
937	1937-06-11	\N	\N	f	\N	\N	1	\N	45	\N	875	5	\N	2
938	1937-06-11	\N	\N	f	\N	\N	2	\N	44	\N	876	5	\N	2
941	1938-01-05	\N	\N	f	\N	\N	1	\N	\N	\N	879	5	\N	2
942	1938-01-24	\N	\N	f	\N	\N	2	\N	46	\N	880	5	\N	2
943	1938-01-25	\N	\N	f	\N	\N	1	\N	46	\N	881	5	\N	2
944	1938-01-26	\N	\N	f	\N	\N	1	\N	46	\N	882	5	\N	2
945	1938-01-28	\N	\N	f	\N	\N	1	\N	46	\N	883	5	\N	2
947	1938-03-28	\N	\N	f	\N	\N	1	\N	\N	\N	884	5	\N	2
964	1939-09-22	\N	\N	f	Maugham	Lord	1	\N	\N	\N	849	5	\N	2
949	1938-06-28	\N	\N	f	\N	\N	1	\N	47	\N	885	5	\N	2
950	1938-06-29	\N	\N	f	\N	\N	1	\N	47	\N	886	5	\N	2
951	1939-02-01	\N	\N	f	\N	\N	1	\N	48	\N	887	5	\N	2
953	1939-02-03	\N	\N	f	\N	\N	1	\N	48	\N	889	5	\N	2
954	1939-02-04	\N	\N	f	\N	\N	1	\N	48	\N	890	5	\N	2
956	1939-07-05	\N	\N	f	\N	\N	1	\N	49	\N	892	5	\N	2
960	1939-07-06	\N	\N	f	\N	\N	1	\N	49	\N	896	5	\N	2
880	1926-05-07	\N	\N	t	Reading	1st Earl	1	\N	\N	\N	609	5	\N	4
965	1940-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	899	5	\N	2
966	1940-05-20	\N	\N	f	\N	\N	1	\N	\N	\N	900	5	\N	2
967	1940-05-28	\N	\N	f	\N	\N	1	\N	\N	\N	901	5	\N	2
969	1940-06-28	\N	\N	f	\N	\N	1	\N	50	\N	903	5	\N	2
970	1941-01-25	\N	\N	f	\N	\N	1	\N	51	\N	904	5	\N	2
972	1941-01-27	\N	\N	f	\N	\N	1	\N	51	\N	905	5	\N	2
973	1941-01-28	\N	\N	f	\N	\N	1	\N	51	\N	906	5	\N	2
976	1941-05-19	\N	\N	f	\N	\N	1	\N	\N	\N	909	5	\N	2
977	1941-07-16	\N	\N	f	\N	\N	1	\N	52	\N	910	5	\N	2
873	1932-01-30	\N	\N	f	Sankey	1st Lord	1	\N	32	\N	785	5	\N	4
848	1926-07-16	\N	\N	f	\N	\N	1	\N	20	\N	791	5	\N	4
980	1941-08-06	\N	\N	f	\N	\N	1	\N	\N	\N	913	5	\N	2
981	1941-08-14	\N	\N	f	\N	\N	1	\N	\N	\N	914	5	\N	2
979	1942-01-12	\N	\N	f	\N	\N	1	\N	53	\N	912	5	\N	2
983	1942-01-21	\N	\N	f	\N	\N	1	\N	53	\N	916	5	\N	2
984	1942-01-28	\N	\N	f	\N	\N	1	\N	54	\N	917	5	\N	2
988	1942-03-09	\N	\N	f	\N	\N	1	\N	\N	\N	921	5	\N	2
989	1942-04-02	\N	\N	f	\N	\N	1	\N	\N	\N	922	5	\N	2
987	1942-07-06	\N	\N	f	\N	\N	1	\N	55	\N	920	5	\N	2
992	1943-01-22	\N	\N	f	\N	\N	1	\N	56	\N	925	5	\N	2
994	1943-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	927	5	\N	2
993	1943-03-08	\N	\N	f	\N	\N	1	\N	56	\N	926	5	\N	2
995	1943-05-17	\N	\N	f	\N	\N	1	\N	56	\N	928	5	\N	2
998	1943-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	932	5	\N	2
996	1944-01-27	\N	\N	f	\N	\N	1	\N	58	\N	930	5	\N	2
997	1944-01-28	\N	\N	f	\N	\N	1	\N	58	\N	931	5	\N	2
1035	1944-02-01	\N	\N	f	\N	\N	1	\N	58	\N	965	5	\N	2
1002	1944-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	936	5	\N	2
1036	1944-06-26	\N	\N	f	\N	\N	1	\N	59	\N	966	5	\N	2
1004	1944-07-14	\N	\N	f	\N	\N	1	\N	\N	\N	937	5	\N	2
1005	1944-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	938	5	\N	2
1008	1945-02-12	\N	\N	f	\N	\N	2	\N	60	\N	941	5	\N	2
1022	1945-09-12	\N	\N	f	Kemsley	1st Lord	1	\N	64	\N	855	5	\N	2
1010	1945-07-02	\N	\N	f	\N	\N	2	\N	61	\N	942	5	\N	2
1011	1945-07-03	\N	\N	f	\N	\N	1	\N	61	\N	943	5	\N	2
1013	1945-07-07	\N	\N	f	\N	\N	1	\N	61	\N	945	5	\N	2
1014	1945-07-09	\N	\N	f	\N	\N	1	\N	61	\N	946	5	\N	2
1015	1945-07-10	\N	\N	f	\N	\N	1	\N	62	\N	947	5	\N	2
1016	1945-07-11	\N	\N	f	\N	\N	1	\N	62	\N	948	5	\N	2
1019	1945-07-14	\N	\N	f	\N	\N	1	\N	62	\N	951	5	\N	2
1020	1945-07-23	\N	\N	f	\N	\N	1	\N	61	\N	952	5	\N	2
1023	1945-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	954	5	\N	2
1024	1945-08-16	\N	\N	f	\N	\N	1	\N	\N	\N	955	5	\N	2
1043	1946-01-26	\N	\N	f	Cunningham of Hyndhope	1st Lord	1	\N	65	\N	959	5	\N	2
1025	1945-09-12	\N	\N	f	\N	\N	2	\N	64	\N	956	5	\N	2
1027	1945-09-13	\N	\N	f	\N	\N	2	\N	64	\N	957	5	\N	2
1028	1945-09-14	\N	\N	f	\N	\N	1	\N	64	\N	958	5	\N	2
1029	1945-09-15	\N	\N	f	\N	\N	1	\N	64	\N	959	5	\N	2
1030	1945-09-18	\N	\N	f	\N	\N	1	\N	64	\N	960	5	\N	2
1033	1945-10-19	\N	\N	f	\N	\N	1	\N	\N	\N	963	5	\N	2
1034	1945-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	964	5	\N	2
1073	1945-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	998	5	\N	2
1037	1945-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	967	5	\N	2
1039	1945-11-17	\N	\N	f	\N	\N	1	\N	\N	\N	968	5	\N	2
1040	1945-12-01	\N	\N	f	\N	\N	1	\N	\N	\N	969	5	\N	2
1041	1946-01-09	\N	\N	f	\N	\N	1	\N	\N	\N	970	5	\N	2
1069	1947-01-20	\N	\N	f	Jowitt	1st Lord	1	\N	67	\N	954	5	\N	2
1045	1946-01-28	\N	\N	f	\N	\N	2	\N	65	\N	971	5	\N	2
1047	1946-01-30	\N	\N	f	\N	\N	1	\N	65	\N	972	5	\N	2
1048	1946-01-31	\N	\N	f	\N	\N	1	\N	65	\N	973	5	\N	2
1050	1946-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	975	5	\N	2
1009	1945-07-02	\N	\N	f	Addison	1st Lord	1	\N	61	\N	864	5	\N	2
1049	1946-02-11	\N	\N	f	\N	\N	1	\N	65	\N	974	5	\N	2
1052	1946-02-12	\N	\N	f	\N	\N	1	\N	65	\N	977	5	\N	2
1056	1946-04-05	\N	\N	f	\N	\N	1	\N	\N	\N	981	5	\N	2
1054	1946-06-25	\N	\N	f	\N	\N	1	\N	66	\N	979	5	\N	2
1057	1946-06-27	\N	\N	f	\N	\N	1	\N	66	\N	982	5	\N	2
1058	1946-07-16	\N	\N	f	\N	\N	1	\N	66	\N	983	5	\N	2
1059	1946-07-17	\N	\N	f	\N	\N	1	\N	66	\N	984	5	\N	2
1060	1946-07-18	\N	\N	f	\N	\N	1	\N	66	\N	985	5	\N	2
1061	1946-09-19	\N	\N	f	\N	\N	1	\N	65	\N	987	5	\N	2
1064	1946-10-28	\N	\N	f	\N	\N	1	\N	\N	\N	990	5	\N	2
1063	1947-01-14	\N	\N	f	\N	\N	1	\N	67	\N	989	5	\N	2
1110	1947-07-03	\N	\N	f	\N	\N	1	\N	68	\N	1034	5	\N	2
1066	1947-01-15	\N	\N	f	\N	\N	1	\N	67	\N	992	5	\N	2
1068	1947-01-17	\N	\N	f	\N	\N	1	\N	67	\N	994	5	\N	2
1078	1948-02-02	\N	\N	f	Hyndley	1st Lord	1	\N	69	\N	804	5	\N	2
1070	1947-01-20	\N	\N	f	\N	\N	2	\N	67	\N	995	5	\N	2
1071	1947-01-21	\N	\N	f	\N	\N	1	\N	67	\N	996	5	\N	2
1072	1947-03-18	\N	\N	f	\N	\N	1	\N	67	\N	997	5	\N	2
1112	1947-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	1036	5	\N	2
1113	1947-07-15	\N	\N	f	\N	\N	1	\N	68	\N	1037	5	\N	2
1076	1947-07-16	\N	\N	f	\N	\N	1	\N	68	\N	1001	5	\N	2
1077	1947-10-09	\N	\N	f	\N	\N	1	\N	68	\N	1002	5	\N	2
1079	1948-02-07	\N	\N	f	\N	\N	1	\N	69	\N	1003	5	\N	2
1080	1948-02-09	\N	\N	f	\N	\N	1	\N	69	\N	1004	5	\N	2
1081	1948-02-26	\N	\N	f	\N	\N	1	\N	69	\N	1005	5	\N	2
1082	1948-06-22	\N	\N	f	\N	\N	1	\N	70	\N	1006	5	\N	2
1086	1948-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	1010	5	\N	2
1085	1949-02-16	\N	\N	f	\N	\N	1	\N	71	\N	1009	5	\N	2
1087	1949-03-09	\N	\N	f	\N	\N	1	\N	71	\N	1011	5	\N	2
1089	1949-04-13	\N	\N	f	\N	\N	1	\N	\N	\N	1013	5	\N	2
1088	1949-06-21	\N	\N	f	\N	\N	1	\N	72	\N	1012	5	\N	2
1090	1949-07-07	\N	\N	f	\N	\N	1	\N	71	\N	1014	5	\N	2
1091	1949-07-12	\N	\N	f	\N	\N	1	\N	72	\N	1015	5	\N	2
1092	1950-01-30	\N	\N	f	\N	\N	1	\N	73	\N	1016	5	\N	2
1096	1950-02-03	\N	\N	f	\N	\N	1	\N	73	\N	1020	5	\N	2
1098	1950-03-17	\N	\N	f	\N	\N	1	\N	\N	\N	1022	5	\N	2
1099	1950-04-11	\N	\N	f	\N	\N	1	\N	\N	\N	1023	5	\N	2
1097	1950-07-04	\N	\N	f	\N	\N	1	\N	74	\N	1021	5	\N	2
1100	1950-07-05	\N	\N	f	\N	\N	1	\N	74	\N	1024	5	\N	2
1101	1950-07-06	\N	\N	f	\N	\N	1	\N	74	\N	1025	5	\N	2
1102	1950-07-07	\N	\N	f	\N	\N	1	\N	74	\N	1026	5	\N	2
1103	1950-07-08	\N	\N	f	\N	\N	1	\N	74	\N	1027	5	\N	2
1104	1950-07-10	\N	\N	f	\N	\N	1	\N	74	\N	1028	5	\N	2
1108	1950-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	1032	5	\N	2
1111	1951-04-23	\N	\N	f	\N	\N	1	\N	\N	\N	1035	5	\N	2
1115	1951-12-14	\N	\N	f	\N	\N	1	\N	\N	\N	1039	5	\N	2
1106	1981-05-12	\N	\N	f	\N	\N	1	\N	190	\N	1030	5	\N	1
1001	1939-09-06	\N	\N	f	\N	\N	1	\N	\N	\N	935	5	\N	2
1000	1940-06-26	\N	\N	f	\N	\N	1	\N	50	\N	934	5	\N	2
1152	1951-12-20	\N	\N	f	\N	\N	1	\N	77	\N	1070	5	\N	2
1125	1952-03-11	\N	\N	f	Alexander of Tunis	1st Viscount	1	\N	\N	\N	1047	5	\N	1
1119	1951-12-24	\N	\N	f	\N	\N	2	\N	77	\N	1041	5	\N	2
1120	1952-01-05	\N	\N	f	\N	\N	1	\N	78	\N	1042	5	\N	2
1122	1952-01-30	\N	\N	f	\N	\N	1	\N	77	\N	1044	5	\N	2
1126	1952-06-24	\N	\N	f	Simonds	Lord	1	\N	79	\N	936	5	\N	1
1124	1952-04-10	\N	\N	f	\N	\N	1	\N	78	\N	1046	5	\N	1
1150	1954-10-18	\N	\N	f	Simonds	1st Lord	1	\N	\N	\N	936	5	\N	1
1127	1952-07-01	\N	\N	f	\N	\N	1	\N	79	\N	1048	5	\N	1
1128	1952-07-05	\N	\N	f	\N	\N	1	\N	79	\N	1049	5	\N	1
1129	1952-07-12	\N	\N	f	\N	\N	1	\N	79	\N	1050	5	\N	1
1130	1953-02-11	\N	\N	f	\N	\N	1	\N	80	\N	1051	5	\N	1
1132	1953-06-29	\N	\N	f	\N	\N	1	\N	81	\N	1053	5	\N	1
1133	1953-06-30	\N	\N	f	\N	\N	1	\N	81	\N	1054	5	\N	1
1134	1953-07-01	\N	\N	f	\N	\N	1	\N	81	\N	1055	5	\N	1
1138	1953-10-16	\N	\N	f	\N	\N	1	\N	\N	\N	1059	5	\N	1
1139	1953-11-04	\N	\N	f	\N	\N	1	\N	\N	\N	1060	5	\N	1
1136	1954-01-14	\N	\N	f	\N	\N	1	\N	82	\N	1057	5	\N	1
1137	1954-01-16	\N	\N	f	\N	\N	1	\N	82	\N	1058	5	\N	1
1141	1954-01-18	\N	\N	f	\N	\N	2	\N	82	\N	1061	5	\N	1
1143	1954-02-16	\N	\N	f	\N	\N	1	\N	82	\N	1063	5	\N	1
1146	1954-07-31	\N	\N	f	\N	\N	1	\N	83	\N	1065	5	\N	1
1149	1954-09-09	\N	\N	f	\N	\N	1	\N	\N	\N	1068	5	\N	1
1194	1956-01-09	\N	\N	f	Woolton	1st Viscount	1	\N	\N	\N	1056	5	\N	1
1151	1954-10-19	\N	\N	f	\N	\N	1	\N	\N	\N	1069	5	\N	1
1188	1955-01-28	\N	\N	f	\N	\N	1	\N	84	\N	1106	5	\N	1
1153	1955-03-18	\N	\N	f	\N	\N	1	\N	\N	\N	1071	5	\N	1
1154	1955-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	1072	5	\N	1
1155	1955-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	1073	5	\N	1
1190	1955-06-20	\N	\N	f	\N	\N	1	\N	85	\N	1108	5	\N	1
1157	1955-08-04	\N	\N	f	\N	\N	1	\N	85	\N	1075	5	\N	1
1159	1955-12-16	\N	\N	f	\N	\N	1	\N	\N	\N	1077	5	\N	1
1161	1956-01-13	\N	\N	f	\N	\N	1	\N	\N	\N	1079	5	\N	1
1162	1956-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	1080	5	\N	1
1164	1956-01-19	\N	\N	f	\N	\N	1	\N	\N	\N	1082	5	\N	1
1148	1951-10-16	\N	\N	f	\N	\N	1	\N	76	\N	1067	5	\N	2
1158	1956-01-20	\N	\N	f	\N	\N	1	\N	86	\N	1076	5	\N	1
1165	1956-01-21	\N	\N	f	\N	\N	1	\N	86	\N	1083	5	\N	1
1166	1956-01-23	\N	\N	f	\N	\N	1	\N	86	\N	1084	5	\N	1
1169	1956-07-16	\N	\N	f	\N	\N	1	\N	87	\N	1087	5	\N	1
1170	1957-01-21	\N	\N	f	\N	\N	1	\N	88	\N	1088	5	\N	1
1172	1957-01-22	\N	\N	f	\N	\N	1	\N	\N	\N	1090	5	\N	1
1173	1957-02-11	\N	\N	f	\N	\N	1	\N	\N	\N	1091	5	\N	1
1174	1957-02-12	\N	\N	f	\N	\N	1	\N	\N	\N	1092	5	\N	1
1175	1957-02-15	\N	\N	f	\N	\N	1	\N	\N	\N	1093	5	\N	1
1176	1957-04-24	\N	\N	f	\N	\N	1	\N	\N	\N	1094	5	\N	1
1179	1958-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	1097	5	\N	1
1178	1958-01-31	\N	\N	f	\N	\N	1	\N	90	\N	1096	5	\N	1
1180	1958-02-17	\N	\N	f	\N	\N	1	\N	90	\N	1098	5	\N	1
1181	1958-07-10	\N	\N	f	\N	\N	1	\N	91	\N	1099	5	\N	1
1182	1958-07-11	\N	\N	f	\N	\N	1	\N	91	\N	1100	5	\N	1
1183	1958-08-01	\N	\N	f	\N	\N	1	\N	284	\N	1101	5	\N	1
1184	1958-08-02	\N	\N	f	\N	\N	1	\N	284	\N	1102	5	\N	1
1187	1958-08-06	\N	\N	f	\N	\N	1	\N	284	\N	1105	5	\N	1
1219	1958-08-11	\N	\N	f	\N	\N	1	\N	284	\N	1137	5	\N	1
1228	1958-08-18	\N	\N	f	\N	\N	1	\N	284	\N	1146	5	\N	1
1191	1958-09-24	\N	\N	f	\N	\N	1	\N	284	\N	1110	5	\N	1
1195	1958-09-26	\N	\N	f	\N	\N	1	\N	284	\N	1111	5	\N	1
1192	1958-09-30	\N	\N	f	\N	\N	1	\N	\N	\N	1113	5	\N	1
1193	1959-02-14	\N	\N	f	\N	\N	1	\N	93	\N	1114	5	\N	1
1198	1959-02-16	\N	\N	f	\N	\N	1	\N	92	\N	1115	5	\N	1
1199	1959-02-17	\N	\N	f	\N	\N	1	\N	93	\N	1116	5	\N	1
1201	1959-03-10	\N	\N	f	\N	\N	1	\N	92	\N	1118	5	\N	1
1203	1959-04-06	\N	\N	f	\N	\N	1	\N	\N	\N	1120	5	\N	1
1202	1959-06-16	\N	\N	f	\N	\N	1	\N	93	\N	1119	5	\N	1
1204	1959-07-15	\N	\N	f	\N	\N	1	\N	94	\N	1121	5	\N	1
1205	1959-07-16	\N	\N	f	\N	\N	1	\N	94	\N	1122	5	\N	1
1206	1959-08-20	\N	\N	f	\N	\N	1	\N	94	\N	1123	5	\N	1
1207	1959-11-02	\N	\N	f	\N	\N	1	\N	95	\N	1124	5	\N	1
1209	1959-11-03	\N	\N	f	\N	\N	1	\N	\N	\N	1126	5	\N	1
1210	1959-12-08	\N	\N	f	\N	\N	1	\N	95	\N	1127	5	\N	1
1212	1960-01-20	\N	\N	f	\N	\N	2	\N	96	\N	1130	5	\N	1
1214	1960-01-30	\N	\N	f	\N	\N	1	\N	96	\N	1132	5	\N	1
1215	1960-02-08	\N	\N	f	\N	\N	1	\N	96	\N	1133	5	\N	1
1216	1960-07-04	\N	\N	f	\N	\N	1	\N	97	\N	1134	5	\N	1
1220	1960-08-02	\N	\N	f	\N	\N	1	\N	\N	\N	1138	5	\N	1
1221	1960-08-22	\N	\N	f	\N	\N	1	\N	\N	\N	1139	5	\N	1
1222	1960-09-01	\N	\N	f	\N	\N	1	\N	\N	\N	1140	5	\N	1
1223	1960-09-08	\N	\N	f	\N	\N	1	\N	\N	\N	1141	5	\N	1
1225	1960-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	1143	5	\N	1
1226	1960-11-23	\N	\N	f	\N	\N	1	\N	\N	\N	1144	5	\N	1
1227	1961-01-20	\N	\N	f	\N	\N	1	\N	\N	\N	1145	5	\N	1
1230	1961-02-08	\N	\N	f	\N	\N	1	\N	99	\N	1148	5	\N	1
1231	1961-02-09	\N	\N	f	\N	\N	1	\N	99	\N	1149	5	\N	1
1232	1961-02-10	\N	\N	f	\N	\N	1	\N	99	\N	1150	5	\N	1
1234	1961-02-16	\N	\N	f	\N	\N	1	\N	\N	\N	1152	5	\N	1
1233	1961-02-21	\N	\N	f	\N	\N	1	\N	99	\N	1151	5	\N	1
1236	1961-06-02	\N	\N	f	\N	\N	1	\N	\N	\N	1154	5	\N	1
1235	1961-06-28	\N	\N	f	\N	\N	1	\N	100	\N	1153	5	\N	1
1238	1961-07-10	\N	\N	f	\N	\N	1	\N	100	\N	1156	5	\N	1
1241	1962-01-26	\N	\N	f	\N	\N	1	\N	101	\N	1159	5	\N	1
1243	1962-02-02	\N	\N	f	\N	\N	1	\N	\N	\N	1161	5	\N	1
1242	1962-03-26	\N	\N	f	\N	\N	1	\N	101	\N	1160	5	\N	1
1244	1962-04-13	\N	\N	f	\N	\N	1	\N	102	\N	1163	5	\N	1
1245	1962-04-16	\N	\N	f	\N	\N	1	\N	102	\N	1164	5	\N	1
1247	1962-04-19	\N	\N	f	\N	\N	1	\N	\N	\N	1166	5	\N	1
1246	1962-05-03	\N	\N	f	\N	\N	1	\N	102	\N	1165	5	\N	1
1248	1962-05-10	\N	\N	f	\N	\N	1	\N	102	\N	1167	5	\N	1
1250	1962-05-14	\N	\N	f	\N	\N	1	\N	102	\N	1169	5	\N	1
1147	1951-06-27	\N	\N	f	\N	\N	1	\N	76	\N	1066	5	\N	2
1313	1965-01-01	\N	\N	f	\N	\N	2	\N	115	3	1230	5	\N	1
1317	1965-01-28	\N	\N	f	\N	\N	1	\N	116	\N	1231	5	\N	1
1305	1964-12-22	\N	\N	f	\N	\N	1	\N	115	2	1222	5	\N	1
1326	1965-05-12	\N	\N	f	\N	\N	1	\N	118	2	1241	5	\N	1
1324	1965-05-11	\N	\N	f	\N	\N	2	\N	118	3	1239	5	\N	1
1327	1965-05-12	\N	\N	f	\N	\N	2	\N	118	3	1242	5	\N	1
1328	1965-05-13	\N	\N	f	\N	\N	1	\N	118	2	1243	5	\N	1
1329	1965-05-13	\N	\N	f	\N	\N	2	\N	118	3	1244	5	\N	1
1331	1965-05-14	\N	\N	f	\N	\N	2	\N	118	3	1246	5	\N	1
1258	1963-01-24	\N	\N	f	\N	\N	1	\N	104	\N	1176	5	\N	1
1254	1963-01-18	\N	\N	f	\N	\N	1	\N	104	\N	1173	5	\N	1
1260	1963-01-31	\N	\N	f	\N	\N	1	\N	104	\N	1178	5	\N	1
1261	1963-06-13	\N	\N	f	\N	\N	1	\N	105	\N	1179	5	\N	1
1262	1963-07-09	\N	\N	f	\N	\N	1	\N	105	\N	1180	5	\N	1
1265	1963-11-26	\N	\N	f	\N	\N	1	\N	\N	\N	1184	5	\N	1
1275	1961-02-04	\N	\N	f	\N	\N	1	\N	99	\N	1182	5	\N	1
1267	1964-01-14	\N	\N	f	Eccles	1st Lord	1	\N	108	\N	1175	5	\N	1
1304	1963-11-27	\N	\N	f	\N	\N	1	\N	106	\N	1220	5	\N	1
1268	1964-01-15	\N	\N	f	\N	\N	1	\N	107	\N	1187	5	\N	1
1307	1964-12-23	\N	\N	f	\N	\N	1	\N	114	\N	1224	5	\N	1
1270	1964-01-18	\N	\N	f	\N	\N	1	\N	107	\N	1189	5	\N	1
1271	1964-01-20	\N	\N	f	\N	\N	1	\N	107	\N	1190	5	\N	1
1277	1964-01-21	\N	\N	f	\N	\N	1	\N	107	\N	1191	5	\N	1
1266	1964-01-11	\N	\N	f	\N	\N	1	\N	\N	\N	1186	5	\N	1
1255	1962-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	1174	5	\N	1
1278	1964-01-22	\N	\N	f	\N	\N	1	\N	107	\N	1192	5	\N	1
1264	1961-02-07	\N	\N	f	\N	\N	1	\N	99	\N	1183	5	\N	1
1273	1962-04-12	\N	\N	f	\N	\N	1	\N	102	\N	1162	5	\N	1
1315	1964-01-23	\N	\N	f	\N	\N	1	\N	107	\N	1193	5	\N	1
1279	1964-03-10	\N	\N	f	\N	\N	1	\N	108	\N	1194	5	\N	1
1282	1964-06-29	\N	\N	f	\N	\N	1	\N	111	\N	1197	5	\N	1
1283	1964-07-16	\N	\N	f	\N	\N	1	\N	111	\N	1198	5	\N	1
1284	1964-07-16	\N	\N	f	\N	\N	2	\N	111	\N	1199	5	\N	1
1286	1964-08-24	\N	\N	f	\N	\N	1	\N	113	\N	1201	5	\N	1
1287	1964-08-25	\N	\N	f	\N	\N	1	\N	113	\N	1202	5	\N	1
1290	1964-09-04	\N	\N	f	\N	\N	1	\N	\N	\N	1205	5	\N	1
1288	1964-09-14	\N	\N	f	\N	\N	1	\N	113	\N	1203	5	\N	1
1289	1964-09-17	\N	\N	f	\N	\N	1	\N	113	\N	1204	5	\N	1
1291	1964-10-01	\N	\N	f	\N	\N	1	\N	112	\N	1206	5	\N	1
1294	1964-10-27	\N	\N	f	\N	\N	1	\N	\N	\N	1209	5	\N	1
1295	1964-10-29	\N	\N	f	\N	\N	1	\N	\N	\N	1210	5	\N	1
1296	1964-11-11	\N	\N	f	\N	\N	1	\N	\N	\N	1211	5	\N	1
1314	1964-12-08	\N	\N	f	\N	\N	1	\N	114	\N	1212	5	\N	1
1298	1964-12-12	\N	\N	f	\N	\N	1	\N	115	\N	1214	5	\N	1
1299	1964-12-14	\N	\N	f	\N	\N	1	\N	115	\N	1215	5	\N	1
1300	1964-12-15	\N	\N	f	\N	\N	1	\N	115	\N	1216	5	\N	1
1302	1964-12-16	\N	\N	f	\N	\N	2	\N	115	3	1218	5	\N	1
1332	1965-06-22	\N	\N	f	\N	\N	1	\N	119	\N	1247	5	\N	1
1342	1964-12-18	\N	\N	f	\N	\N	2	\N	115	3	1259	5	\N	1
1316	1964-12-21	\N	\N	f	\N	\N	1	\N	115	2	1221	5	\N	1
1308	1964-12-28	\N	\N	f	\N	\N	1	\N	115	\N	1225	5	\N	1
1309	1964-12-29	\N	\N	f	\N	\N	1	\N	115	\N	1226	5	\N	1
1310	1964-12-30	\N	\N	f	\N	\N	1	\N	114	\N	1227	5	\N	1
1318	1965-01-29	\N	\N	f	\N	\N	1	\N	116	\N	1232	5	\N	1
1319	1965-02-04	\N	\N	f	\N	\N	1	\N	116	\N	1233	5	\N	1
1325	1965-05-11	\N	\N	f	\N	\N	1	\N	\N	2	1240	5	\N	1
1263	1961-02-03	\N	\N	f	\N	\N	1	\N	98	\N	1181	5	\N	1
1322	1965-02-19	\N	\N	f	\N	\N	1	\N	\N	\N	1236	5	\N	1
1320	1965-03-24	\N	\N	f	\N	\N	1	\N	116	\N	1234	5	\N	1
1354	1965-05-10	\N	\N	f	\N	\N	1	\N	118	2	1237	5	\N	1
1333	1965-07-05	\N	\N	f	\N	\N	1	\N	119	\N	1248	5	\N	1
1335	1965-07-07	\N	\N	f	\N	\N	1	\N	119	\N	1250	5	\N	1
1336	1965-07-16	\N	\N	f	\N	\N	1	\N	119	\N	1251	5	\N	1
1337	1965-07-20	\N	\N	f	\N	\N	1	\N	119	\N	1252	5	\N	1
1339	1966-01-15	\N	\N	f	\N	\N	1	\N	120	\N	1254	5	\N	1
1355	1966-01-17	\N	\N	f	\N	\N	1	\N	120	\N	1256	5	\N	1
1377	1966-01-19	\N	\N	f	\N	\N	1	\N	120	\N	1296	5	\N	1
1380	1966-06-02	\N	\N	f	\N	\N	1	\N	121	\N	1299	5	\N	1
1343	1966-06-06	\N	\N	f	\N	\N	1	\N	121	\N	1260	5	\N	1
1344	1966-06-07	\N	\N	f	\N	\N	1	\N	121	\N	1261	5	\N	1
1346	1966-06-10	\N	\N	f	\N	\N	1	\N	121	\N	1263	5	\N	1
1347	1966-06-15	\N	\N	f	\N	\N	1	\N	121	\N	1264	5	\N	1
1349	1966-06-23	\N	\N	f	\N	\N	1	\N	122	\N	1266	5	\N	1
1351	1966-07-04	\N	\N	f	\N	\N	1	\N	122	\N	1268	5	\N	1
1352	1966-07-05	\N	\N	f	\N	\N	1	\N	122	\N	1269	5	\N	1
1353	1966-07-11	\N	\N	f	\N	\N	1	\N	122	\N	1270	5	\N	1
1356	1966-07-20	\N	\N	f	\N	\N	1	\N	121	\N	1271	5	\N	1
1357	1967-01-16	\N	\N	f	\N	\N	1	\N	123	\N	1273	5	\N	1
1358	1967-01-17	\N	\N	f	\N	\N	1	\N	123	\N	1274	5	\N	1
1359	1967-01-18	\N	\N	f	\N	\N	1	\N	123	\N	1275	5	\N	1
1363	1967-07-11	\N	\N	f	\N	\N	1	\N	124	\N	1280	5	\N	1
1364	1967-08-25	\N	\N	f	\N	\N	1	\N	125	\N	1281	5	\N	1
1365	1967-08-26	\N	\N	f	\N	\N	1	\N	125	\N	1282	5	\N	1
1366	1967-08-30	\N	\N	f	\N	\N	1	\N	125	\N	1284	5	\N	1
1367	1967-09-11	\N	\N	f	\N	\N	1	\N	125	\N	1285	5	\N	1
1368	1967-09-12	\N	\N	f	\N	\N	1	\N	125	\N	1286	5	\N	1
1370	1967-09-18	\N	\N	f	\N	\N	1	\N	125	\N	1289	5	\N	1
1371	1967-09-19	\N	\N	f	\N	\N	1	\N	125	\N	1290	5	\N	1
1373	1967-09-21	\N	\N	f	\N	\N	1	\N	125	\N	1292	5	\N	1
1374	1967-09-22	\N	\N	f	\N	\N	1	\N	125	\N	1293	5	\N	1
1376	1967-11-20	\N	\N	f	\N	\N	1	\N	125	\N	1295	5	\N	1
1379	1967-11-27	\N	\N	f	\N	\N	1	\N	\N	\N	1298	5	\N	1
1381	1968-01-22	\N	\N	f	\N	\N	1	\N	128	\N	1300	5	\N	1
1383	1968-02-12	\N	\N	f	\N	\N	1	\N	128	\N	1302	5	\N	1
1384	1968-05-21	\N	\N	f	\N	\N	1	\N	129	\N	1303	5	\N	1
1385	1968-06-20	\N	\N	f	\N	\N	1	\N	130	\N	1304	5	\N	1
1386	1968-06-21	\N	\N	f	\N	\N	1	\N	130	\N	1305	5	\N	1
1303	1985-02-07	\N	\N	f	\N	\N	1	\N	202	\N	1219	5	\N	1
1393	1967-08-29	\N	\N	f	\N	\N	1	\N	125	\N	1283	5	\N	1
1418	1967-12-06	\N	\N	f	\N	\N	1	\N	127	\N	1336	5	\N	1
1419	1968-01-18	\N	\N	f	\N	\N	1	\N	128	\N	1337	5	\N	1
1390	1968-09-17	\N	\N	f	\N	\N	1	\N	132	\N	1309	5	\N	1
1391	1968-09-30	\N	\N	f	\N	\N	1	\N	131	\N	1310	5	\N	1
1396	1969-01-27	\N	\N	f	\N	\N	1	\N	133	\N	1312	5	\N	1
1397	1969-02-21	\N	\N	f	\N	\N	1	\N	133	\N	1313	5	\N	1
1400	1969-07-03	\N	\N	f	\N	\N	1	\N	135	\N	1316	5	\N	1
1401	1969-07-24	\N	\N	f	\N	\N	1	\N	135	\N	1317	5	\N	1
1402	1970-01-16	\N	\N	f	\N	\N	1	\N	136	\N	1318	5	\N	1
1403	1970-01-23	\N	\N	f	\N	\N	1	\N	136	\N	1319	5	\N	1
1404	1970-02-05	\N	\N	f	\N	\N	1	\N	136	\N	1320	5	\N	1
1405	1970-06-19	\N	\N	f	\N	\N	1	\N	137	\N	1322	5	\N	1
1406	1970-06-20	\N	\N	f	\N	\N	1	\N	137	\N	1323	5	\N	1
1433	1970-07-01	\N	\N	f	Tweedsmuir	Lady	1	\N	137	\N	1325	5	\N	1
1408	1970-07-02	\N	\N	f	\N	\N	1	\N	137	\N	1326	5	\N	1
1409	1970-07-03	\N	\N	f	\N	\N	1	\N	137	\N	1327	5	\N	1
1410	1970-07-04	\N	\N	f	\N	\N	1	\N	137	\N	1328	5	\N	1
1411	1970-07-06	\N	\N	f	\N	\N	1	\N	138	\N	1329	5	\N	1
1412	1970-07-07	\N	\N	f	\N	\N	1	\N	137	\N	1330	5	\N	1
1413	1970-07-08	\N	\N	f	\N	\N	1	\N	137	\N	1331	5	\N	1
1416	1970-07-31	\N	\N	f	\N	\N	1	\N	138	\N	1334	5	\N	1
1455	1970-09-25	\N	\N	f	\N	\N	1	\N	140	\N	1377	5	\N	1
1434	1970-10-12	\N	\N	f	\N	\N	1	\N	140	\N	1338	5	\N	1
1431	1970-11-05	\N	\N	f	\N	\N	1	\N	140	\N	1340	5	\N	1
1420	1970-11-06	\N	\N	f	\N	\N	1	\N	140	\N	1341	5	\N	1
1421	1971-01-29	\N	\N	f	\N	\N	1	\N	141	\N	1342	5	\N	1
1424	1971-03-02	\N	\N	f	\N	\N	1	\N	142	\N	1345	5	\N	1
1425	1971-03-05	\N	\N	f	\N	\N	1	\N	138	\N	1346	5	\N	1
1426	1971-03-12	\N	\N	f	\N	\N	1	\N	144	\N	1347	5	\N	1
1427	1971-04-20	\N	\N	f	\N	\N	1	\N	143	\N	1348	5	\N	1
1430	1971-05-17	\N	\N	f	\N	\N	1	\N	145	\N	1351	5	\N	1
1473	1971-05-18	\N	\N	f	\N	\N	1	\N	145	\N	1352	5	\N	1
1475	1971-05-24	\N	\N	f	\N	\N	1	\N	145	\N	1354	5	\N	1
1470	1971-06-04	\N	\N	f	\N	\N	1	\N	145	\N	1355	5	\N	1
1436	1971-06-18	\N	\N	f	\N	\N	1	\N	145	\N	1356	5	\N	1
1437	1971-07-20	\N	\N	f	\N	\N	1	\N	146	\N	1357	5	\N	1
1438	1971-10-04	\N	\N	f	\N	\N	1	\N	147	\N	1358	5	\N	1
1439	1972-01-10	\N	\N	f	\N	\N	1	\N	148	\N	1359	5	\N	1
1443	1972-04-28	\N	\N	f	\N	\N	1	\N	149	\N	1363	5	\N	1
1444	1972-05-01	\N	\N	f	\N	\N	1	\N	149	\N	1364	5	\N	1
1445	1972-05-09	\N	\N	f	\N	\N	1	\N	149	\N	1366	5	\N	1
1446	1972-05-10	\N	\N	f	\N	\N	1	\N	149	\N	1367	5	\N	1
1447	1972-07-03	\N	\N	f	\N	\N	1	\N	150	\N	1368	5	\N	1
1448	1973-02-05	\N	\N	f	\N	\N	1	\N	151	\N	1369	5	\N	1
1449	1973-03-14	\N	\N	f	\N	\N	1	\N	152	\N	1370	5	\N	1
1450	1973-06-22	\N	\N	f	\N	\N	1	\N	153	\N	1372	5	\N	1
1452	1973-07-06	\N	\N	f	\N	\N	1	\N	153	\N	1374	5	\N	1
1453	1973-07-09	\N	\N	f	\N	\N	1	\N	153	\N	1375	5	\N	1
1454	1973-07-16	\N	\N	f	\N	\N	1	\N	153	\N	1376	5	\N	1
1495	1974-03-06	\N	\N	f	\N	\N	1	\N	154	\N	1416	5	\N	1
1496	1974-03-07	\N	\N	f	\N	\N	1	\N	154	\N	1417	5	\N	1
1458	1974-03-26	\N	\N	f	\N	\N	1	\N	157	\N	1380	5	\N	1
1459	1974-05-02	\N	\N	f	\N	\N	1	\N	159	\N	1381	5	\N	1
1460	1974-05-03	\N	\N	f	\N	\N	1	\N	159	\N	1382	5	\N	1
1462	1974-05-08	\N	\N	f	\N	\N	1	\N	159	\N	1384	5	\N	1
1463	1974-05-09	\N	\N	f	\N	\N	1	\N	159	\N	1385	5	\N	1
1464	1974-05-10	\N	\N	f	\N	\N	1	\N	160	\N	1386	5	\N	1
1471	1974-05-15	\N	\N	f	\N	\N	1	\N	159	\N	1389	5	\N	1
1465	1974-05-16	\N	\N	f	\N	\N	1	\N	160	\N	1390	5	\N	1
1466	1974-06-11	\N	\N	f	\N	\N	1	\N	159	\N	1391	5	\N	1
1467	1974-06-18	\N	\N	f	\N	\N	1	\N	161	\N	1392	5	\N	1
1468	1974-06-19	\N	\N	f	\N	\N	1	\N	161	\N	1393	5	\N	1
1477	1974-06-21	\N	\N	f	\N	\N	1	\N	161	\N	1395	5	\N	1
1512	1974-06-25	\N	\N	f	\N	\N	1	\N	161	\N	1397	5	\N	1
1479	1974-06-26	\N	\N	f	\N	\N	1	\N	161	\N	1398	5	\N	1
1480	1974-06-27	\N	\N	f	\N	\N	1	\N	161	\N	1399	5	\N	1
1481	1974-06-28	\N	\N	f	\N	\N	1	\N	161	\N	1400	5	\N	1
1482	1974-07-01	\N	\N	f	\N	\N	1	\N	161	\N	1401	5	\N	1
1511	1974-07-02	\N	\N	f	\N	\N	1	\N	161	\N	1402	5	\N	1
1483	1974-07-03	\N	\N	f	\N	\N	1	\N	161	\N	1403	5	\N	1
1486	1974-07-09	\N	\N	f	\N	\N	1	\N	162	\N	1406	5	\N	1
1488	1974-07-12	\N	\N	f	\N	\N	1	\N	162	\N	1409	5	\N	1
1489	1974-10-01	\N	\N	f	\N	\N	1	\N	163	\N	1410	5	\N	1
1490	1974-11-18	\N	\N	f	\N	\N	1	\N	158	\N	1411	5	\N	1
1491	1975-01-02	\N	\N	f	\N	\N	1	\N	166	\N	1412	5	\N	1
1492	1975-01-03	\N	\N	f	\N	\N	1	\N	166	\N	1413	5	\N	1
1494	1975-01-07	\N	\N	f	\N	\N	1	\N	166	\N	1415	5	\N	1
1498	1975-01-14	\N	\N	f	\N	\N	1	\N	166	\N	1419	5	\N	1
1499	1975-01-16	\N	\N	f	\N	\N	1	\N	166	\N	1421	5	\N	1
1500	1975-01-17	\N	\N	f	\N	\N	1	\N	166	\N	1422	5	\N	1
1501	1975-01-20	\N	\N	f	\N	\N	1	\N	166	\N	1423	5	\N	1
1503	1975-01-22	\N	\N	f	\N	\N	1	\N	166	\N	1425	5	\N	1
1514	1975-01-27	\N	\N	f	\N	\N	1	\N	166	\N	1428	5	\N	1
1505	1975-01-28	\N	\N	f	\N	\N	1	\N	167	\N	1429	5	\N	1
1506	1975-01-29	\N	\N	f	\N	\N	1	\N	167	\N	1430	5	\N	1
1507	1975-01-30	\N	\N	f	\N	\N	1	\N	167	\N	1431	5	\N	1
1509	1975-07-10	\N	\N	f	\N	\N	1	\N	168	\N	1433	5	\N	1
1510	1975-07-11	\N	\N	f	\N	\N	1	\N	168	\N	1434	5	\N	1
1515	1975-07-14	\N	\N	f	\N	\N	1	\N	168	\N	1435	5	\N	1
1518	1975-07-17	\N	\N	f	\N	\N	1	\N	168	\N	1438	5	\N	1
1519	1975-09-30	\N	\N	f	\N	\N	1	\N	169	\N	1439	5	\N	1
1520	1976-01-14	\N	\N	f	\N	\N	1	\N	170	\N	1440	5	\N	1
1521	1976-01-15	\N	\N	f	\N	\N	1	\N	170	\N	1441	5	\N	1
1522	1976-01-16	\N	\N	f	\N	\N	1	\N	170	\N	1442	5	\N	1
1422	1991-06-07	\N	\N	f	\N	\N	1	\N	222	\N	1343	5	\N	1
1394	1967-01-20	\N	\N	f	\N	\N	1	\N	123	\N	1276	5	\N	1
1587	1979-07-11	\N	\N	f	\N	\N	2	\N	186	3	1513	5	\N	1
1537	1975-01-13	\N	\N	f	\N	\N	1	\N	165	\N	1458	5	\N	1
1588	1979-07-12	\N	\N	f	\N	\N	1	\N	186	2	1514	5	\N	1
1525	1976-01-21	\N	\N	f	\N	\N	1	\N	170	\N	1445	5	\N	1
1526	1976-01-22	\N	\N	f	\N	\N	1	\N	170	\N	1446	5	\N	1
1529	1976-01-29	\N	\N	f	\N	\N	1	\N	171	\N	1450	5	\N	1
1530	1976-01-30	\N	\N	f	\N	\N	1	\N	171	\N	1451	5	\N	1
1532	1976-02-05	\N	\N	f	\N	\N	1	\N	171	\N	1453	5	\N	1
1533	1976-03-08	\N	\N	f	\N	\N	1	\N	172	\N	1454	5	\N	1
1534	1976-06-22	\N	\N	f	\N	\N	1	\N	173	\N	1455	5	\N	1
1535	1976-06-23	\N	\N	f	\N	\N	1	\N	173	\N	1456	5	\N	1
1572	1976-06-29	\N	\N	f	\N	\N	1	\N	173	\N	1496	5	\N	1
1573	1976-06-30	\N	\N	f	\N	\N	1	\N	173	\N	1497	5	\N	1
1574	1976-07-01	\N	\N	f	\N	\N	1	\N	173	\N	1498	5	\N	1
1538	1976-07-02	\N	\N	f	\N	\N	1	\N	174	\N	1459	5	\N	1
1540	1976-07-19	\N	\N	f	\N	\N	1	\N	174	\N	1461	5	\N	1
1541	1976-08-02	\N	\N	f	\N	\N	1	\N	173	\N	1462	5	\N	1
1554	1976-10-18	\N	\N	f	\N	\N	1	\N	174	\N	1464	5	\N	1
1544	1977-01-28	\N	\N	f	\N	\N	1	\N	177	\N	1466	5	\N	1
1545	1977-02-01	\N	\N	f	\N	\N	1	\N	177	\N	1467	5	\N	1
1546	1977-02-07	\N	\N	f	\N	\N	1	\N	177	\N	1468	5	\N	1
1547	1977-02-08	\N	\N	f	\N	\N	1	\N	177	\N	1469	5	\N	1
1548	1977-03-23	\N	\N	f	\N	\N	1	\N	177	\N	1470	5	\N	1
1551	1977-07-19	\N	\N	f	\N	\N	1	\N	178	\N	1473	5	\N	1
1552	1977-07-20	\N	\N	f	\N	\N	1	\N	178	\N	1474	5	\N	1
1553	1977-07-22	\N	\N	f	\N	\N	1	\N	178	\N	1475	5	\N	1
1556	1977-09-30	\N	\N	f	\N	\N	1	\N	\N	\N	1477	5	\N	1
1555	1978-02-08	\N	\N	f	\N	\N	1	\N	179	\N	1476	5	\N	1
1593	1978-02-27	\N	\N	f	\N	\N	1	\N	179	\N	1479	5	\N	1
1558	1978-03-20	\N	\N	f	\N	\N	1	\N	179	\N	1480	5	\N	1
1559	1978-04-14	\N	\N	f	\N	\N	1	\N	180	\N	1481	5	\N	1
1561	1978-04-19	\N	\N	f	\N	\N	1	\N	180	\N	1483	5	\N	1
1563	1978-04-24	\N	\N	f	\N	\N	1	\N	180	\N	1485	5	\N	1
1564	1978-04-26	\N	\N	f	\N	\N	1	\N	180	\N	1486	5	\N	1
1565	1978-05-02	\N	\N	f	\N	\N	1	\N	180	\N	1488	5	\N	1
1566	1978-05-03	\N	\N	f	\N	\N	1	\N	180	\N	1489	5	\N	1
1567	1978-05-04	\N	\N	f	\N	\N	1	\N	180	\N	1490	5	\N	1
1569	1978-05-09	\N	\N	f	\N	\N	1	\N	180	\N	1492	5	\N	1
1570	1978-05-10	\N	\N	f	\N	\N	1	\N	180	\N	1493	5	\N	1
1591	1978-07-10	\N	\N	f	\N	\N	1	\N	181	\N	1495	5	\N	1
1610	1978-07-18	\N	\N	f	\N	\N	1	\N	181	\N	1536	5	\N	1
1611	1978-07-21	\N	\N	f	\N	\N	1	\N	181	\N	1537	5	\N	1
1594	1979-01-31	\N	\N	f	\N	\N	1	\N	181	\N	1499	5	\N	1
1576	1979-02-05	\N	\N	f	\N	\N	1	\N	182	\N	1501	5	\N	1
1577	1979-02-07	\N	\N	f	\N	\N	1	\N	182	\N	1502	5	\N	1
1578	1979-02-19	\N	\N	f	\N	\N	1	\N	182	\N	1503	5	\N	1
1579	1979-02-20	\N	\N	f	\N	\N	1	\N	182	\N	1504	5	\N	1
1580	1979-05-21	\N	\N	f	\N	\N	1	\N	183	\N	1505	5	\N	1
1582	1979-07-05	\N	\N	f	\N	\N	1	\N	185	\N	1507	5	\N	1
1584	1979-07-09	\N	\N	f	\N	\N	1	\N	185	\N	1509	5	\N	1
1592	1979-07-11	\N	\N	f	\N	\N	1	\N	185	2	1512	5	\N	1
1595	1979-07-17	\N	\N	f	\N	\N	1	\N	185	\N	1517	5	\N	1
1596	1979-07-19	\N	\N	f	\N	\N	1	\N	186	\N	1518	5	\N	1
1597	1979-07-24	\N	\N	f	\N	\N	1	\N	185	\N	1519	5	\N	1
1598	1979-07-25	\N	\N	f	\N	\N	1	\N	186	\N	1520	5	\N	1
1630	1979-07-30	\N	\N	f	\N	\N	1	\N	186	\N	1521	5	\N	1
1600	1979-09-07	\N	\N	f	\N	\N	1	\N	186	\N	1524	5	\N	1
1602	1979-09-28	\N	\N	f	\N	\N	1	\N	\N	\N	1527	5	\N	1
1603	1980-01-28	\N	\N	f	\N	\N	1	\N	184	\N	1528	5	\N	1
1633	1980-02-04	\N	\N	f	\N	\N	1	\N	187	\N	1529	5	\N	1
1604	1980-02-06	\N	\N	f	\N	\N	1	\N	187	\N	1530	5	\N	1
1605	1980-02-08	\N	\N	f	\N	\N	1	\N	187	\N	1531	5	\N	1
1606	1980-02-11	\N	\N	f	\N	\N	1	\N	187	\N	1532	5	\N	1
1609	1980-04-15	\N	\N	f	\N	\N	1	\N	\N	\N	1535	5	\N	1
1648	1980-07-11	\N	\N	f	\N	\N	1	\N	188	\N	1574	5	\N	1
1649	1980-07-17	\N	\N	f	\N	\N	1	\N	188	\N	1575	5	\N	1
1650	1980-09-01	\N	\N	f	\N	\N	1	\N	188	\N	1576	5	\N	1
1613	1980-09-29	\N	\N	f	\N	\N	1	\N	\N	\N	1539	5	\N	1
1615	1981-05-11	\N	\N	f	\N	\N	1	\N	190	\N	1541	5	\N	1
1616	1981-05-14	\N	\N	f	\N	\N	1	\N	190	\N	1542	5	\N	1
1629	1981-05-19	\N	\N	f	\N	\N	1	\N	190	\N	1543	5	\N	1
1628	1981-05-22	\N	\N	f	\N	\N	1	\N	190	\N	1545	5	\N	1
1618	1981-05-26	\N	\N	f	\N	\N	1	\N	190	\N	1546	5	\N	1
1619	1981-05-27	\N	\N	f	\N	\N	1	\N	190	\N	1547	5	\N	1
1631	1981-05-28	\N	\N	f	\N	\N	1	\N	190	\N	1548	5	\N	1
1620	1981-05-29	\N	\N	f	\N	\N	1	\N	190	\N	1549	5	\N	1
1622	1981-06-16	\N	\N	f	\N	\N	1	\N	190	\N	1551	5	\N	1
1624	1981-07-15	\N	\N	f	\N	\N	1	\N	191	\N	1553	5	\N	1
1626	1981-09-22	\N	\N	f	\N	\N	1	\N	191	\N	1555	5	\N	1
1635	1981-09-24	\N	\N	f	\N	\N	1	\N	\N	\N	1558	5	\N	1
1627	1982-02-02	\N	\N	f	\N	\N	1	\N	192	\N	1556	5	\N	1
1634	1982-02-08	\N	\N	f	\N	\N	1	\N	192	\N	1557	5	\N	1
1636	1982-02-10	\N	\N	f	\N	\N	1	\N	192	\N	1559	5	\N	1
1637	1982-03-12	\N	\N	f	\N	\N	1	\N	193	\N	1560	5	\N	1
1639	1982-07-16	\N	\N	f	\N	\N	1	\N	194	\N	1563	5	\N	1
1642	1982-11-19	\N	\N	f	\N	\N	1	\N	196	\N	1566	5	\N	1
1643	1983-01-17	\N	\N	f	\N	\N	1	\N	197	\N	1567	5	\N	1
1644	1983-01-27	\N	\N	f	\N	\N	1	\N	197	\N	1570	5	\N	1
1645	1983-01-31	\N	\N	f	\N	\N	1	\N	197	\N	1571	5	\N	1
1646	1983-02-02	\N	\N	f	\N	\N	1	\N	198	\N	1572	5	\N	1
1647	1983-02-03	\N	\N	f	\N	\N	1	\N	198	\N	1573	5	\N	1
1652	1983-06-30	\N	\N	f	\N	\N	1	\N	199	\N	1578	5	\N	1
1654	1983-07-01	\N	\N	f	\N	\N	1	\N	199	\N	1580	5	\N	1
1656	1983-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	1582	5	\N	1
1658	1983-09-05	\N	\N	f	\N	\N	1	\N	199	\N	1584	5	\N	1
1659	1983-09-07	\N	\N	f	\N	\N	1	\N	200	\N	1585	5	\N	1
1660	1983-09-09	\N	\N	f	\N	\N	1	\N	200	\N	1586	5	\N	1
1590	1979-07-16	\N	\N	f	\N	\N	1	\N	185	\N	1516	5	\N	1
1795	1992-04-27	\N	\N	f	\N	\N	1	\N	227	2	1724	5	\N	1
1671	1983-01-24	\N	\N	f	\N	\N	1	\N	197	\N	1569	5	\N	1
1687	1983-02-09	\N	\N	f	\N	\N	1	\N	197	\N	1612	5	\N	1
1688	1983-02-10	\N	\N	f	\N	\N	1	\N	197	\N	1613	5	\N	1
1689	1983-03-14	\N	\N	f	\N	\N	1	\N	198	\N	1614	5	\N	1
1663	1983-09-16	\N	\N	f	\N	\N	1	\N	200	\N	1589	5	\N	1
1664	1983-09-21	\N	\N	f	\N	\N	1	\N	200	\N	1590	5	\N	1
1665	1983-09-23	\N	\N	f	\N	\N	1	\N	200	\N	1591	5	\N	1
1668	1983-09-30	\N	\N	f	\N	\N	1	\N	200	\N	1594	5	\N	1
1669	1983-10-03	\N	\N	f	\N	\N	1	\N	200	\N	1595	5	\N	1
1670	1983-10-05	\N	\N	f	\N	\N	1	\N	200	\N	1596	5	\N	1
1674	1983-10-12	\N	\N	f	\N	\N	1	\N	200	\N	1598	5	\N	1
1675	1983-10-14	\N	\N	f	\N	\N	1	\N	200	\N	1599	5	\N	1
1676	1984-01-30	\N	\N	f	\N	\N	1	\N	201	\N	1600	5	\N	1
1677	1984-01-31	\N	\N	f	\N	\N	1	\N	201	\N	1601	5	\N	1
1678	1984-02-02	\N	\N	f	\N	\N	1	\N	201	\N	1602	5	\N	1
1709	1984-02-24	\N	\N	f	\N	\N	1	\N	\N	\N	1636	5	\N	1
1711	1985-02-06	\N	\N	f	\N	\N	1	\N	202	\N	1606	5	\N	1
1683	1985-05-09	\N	\N	f	\N	\N	1	\N	203	\N	1608	5	\N	1
1684	1985-05-13	\N	\N	f	\N	\N	1	\N	203	\N	1609	5	\N	1
1685	1985-05-15	\N	\N	f	\N	\N	1	\N	203	\N	1610	5	\N	1
1686	1985-05-16	\N	\N	f	\N	\N	1	\N	203	\N	1611	5	\N	1
1726	1985-05-21	\N	\N	f	\N	\N	1	\N	203	\N	1652	5	\N	1
1727	1985-05-23	\N	\N	f	\N	\N	1	\N	\N	\N	1654	5	\N	1
1749	1985-05-29	\N	\N	f	\N	\N	1	\N	203	\N	1653	5	\N	1
1690	1985-05-30	\N	\N	f	\N	\N	1	\N	203	\N	1615	5	\N	1
1692	1985-06-13	\N	\N	f	\N	\N	1	\N	203	\N	1618	5	\N	1
1694	1985-07-22	\N	\N	f	\N	\N	1	\N	204	\N	1620	5	\N	1
1696	1986-01-30	\N	\N	f	\N	\N	1	\N	\N	\N	1622	5	\N	1
1697	1986-01-31	\N	\N	f	\N	\N	1	\N	\N	\N	1623	5	\N	1
1698	1986-02-06	\N	\N	f	\N	\N	1	\N	\N	\N	1624	5	\N	1
1695	1986-02-14	\N	\N	f	\N	\N	1	\N	205	\N	1621	5	\N	1
1699	1986-07-21	\N	\N	f	\N	\N	1	\N	206	\N	1625	5	\N	1
1700	1986-07-22	\N	\N	f	\N	\N	1	\N	206	\N	1626	5	\N	1
1701	1986-09-23	\N	\N	f	\N	\N	1	\N	206	\N	1627	5	\N	1
1704	1987-03-23	\N	\N	f	\N	\N	1	\N	208	\N	1631	5	\N	1
1705	1987-03-24	\N	\N	f	\N	\N	1	\N	208	\N	1632	5	\N	1
1707	1987-03-27	\N	\N	f	\N	\N	1	\N	208	\N	1634	5	\N	1
1708	1987-03-31	\N	\N	f	\N	\N	1	\N	208	\N	1635	5	\N	1
1712	1987-04-03	\N	\N	f	\N	\N	1	\N	208	\N	1637	5	\N	1
1713	1987-04-06	\N	\N	f	\N	\N	1	\N	208	\N	1638	5	\N	1
1714	1987-04-08	\N	\N	f	\N	\N	1	\N	208	\N	1640	5	\N	1
1716	1987-07-22	\N	\N	f	\N	\N	1	\N	209	\N	1642	5	\N	1
1717	1987-10-06	\N	\N	f	\N	\N	1	\N	211	\N	1643	5	\N	1
1718	1987-10-07	\N	\N	f	\N	\N	1	\N	211	\N	1644	5	\N	1
1720	1987-10-09	\N	\N	f	\N	\N	1	\N	211	\N	1646	5	\N	1
1721	1987-10-12	\N	\N	f	\N	\N	1	\N	211	\N	1647	5	\N	1
1723	1987-10-14	\N	\N	f	\N	\N	1	\N	211	\N	1649	5	\N	1
1724	1987-10-15	\N	\N	f	\N	\N	1	\N	211	\N	1650	5	\N	1
1725	1987-10-16	\N	\N	f	\N	\N	1	\N	211	\N	1651	5	\N	1
1760	1987-10-20	\N	\N	f	\N	\N	1	\N	211	\N	1690	5	\N	1
1761	1987-11-02	\N	\N	f	\N	\N	1	\N	211	\N	1691	5	\N	1
1762	1987-11-04	\N	\N	f	\N	\N	1	\N	211	\N	1692	5	\N	1
1747	1988-02-08	\N	\N	f	\N	\N	1	\N	210	\N	1658	5	\N	1
1731	1988-02-15	\N	\N	f	\N	\N	1	\N	212	\N	1659	5	\N	1
1732	1988-02-26	\N	\N	f	\N	\N	1	\N	212	\N	1660	5	\N	1
1733	1988-07-11	\N	\N	f	\N	\N	1	\N	213	\N	1661	5	\N	1
1734	1988-08-08	\N	\N	f	\N	\N	1	\N	213	\N	1662	5	\N	1
1735	1988-08-10	\N	\N	f	\N	\N	1	\N	213	\N	1663	5	\N	1
1736	1988-10-18	\N	\N	f	\N	\N	1	\N	213	\N	1664	5	\N	1
1738	1989-01-31	\N	\N	f	\N	\N	1	\N	215	\N	1666	5	\N	1
1748	1989-02-09	\N	\N	f	\N	\N	1	\N	215	\N	1668	5	\N	1
1742	1989-02-10	\N	\N	f	\N	\N	1	\N	\N	\N	1671	5	\N	1
1740	1989-07-21	\N	\N	f	\N	\N	1	\N	216	\N	1669	5	\N	1
1741	1989-07-24	\N	\N	f	\N	\N	1	\N	216	\N	1670	5	\N	1
1744	1990-02-26	\N	\N	f	\N	\N	1	\N	217	\N	1673	5	\N	1
1745	1990-02-28	\N	\N	f	\N	\N	1	\N	217	\N	1675	5	\N	1
1751	1990-05-09	\N	\N	f	\N	\N	1	\N	218	\N	1677	5	\N	1
1780	1990-05-10	\N	\N	f	\N	\N	1	\N	218	\N	1678	5	\N	1
1752	1990-05-14	\N	\N	f	\N	\N	1	\N	218	\N	1679	5	\N	1
1754	1990-05-17	\N	\N	f	\N	\N	1	\N	218	\N	1681	5	\N	1
1755	1990-05-22	\N	\N	f	\N	\N	1	\N	218	\N	1683	5	\N	1
1757	1990-05-30	\N	\N	f	\N	\N	1	\N	218	\N	1685	5	\N	1
1758	1990-06-18	\N	\N	f	\N	\N	1	\N	218	\N	1688	5	\N	1
1763	1990-12-04	\N	\N	f	\N	\N	1	\N	\N	\N	1693	5	\N	1
1764	1991-01-25	\N	\N	f	\N	\N	1	\N	220	\N	1694	5	\N	1
1765	1991-02-01	\N	\N	f	\N	\N	1	\N	219	\N	1695	5	\N	1
1766	1991-02-04	\N	\N	f	\N	\N	1	\N	220	\N	1696	5	\N	1
1767	1991-02-05	\N	\N	f	\N	\N	1	\N	220	\N	1697	5	\N	1
1788	1991-02-14	\N	\N	f	\N	\N	1	\N	220	\N	1699	5	\N	1
1782	1991-06-06	\N	\N	f	\N	\N	1	\N	222	\N	1702	5	\N	1
1771	1991-06-10	\N	\N	f	\N	\N	1	\N	222	\N	1703	5	\N	1
1783	1991-06-14	\N	\N	f	\N	\N	1	\N	222	\N	1705	5	\N	1
1785	1991-06-19	\N	\N	f	\N	\N	1	\N	222	\N	1706	5	\N	1
1786	1991-06-21	\N	\N	f	\N	\N	1	\N	222	\N	1707	5	\N	1
1772	1991-06-24	\N	\N	f	\N	\N	1	\N	222	\N	1708	5	\N	1
1773	1991-06-26	\N	\N	f	\N	\N	1	\N	222	\N	1709	5	\N	1
1775	1991-07-17	\N	\N	f	\N	\N	1	\N	223	\N	1712	5	\N	1
1776	1991-07-29	\N	\N	f	\N	\N	1	\N	223	\N	1713	5	\N	1
1777	1991-07-30	\N	\N	f	\N	\N	1	\N	224	\N	1714	5	\N	1
1778	1991-10-01	\N	\N	f	\N	\N	1	\N	225	\N	1715	5	\N	1
1779	1992-01-10	\N	\N	f	\N	\N	1	\N	225	\N	1716	5	\N	1
1789	1992-01-27	\N	\N	f	\N	\N	1	\N	226	\N	1717	5	\N	1
1791	1992-02-12	\N	\N	f	\N	\N	1	\N	226	\N	1719	5	\N	1
1792	1992-02-14	\N	\N	f	\N	\N	1	\N	226	\N	1720	5	\N	1
1797	1992-06-27	\N	\N	f	\N	\N	1	\N	232	\N	1727	5	\N	1
1796	1992-04-29	\N	\N	f	\N	\N	1	\N	229	\N	1725	5	\N	1
1672	1983-01-20	\N	\N	f	\N	\N	1	\N	197	\N	1568	5	\N	1
1879	1996-10-04	\N	\N	f	\N	\N	1	\N	253	\N	1812	5	\N	1
1887	1997-05-14	\N	\N	f	\N	\N	2	\N	257	3	1825	5	\N	1
1888	1997-05-16	\N	\N	f	\N	\N	1	\N	258	2	1826	5	\N	1
1891	1997-05-21	\N	\N	f	\N	\N	1	\N	\N	\N	1830	5	\N	1
1895	1997-06-06	\N	\N	f	\N	\N	2	\N	256	3	1834	5	\N	1
1896	1997-06-09	\N	\N	f	\N	\N	1	\N	256	2	1835	5	\N	1
1897	1997-06-09	\N	\N	f	\N	\N	2	\N	256	3	1836	5	\N	1
1898	1997-06-10	\N	\N	f	\N	\N	1	\N	256	2	1837	5	\N	1
1801	1990-08-13	\N	\N	f	\N	\N	1	\N	219	\N	1731	5	\N	1
1802	1991-01-17	\N	\N	f	\N	\N	1	\N	220	\N	1732	5	\N	1
1826	1992-06-26	\N	\N	f	\N	\N	1	\N	230	\N	1726	5	\N	1
1805	1992-07-07	\N	\N	f	\N	\N	1	\N	230	\N	1735	5	\N	1
1806	1992-07-08	\N	\N	f	\N	\N	1	\N	230	2	1736	5	\N	1
1899	1997-06-10	\N	\N	f	\N	\N	2	\N	256	3	1838	5	\N	1
1908	1997-06-11	\N	\N	f	\N	\N	2	\N	256	3	1840	5	\N	1
1809	1992-07-10	\N	\N	f	\N	\N	1	\N	230	\N	1739	5	\N	1
1810	1992-07-14	\N	\N	f	\N	\N	1	\N	232	\N	1740	5	\N	1
1812	1992-07-17	\N	\N	f	\N	\N	1	\N	230	\N	1742	5	\N	1
1814	1992-07-20	\N	\N	f	\N	\N	1	\N	232	\N	1744	5	\N	1
1815	1992-07-21	\N	\N	f	\N	\N	1	\N	232	\N	1745	5	\N	1
1816	1992-07-24	\N	\N	f	\N	\N	1	\N	232	\N	1746	5	\N	1
1817	1992-07-27	\N	\N	f	\N	\N	1	\N	232	\N	1747	5	\N	1
1825	1992-07-29	\N	\N	f	\N	\N	1	\N	232	\N	1749	5	\N	1
1819	1992-07-30	\N	\N	f	\N	\N	1	\N	232	\N	1750	5	\N	1
1820	1992-08-10	\N	\N	f	\N	\N	1	\N	231	\N	1751	5	\N	1
1823	1992-08-25	\N	\N	f	\N	\N	1	\N	230	\N	1754	5	\N	1
1824	1992-09-18	\N	\N	f	\N	\N	1	\N	230	\N	1755	5	\N	1
1865	1993-02-01	\N	\N	f	\N	\N	1	\N	234	\N	1756	5	\N	1
1827	1993-07-14	\N	\N	f	\N	\N	1	\N	235	\N	1757	5	\N	1
1828	1993-07-15	\N	\N	f	\N	\N	1	\N	235	\N	1758	5	\N	1
1804	1992-07-06	\N	\N	f	\N	\N	1	\N	230	\N	1734	5	\N	1
1829	1993-07-19	\N	\N	f	\N	\N	1	\N	235	\N	1759	5	\N	1
1831	1993-10-01	\N	\N	f	\N	\N	1	\N	236	\N	1761	5	\N	1
1860	1993-10-06	\N	\N	f	\N	\N	1	\N	237	\N	1764	5	\N	1
1834	1993-10-11	\N	\N	f	\N	\N	1	\N	237	\N	1765	5	\N	1
1835	1993-10-13	\N	\N	f	\N	\N	1	\N	237	\N	1767	5	\N	1
1862	1993-10-14	\N	\N	f	\N	\N	1	\N	237	\N	1768	5	\N	1
1874	1994-01-11	\N	\N	f	\N	\N	1	\N	236	\N	1807	5	\N	1
1807	1992-07-08	\N	\N	f	\N	\N	2	\N	230	3	1737	5	\N	1
1839	1994-07-14	\N	\N	f	\N	\N	1	\N	239	\N	1772	5	\N	1
1840	1994-09-06	\N	\N	f	\N	\N	1	\N	239	\N	1773	5	\N	1
1841	1994-09-26	\N	\N	f	\N	\N	1	\N	241	\N	1774	5	\N	1
1843	1994-09-28	\N	\N	f	\N	\N	1	\N	241	\N	1776	5	\N	1
1859	1994-09-29	\N	\N	f	\N	\N	1	\N	241	\N	1777	5	\N	1
1845	1994-10-03	\N	\N	f	\N	\N	1	\N	240	\N	1779	5	\N	1
1846	1994-10-04	\N	\N	f	\N	\N	1	\N	241	\N	1780	5	\N	1
1864	1994-10-06	\N	\N	f	\N	\N	1	\N	241	\N	1782	5	\N	1
1849	1995-01-11	\N	\N	f	\N	\N	1	\N	242	\N	1785	5	\N	1
1861	1995-02-03	\N	\N	f	\N	\N	1	\N	243	\N	1786	5	\N	1
1852	1995-07-24	\N	\N	f	\N	\N	1	\N	245	\N	1790	5	\N	1
1854	1995-08-25	\N	\N	f	\N	\N	1	\N	245	\N	1792	5	\N	1
1855	1995-09-08	\N	\N	f	\N	\N	1	\N	245	\N	1793	5	\N	1
1856	1995-12-13	\N	\N	f	\N	\N	1	\N	246	\N	1794	5	\N	1
1857	1995-12-18	\N	\N	f	\N	\N	1	\N	247	\N	1795	5	\N	1
1858	1995-12-19	\N	\N	f	\N	\N	1	\N	247	\N	1796	5	\N	1
1867	1995-12-21	\N	\N	f	\N	\N	1	\N	247	\N	1798	5	\N	1
1902	1996-01-02	\N	\N	f	\N	\N	1	\N	247	\N	1799	5	\N	1
1847	1994-10-07	\N	\N	f	\N	\N	1	\N	241	\N	1783	5	\N	1
1850	1995-02-10	\N	\N	f	\N	\N	1	\N	243	\N	1787	5	\N	1
1868	1996-01-10	\N	\N	f	\N	\N	1	\N	247	\N	1800	5	\N	1
1869	1996-01-12	\N	\N	f	\N	\N	1	\N	247	\N	1801	5	\N	1
1870	1996-01-15	\N	\N	f	\N	\N	1	\N	247	\N	1802	5	\N	1
1875	1996-02-05	\N	\N	f	\N	\N	1	\N	249	\N	1808	5	\N	1
1871	1996-02-16	\N	\N	f	\N	\N	1	\N	249	\N	1804	5	\N	1
1873	1996-06-04	\N	\N	f	\N	\N	1	\N	250	\N	1806	5	\N	1
1915	1996-09-03	\N	\N	f	\N	\N	1	\N	251	\N	1847	5	\N	1
1917	1996-09-30	\N	\N	f	\N	\N	1	\N	253	\N	1849	5	\N	1
1877	1996-10-01	\N	\N	f	\N	\N	2	\N	253	3	1810	5	\N	1
1905	1996-10-07	\N	\N	f	\N	\N	1	\N	253	\N	1813	5	\N	1
1880	1996-10-08	\N	\N	f	\N	\N	1	\N	253	\N	1814	5	\N	1
1904	1996-10-11	\N	\N	f	\N	\N	1	\N	253	\N	1816	5	\N	1
1900	1996-10-15	\N	\N	f	\N	\N	1	\N	253	\N	1818	5	\N	1
1910	1997-06-12	\N	\N	f	\N	\N	2	\N	256	3	1842	5	\N	1
1882	1996-10-17	\N	\N	f	\N	\N	1	\N	253	\N	1819	5	\N	1
1883	1996-10-18	\N	\N	f	\N	\N	1	\N	253	\N	1820	5	\N	1
1884	1996-10-21	\N	\N	f	\N	\N	1	\N	253	\N	1821	5	\N	1
1885	1997-02-18	\N	\N	f	\N	\N	1	\N	255	\N	1823	5	\N	1
1890	1997-06-03	\N	\N	f	\N	\N	1	\N	256	\N	1828	5	\N	1
1903	1997-06-04	\N	\N	f	\N	\N	1	\N	256	\N	1829	5	\N	1
1911	1997-06-13	\N	\N	f	\N	\N	1	\N	256	2	1843	5	\N	1
1912	1997-06-16	\N	\N	f	\N	\N	1	\N	256	\N	1844	5	\N	1
1919	1997-09-24	\N	\N	f	\N	\N	2	\N	261	3	1852	5	\N	1
1920	1997-09-25	\N	\N	f	\N	\N	1	\N	261	2	1853	5	\N	1
1893	1997-06-05	\N	\N	f	\N	\N	2	\N	256	3	1832	5	\N	1
1913	1997-06-17	\N	\N	f	\N	\N	1	\N	256	\N	1845	5	\N	1
1923	1997-09-26	\N	\N	f	\N	\N	2	\N	261	3	1856	5	\N	1
1925	1997-09-27	\N	\N	f	\N	\N	2	\N	261	3	1858	5	\N	1
1926	1997-09-29	\N	\N	f	\N	\N	1	\N	260	2	1859	5	\N	1
1927	1997-09-29	\N	\N	f	\N	\N	2	\N	260	3	1860	5	\N	1
1928	1997-10-01	\N	\N	f	\N	\N	2	\N	261	3	1863	5	\N	1
1929	1997-10-02	\N	\N	f	\N	\N	1	\N	261	2	1864	5	\N	1
1914	1997-07-18	\N	\N	f	\N	\N	1	\N	259	\N	1846	5	\N	1
1918	1997-09-23	\N	\N	f	\N	\N	1	\N	261	2	1850	5	\N	1
1931	1997-10-03	\N	\N	f	\N	\N	2	\N	261	3	1866	5	\N	1
1932	1997-10-04	\N	\N	f	\N	\N	1	\N	261	2	1867	5	\N	1
1800	1990-07-17	\N	\N	f	\N	\N	1	\N	219	\N	1730	5	\N	1
1808	1992-07-09	\N	\N	f	\N	\N	1	\N	230	\N	1738	5	\N	1
1837	1992-07-02	\N	\N	f	\N	\N	1	\N	230	\N	1770	5	\N	1
1939	1997-10-22	\N	\N	f	\N	\N	1	\N	261	2	1875	5	\N	1
1940	1997-10-22	\N	\N	f	\N	\N	2	\N	261	3	1876	5	\N	1
1942	1997-10-23	\N	\N	f	\N	\N	2	\N	261	3	1878	5	\N	1
1947	1997-10-25	\N	\N	f	\N	\N	1	\N	261	2	1881	5	\N	1
1945	1997-10-06	\N	\N	f	\N	\N	1	\N	261	2	1869	5	\N	1
1943	1997-09-30	\N	\N	f	\N	\N	2	\N	260	3	1862	5	\N	1
1948	1997-10-25	\N	\N	f	\N	\N	2	\N	261	3	1882	5	\N	1
1949	1997-10-27	\N	\N	f	\N	\N	1	\N	261	2	1883	5	\N	1
1951	1997-10-28	\N	\N	f	\N	\N	2	\N	260	3	1886	5	\N	1
2024	1997-10-30	\N	\N	f	\N	\N	2	\N	261	3	1929	5	\N	1
1953	1997-07-22	\N	\N	f	\N	\N	1	\N	259	\N	1888	5	\N	1
1956	1997-10-31	\N	\N	f	\N	\N	2	\N	260	3	1891	5	\N	1
1981	1997-11-01	\N	\N	f	\N	\N	2	\N	261	3	1892	5	\N	1
1982	1997-11-03	\N	\N	f	\N	\N	2	\N	261	3	1894	5	\N	1
1959	1997-11-05	\N	\N	f	\N	\N	1	\N	261	2	1897	5	\N	1
1963	1997-11-22	\N	\N	f	\N	\N	1	\N	256	\N	1901	5	\N	1
1970	1998-07-17	\N	\N	f	\N	\N	2	\N	265	3	1908	5	\N	1
1971	1998-07-18	\N	\N	f	\N	\N	1	\N	265	2	1909	5	\N	1
1972	1998-07-20	\N	\N	f	\N	\N	2	\N	264	3	1911	5	\N	1
1980	1998-07-21	\N	\N	f	\N	\N	1	\N	265	2	1912	5	\N	1
1978	1998-07-23	\N	\N	f	\N	\N	1	\N	265	2	1914	5	\N	1
1979	1998-07-24	\N	\N	f	\N	\N	2	\N	265	3	1917	5	\N	1
1954	1997-07-28	\N	\N	f	\N	\N	1	\N	285	\N	1889	5	\N	1
1944	1997-09-30	\N	\N	f	\N	\N	1	\N	261	2	1861	5	\N	1
2021	1998-07-28	\N	\N	f	\N	\N	1	\N	265	2	1921	5	\N	1
1977	1998-07-27	\N	\N	f	\N	\N	2	\N	265	3	1920	5	\N	1
1973	1998-07-21	\N	\N	f	\N	\N	2	\N	265	3	1913	5	\N	1
1957	1997-11-03	\N	\N	f	\N	\N	1	\N	261	2	1893	5	\N	1
1985	1997-11-04	\N	\N	f	\N	\N	1	\N	261	2	1895	5	\N	1
1974	1998-07-24	\N	\N	f	\N	\N	1	\N	265	2	1916	5	\N	1
1965	1997-11-28	\N	\N	f	\N	\N	1	\N	262	\N	1903	5	\N	1
1966	1998-02-12	\N	\N	f	\N	\N	1	\N	263	\N	1904	5	\N	1
1967	1998-02-13	\N	\N	f	\N	\N	1	\N	263	\N	1905	5	\N	1
1968	1998-02-23	\N	\N	f	\N	\N	1	\N	263	\N	1906	5	\N	1
1969	1998-07-17	\N	\N	f	\N	\N	1	\N	265	2	1907	5	\N	1
1986	1998-07-28	\N	\N	f	\N	\N	2	\N	265	3	1922	5	\N	1
1958	1997-11-04	\N	\N	f	\N	\N	2	\N	261	3	1896	5	\N	1
1988	1998-07-29	\N	\N	f	\N	\N	2	\N	265	3	1924	5	\N	1
1989	1998-07-30	\N	\N	f	\N	\N	2	\N	265	3	1925	5	\N	1
1990	1998-07-31	\N	\N	f	\N	\N	1	\N	265	2	1926	5	\N	1
2059	1998-08-01	\N	\N	f	\N	\N	2	\N	265	3	1968	5	\N	1
1994	1998-08-05	\N	\N	f	\N	\N	1	\N	265	\N	1932	5	\N	1
1998	1998-10-01	\N	\N	f	\N	\N	2	\N	\N	3	1936	5	\N	1
1995	1999-02-05	\N	\N	f	\N	\N	1	\N	267	\N	1933	5	\N	1
2005	1999-07-14	\N	\N	f	\N	\N	2	\N	270	3	1946	5	\N	1
2023	1999-07-15	\N	\N	f	\N	\N	1	\N	268	2	1947	5	\N	1
2007	1999-07-16	\N	\N	f	\N	\N	2	\N	270	3	1950	5	\N	1
2009	1999-07-20	\N	\N	f	\N	\N	1	\N	270	2	1952	5	\N	1
2011	1999-07-21	\N	\N	f	\N	\N	1	\N	270	2	1954	5	\N	1
2012	1999-07-22	\N	\N	f	\N	\N	1	\N	270	2	1955	5	\N	1
2013	1999-07-22	\N	\N	f	\N	\N	2	\N	270	3	1956	5	\N	1
2014	1999-07-23	\N	\N	f	\N	\N	1	\N	270	2	1957	5	\N	1
2015	1999-07-23	\N	\N	f	\N	\N	2	\N	270	3	1958	5	\N	1
2016	1999-07-26	\N	\N	f	\N	\N	1	\N	270	2	1959	5	\N	1
2020	1999-07-26	\N	\N	f	\N	\N	2	\N	270	3	1960	5	\N	1
1997	1998-10-01	\N	\N	f	\N	\N	1	\N	\N	2	1935	5	\N	1
1999	1999-02-10	\N	\N	f	\N	\N	1	\N	267	\N	1937	5	\N	1
2022	1999-02-25	\N	\N	f	\N	\N	1	\N	267	\N	1938	5	\N	1
2027	1999-07-27	\N	\N	f	\N	\N	2	\N	268	3	1962	5	\N	1
2033	1998-08-03	\N	\N	f	\N	\N	2	\N	265	3	1969	5	\N	1
2000	1999-03-01	\N	\N	f	\N	\N	1	\N	267	\N	1939	5	\N	1
2001	1999-03-02	\N	\N	f	\N	\N	1	\N	267	\N	1940	5	\N	1
2026	1999-07-10	\N	\N	f	\N	\N	1	\N	270	\N	1941	5	\N	1
2018	1999-07-15	\N	\N	f	\N	\N	2	\N	270	3	1948	5	\N	1
1955	1997-10-31	\N	\N	f	\N	\N	1	\N	260	2	1890	5	\N	1
2004	1999-07-14	\N	\N	f	\N	\N	1	\N	270	2	1945	5	\N	1
2028	1999-07-28	\N	\N	f	\N	\N	1	\N	270	2	1963	5	\N	1
2030	1999-07-29	\N	\N	f	\N	\N	1	\N	270	2	1965	5	\N	1
2031	1999-07-29	\N	\N	f	\N	\N	2	\N	270	3	1966	5	\N	1
1992	1998-08-04	\N	\N	f	\N	\N	1	\N	265	2	1930	5	\N	1
2053	1999-08-02	\N	\N	f	\N	\N	2	\N	270	3	1971	5	\N	1
2055	1999-08-04	\N	\N	f	\N	\N	1	\N	270	2	1974	5	\N	1
2037	1999-08-05	\N	\N	f	\N	\N	1	\N	270	2	1976	5	\N	1
2060	1999-08-05	\N	\N	f	\N	\N	2	\N	270	3	1977	5	\N	1
2047	2000-06-12	\N	\N	f	\N	\N	1	\N	274	\N	1989	5	\N	1
2040	2000-04-18	\N	\N	f	Redesdale	6th Lord	1	\N	274	3	1981	5	\N	1
2062	2000-05-02	\N	\N	f	\N	\N	2	\N	274	3	1997	5	\N	1
2057	1999-08-03	\N	\N	f	\N	\N	1	\N	270	2	1972	5	\N	1
2003	1999-07-13	\N	\N	f	\N	\N	1	\N	268	2	1943	5	\N	1
2036	1999-08-04	\N	\N	f	\N	\N	2	\N	270	3	1975	5	\N	1
2039	1999-08-24	\N	\N	f	\N	\N	1	\N	271	\N	1980	5	\N	1
2034	1999-08-02	\N	\N	f	\N	\N	1	\N	270	2	1970	5	\N	1
1938	1997-10-21	\N	\N	f	\N	\N	2	\N	261	3	1874	5	\N	1
2035	1999-08-03	\N	\N	f	\N	\N	2	\N	270	3	1973	5	\N	1
2046	2000-06-07	\N	\N	f	\N	\N	2	\N	274	3	1988	5	\N	1
2056	1999-08-06	\N	\N	f	\N	\N	2	\N	270	3	1979	5	\N	1
2065	2000-02-09	\N	\N	f	\N	\N	1	\N	273	\N	2003	5	\N	1
2066	2000-02-11	\N	\N	f	\N	\N	1	\N	273	\N	2005	5	\N	1
2045	2000-06-05	\N	\N	f	\N	\N	1	\N	274	\N	1986	5	\N	1
2044	2000-04-19	\N	\N	f	Ponsonby of Shulbrede	4th Lord	3	\N	274	5	1985	5	\N	1
1952	1997-07-21	\N	\N	f	\N	\N	1	\N	259	2	1887	5	\N	1
1936	1997-10-20	\N	\N	f	\N	\N	2	\N	260	3	1872	5	\N	1
2058	2000-06-07	\N	\N	f	\N	\N	1	\N	274	2	1987	5	\N	1
2048	2000-07-17	\N	\N	f	\N	\N	1	\N	275	\N	1990	5	\N	1
2049	2000-10-02	\N	\N	f	\N	\N	1	\N	276	\N	1991	5	\N	1
2050	2000-10-20	\N	\N	f	\N	\N	1	\N	274	\N	1992	5	\N	1
2054	2001-01-15	\N	\N	f	\N	\N	1	\N	277	\N	1993	5	\N	1
2096	2000-05-11	\N	\N	f	\N	\N	1	\N	274	2	2014	5	\N	1
2097	2000-05-15	\N	\N	f	\N	\N	1	\N	274	2	2018	5	\N	1
2077	2000-05-16	\N	\N	f	\N	\N	1	\N	274	2	2020	5	\N	1
2078	2000-05-16	\N	\N	f	\N	\N	2	\N	274	3	2021	5	\N	1
2084	2001-06-02	\N	\N	f	\N	\N	1	\N	278	\N	2029	5	\N	1
2081	2000-05-04	\N	\N	f	\N	\N	1	\N	274	2	2026	5	\N	1
2079	2000-05-01	\N	\N	f	\N	\N	2	\N	274	3	2023	5	\N	1
2083	2000-05-05	\N	\N	f	\N	\N	1	\N	274	2	2028	5	\N	1
2093	2000-05-09	\N	\N	f	\N	\N	1	\N	274	2	2010	5	\N	1
2089	1999-07-31	\N	\N	f	\N	\N	2	\N	270	3	2001	5	\N	1
2102	2001-06-27	\N	\N	f	\N	\N	2	\N	278	3	2039	5	\N	1
2080	2000-05-03	\N	\N	f	\N	\N	2	\N	274	3	2025	5	\N	1
2071	2000-05-10	\N	\N	f	\N	\N	1	\N	274	2	2012	5	\N	1
2074	2000-05-12	\N	\N	f	\N	\N	1	\N	274	2	2016	5	\N	1
2076	2000-05-15	\N	\N	f	\N	\N	2	\N	274	3	2019	5	\N	1
2095	2000-02-10	\N	\N	f	\N	\N	1	\N	273	\N	2004	5	\N	1
2138	2004-06-03	\N	\N	f	\N	\N	1	\N	295	2	2077	5	\N	1
2134	2001-06-29	\N	\N	f	\N	\N	1	\N	278	2	2042	5	\N	1
2105	2001-06-30	\N	\N	f	\N	\N	1	\N	278	\N	2044	5	\N	1
2085	2001-06-04	\N	\N	f	\N	\N	1	\N	278	\N	2030	5	\N	1
2086	2001-06-05	\N	\N	f	\N	\N	1	\N	278	\N	2031	5	\N	1
2087	2001-06-16	\N	\N	f	\N	\N	1	\N	280	\N	2032	5	\N	1
2094	2001-06-18	\N	\N	f	\N	\N	1	\N	278	\N	2033	5	\N	1
2137	2001-06-23	\N	\N	f	\N	\N	1	\N	278	\N	2075	5	\N	1
2108	2001-07-03	\N	\N	f	\N	\N	1	\N	280	2	2047	5	\N	1
2109	2001-07-03	\N	\N	f	\N	\N	2	\N	280	3	2048	5	\N	1
2110	2001-07-04	\N	\N	f	\N	\N	1	\N	280	2	2049	5	\N	1
2111	2001-07-04	\N	\N	f	\N	\N	2	\N	280	3	2050	5	\N	1
2088	2001-06-19	\N	\N	f	\N	\N	1	\N	278	\N	2034	5	\N	1
2068	2000-02-15	\N	\N	f	\N	\N	1	\N	273	\N	2007	5	\N	1
2114	2001-07-06	\N	\N	f	\N	\N	1	\N	280	\N	2053	5	\N	1
2104	2001-06-29	\N	\N	f	\N	\N	2	\N	278	3	2043	5	\N	1
2139	2004-06-03	\N	\N	f	\N	\N	2	\N	295	3	2078	5	\N	1
2101	2001-06-27	\N	\N	f	\N	\N	1	\N	286	2	2038	5	\N	1
2169	2001-06-25	\N	\N	f	\N	\N	1	\N	278	\N	2076	5	\N	1
2142	2004-06-07	\N	\N	f	\N	\N	1	\N	295	2	2081	5	\N	1
2106	2001-07-02	\N	\N	f	\N	\N	1	\N	280	2	2045	5	\N	1
2143	2004-06-07	\N	\N	f	\N	\N	2	\N	295	3	2082	5	\N	1
2144	2004-06-08	\N	\N	f	\N	\N	2	\N	295	3	2084	5	\N	1
2145	2004-06-09	\N	\N	f	\N	\N	1	\N	295	2	2085	5	\N	1
2146	2004-06-10	\N	\N	f	\N	\N	1	\N	295	2	2086	5	\N	1
2176	2004-06-10	\N	\N	f	\N	\N	2	\N	295	3	2087	5	\N	1
2173	2004-06-15	\N	\N	f	\N	\N	1	\N	295	2	2091	5	\N	1
2152	2004-06-18	\N	\N	f	\N	\N	1	\N	295	2	2097	5	\N	1
2115	2001-07-09	\N	\N	f	\N	\N	1	\N	280	\N	2054	5	\N	1
2116	2001-07-10	\N	\N	f	\N	\N	1	\N	280	\N	2055	5	\N	1
2117	2001-07-11	\N	\N	f	\N	\N	1	\N	280	\N	2056	5	\N	1
2119	2001-07-16	\N	\N	f	\N	\N	1	\N	280	\N	2059	5	\N	1
2120	2001-07-17	\N	\N	f	\N	\N	1	\N	280	\N	2060	5	\N	1
2121	2001-07-18	\N	\N	f	\N	\N	1	\N	278	\N	2061	5	\N	1
2122	2001-07-19	\N	\N	f	\N	\N	1	\N	280	\N	2062	5	\N	1
2124	2001-07-30	\N	\N	f	\N	\N	1	\N	280	\N	2065	5	\N	1
2125	2001-10-30	\N	\N	f	\N	\N	1	\N	287	\N	2066	5	\N	1
2127	2002-11-01	\N	\N	f	\N	\N	1	\N	289	\N	2068	5	\N	1
2128	2002-11-18	\N	\N	f	\N	\N	1	\N	290	\N	2069	5	\N	1
2129	2003-06-16	\N	\N	f	\N	\N	1	\N	291	\N	2070	5	\N	1
2130	2003-06-17	\N	\N	f	\N	\N	1	\N	292	\N	2071	5	\N	1
2131	2004-01-09	\N	\N	f	\N	\N	1	\N	293	\N	2072	5	\N	1
2132	2004-01-12	\N	\N	f	\N	\N	2	\N	294	3	2073	5	\N	1
2174	2004-06-11	\N	\N	f	\N	\N	1	\N	295	2	2088	5	\N	1
2153	2004-06-18	\N	\N	f	\N	\N	2	\N	295	3	2098	5	\N	1
2154	2004-06-21	\N	\N	f	\N	\N	1	\N	295	2	2099	5	\N	1
2171	2004-06-11	\N	\N	f	\N	\N	2	\N	295	3	2089	5	\N	1
2155	2004-06-21	\N	\N	f	\N	\N	2	\N	296	3	2100	5	\N	1
2100	2001-06-26	\N	\N	f	\N	\N	1	\N	278	\N	2037	5	\N	1
2166	2004-06-24	\N	\N	f	\N	\N	1	\N	296	2	2104	5	\N	1
2160	2004-06-28	\N	\N	f	\N	\N	2	\N	295	3	2109	5	\N	1
2161	2004-06-29	\N	\N	f	\N	\N	1	\N	296	2	2110	5	\N	1
2162	2004-06-29	\N	\N	f	\N	\N	2	\N	297	3	2111	5	\N	1
2167	2004-07-01	\N	\N	f	\N	\N	1	\N	296	2	2113	5	\N	1
2165	2005-01-11	\N	\N	f	\N	\N	1	\N	298	\N	2115	5	\N	1
2170	2004-06-24	\N	\N	f	\N	\N	2	\N	295	3	2105	5	\N	1
2164	2004-07-01	\N	\N	f	\N	\N	2	\N	295	3	2114	5	\N	1
2175	2004-06-25	\N	\N	f	\N	\N	2	\N	295	3	2107	5	\N	1
2151	2004-06-17	\N	\N	f	\N	\N	2	\N	295	3	2096	5	\N	1
2149	2004-06-16	\N	\N	f	\N	\N	1	\N	295	2	2093	5	\N	1
2159	2004-06-28	\N	\N	f	\N	\N	1	\N	295	2	2108	5	\N	1
2179	2005-05-17	\N	\N	f	\N	\N	1	\N	300	\N	2118	5	\N	1
2181	2005-06-14	\N	\N	f	\N	\N	2	\N	301	3	2123	5	\N	1
2182	2005-06-15	\N	\N	f	\N	\N	1	\N	301	2	2124	5	\N	1
2183	2005-06-15	\N	\N	f	\N	\N	2	\N	301	3	2125	5	\N	1
2184	2005-06-17	\N	\N	f	\N	\N	1	\N	301	2	2126	5	\N	1
2185	2005-06-17	\N	\N	f	\N	\N	2	\N	301	3	2127	5	\N	1
2187	2005-06-20	\N	\N	f	\N	\N	2	\N	301	3	2129	5	\N	1
2189	2005-06-22	\N	\N	f	\N	\N	2	\N	301	3	2133	5	\N	1
2190	2005-06-23	\N	\N	f	\N	\N	2	\N	301	3	2135	5	\N	1
2191	2005-06-24	\N	\N	f	\N	\N	2	\N	301	3	2137	5	\N	1
2192	2005-06-27	\N	\N	f	\N	\N	1	\N	301	2	2138	5	\N	1
2194	2005-06-28	\N	\N	f	\N	\N	1	\N	301	2	2140	5	\N	1
2195	2005-07-19	\N	\N	f	\N	\N	1	\N	301	\N	2143	5	\N	1
2196	2005-09-06	\N	\N	f	\N	\N	1	\N	302	\N	2144	5	\N	1
2197	2005-09-07	\N	\N	f	\N	\N	1	\N	302	\N	2145	5	\N	1
2091	1999-07-31	\N	\N	f	\N	\N	1	\N	270	2	2000	5	\N	1
2198	2005-10-03	\N	\N	f	\N	\N	1	\N	303	\N	2146	5	\N	1
2199	2005-10-11	\N	\N	f	\N	\N	1	\N	304	\N	2149	5	\N	1
2200	2005-10-12	\N	\N	f	\N	\N	1	\N	302	\N	2150	5	\N	1
2201	2006-03-22	\N	\N	f	\N	\N	1	\N	305	\N	2151	5	\N	1
2072	2000-05-10	\N	\N	f	\N	\N	2	\N	274	3	2013	5	\N	1
2246	2006-12-19	\N	\N	f	\N	\N	1	\N	320	\N	2196	5	\N	1
2259	2007-03-28	\N	\N	f	\N	\N	1	\N	321	\N	2200	5	\N	1
2220	2006-06-07	\N	\N	f	\N	\N	1	\N	307	2	2162	5	\N	1
2213	2006-05-30	\N	\N	f	\N	\N	2	\N	307	3	2155	5	\N	1
2221	2006-06-07	\N	\N	f	\N	\N	2	\N	307	3	2163	5	\N	1
2222	2006-06-08	\N	\N	f	\N	\N	1	\N	307	2	2164	5	\N	1
2223	2006-06-08	\N	\N	f	\N	\N	2	\N	310	3	2165	5	\N	1
2209	2005-06-29	\N	\N	f	\N	\N	2	\N	301	3	2142	5	\N	1
2318	2014-11-28	\N	\N	f	\N	\N	1	\N	344	\N	2270	5	\N	1
2247	2006-05-31	\N	\N	f	\N	\N	2	\N	307	3	2197	5	\N	1
2210	2005-10-05	\N	\N	f	\N	\N	1	\N	302	\N	2147	5	\N	1
2262	2007-07-09	\N	\N	f	\N	\N	2	\N	323	3	2203	5	\N	1
2296	2008-06-02	\N	\N	f	\N	\N	1	\N	327	\N	2214	5	\N	1
2330	2010-06-18	\N	\N	f	\N	\N	3	\N	342	5	2282	5	\N	1
2303	2010-06-22	\N	\N	f	\N	\N	2	\N	342	3	2248	5	\N	1
2331	2010-06-26	\N	\N	f	\N	\N	1	\N	342	2	2253	5	\N	1
2333	2010-06-26	\N	\N	f	\N	\N	2	\N	342	3	2254	5	\N	1
2307	2010-06-27	\N	\N	f	\N	\N	1	\N	342	2	2255	5	\N	1
2308	2010-06-27	\N	\N	f	\N	\N	2	\N	342	3	2256	5	\N	1
2310	2010-06-28	\N	\N	f	\N	\N	2	\N	342	6	2258	5	\N	1
2311	2010-07-07	\N	\N	f	\N	\N	1	\N	342	2	2259	5	\N	1
2312	2010-07-07	\N	\N	f	\N	\N	3	\N	342	9	2261	5	\N	1
2253	2013-03-25	\N	\N	f	\N	\N	1	\N	315	\N	2179	5	\N	1
2235	2013-03-26	\N	\N	f	\N	\N	1	\N	315	\N	2180	5	\N	1
2236	2013-07-12	\N	\N	f	\N	\N	1	\N	316	\N	2181	5	\N	1
2238	2013-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	2184	5	\N	1
2237	2013-09-04	\N	\N	f	\N	\N	1	\N	317	2	2182	5	\N	1
2251	2013-09-04	\N	\N	f	\N	\N	2	\N	317	3	2183	5	\N	1
2314	2010-07-08	\N	\N	f	\N	\N	2	\N	342	3	2264	5	\N	1
2240	2013-09-05	\N	\N	f	\N	\N	2	\N	317	3	2186	5	\N	1
2316	2010-07-09	\N	\N	f	\N	\N	1	\N	342	2	2266	5	\N	1
2332	2010-07-09	\N	\N	f	\N	\N	2	\N	342	3	2267	5	\N	1
2317	2010-07-10	\N	\N	f	\N	\N	2	\N	342	3	2268	5	\N	1
2231	2012-01-10	\N	\N	f	\N	\N	1	\N	311	\N	2174	5	\N	1
2263	2007-07-10	\N	\N	f	\N	\N	1	\N	\N	\N	2205	5	\N	1
2299	2007-07-11	\N	\N	f	\N	\N	1	\N	323	\N	2204	5	\N	1
2264	2007-07-12	\N	\N	f	\N	\N	1	\N	323	\N	2206	5	\N	1
2252	2012-06-25	\N	\N	f	\N	\N	1	\N	312	\N	2175	5	\N	1
2232	2012-07-03	\N	\N	f	\N	\N	1	\N	312	\N	2176	5	\N	1
2233	2012-11-01	\N	\N	f	\N	\N	1	\N	313	\N	2177	5	\N	1
2325	2015-05-28	\N	\N	f	\N	\N	2	\N	348	3	2279	5	\N	1
2328	2015-09-29	\N	\N	f	\N	\N	1	\N	349	2	2283	5	\N	1
2241	2013-09-09	\N	\N	f	\N	\N	1	\N	317	2	2189	5	\N	1
2319	2014-12-03	\N	\N	f	\N	\N	1	\N	344	\N	2272	5	\N	1
2265	2007-10-10	\N	\N	f	\N	\N	1	\N	324	\N	2207	5	\N	1
2300	2007-10-11	\N	\N	f	\N	\N	1	\N	325	\N	2208	5	\N	1
2301	2010-06-19	\N	\N	f	\N	\N	1	\N	342	\N	2243	5	\N	1
2297	2009-09-11	\N	\N	f	\N	\N	1	\N	338	\N	2229	5	\N	1
2298	2010-06-17	\N	\N	f	\N	\N	1	\N	342	2	2238	5	\N	1
2244	2006-06-30	\N	\N	f	\N	\N	1	\N	318	\N	2194	5	\N	1
2326	2010-06-18	\N	\N	f	\N	\N	1	\N	342	4	2280	5	\N	1
2334	2010-06-20	\N	\N	f	\N	\N	1	\N	342	2	2244	5	\N	1
2302	2010-06-21	\N	\N	f	\N	\N	1	\N	342	2	2246	5	\N	1
2335	2010-06-22	\N	\N	f	\N	\N	1	\N	342	2	2247	5	\N	1
2327	2010-06-18	\N	\N	f	\N	\N	2	\N	342	6	2281	5	\N	1
2304	2010-06-23	\N	\N	f	\N	\N	1	\N	342	2	2249	5	\N	1
2305	2010-06-23	\N	\N	f	\N	\N	2	\N	342	3	2250	5	\N	1
2306	2010-06-24	\N	\N	f	\N	\N	2	\N	342	3	2251	5	\N	1
2337	2010-07-07	\N	\N	f	\N	\N	4	\N	342	7	2262	5	\N	1
2234	2013-01-21	\N	\N	f	\N	\N	1	\N	314	\N	2178	5	\N	1
2245	2006-09-18	\N	\N	f	\N	\N	1	\N	319	\N	2195	5	\N	1
2206	2005-04-06	\N	\N	f	\N	\N	1	\N	309	\N	2157	5	\N	1
2313	2010-07-08	\N	\N	f	\N	\N	1	\N	342	2	2263	5	\N	1
2336	2010-06-25	\N	\N	f	\N	\N	1	\N	342	2	2252	5	\N	1
2309	2010-06-28	\N	\N	f	\N	\N	1	\N	342	4	2257	5	\N	1
2315	2011-01-19	\N	\N	f	\N	\N	2	\N	343	3	2265	5	\N	1
2320	2014-12-11	\N	\N	f	\N	\N	1	\N	344	\N	2273	5	\N	1
2248	2006-06-01	\N	\N	f	\N	\N	2	\N	307	3	2198	5	\N	1
2249	2006-06-02	\N	\N	f	\N	\N	1	\N	307	2	2199	5	\N	1
2250	2006-06-05	\N	\N	f	\N	\N	2	\N	307	3	2160	5	\N	1
2217	2005-10-10	\N	\N	f	\N	\N	1	\N	302	\N	2148	5	\N	1
2219	2006-06-06	\N	\N	f	\N	\N	2	\N	307	3	2161	5	\N	1
2203	2006-05-26	\N	\N	f	\N	\N	1	\N	307	2	2153	5	\N	1
2322	2015-03-17	\N	\N	f	\N	\N	1	\N	346	\N	2275	5	\N	1
2323	2015-05-26	\N	\N	f	\N	\N	1	\N	348	2	2277	5	\N	1
2324	2015-05-28	\N	\N	f	\N	\N	1	\N	348	2	2278	5	\N	1
2329	2015-09-29	\N	\N	f	\N	\N	2	\N	349	3	2284	5	\N	1
2224	2006-06-09	\N	\N	f	\N	\N	1	\N	307	2	2166	5	\N	1
2227	2006-06-12	\N	\N	f	\N	\N	2	\N	307	3	2169	5	\N	1
2228	2006-06-13	\N	\N	f	\N	\N	2	\N	310	3	2170	5	\N	1
2260	2007-03-29	\N	\N	f	\N	\N	1	\N	321	\N	2201	5	\N	1
2261	2007-07-09	\N	\N	f	\N	\N	1	\N	322	2	2202	5	\N	1
2321	2014-12-16	\N	\N	f	\N	\N	1	\N	345	\N	2274	5	\N	1
2204	2006-05-30	\N	\N	f	\N	\N	1	\N	307	2	2154	5	\N	1
2225	2006-06-09	\N	\N	f	\N	\N	2	\N	307	3	2167	5	\N	1
2229	2006-06-14	\N	\N	f	\N	\N	2	\N	307	3	2172	5	\N	1
2230	2006-06-15	\N	\N	f	\N	\N	1	\N	310	2	2173	5	\N	1
2242	2006-06-15	\N	\N	f	\N	\N	2	\N	310	3	2191	5	\N	1
2243	2006-06-16	\N	\N	f	\N	\N	1	\N	310	2	2192	5	\N	1
2205	2005-03-31	\N	\N	f	\N	\N	1	\N	308	\N	2156	5	\N	1
2218	2005-05-16	\N	\N	f	\N	\N	1	\N	299	\N	2158	5	\N	1
2215	2005-06-13	\N	\N	f	\N	\N	1	\N	301	\N	2121	5	\N	1
2212	2005-06-14	\N	\N	f	\N	\N	1	\N	301	2	2122	5	\N	1
2214	2005-06-21	\N	\N	f	\N	\N	1	\N	301	2	2130	5	\N	1
2208	2005-06-21	\N	\N	f	\N	\N	2	\N	301	3	2131	5	\N	1
2216	2005-06-23	\N	\N	f	\N	\N	1	\N	301	2	2134	5	\N	1
2207	2005-06-24	\N	\N	f	\N	\N	1	\N	301	2	2136	5	\N	1
2366	2015-06-08	\N	\N	f	\N	\N	1	\N	355	\N	2321	5	\N	1
2378	2010-07-14	\N	\N	f	\N	\N	2	\N	342	3	2289	5	\N	1
2347	2010-07-16	\N	\N	f	\N	\N	2	\N	342	3	2293	5	\N	1
2379	2010-07-19	\N	\N	f	\N	\N	1	\N	342	2	2294	5	\N	1
2350	2010-07-21	\N	\N	f	\N	\N	1	\N	342	2	2298	5	\N	1
2372	2010-07-21	\N	\N	f	\N	\N	2	\N	342	3	2299	5	\N	1
2352	2010-07-23	\N	\N	f	\N	\N	1	\N	351	\N	2301	5	\N	1
2359	2010-12-18	\N	\N	f	\N	\N	1	\N	343	2	2309	5	\N	1
2360	2010-12-18	\N	\N	f	\N	\N	2	\N	343	3	2310	5	\N	1
2353	2010-07-26	\N	\N	f	\N	\N	1	\N	351	\N	2302	5	\N	1
2374	2010-11-15	\N	\N	f	\N	\N	1	\N	352	\N	2304	5	\N	1
2358	2010-12-17	\N	\N	f	\N	\N	2	\N	343	3	2308	5	\N	1
2382	2010-12-22	\N	\N	f	\N	\N	2	\N	343	3	2315	5	\N	1
2363	2010-12-23	\N	\N	f	\N	\N	2	\N	343	3	2317	5	\N	1
2364	2010-12-24	\N	\N	f	\N	\N	2	\N	343	3	2319	5	\N	1
2365	2011-01-10	\N	\N	f	\N	\N	2	\N	343	3	2320	5	\N	1
2404	2011-01-11	\N	\N	f	\N	\N	2	\N	343	3	2361	5	\N	1
2342	2015-09-30	\N	\N	f	\N	\N	1	\N	349	2	2285	5	\N	1
2370	2011-01-14	\N	\N	f	\N	\N	2	\N	343	3	2325	5	\N	1
2383	2011-01-15	\N	\N	f	\N	\N	2	\N	343	3	2327	5	\N	1
2368	2015-09-28	\N	\N	f	\N	\N	2	\N	349	3	2323	5	\N	1
2351	2010-07-22	\N	\N	f	\N	\N	2	\N	351	3	2300	5	\N	1
2349	2010-07-20	\N	\N	f	\N	\N	2	\N	342	3	2297	5	\N	1
2346	2010-07-16	\N	\N	f	\N	\N	1	\N	342	2	2292	5	\N	1
2380	2010-07-15	\N	\N	f	\N	\N	1	\N	342	2	2290	5	\N	1
2373	2010-07-19	\N	\N	f	\N	\N	2	\N	342	3	2295	5	\N	1
2375	2010-07-15	\N	\N	f	\N	\N	2	\N	342	3	2291	5	\N	1
2355	2010-11-16	\N	\N	f	\N	\N	1	\N	353	\N	2305	5	\N	1
2369	2011-01-13	\N	\N	f	\N	\N	2	\N	343	3	2324	5	\N	1
2384	2011-01-17	\N	\N	f	\N	\N	1	\N	343	2	2328	5	\N	1
2411	2011-01-18	\N	\N	f	\N	\N	1	\N	343	2	2329	5	\N	1
2387	2011-01-20	\N	\N	f	\N	\N	1	\N	343	2	2332	5	\N	1
2388	2011-01-20	\N	\N	f	\N	\N	2	\N	343	2	2333	5	\N	1
2410	2011-01-21	\N	\N	f	\N	\N	1	\N	343	2	2334	5	\N	1
2417	2011-01-24	\N	\N	f	\N	\N	2	\N	343	3	2336	5	\N	1
2415	2011-01-26	\N	\N	f	\N	\N	2	\N	343	3	2340	5	\N	1
2395	2011-02-01	\N	\N	f	\N	\N	2	\N	343	3	2347	5	\N	1
2396	2011-02-02	\N	\N	f	\N	\N	1	\N	343	2	2348	5	\N	1
2397	2011-02-02	\N	\N	f	\N	\N	2	\N	343	3	2349	5	\N	1
2398	2011-02-04	\N	\N	f	\N	\N	1	\N	343	2	2350	5	\N	1
2412	2011-02-04	\N	\N	f	\N	\N	2	\N	343	3	2351	5	\N	1
2416	2015-10-06	\N	\N	f	\N	\N	2	\N	349	3	2356	5	\N	1
2418	2015-10-08	\N	\N	f	\N	\N	1	\N	349	2	2359	5	\N	1
2386	2011-01-19	\N	\N	f	\N	\N	1	\N	343	2	2331	5	\N	1
2409	2015-10-14	\N	\N	f	\N	\N	1	\N	349	2	2366	5	\N	1
2413	2015-10-14	\N	\N	f	\N	\N	2	\N	349	3	2367	5	\N	1
2389	2011-01-24	\N	\N	f	\N	\N	1	\N	343	2	2335	5	\N	1
2390	2011-01-25	\N	\N	f	\N	\N	1	\N	343	2	2337	5	\N	1
2400	2011-10-12	\N	\N	f	\N	\N	1	\N	358	\N	2353	5	\N	1
2401	2011-10-13	\N	\N	f	\N	\N	1	\N	358	\N	2354	5	\N	1
2468	2013-09-10	\N	\N	f	\N	\N	2	\N	317	3	2416	5	\N	1
2399	2011-02-28	\N	\N	f	\N	\N	1	\N	343	\N	2352	5	\N	1
2458	2015-10-15	\N	\N	f	\N	\N	1	\N	349	2	2368	5	\N	1
2419	2011-01-27	\N	\N	f	\N	\N	1	\N	343	2	2341	5	\N	1
2420	2015-10-07	\N	\N	f	\N	\N	1	\N	349	2	2357	5	\N	1
2450	2015-10-09	\N	\N	f	\N	\N	2	\N	349	3	2402	5	\N	1
2393	2011-01-28	\N	\N	f	\N	\N	2	\N	356	3	2344	5	\N	1
2403	2015-10-07	\N	\N	f	\N	\N	2	\N	349	3	2358	5	\N	1
2469	2013-09-11	\N	\N	f	\N	\N	1	\N	317	2	2417	5	\N	1
2454	2015-10-16	\N	\N	f	\N	\N	1	\N	349	2	2370	5	\N	1
2462	2015-10-01	\N	\N	f	\N	\N	3	\N	349	7	2373	5	\N	1
2459	2015-10-02	\N	\N	f	\N	\N	2	\N	349	3	2375	5	\N	1
2428	2015-10-05	\N	\N	f	\N	\N	2	\N	349	3	2377	5	\N	1
2430	2015-10-19	\N	\N	f	\N	\N	1	\N	349	2	2379	5	\N	1
2432	2015-10-20	\N	\N	f	\N	\N	1	\N	349	2	2381	5	\N	1
2463	2015-10-21	\N	\N	f	\N	\N	1	\N	349	2	2383	5	\N	1
2434	2015-10-22	\N	\N	f	\N	\N	1	\N	349	2	2385	5	\N	1
2444	2015-10-29	\N	\N	f	\N	\N	1	\N	359	\N	2405	5	\N	1
2452	2014-09-15	\N	\N	f	\N	\N	2	\N	345	3	2390	5	\N	1
2457	2014-09-18	\N	\N	f	\N	\N	2	\N	345	3	2395	5	\N	1
2440	2014-09-22	\N	\N	f	\N	\N	1	\N	345	2	2398	5	\N	1
2448	2014-09-22	\N	\N	f	\N	\N	2	\N	345	3	2399	5	\N	1
2407	2015-10-13	\N	\N	f	\N	\N	1	\N	349	2	2364	5	\N	1
2449	2015-10-30	\N	\N	f	\N	\N	2	\N	359	3	2407	5	\N	1
2341	2014-12-02	\N	\N	f	\N	\N	1	\N	344	\N	2271	5	\N	1
2464	2015-11-02	\N	\N	f	\N	\N	1	\N	359	\N	2408	5	\N	1
2460	2014-09-16	\N	\N	f	\N	\N	2	\N	345	3	2392	5	\N	1
2429	2015-10-16	\N	\N	f	\N	\N	2	\N	349	3	2378	5	\N	1
2437	2014-09-11	\N	\N	f	\N	\N	2	\N	345	3	2388	5	\N	1
2439	2014-09-19	\N	\N	f	\N	\N	2	\N	345	3	2397	5	\N	1
2425	2015-10-01	\N	\N	f	\N	\N	1	\N	349	2	2372	5	\N	1
2424	2015-10-15	\N	\N	f	\N	\N	2	\N	349	3	2369	5	\N	1
2427	2015-10-05	\N	\N	f	\N	\N	1	\N	349	2	2376	5	\N	1
2438	2014-09-17	\N	\N	f	\N	\N	1	\N	345	2	2393	5	\N	1
2426	2015-10-02	\N	\N	f	\N	\N	1	\N	349	2	2374	5	\N	1
2445	2015-10-30	\N	\N	f	\N	\N	1	\N	359	2	2406	5	\N	1
2433	2015-10-21	\N	\N	f	\N	\N	2	\N	349	3	2384	5	\N	1
2447	2016-02-29	\N	\N	f	\N	\N	1	\N	360	\N	2410	5	\N	1
2465	2016-08-31	\N	\N	f	\N	\N	1	\N	361	2	2412	5	\N	1
2467	2016-09-01	\N	\N	f	\N	\N	1	\N	361	2	2414	5	\N	1
2472	2013-09-12	\N	\N	f	\N	\N	2	\N	317	3	2420	5	\N	1
2435	2014-09-05	\N	\N	f	\N	\N	1	\N	345	\N	2386	5	\N	1
2446	2015-12-01	\N	\N	f	\N	\N	1	\N	349	\N	2409	5	\N	1
2344	2010-07-13	\N	\N	f	\N	\N	2	\N	342	3	2287	5	\N	1
2339	2010-07-12	\N	\N	f	\N	\N	1	\N	342	2	2269	5	\N	1
2340	2010-06-20	\N	\N	f	\N	\N	2	\N	342	3	2245	5	\N	1
2345	2010-07-14	\N	\N	f	\N	\N	1	\N	342	2	2288	5	\N	1
2481	2013-10-04	\N	\N	f	\N	\N	1	\N	362	\N	2434	5	\N	1
2497	2014-09-24	\N	\N	f	\N	\N	2	\N	345	3	2437	5	\N	1
2491	2016-09-05	\N	\N	f	\N	\N	2	\N	361	3	2441	5	\N	1
2502	2015-10-26	\N	\N	f	\N	\N	2	\N	349	3	2443	5	\N	1
2488	2014-02-24	\N	\N	f	\N	\N	1	\N	366	\N	2450	5	\N	1
2487	2017-10-30	\N	\N	f	\N	\N	1	\N	365	\N	2449	5	\N	1
2506	2017-11-07	\N	\N	f	\N	\N	2	\N	365	3	2453	5	\N	1
2493	2017-10-19	\N	\N	f	\N	\N	1	\N	364	2	2447	5	\N	1
2486	2017-10-19	\N	\N	f	\N	\N	2	\N	364	3	2448	5	\N	1
2489	2017-11-03	\N	\N	f	\N	\N	1	\N	365	\N	2451	5	\N	1
2501	2014-09-23	\N	\N	f	\N	\N	2	\N	345	3	2435	5	\N	1
2508	2018-06-18	\N	\N	f	\N	\N	1	\N	367	2	2455	5	\N	1
2475	2013-09-16	\N	\N	f	\N	\N	2	\N	317	3	2424	5	\N	1
2478	2013-09-19	\N	\N	f	\N	\N	1	\N	317	2	2429	5	\N	1
2484	2015-10-26	\N	\N	f	\N	\N	1	\N	349	2	2442	5	\N	1
2479	2013-10-02	\N	\N	f	\N	\N	2	\N	317	3	2431	5	\N	1
2482	2014-09-24	\N	\N	f	\N	\N	1	\N	345	2	2436	5	\N	1
2499	2015-10-27	\N	\N	f	\N	\N	1	\N	349	\N	2444	5	\N	1
2496	2013-09-18	\N	\N	f	\N	\N	1	\N	317	2	2427	5	\N	1
2483	2016-09-02	\N	\N	f	\N	\N	1	\N	361	2	2438	5	\N	1
2509	2018-06-18	\N	\N	f	\N	\N	2	\N	367	3	2456	5	\N	1
2539	2018-06-19	\N	\N	f	\N	\N	2	\N	367	3	2457	5	\N	1
2545	2018-06-20	\N	\N	f	\N	\N	1	\N	367	2	2458	5	\N	1
2511	2018-06-22	\N	\N	f	\N	\N	1	\N	367	2	2462	5	\N	1
2523	2018-06-22	\N	\N	f	\N	\N	2	\N	367	3	2485	5	\N	1
2485	2017-07-14	\N	\N	f	\N	\N	1	\N	363	\N	2446	5	\N	1
2516	2019-10-09	\N	\N	f	\N	\N	2	\N	371	3	2471	5	\N	1
2517	2019-10-10	\N	\N	f	\N	\N	1	\N	372	2	2472	5	\N	1
2542	2019-10-10	\N	\N	f	\N	\N	2	\N	371	3	2473	5	\N	1
2537	2019-10-11	\N	\N	f	\N	\N	2	\N	373	3	2475	5	\N	1
2541	2018-11-26	\N	\N	f	\N	\N	1	\N	367	\N	2465	5	\N	1
2532	2019-10-15	\N	\N	f	\N	\N	2	\N	372	3	2478	5	\N	1
2524	2018-06-25	\N	\N	f	\N	\N	1	\N	367	\N	2486	5	\N	1
2538	2019-10-16	\N	\N	f	\N	\N	1	\N	371	2	2479	5	\N	1
2510	2018-06-21	\N	\N	f	\N	\N	1	\N	367	2	2460	5	\N	1
2520	2016-10-17	\N	\N	f	\N	\N	1	\N	374	\N	2482	5	\N	1
2521	2016-10-20	\N	\N	f	\N	\N	1	\N	361	\N	2483	5	\N	1
2505	2017-06-22	\N	\N	f	\N	\N	1	\N	361	\N	2445	5	\N	1
2568	2019-11-11	\N	\N	f	\N	\N	1	\N	372	\N	2514	5	\N	1
2533	2018-07-09	\N	\N	f	\N	\N	1	\N	368	\N	2487	5	\N	1
2512	2018-10-26	\N	\N	f	\N	\N	1	\N	370	\N	2464	5	\N	1
2551	1869-12-07	\N	\N	t	Southesk	9th Earl 	1	\N	\N	\N	2497	5	2	6
2534	2018-06-20	\N	\N	f	\N	\N	2	\N	367	3	2459	5	\N	1
2547	1846-05-02	\N	\N	f	\N	\N	1	\N	\N	\N	2494	5	\N	6
2513	2019-10-07	\N	\N	f	\N	\N	2	\N	371	3	2466	5	\N	1
2518	2019-10-11	\N	\N	f	\N	\N	1	\N	372	2	2474	5	\N	1
2515	2019-10-09	\N	\N	f	\N	\N	1	\N	372	2	2470	5	\N	1
2525	2018-07-10	\N	\N	f	\N	\N	1	\N	368	\N	2488	5	\N	1
2531	2019-02-01	\N	\N	f	\N	\N	1	\N	\N	\N	2467	5	\N	1
2519	2019-10-15	\N	\N	f	\N	\N	1	\N	372	2	2477	5	\N	1
2495	2013-09-16	\N	\N	f	\N	\N	1	\N	317	2	2423	5	\N	1
2555	1884-06-17	\N	\N	t	Seafield	9th Earl 	1	\N	\N	\N	2501	5	2	6
2540	2020-01-06	\N	\N	f	\N	\N	1	\N	377	\N	2489	5	\N	1
2549	1859-04-16	\N	\N	f	\N	\N	1	\N	\N	\N	2495	5	\N	6
2579	1901-11-09	\N	\N	t	Cornwall and York	Duke	1	\N	\N	\N	454	5	\N	5
2556	1885-12-31	\N	\N	f	Colville of Culross	10th Lord 	1	\N	\N	\N	2502	5	2	6
2552	1874-02-28	\N	\N	f	\N	\N	1	\N	\N	\N	2498	5	\N	6
2553	1874-03-02	\N	\N	f	\N	\N	1	\N	\N	\N	2499	5	\N	6
2504	2013-09-17	\N	\N	f	\N	\N	2	\N	317	3	2426	5	\N	1
2566	1911-06-20	\N	\N	f	Mountgarret	14th Viscount 	1	\N	\N	\N	2512	5	3	4
2528	1838-07-05	\N	\N	t	Kintore	7th Earl 	1	\N	\N	\N	2492	5	2	6
2557	1886-08-13	\N	\N	f	\N	\N	2	\N	\N	\N	488	5	\N	6
2558	1891-06-23	\N	\N	f	\N	\N	1	\N	\N	\N	2503	5	\N	6
2559	1892-02-22	\N	\N	f	\N	\N	1	\N	\N	\N	2504	5	\N	6
2581	1892-08-24	\N	\N	f	\N	\N	1	\N	\N	\N	2505	5	\N	6
2561	1896-01-31	\N	\N	f	\N	\N	1	\N	\N	\N	2507	5	\N	6
2563	1897-08-23	\N	\N	f	\N	\N	1	\N	\N	\N	2509	5	\N	6
2526	1837-08-11	\N	\N	t	Roxburghe	6th Duke 	1	\N	\N	\N	2490	5	2	6
2564	1906-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	2510	5	\N	5
2570	1915-02-22	\N	\N	f	St Aldwyn	1st Viscount	1	\N	\N	\N	539	5	\N	4
2567	1911-06-21	\N	\N	f	\N	\N	1	\N	\N	\N	2513	5	\N	4
2604	1913-03-04	\N	\N	f	\N	\N	1	\N	\N	\N	2536	5	\N	4
2575	1925-06-16	\N	\N	f	Bearsted	1st Lord	1	\N	18	\N	702	5	\N	4
2571	1916-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	679	5	\N	4
2573	1920-01-28	\N	\N	f	\N	\N	1	\N	6	\N	2517	5	\N	4
2574	1922-01-25	\N	\N	f	\N	\N	1	\N	10	\N	2518	5	\N	4
2578	1929-06-24	\N	\N	f	Plumer	1st Lord	1	\N	26	\N	720	5	\N	4
2591	1941-01-20	\N	\N	f	Camrose	1st Lord	1	\N	51	\N	783	5	\N	2
2583	1929-07-10	\N	\N	f	\N	\N	2	\N	27	\N	2519	5	\N	4
2585	1929-11-18	\N	\N	f	\N	\N	1	\N	\N	\N	2521	5	\N	4
2584	1932-06-22	\N	\N	f	\N	\N	1	\N	33	\N	2520	5	\N	4
2587	1935-06-26	\N	\N	f	\N	\N	1	\N	40	\N	2522	5	\N	4
2588	1936-07-17	\N	\N	f	\N	\N	1	\N	42	\N	2523	5	\N	3
2589	1937-02-22	\N	\N	f	\N	\N	1	\N	43	\N	2524	5	\N	2
2592	1944-01-29	\N	\N	f	\N	\N	1	\N	58	\N	2525	5	\N	2
2593	1945-07-05	\N	\N	f	\N	\N	1	\N	61	\N	2526	5	\N	2
2595	1945-11-13	\N	\N	f	\N	\N	1	\N	\N	\N	2528	5	\N	2
2596	1946-06-28	\N	\N	f	\N	\N	1	\N	66	\N	2529	5	\N	2
2498	2013-09-20	\N	\N	f	\N	\N	2	\N	317	3	2430	5	\N	1
2597	1947-04-01	\N	\N	f	\N	\N	1	\N	67	\N	2530	5	\N	2
2599	1947-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	2532	5	\N	2
2598	1951-06-26	\N	\N	f	\N	\N	1	\N	76	\N	2531	5	\N	2
2603	1955-01-10	\N	\N	f	\N	\N	1	\N	84	\N	2535	5	\N	1
2606	1960-01-07	\N	\N	f	\N	\N	1	\N	\N	\N	2539	5	\N	1
2605	1961-02-02	\N	\N	f	\N	\N	1	\N	98	\N	2538	5	\N	1
2527	2006-05-31	\N	\N	f	\N	\N	1	\N	307	2	2491	5	\N	1
2529	2019-03-10	\N	\N	t	Wessex	Earl	1	\N	\N	\N	2493	5	\N	1
2732	1992-10-01	\N	\N	f	\N	\N	1	\N	233	\N	2661	5	\N	1
2613	1966-05-31	\N	\N	f	\N	\N	1	\N	121	\N	2546	5	\N	1
2711	1966-06-01	\N	\N	f	\N	\N	1	\N	121	\N	2646	5	\N	1
2722	1959-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	2650	5	\N	1
2721	1967-12-05	\N	\N	f	\N	\N	1	\N	127	\N	2649	5	\N	1
2618	1970-09-21	\N	\N	f	\N	\N	1	\N	140	\N	2550	5	\N	1
2619	1971-02-05	\N	\N	f	\N	\N	1	\N	141	\N	2551	5	\N	1
2620	1973-06-29	\N	\N	f	\N	\N	1	\N	153	\N	2552	5	\N	1
2621	1974-01-31	\N	\N	f	\N	\N	1	\N	155	\N	2553	5	\N	1
2725	1974-09-02	\N	\N	f	\N	\N	1	\N	162	\N	2653	5	\N	1
2624	1975-02-03	\N	\N	f	\N	\N	1	\N	167	\N	2557	5	\N	1
2625	1976-06-25	\N	\N	f	\N	\N	1	\N	173	\N	2558	5	\N	1
2726	1978-02-07	\N	\N	f	\N	\N	1	\N	179	\N	2654	5	\N	1
2628	1978-05-11	\N	\N	f	\N	\N	1	\N	180	\N	2561	5	\N	1
2629	1978-07-13	\N	\N	f	\N	\N	1	\N	181	\N	2562	5	\N	1
2630	1979-02-09	\N	\N	f	\N	\N	1	\N	182	\N	2563	5	\N	1
2727	1979-07-18	\N	\N	f	\N	\N	1	\N	186	\N	2655	5	\N	1
2632	1980-07-10	\N	\N	f	\N	\N	1	\N	188	\N	2565	5	\N	1
2633	1981-06-02	\N	\N	f	\N	\N	1	\N	190	\N	2566	5	\N	1
2634	1983-02-07	\N	\N	f	\N	\N	1	\N	197	\N	2567	5	\N	1
2729	1983-09-19	\N	\N	f	\N	\N	1	\N	200	\N	2657	5	\N	1
2730	1987-03-30	\N	\N	f	\N	\N	1	\N	208	\N	2658	5	\N	1
2639	1958-08-07	\N	\N	f	\N	\N	1	\N	284	\N	2572	5	\N	1
2615	1958-08-08	\N	\N	f	\N	\N	1	\N	284	\N	2537	5	\N	1
2649	1990-08-24	\N	\N	f	\N	\N	1	\N	219	\N	2575	5	\N	1
2653	1997-10-29	\N	\N	f	\N	\N	1	\N	261	2	2586	5	\N	1
2654	1997-11-01	\N	\N	f	\N	\N	1	\N	261	2	2587	5	\N	1
2644	1994-02-10	\N	\N	f	\N	\N	1	\N	238	\N	2579	5	\N	1
2645	1995-02-28	\N	\N	f	\N	\N	1	\N	243	\N	2580	5	\N	1
2733	1996-01-11	\N	\N	f	\N	\N	1	\N	247	\N	2662	5	\N	1
2655	1998-02-14	\N	\N	f	\N	\N	1	\N	263	\N	2588	5	\N	1
2646	1996-10-16	\N	\N	f	\N	\N	1	\N	253	\N	2582	5	\N	1
2734	1998-07-20	\N	\N	f	\N	\N	1	\N	264	2	2664	5	\N	1
2657	1999-01-12	\N	\N	f	\N	\N	1	\N	\N	\N	2591	5	\N	1
2712	1915-05-15	\N	\N	t	Aberdeen	7th Earl 	1	\N	\N	\N	2647	5	2	4
2664	2004-06-30	\N	\N	f	\N	\N	1	\N	295	2	2600	5	\N	1
2656	1998-07-31	\N	\N	f	\N	\N	2	\N	265	3	2589	5	\N	1
2682	2001-06-20	\N	\N	f	\N	\N	1	\N	281	\N	2594	5	\N	1
2658	1999-11-16	\N	\N	f	Shepherd	2nd Lord	5	\N	272	10	2592	5	\N	1
2680	2004-01-12	\N	\N	f	\N	\N	1	\N	379	2	2596	5	\N	1
2663	2005-01-28	\N	\N	f	\N	\N	1	\N	298	\N	2599	5	\N	1
2669	2010-06-21	\N	\N	f	\N	\N	2	\N	342	3	2606	5	\N	1
2672	2010-07-22	\N	\N	f	\N	\N	1	\N	351	2	2609	5	\N	1
2689	2007-01-11	\N	\N	f	\N	\N	1	\N	380	\N	2625	5	\N	1
2683	2011-01-10	\N	\N	f	\N	\N	1	\N	343	2	2610	5	\N	1
2640	1988-02-09	\N	\N	f	\N	\N	1	\N	\N	\N	2573	5	\N	1
2668	2010-06-17	\N	\N	f	\N	\N	2	\N	342	3	2605	5	\N	1
2674	2011-01-14	\N	\N	f	\N	\N	1	\N	343	2	2612	5	\N	1
2681	2011-01-31	\N	\N	f	\N	\N	1	\N	343	2	2613	5	\N	1
2684	2016-08-30	\N	\N	f	\N	\N	2	\N	361	3	2618	5	\N	1
2676	2015-10-01	\N	\N	f	\N	\N	2	\N	349	9	2615	5	\N	1
2671	2015-05-29	\N	\N	f	\N	\N	1	\N	348	\N	2608	5	\N	1
2688	2013-01-08	\N	\N	f	\N	\N	1	\N	382	\N	2624	5	\N	1
2673	2011-01-11	\N	\N	f	\N	\N	1	\N	343	2	2611	5	\N	1
2714	2016-09-06	\N	\N	f	\N	\N	1	\N	\N	2	2621	5	\N	1
2686	2019-10-28	\N	\N	f	\N	\N	1	\N	372	\N	2622	5	\N	1
2687	2019-10-30	\N	\N	f	\N	\N	1	\N	372	\N	2623	5	\N	1
2642	1992-07-01	\N	\N	f	\N	\N	2	\N	230	3	2577	5	\N	1
2660	2001-06-22	\N	\N	f	\N	\N	2	\N	280	3	2595	5	\N	1
2667	2008-10-13	\N	\N	f	\N	\N	1	\N	381	\N	2604	5	\N	1
2697	1831-09-10	\N	\N	f	Howden	1st Lord 	8	\N	\N	\N	2635	5	3	7
2643	1993-10-15	\N	\N	f	\N	\N	1	\N	237	\N	2578	5	\N	1
2679	2013-10-02	\N	\N	f	\N	\N	1	\N	317	2	2619	5	\N	1
2696	1831-06-20	\N	\N	t	Fingall	8th Earl 	1	\N	\N	\N	2634	5	3	7
2736	1806-03-13	\N	\N	f	\N	\N	1	\N	\N	\N	2665	5	\N	11
2610	1963-11-09	\N	\N	f	\N	\N	1	\N	\N	\N	2543	5	\N	1
2737	1826-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	2666	5	\N	8
2738	1831-09-10	\N	\N	f	\N	\N	9	\N	\N	\N	2667	5	\N	7
2698	1832-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	2636	5	\N	7
2699	1839-04-20	\N	\N	f	\N	\N	2	\N	\N	\N	2637	5	\N	6
2739	1841-08-18	\N	\N	f	\N	\N	1	\N	\N	\N	2668	5	\N	6
2702	1898-01-19	\N	\N	f	\N	\N	2	\N	\N	\N	2640	5	\N	6
2715	1801-04-27	\N	\N	t	St Vincent	1st Earl	1	\N	\N	\N	2627	5	\N	11
2704	1910-07-20	\N	\N	f	\N	\N	1	\N	\N	\N	895	5	\N	4
2740	1858-08-14	\N	\N	t	Seafield	7th Earl 	1	\N	\N	\N	2669	5	2	6
2707	1934-01-13	\N	\N	f	\N	\N	1	\N	36	\N	878	5	\N	4
2710	1940-10-21	\N	\N	f	\N	\N	1	\N	\N	\N	2645	5	\N	2
2720	1954-10-04	\N	\N	f	\N	\N	1	\N	\N	\N	2648	5	\N	1
2608	1963-11-08	\N	\N	f	\N	\N	1	\N	378	\N	2541	5	\N	1
2708	1948-02-06	\N	\N	f	\N	\N	1	\N	69	\N	2571	5	\N	2
2614	1967-01-19	\N	\N	f	\N	\N	1	\N	123	\N	2547	5	\N	1
2719	1918-01-15	\N	\N	f	\N	\N	1	\N	\N	\N	2641	5	\N	4
2612	1966-01-18	\N	\N	f	\N	\N	1	\N	120	\N	2545	5	\N	1
2717	1860-09-01	\N	\N	f	Kinnaird	9th Lord 	1	\N	\N	\N	141	5	2	6
2701	1893-06-24	\N	\N	f	\N	\N	1	\N	\N	\N	2639	5	\N	6
2706	1933-01-17	\N	\N	f	\N	\N	1	\N	34	\N	2643	5	\N	4
2709	1957-02-04	\N	\N	f	\N	\N	1	\N	88	\N	2644	5	\N	1
2617	1969-03-03	\N	\N	f	\N	\N	1	\N	134	\N	2549	5	\N	1
2611	1964-12-17	\N	\N	f	\N	\N	1	\N	115	2	2544	5	\N	1
2623	1975-01-08	\N	\N	f	\N	\N	1	\N	166	\N	2556	5	\N	1
2631	1979-07-26	\N	\N	f	\N	\N	1	\N	186	\N	2564	5	\N	1
2636	1983-10-10	\N	\N	f	\N	\N	1	\N	200	\N	2569	5	\N	1
2666	1987-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	2603	5	\N	1
2650	1996-08-19	\N	\N	f	\N	\N	1	\N	251	\N	2581	5	\N	1
2693	1815-08-11	\N	\N	f	\N	\N	8	\N	\N	\N	2630	5	\N	11
2692	1806-02-24	\N	\N	t	Granard	6th Earl 	1	\N	\N	\N	2629	5	3	11
2694	1825-01-26	\N	\N	f	Strangford	6th Viscount 	1	\N	\N	\N	2632	5	3	8
2723	1963-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	2651	5	\N	1
2813	2006-06-06	\N	\N	f	\N	\N	1	\N	307	2	2729	5	\N	1
2847	2004-06-22	\N	\N	f	\N	\N	1	\N	296	2	2745	5	\N	1
2810	1991-06-20	\N	\N	f	\N	\N	1	\N	222	\N	2725	5	\N	1
2780	2006-06-01	\N	\N	f	\N	\N	1	\N	307	2	2687	5	\N	1
2762	2016-10-04	\N	\N	f	\N	\N	1	\N	374	\N	2688	5	\N	1
2748	2006-06-05	\N	\N	f	\N	\N	1	\N	307	2	2674	5	\N	1
2826	1997-02-14	\N	\N	f	\N	\N	1	\N	255	\N	2741	5	\N	1
2865	1831-09-10	\N	\N	f	\N	\N	2	\N	\N	\N	2778	5	\N	7
2828	1998-07-30	\N	\N	f	\N	\N	1	\N	265	2	2743	5	\N	1
2858	2018-07-16	\N	\N	f	\N	\N	1	\N	369	\N	2771	5	\N	1
2775	1957-08-22	\N	\N	f	\N	\N	1	\N	89	\N	2696	5	\N	1
2783	1914-07-27	\N	\N	f	Kitchener of Khartoum	1st Viscount	1	\N	\N	\N	492	5	\N	4
2806	1964-06-30	\N	\N	f	\N	\N	1	\N	111	\N	2719	5	\N	1
2861	1986-07-23	\N	\N	f	\N	\N	1	\N	\N	\N	2773	5	\N	1
2795	1987-11-03	\N	\N	f	\N	\N	1	\N	211	\N	2712	5	\N	1
2839	2006-06-13	\N	\N	f	\N	\N	1	\N	310	2	2747	5	\N	1
2755	2017-11-20	\N	\N	f	\N	\N	1	\N	365	\N	2681	5	\N	1
2812	2004-01-13	\N	\N	f	\N	\N	1	\N	294	\N	2727	5	\N	1
2849	1881-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2761	5	\N	6
2779	1917-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	2699	5	\N	4
2804	1946-03-01	\N	\N	f	\N	\N	1	\N	65	\N	1047	5	\N	2
2863	1961-07-12	\N	\N	f	\N	\N	1	\N	\N	\N	2775	5	\N	1
2856	1928-03-31	\N	\N	f	\N	\N	1	\N	\N	\N	2769	5	\N	4
2803	1943-07-05	\N	\N	f	\N	\N	1	\N	57	\N	2717	5	\N	2
2805	1953-02-13	\N	\N	f	\N	\N	1	\N	80	\N	2718	5	\N	1
2769	1960-05-16	\N	\N	f	\N	\N	1	\N	\N	\N	2694	5	\N	1
2820	1964-12-19	\N	\N	f	\N	\N	1	\N	114	\N	1995	5	\N	1
2766	1902-07-15	\N	\N	f	Milner	1st Lord	1	\N	\N	\N	508	5	\N	5
2758	1962-01-29	\N	\N	f	\N	\N	1	\N	101	\N	1994	5	\N	1
2836	1919-05-16	\N	\N	f	\N	\N	2	\N	4	\N	2756	5	\N	4
2750	2004-06-09	\N	\N	f	\N	\N	2	\N	295	3	2671	5	\N	1
2767	1917-01-01	\N	\N	f	Sandhurst	2nd Lord	1	\N	\N	\N	2692	5	\N	4
2807	1967-02-06	\N	\N	f	\N	\N	1	\N	123	\N	2721	5	\N	1
2808	1969-10-28	\N	\N	f	\N	\N	1	\N	135	\N	2722	5	\N	1
2787	1974-12-19	\N	\N	f	\N	\N	1	\N	164	\N	2704	5	\N	1
2789	1975-01-09	\N	\N	f	\N	\N	1	\N	166	\N	2706	5	\N	1
2790	1978-05-16	\N	\N	f	\N	\N	1	\N	180	\N	2707	5	\N	1
2788	1975-01-10	\N	\N	f	\N	\N	1	\N	166	\N	2705	5	\N	1
2791	1980-02-21	\N	\N	f	\N	\N	1	\N	187	\N	2708	5	\N	1
2792	1981-05-18	\N	\N	f	\N	\N	1	\N	190	\N	2709	5	\N	1
2815	1981-06-19	\N	\N	f	\N	\N	1	\N	190	\N	2723	5	\N	1
2759	1985-05-22	\N	\N	f	\N	\N	1	\N	203	\N	2684	5	\N	1
2760	1987-10-19	\N	\N	f	\N	\N	1	\N	211	\N	2685	5	\N	1
2809	1987-11-05	\N	\N	f	\N	\N	1	\N	211	\N	2724	5	\N	1
2841	2011-01-21	\N	\N	f	\N	\N	2	\N	343	3	2751	5	\N	1
2864	1876-08-21	\N	\N	f	\N	\N	1	\N	\N	\N	2777	5	\N	6
2862	1920-06-03	\N	\N	f	\N	\N	1	\N	7	\N	2774	5	\N	4
2872	1919-09-30	\N	\N	f	Iveagh	1st Viscount	1	\N	5	\N	431	5	\N	4
2860	1937-03-08	\N	\N	f	\N	\N	1	\N	\N	\N	2772	5	\N	2
2855	1947-11-20	\N	\N	f	\N	\N	1	\N	\N	\N	2768	5	\N	2
2756	1955-09-02	\N	\N	f	\N	\N	1	\N	85	\N	2682	5	\N	1
2817	1965-05-17	\N	\N	f	\N	\N	1	\N	117	\N	2720	5	\N	1
2785	1968-01-19	\N	\N	f	\N	\N	1	\N	128	\N	2702	5	\N	1
2794	1987-10-05	\N	\N	f	\N	\N	1	\N	211	\N	2711	5	\N	1
2747	1991-02-07	\N	\N	f	\N	\N	1	\N	221	\N	2659	5	\N	1
2796	1996-01-17	\N	\N	f	\N	\N	1	\N	247	\N	2713	5	\N	1
2814	2004-06-02	\N	\N	f	\N	\N	1	\N	295	2	2728	5	\N	1
2811	1998-07-25	\N	\N	f	\N	\N	2	\N	265	3	2726	5	\N	1
2844	1998-08-03	\N	\N	f	\N	\N	1	\N	264	2	2737	5	\N	1
2797	1996-10-01	\N	\N	f	\N	\N	1	\N	252	2	2714	5	\N	1
2830	2007-12-10	\N	\N	f	\N	\N	1	\N	326	\N	2748	5	\N	1
2784	1966-06-13	\N	\N	f	\N	\N	1	\N	121	\N	2701	5	\N	1
2746	2015-10-22	\N	\N	f	\N	\N	2	\N	349	3	2679	5	\N	1
2749	1997-09-23	\N	\N	f	\N	\N	2	\N	260	3	2663	5	\N	1
2831	2015-05-26	\N	\N	f	\N	\N	2	\N	348	3	2749	5	\N	1
2827	1997-10-03	\N	\N	f	\N	\N	1	\N	261	2	2742	5	\N	1
2823	1999-07-19	\N	\N	f	\N	\N	1	\N	268	2	2738	5	\N	1
2763	2001-08-28	\N	\N	f	\N	\N	1	\N	280	\N	2689	5	\N	1
2742	2005-06-16	\N	\N	f	\N	\N	1	\N	301	2	2672	5	\N	1
2816	2007-10-15	\N	\N	f	\N	\N	1	\N	325	\N	2730	5	\N	1
2818	2011-01-17	\N	\N	f	\N	\N	2	\N	343	3	2732	5	\N	1
2833	2014-09-15	\N	\N	f	\N	\N	1	\N	345	2	2752	5	\N	1
2744	2010-12-20	\N	\N	f	\N	\N	2	\N	343	3	2677	5	\N	1
2851	2011-05-26	\N	\N	f	\N	\N	1	\N	357	\N	2764	5	\N	1
2846	2013-09-20	\N	\N	f	\N	\N	1	\N	317	2	2753	5	\N	1
2751	2006-05-26	\N	\N	f	\N	\N	2	\N	307	3	2673	5	\N	1
2773	1941-07-04	\N	\N	f	\N	\N	1	\N	52	\N	1085	5	\N	2
2753	1816-01-16	\N	\N	f	Hill	1st Lord	1	\N	\N	\N	54	5	\N	11
2840	2014-09-12	\N	\N	f	\N	\N	2	\N	345	3	2733	5	\N	1
2843	2013-09-19	\N	\N	f	\N	\N	2	\N	317	3	2734	5	\N	1
2871	1812-09-07	\N	\N	f	Harewood	1st Lord	4	\N	\N	\N	2781	5	\N	11
2834	2019-10-14	\N	\N	f	\N	\N	2	\N	371	3	2754	5	\N	1
2866	1831-09-12	\N	\N	f	Duncan	2nd Viscount	2	\N	\N	\N	2779	5	\N	7
2782	1900-06-26	\N	\N	f	Strathcona and Mount Royal	1st Lord	1	\N	\N	\N	2509	5	\N	6
2757	1841-06-30	\N	\N	f	\N	\N	1	\N	\N	\N	2683	5	\N	6
2853	1874-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2766	5	\N	6
2848	1999-11-17	\N	\N	f	Belstead	2nd Lord	2	\N	272	6	2758	5	\N	1
2850	1892-04-07	\N	\N	t	Argyll	8th Duke 	1	\N	\N	\N	2762	5	2	6
2774	1950-01-27	\N	\N	f	\N	\N	1	\N	73	\N	1177	5	\N	2
2801	1929-08-31	\N	\N	f	\N	\N	1	\N	27	\N	897	5	\N	4
2835	1938-01-27	\N	\N	f	\N	\N	1	\N	46	\N	2755	5	\N	2
2768	1945-10-12	\N	\N	f	\N	\N	1	\N	\N	\N	2693	5	\N	2
2778	1961-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	1996	5	\N	1
2764	1876-10-16	\N	\N	f	\N	\N	1	\N	\N	\N	2690	5	\N	6
2754	2016-09-01	\N	\N	f	\N	\N	2	\N	361	3	2680	5	\N	1
2852	1890-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2765	5	\N	6
2800	1920-01-09	\N	\N	f	\N	\N	1	\N	6	\N	2716	5	\N	4
2875	1917-12-20	\N	\N	f	Reading	1st Viscount	1	\N	\N	\N	609	5	\N	4
2923	2000-05-01	\N	\N	f	\N	\N	1	\N	274	2	2022	5	\N	1
2929	1943-05-03	\N	\N	f	\N	\N	1	\N	\N	\N	929	5	\N	2
2880	1911-07-03	\N	\N	t	Crewe	1st Earl	1	\N	\N	\N	494	5	\N	4
2879	1931-02-20	\N	\N	f	Willingdon	1st Viscount	1	\N	\N	\N	895	5	\N	4
114	1815-11-30	\N	\N	f	Bradford	2nd Lord	1	\N	\N	\N	109	5	\N	11
296	1866-05-01	\N	\N	t	Caithness	14th Earl 	1	\N	\N	\N	277	5	2	6
292	1863-08-20	\N	\N	f	\N	\N	1	\N	\N	\N	272	5	\N	6
422	1885-12-30	\N	\N	f	Elphinstone	15th Lord 	1	\N	\N	\N	400	5	2	6
2920	1959-12-16	\N	\N	f	\N	\N	1	\N	95	\N	1128	5	\N	1
2921	1965-12-07	\N	\N	f	\N	\N	1	\N	\N	\N	1255	5	\N	1
2898	2013-09-09	\N	\N	f	\N	\N	2	\N	317	3	2190	5	\N	1
2907	1982-07-14	\N	\N	f	\N	\N	1	\N	194	\N	1562	5	\N	1
2903	2015-10-23	\N	\N	f	\N	\N	1	\N	349	2	2401	5	\N	1
2892	2015-05-19	\N	\N	f	\N	\N	1	\N	347	\N	2276	5	\N	1
2893	1997-09-24	\N	\N	f	\N	\N	1	\N	261	2	1851	5	\N	1
2916	1972-05-02	\N	\N	f	\N	\N	1	\N	149	\N	1365	5	\N	1
2889	2005-06-28	\N	\N	f	\N	\N	2	\N	301	3	2141	5	\N	1
2883	1922-05-05	\N	\N	f	\N	\N	1	\N	\N	\N	2776	5	\N	4
2899	2016-09-02	\N	\N	f	\N	\N	2	\N	361	3	2439	5	\N	1
2897	1970-10-14	\N	\N	f	\N	\N	1	\N	140	\N	1339	5	\N	1
2924	1990-02-27	\N	\N	f	\N	\N	1	\N	217	\N	1674	5	\N	1
2908	1990-07-16	\N	\N	f	\N	\N	2	\N	219	3	2574	5	\N	1
2890	2007-12-11	\N	\N	f	\N	\N	1	\N	326	\N	2211	5	\N	1
2901	1987-03-18	\N	\N	f	\N	\N	1	\N	208	\N	1630	5	\N	1
2878	1999-06-19	\N	\N	f	\N	\N	1	\N	269	\N	2493	5	\N	1
2902	2004-06-23	\N	\N	f	\N	\N	2	\N	295	3	2103	5	\N	1
2913	1993-10-12	\N	\N	f	\N	\N	1	\N	237	\N	1766	5	\N	1
2891	1979-08-06	\N	\N	f	\N	\N	1	\N	186	\N	1522	5	\N	1
2926	1995-02-17	\N	\N	f	\N	\N	1	\N	243	\N	1788	5	\N	1
2895	1996-10-14	\N	\N	f	\N	\N	1	\N	253	\N	1817	5	\N	1
2919	2001-06-28	\N	\N	f	\N	\N	1	\N	278	2	2040	5	\N	1
2918	1974-07-11	\N	\N	f	\N	\N	1	\N	161	\N	1408	5	\N	1
2917	1976-01-26	\N	\N	f	\N	\N	1	\N	170	\N	1448	5	\N	1
2906	2007-03-30	\N	\N	f	\N	\N	1	\N	321	\N	2675	5	\N	1
2905	1964-12-07	\N	\N	f	\N	\N	2	\N	114	\N	1208	5	\N	1
2900	1967-09-15	\N	\N	f	\N	\N	1	\N	125	\N	1288	5	\N	1
51	1812-09-07	\N	\N	f	Camden	2nd Earl	2	\N	\N	\N	49	5	\N	11
2911	1990-05-18	\N	\N	f	\N	\N	1	\N	218	\N	1682	5	\N	1
31	1804-05-14	\N	\N	f	Clive	1st Lord	1	\N	\N	\N	36	5	\N	11
2925	1997-10-24	\N	\N	f	\N	\N	1	\N	261	2	1879	5	\N	1
2932	1945-09-17	\N	\N	f	\N	\N	1	\N	64	\N	2527	5	\N	2
2876	1955-05-05	\N	\N	f	Swinton	1st Viscount	1	\N	\N	\N	851	5	\N	1
171	1832-05-15	\N	\N	f	Falkland	10th Viscount 	1	\N	\N	\N	160	5	2	7
2931	1946-08-23	\N	\N	f	\N	\N	1	\N	66	\N	986	5	\N	2
71	1806-02-22	\N	\N	t	Lauderdale	8th Earl 	1	\N	\N	\N	68	5	2	11
2885	1801-06-26	\N	\N	f	Grey de Wilton	1st Lord	1	\N	\N	\N	2785	5	\N	11
2928	1803-10-26	\N	\N	f	Bath	1st Baroness	1	\N	\N	\N	2759	5	\N	11
39	1805-11-20	\N	\N	f	Nelson	2nd Lord	2	\N	\N	\N	23	5	\N	11
120	1827-10-05	\N	\N	t	Darlington	3rd Earl	1	\N	\N	\N	115	5	\N	8
155	1831-09-10	\N	\N	f	Ludlow	3rd Earl 	6	\N	\N	\N	146	5	3	7
2877	1812-02-28	\N	\N	f	Wellington	1st Viscount	1	\N	\N	\N	48	5	\N	11
2884	1815-11-28	\N	\N	f	Eliot	2nd Lord	1	\N	\N	\N	2783	5	\N	11
90	1821-07-17	\N	\N	f	Somers	2nd Lord	1	\N	\N	\N	83	5	\N	8
186	1835-06-13	\N	\N	t	Gosford	2nd Earl 	1	\N	\N	\N	176	5	3	7
133	1827-04-30	\N	\N	f	\N	\N	1	\N	\N	\N	123	5	\N	8
136	1827-10-06	\N	\N	f	Cawdor	2nd Lord	1	\N	\N	\N	126	5	\N	8
249	1837-02-13	\N	\N	t	Charlemont	2nd Earl 	1	\N	\N	\N	219	5	3	7
204	1833-04-13	\N	\N	f	Goderich	1st Viscount	1	\N	\N	\N	121	5	\N	7
354	1876-01-13	\N	\N	t	Erne	3rd Earl 	2	\N	\N	\N	334	5	3	6
263	1856-11-19	\N	\N	f	Talbot of Malahide	4th Lord 	1	\N	\N	\N	246	5	3	6
313	1859-05-21	\N	\N	f	Elphinstone	13th Lord 	2	\N	\N	\N	294	5	2	6
227	1841-08-17	\N	\N	f	Segrave	1st Lord	1	\N	\N	\N	152	5	\N	6
223	1839-09-05	\N	\N	f	\N	\N	1	\N	\N	\N	209	5	\N	6
242	1844-10-22	\N	\N	f	Ellenborough	2nd Lord	1	\N	\N	\N	228	5	\N	6
324	1866-07-12	\N	\N	f	Cremorne	3rd Lord 	1	\N	\N	\N	221	5	3	6
258	1856-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	241	5	\N	6
2886	1861-10-21	\N	\N	t	Sutherland	Duchess	1	\N	\N	\N	2760	5	\N	6
270	1858-03-01	\N	\N	f	\N	\N	1	\N	\N	\N	253	5	\N	6
274	1858-08-28	\N	\N	f	\N	\N	1	\N	\N	\N	257	5	\N	6
2882	1899-10-16	\N	\N	t	Fife	1st Duke	1	\N	\N	\N	453	5	\N	6
279	1859-08-18	\N	\N	f	\N	\N	1	\N	\N	\N	262	5	\N	6
2934	1864-04-27	\N	\N	f	De La Warr	Countess	1	\N	\N	\N	273	5	\N	6
386	1881-10-08	\N	\N	f	Reay	11th Lord 	1	\N	\N	\N	367	5	2	6
361	1874-04-02	\N	\N	f	Ravensworth	2nd Lord	1	\N	\N	\N	342	5	\N	6
305	1866-08-03	\N	\N	f	\N	\N	1	\N	\N	\N	286	5	\N	6
310	1868-04-17	\N	\N	f	\N	\N	1	\N	\N	\N	291	5	\N	6
331	1870-10-26	\N	\N	f	\N	\N	1	\N	\N	\N	311	5	\N	6
343	1873-08-23	\N	\N	f	\N	\N	1	\N	\N	\N	323	5	\N	6
383	1874-03-06	\N	\N	f	\N	\N	2	\N	\N	\N	364	5	\N	6
399	1876-06-10	\N	\N	f	Northbrook	2nd Lord	1	\N	\N	\N	380	5	\N	6
370	1878-09-27	\N	\N	f	Cairns	1st Lord	1	\N	\N	\N	288	5	\N	6
376	1880-05-04	\N	\N	f	Sondes	5th Lord	2	\N	\N	\N	357	5	\N	6
2888	1958-07-26	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	2786	5	\N	1
2930	1885-09-28	\N	\N	f	Wolseley	1st Lord	1	\N	\N	\N	374	5	\N	6
394	1884-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	375	5	\N	6
409	1885-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	386	5	\N	6
419	1885-07-23	\N	\N	f	\N	\N	1	\N	\N	\N	396	5	\N	6
432	1886-08-19	\N	\N	f	\N	\N	1	\N	\N	\N	411	5	\N	6
446	1887-07-07	\N	\N	f	\N	\N	1	\N	\N	\N	422	5	\N	6
451	1889-12-05	\N	\N	f	\N	\N	1	\N	\N	\N	428	5	\N	6
461	1892-06-20	\N	\N	f	\N	\N	1	\N	\N	\N	440	5	\N	6
81	1812-09-07	\N	\N	t	Northampton	9th Earl	1	\N	\N	\N	77	5	\N	11
2887	1910-06-23	\N	\N	t	Cornwall	Duke	1	\N	\N	\N	2772	5	\N	4
471	1893-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	451	5	\N	6
484	1893-06-26	\N	\N	f	\N	\N	1	\N	\N	\N	460	5	\N	6
489	1894-05-07	\N	\N	f	\N	\N	1	\N	\N	\N	465	5	\N	6
518	1899-01-25	\N	\N	f	Cromer	1st Lord	1	\N	\N	\N	440	5	\N	6
500	1895-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	475	5	\N	6
505	1897-02-05	\N	\N	f	\N	\N	1	\N	\N	\N	480	5	\N	6
511	1897-07-27	\N	\N	f	\N	\N	1	\N	\N	\N	486	5	\N	6
578	1902-07-14	\N	\N	f	Churchill	3rd Lord	1	\N	\N	\N	546	5	\N	5
525	1899-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	497	5	\N	6
530	1900-05-10	\N	\N	f	\N	\N	1	\N	\N	\N	503	5	\N	6
686	1917-05-07	\N	\N	f	Valentia	11th Viscount 	1	\N	\N	\N	647	5	3	4
540	1902-07-16	\N	\N	f	\N	\N	1	\N	\N	\N	512	5	\N	5
545	1902-07-22	\N	\N	f	\N	\N	1	\N	\N	\N	517	5	\N	5
550	1905-02-23	\N	\N	f	\N	\N	1	\N	\N	\N	522	5	\N	5
555	1905-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	526	5	\N	5
563	1905-12-22	\N	\N	f	\N	\N	2	\N	\N	\N	531	5	\N	5
574	1906-01-11	\N	\N	f	\N	\N	1	\N	\N	\N	542	5	\N	5
617	1906-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	585	5	\N	5
586	1907-07-17	\N	\N	f	\N	\N	1	\N	\N	\N	554	5	\N	5
591	1908-05-04	\N	\N	f	\N	\N	1	\N	\N	\N	559	5	\N	5
596	1908-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	564	5	\N	5
602	1910-03-15	\N	\N	f	\N	\N	2	\N	\N	\N	570	5	\N	5
607	1910-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	575	5	\N	4
612	1910-09-21	\N	\N	f	\N	\N	1	\N	\N	\N	580	5	\N	4
622	1911-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	590	5	\N	4
670	1916-06-26	\N	\N	f	Reading	1st Lord	1	\N	\N	\N	609	5	\N	4
649	1914-01-28	\N	\N	f	\N	\N	1	\N	\N	\N	613	5	\N	4
654	1914-07-04	\N	\N	f	\N	\N	1	\N	\N	\N	618	5	\N	4
660	1915-06-29	\N	\N	f	\N	\N	1	\N	\N	\N	624	5	\N	4
665	1916-01-25	\N	\N	f	\N	\N	1	\N	\N	\N	628	5	\N	4
700	1918-01-16	\N	\N	f	Furness	2nd Lord	1	\N	\N	\N	657	5	\N	4
677	1917-01-01	\N	\N	f	\N	\N	2	\N	\N	\N	639	5	\N	4
682	1917-01-04	\N	\N	f	\N	\N	1	\N	\N	\N	643	5	\N	4
710	1919-05-16	\N	\N	f	Burnham	2nd Lord	1	\N	4	\N	666	5	\N	4
781	1922-11-28	\N	\N	f	Lee of Fareham	1st Lord	2	\N	\N	\N	669	5	\N	4
703	1918-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	660	5	\N	4
704	1918-01-19	\N	\N	f	\N	\N	1	\N	\N	\N	661	5	\N	4
719	1919-02-04	\N	\N	f	\N	\N	1	\N	\N	\N	674	5	\N	4
724	1919-03-24	\N	\N	f	\N	\N	1	\N	\N	\N	678	5	\N	4
946	1938-06-25	\N	\N	f	Weir	1st Lord	1	\N	47	\N	663	5	\N	2
740	1919-12-12	\N	\N	f	\N	\N	1	\N	\N	\N	693	5	\N	4
748	1921-01-18	\N	\N	f	\N	\N	1	\N	8	\N	700	5	\N	4
756	1921-06-04	\N	\N	f	\N	\N	2	\N	\N	\N	707	5	\N	4
773	1922-06-20	\N	\N	f	\N	\N	1	\N	11	\N	722	5	\N	4
971	1940-10-28	\N	\N	f	Hewart	1st Lord	1	\N	\N	\N	754	5	\N	2
790	1924-01-12	\N	\N	f	\N	\N	1	\N	13	\N	737	5	\N	4
798	1925-01-19	\N	\N	f	\N	\N	1	\N	17	\N	744	5	\N	4
805	1925-12-22	\N	\N	f	\N	\N	1	\N	\N	\N	750	5	\N	4
823	1928-06-15	\N	\N	f	\N	\N	1	\N	24	\N	768	5	\N	4
832	1929-06-17	\N	\N	f	\N	\N	1	\N	26	\N	778	5	\N	4
843	1929-06-22	\N	\N	f	\N	\N	1	\N	\N	\N	786	5	\N	4
844	1929-07-05	\N	\N	f	\N	\N	1	\N	27	\N	787	5	\N	4
887	1929-07-24	\N	\N	f	\N	\N	1	\N	26	\N	828	5	\N	4
854	1930-01-21	\N	\N	f	\N	\N	1	\N	28	\N	797	5	\N	4
867	1931-12-07	\N	\N	f	\N	\N	1	\N	31	\N	810	5	\N	4
877	1932-06-21	\N	\N	f	\N	\N	1	\N	33	\N	819	5	\N	4
900	1935-01-26	\N	\N	f	\N	\N	1	\N	39	\N	840	5	\N	4
911	1935-10-14	\N	\N	f	\N	\N	1	\N	\N	\N	850	5	\N	4
1038	1944-07-11	\N	\N	f	Halifax	3rd Viscount	1	\N	59	\N	750	5	\N	2
999	1939-07-08	\N	\N	f	\N	\N	1	\N	49	\N	933	5	\N	2
1026	1945-09-13	\N	\N	f	Marchwood	1st Lord	1	\N	64	\N	871	5	\N	2
978	1941-07-16	\N	\N	f	\N	\N	2	\N	52	\N	911	5	\N	2
991	1942-04-27	\N	\N	f	\N	\N	2	\N	\N	\N	924	5	\N	2
1118	1947-10-18	\N	\N	f	Mountbatten of Burma	1st Viscount	1	\N	\N	\N	986	5	\N	2
1006	1944-10-13	\N	\N	f	\N	\N	1	\N	\N	\N	939	5	\N	2
1017	1945-07-12	\N	\N	f	\N	\N	1	\N	62	\N	949	5	\N	2
1135	1953-07-02	\N	\N	f	Woolton	1st Lord	1	\N	81	\N	1056	5	\N	1
1074	1945-11-15	\N	\N	f	\N	\N	1	\N	\N	\N	999	5	\N	2
1065	1947-01-06	\N	\N	f	\N	\N	1	\N	\N	\N	991	5	\N	2
1145	1954-07-16	\N	\N	f	Soulbury	1st Lord	1	\N	83	\N	913	5	\N	1
1083	1948-06-23	\N	\N	f	\N	\N	1	\N	70	\N	1007	5	\N	2
1094	1950-02-01	\N	\N	f	\N	\N	1	\N	73	\N	1018	5	\N	2
1105	1950-07-11	\N	\N	f	\N	\N	1	\N	74	\N	1029	5	\N	2
1114	1951-11-12	\N	\N	f	\N	\N	1	\N	\N	\N	1038	5	\N	2
634	1912-07-08	\N	\N	t	Carrick	7th Earl 	1	\N	\N	\N	599	5	3	4
1259	1963-01-30	\N	\N	f	Alexander of Hillsborough	1st Viscount	1	\N	104	\N	1177	5	\N	1
1189	1955-02-18	\N	\N	f	\N	\N	1	\N	84	\N	1107	5	\N	1
1156	1955-07-25	\N	\N	f	\N	\N	1	\N	85	\N	1074	5	\N	1
1163	1956-01-18	\N	\N	f	\N	\N	1	\N	\N	\N	1081	5	\N	1
1177	1957-07-02	\N	\N	f	\N	\N	1	\N	89	\N	1095	5	\N	1
1229	1958-08-22	\N	\N	f	\N	\N	1	\N	284	\N	1147	5	\N	1
1293	1964-12-07	\N	\N	f	Dilhorne	1st Lord	1	\N	114	\N	1174	5	\N	1
1217	1960-04-12	\N	\N	f	\N	\N	1	\N	\N	\N	1135	5	\N	1
1224	1960-10-01	\N	\N	f	\N	\N	1	\N	\N	\N	1142	5	\N	1
1240	1961-10-11	\N	\N	f	\N	\N	1	\N	\N	\N	1158	5	\N	1
1256	1962-08-01	\N	\N	f	\N	\N	1	\N	\N	\N	1175	5	\N	1
1280	1964-05-13	\N	\N	f	\N	\N	1	\N	110	\N	1195	5	\N	1
1321	1965-02-18	\N	\N	f	\N	\N	1	\N	\N	\N	1235	5	\N	1
1345	1966-06-09	\N	\N	f	\N	\N	1	\N	121	\N	1262	5	\N	1
1360	1967-07-06	\N	\N	f	\N	\N	1	\N	124	\N	1277	5	\N	1
466	1892-08-27	\N	\N	f	\N	\N	1	\N	\N	\N	446	5	\N	6
1389	1968-07-11	\N	\N	f	\N	\N	1	\N	130	\N	1308	5	\N	1
1399	1969-07-02	\N	\N	f	\N	\N	1	\N	135	\N	1315	5	\N	1
1414	1970-07-09	\N	\N	f	\N	\N	1	\N	137	\N	1332	5	\N	1
1429	1971-05-01	\N	\N	f	\N	\N	1	\N	145	\N	1350	5	\N	1
1457	1974-03-25	\N	\N	f	\N	\N	1	\N	157	\N	1379	5	\N	1
1472	1974-05-14	\N	\N	f	\N	\N	1	\N	160	\N	1388	5	\N	1
1487	1974-07-10	\N	\N	f	\N	\N	1	\N	162	\N	1407	5	\N	1
1502	1975-01-21	\N	\N	f	\N	\N	1	\N	166	\N	1424	5	\N	1
492	1895-07-16	\N	\N	f	Carrington	3rd Lord	1	\N	\N	\N	468	5	\N	6
1976	1998-07-27	\N	\N	f	\N	\N	1	\N	264	2	1919	5	\N	1
2032	1998-08-01	\N	\N	f	\N	\N	1	\N	265	2	1967	5	\N	1
2067	2000-02-14	\N	\N	f	\N	\N	1	\N	273	\N	2006	5	\N	1
2002	1999-07-12	\N	\N	f	\N	\N	1	\N	268	\N	1942	5	\N	1
2090	2000-05-02	\N	\N	f	\N	\N	1	\N	274	2	2024	5	\N	1
2163	2004-06-30	\N	\N	f	\N	\N	2	\N	297	3	2112	5	\N	1
2118	2001-07-12	\N	\N	f	\N	\N	1	\N	280	\N	2057	5	\N	1
2894	2000-05-09	\N	\N	f	\N	\N	2	\N	274	3	2011	5	\N	1
2211	2005-05-31	\N	\N	f	\N	\N	1	\N	300	\N	2119	5	\N	1
2148	2004-06-15	\N	\N	f	\N	\N	2	\N	295	3	2092	5	\N	1
2665	2005-06-29	\N	\N	f	\N	\N	1	\N	301	2	2601	5	\N	1
2257	2006-06-14	\N	\N	f	\N	\N	1	\N	307	2	2171	5	\N	1
2678	2015-10-23	\N	\N	f	\N	\N	2	\N	349	3	2617	5	\N	1
2254	2013-09-06	\N	\N	f	\N	\N	2	\N	317	3	2188	5	\N	1
2292	2007-03-23	\N	\N	f	\N	\N	1	\N	321	\N	2239	5	\N	1
2832	2010-07-12	\N	\N	f	\N	\N	2	\N	342	3	2750	5	\N	1
2202	2006-04-28	\N	\N	f	\N	\N	1	\N	306	\N	2152	5	\N	1
2507	2018-06-12	\N	\N	f	\N	\N	1	\N	367	\N	2454	5	\N	1
2535	2018-07-11	\N	\N	f	\N	\N	1	\N	368	\N	2463	5	\N	1
2255	2013-09-06	\N	\N	f	\N	\N	1	\N	317	2	2187	5	\N	1
2752	1801-08-18	\N	\N	f	Nelson	1st Viscount	1	\N	\N	\N	3	5	\N	11
2075	2000-05-12	\N	\N	f	\N	\N	2	\N	274	3	2017	5	\N	1
2881	1822-02-04	\N	\N	t	Buckingham	2nd Marquess	1	\N	\N	\N	2763	5	\N	8
2867	1827-10-05	\N	\N	f	Dudley and Ward	4th Viscount	2	\N	\N	\N	2780	5	\N	8
2859	1814-05-11	\N	\N	t	Wellington	1st Marquess	1	\N	\N	\N	48	5	\N	11
2873	1837-08-12	\N	\N	f	\N	\N	1	\N	\N	\N	2782	5	\N	6
2548	1856-01-16	\N	\N	f	\N	\N	1	\N	\N	\N	244	5	\N	6
2854	1866-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	2767	5	\N	6
2781	1902-07-11	\N	\N	f	Kitchener of Khartoum	1st Lord	1	\N	\N	\N	492	5	\N	5
2554	1880-05-26	\N	\N	f	\N	\N	1	\N	\N	\N	2500	5	\N	6
2765	1886-08-27	\N	\N	f	\N	\N	1	\N	\N	\N	2691	5	\N	6
2560	1896-01-24	\N	\N	f	\N	\N	1	\N	\N	\N	2506	5	\N	6
2874	1905-12-22	\N	\N	f	Hawkesbury	1st Lord	1	\N	\N	\N	2639	5	\N	5
2705	1919-10-28	\N	\N	f	Ruthven of Freeland	9th Lord 	1	\N	\N	\N	2642	5	2	4
2565	1909-02-20	\N	\N	f	\N	\N	1	\N	\N	\N	2511	5	\N	5
2700	1873-04-09	\N	\N	t	Normanton	3rd Earl 	1	\N	\N	\N	2638	5	3	6
2572	1918-11-14	\N	\N	f	\N	\N	1	\N	\N	\N	2516	5	\N	4
2735	1924-06-23	\N	\N	f	Willingdon	1st Lord	1	\N	16	\N	895	5	\N	4
2577	1926-02-17	\N	\N	f	Dunedin	1st Lord	1	\N	19	\N	523	5	\N	4
2770	1927-01-31	\N	\N	f	Sumner	Lord	1	\N	21	\N	608	5	\N	4
2600	1949-06-01	\N	\N	f	\N	\N	1	\N	\N	\N	1172	5	\N	2
2607	1961-07-11	\N	\N	f	\N	\N	1	\N	100	\N	2540	5	\N	1
2609	1964-08-21	\N	\N	f	\N	\N	1	\N	113	\N	2542	5	\N	1
1961	1997-11-06	\N	\N	f	\N	\N	1	\N	261	2	1899	5	\N	1
2622	1974-05-07	\N	\N	f	\N	\N	1	\N	159	\N	2554	5	\N	1
1524	1976-01-20	\N	\N	f	\N	\N	1	\N	170	\N	1444	5	\N	1
1528	1976-01-27	\N	\N	f	\N	\N	1	\N	171	\N	1449	5	\N	1
1543	1977-01-10	\N	\N	f	\N	\N	1	\N	176	\N	1465	5	\N	1
1571	1978-05-19	\N	\N	f	\N	\N	1	\N	180	\N	1494	5	\N	1
1601	1979-09-27	\N	\N	f	\N	\N	1	\N	186	\N	1525	5	\N	1
1612	1981-02-02	\N	\N	f	\N	\N	1	\N	189	\N	1538	5	\N	1
1625	1981-07-21	\N	\N	f	\N	\N	1	\N	191	\N	1554	5	\N	1
1653	1983-06-16	\N	\N	f	\N	\N	1	\N	\N	\N	1579	5	\N	1
1661	1983-09-12	\N	\N	f	\N	\N	1	\N	200	\N	1587	5	\N	1
1667	1983-09-28	\N	\N	f	\N	\N	1	\N	200	\N	1593	5	\N	1
1681	1984-10-10	\N	\N	f	\N	\N	1	\N	\N	\N	1605	5	\N	1
2637	1985-05-17	\N	\N	f	\N	\N	1	\N	203	\N	2570	5	\N	1
1715	1987-07-14	\N	\N	f	\N	\N	1	\N	209	\N	1641	5	\N	1
1728	1987-11-16	\N	\N	f	\N	\N	1	\N	211	\N	1655	5	\N	1
1743	1989-07-25	\N	\N	f	\N	\N	1	\N	216	\N	1672	5	\N	1
1756	1990-05-29	\N	\N	f	\N	\N	1	\N	218	\N	1684	5	\N	1
1784	1990-06-01	\N	\N	f	\N	\N	1	\N	218	\N	1686	5	\N	1
1803	1992-07-03	\N	\N	f	\N	\N	1	\N	230	\N	1733	5	\N	1
1818	1992-07-28	\N	\N	f	\N	\N	1	\N	230	\N	1748	5	\N	1
1833	1993-10-05	\N	\N	f	\N	\N	1	\N	237	\N	1763	5	\N	1
1848	1994-10-10	\N	\N	f	\N	\N	1	\N	241	\N	1784	5	\N	1
1878	1996-10-02	\N	\N	f	\N	\N	1	\N	253	\N	1811	5	\N	1
1892	1997-06-05	\N	\N	f	\N	\N	1	\N	256	2	1831	5	\N	1
1946	1997-10-24	\N	\N	f	\N	\N	2	\N	261	3	1880	5	\N	1
2017	1999-07-27	\N	\N	f	\N	\N	1	\N	270	2	1961	5	\N	1
2133	2001-07-13	\N	\N	f	\N	\N	1	\N	280	\N	2063	5	\N	1
2178	2004-06-02	\N	\N	f	\N	\N	2	\N	295	3	2117	5	\N	1
2193	2005-06-27	\N	\N	f	\N	\N	2	\N	301	3	2139	5	\N	1
2226	2006-06-12	\N	\N	f	\N	\N	1	\N	307	2	2168	5	\N	1
2288	2007-03-26	\N	\N	f	\N	\N	1	\N	321	\N	2240	5	\N	1
2289	2007-03-27	\N	\N	f	\N	\N	1	\N	321	\N	2241	5	\N	1
2266	2007-10-17	\N	\N	f	\N	\N	1	\N	325	\N	2210	5	\N	1
2267	2008-05-28	\N	\N	f	\N	\N	1	\N	327	\N	2212	5	\N	1
2268	2008-05-29	\N	\N	f	\N	\N	1	\N	327	\N	2213	5	\N	1
2271	2008-10-15	\N	\N	f	\N	\N	1	\N	330	\N	2217	5	\N	1
2272	2008-10-16	\N	\N	f	\N	\N	1	\N	330	\N	2218	5	\N	1
2273	2008-11-03	\N	\N	f	\N	\N	1	\N	331	\N	2219	5	\N	1
2291	2008-11-10	\N	\N	f	\N	\N	1	\N	331	\N	2220	5	\N	1
2274	2009-02-02	\N	\N	f	\N	\N	1	\N	332	\N	2221	5	\N	1
2276	2009-05-29	\N	\N	f	\N	\N	1	\N	334	\N	2223	5	\N	1
2277	2009-06-27	\N	\N	f	\N	\N	1	\N	335	\N	2224	5	\N	1
2278	2009-06-29	\N	\N	f	\N	\N	1	\N	333	\N	2225	5	\N	1
2279	2009-07-20	\N	\N	f	\N	\N	1	\N	337	\N	2227	5	\N	1
2280	2009-09-01	\N	\N	f	\N	\N	1	\N	338	\N	2228	5	\N	1
2282	2010-03-19	\N	\N	f	\N	\N	1	\N	339	\N	2231	5	\N	1
2283	2010-03-22	\N	\N	f	\N	\N	1	\N	339	\N	2232	5	\N	1
2294	2010-03-23	\N	\N	f	\N	\N	1	\N	339	\N	2233	5	\N	1
2285	2010-05-27	\N	\N	f	\N	\N	1	\N	340	\N	2235	5	\N	1
2286	2010-05-28	\N	\N	f	\N	\N	1	\N	341	\N	2236	5	\N	1
2287	2010-05-29	\N	\N	f	\N	\N	1	\N	340	\N	2237	5	\N	1
2819	2018-06-19	\N	\N	f	\N	\N	1	\N	367	2	2735	5	\N	1
1934	1997-10-18	\N	\N	f	\N	\N	1	\N	261	\N	1870	5	\N	1
2377	2010-12-22	\N	\N	f	\N	\N	1	\N	343	2	2314	5	\N	1
2745	2011-01-12	\N	\N	f	\N	\N	1	\N	343	2	2678	5	\N	1
2414	2011-01-26	\N	\N	f	\N	\N	1	\N	343	2	2339	5	\N	1
2385	2011-01-18	\N	\N	f	\N	\N	2	\N	343	3	2330	5	\N	1
2675	2015-10-09	\N	\N	f	\N	\N	1	\N	349	2	2614	5	\N	1
2461	2014-09-12	\N	\N	f	\N	\N	1	\N	345	2	2389	5	\N	1
2503	2016-08-30	\N	\N	f	\N	\N	1	\N	361	2	2411	5	\N	1
1330	1965-05-14	\N	\N	f	\N	\N	1	\N	118	2	1245	5	\N	1
1306	1964-12-22	\N	\N	f	\N	\N	2	\N	115	3	1223	5	\N	1
2477	2013-09-18	\N	\N	f	\N	\N	2	\N	317	3	2428	5	\N	1
1586	1979-07-10	\N	\N	f	\N	\N	2	\N	185	3	1511	5	\N	1
2909	1992-04-24	\N	\N	f	\N	\N	2	\N	228	3	1723	5	\N	1
1889	1997-05-16	\N	\N	f	\N	\N	2	\N	257	3	1827	5	\N	1
1907	1997-06-11	\N	\N	f	\N	\N	1	\N	256	2	1839	5	\N	1
1922	1997-09-26	\N	\N	f	\N	\N	1	\N	261	2	1855	5	\N	1
2652	1997-10-06	\N	\N	f	\N	\N	2	\N	261	3	2585	5	\N	1
2480	2013-10-03	\N	\N	f	\N	\N	1	\N	317	2	2432	5	\N	1
2922	1997-10-27	\N	\N	f	\N	\N	2	\N	261	3	1884	5	\N	1
1991	1997-10-29	\N	\N	f	\N	\N	2	\N	260	3	1927	5	\N	1
1984	1998-07-18	\N	\N	f	\N	\N	2	\N	265	3	1910	5	\N	1
1993	1998-08-04	\N	\N	f	\N	\N	2	\N	265	3	1931	5	\N	1
1975	1998-07-25	\N	\N	f	\N	\N	1	\N	265	2	1918	5	\N	1
2010	1999-07-20	\N	\N	f	\N	\N	2	\N	270	3	1953	5	\N	1
1960	1997-11-05	\N	\N	f	\N	\N	2	\N	261	3	1898	5	\N	1
2685	1999-07-30	\N	\N	f	\N	\N	2	\N	270	3	2590	5	\N	1
2821	1999-11-16	\N	\N	t	Longford	7th Earl 	4	\N	272	11	2693	5	3	1
2530	2018-06-21	\N	\N	f	\N	\N	2	\N	367	3	2461	5	\N	1
47	1807-11-04	\N	\N	f	Lake	1st Lord	1	\N	\N	\N	19	5	\N	11
2168	2004-06-08	\N	\N	f	\N	\N	1	\N	295	2	2083	5	\N	1
2158	2004-06-25	\N	\N	f	\N	\N	1	\N	295	2	2106	5	\N	1
2829	2005-06-16	\N	\N	f	\N	\N	2	\N	301	3	2746	5	\N	1
2141	2004-06-04	\N	\N	f	\N	\N	2	\N	295	3	2080	5	\N	1
2258	2006-06-02	\N	\N	f	\N	\N	2	\N	307	3	2159	5	\N	1
2348	2010-07-20	\N	\N	f	\N	\N	1	\N	350	2	2296	5	\N	1
2361	2010-12-20	\N	\N	f	\N	\N	1	\N	343	2	2311	5	\N	1
2421	2015-10-08	\N	\N	f	\N	\N	2	\N	349	3	2360	5	\N	1
2376	2010-12-24	\N	\N	f	\N	\N	1	\N	343	2	2318	5	\N	1
2391	2011-01-25	\N	\N	f	\N	\N	2	\N	343	3	2338	5	\N	1
2239	2013-09-05	\N	\N	f	\N	\N	1	\N	317	2	2185	5	\N	1
2423	2011-01-31	\N	\N	f	\N	\N	2	\N	343	3	2345	5	\N	1
2394	2011-02-01	\N	\N	f	\N	\N	1	\N	343	2	2346	5	\N	1
2451	2015-10-20	\N	\N	f	\N	\N	2	\N	349	3	2382	5	\N	1
2367	2015-09-28	\N	\N	f	\N	\N	1	\N	349	2	2322	5	\N	1
2441	2014-09-23	\N	\N	f	\N	\N	1	\N	345	2	2400	5	\N	1
2910	2014-09-16	\N	\N	f	\N	\N	1	\N	345	2	2391	5	\N	1
2473	2013-09-13	\N	\N	f	\N	\N	1	\N	317	2	2421	5	\N	1
2494	2013-10-03	\N	\N	f	\N	\N	2	\N	317	3	2433	5	\N	1
2466	2016-08-31	\N	\N	f	\N	\N	2	\N	361	3	2413	5	\N	1
2543	2019-10-16	\N	\N	f	\N	\N	2	\N	372	3	2480	5	\N	1
2514	2019-10-08	\N	\N	f	\N	\N	1	\N	371	2	2468	5	\N	1
1941	1997-10-23	\N	\N	f	\N	\N	1	\N	261	2	1877	5	\N	1
2150	2004-06-16	\N	\N	f	\N	\N	2	\N	296	3	2094	5	\N	1
2431	2015-10-19	\N	\N	f	\N	\N	2	\N	349	3	2380	5	\N	1
2038	1999-08-06	\N	\N	f	\N	\N	1	\N	270	2	1978	5	\N	1
2405	2011-01-12	\N	\N	f	\N	\N	2	\N	343	3	2362	5	\N	1
2188	2005-06-22	\N	\N	f	\N	\N	1	\N	301	2	2132	5	\N	1
2029	1999-07-28	\N	\N	f	\N	\N	2	\N	270	3	1964	5	\N	1
121	1817-02-13	\N	\N	t	Moira	2nd Earl 	1	\N	\N	\N	116	5	3	11
2453	2014-09-18	\N	\N	f	\N	\N	1	\N	345	2	2394	5	\N	1
1323	1965-05-10	\N	\N	f	\N	\N	2	\N	118	3	1238	5	\N	1
1759	1990-07-16	\N	\N	f	\N	\N	1	\N	219	2	1689	5	\N	1
1799	1992-06-29	\N	\N	f	\N	\N	2	\N	230	3	1729	5	\N	1
2019	1997-10-30	\N	\N	f	\N	\N	1	\N	261	2	1928	5	\N	1
2471	2013-09-12	\N	\N	f	\N	\N	1	\N	317	2	2419	5	\N	1
2338	2010-07-07	\N	\N	f	\N	\N	2	\N	342	1	2260	5	\N	1
1798	1992-06-29	\N	\N	f	\N	\N	1	\N	230	2	1728	5	\N	1
1950	1997-10-28	\N	\N	f	\N	\N	1	\N	261	2	1885	5	\N	1
2716	1821-07-14	\N	\N	t	Donoughmore	1st Earl 	2	\N	\N	\N	2631	5	3	8
25	1806-02-26	\N	\N	f	\N	\N	1	\N	\N	\N	30	5	\N	11
123	1821-07-17	\N	\N	t	Ormonde and Ossory	19th Earl 	4	\N	\N	\N	86	5	3	8
93	1821-07-17	\N	\N	t	Wemyss and March	8th & 4th Earl 	5	\N	\N	\N	87	5	2	8
110	1826-07-04	\N	\N	t	Clanricarde	1st Marquess 	1	\N	\N	\N	105	5	3	8
119	1821-07-17	\N	\N	t	Ailesbury	2nd Earl	16	\N	\N	\N	114	5	\N	8
147	1831-06-17	\N	\N	t	Erroll	18th Earl 	1	\N	\N	\N	138	5	2	7
2098	1999-11-16	\N	\N	f	Windlesham	3rd Lord	6	\N	272	8	2035	5	\N	1
64	1815-08-11	\N	\N	t	Dalhousie	9th Earl 	1	\N	\N	\N	61	5	2	11
167	1831-06-04	\N	\N	f	\N	\N	1	\N	\N	\N	155	5	\N	7
156	1831-09-10	\N	\N	f	Belhaven and Stenton	8th Lord 	7	\N	\N	\N	147	5	2	7
160	1831-09-10	\N	\N	f	\N	\N	13	\N	\N	\N	151	5	\N	7
1585	1979-07-10	\N	\N	f	\N	\N	1	\N	185	2	1510	5	\N	1
207	1831-09-12	\N	\N	t	Breadalbane	4th Earl 	1	\N	\N	\N	195	5	2	7
2761	2000-04-17	\N	\N	f	Grenfell	3rd Lord	2	\N	274	3	2686	5	\N	1
2073	2000-05-11	\N	\N	f	\N	\N	2	\N	274	3	2015	5	\N	1
2103	2001-06-28	\N	\N	f	\N	\N	2	\N	278	3	2041	5	\N	1
2112	2001-07-05	\N	\N	f	\N	\N	1	\N	280	2	2051	5	\N	1
239	1841-08-16	\N	\N	t	Stair	8th Earl 	2	\N	\N	\N	213	5	2	6
58	1814-06-01	\N	\N	f	Keith	1st Lord	1	\N	\N	\N	56	5	\N	11
201	1837-01-27	\N	\N	f	Howard of Effingham	11th Lord	2	\N	\N	\N	190	5	\N	7
2798	1850-01-22	\N	\N	f	Dufferin and Claneboye	5th Lord 	1	\N	\N	\N	457	5	3	6
2052	1999-11-16	\N	\N	f	Erroll of Hale	1st Lord	2	\N	272	5	1995	5	\N	1
334	1871-08-07	\N	\N	f	Bloomfield	2nd Lord 	1	\N	\N	\N	315	5	3	6
2580	1860-03-22	\N	\N	f	Brougham and Vaux	1st Lord	1	\N	\N	\N	137	5	\N	6
35	1802-06-19	\N	\N	t	Downshire	Marchioness	1	\N	\N	\N	15	5	\N	11
1341	1964-12-18	\N	\N	f	\N	\N	1	\N	115	2	1258	5	\N	1
2357	2010-12-17	\N	\N	f	\N	\N	1	\N	343	2	2307	5	\N	1
958	1937-06-01	\N	\N	t	Strathmore and Kinghorne	14th Earl 	1	\N	44	\N	894	5	2	2
521	1898-01-19	\N	\N	f	Halsbury	1st Lord	1	\N	\N	\N	386	5	\N	6
556	1901-08-06	\N	\N	f	Cromer	1st Viscount	1	\N	\N	\N	440	5	\N	5
802	1926-01-19	\N	\N	f	Oranmore and Browne	3rd Lord 	1	\N	19	\N	747	5	3	4
627	1911-07-05	\N	\N	f	Brassey	1st Lord	1	\N	\N	\N	409	5	\N	4
693	1917-06-23	\N	\N	f	Astor	1st Lord	1	\N	\N	\N	629	5	\N	4
745	1920-11-08	\N	\N	f	Buxton	1st Viscount	1	\N	\N	\N	614	5	\N	4
761	1921-06-28	\N	\N	f	Curzon of Kedleston	1st Earl	1	\N	9	\N	711	5	\N	4
767	1921-07-09	\N	\N	f	Pirrie	1st Lord	1	\N	\N	\N	549	5	\N	4
959	1936-05-26	\N	\N	t	Willingdon	1st Earl	1	\N	\N	\N	895	5	\N	3
786	1923-07-24	\N	\N	f	\N	\N	1	\N	12	\N	733	5	\N	4
839	1929-06-20	\N	\N	f	Inchcape	1st Viscount	1	\N	26	\N	588	5	\N	4
830	1929-03-19	\N	\N	f	\N	\N	1	\N	25	\N	776	5	\N	4
847	1929-07-10	\N	\N	f	Peel	2nd Viscount	1	\N	27	\N	790	5	\N	4
901	1935-06-24	\N	\N	f	Bledisloe	1st Lord	1	\N	40	\N	670	5	\N	4
862	1931-01-22	\N	\N	f	\N	\N	1	\N	30	\N	805	5	\N	4
872	1932-01-25	\N	\N	f	\N	\N	1	\N	32	\N	815	5	\N	4
884	1933-02-03	\N	\N	f	\N	\N	1	\N	34	\N	825	5	\N	4
892	1934-01-15	\N	\N	f	\N	\N	1	\N	36	\N	833	5	\N	4
2602	1954-07-30	\N	\N	t	Dundee	11th Earl 	1	\N	83	\N	2534	5	2	1
940	1938-01-24	\N	\N	f	Nuffield	1st Lord	1	\N	46	\N	878	5	\N	2
1046	1946-01-29	\N	\N	f	Alanbrooke	1st Lord	1	\N	65	\N	960	5	\N	2
411	1885-06-28	\N	\N	f	Henley	3rd Lord 	1	\N	\N	\N	388	5	3	6
1044	1947-05-01	\N	\N	f	Wavell	1st Viscount	1	\N	\N	\N	932	5	\N	2
955	1939-07-04	\N	\N	f	\N	\N	1	\N	49	\N	891	5	\N	2
2590	1939-07-07	\N	\N	f	\N	\N	1	\N	49	\N	1056	5	\N	2
974	1941-01-29	\N	\N	f	\N	\N	1	\N	51	\N	907	5	\N	2
982	1942-01-16	\N	\N	f	\N	\N	1	\N	53	\N	915	5	\N	2
985	1942-02-04	\N	\N	f	\N	\N	1	\N	53	\N	918	5	\N	2
1032	1944-01-31	\N	\N	f	\N	\N	1	\N	58	\N	962	5	\N	2
1012	1945-07-06	\N	\N	f	\N	\N	1	\N	61	\N	944	5	\N	2
1075	1946-01-23	\N	\N	f	\N	\N	1	\N	65	\N	1000	5	\N	2
1140	1954-01-18	\N	\N	f	Leathers	1st Lord	1	\N	82	\N	909	5	\N	1
1053	1946-03-12	\N	\N	f	\N	\N	1	\N	65	\N	978	5	\N	2
1062	1947-01-13	\N	\N	f	\N	\N	1	\N	67	\N	988	5	\N	2
436	1887-07-01	\N	\N	t	Strathmore and Kinghorne	13th Earl 	2	\N	\N	\N	415	5	2	6
1084	1948-06-24	\N	\N	f	\N	\N	1	\N	70	\N	1008	5	\N	2
1095	1950-02-02	\N	\N	f	\N	\N	1	\N	73	\N	1019	5	\N	2
1107	1951-01-25	\N	\N	f	\N	\N	1	\N	75	\N	1031	5	\N	2
1131	1953-02-12	\N	\N	f	\N	\N	1	\N	80	\N	1052	5	\N	1
1196	1958-10-06	\N	\N	f	Ravensdale	2nd Baroness	1	\N	284	\N	1112	5	\N	1
1253	1962-07-11	\N	\N	f	Radcliffe	Lord	1	\N	103	\N	1172	5	\N	1
1171	1957-07-01	\N	\N	f	\N	\N	1	\N	89	\N	1089	5	\N	1
1185	1958-08-04	\N	\N	f	\N	\N	1	\N	284	\N	1103	5	\N	1
1272	1962-07-20	\N	\N	f	Kilmuir	1st Viscount	1	\N	\N	\N	1069	5	\N	1
1208	1959-11-20	\N	\N	f	\N	\N	1	\N	95	\N	1125	5	\N	1
1218	1960-07-15	\N	\N	f	\N	\N	1	\N	97	\N	1136	5	\N	1
1239	1962-01-25	\N	\N	f	\N	\N	1	\N	101	\N	1157	5	\N	1
1251	1962-05-15	\N	\N	f	\N	\N	1	\N	102	\N	1170	5	\N	1
1504	1975-01-24	\N	\N	f	Balniel	Lord	1	\N	166	\N	1427	5	\N	1
1274	1964-01-13	\N	\N	f	Davidson	Viscountess	1	\N	107	\N	1185	5	\N	1
2776	1964-04-20	\N	\N	f	\N	\N	1	\N	109	\N	2697	5	\N	1
1285	1964-08-22	\N	\N	f	\N	\N	1	\N	113	\N	1200	5	\N	1
1297	1964-12-11	\N	\N	f	\N	\N	1	\N	114	\N	1213	5	\N	1
598	1909-05-12	\N	\N	t	Desart	5th Earl 	1	\N	\N	\N	566	5	3	5
1311	1964-12-31	\N	\N	f	\N	\N	1	\N	114	\N	1228	5	\N	1
1378	1966-05-27	\N	\N	f	\N	\N	1	\N	121	\N	1297	5	\N	1
1350	1966-06-24	\N	\N	f	\N	\N	1	\N	122	\N	1267	5	\N	1
1361	1967-07-07	\N	\N	f	\N	\N	1	\N	124	\N	1278	5	\N	1
1369	1967-09-14	\N	\N	f	\N	\N	1	\N	125	\N	1287	5	\N	1
1375	1967-10-13	\N	\N	f	\N	\N	1	\N	125	\N	1294	5	\N	1
1417	1967-12-04	\N	\N	f	\N	\N	1	\N	127	\N	1335	5	\N	1
1382	1968-01-29	\N	\N	f	\N	\N	1	\N	128	\N	1301	5	\N	1
1398	1969-03-24	\N	\N	f	\N	\N	1	\N	133	\N	1314	5	\N	1
1415	1970-07-28	\N	\N	f	\N	\N	1	\N	138	\N	1333	5	\N	1
2786	1970-09-22	\N	\N	f	\N	\N	1	\N	140	\N	2703	5	\N	1
1435	1971-05-21	\N	\N	f	\N	\N	1	\N	145	\N	1353	5	\N	1
1441	1972-04-24	\N	\N	f	\N	\N	1	\N	149	\N	1361	5	\N	1
1442	1972-04-26	\N	\N	f	\N	\N	1	\N	149	\N	1362	5	\N	1
2724	1972-07-10	\N	\N	f	\N	\N	1	\N	150	\N	2652	5	\N	1
1474	1973-06-18	\N	\N	f	\N	\N	1	\N	153	\N	1371	5	\N	1
1497	1974-03-11	\N	\N	f	\N	\N	1	\N	156	\N	1418	5	\N	1
1478	1974-06-24	\N	\N	f	\N	\N	1	\N	161	\N	1396	5	\N	1
1484	1974-07-04	\N	\N	f	\N	\N	1	\N	161	\N	1404	5	\N	1
1493	1975-01-06	\N	\N	f	\N	\N	1	\N	166	\N	1414	5	\N	1
2927	1975-01-23	\N	\N	f	\N	\N	1	\N	166	\N	1426	5	\N	1
1516	1975-07-15	\N	\N	f	\N	\N	1	\N	168	\N	1436	5	\N	1
1527	1976-01-23	\N	\N	f	\N	\N	1	\N	170	\N	1447	5	\N	1
1536	1976-06-24	\N	\N	f	\N	\N	1	\N	173	\N	1457	5	\N	1
1542	1976-09-23	\N	\N	f	\N	\N	1	\N	175	\N	1463	5	\N	1
1557	1978-02-09	\N	\N	f	\N	\N	1	\N	179	\N	1478	5	\N	1
1560	1978-04-17	\N	\N	f	\N	\N	1	\N	180	\N	1482	5	\N	1
1568	1978-05-05	\N	\N	f	\N	\N	1	\N	180	\N	1491	5	\N	1
1575	1979-02-02	\N	\N	f	\N	\N	1	\N	182	\N	1500	5	\N	1
1583	1979-07-06	\N	\N	f	\N	\N	1	\N	186	\N	1508	5	\N	1
1599	1979-08-07	\N	\N	f	\N	\N	1	\N	186	\N	1523	5	\N	1
1607	1980-02-14	\N	\N	f	\N	\N	1	\N	187	\N	1533	5	\N	1
2728	1980-07-22	\N	\N	f	\N	\N	1	\N	188	\N	2656	5	\N	1
1623	1981-07-06	\N	\N	f	\N	\N	1	\N	191	\N	1552	5	\N	1
1638	1982-05-21	\N	\N	f	\N	\N	1	\N	192	\N	1561	5	\N	1
1640	1982-07-20	\N	\N	f	\N	\N	1	\N	194	\N	1564	5	\N	1
1651	1983-03-28	\N	\N	f	\N	\N	1	\N	197	\N	1577	5	\N	1
1662	1983-09-14	\N	\N	f	\N	\N	1	\N	200	\N	1588	5	\N	1
1673	1983-10-07	\N	\N	f	\N	\N	1	\N	200	\N	1597	5	\N	1
1702	1987-02-03	\N	\N	f	\N	\N	1	\N	207	\N	1628	5	\N	1
1703	1987-02-09	\N	\N	f	\N	\N	1	\N	207	\N	1629	5	\N	1
1746	1987-04-07	\N	\N	f	\N	\N	1	\N	208	\N	1639	5	\N	1
1722	1987-10-13	\N	\N	f	\N	\N	1	\N	211	\N	1648	5	\N	1
1730	1988-02-05	\N	\N	f	\N	\N	1	\N	212	\N	1657	5	\N	1
1737	1989-01-09	\N	\N	f	\N	\N	1	\N	214	\N	1665	5	\N	1
1750	1990-05-08	\N	\N	f	\N	\N	1	\N	218	\N	1676	5	\N	1
1781	1990-06-11	\N	\N	f	\N	\N	1	\N	218	\N	1687	5	\N	1
1770	1991-06-05	\N	\N	f	\N	\N	1	\N	222	\N	1701	5	\N	1
1774	1991-07-15	\N	\N	f	\N	\N	1	\N	223	\N	1710	5	\N	1
1790	1992-01-30	\N	\N	f	\N	\N	1	\N	226	\N	1718	5	\N	1
2641	1992-06-30	\N	\N	f	\N	\N	1	\N	230	2	2576	5	\N	1
1836	1992-07-01	\N	\N	f	\N	\N	1	\N	230	2	1769	5	\N	1
1813	1992-07-18	\N	\N	f	\N	\N	1	\N	230	\N	1743	5	\N	1
1821	1992-08-11	\N	\N	f	\N	\N	1	\N	232	\N	1752	5	\N	1
2824	1992-08-12	\N	\N	f	\N	\N	1	\N	231	\N	2739	5	\N	1
1830	1993-07-30	\N	\N	f	\N	\N	1	\N	235	\N	1760	5	\N	1
1876	1994-03-22	\N	\N	f	\N	\N	1	\N	238	\N	1809	5	\N	1
1866	1995-12-20	\N	\N	f	\N	\N	1	\N	247	\N	1797	5	\N	1
1906	1996-01-16	\N	\N	f	\N	\N	1	\N	247	\N	1803	5	\N	1
1872	1996-02-21	\N	\N	f	\N	\N	1	\N	249	\N	1805	5	\N	1
1881	1996-10-09	\N	\N	f	\N	\N	1	\N	253	\N	1815	5	\N	1
1886	1997-05-14	\N	\N	f	\N	\N	1	\N	256	2	1824	5	\N	1
2651	1997-07-21	\N	\N	f	\N	\N	2	\N	256	3	2584	5	\N	1
1964	1997-11-24	\N	\N	f	\N	\N	1	\N	256	\N	1902	5	\N	1
1996	1998-10-02	\N	\N	f	\N	\N	1	\N	266	\N	1934	5	\N	1
2069	2000-02-16	\N	\N	f	\N	\N	1	\N	273	\N	2008	5	\N	1
2136	2001-06-22	\N	\N	f	\N	\N	1	\N	280	2	2074	5	\N	1
2135	2001-07-14	\N	\N	f	\N	\N	1	\N	280	\N	2058	5	\N	1
2126	2002-10-01	\N	\N	f	\N	\N	1	\N	288	\N	2067	5	\N	1
2180	2005-06-10	\N	\N	f	\N	\N	1	\N	301	\N	2120	5	\N	1
2293	2007-10-16	\N	\N	f	\N	\N	1	\N	325	\N	2209	5	\N	1
2270	2008-10-01	\N	\N	f	\N	\N	1	\N	329	\N	2216	5	\N	1
2275	2009-04-21	\N	\N	f	\N	\N	1	\N	333	\N	2222	5	\N	1
2281	2009-08-25	\N	\N	f	\N	\N	1	\N	\N	\N	2230	5	\N	1
2284	2010-03-24	\N	\N	f	\N	\N	1	\N	339	\N	2234	5	\N	1
2743	2010-06-24	\N	\N	f	\N	\N	1	\N	342	2	2676	5	\N	1
2915	2010-12-21	\N	\N	f	\N	\N	2	\N	343	3	2313	5	\N	1
2490	2017-11-07	\N	\N	f	\N	\N	1	\N	365	2	2452	5	\N	1
2713	2019-10-07	\N	\N	f	\N	\N	1	\N	372	2	2620	5	\N	1
2569	2020-01-07	\N	\N	f	\N	\N	1	\N	375	\N	2515	5	\N	1
2522	2020-01-11	\N	\N	f	\N	\N	1	\N	376	\N	2484	5	\N	1
192	1838-07-06	\N	\N	f	Lismore	1st Viscount 	1	\N	\N	\N	183	5	3	6
259	1856-03-12	\N	\N	t	Kenmare	3rd Earl 	1	\N	\N	\N	242	5	3	6
339	1873-03-25	\N	\N	t	Breadalbane	7th Earl 	1	\N	\N	\N	320	5	2	6
297	1866-05-02	\N	\N	f	Clermont	1st Lord 	1	\N	\N	\N	278	5	3	6
318	1869-06-29	\N	\N	f	Rollo	10th Lord 	1	\N	\N	\N	300	5	2	6
384	1881-10-06	\N	\N	t	Tweeddale	10th Marquess 	1	\N	\N	\N	365	5	2	6
403	1880-04-17	\N	\N	f	Barrington	7th Viscount 	1	\N	\N	\N	350	5	3	6
406	1884-11-07	\N	\N	t	Arran	5th Earl 	1	\N	\N	\N	383	5	3	6
1142	1954-01-30	\N	\N	t	Drogheda	10th Earl 	1	\N	82	\N	1062	5	3	1
433	1886-09-09	\N	\N	f	Hawarden	4th Viscount 	1	\N	\N	\N	412	5	3	6
624	1911-07-03	\N	\N	f	Elibank	10th Lord 	3	\N	\N	\N	592	5	2	4
758	1920-02-02	\N	\N	f	Midleton	9th Viscount 	1	\N	6	\N	709	5	3	4
2061	1999-11-16	\N	\N	t	Snowdon	1st Earl	3	\N	272	7	1996	5	\N	1
477	1888-11-17	\N	\N	t	Dufferin	1st Earl	1	\N	\N	\N	457	5	\N	6
32	1801-06-22	\N	\N	f	Romney	3rd Lord	1	\N	\N	\N	37	5	\N	11
76	1812-09-07	\N	\N	f	Mulgrave	1st Lord & 3rd Lord	3	\N	\N	\N	72	5	\N	11
116	1821-07-14	\N	\N	f	Falmouth	4th Viscount	1	\N	\N	\N	111	5	\N	8
243	1841-08-16	\N	\N	f	Barham	3rd Lord	1	\N	\N	\N	229	5	\N	6
496	1895-08-03	\N	\N	f	Knutsford	1st Lord	1	\N	\N	\N	426	5	\N	6
220	1839-05-15	\N	\N	f	\N	\N	1	\N	\N	\N	206	5	\N	6
507	1897-07-22	\N	\N	f	Egerton	2nd Lord	1	\N	\N	\N	482	5	\N	6
678	1917-01-02	\N	\N	f	Cowdray	1st Lord	1	\N	\N	\N	576	5	\N	4
691	1917-06-22	\N	\N	f	Devonport	1st Lord	1	\N	\N	\N	575	5	\N	4
791	1924-01-21	\N	\N	f	Inchcape	1st Lord	1	\N	13	\N	588	5	\N	4
1042	1946-01-25	\N	\N	f	Southwood	1st Lord	1	\N	65	\N	876	5	\N	2
66	1815-08-11	\N	\N	t	Glasgow	4th Earl 	3	\N	\N	\N	63	5	2	11
275	1859-04-14	\N	\N	f	\N	\N	1	\N	\N	\N	258	5	\N	6
283	1861-08-05	\N	\N	f	\N	\N	1	\N	\N	\N	266	5	\N	6
311	1868-04-18	\N	\N	f	\N	\N	1	\N	\N	\N	292	5	\N	6
364	1871-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	314	5	\N	6
418	1885-07-06	\N	\N	f	\N	\N	1	\N	\N	\N	395	5	\N	6
442	1886-02-17	\N	\N	f	\N	\N	1	\N	\N	\N	403	5	\N	6
481	1892-08-26	\N	\N	f	\N	\N	1	\N	\N	\N	445	5	\N	6
486	1893-09-23	\N	\N	f	\N	\N	1	\N	\N	\N	462	5	\N	6
526	1899-08-22	\N	\N	f	\N	\N	1	\N	\N	\N	499	5	\N	6
536	1901-06-03	\N	\N	f	\N	\N	1	\N	\N	\N	508	5	\N	5
548	1903-08-03	\N	\N	f	\N	\N	1	\N	\N	\N	520	5	\N	5
564	1905-12-23	\N	\N	f	\N	\N	1	\N	\N	\N	532	5	\N	5
577	1906-01-09	\N	\N	f	\N	\N	1	\N	282	\N	545	5	\N	5
583	1906-07-19	\N	\N	f	\N	\N	1	\N	\N	\N	551	5	\N	5
593	1908-07-02	\N	\N	f	\N	\N	1	\N	\N	\N	561	5	\N	5
604	1910-04-27	\N	\N	f	\N	\N	1	\N	\N	\N	572	5	\N	5
614	1911-03-27	\N	\N	f	\N	\N	1	\N	\N	\N	582	5	\N	4
639	1912-12-10	\N	\N	f	\N	\N	1	\N	\N	\N	604	5	\N	4
648	1914-01-17	\N	\N	f	\N	\N	1	\N	\N	\N	612	5	\N	4
659	1915-06-28	\N	\N	f	\N	\N	1	\N	\N	\N	623	5	\N	4
720	1917-07-18	\N	\N	f	\N	\N	1	\N	\N	\N	675	5	\N	4
717	1918-11-16	\N	\N	f	\N	\N	1	\N	\N	\N	672	5	\N	4
733	1919-10-06	\N	\N	f	\N	\N	1	\N	\N	\N	685	5	\N	4
841	1928-05-08	\N	\N	f	\N	\N	1	\N	\N	\N	770	5	\N	4
856	1930-06-17	\N	\N	f	\N	\N	1	\N	29	\N	799	5	\N	4
914	1935-12-20	\N	\N	f	\N	\N	1	\N	\N	\N	853	5	\N	4
968	1940-06-27	\N	\N	f	\N	\N	1	\N	50	\N	902	5	\N	2
990	1942-04-27	\N	\N	f	\N	\N	1	\N	\N	\N	923	5	\N	2
1109	1951-02-07	\N	\N	f	\N	\N	1	\N	75	\N	1033	5	\N	2
1	1801-01-20	\N	\N	t	Ormond and Ossory	18th Earl 	1	\N	\N	\N	1	5	3	11
6	1801-07-31	\N	\N	f	Saint Helens	1st Lord 	1	\N	\N	\N	7	5	3	11
2772	1934-06-26	\N	\N	t	Lucan	5th Earl 	1	\N	37	\N	2695	5	3	4
2741	1866-08-31	\N	\N	f	Boyne	7th Viscount 	1	\N	\N	\N	2670	5	3	6
178	1835-01-10	\N	\N	f	Fitz Gerald and Vesey	2nd Lord 	1	\N	\N	\N	168	5	3	7
2043	2000-04-19	\N	\N	t	Mar and Kellie	Earl	2	\N	274	6	1984	5	\N	1
2042	2000-04-19	\N	\N	f	Chandos	3rd Viscount	1	\N	274	4	1983	5	\N	1
67	1815-08-11	\N	\N	t	Enniskillen	2nd Earl 	4	\N	\N	\N	64	5	3	11
1167	1956-06-26	\N	\N	f	Cherwell	1st Lord	1	\N	87	\N	1085	5	\N	1
2691	1806-02-21	\N	\N	t	Eglinton	12th Earl 	1	\N	\N	\N	2628	5	2	11
2099	1999-11-17	\N	\N	f	Cecil	Lord	3	\N	272	5	2036	5	\N	1
2070	2000-04-17	\N	\N	f	Acton	4th Lord	1	\N	274	2	2009	5	\N	1
2051	1999-11-16	\N	\N	f	Aldington	1st Lord	1	\N	272	6	1994	5	\N	1
2356	2010-11-22	\N	\N	t	Lothian	13th Marquess 	1	\N	354	\N	2306	5	2	1
1211	1960-01-20	\N	\N	f	Rochdale	2nd Lord	1	\N	96	\N	1129	5	\N	1
1257	1962-08-22	\N	\N	f	Mills	1st Lord	1	\N	\N	\N	1090	5	\N	1
1340	1964-12-17	\N	\N	f	\N	\N	2	\N	115	3	1257	5	\N	1
2576	1922-11-27	\N	\N	f	Leverhulme	1st Lord	1	\N	\N	\N	650	5	\N	4
2870	1945-01-08	\N	\N	f	Gowrie	1st Lord	1	\N	\N	\N	853	5	\N	2
2771	1926-02-20	\N	\N	f	D'Abernon	1st Lord	1	\N	19	\N	616	5	\N	4
2837	1925-06-29	\N	\N	f	Jellicoe	1st Viscount	1	\N	17	\N	2641	5	\N	4
284	1850-06-11	\N	\N	f	Cottenham	1st Lord	1	\N	\N	\N	177	5	\N	6
348	1874-02-27	\N	\N	f	Sydney	3rd Viscount	2	\N	\N	\N	328	5	\N	6
567	1905-12-28	\N	\N	f	Tredegar	2nd Lord	1	\N	\N	\N	535	5	\N	5
641	1912-02-26	\N	\N	f	Carrington	1st Earl	1	\N	\N	\N	606	5	\N	4
732	1918-06-17	\N	\N	f	St Davids	1st Lord	1	\N	3	\N	564	5	\N	4
2933	1876-01-15	\N	\N	f	Wharncliffe	3rd Lord	1	\N	\N	\N	2784	5	\N	6
714	1918-09-02	\N	\N	f	Bertie of Thame	1st Lord	1	\N	\N	\N	623	5	\N	4
2777	1911-07-03	\N	\N	t	Rosebery	5th Earl 	2	\N	\N	\N	2698	5	2	4
1301	1964-12-16	\N	\N	f	\N	\N	1	\N	115	2	1217	5	\N	1
1395	1966-09-19	\N	\N	f	\N	\N	1	\N	122	\N	1272	5	\N	1
1589	1979-07-12	\N	\N	f	\N	\N	2	\N	185	3	1515	5	\N	1
1657	1983-07-11	\N	\N	f	\N	\N	1	\N	\N	\N	1583	5	\N	1
1680	1984-06-08	\N	\N	f	\N	\N	1	\N	\N	\N	1604	5	\N	1
1794	1992-04-24	\N	\N	f	\N	\N	1	\N	228	2	1722	5	\N	1
1894	1997-06-06	\N	\N	f	\N	\N	1	\N	256	2	1833	5	\N	1
1909	1997-06-12	\N	\N	f	\N	\N	1	\N	256	2	1841	5	\N	1
1924	1997-09-27	\N	\N	f	\N	\N	1	\N	261	2	1857	5	\N	1
1933	1997-10-04	\N	\N	f	\N	\N	2	\N	261	3	1868	5	\N	1
1937	1997-10-21	\N	\N	f	\N	\N	1	\N	261	2	1873	5	\N	1
1935	1997-10-20	\N	\N	f	\N	\N	1	\N	261	2	1871	5	\N	1
1962	1997-11-06	\N	\N	f	\N	\N	2	\N	261	3	1900	5	\N	1
1983	1998-07-23	\N	\N	f	\N	\N	2	\N	265	3	1915	5	\N	1
1987	1998-07-29	\N	\N	f	\N	\N	1	\N	265	2	1923	5	\N	1
2006	1999-07-16	\N	\N	f	\N	\N	1	\N	270	2	1949	5	\N	1
2063	1999-07-30	\N	\N	f	\N	\N	1	\N	270	2	1999	5	\N	1
2107	2001-07-02	\N	\N	f	\N	\N	2	\N	280	3	2046	5	\N	1
2140	2004-06-04	\N	\N	f	\N	\N	1	\N	295	2	2079	5	\N	1
2172	2004-06-17	\N	\N	f	\N	\N	1	\N	296	2	2095	5	\N	1
2157	2004-06-23	\N	\N	f	\N	\N	1	\N	295	2	2102	5	\N	1
2147	2004-06-14	\N	\N	f	\N	\N	2	\N	295	3	2090	5	\N	1
2186	2005-06-20	\N	\N	f	\N	\N	1	\N	301	2	2128	5	\N	1
2456	2015-09-30	\N	\N	f	\N	\N	2	\N	349	3	2371	5	\N	1
2381	2010-12-21	\N	\N	f	\N	\N	1	\N	343	2	2312	5	\N	1
2371	2011-01-15	\N	\N	f	\N	\N	1	\N	343	2	2326	5	\N	1
2362	2010-12-23	\N	\N	f	\N	\N	1	\N	343	2	2316	5	\N	1
2422	2011-01-28	\N	\N	f	\N	\N	1	\N	343	2	2343	5	\N	1
2408	2015-10-13	\N	\N	f	\N	\N	2	\N	349	3	2365	5	\N	1
2392	2011-01-27	\N	\N	f	\N	\N	2	\N	343	3	2342	5	\N	1
2402	2015-10-06	\N	\N	f	\N	\N	1	\N	349	2	2355	5	\N	1
2443	2015-10-12	\N	\N	f	\N	\N	2	\N	349	3	2404	5	\N	1
2455	2014-09-19	\N	\N	f	\N	\N	1	\N	345	2	2396	5	\N	1
2536	2016-09-06	\N	\N	f	\N	\N	2	\N	361	3	2481	5	\N	1
2474	2013-09-13	\N	\N	f	\N	\N	2	\N	317	3	2422	5	\N	1
2544	2019-10-08	\N	\N	f	\N	\N	2	\N	371	3	2469	5	\N	1
2546	2019-10-14	\N	\N	f	\N	\N	1	\N	372	2	2476	5	\N	1
2476	2013-09-17	\N	\N	f	\N	\N	1	\N	317	2	2425	5	\N	1
2562	1896-06-09	\N	\N	f	\N	\N	1	\N	\N	\N	2508	5	\N	6
2731	1992-06-30	\N	\N	f	\N	\N	2	\N	230	3	2660	5	\N	1
2670	2010-07-10	\N	\N	f	\N	\N	1	\N	342	2	2607	5	\N	1
2677	2014-09-17	\N	\N	f	\N	\N	2	\N	345	3	2616	5	\N	1
2838	1997-10-01	\N	\N	f	\N	\N	1	\N	261	2	2757	5	\N	1
2896	1964-12-21	\N	\N	f	\N	\N	2	\N	115	3	2700	5	\N	1
456	1891-07-15	\N	\N	f	\N	\N	1	\N	\N	\N	433	5	\N	6
535	1900-12-19	\N	\N	f	\N	\N	1	\N	\N	\N	507	5	\N	6
1249	1962-05-11	\N	\N	f	\N	\N	1	\N	102	\N	1168	5	\N	1
1921	1997-09-25	\N	\N	f	\N	\N	2	\N	261	3	1854	5	\N	1
2343	2010-07-13	\N	\N	f	\N	\N	1	\N	342	2	2286	5	\N	1
2492	2016-09-05	\N	\N	f	\N	\N	1	\N	361	2	2440	5	\N	1
1930	1997-10-02	\N	\N	f	\N	\N	2	\N	260	3	1865	5	\N	1
2842	1999-07-21	\N	\N	f	\N	\N	2	\N	270	3	2744	5	\N	1
2662	2004-06-14	\N	\N	f	\N	\N	1	\N	295	2	2598	5	\N	1
2406	2011-01-13	\N	\N	f	\N	\N	1	\N	343	2	2363	5	\N	1
2436	2014-09-11	\N	\N	f	\N	\N	1	\N	345	2	2387	5	\N	1
2082	2000-05-04	\N	\N	f	\N	\N	2	\N	274	3	2027	5	\N	1
2845	2010-06-25	\N	\N	f	\N	\N	2	\N	342	3	2731	5	\N	1
2177	2004-06-01	\N	\N	f	\N	\N	2	\N	295	3	2116	5	\N	1
1121	1952-01-28	\N	\N	f	\N	\N	1	\N	78	\N	1043	5	\N	2
1423	1971-02-09	\N	\N	f	\N	\N	1	\N	141	\N	1344	5	\N	1
2627	1976-09-29	\N	\N	f	\N	\N	1	\N	175	\N	2560	5	\N	1
2793	1984-02-01	\N	\N	f	\N	\N	1	\N	201	\N	2710	5	\N	1
1682	1985-02-14	\N	\N	f	\N	\N	1	\N	202	\N	1607	5	\N	1
1844	1994-09-30	\N	\N	f	\N	\N	1	\N	241	\N	1778	5	\N	1
2869	1885-07-13	\N	\N	t	Fife	6th Earl 	1	\N	\N	\N	453	5	3	6
91	1821-07-17	\N	\N	t	Lothian	6th Marquess 	2	\N	\N	\N	84	5	2	8
288	1859-06-23	\N	\N	t	Eglinton	13th Earl 	1	\N	\N	\N	269	5	2	6
560	1901-02-11	\N	\N	f	Roberts of Kandahar	1st Lord	1	\N	\N	\N	436	5	\N	5
705	1918-06-15	\N	\N	f	Wimborne	2nd Lord	1	\N	\N	\N	570	5	\N	4
2695	1826-07-06	\N	\N	f	Northland	2nd Viscount 	1	\N	\N	\N	2633	5	3	8
238	1849-11-13	\N	\N	t	Elgin and Kincardine	8/12 Earl 	1	\N	\N	\N	224	5	2	6
440	1885-07-11	\N	\N	t	Breadalbane	7th Earl 	1	\N	\N	\N	320	5	2	6
2690	1801-01-17	\N	\N	t	Drogheda	1st Marquess 	1	\N	\N	\N	2626	5	3	11
358	1876-01-13	\N	\N	t	Richmond	6th Duke 	1	\N	\N	\N	339	5	2	6
2041	2000-04-18	\N	\N	f	Berkeley	18th Lord	2	\N	274	3	1982	5	\N	1
70	1815-08-11	\N	\N	f	Melbourne	1st Viscount 	7	\N	\N	\N	67	5	3	11
36	1802-04-01	\N	\N	f	Rivers	1st Lord	1	\N	\N	\N	13	5	\N	11
41	1806-04-09	\N	\N	f	Newark	1st Viscount	1	\N	\N	\N	40	5	\N	11
45	1806-11-27	\N	\N	f	Gardner	1st Lord 	1	\N	\N	\N	43	5	3	11
60	1814-07-16	\N	\N	f	Cathcart	1st Viscount	1	\N	\N	\N	45	5	\N	11
23	1801-01-19	\N	\N	t	Ely	1st Marquess 	1	\N	\N	\N	28	5	3	11
111	1826-07-05	\N	\N	t	Balcarres	7th Earl 	1	\N	\N	\N	106	5	2	8
7	1801-10-02	\N	\N	t	Thomond	1st Marquess 	1	\N	\N	\N	8	5	3	11
168	1831-09-14	\N	\N	f	Cloncurry	2nd Lord 	1	\N	\N	\N	157	5	3	7
152	1831-09-10	\N	\N	t	Headfort	2nd Marquess 	3	\N	\N	\N	143	5	3	7
200	1833-03-23	\N	\N	f	Durham	1st Lord	1	\N	\N	\N	133	5	\N	7
185	1835-05-12	\N	\N	f	\N	\N	1	\N	\N	\N	175	5	\N	7
205	1837-01-30	\N	\N	f	Yarborough	2nd Lord	2	\N	\N	\N	193	5	\N	7
150	1831-06-20	\N	\N	f	Kinnaird	9th Lord 	4	\N	\N	\N	141	5	2	7
352	1875-06-12	\N	\N	t	Dalhousie	12th Earl 	1	\N	\N	\N	332	5	2	6
476	1892-08-22	\N	\N	f	Cranbrook	1st Viscount	2	\N	\N	\N	456	5	\N	6
698	1918-01-14	\N	\N	f	Northcliffe	1st Lord	1	\N	\N	\N	534	5	\N	4
727	1919-05-17	\N	\N	f	Rothermere	1st Lord	1	\N	4	\N	612	5	\N	4
750	1921-06-15	\N	\N	f	Birkenhead	1st Lord	1	\N	9	\N	673	5	\N	4
782	1922-11-30	\N	\N	f	Farquhar	1st Viscount	1	\N	\N	\N	489	5	\N	4
817	1927-07-04	\N	\N	f	\N	\N	1	\N	22	\N	762	5	\N	4
838	1929-07-04	\N	\N	f	Hailsham	1st Lord	1	\N	26	\N	769	5	\N	4
850	1930-01-17	\N	\N	f	\N	\N	1	\N	28	\N	793	5	\N	4
864	1931-11-24	\N	\N	f	\N	\N	1	\N	31	\N	807	5	\N	4
879	1932-06-30	\N	\N	f	\N	\N	1	\N	33	\N	821	5	\N	4
890	1934-01-11	\N	\N	f	\N	\N	1	\N	36	\N	831	5	\N	4
903	1935-06-24	\N	\N	f	\N	\N	2	\N	40	\N	842	5	\N	4
919	1936-07-14	\N	\N	f	\N	\N	1	\N	42	\N	857	5	\N	3
929	1937-06-04	\N	\N	f	\N	\N	1	\N	44	\N	867	5	\N	2
939	1937-06-12	\N	\N	f	\N	\N	1	\N	44	\N	877	5	\N	2
952	1939-02-02	\N	\N	f	\N	\N	1	\N	48	\N	888	5	\N	2
975	1941-07-03	\N	\N	f	\N	\N	1	\N	52	\N	908	5	\N	2
986	1942-02-20	\N	\N	f	\N	\N	1	\N	54	\N	919	5	\N	2
1007	1945-02-12	\N	\N	f	\N	\N	1	\N	60	\N	940	5	\N	2
1018	1945-07-13	\N	\N	f	\N	\N	1	\N	62	\N	950	5	\N	2
1031	1945-09-19	\N	\N	f	\N	\N	1	\N	63	\N	961	5	\N	2
1055	1946-06-26	\N	\N	f	\N	\N	1	\N	66	\N	980	5	\N	2
1067	1947-01-16	\N	\N	f	\N	\N	1	\N	67	\N	993	5	\N	2
1051	1946-02-08	\N	\N	f	Gort	6th Viscount 	1	\N	\N	\N	976	5	3	2
1093	1950-01-31	\N	\N	f	\N	\N	1	\N	73	\N	1017	5	\N	2
1117	1951-12-24	\N	\N	f	Jowitt	1st Viscount	1	\N	77	\N	954	5	\N	2
1144	1954-07-03	\N	\N	f	\N	\N	1	\N	83	\N	1064	5	\N	1
1168	1956-07-09	\N	\N	f	\N	\N	1	\N	87	\N	1086	5	\N	1
1186	1958-08-05	\N	\N	f	\N	\N	1	\N	284	\N	1104	5	\N	1
1200	1959-02-19	\N	\N	f	\N	\N	1	\N	93	\N	1117	5	\N	1
1213	1960-01-28	\N	\N	f	\N	\N	1	\N	96	\N	1131	5	\N	1
1237	1961-06-29	\N	\N	f	\N	\N	1	\N	100	\N	1155	5	\N	1
1252	1962-06-15	\N	\N	f	\N	\N	1	\N	103	\N	1171	5	\N	1
1269	1964-01-16	\N	\N	f	\N	\N	1	\N	107	\N	1188	5	\N	1
1281	1964-06-26	\N	\N	f	\N	\N	1	\N	111	\N	1196	5	\N	1
1292	1964-10-05	\N	\N	f	\N	\N	1	\N	113	\N	1207	5	\N	1
1312	1965-01-01	\N	\N	f	\N	\N	1	\N	114	2	1229	5	\N	1
1338	1966-01-14	\N	\N	f	\N	\N	1	\N	120	\N	1253	5	\N	1
1348	1966-06-16	\N	\N	f	\N	\N	1	\N	121	\N	1265	5	\N	1
1362	1967-07-10	\N	\N	f	\N	\N	1	\N	124	\N	1279	5	\N	1
1372	1967-09-20	\N	\N	f	\N	\N	1	\N	126	\N	1291	5	\N	1
1387	1968-06-28	\N	\N	f	\N	\N	1	\N	130	\N	1306	5	\N	1
1392	1969-01-09	\N	\N	f	\N	\N	1	\N	133	\N	1311	5	\N	1
1432	1970-02-12	\N	\N	f	Masham	Lady	1	\N	136	\N	1321	5	\N	1
1456	1970-09-28	\N	\N	f	\N	\N	1	\N	140	\N	1378	5	\N	1
1428	1971-04-30	\N	\N	f	\N	\N	1	\N	145	\N	1349	5	\N	1
1440	1972-04-20	\N	\N	f	\N	\N	1	\N	149	\N	1360	5	\N	1
1276	1961-07-25	\N	\N	f	Fairhaven	1st Lord	1	\N	\N	\N	777	5	\N	1
2822	1881-11-24	\N	\N	f	Lyons	2nd Lord	1	\N	1	\N	2736	5	\N	6
410	1885-06-27	\N	\N	f	Powerscourt	7th Viscount 	1	\N	\N	\N	387	5	3	6
1197	1958-09-22	\N	\N	t	Reading	Marchioness dowager	1	\N	284	\N	1109	5	\N	1
299	1866-06-12	\N	\N	t	Dunraven and Mount Earl	3rd Earl 	1	\N	\N	\N	280	5	3	6
2586	1933-02-24	\N	\N	f	Buckmaster	1st Lord	1	\N	33	\N	622	5	\N	4
407	1884-11-08	\N	\N	f	de Vesci	4th Viscount 	1	\N	\N	\N	384	5	3	6
1003	1945-02-01	\N	\N	f	Portal	1st Lord	1	\N	60	\N	840	5	\N	2
2594	1946-01-28	\N	\N	f	Portal of Hungerford	1st Lord	1	\N	65	\N	2527	5	\N	2
2638	1957-07-10	\N	\N	f	Mackintosh of Halifax	1st Lord	1	\N	89	\N	2571	5	\N	1
1123	1952-01-31	\N	\N	f	Winterton	6th Earl 	1	\N	78	\N	1045	5	3	2
214	1839-05-08	\N	\N	f	Talbot de Malahide	2nd Lord 	1	\N	\N	\N	200	5	3	6
1451	1973-06-25	\N	\N	f	\N	\N	1	\N	153	\N	1373	5	\N	1
1461	1974-05-06	\N	\N	f	\N	\N	1	\N	159	\N	1383	5	\N	1
1476	1974-06-20	\N	\N	f	\N	\N	1	\N	161	\N	1394	5	\N	1
1485	1974-07-08	\N	\N	f	\N	\N	1	\N	161	\N	1405	5	\N	1
1513	1975-01-15	\N	\N	f	\N	\N	1	\N	166	\N	1420	5	\N	1
1508	1975-01-31	\N	\N	f	\N	\N	1	\N	167	\N	1432	5	\N	1
1523	1976-01-19	\N	\N	f	\N	\N	1	\N	170	\N	1443	5	\N	1
1531	1976-02-03	\N	\N	f	\N	\N	1	\N	171	\N	1452	5	\N	1
1539	1976-07-12	\N	\N	f	\N	\N	1	\N	174	\N	1460	5	\N	1
1549	1977-07-15	\N	\N	f	\N	\N	1	\N	178	\N	1471	5	\N	1
1562	1978-04-21	\N	\N	f	\N	\N	1	\N	180	\N	1484	5	\N	1
1608	1978-07-17	\N	\N	f	\N	\N	1	\N	181	\N	1534	5	\N	1
1581	1979-07-03	\N	\N	f	\N	\N	1	\N	185	\N	1506	5	\N	1
1632	1979-10-02	\N	\N	f	\N	\N	1	\N	186	\N	1526	5	\N	1
1614	1981-02-16	\N	\N	f	\N	\N	1	\N	189	\N	1540	5	\N	1
1621	1981-06-01	\N	\N	f	\N	\N	1	\N	190	\N	1550	5	\N	1
1641	1982-09-30	\N	\N	f	\N	\N	1	\N	195	\N	1565	5	\N	1
1655	1983-07-15	\N	\N	f	\N	\N	1	\N	199	\N	1581	5	\N	1
1666	1983-09-27	\N	\N	f	\N	\N	1	\N	200	\N	1592	5	\N	1
1679	1985-02-04	\N	\N	f	\N	\N	1	\N	202	\N	1603	5	\N	1
1710	1985-06-10	\N	\N	f	\N	\N	1	\N	203	\N	1617	5	\N	1
1706	1987-03-25	\N	\N	f	\N	\N	1	\N	208	\N	1633	5	\N	1
1719	1987-10-08	\N	\N	f	\N	\N	1	\N	211	\N	1645	5	\N	1
1729	1987-11-20	\N	\N	f	\N	\N	1	\N	211	\N	1656	5	\N	1
1739	1989-02-08	\N	\N	f	\N	\N	1	\N	215	\N	1667	5	\N	1
1753	1990-05-16	\N	\N	f	\N	\N	1	\N	218	\N	1680	5	\N	1
1768	1991-02-08	\N	\N	f	\N	\N	1	\N	220	\N	1698	5	\N	1
1787	1991-07-16	\N	\N	f	\N	\N	1	\N	223	\N	1711	5	\N	1
1793	1992-03-11	\N	\N	f	\N	\N	1	\N	225	\N	1721	5	\N	1
1811	1992-07-15	\N	\N	f	\N	\N	1	\N	230	\N	1741	5	\N	1
1822	1992-08-21	\N	\N	f	\N	\N	1	\N	232	\N	1753	5	\N	1
1832	1993-10-04	\N	\N	f	\N	\N	1	\N	237	\N	1762	5	\N	1
1842	1994-09-27	\N	\N	f	\N	\N	1	\N	241	\N	1775	5	\N	1
1853	1995-07-25	\N	\N	f	\N	\N	1	\N	245	\N	1791	5	\N	1
1838	1994-07-12	\N	\N	f	\N	\N	1	\N	239	\N	1771	5	\N	1
1916	1996-09-11	\N	\N	f	\N	\N	1	\N	251	\N	1848	5	\N	1
1901	1997-02-17	\N	\N	f	\N	\N	1	\N	255	\N	1822	5	\N	1
2025	1999-07-13	\N	\N	f	\N	\N	2	\N	268	3	1944	5	\N	1
2064	1999-11-17	\N	\N	f	Carrington	6th Lord	4	\N	272	7	2002	5	\N	1
2092	2000-05-03	\N	\N	f	\N	\N	1	\N	274	2	1998	5	\N	1
2113	2001-07-05	\N	\N	f	\N	\N	2	\N	280	3	2052	5	\N	1
2123	2001-07-20	\N	\N	f	\N	\N	1	\N	280	\N	2064	5	\N	1
2156	2004-06-22	\N	\N	f	\N	\N	2	\N	295	3	2101	5	\N	1
2354	2010-11-08	\N	\N	f	\N	\N	1	\N	352	\N	2303	5	\N	1
2442	2015-10-12	\N	\N	f	Hailsham	3rd Viscount	1	\N	349	2	2403	5	\N	1
2500	2013-09-10	\N	\N	f	\N	\N	1	\N	317	2	2415	5	\N	1
2550	1868-07-06	\N	\N	f	Bridport	3rd Lord 	1	\N	\N	\N	2496	5	3	6
2582	1928-01-12	\N	\N	f	Byng of Vimy	1st Lord	1	\N	\N	\N	687	5	\N	4
2601	1952-01-07	\N	\N	f	\N	\N	1	\N	78	\N	2533	5	\N	2
2616	1967-11-29	\N	\N	f	\N	\N	1	\N	127	\N	2548	5	\N	1
2626	1976-06-28	\N	\N	f	\N	\N	1	\N	173	\N	2559	5	\N	1
2635	1983-02-11	\N	\N	f	\N	\N	1	\N	198	\N	2568	5	\N	1
2647	1997-01-06	\N	\N	f	\N	\N	1	\N	254	\N	2583	5	\N	1
2661	2004-06-01	\N	\N	f	\N	\N	1	\N	295	2	2597	5	\N	1
2703	1902-07-12	\N	\N	f	Colville of Culross	1st Lord	1	\N	\N	\N	2502	5	\N	5
2659	1999-11-17	\N	\N	f	Jellicoe	2nd Earl	1	\N	272	4	2593	5	\N	1
2857	1934-10-12	\N	\N	f	\N	\N	1	\N	38	\N	2770	5	\N	4
2802	1936-01-17	\N	\N	f	Hanworth	1st Lord	1	\N	41	\N	751	5	\N	4
2825	1996-04-03	\N	\N	f	\N	\N	1	\N	248	\N	2740	5	\N	1
2799	1875-06-11	\N	\N	t	Home	11th Earl 	1	\N	\N	\N	2715	5	2	6
2868	1871-11-13	\N	\N	f	Dufferin and Claneboye	5th Lord 	1	\N	\N	\N	457	5	3	6
2914	1991-06-11	\N	\N	f	\N	\N	1	\N	222	\N	1704	5	\N	1
2912	1978-04-28	\N	\N	f	\N	\N	1	\N	180	\N	1487	5	\N	1
22	1806-02-20	\N	\N	t	Sligo	1st Marquess 	1	\N	\N	\N	27	5	3	11
197	1833-01-29	\N	\N	t	Cleveland	1st Marquess	1	\N	\N	\N	115	5	\N	7
61	1814-07-16	\N	\N	t	Aberdeen	4th Earl 	2	\N	\N	\N	58	5	2	11
813	1927-01-20	\N	\N	f	\N	\N	1	\N	21	\N	758	5	\N	4
935	1937-06-10	\N	\N	f	\N	\N	1	\N	45	\N	873	5	\N	2
1116	1951-12-22	\N	\N	f	\N	\N	1	\N	77	\N	1040	5	\N	2
1388	1968-07-10	\N	\N	f	\N	\N	1	\N	130	\N	1307	5	\N	1
1517	1975-07-16	\N	\N	f	\N	\N	1	\N	168	\N	1437	5	\N	1
2256	2006-06-16	\N	\N	f	\N	\N	2	\N	310	3	2193	5	\N	1
2718	1911-11-02	\N	\N	f	Curzon of Kedleston	1st Lord 	1	\N	\N	\N	711	5	3	4
1693	1985-07-12	\N	\N	f	\N	\N	1	\N	204	\N	1619	5	\N	1
1863	1994-10-05	\N	\N	f	\N	\N	1	\N	241	\N	1781	5	\N	1
2269	2008-06-30	\N	\N	f	\N	\N	1	\N	328	\N	2215	5	\N	1
2295	2009-06-30	\N	\N	f	\N	\N	1	\N	336	\N	2226	5	\N	1
2290	2010-06-18	\N	\N	f	\N	\N	4	\N	342	7	2242	5	\N	1
234	1847-09-20	\N	\N	f	Cremorne	3rd Lord 	1	\N	\N	\N	221	5	3	6
915	1936-01-31	\N	\N	f	Trenchard	1st Lord	1	\N	41	\N	798	5	\N	3
1021	1945-08-01	\N	\N	f	\N	\N	1	\N	61	\N	953	5	\N	2
1160	1956-01-12	\N	\N	f	De L'Isle and Dudley	6th Lord	1	\N	\N	\N	1078	5	\N	1
1334	1965-07-06	\N	\N	f	\N	\N	1	\N	119	\N	1249	5	\N	1
1407	1970-06-30	\N	\N	f	\N	\N	1	\N	139	\N	1324	5	\N	1
1469	1974-05-13	\N	\N	f	\N	\N	1	\N	159	\N	1387	5	\N	1
1550	1977-07-18	\N	\N	f	\N	\N	1	\N	178	\N	1472	5	\N	1
1617	1981-05-21	\N	\N	f	\N	\N	1	\N	190	\N	1544	5	\N	1
474	1892-05-24	\N	\N	f	\N	\N	1	\N	\N	\N	454	5	\N	6
671	1916-06-26	\N	\N	f	\N	\N	2	\N	\N	\N	633	5	\N	4
1691	1985-06-05	\N	\N	f	\N	\N	1	\N	203	\N	1616	5	\N	1
1769	1991-03-26	\N	\N	f	\N	\N	1	\N	220	\N	1700	5	\N	1
1851	1995-02-21	\N	\N	f	\N	\N	1	\N	244	\N	1789	5	\N	1
165	1831-09-10	\N	\N	t	Cassillis	12th Earl 	1	\N	\N	\N	41	5	2	7
244	1849-08-25	\N	\N	t	Dalhousie	10th Earl 	1	\N	\N	\N	230	5	2	6
801	1922-06-05	\N	\N	f	French of Ypres	1st Viscount	1	\N	\N	\N	746	5	\N	4
2008	1999-07-19	\N	\N	f	\N	\N	2	\N	270	3	1951	5	\N	1
2470	2013-09-11	\N	\N	f	\N	\N	2	\N	317	3	2418	5	\N	1
2648	1974-07-05	\N	\N	f	Delacourt-Smith	Lady	1	\N	162	\N	2555	5	\N	1
2904	1990-05-21	\N	\N	f	\N	\N	1	\N	218	\N	2602	5	\N	1
957	1937-06-02	\N	\N	t	Bessborough	9th Earl 	1	\N	44	\N	893	5	3	2
475	1892-08-23	\N	\N	f	Willoughby de Eresby	24th Lord	1	\N	\N	\N	455	5	\N	6
2935	1706-12-30	\N	\N	f	\N	\N	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 32	\N	\N	2845	1	\N	16
2936	1706-12-27	\N	\N	f	Cholmondeley	Viscount	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 33; dated 29 (sic) Dec. in CP, iii, 201	\N	\N	2846	1	3	16
2937	1706-12-26	\N	\N	f	Godolphin	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 34	\N	\N	2847	1	\N	16
2938	1706-12-24	\N	\N	f	Poulett	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 36	\N	\N	2848	1	\N	16
2939	1706-12-23	\N	\N	f	Wharton	Lord	\N	C 231/9, p. 149; 5 Ann., pt. 1 (C 66/3453) no. 35	\N	\N	2849	1	\N	16
2940	1706-12-23	\N	\N	t	Kingston	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 1 (C 66/3453) no. 37	\N	\N	2850	1	\N	16
2941	1706-12-21	\N	\N	t	Lindsey	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 1 (C 66/3453) no. 38	\N	\N	2851	1	\N	16
2942	1706-12-16	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 4	\N	\N	2852	1	\N	16
2943	1706-12-14	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 17	\N	\N	2853	1	\N	16
2944	1800-12-29	\N	\N	f	Malmesbury	Lord	\N	C 231/13, p. 285; 41 Geo. III, pt. 4 (C 66/3982) no. 1	\N	\N	2854	4	\N	9
2945	1800-12-27	\N	\N	f	Cadogan	Lord	\N	C 231/13, p. 285; 41 Geo. III, pt. 4 (C 66/3982) no. 2	\N	\N	2855	4	\N	9
2946	1800-06-16	\N	\N	f	Bridport	Lord	\N	C 231/13, p. 248; 40 Geo. III, pt. 11 (C66/3973) no. 6	\N	\N	2856	4	3	9
2947	1799-09-24	\N	\N	t	Clare	Earl	\N	C 231/13, p. 231; 39 Geo. III, pt. 11 (C 66/3962) no. 1	\N	\N	2857	4	3	9
2948	1799-07-18	Sir	Kt.	f	\N	\N	\N	C 231/13, p. 230; 39 Geo. III, pt. 11 (C 66/3962) no. 18	\N	\N	110	4	\N	9
2949	1898-11-11	Hon.	\N	f	\N	\N	\N	LJ, cxl, 19	\N	\N	711	3	\N	\N
2950	1868-12-21	\N	\N	f	\N	\N	\N	LP printed in LJ, ci, 229-30	\N	\N	2858	3	\N	\N
2951	1868-08-10	\N	\N	t	Abercorn	Marquess	\N	CP, i, 9	\N	\N	2859	3	4	\N
2952	1863-12-14	Sir	Bart.	f	\N	\N	\N	LP printed in LJ, xcvi, 87-8	\N	\N	279	3	\N	\N
2953	1855-05-14	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxviii, 85-6; The House of Lords resolved 1 July 1856 that grantee had not made out his claim to vote at elections for representative peers (ibid. 336); in consequence he received fresh LP 10 Sept. 1856	\N	\N	2860	3	\N	\N
2954	1852-02-11	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxv, 537-9	\N	\N	278	3	\N	\N
2955	1848-07-10	Sir	Bart.	f	\N	\N	\N	LP printed in LJ, lxxxviii, 387-8	\N	\N	2861	3	\N	\N
2956	1706-12-14	\N	\N	t	Kent	Earl	\N	C 231/9, p. 148; 5 Ann., pt. 2 (C 66/3454) no. 1; dated 14 Nov. (sic) in CP, vii, 177	\N	\N	2862	1	\N	16
2957	1706-12-09	Prince	\N	f	\N	\N	\N	C 231/9, p. 147; 5 Ann., pt. 2 (C 66/3454) no. 3; dated 9 Nov. (sic) in CP, ii, 497	\N	\N	2863	1	\N	16
2958	1705-11-26	\N	\N	t	Argyll	Duke	\N	C 231/9, p. 134; 4 Ann., pt. 4 (C 66/3451) no. 9	\N	\N	2864	1	2	16
2959	1705-04-14	\N	\N	t	Montagu	Earl	\N	C 231/9, p. 124; 4 Ann., pt. 1 (C 66/3448) no. 16	\N	\N	2865	1	\N	16
2960	1703-03-29	\N	\N	t	Rutland	Earl	\N	C 231/9, p. 93; 2 Ann., pt. 2 (C 66/3439) no. 17	\N	\N	2866	1	\N	16
2961	1703-03-24	\N	\N	t	Normanby	Marquess	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 20; dated 23 (sic) Mar. in CP, ii, 398 but 24 Mar. in ibid., ix, 638	\N	\N	2867	1	\N	16
2962	1703-03-23	\N	\N	f	\N	\N	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 12	\N	\N	2868	1	\N	16
2963	1703-03-17	\N	\N	f	\N	\N	\N	C 231/9, p. 92; 2 Ann., pt. 2 (C 66/3439) no. 22; CP, iii, 402 omits mention of remainder to Seymour	\N	\N	2869	1	\N	16
2964	1703-03-16	Sir	Bart.	f	\N	\N	\N	C 231/9, p. 91; 2 Ann., pt. 2 (C 66/3439) no. 27	\N	\N	2870	1	\N	16
2965	1799-04-24	Prince	\N	f	\N	\N	\N	C 231/13, p. 221; 39 Geo. III, pt. 7 (C 66/3958) no. 2	\N	\N	2871	4	\N	9
2966	1799-04-24	Prince	\N	f	\N	\N	\N	C 231/13, p. 221; 39 Geo. III, pt. 7 (C 66/3958) no. 3	\N	\N	2872	4	\N	9
2967	1798-11-06	Sir	Kt.	f	\N	\N	\N	C 231/13, p. 214; 39 Geo. III, pt. 1 (C 66/3952) no. 8	\N	\N	3	4	\N	9
2968	1797-11-30	\N	\N	f	de Dunstanville	Lord	\N	C 231/13, p. 197; 38 Geo. III, pt. 2 (C 66/3944) no. 22	\N	\N	2873	4	\N	9
2969	1797-10-30	\N	\N	f	\N	\N	\N	C 231/13, p. 195; 38 Geo. III, pt. 1 (C 66/3943) no. 10	\N	\N	2874	4	\N	9
2970	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 11	\N	\N	2875	4	\N	9
2971	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 12	\N	\N	2876	4	\N	9
2972	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 13	\N	\N	2877	4	\N	9
2973	1797-10-26	\N	\N	f	\N	\N	\N	C 231/13, p. 194; 38 Geo. III, pt. 1 (C 66/3943) no. 14	\N	\N	2878	4	\N	9
2974	1845-06-03	\N	\N	f	\N	\N	\N	LJ, lxxvii, 734; dated 6 (sic) June 1845 in CP, iv, 550	\N	\N	2879	3	\N	\N
2975	1836-05-04	\N	\N	f	\N	\N	\N	Abstract, p. 67	\N	\N	2880	3	\N	\N
2976	1834-06-13	\N	\N	f	\N	\N	\N	Abstract, p. 47	\N	\N	185	3	\N	\N
2977	1831-09-14	\N	\N	f	Northland	Viscount	\N	Abstract, p. 19	\N	\N	2633	3	\N	\N
2978	1831-05-28	\N	\N	f	\N	\N	\N	LP printed in LJ, lxxxiii, 267-8; dated 26 (sic) May 1831 in Abstract, p. 16	\N	\N	2881	3	\N	\N
2979	1831-01-06	\N	\N	f	\N	\N	\N	Abstract, p. 11; LP printed in LJ, lxxxviii, 385-6; dated 28 (sic) Jan. 1831 in CP, vi, 219	\N	\N	2882	3	\N	\N
2980	1827-06-23	\N	\N	f	Norbury	Lord	\N	LJ, lxiii, 964; CP, v, 566	\N	\N	2883	3	\N	\N
2981	1826-06-27	\N	\N	f	\N	\N	\N	LJ, lxvi, 346; dated 31 July (sic) 1826 in CP, v, 405	\N	\N	2884	3	\N	\N
\.


--
-- Name: letters_patents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('letters_patents_id_seq', 2981, true);


--
-- Data for Name: monarchs; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY monarchs (id, name) FROM stdin;
1	Elizabeth II
2	George VI
3	Edward VIII
4	George V
5	Edward VII
6	Victoria
7	William IV
8	George IV
9	George III
10	George II
11	George I
12	Anne
\.


--
-- Name: monarchs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('monarchs_id_seq', 12, true);


--
-- Data for Name: peerage_holdings; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerage_holdings (id, ordinality, start_on, end_on, notes, person_id, peerage_id, introduced_on) FROM stdin;
1	1	1801-01-20	1820-08-10	\N	1	3	1801-03-27
2	1	1801-01-21	1828-04-07	\N	2	4	1801-11-27
3	1	1801-05-22	1805-10-21	\N	3	8	1801-10-29
4	1	1801-05-22	1804-03-19	\N	4	9	1801-05-27
5	1	1801-05-28	1821-02-11	\N	5	10	1821-04-09
6	1	1801-06-23	1807-11-14	\N	6	15	1801-10-29
7	1	1801-07-31	1839-02-19	\N	7	17	1802-11-22
8	1	1801-10-02	1808-02-10	\N	8	19	1801-10-29
9	1	1801-12-15	1823-03-10	\N	9	22	1802-11-17
10	1	1801-12-16	1832-06-29	\N	10	23	1802-06-21
11	1	1802-02-15	1830-01-16	\N	11	24	1802-02-19
12	1	1802-02-27	1820-03-21	\N	12	25	1802-03-08
13	1	1802-04-01	1803-05-07	\N	13	26	1829-02-05
14	1	1802-04-19	1818-12-13	\N	14	27	1802-04-26
15	1	1802-06-19	1836-08-01	\N	15	28	1836-08-12
16	1	1802-07-28	1840-07-05	\N	16	29	1802-11-22
17	1	1802-07-29	1821-05-30	\N	17	30	1802-11-23
18	1	1802-12-24	1811-05-29	\N	18	31	1803-04-20
19	1	1803-09-17	1823-03-10	\N	9	32	\N
20	1	1804-09-01	1808-02-20	\N	19	35	\N
21	1	1805-01-12	1844-02-15	\N	20	36	1805-01-15
22	1	1805-05-01	1813-06-17	\N	21	37	1805-06-05
23	1	1814-06-01	1833-01-23	\N	22	78	1814-11-08
24	1	1805-11-20	1835-02-28	\N	23	38	1806-01-21
25	1	1805-11-20	1810-03-07	\N	24	39	\N
26	1	1806-02-10	1823-11-17	\N	25	40	1806-02-10
27	1	1806-02-17	1818-07-31	\N	26	41	1806-02-28
28	1	1806-02-20	1809-06-02	\N	27	42	1806-05-02
29	1	1801-01-19	1806-03-22	\N	28	2	1801-02-24
30	1	1806-02-25	1829-04-28	\N	29	46	1806-03-04
31	1	1806-02-26	1816-10-21	\N	30	47	1806-05-08
32	1	1801-11-27	1850-07-08	\N	31	21	1801-12-15
33	1	1801-11-27	1843-04-21	\N	32	20	1805-01-15
34	1	1801-06-23	1805-01-08	\N	33	14	1801-06-30
35	1	1801-06-18	1825-07-30	\N	34	11	1801-10-30
36	1	1801-06-19	1814-05-17	\N	35	12	1801-10-29
37	1	1804-05-14	1839-05-16	\N	36	34	1804-05-18
38	1	1801-06-22	1811-03-01	\N	37	13	1801-06-29
39	1	1801-04-21	1805-01-03	\N	38	6	1801-04-28
40	1	1801-02-04	1804-05-01	\N	39	5	1801-05-18
41	1	1806-04-09	1816-06-17	\N	40	49	1806-06-19
42	1	1806-04-11	1807-11-14	\N	6	51	1806-04-28
43	1	1806-11-12	1846-09-08	\N	41	52	1806-12-15
44	1	1806-11-13	1834-03-29	\N	42	53	1807-01-02
45	1	1806-11-27	1809-01-01	\N	43	54	1807-06-22
46	1	1807-04-20	1842-05-31	\N	44	56	1807-04-24
47	1	1807-11-04	1808-02-20	\N	19	57	1808-01-21
48	1	1807-11-09	1843-06-16	\N	45	58	1808-02-01
49	1	1807-11-09	1833-04-19	\N	46	59	1808-01-21
50	1	1809-02-03	1816-05-29	\N	47	60	1817-04-25
51	1	1809-09-04	1852-09-14	\N	48	62	1814-06-28
52	1	1812-09-07	1840-10-08	\N	49	65	1812-11-28
53	1	1813-06-14	1825-05-12	\N	50	70	1813-06-16
54	1	1814-05-17	1823-08-27	\N	51	72	1817-04-25
55	1	1814-05-17	1843-12-18	\N	52	73	1815-03-10
56	1	1814-05-17	1865-02-21	\N	53	74	1814-06-01
57	1	1814-05-17	1842-12-10	\N	54	75	1814-06-01
58	1	1814-05-17	1854-01-08	\N	55	76	1814-06-01
59	1	1814-06-01	1823-03-10	\N	56	77	1815-03-20
60	1	1814-07-01	1854-03-06	\N	57	79	1814-07-06
61	1	1814-07-16	1843-06-16	\N	45	80	1814-07-21
62	1	1814-07-16	1860-12-14	\N	58	81	1814-07-27
63	1	1815-08-04	1837-11-24	\N	59	83	1817-02-21
64	1	1815-08-07	1820-07-03	\N	60	84	1816-04-29
65	1	1815-08-11	1838-03-21	\N	61	85	1816-05-24
66	1	1815-08-11	1853-06-17	\N	62	86	1816-05-24
67	1	1815-08-11	1843-07-03	\N	63	87	1817-07-10
68	1	1815-08-11	1840-03-31	\N	64	88	1817-07-10
69	1	1815-08-11	1844-12-07	\N	65	89	1816-05-24
70	1	1815-08-11	1845-03-10	\N	66	90	1816-02-01
71	1	1815-08-11	1828-07-22	\N	67	91	1816-02-01
72	1	1806-02-22	1839-09-15	\N	68	44	1806-02-28
73	1	1815-11-25	1825-05-12	\N	50	96	1818-01-27
74	1	1809-07-19	1847-12-26	\N	69	61	1810-01-23
75	1	1807-04-07	1844-03-19	\N	70	55	1807-04-09
76	1	1813-02-24	1814-06-21	\N	71	69	1816-03-22
77	1	1812-09-07	1831-04-07	\N	72	66	1812-11-24
78	1	1806-04-10	1809-02-24	\N	73	50	1806-04-25
79	1	1815-11-24	1845-11-17	\N	74	95	1816-02-01
80	1	1815-07-04	1854-04-29	\N	75	82	1816-03-11
81	1	1815-11-22	1827-04-10	\N	76	94	1816-03-20
82	1	1812-09-07	1828-05-24	\N	77	64	1812-11-28
83	1	1812-10-03	1852-09-14	\N	48	68	1814-06-28
84	1	1815-11-27	1853-09-15	\N	78	97	1816-02-01
85	1	1815-12-01	1816-10-21	\N	30	101	1816-05-06
86	1	1816-10-25	1833-05-04	\N	79	103	1833-05-15
87	1	1816-11-27	1865-02-12	\N	80	104	1817-01-28
88	1	1816-12-10	1833-01-23	\N	22	105	1817-01-28
89	1	1817-06-03	1829-05-08	\N	81	107	1817-07-03
90	1	1821-07-16	1870-05-12	\N	82	111	1822-03-14
91	1	1821-07-17	1841-01-05	\N	83	113	1822-02-05
92	1	1821-07-17	1824-04-27	\N	84	114	1822-03-07
93	1	1821-07-17	1832-12-28	\N	85	115	1833-02-04
94	1	1821-07-17	1838-05-18	\N	86	116	1822-03-20
95	1	1821-07-17	1853-06-28	\N	87	117	1822-04-26
96	1	1821-07-17	1870-03-20	\N	88	118	1822-02-05
97	1	1821-07-17	1839-10-18	\N	89	119	1824-03-29
98	1	1821-07-17	1835-05-24	\N	90	120	1824-06-22
99	1	1821-07-17	1837-10-12	\N	91	121	1822-04-01
100	1	1821-07-17	1845-02-22	\N	92	122	1822-02-05
101	1	1821-07-17	1828-08-16	\N	93	123	1822-02-06
102	1	1821-07-17	1836-01-28	\N	94	124	1822-02-05
103	1	1821-07-17	1855-03-07	\N	95	125	1822-02-06
104	1	1821-07-17	1855-10-30	\N	96	126	1822-05-20
105	1	1821-07-17	1828-05-23	\N	97	127	1822-05-30
106	1	1821-07-18	1836-09-01	\N	98	129	1837-01-31
107	1	1823-03-01	1851-02-08	\N	99	131	1823-03-05
108	1	1823-04-22	1854-01-08	\N	55	132	1823-04-25
109	1	1823-07-08	1854-03-06	\N	100	133	1823-07-16
110	1	1823-12-08	1837-11-24	\N	101	134	1827-03-07
111	1	1824-01-30	1826-09-04	\N	102	135	1824-02-03
112	1	1815-08-12	1846-01-08	\N	103	93	1816-02-01
113	1	1826-07-03	1846-08-21	\N	104	138	1827-02-27
114	1	1826-07-04	1826-12-13	\N	105	139	1826-07-04
115	1	1826-07-05	1869-12-15	\N	106	140	1827-02-27
116	1	1826-07-08	1838-01-17	\N	107	142	1826-11-14
117	1	1826-07-10	1827-06-18	\N	108	143	1834-05-30
118	1	1815-11-30	1825-09-07	\N	109	100	1816-02-02
119	1	1821-07-07	1838-01-13	\N	110	108	1821-07-09
120	1	1821-07-14	1841-12-29	\N	111	109	1822-03-18
121	1	1815-11-29	1840-03-14	\N	112	99	1816-06-06
122	1	1821-07-18	1827-08-27	\N	113	128	1822-02-05
123	1	1821-07-17	1856-01-04	\N	114	112	1822-02-05
124	1	1827-10-05	1842-01-29	\N	115	155	1828-01-29
125	1	1817-02-13	1826-11-28	\N	116	106	1825-06-03
126	1	1826-07-12	1845-12-19	\N	117	144	1826-11-20
127	1	1826-07-14	1841-07-16	\N	118	145	1826-11-14
128	1	1826-12-19	1857-03-13	\N	119	147	1829-02-05
129	1	1827-02-08	1865-02-21	\N	53	148	1830-06-03
130	1	1827-04-25	1863-10-12	\N	120	149	1827-05-02
131	1	1827-04-28	1859-01-28	\N	121	150	1827-05-02
132	1	1827-04-28	1857-03-09	\N	122	151	1827-05-07
133	1	1827-04-30	1832-11-04	\N	123	152	1827-05-02
134	1	1827-05-01	1854-01-05	\N	124	153	1827-05-02
135	1	1827-07-24	1858-12-01	\N	125	154	1828-01-29
136	1	1827-10-06	1860-11-07	\N	126	157	1828-01-29
137	1	1828-01-21	1847-04-27	\N	127	158	1831-09-05
138	1	1828-01-22	1837-03-15	\N	128	159	1837-04-24
139	1	1828-01-22	1845-11-06	\N	129	160	1828-01-29
140	1	1828-01-23	1860-05-31	\N	130	161	1828-03-28
141	1	1828-01-26	1868-03-04	\N	131	162	1828-03-07
142	1	1828-01-28	1879-10-07	\N	132	163	1828-01-29
143	1	1828-01-29	1840-07-28	\N	133	164	1828-01-31
144	1	1828-01-30	1853-04-03	\N	134	165	1828-02-05
145	1	1828-02-02	1844-02-23	\N	135	166	1828-02-08
146	1	1829-06-05	1845-03-03	\N	136	167	1829-06-11
147	1	1830-11-22	1868-05-07	\N	137	168	1830-11-23
148	1	1831-06-17	1846-04-19	\N	138	170	1831-06-20
149	1	1831-06-20	1838-11-20	\N	139	172	1831-06-20
150	1	1831-06-20	1854-12-31	\N	140	173	1831-06-24
151	1	1831-06-20	1878-01-07	\N	141	174	1831-06-20
152	1	1831-06-20	1833-07-10	\N	142	175	1831-06-20
153	1	1831-09-10	1870-12-06	\N	143	178	1831-09-14
154	1	1831-09-10	1851-03-15	\N	144	179	1831-09-14
155	1	1831-09-10	1836-11-11	\N	145	180	1831-09-26
156	1	1831-09-10	1842-04-16	\N	146	181	1831-09-26
157	1	1831-09-10	1868-12-22	\N	147	182	1833-06-28
158	1	1831-09-10	1864-09-15	\N	148	185	1831-09-14
159	1	1831-09-10	1858-12-19	\N	149	186	1831-09-13
160	1	1831-09-10	1834-04-10	\N	150	187	1831-10-03
161	1	1831-09-10	1854-04-03	\N	151	188	1831-10-03
162	1	1831-09-10	1857-10-10	\N	152	189	1831-09-12
163	1	1831-09-10	1837-09-26	\N	153	190	1831-09-17
164	1	1831-09-10	1852-02-10	\N	154	191	1831-09-10
165	1	1831-06-04	1842-03-20	\N	155	169	1831-06-15
166	1	1831-09-10	1846-09-08	\N	41	176	1831-10-13
167	1	1826-06-30	1859-02-15	\N	156	137	1826-11-28
168	1	1831-09-14	1853-10-28	\N	157	195	1831-09-15
169	1	1831-09-15	1836-10-09	\N	158	197	1831-09-15
170	1	1832-05-14	1850-02-15	\N	159	198	1832-05-18
171	1	1832-05-15	1884-03-12	\N	160	199	1833-02-04
172	1	1832-12-22	1851-06-30	\N	161	201	1833-02-04
173	1	1833-01-28	1844-11-04	\N	162	203	1833-02-04
174	1	1833-05-10	1846-01-08	\N	163	207	1833-05-18
175	1	1833-06-07	1837-12-03	\N	164	208	1833-06-10
176	1	1834-03-28	1854-09-22	\N	165	209	1834-04-01
177	1	1834-06-03	1870-08-09	\N	166	210	\N
178	1	1834-07-19	1847-05-16	\N	167	211	1834-07-22
179	1	1835-01-10	1843-05-11	\N	168	212	1835-02-20
180	1	1835-01-12	1844-04-07	\N	169	213	1835-02-20
181	1	1835-01-13	1851-03-04	\N	170	214	1835-02-20
182	1	1835-03-10	1845-07-21	\N	171	215	1835-04-03
183	1	1835-04-10	1848-05-12	\N	172	216	1835-05-12
184	1	1835-05-08	1866-04-23	\N	173	217	1835-05-12
185	1	1835-05-11	1863-05-04	\N	174	218	1835-06-01
186	1	1835-05-12	1860-06-03	\N	175	219	1835-05-15
187	1	1835-06-13	1849-03-27	\N	176	220	1835-06-30
188	1	1836-01-20	1851-04-29	\N	177	221	1836-02-04
189	1	1836-01-22	1860-03-25	\N	178	222	1860-04-19
190	1	1836-01-23	1851-04-18	\N	179	223	1836-02-04
191	1	1837-01-27	1888-11-19	\N	180	225	1837-03-14
192	1	1837-01-28	1875-06-28	\N	181	227	1837-01-31
193	1	1837-01-30	1845-07-22	\N	182	229	1837-01-31
194	1	1838-07-06	1857-05-30	\N	183	237	1838-07-09
195	1	1838-07-07	1842-08-10	\N	184	238	1839-02-05
196	1	1838-07-09	1856-06-02	\N	185	239	1838-07-10
197	1	1838-07-10	1855-05-16	\N	186	240	1838-07-10
198	1	1838-07-11	1841-03-16	\N	187	241	1838-07-12
199	1	1833-01-29	1842-01-29	\N	115	204	1833-02-04
200	1	1833-01-28	1833-07-19	\N	188	202	1833-02-04
201	1	1837-01-28	1840-06-22	\N	189	226	1837-01-31
202	1	1833-03-23	1840-07-28	\N	133	205	1833-06-03
203	1	1837-01-27	1845-02-13	\N	190	224	1837-04-21
204	1	1831-09-15	1854-03-18	\N	191	196	1831-09-15
205	1	1838-06-30	1893-12-29	\N	192	234	1838-07-03
206	1	1833-04-13	1859-01-28	\N	121	206	1833-04-16
207	1	1837-01-30	1846-09-05	\N	193	228	1837-01-31
208	1	1838-07-02	1839-02-19	\N	194	235	1838-07-04
209	1	1831-09-12	1834-03-29	\N	195	192	1831-09-15
210	1	1831-09-13	1845-02-17	\N	196	194	1831-09-13
211	1	1838-07-12	1858-02-10	\N	197	242	1838-07-13
212	1	1838-07-13	1849-09-11	\N	198	243	1838-07-16
213	1	1839-04-20	1855-02-21	\N	199	244	1842-02-02
214	1	1839-05-08	1849-10-29	\N	200	246	1839-05-13
215	1	1839-05-09	1850-10-02	\N	201	247	1839-05-13
216	1	1839-05-10	1874-01-23	\N	202	248	1839-05-31
217	1	1839-05-11	1850-09-27	\N	203	249	1839-05-30
218	1	1839-05-13	1852-05-09	\N	204	250	1839-05-16
219	1	1839-05-14	1847-04-30	\N	205	251	1839-05-31
220	1	1839-05-15	1854-05-03	\N	206	252	1839-05-16
221	1	1839-05-16	1856-09-29	\N	207	253	1839-05-27
222	1	1839-06-07	1858-04-17	\N	208	254	1840-01-16
223	1	1839-09-05	1866-02-07	\N	209	255	1840-01-16
224	1	1839-12-14	1863-04-17	\N	210	256	1840-01-16
225	1	1839-12-23	1844-08-26	\N	211	258	1840-06-29
226	1	1840-08-19	1841-09-19	\N	212	260	\N
227	1	1841-08-16	1853-01-10	\N	213	263	1842-05-12
228	1	1841-08-17	1857-10-10	\N	152	264	1841-08-24
229	1	1841-08-17	1853-10-31	\N	214	265	1843-02-16
230	1	1841-08-19	1842-08-20	\N	215	267	1841-08-19
231	1	1841-08-20	1842-06-08	\N	216	268	1841-08-23
232	1	1842-09-27	1842-12-10	\N	54	270	1843-02-02
233	1	1845-01-25	1846-09-12	\N	217	272	\N
234	1	1846-04-25	1869-03-02	\N	218	273	\N
235	1	1837-02-13	1863-12-26	\N	219	230	1864-02-04
236	1	1847-09-18	1864-06-15	\N	220	277	1848-04-11
237	1	1847-09-20	1897-05-12	\N	221	278	1848-02-03
238	1	1847-09-21	1857-01-03	\N	222	279	1847-11-18
239	1	1848-05-12	1869-06-16	\N	223	280	1848-05-15
240	1	1849-06-15	1869-03-02	\N	218	281	1850-03-04
241	1	1849-11-13	1863-11-20	\N	224	283	1854-01-31
242	1	1840-04-10	1873-08-01	\N	225	259	\N
243	1	1839-12-21	1849-01-01	\N	226	257	1843-02-02
244	1	1850-01-17	1910-05-06	\N	227	284	\N
245	1	1844-10-22	1871-12-22	\N	228	271	1845-02-04
246	1	1841-08-16	1866-06-10	\N	229	262	1841-08-24
247	1	1849-08-25	1860-12-22	\N	230	282	\N
248	1	1838-06-25	1863-07-28	\N	231	233	1838-06-29
249	1	1841-12-08	1910-05-06	\N	232	269	1863-02-05
250	1	1850-03-04	1860-01-15	\N	233	286	1850-03-07
251	1	1850-03-05	1883-11-17	\N	234	287	1850-03-07
252	1	1850-07-15	1855-11-11	\N	235	289	1850-07-15
253	1	1850-12-20	1868-07-26	\N	236	290	1851-02-04
254	1	1851-02-26	1869-06-03	\N	237	291	1851-02-28
255	1	1851-04-05	1856-09-29	\N	207	292	1857-05-11
256	1	1852-03-01	1875-01-29	\N	238	293	1852-03-04
257	1	1852-05-01	1880-08-14	\N	239	294	1852-11-08
258	1	1852-10-20	1855-06-28	\N	240	295	1852-11-08
259	1	1856-02-26	1867-09-06	\N	241	297	1856-04-29
260	1	1856-03-12	1871-12-26	\N	242	298	1856-05-20
261	1	1856-06-25	1858-11-23	\N	243	299	1856-06-27
262	1	1856-07-23	1868-02-25	\N	244	300	1856-07-25
263	1	1856-08-29	1880-06-30	\N	245	301	1857-02-03
264	1	1856-11-19	1883-04-14	\N	246	302	1857-02-12
265	1	1857-04-11	1884-07-15	\N	247	303	1857-06-05
266	1	1857-04-11	1888-12-28	\N	248	304	1857-05-01
267	1	1857-09-15	1893-11-18	\N	249	305	1858-02-04
268	1	1857-09-16	1859-12-28	\N	250	306	1857-12-03
269	1	1857-10-01	1879-08-07	\N	251	307	1858-02-18
270	1	1858-01-15	1863-11-10	\N	252	308	1858-02-04
271	1	1858-03-01	1878-10-05	\N	253	309	1858-03-12
272	1	1871-11-04	1889-11-21	\N	254	383	1872-02-15
273	1	1858-08-02	1871-09-04	\N	255	310	1859-02-03
274	1	1858-08-16	1863-08-14	\N	256	312	1860-07-30
275	1	1858-08-28	1867-10-07	\N	257	313	1859-02-03
276	1	1859-04-14	1869-03-18	\N	258	314	1859-06-07
277	1	1859-04-15	1883-02-21	\N	259	315	1859-06-03
278	1	1859-06-28	1873-11-10	\N	260	320	1859-07-04
279	1	1859-06-29	1867-04-27	\N	261	321	1859-07-04
280	1	1859-08-18	1869-07-13	\N	262	322	1860-01-24
281	1	1861-01-15	1861-08-02	\N	263	326	1861-02-05
282	1	1861-06-27	1873-07-20	\N	264	327	1861-06-27
283	1	1861-07-30	1878-05-28	\N	265	328	1861-07-30
284	1	1861-08-05	1867-10-17	\N	266	329	1861-08-06
285	1	1850-06-11	1851-04-29	\N	177	288	1851-07-11
286	1	1860-02-17	1885-05-07	\N	267	323	1860-03-01
287	1	1846-07-06	1857-02-18	\N	268	275	1847-02-01
288	1	1847-09-18	1860-06-03	\N	175	276	1847-11-23
289	1	1859-06-23	1861-10-04	\N	269	319	1860-03-08
290	1	1863-06-19	1885-11-28	\N	270	331	\N
291	1	1863-08-19	1873-09-01	\N	271	332	1864-02-04
292	1	1863-08-20	1885-08-11	\N	272	333	1864-02-04
293	1	1864-04-27	1870-01-01	\N	273	334	1870-02-08
294	1	1866-01-03	1874-12-23	\N	274	335	1866-02-05
295	1	1866-01-04	1866-09-06	\N	275	336	1866-02-05
296	1	1866-02-21	1885-08-08	\N	276	337	1866-02-22
297	1	1866-05-01	1881-03-28	\N	277	338	1869-02-18
298	1	1866-05-02	1887-07-29	\N	278	339	1866-06-01
299	1	1866-05-03	1873-12-07	\N	279	340	1866-06-22
300	1	1866-06-12	1871-10-06	\N	280	343	1866-06-25
301	1	1866-07-12	1894-11-29	\N	281	345	1867-02-05
302	1	1866-07-13	1870-04-16	\N	282	346	1866-07-23
303	1	1866-07-14	1873-01-18	\N	283	347	1866-07-26
304	1	1866-07-16	1876-06-01	\N	284	348	1866-07-26
305	1	1866-07-31	1885-10-16	\N	285	349	1866-08-06
306	1	1866-08-03	1886-03-31	\N	286	350	1866-08-06
307	1	1867-02-26	1874-01-31	\N	287	352	1867-03-01
308	1	1867-02-27	1885-04-02	\N	288	353	1867-03-01
309	1	1868-04-15	1874-12-17	\N	289	354	1868-05-05
310	1	1868-04-16	1881-02-03	\N	290	355	1868-05-15
311	1	1868-04-17	1875-12-06	\N	291	356	1868-05-05
312	1	1868-04-18	1883-04-18	\N	292	357	1868-06-16
313	1	1859-05-21	1862-06-17	\N	293	317	\N
314	1	1859-05-21	1860-07-19	\N	294	318	\N
315	1	1868-11-30	1872-12-15	\N	295	361	\N
316	1	1868-12-08	1876-09-28	\N	296	362	1869-03-02
317	1	1868-12-09	1881-07-10	\N	297	363	1868-12-15
318	1	1869-04-03	1879-06-27	\N	298	364	1869-04-15
319	1	1869-04-06	1899-12-09	\N	299	365	1869-04-23
320	1	1869-06-29	1916-10-02	\N	300	366	1869-07-02
321	1	1869-12-08	1924-06-05	\N	301	368	1870-02-08
322	1	1869-12-09	1883-12-01	\N	302	369	1870-02-08
323	1	1869-12-10	1883-01-22	\N	303	370	1870-02-08
324	1	1869-12-11	1902-06-19	\N	304	371	1870-06-23
325	1	1869-12-13	1882-03-09	\N	305	372	1870-02-08
326	1	1866-07-12	1897-05-12	\N	221	344	1866-07-26
327	1	1866-06-01	1902-04-08	\N	306	342	1866-07-23
328	1	1869-12-14	1873-07-24	\N	307	373	1870-04-28
329	1	1869-12-15	1883-01-25	\N	308	374	1870-02-08
330	1	1870-05-03	1887-02-10	\N	309	375	1870-06-13
331	1	1870-06-14	1885-02-01	\N	310	376	1870-06-21
332	1	1870-10-26	1876-10-06	\N	311	377	1872-07-08
333	1	1871-03-23	1872-05-23	\N	312	378	1871-03-31
334	1	1871-03-28	1876-06-23	\N	313	379	1871-05-12
335	1	1871-06-09	1906-12-30	\N	314	380	\N
336	1	1871-08-07	1879-08-17	\N	315	382	1872-02-15
337	1	1872-02-13	1873-03-07	\N	316	385	1872-02-13
338	1	1872-07-16	1898-12-19	\N	317	386	1872-08-01
339	1	1872-10-01	1881-03-08	\N	318	387	1873-02-06
340	1	1872-10-23	1895-05-04	\N	319	388	1873-02-06
341	1	1873-03-25	1922-10-19	\N	320	389	1874-03-19
342	1	1873-03-28	1888-11-19	\N	180	390	1873-05-06
343	1	1873-04-10	1886-02-05	\N	321	392	1873-05-06
344	1	1873-06-12	1873-06-19	\N	322	393	\N
345	1	1873-08-23	1895-02-25	\N	323	394	1874-03-10
346	1	1874-01-08	1880-10-08	\N	324	395	1874-05-07
347	1	1874-01-09	1895-04-27	\N	325	396	1874-04-20
348	1	1874-01-10	1894-06-14	\N	326	397	1874-04-23
349	1	1874-01-12	1894-04-20	\N	327	398	1874-03-19
350	1	1874-02-27	1890-02-14	\N	328	400	1874-03-20
351	1	1868-07-17	1890-01-14	\N	329	359	1868-07-27
352	1	1874-03-06	1880-04-09	\N	330	405	1874-03-10
353	1	1874-03-16	1892-07-11	\N	331	406	1874-03-19
354	1	1875-06-12	1880-07-20	\N	332	410	1875-06-21
355	1	1875-06-14	1885-01-18	\N	333	411	1875-06-15
356	1	1876-01-13	1885-10-03	\N	334	413	1886-01-21
357	1	1876-01-14	1876-06-15	\N	335	415	1876-02-08
358	1	1876-01-15	1904-02-17	\N	336	417	1876-02-17
359	1	1876-01-17	1890-12-09	\N	337	418	1876-02-08
360	1	1876-01-18	1887-03-15	\N	338	419	1876-02-08
361	1	1876-01-13	1903-09-27	\N	339	412	1904-07-11
362	1	1874-02-27	1899-12-22	\N	340	399	1874-03-26
363	1	1868-07-25	1915-01-13	\N	341	360	1868-12-15
364	1	1874-04-02	1878-03-19	\N	342	407	1874-04-30
365	1	1876-01-14	1915-12-12	\N	343	414	1876-02-10
366	1	1871-06-23	1900-07-09	\N	344	381	1871-06-26
367	1	1876-10-02	1888-10-01	\N	345	422	1877-02-08
368	1	1876-10-17	1879-08-21	\N	346	424	1876-11-21
369	1	1876-11-29	1881-09-13	\N	347	425	1877-02-08
370	1	1878-04-16	1905-03-28	\N	348	427	1878-05-14
371	1	1878-05-04	1906-10-30	\N	349	428	1878-05-14
372	1	1878-09-27	1885-04-02	\N	288	429	1878-12-06
373	1	1880-04-17	1886-11-07	\N	350	430	1880-05-07
374	1	1880-04-23	1893-08-07	\N	351	431	\N
375	1	1880-04-28	1899-09-14	\N	352	433	1880-05-07
376	1	1880-04-29	1883-03-22	\N	353	434	1880-05-13
377	1	1880-04-30	1914-02-22	\N	354	435	1880-05-07
378	1	1880-05-01	1915-01-20	\N	355	436	1880-05-25
379	1	1880-05-03	1890-02-15	\N	356	438	1880-05-20
380	1	1880-05-04	1894-09-10	\N	357	439	1880-05-27
381	1	1880-05-04	1895-07-24	\N	358	440	1880-05-20
382	1	1880-05-05	1894-12-25	\N	359	441	1880-06-07
383	1	1880-05-06	1903-11-09	\N	360	442	1880-05-13
384	1	1880-05-25	1892-07-27	\N	361	443	1880-05-27
385	1	1880-05-25	1888-10-17	\N	362	444	1880-05-27
386	1	1874-03-05	1890-04-29	\N	363	403	1874-06-02
387	1	1874-03-06	1886-02-15	\N	364	404	1874-03-10
388	1	1881-10-06	1911-11-25	\N	365	448	1882-02-07
389	1	1881-10-07	1909-03-09	\N	366	449	1882-03-09
390	1	1881-10-08	1921-08-01	\N	367	450	1882-02-07
391	1	1881-10-10	1916-03-01	\N	368	451	1882-07-13
392	1	1881-10-11	1926-10-29	\N	369	452	1882-02-07
393	1	1881-10-12	1894-03-04	\N	370	453	1882-02-07
394	1	1882-02-03	1892-05-09	\N	371	455	1882-04-24
395	1	1882-06-23	1889-10-16	\N	372	456	1882-06-27
396	1	1882-11-24	1895-03-30	\N	373	457	1883-04-12
397	1	1882-11-25	1913-03-25	\N	374	458	1883-02-15
398	1	1884-01-24	1892-10-06	\N	375	460	1884-03-11
399	1	1884-03-04	1892-03-14	\N	376	461	1884-05-20
400	1	1884-11-04	1897-05-25	\N	377	463	1884-11-11
401	1	1880-05-03	1898-11-19	\N	378	437	1880-05-27
402	1	1880-04-28	1891-11-24	\N	379	432	1881-01-06
403	1	1876-06-10	1904-11-15	\N	380	420	1876-06-15
404	1	1877-01-03	1886-05-02	\N	381	426	1877-02-08
405	1	1882-12-30	1895-05-04	\N	319	459	1883-02-15
406	1	1884-11-05	1893-02-04	\N	382	464	1884-11-11
407	1	1884-11-07	1901-03-14	\N	383	465	1884-11-11
408	1	1884-11-08	1903-07-06	\N	384	466	1884-11-11
409	1	1884-11-10	1908-10-05	\N	385	467	1884-11-13
410	1	1885-06-26	1921-12-11	\N	386	468	1885-06-26
411	1	1885-06-27	1904-06-05	\N	387	469	1885-07-13
412	1	1885-06-28	1898-11-27	\N	388	470	1885-07-13
413	1	1885-06-29	1915-03-31	\N	389	471	1885-07-09
414	1	1885-06-30	1897-07-17	\N	390	472	1885-07-07
415	1	1885-07-01	1886-10-27	\N	391	473	1885-07-07
416	1	1885-07-02	1904-12-06	\N	392	474	1885-07-13
417	1	1885-07-03	1905-07-22	\N	393	476	1885-07-07
418	1	1885-07-04	1913-05-22	\N	394	477	1885-07-06
419	1	1885-07-06	1893-01-20	\N	395	478	1885-07-06
420	1	1885-07-23	1901-06-10	\N	396	481	1885-07-28
421	1	1885-07-24	1899-05-24	\N	397	482	1885-07-27
422	1	1885-09-28	1913-03-25	\N	374	483	1886-01-19
423	1	1885-11-18	1890-12-01	\N	398	484	1886-01-19
424	1	1885-12-29	1905-11-04	\N	399	485	1886-01-19
425	1	1885-12-30	1893-01-18	\N	400	486	1886-01-26
426	1	1881-03-11	1884-08-25	\N	401	446	1881-07-05
427	1	1886-02-16	1887-04-03	\N	402	490	1886-02-25
428	1	1886-02-17	1905-04-29	\N	403	491	1886-02-23
429	1	1886-03-22	1912-05-18	\N	404	492	1886-04-01
430	1	1886-03-23	1896-10-07	\N	405	493	1886-04-01
431	1	1886-05-11	1886-05-17	\N	406	494	\N
432	1	1886-08-13	1898-04-16	\N	407	495	1886-08-19
433	1	1886-08-14	1900-10-15	\N	408	497	1887-01-27
434	1	1886-08-16	1918-02-23	\N	409	498	1886-08-19
435	1	1886-08-17	1907-02-04	\N	410	499	1886-08-19
436	1	1886-08-19	1914-01-08	\N	411	500	1886-09-02
437	1	1886-09-09	1905-01-09	\N	412	502	1887-07-12
438	1	1887-01-25	1913-02-17	\N	413	503	1887-01-27
439	1	1887-05-12	1902-09-03	\N	414	504	1892-06-23
440	1	1887-07-01	1904-02-16	\N	415	506	1887-07-11
441	1	1887-07-02	1931-03-07	\N	416	507	1887-07-12
442	1	1885-07-03	1887-01-12	\N	417	475	1885-07-06
443	1	1887-07-01	1900-04-19	\N	418	505	1887-07-12
444	1	1885-07-11	1922-10-19	\N	320	479	1885-07-14
445	1	1887-07-04	1908-05-14	\N	419	508	1887-07-12
446	1	1887-07-05	1890-06-27	\N	420	509	1887-07-15
447	1	1887-07-06	1900-12-27	\N	421	510	1887-07-29
448	1	1887-07-07	1894-10-22	\N	422	511	1887-07-12
449	1	1887-07-08	1887-08-09	\N	423	512	1888-04-17
450	1	1887-07-09	1891-10-02	\N	424	513	1887-07-11
451	1	1887-07-22	1889-08-28	\N	425	514	1887-07-25
452	1	1888-02-23	1914-01-29	\N	426	515	1888-02-28
453	1	1888-10-27	1896-11-28	\N	427	516	1888-11-13
454	1	1889-12-05	1901-09-08	\N	428	519	1889-12-06
455	1	1890-04-14	1907-01-23	\N	429	520	1890-04-28
456	1	1891-01-20	1893-12-31	\N	430	522	1891-01-22
457	1	1891-01-21	1927-10-07	\N	431	523	1891-01-22
458	1	1891-01-28	1894-03-29	\N	432	524	1891-01-29
459	1	1891-07-15	1906-02-02	\N	433	526	1891-07-27
460	1	1891-08-14	1920-09-05	\N	434	527	\N
461	1	1891-11-11	1913-08-13	\N	435	528	1914-02-11
462	1	1892-02-20	1914-11-14	\N	436	529	1893-06-19
463	1	1886-02-08	1899-03-01	\N	437	488	1886-02-08
464	1	1886-02-15	1898-04-03	\N	438	489	1886-02-18
465	1	1892-06-18	1902-01-15	\N	439	534	1892-06-20
466	1	1892-06-20	1917-01-29	\N	440	535	1893-07-24
467	1	1892-08-20	1904-03-06	\N	441	536	1892-12-05
468	1	1892-08-22	1917-02-26	\N	442	539	1893-01-31
469	1	1892-08-23	1895-12-19	\N	443	541	1893-04-20
470	1	1892-08-25	1908-02-05	\N	444	543	1893-01-31
471	1	1892-08-26	1909-01-16	\N	445	544	1893-01-31
472	1	1892-08-27	1898-12-15	\N	446	545	1893-02-07
473	1	1892-08-29	1895-12-11	\N	447	546	1893-05-15
474	1	1892-08-30	1912-09-24	\N	448	547	1893-01-31
475	1	1892-09-03	1898-05-29	\N	449	548	1893-01-31
476	1	1892-09-05	1907-11-27	\N	450	549	1893-01-31
477	1	1893-06-09	1894-11-28	\N	451	550	1893-06-19
478	1	1893-06-22	1899-10-11	\N	452	551	1893-07-07
479	1	1889-07-29	1912-01-29	\N	453	518	1890-02-13
480	1	1892-05-24	1936-01-20	\N	454	533	1892-06-17
481	1	1892-08-23	1910-12-24	\N	455	540	1893-01-31
482	1	1892-08-22	1906-10-30	\N	456	538	1893-01-31
483	1	1888-11-17	1902-02-12	\N	457	517	1889-02-21
484	1	1892-08-22	1929-03-11	\N	458	537	1893-01-31
485	1	1893-06-23	1908-02-15	\N	459	552	1893-07-04
486	1	1893-06-26	1894-10-19	\N	460	554	1893-07-04
487	1	1893-08-21	1912-01-30	\N	461	555	1893-09-05
488	1	1893-09-23	1894-04-10	\N	462	556	1893-11-09
489	1	1894-03-30	1913-06-04	\N	463	557	1894-04-23
490	1	1894-04-16	1915-10-29	\N	464	558	1894-04-23
491	1	1894-05-07	1900-08-10	\N	465	559	1894-05-28
492	1	1894-08-13	1907-02-20	\N	466	560	1894-08-14
493	1	1895-05-09	1912-10-24	\N	467	561	1896-02-11
494	1	1895-07-16	1928-06-13	\N	468	562	1896-02-11
495	1	1895-07-18	1900-06-20	\N	469	564	1895-08-13
496	1	1895-07-19	1912-02-10	\N	470	565	1895-08-13
497	1	1895-07-25	1930-05-27	\N	471	566	1897-03-25
498	1	1895-08-03	1914-01-29	\N	426	567	1895-08-13
499	1	1895-08-03	1921-05-06	\N	472	568	1896-02-11
500	1	1895-08-05	1913-04-03	\N	473	569	1895-08-13
501	1	1895-08-05	1911-08-18	\N	474	570	1896-02-11
502	1	1895-11-14	1919-08-22	\N	475	571	1896-02-11
503	1	1895-11-15	1903-01-09	\N	476	572	1896-02-11
504	1	1895-11-16	1908-11-24	\N	477	573	1896-02-11
505	1	1892-02-23	1907-12-17	\N	478	531	1892-02-25
506	1	1896-08-11	1897-10-28	\N	479	579	1896-08-13
507	1	1897-02-05	1917-12-20	\N	480	580	1897-03-25
508	1	1897-02-06	1912-02-10	\N	481	581	1897-02-23
509	1	1897-07-22	1909-03-16	\N	482	582	1898-05-12
510	1	1897-07-23	1915-12-13	\N	483	583	1898-02-15
511	1	1897-07-24	1924-01-21	\N	484	584	1898-02-08
512	1	1897-07-26	1899-12-25	\N	485	585	1897-08-05
513	1	1897-07-27	1898-03-06	\N	486	586	1909-07-05
514	1	1897-07-28	1901-02-12	\N	487	587	1897-07-30
515	1	1897-11-11	1899-05-24	\N	397	589	1898-02-08
516	1	1897-11-29	1909-02-01	\N	488	590	1963-07-17
517	1	1898-01-20	1923-08-30	\N	489	593	1898-02-08
518	1	1898-06-11	1917-03-30	\N	490	594	1898-07-01
519	1	1898-06-13	1907-04-21	\N	491	595	1898-06-20
520	1	1898-11-01	1916-06-05	\N	492	596	1899-07-25
521	1	1899-01-25	1917-01-29	\N	440	597	1899-07-25
522	1	1899-01-25	1906-05-12	\N	493	598	1899-06-27
523	1	1895-07-17	1945-06-20	\N	494	563	1895-08-15
524	1	1898-01-19	1921-12-11	\N	386	591	1898-02-08
525	1	1899-01-26	1906-01-06	\N	495	599	1899-02-07
526	1	1899-01-27	1907-10-06	\N	496	600	1899-02-07
527	1	1899-01-28	1902-10-13	\N	497	601	1899-02-07
528	1	1899-08-02	1925-03-02	\N	498	602	1925-07-08
529	1	1899-08-22	1902-05-24	\N	499	603	1899-10-26
530	1	1899-11-14	1909-02-02	\N	500	605	1899-11-16
531	1	1900-01-20	1911-09-29	\N	501	606	1900-01-30
532	1	1900-01-22	1913-05-28	\N	502	607	1900-01-30
533	1	1900-05-10	1921-12-09	\N	503	608	1900-05-14
534	1	1900-06-15	1901-09-08	\N	428	609	1902-01-16
535	1	1900-06-16	1914-09-07	\N	504	610	1900-06-25
536	1	1900-06-18	1915-12-15	\N	505	611	1900-06-18
537	1	1900-12-18	1907-02-07	\N	506	613	1901-02-14
538	1	1900-12-19	1904-11-28	\N	507	614	1901-02-14
539	1	1901-02-11	1914-11-14	\N	436	615	1901-02-14
540	1	1901-06-03	1925-05-13	\N	508	616	1901-06-13
541	1	1896-06-08	1922-08-10	\N	509	576	1896-06-26
542	1	1896-06-17	1906-08-04	\N	510	578	\N
543	1	1902-07-15	1905-01-22	\N	511	623	1902-08-07
544	1	1902-07-16	1939-12-20	\N	512	624	1904-02-02
545	1	1902-07-17	1917-04-04	\N	513	625	1902-07-21
546	1	1902-07-18	1925-02-22	\N	514	626	1902-07-29
547	1	1902-07-19	1925-01-27	\N	515	627	1902-07-22
548	1	1902-07-21	1924-08-15	\N	516	628	1902-08-07
549	1	1902-07-22	1916-08-17	\N	517	629	1902-07-24
550	1	1903-07-31	1916-01-09	\N	518	631	1903-08-06
551	1	1903-08-01	1923-04-06	\N	519	632	1903-08-06
552	1	1903-08-03	1915-01-12	\N	520	633	1903-08-06
553	1	1903-08-04	1941-10-16	\N	521	634	1904-02-25
554	1	1905-02-23	1905-04-09	\N	522	635	\N
555	1	1905-03-09	1942-08-21	\N	523	636	1905-04-04
556	1	1905-07-06	1909-11-06	\N	524	637	1905-07-18
557	1	1905-12-18	1927-10-07	\N	431	639	1906-02-13
558	1	1905-12-18	1925-11-14	\N	525	640	1906-02-13
559	1	1905-12-19	1922-09-26	\N	526	641	1906-02-13
560	1	1901-08-06	1917-01-29	\N	440	617	1901-08-08
561	1	1905-12-18	1923-03-06	\N	527	638	1906-02-13
562	1	1902-10-27	1908-02-29	\N	528	630	1904-03-14
563	1	1905-12-19	1932-03-13	\N	529	642	1906-02-13
564	1	1905-12-20	1923-03-21	\N	530	643	1906-02-13
565	1	1905-12-22	1906-01-09	\N	531	645	1906-06-18
566	1	1905-12-23	1925-05-17	\N	532	646	1906-02-19
567	1	1905-12-26	1929-03-03	\N	533	647	1906-02-13
568	1	1905-12-27	1922-08-14	\N	534	648	1906-02-14
569	1	1905-12-28	1913-03-11	\N	535	649	1907-07-16
570	1	1905-12-28	1919-01-07	\N	536	650	1906-02-13
571	1	1905-12-29	1920-09-17	\N	537	651	1906-02-14
572	1	1905-12-30	1945-01-09	\N	538	652	1906-02-14
573	1	1906-01-06	1916-04-30	\N	539	653	1906-02-14
574	1	1906-01-08	1923-11-30	\N	540	654	1906-02-13
575	1	1906-01-10	1923-03-01	\N	541	656	1906-02-19
576	1	1906-01-11	1917-05-10	\N	542	657	1906-02-14
577	1	1906-01-12	1908-03-04	\N	543	658	1906-02-14
578	1	1906-01-13	1936-11-21	\N	544	659	1906-02-14
579	1	1906-01-09	1935-06-21	\N	545	655	1906-02-14
580	1	1902-07-14	1934-01-03	\N	546	621	1902-07-24
581	1	1906-07-14	1918-05-11	\N	547	663	1906-07-19
582	1	1906-07-16	1928-04-19	\N	548	664	1906-07-23
583	1	1906-07-17	1924-06-06	\N	549	665	1906-07-23
584	1	1906-07-18	1915-07-27	\N	550	666	1906-07-23
585	1	1906-07-19	1915-12-07	\N	551	667	1906-07-23
586	1	1906-07-20	1907-02-13	\N	552	668	1907-04-25
587	1	1907-03-06	1911-01-03	\N	553	669	1907-03-07
588	1	1907-07-17	1911-03-16	\N	554	670	1907-08-01
589	1	1907-07-18	1911-01-12	\N	555	671	1907-08-01
590	1	1907-07-19	1925-02-08	\N	556	672	1907-08-01
591	1	1907-07-20	1919-10-21	\N	557	673	\N
592	1	1908-05-02	1923-09-23	\N	558	674	1908-05-05
593	1	1908-05-04	1911-02-25	\N	559	675	1908-05-05
594	1	1908-05-22	1911-09-13	\N	560	676	1908-05-26
595	1	1908-07-02	1925-06-09	\N	561	677	1908-07-14
596	1	1908-07-03	1925-10-21	\N	562	678	1908-07-20
597	1	1908-07-04	1912-03-25	\N	563	679	1909-06-29
598	1	1908-07-06	1938-03-28	\N	564	680	1908-07-13
599	1	1909-02-16	1913-04-22	\N	565	682	1909-02-16
600	1	1909-05-12	1934-11-04	\N	566	684	1909-07-05
601	1	1909-12-07	1920-07-10	\N	567	685	1910-03-10
602	1	1909-12-08	1932-06-27	\N	568	686	1911-02-15
603	1	1910-03-15	1930-03-06	\N	569	687	1910-04-14
604	1	1910-03-15	1939-06-14	\N	570	688	1910-03-22
605	1	1910-03-16	1929-09-03	\N	571	689	1910-04-07
606	1	1910-04-27	1936-12-06	\N	572	690	1910-04-28
607	1	1910-07-13	1929-02-23	\N	573	692	1910-07-21
608	1	1910-07-14	1913-01-31	\N	574	693	1910-07-25
609	1	1910-07-15	1934-09-05	\N	575	694	1910-07-26
610	1	1910-07-16	1927-05-01	\N	576	695	1910-07-27
611	1	1910-07-18	1927-12-26	\N	577	696	1910-07-28
612	1	1910-07-19	1912-11-10	\N	578	697	1910-07-25
613	1	1910-07-21	1944-08-02	\N	579	699	1916-05-16
614	1	1910-09-21	1914-09-02	\N	580	700	1911-07-10
615	1	1910-10-07	1918-09-11	\N	581	701	1910-10-19
616	1	1911-03-27	1928-08-19	\N	582	702	1911-03-30
617	1	1911-04-03	1920-11-21	\N	583	703	1911-05-16
618	1	1906-02-01	1911-01-29	\N	584	661	1906-02-14
619	1	1906-02-20	1939-02-28	\N	585	662	1906-04-05
620	1	1909-02-15	1925-01-11	\N	586	681	1909-02-16
621	1	1911-06-24	1914-08-27	\N	587	708	1911-07-24
622	1	1911-06-26	1932-05-23	\N	588	709	1911-07-19
623	1	1911-06-27	1933-03-19	\N	589	710	1911-07-19
624	1	1911-06-28	1933-05-01	\N	590	711	1911-07-20
625	1	1911-06-29	1945-02-03	\N	591	712	1911-07-17
626	1	1911-07-03	1927-02-20	\N	592	715	1911-08-01
627	1	1911-07-04	1923-11-30	\N	540	716	1911-08-01
628	1	1911-07-04	1924-08-15	\N	516	717	1911-07-05
629	1	1911-07-05	1918-02-23	\N	409	718	1911-08-01
630	1	1911-07-05	1923-12-12	\N	593	719	1911-08-01
631	1	1911-07-06	1926-01-15	\N	594	720	1911-07-25
632	1	1911-11-02	1926-12-13	\N	595	722	1911-11-14
633	1	1911-11-03	1936-07-25	\N	596	723	1911-11-14
634	1	1912-02-08	1927-12-14	\N	597	725	1912-02-19
635	1	1912-02-09	1929-02-18	\N	598	726	1912-03-21
636	1	1912-07-08	1931-11-02	\N	599	728	1912-10-14
637	1	1912-07-09	1926-02-20	\N	600	729	1912-07-11
638	1	1912-07-11	1918-09-13	\N	601	730	1913-07-17
639	1	1912-08-13	1920-09-13	\N	602	731	1912-12-10
640	1	1912-10-01	1921-03-09	\N	603	732	1912-10-14
641	1	1912-12-10	1967-09-29	\N	604	733	1912-12-10
642	1	1913-02-12	1933-02-07	\N	605	734	1913-06-05
643	1	1912-02-26	1928-06-13	\N	606	727	1912-03-13
644	1	1913-02-14	1945-03-24	\N	607	735	1913-03-10
645	1	1913-10-20	1934-05-24	\N	608	737	1913-10-20
646	1	1913-11-24	1915-12-15	\N	505	738	\N
647	1	1914-01-09	1935-12-30	\N	609	739	1914-02-12
648	1	1914-01-15	1928-10-02	\N	610	740	1914-04-28
649	1	1914-01-16	1941-06-30	\N	611	741	1914-02-10
650	1	1914-01-17	1940-11-26	\N	612	742	1914-03-18
651	1	1914-01-28	1922-01-22	\N	613	743	1914-02-10
652	1	1914-05-11	1934-10-15	\N	614	744	1914-06-15
653	1	1914-07-01	1920-06-18	\N	615	745	1914-07-02
654	1	1914-07-02	1941-11-01	\N	616	746	1914-07-20
655	1	1914-07-03	1921-02-28	\N	617	747	1914-07-15
656	1	1914-07-04	1926-09-18	\N	618	748	1914-07-13
657	1	1911-06-22	1917-06-04	\N	619	706	1911-07-24
658	1	1912-02-07	1926-01-16	\N	620	724	1917-05-16
659	1	1911-06-23	1931-03-31	\N	621	707	1911-07-24
660	1	1915-06-14	1934-12-05	\N	622	754	1915-06-22
661	1	1915-06-28	1919-09-26	\N	623	755	1916-04-12
662	1	1915-06-29	1930-05-22	\N	624	756	1915-06-30
663	1	1916-01-01	1925-05-22	\N	625	757	1916-02-29
664	1	1916-01-22	1929-09-03	\N	571	758	1916-02-22
665	1	1916-01-22	1919-09-06	\N	626	759	1916-01-26
666	1	1916-01-24	1934-03-17	\N	627	760	1916-02-16
667	1	1916-01-25	1923-12-10	\N	628	761	1916-11-23
668	1	1916-01-26	1919-10-18	\N	629	762	1916-02-16
669	1	1916-01-27	1930-12-07	\N	630	763	1916-02-22
670	1	1916-01-28	1918-07-03	\N	631	764	1916-02-24
671	1	1916-06-20	1923-05-29	\N	632	765	1916-06-22
672	1	1916-06-26	1935-12-30	\N	609	766	1916-07-26
673	1	1916-06-26	1935-02-25	\N	633	767	1916-07-13
674	1	1916-06-27	1928-11-05	\N	634	768	1916-07-26
675	1	1916-06-28	1933-08-20	\N	635	769	1916-07-20
676	1	1916-06-29	1918-11-26	\N	636	770	1916-07-13
677	1	1916-06-30	1925-06-17	\N	637	771	1916-07-20
678	1	1916-07-27	1933-09-07	\N	638	772	1916-08-01
679	1	1917-01-01	1926-04-24	\N	639	775	1917-02-13
680	1	1917-01-02	1927-05-01	\N	576	776	1917-02-15
681	1	1917-01-02	1964-06-09	\N	640	777	1917-02-14
682	1	1917-01-03	1922-02-24	\N	641	778	1917-02-07
683	1	1917-01-03	1943-02-15	\N	642	779	1917-02-08
684	1	1917-01-04	1929-11-23	\N	643	780	1917-02-04
685	1	1917-01-05	1923-06-07	\N	644	781	1917-02-08
686	1	1917-01-06	1925-01-05	\N	645	782	1925-03-25
687	1	1917-05-05	1938-01-28	\N	646	783	1920-04-28
688	1	1917-05-07	1927-01-20	\N	647	784	1917-05-16
689	1	1917-06-19	1928-12-26	\N	648	785	1917-07-04
690	1	1917-06-20	1933-10-18	\N	649	786	1917-07-10
691	1	1917-06-21	1923-08-30	\N	489	787	1917-06-27
692	1	1917-06-21	1925-05-07	\N	650	788	1917-07-24
693	1	1917-06-22	1934-09-05	\N	575	789	1917-08-01
694	1	1917-06-22	1946-01-26	\N	651	790	1917-07-19
695	1	1917-06-23	1919-10-18	\N	629	791	1917-07-19
696	1	1917-06-23	1938-01-23	\N	652	792	1917-07-18
697	1	1914-12-14	1920-01-06	\N	653	750	1915-02-16
698	1	1915-04-12	1935-10-27	\N	654	752	1915-04-14
699	1	1917-11-01	1947-01-17	\N	655	797	1918-04-25
700	1	1918-01-14	1922-08-14	\N	534	799	1918-02-26
701	1	1918-01-15	1935-10-24	\N	656	801	1918-04-09
702	1	1918-01-16	1940-10-06	\N	657	802	1918-03-05
703	1	1918-01-16	1937-03-30	\N	658	803	1918-02-26
704	1	1918-01-17	1924-06-08	\N	659	804	1918-01-24
705	1	1918-01-18	1949-09-22	\N	660	805	1918-01-24
706	1	1918-01-19	1921-02-08	\N	661	806	1918-01-29
707	1	1918-06-15	1939-06-14	\N	570	807	1919-02-06
708	1	1918-06-19	1918-07-03	\N	631	809	\N
709	1	1918-06-27	1928-09-23	\N	662	811	1918-07-24
710	1	1918-06-26	1959-07-02	\N	663	810	1918-07-09
711	1	1918-06-28	1942-06-28	\N	664	812	1918-07-23
712	1	1918-06-29	1931-02-01	\N	665	813	1918-07-11
713	1	1919-05-16	1933-07-20	\N	666	829	1919-08-06
714	1	1918-07-01	1930-09-10	\N	667	814	1918-07-23
715	1	1918-07-02	1929-03-13	\N	668	815	1918-07-11
716	1	1918-07-09	1947-07-21	\N	669	816	1918-07-10
717	1	1918-09-02	1919-09-26	\N	623	817	1919-05-21
718	1	1918-10-15	1958-07-03	\N	670	818	1918-10-16
719	1	1918-11-14	1923-08-17	\N	671	820	1918-11-14
720	1	1918-11-16	1920-07-02	\N	672	821	1918-11-18
721	1	1919-02-03	1930-09-30	\N	673	822	1919-02-04
722	1	1919-02-04	1937-07-01	\N	674	823	1919-02-05
723	1	1917-07-18	1960-02-23	\N	675	796	1918-03-06
724	1	1919-02-05	1955-09-17	\N	676	824	1919-02-26
725	1	1919-02-14	1928-03-05	\N	677	825	1919-02-25
726	1	1919-03-24	1942-06-02	\N	678	826	1919-04-08
727	1	1919-03-27	1929-03-09	\N	679	827	1919-04-08
728	1	1919-04-24	1938-11-17	\N	680	828	1919-07-09
729	1	1919-05-17	1940-11-26	\N	612	831	1935-01-30
730	1	1919-05-17	1937-06-03	\N	681	832	1919-05-28
731	1	1919-05-19	1955-12-19	\N	682	833	1919-05-21
732	1	1919-05-20	1930-04-11	\N	683	834	1919-05-28
733	1	1919-09-27	1936-03-11	\N	684	835	1919-11-05
734	1	1918-06-17	1938-03-28	\N	564	808	1918-07-02
735	1	1919-10-06	1925-03-28	\N	685	839	1919-11-05
736	1	1919-10-07	1936-05-14	\N	686	840	1925-07-08
737	1	1919-10-07	1935-06-06	\N	687	841	1919-11-05
738	1	1919-10-08	1929-08-14	\N	688	842	1919-11-12
739	1	1919-10-27	1933-02-02	\N	689	844	1919-11-12
740	1	1919-11-01	1919-11-15	\N	690	846	1925-02-25
741	1	1919-11-18	1933-05-24	\N	691	847	1920-05-12
742	1	1919-11-29	1943-10-07	\N	692	848	1919-12-03
743	1	1919-12-12	1936-01-15	\N	693	849	1919-12-17
744	1	1920-02-09	1945-03-07	\N	694	853	1920-02-18
745	1	1921-01-14	1936-03-29	\N	695	858	1921-03-02
746	1	1920-04-21	1932-11-03	\N	696	854	1920-05-12
747	1	1921-01-15	1936-04-09	\N	697	859	1921-05-04
748	1	1920-11-08	1934-10-15	\N	614	856	1920-11-10
749	1	1920-12-06	1934-03-30	\N	698	857	1920-12-06
750	1	1921-01-17	1927-03-28	\N	699	860	1921-03-23
751	1	1921-01-18	1935-08-21	\N	700	861	1921-02-23
752	1	1921-01-19	1923-03-03	\N	701	862	1921-04-13
753	1	1921-06-15	1930-09-30	\N	673	868	1921-07-07
754	1	1921-06-15	1927-01-17	\N	702	869	1921-07-06
755	1	1921-04-28	1947-05-18	\N	703	863	1921-07-27
756	1	1921-06-01	1935-10-22	\N	704	864	1921-06-01
757	1	1921-06-03	1933-04-01	\N	705	865	1921-07-20
758	1	1921-06-04	1924-09-26	\N	706	866	1921-11-02
759	1	1921-06-04	1942-01-23	\N	707	867	1921-07-06
760	1	1917-07-16	1957-01-16	\N	708	794	1918-07-17
761	1	1920-02-02	1942-02-13	\N	709	852	1920-02-11
762	1	1917-07-17	1921-09-11	\N	710	795	1917-07-25
763	1	1921-06-28	1925-03-20	\N	711	870	1921-07-07
764	1	1921-06-28	1935-07-15	\N	712	871	1921-08-10
765	1	1921-07-01	1924-09-23	\N	713	872	1921-08-03
766	1	1922-01-23	1930-06-14	\N	714	877	1922-02-22
767	1	1922-01-24	1935-08-09	\N	715	878	1922-05-24
768	1	1921-07-08	1949-03-27	\N	716	873	1921-10-26
769	1	1921-07-09	1924-06-06	\N	549	874	1921-07-13
770	1	1921-07-26	1931-03-22	\N	717	875	1921-11-09
771	1	1921-08-24	1936-08-03	\N	718	876	1921-10-26
772	1	1919-09-29	1928-01-29	\N	719	836	1919-11-12
773	1	1919-10-04	1932-07-16	\N	720	838	1921-07-20
774	1	1919-10-09	1920-02-20	\N	721	843	1919-10-29
775	1	1922-06-20	1940-12-10	\N	722	885	1922-06-21
776	1	1922-07-18	1940-01-09	\N	723	886	1922-07-19
777	1	1922-07-20	1936-01-27	\N	724	887	1922-07-26
778	1	1923-07-23	1927-12-17	\N	725	899	1923-07-25
779	1	1922-11-20	1947-02-08	\N	726	888	1923-02-21
780	1	1922-11-21	1951-04-24	\N	727	889	1922-12-07
781	1	1922-11-22	1936-07-17	\N	728	890	1922-11-29
782	1	1922-11-23	1945-05-27	\N	729	891	1922-12-06
783	1	1922-11-28	1947-07-21	\N	669	894	1922-12-06
784	1	1922-11-30	1923-08-30	\N	489	895	1922-12-01
785	1	1923-02-12	1949-05-10	\N	730	896	1923-03-14
786	1	1923-02-14	1937-06-05	\N	731	897	1923-03-07
787	1	1923-02-20	1929-04-29	\N	732	898	1923-02-21
788	1	1923-07-24	1935-05-22	\N	733	900	1923-07-25
789	1	1924-01-08	1950-11-01	\N	734	903	1924-01-16
790	1	1923-10-12	1946-08-17	\N	735	901	1923-11-14
791	1	1923-12-24	1958-11-24	\N	736	902	1924-01-16
792	1	1924-01-12	1936-05-29	\N	737	904	1924-01-16
793	1	1924-01-21	1932-05-23	\N	588	905	1924-01-22
794	1	1924-01-21	1936-08-13	\N	738	906	1924-01-22
795	1	1924-02-19	1935-06-30	\N	739	910	1924-02-20
796	1	1924-02-09	1943-02-15	\N	740	907	1924-02-12
797	1	1924-02-11	1930-10-05	\N	741	908	1924-02-12
798	1	1924-02-12	1945-08-03	\N	742	909	1924-02-12
799	1	1924-05-07	1926-06-10	\N	743	911	1924-07-09
800	1	1925-01-19	1939-05-20	\N	744	913	1925-02-11
801	1	1925-01-28	1950-05-03	\N	745	914	1925-03-11
802	1	1922-11-28	1930-09-30	\N	673	893	1922-11-30
803	1	1922-06-05	1925-05-22	\N	746	883	1922-06-27
804	1	1926-01-19	1927-06-30	\N	747	921	1926-02-03
805	1	1925-06-12	1941-08-20	\N	748	916	1925-06-17
806	1	1925-11-16	1941-02-04	\N	749	919	1926-07-28
807	1	1925-12-22	1959-12-23	\N	750	920	1926-02-10
808	1	1926-01-28	1936-10-22	\N	751	922	1926-02-10
809	1	1922-01-26	1929-02-16	\N	752	880	1922-02-08
810	1	1922-06-19	1931-10-29	\N	753	884	1922-07-05
811	1	1922-03-24	1943-05-05	\N	754	881	1922-03-29
812	1	1926-08-04	1934-05-03	\N	755	927	1926-11-17
813	1	1927-01-18	1934-12-17	\N	756	929	1927-05-04
814	1	1926-10-25	1937-10-26	\N	757	928	1926-11-17
815	1	1927-01-20	1940-11-24	\N	758	930	1927-05-25
816	1	1927-01-29	1946-11-07	\N	759	931	1927-02-16
817	1	1927-01-31	1935-09-26	\N	760	933	1927-05-25
818	1	1927-06-21	1938-10-24	\N	761	934	1927-06-29
819	1	1927-07-04	1928-04-18	\N	762	935	1927-07-06
820	1	1928-01-11	1931-10-28	\N	763	937	1928-02-15
821	1	1927-11-07	1934-10-12	\N	764	936	1927-11-09
822	1	1928-01-19	1940-08-22	\N	765	939	1928-11-07
823	1	1928-03-16	1945-04-11	\N	766	941	1928-04-25
824	1	1928-02-06	1944-06-25	\N	767	940	1928-02-15
825	1	1928-06-15	1930-12-27	\N	768	945	1928-06-20
826	1	1928-04-05	1950-08-16	\N	769	943	1928-04-19
827	1	1928-05-08	1938-01-07	\N	770	944	\N
828	1	1928-06-26	1933-01-30	\N	771	946	1928-07-11
829	1	1928-07-05	1953-05-24	\N	772	947	1928-07-18
830	1	1929-03-18	1931-06-13	\N	773	950	1931-11-25
831	1	1928-11-14	1930-05-25	\N	774	948	1928-11-14
832	1	1929-02-11	1935-08-12	\N	775	949	1929-02-13
833	1	1929-03-19	1936-09-07	\N	776	951	1929-04-17
834	1	1929-03-20	1966-08-20	\N	777	952	1929-05-08
835	1	1929-06-17	1930-10-21	\N	778	955	1929-07-03
836	1	1929-05-01	1948-06-13	\N	779	953	1929-05-01
837	1	1929-05-07	1937-06-28	\N	780	954	1929-05-08
838	1	1929-06-18	1935-08-14	\N	781	956	1929-06-26
839	1	1929-06-18	1940-02-24	\N	782	957	1929-07-03
840	1	1929-06-19	1954-06-15	\N	783	958	1929-07-03
841	1	1929-07-04	1950-08-16	\N	769	963	1929-07-10
842	1	1929-06-20	1932-05-23	\N	588	959	1929-06-26
843	1	1925-02-09	1928-02-15	\N	784	915	1925-02-17
844	1	1929-06-21	1948-02-06	\N	785	960	1929-06-25
845	1	1929-06-22	1947-10-13	\N	786	961	1929-06-27
846	1	1929-07-05	1932-06-08	\N	787	964	1929-07-10
847	1	1929-07-08	1956-12-01	\N	788	965	1929-07-24
848	1	1929-07-09	1943-02-23	\N	789	966	1929-07-10
849	1	1929-07-10	1937-09-28	\N	790	967	1929-07-24
850	1	1926-07-16	1928-05-23	\N	791	926	1926-07-21
851	1	1930-01-16	1952-02-29	\N	792	975	1930-01-22
852	1	1930-01-17	1946-03-24	\N	793	976	1930-01-22
853	1	1929-09-17	1941-01-08	\N	794	973	1929-10-30
854	1	1930-01-18	1943-05-31	\N	795	977	1930-10-29
855	1	1930-01-20	1941-01-15	\N	796	978	1930-01-29
856	1	1930-01-21	1935-09-11	\N	797	979	1930-02-05
857	1	1930-01-23	1956-02-10	\N	798	980	1930-01-29
858	1	1930-06-17	1948-09-12	\N	799	982	1930-07-16
859	1	1930-06-18	1939-03-25	\N	800	983	1930-07-09
860	1	1930-02-03	1952-09-05	\N	801	981	1930-02-05
861	1	1930-07-10	1939-08-01	\N	802	984	1930-07-23
862	1	1931-01-20	1946-01-19	\N	803	985	1931-01-28
863	1	1931-01-21	1963-01-05	\N	804	986	1931-02-04
864	1	1931-01-22	1937-10-19	\N	805	987	1931-02-04
865	1	1931-01-23	1955-01-13	\N	806	988	1931-01-28
866	1	1931-11-24	1937-05-15	\N	807	991	1931-11-25
867	1	1931-12-05	1945-11-02	\N	808	992	1931-12-09
868	1	1931-03-23	1944-04-21	\N	809	990	1931-03-25
869	1	1931-12-07	1937-04-19	\N	810	993	1931-12-09
870	1	1932-01-13	1939-07-03	\N	811	994	1932-02-10
871	1	1932-01-14	1938-12-24	\N	812	995	1932-02-10
872	1	1932-01-18	1939-03-03	\N	813	996	1932-02-17
873	1	1932-01-21	1944-11-06	\N	814	997	1932-02-10
874	1	1932-01-25	1939-09-26	\N	815	998	1932-02-17
875	1	1932-01-30	1948-02-06	\N	785	999	1932-02-02
876	1	1932-06-17	1949-02-03	\N	816	1001	1932-06-29
877	1	1932-06-20	1944-06-24	\N	817	1002	1932-07-05
878	1	1932-04-11	1964-06-27	\N	818	1000	1932-04-13
879	1	1932-06-21	1944-06-16	\N	819	1003	1932-06-29
880	1	1932-06-28	1949-02-14	\N	820	1005	1932-07-05
881	1	1932-06-30	1950-06-13	\N	821	1006	1932-07-06
882	1	1926-05-07	1935-12-30	\N	609	925	1926-06-09
883	1	1933-01-19	1934-11-21	\N	822	1008	1933-02-15
884	1	1933-01-23	1955-08-13	\N	823	1009	1933-03-08
885	1	1933-01-26	1948-03-23	\N	824	1010	1933-02-15
886	1	1933-02-03	1939-05-25	\N	825	1011	1933-06-14
887	1	1929-07-16	1938-09-24	\N	826	969	1929-07-17
888	1	1929-07-22	1942-05-05	\N	827	970	1929-07-24
889	1	1929-07-24	1947-03-14	\N	828	971	1935-05-08
890	1	1933-06-24	1948-12-08	\N	829	1016	1933-07-05
891	1	1933-07-24	1947-12-11	\N	830	1017	1933-11-15
892	1	1934-01-11	1941-04-01	\N	831	1018	1934-02-07
893	1	1934-01-12	1948-11-01	\N	832	1019	1934-02-07
894	1	1934-01-15	1942-09-02	\N	833	1021	1934-02-14
895	1	1934-01-16	1973-04-18	\N	834	1022	1934-02-14
896	1	1934-06-27	1955-10-06	\N	835	1024	1934-07-25
897	1	1934-06-28	1941-01-15	\N	796	1025	1934-07-25
898	1	1934-06-28	1943-01-22	\N	836	1026	1934-07-11
899	1	1934-06-29	1936-04-30	\N	837	1027	1934-07-11
900	1	1935-01-24	1949-11-18	\N	838	1029	1935-02-06
901	1	1935-01-25	1944-07-20	\N	839	1030	1935-03-13
902	1	1935-01-26	1949-05-06	\N	840	1031	1935-02-06
903	1	1935-06-24	1958-07-03	\N	670	1033	1935-07-09
904	1	1935-06-01	1940-02-11	\N	841	1032	1935-07-09
905	1	1935-06-24	1935-10-20	\N	842	1034	1935-07-03
906	1	1935-06-25	1960-09-03	\N	843	1035	1935-07-03
907	1	1935-06-27	1957-07-07	\N	844	1037	1935-07-24
908	1	1935-06-28	1946-04-10	\N	845	1038	1935-07-24
909	1	1935-06-29	1941-11-26	\N	846	1039	1936-06-24
910	1	1936-01-11	1937-08-14	\N	847	1046	1936-04-29
911	1	1935-07-15	1960-07-11	\N	848	1040	1935-07-15
912	1	1935-10-07	1958-03-23	\N	849	1041	1935-10-22
913	1	1935-10-14	1956-12-22	\N	850	1042	1935-10-22
914	1	1935-11-29	1972-07-27	\N	851	1043	1935-12-04
915	1	1935-11-30	1969-03-21	\N	852	1044	1935-12-04
916	1	1935-12-20	1955-05-02	\N	853	1045	1938-05-11
917	1	1936-01-31	1956-02-10	\N	798	1048	1936-02-05
918	1	1936-02-01	1937-06-13	\N	854	1049	1936-02-05
919	1	1936-02-03	1968-02-06	\N	855	1050	1936-03-11
920	1	1936-02-24	1959-08-23	\N	856	1051	1936-03-11
921	1	1936-07-14	1946-09-21	\N	857	1053	1936-11-11
922	1	1936-07-15	1969-06-01	\N	858	1054	1936-07-29
923	1	1936-07-16	1941-05-23	\N	859	1055	1936-07-29
924	1	1933-03-01	1941-07-26	\N	860	1013	1933-05-10
925	1	1933-06-21	1947-11-07	\N	861	1014	1933-06-28
926	1	1933-06-22	1960-07-25	\N	862	1015	1933-07-26
927	1	1937-02-24	1961-07-13	\N	863	1061	1937-04-28
928	1	1937-05-22	1951-12-11	\N	864	1063	1937-06-30
929	1	1937-05-24	1948-11-30	\N	865	1064	1937-06-16
930	1	1937-06-03	1948-05-26	\N	866	1067	1937-06-16
931	1	1937-06-04	1967-11-15	\N	867	1068	1937-07-07
932	1	1937-06-07	1941-05-31	\N	868	1069	1937-07-07
933	1	1937-06-08	1947-12-14	\N	869	1070	1937-06-09
934	1	1937-06-08	1963-02-05	\N	870	1071	1937-06-09
935	1	1937-06-08	1955-01-01	\N	871	1072	1937-06-23
936	1	1937-06-09	1940-09-03	\N	872	1073	1937-06-23
937	1	1937-06-10	1949-11-14	\N	873	1074	1937-06-23
938	1	1937-06-10	1953-11-03	\N	874	1075	1937-07-14
939	1	1937-06-11	1970-12-11	\N	875	1076	1937-06-30
940	1	1937-06-11	1946-04-10	\N	876	1077	1937-07-14
941	1	1937-06-12	1949-12-04	\N	877	1078	1937-11-17
942	1	1938-01-24	1963-08-22	\N	878	1080	1938-05-18
943	1	1938-01-05	1944-08-19	\N	879	1079	1938-02-02
944	1	1938-01-24	1938-04-14	\N	880	1081	1938-02-16
945	1	1938-01-25	1951-05-17	\N	881	1082	1938-02-02
946	1	1938-01-26	1958-10-22	\N	882	1083	1938-02-09
947	1	1938-01-28	1956-06-17	\N	883	1085	1938-02-16
948	1	1938-06-25	1959-07-02	\N	663	1087	1938-07-20
949	1	1938-03-28	1956-02-13	\N	884	1086	1938-03-29
950	1	1938-06-27	1941-08-20	\N	748	1088	1938-06-29
951	1	1938-06-28	1941-04-16	\N	885	1089	1938-07-20
952	1	1938-06-29	1956-02-17	\N	886	1090	1938-07-20
953	1	1939-02-01	1945-02-04	\N	887	1091	1939-02-08
954	1	1939-02-02	1962-12-07	\N	888	1092	1939-02-15
955	1	1939-02-03	1963-01-25	\N	889	1093	1939-02-15
956	1	1939-02-04	1948-08-13	\N	890	1094	1939-02-08
957	1	1939-07-04	1944-11-17	\N	891	1095	1939-07-19
958	1	1939-07-05	1958-03-17	\N	892	1096	1939-07-12
959	1	1937-06-02	1956-03-10	\N	893	1066	1937-06-30
960	1	1937-06-01	1944-11-07	\N	894	1065	1945-11-28
961	1	1936-05-26	1941-08-12	\N	895	1052	1936-06-24
962	1	1939-07-06	1963-08-17	\N	896	1097	1939-07-12
963	1	1936-10-30	1945-03-07	\N	694	1057	1936-12-16
964	1	1937-02-16	1948-09-10	\N	897	1058	1937-03-24
965	1	1937-02-23	1942-08-17	\N	898	1060	1937-03-10
966	1	1939-09-22	1958-03-23	\N	849	1101	1939-09-27
967	1	1940-04-18	1940-11-24	\N	899	1102	1940-04-24
968	1	1940-05-20	1954-01-11	\N	900	1103	1940-05-21
969	1	1940-05-28	1947-12-07	\N	901	1104	1940-05-29
970	1	1940-06-27	1968-01-07	\N	902	1106	1940-07-03
971	1	1940-06-28	1963-10-23	\N	903	1107	1940-07-03
972	1	1941-01-25	1956-12-10	\N	904	1111	1941-02-12
973	1	1940-10-28	1943-05-05	\N	754	1109	\N
974	1	1941-01-27	1962-01-18	\N	905	1112	1941-02-05
975	1	1941-01-28	1954-07-20	\N	906	1113	1941-02-05
976	1	1941-01-29	1959-09-22	\N	907	1114	1941-02-26
977	1	1941-07-03	1957-02-14	\N	908	1116	1941-07-16
978	1	1941-05-19	1965-03-18	\N	909	1115	1941-06-11
979	1	1941-07-16	1947-06-27	\N	910	1118	1941-07-23
980	1	1941-07-16	1952-04-16	\N	911	1119	1941-07-23
981	1	1942-01-12	1960-11-17	\N	912	1122	1942-01-21
982	1	1941-08-06	1971-01-31	\N	913	1120	1941-09-10
983	1	1941-08-14	1970-04-01	\N	914	1121	1941-09-10
984	1	1942-01-16	1970-03-31	\N	915	1123	1942-01-21
985	1	1942-01-21	1943-07-26	\N	916	1124	1942-01-28
986	1	1942-01-28	1954-01-08	\N	917	1125	1942-02-04
987	1	1942-02-04	1961-06-07	\N	918	1126	1942-02-04
988	1	1942-02-20	1946-03-15	\N	919	1127	1942-02-25
989	1	1942-07-06	1946-04-21	\N	920	1132	1942-07-08
990	1	1942-03-09	1993-01-14	\N	921	1128	1942-03-18
991	1	1942-04-02	1945-12-05	\N	922	1129	1942-04-15
992	1	1942-04-27	1965-12-24	\N	923	1130	1942-05-06
993	1	1942-04-27	1964-05-17	\N	924	1131	1942-05-06
994	1	1943-01-22	1945-12-26	\N	925	1133	1943-01-27
995	1	1943-03-08	1977-04-12	\N	926	1135	1943-03-31
996	1	1943-02-01	1947-12-10	\N	927	1134	1943-02-10
997	1	1943-05-17	1964-09-18	\N	928	1137	1945-11-07
998	1	1943-05-03	1962-07-08	\N	929	1136	1962-12-05
999	1	1944-01-27	1947-06-02	\N	930	1140	1944-02-16
1000	1	1944-01-28	1950-11-06	\N	931	1141	1944-02-16
1001	1	1943-07-22	1950-05-24	\N	932	1139	1943-07-28
1002	1	1939-07-08	1950-07-20	\N	933	1099	1939-07-26
1003	1	1940-06-26	1940-12-06	\N	934	1105	1940-07-03
1004	1	1939-09-06	1947-10-11	\N	935	1100	1939-09-06
1005	1	1944-04-18	1971-06-28	\N	936	1145	1944-04-18
1006	1	1945-02-01	1949-05-06	\N	840	1152	1945-02-21
1007	1	1944-07-14	1959-05-07	\N	937	1148	1944-10-11
1008	1	1944-07-19	1971-05-29	\N	938	1149	1944-07-19
1009	1	1944-10-13	1950-02-04	\N	939	1150	1945-05-30
1010	1	1945-02-12	1945-03-26	\N	940	1153	1945-06-13
1011	1	1945-02-12	1949-05-25	\N	941	1154	1945-03-14
1012	1	1945-07-02	1951-12-11	\N	864	1155	1945-08-01
1013	1	1945-07-02	1950-07-29	\N	942	1156	1945-08-07
1014	1	1945-07-03	1955-09-02	\N	943	1157	1945-10-16
1015	1	1945-07-06	1954-05-02	\N	944	1159	\N
1016	1	1945-07-07	1962-04-16	\N	945	1160	1945-08-03
1017	1	1945-07-09	1951-04-25	\N	946	1161	1945-08-03
1018	1	1945-07-10	1950-07-06	\N	947	1162	1945-08-07
1019	1	1945-07-11	1946-07-15	\N	948	1163	1945-08-01
1020	1	1945-07-12	1955-08-09	\N	949	1164	1945-10-31
1021	1	1945-07-13	1945-08-24	\N	950	1165	\N
1022	1	1945-07-14	1959-05-16	\N	951	1166	1945-08-02
1023	1	1945-07-23	1958-02-17	\N	952	1167	1945-08-01
1024	1	1945-08-01	1955-12-01	\N	953	1168	1945-08-22
1025	1	1945-09-12	1968-02-06	\N	855	1171	1945-10-24
1026	1	1945-08-02	1957-08-16	\N	954	1169	1945-08-02
1027	1	1945-08-16	1961-09-17	\N	955	1170	1945-08-21
1028	1	1945-09-12	1957-01-24	\N	956	1172	1945-10-10
1029	1	1945-09-13	1955-01-01	\N	871	1173	1945-10-10
1030	1	1945-09-13	1954-03-06	\N	957	1174	1945-10-17
1031	1	1945-09-14	1952-04-17	\N	958	1175	1945-10-17
1032	1	1945-09-15	1963-06-12	\N	959	1176	1945-11-21
1033	1	1945-09-18	1963-06-17	\N	960	1178	\N
1034	1	1945-09-19	1953-01-19	\N	961	1179	1945-10-24
1035	1	1944-01-31	1960-04-02	\N	962	1143	1944-02-02
1036	1	1945-10-19	1984-04-04	\N	963	1181	1945-10-23
1037	1	1945-11-12	1957-08-20	\N	964	1182	1945-11-20
1038	1	1944-02-01	1954-11-01	\N	965	1144	1944-02-09
1039	1	1944-06-26	1956-06-28	\N	966	1146	1944-06-28
1040	1	1945-11-16	1978-01-27	\N	967	1186	1945-11-28
1041	1	1944-07-11	1959-12-23	\N	750	1147	1944-07-12
1042	1	1945-11-17	1955-09-20	\N	968	1187	1945-11-20
1043	1	1945-12-01	1977-08-18	\N	969	1188	1945-12-12
1044	1	1946-01-09	1949-04-24	\N	970	1189	1946-01-11
1045	1	1946-01-25	1946-04-10	\N	876	1191	1946-02-06
1046	1	1946-01-26	1963-06-12	\N	959	1192	1946-02-27
1047	1	1947-05-01	1950-05-24	\N	932	1228	1947-06-04
1048	1	1946-01-28	1954-11-03	\N	971	1194	1946-03-06
1049	1	1946-01-29	1963-06-17	\N	960	1195	1946-02-27
1050	1	1946-01-30	1979-08-26	\N	972	1196	1946-01-30
1051	1	1946-01-31	1976-03-24	\N	973	1197	1946-07-24
1052	1	1946-02-11	1971-01-12	\N	974	1200	1946-02-20
1053	1	1946-02-05	1949-04-27	\N	975	1198	1946-02-13
1054	1	1946-02-08	1946-03-31	\N	976	1199	\N
1055	1	1946-02-12	1950-12-26	\N	977	1201	1946-03-06
1056	1	1946-03-12	1964-12-31	\N	978	1203	1947-06-04
1057	1	1946-06-25	1963-03-16	\N	979	1205	1946-06-25
1058	1	1946-06-26	1974-02-28	\N	980	1206	1946-07-24
1059	1	1946-04-05	1951-07-05	\N	981	1204	1946-05-15
1060	1	1946-06-27	1967-10-11	\N	982	1207	1946-07-10
1061	1	1946-07-16	1983-01-22	\N	983	1209	1946-07-25
1062	1	1946-07-17	1963-08-23	\N	984	1210	1946-10-09
1063	1	1946-07-18	1963-11-30	\N	985	1211	1946-07-24
1064	1	1946-08-23	1979-08-27	\N	986	1212	1946-10-23
1065	1	1946-09-19	1981-02-12	\N	987	1213	1946-10-09
1066	1	1947-01-13	1971-08-28	\N	988	1216	1947-02-19
1067	1	1947-01-14	1965-12-17	\N	989	1217	1947-02-05
1068	1	1946-10-28	1965-11-08	\N	990	1214	1946-10-30
1069	1	1947-01-06	1962-10-05	\N	991	1215	1947-01-22
1070	1	1947-01-15	1969-04-20	\N	992	1218	1947-04-16
1071	1	1947-01-16	1966-02-14	\N	993	1219	1947-02-19
1072	1	1947-01-17	1960-10-03	\N	994	1220	1947-02-12
1073	1	1947-01-20	1957-08-16	\N	954	1221	1947-01-21
1074	1	1947-01-20	1961-02-05	\N	995	1222	1947-02-05
1075	1	1947-01-21	1960-09-27	\N	996	1223	1947-01-22
1076	1	1947-03-18	1967-08-25	\N	997	1224	1947-03-26
1077	1	1945-11-14	1966-07-07	\N	998	1184	1945-11-20
1078	1	1945-11-15	1953-12-25	\N	999	1185	1945-11-20
1079	1	1946-01-23	1967-06-03	\N	1000	1190	1946-03-13
1080	1	1947-07-16	1966-10-15	\N	1001	1231	1947-07-30
1081	1	1947-10-09	1978-10-27	\N	1002	1232	1947-11-12
1082	1	1948-02-02	1963-01-05	\N	804	1235	1948-02-25
1083	1	1947-10-18	1979-08-27	\N	986	1233	1948-07-21
1084	1	1948-02-07	1969-10-30	\N	1003	1237	1948-02-25
1085	1	1948-02-09	1961-05-21	\N	1004	1238	1948-04-14
1086	1	1948-02-26	1954-10-31	\N	1005	1239	1948-03-10
1087	1	1948-06-22	1958-05-28	\N	1006	1240	1948-07-14
1088	1	1948-06-23	1951-09-22	\N	1007	1241	1948-07-14
1089	1	1948-06-24	1966-02-18	\N	1008	1242	1948-07-14
1090	1	1949-02-16	1960-08-23	\N	1009	1244	1949-02-23
1091	1	1948-10-06	1975-03-29	\N	1010	1243	1948-10-27
1092	1	1949-03-09	1971-06-25	\N	1011	1245	1949-03-09
1093	1	1949-06-21	1951-09-27	\N	1012	1248	1949-06-22
1094	1	1949-04-13	1966-01-20	\N	1013	1246	1949-04-13
1095	1	1949-07-07	1951-08-17	\N	1014	1249	\N
1096	1	1949-07-12	1975-02-25	\N	1015	1250	1949-07-13
1097	1	1950-01-30	1964-07-22	\N	1016	1252	1950-03-02
1098	1	1950-01-31	1970-12-10	\N	1017	1253	1950-03-02
1099	1	1950-02-01	1970-05-27	\N	1018	1254	1950-03-01
1100	1	1950-02-02	1960-08-20	\N	1019	1255	1950-03-01
1101	1	1950-02-03	1950-02-26	\N	1020	1256	\N
1102	1	1950-07-04	1972-05-11	\N	1021	1259	1950-07-19
1103	1	1950-03-17	1965-08-03	\N	1022	1257	1950-03-22
1104	1	1950-04-11	1980-03-31	\N	1023	1258	1950-04-26
1105	1	1950-07-05	1975-08-07	\N	1024	1260	1950-07-12
1106	1	1950-07-06	1958-04-06	\N	1025	1261	1950-07-12
1107	1	1950-07-07	1965-04-24	\N	1026	1262	1950-07-26
1108	1	1950-07-08	1967-02-18	\N	1027	1263	1950-07-26
1109	1	1950-07-10	1976-08-30	\N	1028	1264	1950-07-12
1110	1	1950-07-11	1954-07-01	\N	1029	1265	1950-10-18
1111	1	1981-05-12	2001-05-26	\N	1030	1856	1981-05-13
1112	1	1951-01-25	1965-06-13	\N	1031	1267	1951-02-14
1113	1	1950-09-29	1975-11-17	\N	1032	1266	1950-10-18
1114	1	1951-02-07	1966-06-14	\N	1033	1268	1951-04-11
1115	1	1947-07-03	1989-03-10	\N	1034	1229	1947-07-30
1116	1	1951-04-23	1954-08-24	\N	1035	1269	1951-04-25
1117	1	1947-04-23	1979-07-13	\N	1036	1227	1947-04-23
1118	1	1947-07-15	1952-09-05	\N	1037	1230	1947-07-16
1119	1	1951-11-12	1973-05-09	\N	1038	1273	1951-11-14
1120	1	1951-12-14	1958-05-05	\N	1039	1274	1952-05-21
1121	1	1951-12-22	1955-04-16	\N	1040	1276	1952-02-20
1122	1	1951-12-24	1957-08-16	\N	954	1277	1952-01-30
1123	1	1951-12-24	1968-11-20	\N	1041	1278	1952-02-05
1124	1	1952-01-05	1957-02-02	\N	1042	1279	1952-02-27
1125	1	1952-01-28	1958-01-04	\N	1043	1281	1952-01-30
1126	1	1952-01-30	1965-09-26	\N	1044	1282	1952-02-27
1127	1	1952-01-31	1962-08-26	\N	1045	1283	1952-02-20
1128	1	1952-04-10	1970-06-15	\N	1046	1285	1954-07-07
1129	1	1952-03-11	1969-06-16	\N	1047	1284	1952-03-12
1130	1	1952-06-24	1971-06-28	\N	936	1286	1952-06-25
1131	1	1952-07-01	1973-08-18	\N	1048	1287	1952-11-12
1132	1	1952-07-05	1954-01-01	\N	1049	1288	1952-07-23
1133	1	1952-07-12	1960-12-19	\N	1050	1289	1952-07-16
1134	1	1953-02-11	1982-11-28	\N	1051	1290	1953-04-01
1135	1	1953-02-12	1958-04-03	\N	1052	1291	1953-04-01
1136	1	1953-06-29	1960-05-01	\N	1053	1293	1953-07-07
1137	1	1953-06-30	1976-07-02	\N	1054	1294	1953-07-22
1138	1	1953-07-01	1957-09-29	\N	1055	1295	1953-07-22
1139	1	1953-07-02	1964-12-14	\N	1056	1296	1953-07-07
1140	1	1954-01-14	1957-02-16	\N	1057	1299	1954-01-20
1141	1	1954-01-16	1978-05-27	\N	1058	1300	1954-02-17
1142	1	1953-10-16	1975-06-27	\N	1059	1297	1953-10-21
1143	1	1953-11-04	1964-06-29	\N	1060	1298	1953-11-04
1144	1	1954-01-18	1965-03-18	\N	909	1301	1954-02-24
1145	1	1954-01-18	1961-04-22	\N	1061	1302	1954-01-27
1146	1	1954-01-30	1957-11-22	\N	1062	1303	1958-01-29
1147	1	1954-02-16	1980-11-15	\N	1063	1304	1954-02-17
1148	1	1954-07-03	1968-11-29	\N	1064	1305	1954-07-07
1149	1	1954-07-16	1971-01-31	\N	913	1306	1954-11-03
1150	1	1954-07-31	1955-07-15	\N	1065	1308	1955-03-30
1151	1	1951-06-27	1963-04-21	\N	1066	1271	1951-06-27
1152	1	1951-10-16	1963-07-04	\N	1067	1272	1952-10-29
1153	1	1954-09-09	1972-01-21	\N	1068	1309	1954-12-08
1154	1	1954-10-18	1971-06-28	\N	936	1311	1954-11-03
1155	1	1954-10-19	1967-01-27	\N	1069	1312	1954-10-19
1156	1	1951-12-20	1967-06-16	\N	1070	1275	1952-01-30
1157	1	1955-03-18	1971-05-08	\N	1071	1316	1955-10-26
1158	1	1955-05-04	1985-07-12	\N	1072	1317	1955-05-05
1159	1	1955-05-12	1974-08-28	\N	1073	1319	1955-06-22
1160	1	1955-07-25	1974-06-15	\N	1074	1321	1955-11-23
1161	1	1955-08-04	1975-05-22	\N	1075	1322	1955-11-23
1162	1	1956-01-20	1966-10-03	\N	1076	1331	1956-01-31
1163	1	1955-12-16	1967-10-08	\N	1077	1324	1956-01-25
1164	1	1956-01-12	1991-04-05	\N	1078	1326	1956-02-01
1165	1	1956-01-13	1961-10-17	\N	1079	1327	1956-02-15
1166	1	1956-01-17	1966-10-11	\N	1080	1328	1956-02-01
1167	1	1956-01-18	1960-07-13	\N	1081	1329	1956-01-26
1168	1	1956-01-19	1996-01-06	\N	1082	1330	1956-01-31
1169	1	1956-01-21	1971-07-19	\N	1083	1332	1956-03-21
1170	1	1956-01-23	1976-04-10	\N	1084	1333	1956-02-15
1171	1	1956-06-26	1957-07-03	\N	1085	1334	1956-07-11
1172	1	1956-07-09	1960-08-19	\N	1086	1335	1956-07-18
1173	1	1956-07-16	1977-08-07	\N	1087	1336	1956-10-30
1174	1	1957-01-21	1979-03-04	\N	1088	1337	1957-03-27
1175	1	1957-07-01	1963-10-26	\N	1089	1344	1957-07-24
1176	1	1957-01-22	1968-09-10	\N	1090	1338	1957-01-23
1177	1	1957-02-11	1965-01-09	\N	1091	1340	1957-04-03
1178	1	1957-02-12	1967-02-14	\N	1092	1341	1957-02-27
1179	1	1957-02-15	1974-11-05	\N	1093	1342	1957-05-22
1180	1	1957-04-24	1999-03-05	\N	1094	1343	1957-05-15
1181	1	1957-07-02	1972-03-29	\N	1095	1345	1957-07-17
1182	1	1958-01-31	1962-02-10	\N	1096	1349	1958-02-19
1183	1	1958-01-30	1976-10-10	\N	1097	1348	1958-02-18
1184	1	1958-02-17	1989-01-20	\N	1098	1350	1958-02-19
1185	1	1958-07-10	1962-07-21	\N	1099	1351	1958-07-16
1186	1	1958-07-11	1993-01-28	\N	1100	1352	1958-07-16
1187	1	1958-08-01	1974-12-19	\N	1101	1354	1958-10-22
1188	1	1958-08-02	1971-12-22	\N	1102	1355	1958-10-21
1189	1	1958-08-04	1983-05-02	\N	1103	1356	1958-10-22
1190	1	1958-08-05	1961-03-06	\N	1104	1357	1959-03-10
1191	1	1958-08-06	1984-09-23	\N	1105	1358	1958-10-21
1192	1	1955-01-28	1977-08-04	\N	1106	1314	1955-03-02
1193	1	1955-02-18	1970-04-01	\N	1107	1315	1955-04-27
1194	1	1955-06-20	1984-09-20	\N	1108	1320	1955-07-20
1195	1	1958-09-22	1971-05-22	\N	1109	1364	1958-10-21
1196	1	1958-09-24	1992-06-04	\N	1110	1365	1958-10-22
1197	1	1958-09-26	1994-01-03	\N	1111	1366	1958-10-22
1198	1	1958-10-06	1966-02-09	\N	1112	1368	1958-10-22
1199	1	1958-09-30	1972-09-15	\N	1113	1367	1958-10-21
1200	1	1959-02-14	2003-07-10	\N	1114	1369	1959-05-06
1201	1	1956-01-09	1964-12-14	\N	1056	1325	1956-02-01
1202	1	1959-02-16	1964-12-12	\N	1115	1370	1959-04-15
1203	1	1959-02-17	2001-02-15	\N	1116	1371	1959-04-15
1204	1	1959-02-19	1992-05-16	\N	1117	1372	1959-03-10
1205	1	1959-03-10	1980-11-08	\N	1118	1373	1959-04-08
1206	1	1959-06-16	1984-05-15	\N	1119	1375	1959-07-15
1207	1	1959-04-06	1969-07-21	\N	1120	1374	1959-04-08
1208	1	1959-07-15	1977-03-26	\N	1121	1376	1959-07-16
1209	1	1959-07-16	1972-07-24	\N	1122	1377	1959-07-22
1210	1	1959-08-20	1973-11-15	\N	1123	1378	1959-10-21
1211	1	1959-11-02	1965-03-06	\N	1124	1379	1959-11-17
1212	1	1959-11-20	1971-02-20	\N	1125	1382	1959-12-16
1213	1	1959-11-03	1993-07-28	\N	1126	1380	1959-11-04
1214	1	1959-12-08	1979-11-11	\N	1127	1383	1959-12-09
1215	1	1959-12-16	1969-12-06	\N	1128	1384	1960-01-27
1216	1	1960-01-20	1993-05-24	\N	1129	1386	1960-02-10
1217	1	1960-01-20	1962-07-16	\N	1130	1387	1960-04-06
1218	1	1960-01-28	1962-02-13	\N	1131	1388	1960-02-03
1219	1	1960-01-30	1965-09-04	\N	1132	1389	1960-02-10
1220	1	1960-02-08	1973-03-10	\N	1133	1390	1960-03-09
1221	1	1960-07-04	1971-08-15	\N	1134	1393	1960-10-26
1222	1	1960-04-12	1996-10-24	\N	1135	1391	1960-06-01
1223	1	1960-07-15	1970-12-14	\N	1136	1394	1960-11-16
1224	1	1958-08-11	1994-09-22	\N	1137	1361	1958-10-21
1225	1	1960-08-02	1983-03-29	\N	1138	1395	1966-04-20
1226	1	1960-08-22	1973-04-27	\N	1139	1396	1960-11-09
1227	1	1960-09-01	1981-01-19	\N	1140	1397	1960-10-26
1228	1	1960-09-08	1983-03-08	\N	1141	1398	1960-11-16
1229	1	1960-10-01	1984-03-11	\N	1142	1399	1960-10-25
1230	1	1960-11-11	1988-06-15	\N	1143	1400	1960-11-23
1231	1	1960-11-23	1987-11-01	\N	1144	1401	1960-11-30
1232	1	1961-01-20	1984-09-25	\N	1145	1402	1961-01-24
1233	1	1958-08-18	1967-07-21	\N	1146	1362	1958-10-22
1234	1	1958-08-22	1986-07-16	\N	1147	1363	1958-11-12
1235	1	1961-02-08	1978-04-13	\N	1148	1407	1961-03-01
1236	1	1961-02-09	1971-09-08	\N	1149	1408	1961-02-15
1237	1	1961-02-10	1991-05-29	\N	1150	1409	1961-04-12
1238	1	1961-02-21	1991-10-13	\N	1151	1411	1961-03-01
1239	1	1961-02-16	1998-10-28	\N	1152	1410	1961-02-21
1240	1	1961-06-28	1999-06-27	\N	1153	1413	1961-07-26
1241	1	1961-06-02	1972-09-15	\N	1154	1412	1961-06-07
1242	1	1961-06-29	1974-04-29	\N	1155	1414	1961-07-19
1243	1	1961-07-10	1964-12-08	\N	1156	1415	1961-07-26
1244	1	1962-01-25	1963-10-17	\N	1157	1421	1962-02-14
1245	1	1961-07-25	1966-08-20	\N	777	1418	1967-05-10
1246	1	1961-10-11	1992-08-09	\N	1158	1420	1961-10-19
1247	1	1962-01-26	1966-12-29	\N	1159	1422	1962-02-13
1248	1	1962-03-26	1967-09-13	\N	1160	1425	1962-05-17
1249	1	1962-02-02	1989-10-16	\N	1161	1424	1962-05-22
1250	1	1962-04-12	1991-10-06	\N	1162	1426	1962-04-18
1251	1	1962-04-13	1970-06-05	\N	1163	1427	1962-04-18
1252	1	1962-04-16	1997-01-10	\N	1164	1428	1962-05-16
1253	1	1962-05-03	1998-10-21	\N	1165	1430	1962-05-22
1254	1	1962-04-19	1990-11-26	\N	1166	1429	1962-05-02
1255	1	1962-05-10	1992-10-15	\N	1167	1431	1962-06-05
1256	1	1962-05-11	1985-03-02	\N	1168	1432	1962-05-17
1257	1	1962-05-14	1974-08-20	\N	1169	1433	1962-05-23
1258	1	1962-05-15	1983-02-27	\N	1170	1434	1962-05-30
1259	1	1962-06-15	1969-11-16	\N	1171	1435	1962-07-11
1260	1	1962-07-11	1977-04-01	\N	1172	1436	1962-07-25
1261	1	1963-01-18	1976-12-03	\N	1173	1441	1963-01-23
1262	1	1962-07-17	1980-09-07	\N	1174	1437	1962-07-17
1263	1	1962-08-01	1999-02-24	\N	1175	1439	1962-08-01
1264	1	1962-08-22	1968-09-10	\N	1090	1440	1962-11-06
1265	1	1963-01-24	1967-06-15	\N	1176	1442	1963-11-13
1266	1	1963-01-30	1965-01-11	\N	1177	1443	1963-01-31
1267	1	1963-01-31	1997-03-03	\N	1178	1444	1963-02-13
1268	1	1963-06-13	1989-08-22	\N	1179	1445	1963-07-10
1269	1	1963-07-09	1984-07-28	\N	1180	1446	1963-07-17
1270	1	1961-02-03	1968-08-06	\N	1181	1404	1961-02-15
1271	1	1961-02-04	1980-02-04	\N	1182	1405	1961-02-07
1272	1	1961-02-07	1999-12-31	\N	1183	1406	1961-02-22
1273	1	1963-11-26	1971-01-27	\N	1184	1450	1963-12-04
1274	1	1964-01-13	1985-11-25	\N	1185	1453	1964-02-05
1275	1	1964-01-11	1971-12-12	\N	1186	1452	1964-01-23
1276	1	1964-01-14	1999-02-24	\N	1175	1454	1964-01-15
1277	1	1964-01-15	1990-01-07	\N	1187	1455	1964-01-16
1278	1	1964-01-16	1981-10-27	\N	1188	1456	1964-01-22
1279	1	1964-01-18	1989-07-31	\N	1189	1457	1964-01-29
1280	1	1964-01-20	1966-02-17	\N	1190	1458	1964-01-23
1281	1	1962-07-20	1967-01-27	\N	1069	1438	1962-07-25
1282	1	1964-01-21	1992-12-22	\N	1191	1459	1964-01-22
1283	1	1964-01-22	1973-06-05	\N	1192	1460	1964-02-05
1284	1	1964-01-23	1989-07-01	\N	1193	1461	1964-01-29
1285	1	1964-03-10	1976-08-04	\N	1194	1462	1964-03-18
1286	1	1964-05-13	1989-05-03	\N	1195	1464	1964-05-13
1287	1	1964-06-26	1995-12-19	\N	1196	1465	1964-07-15
1288	1	1964-06-29	1996-11-09	\N	1197	1466	1964-07-15
1289	1	1964-07-16	1992-08-17	\N	1198	1468	1964-07-22
1290	1	1964-07-16	1996-01-18	\N	1199	1469	1964-07-22
1291	1	1964-08-22	1982-06-26	\N	1200	1471	1964-12-02
1292	1	1964-08-24	1966-02-12	\N	1201	1472	1964-11-11
1293	1	1964-08-25	1975-09-30	\N	1202	1473	1964-10-28
1294	1	1964-09-14	1987-09-11	\N	1203	1475	1964-10-28
1295	1	1964-09-17	1993-10-10	\N	1204	1476	1964-11-11
1296	1	1964-09-04	1980-12-14	\N	1205	1474	1964-11-25
1297	1	1964-10-01	2003-02-15	\N	1206	1477	1964-10-29
1298	1	1964-10-05	1970-02-14	\N	1207	1478	1964-10-29
1299	1	1964-12-07	1980-09-07	\N	1174	1482	1964-12-16
1300	1	1964-12-07	2000-09-01	\N	1208	1483	1964-12-09
1301	1	1964-10-27	1990-09-05	\N	1209	1479	1964-11-18
1302	1	1964-10-29	1980-07-01	\N	1210	1480	1964-11-04
1303	1	1964-11-11	2020-01-10	\N	1211	1481	1964-11-12
1304	1	1964-12-08	1980-10-10	\N	1212	1484	1964-12-16
1305	1	1964-12-11	1979-12-08	\N	1213	1485	1964-12-15
1306	1	1964-12-12	1970-12-29	\N	1214	1486	1964-12-14
1307	1	1964-12-14	1995-12-29	\N	1215	1487	1964-12-15
1308	1	1964-12-15	1971-10-08	\N	1216	1488	1964-12-17
1309	1	1964-12-16	1992-12-18	\N	1217	1489	1964-12-17
1310	1	1964-12-16	1987-10-25	\N	1218	1490	1964-12-17
1311	1	1985-02-07	\N	\N	1219	1931	1985-02-27
1312	1	1963-11-27	1972-06-06	\N	1220	1451	1964-01-15
1313	1	1964-12-21	1992-08-14	\N	1221	1496	1964-12-22
1314	1	1964-12-22	1985-03-17	\N	1222	1498	1965-01-20
1315	1	1964-12-22	1984-02-06	\N	1223	1499	1964-12-23
1316	1	1964-12-23	1973-09-30	\N	1224	1500	1965-03-10
1317	1	1964-12-28	1988-11-06	\N	1225	1501	1965-01-20
1318	1	1964-12-29	1978-02-23	\N	1226	1502	1965-01-21
1319	1	1964-12-30	1966-11-06	\N	1227	1503	1965-01-20
1320	1	1964-12-31	1980-12-27	\N	1228	1504	1965-02-17
1321	1	1965-01-01	1996-05-25	\N	1229	1505	1965-02-10
1322	1	1965-01-01	1965-11-11	\N	1230	1506	1965-01-26
1323	1	1965-01-28	1983-06-22	\N	1231	1507	1965-03-10
1324	1	1965-01-29	1975-10-17	\N	1232	1508	1965-03-24
1325	1	1965-02-04	1968-02-21	\N	1233	1509	1965-04-07
1326	1	1965-03-24	1979-11-29	\N	1234	1512	1965-04-14
1327	1	1965-02-18	1980-01-31	\N	1235	1510	1965-03-03
1328	1	1965-02-19	1982-03-08	\N	1236	1511	1965-02-24
1329	1	1965-05-10	1972-06-13	\N	1237	1513	1965-06-02
1330	1	1965-05-10	1991-01-17	\N	1238	1514	1965-06-02
1331	1	1965-05-11	1977-05-03	\N	1239	1516	1965-05-19
1332	1	1965-05-11	1990-10-31	\N	1240	1515	1965-06-23
1333	1	1965-05-12	1998-12-22	\N	1241	1517	1965-05-25
1334	1	1965-05-12	1969-12-27	\N	1242	1518	1965-05-26
1335	1	1965-05-13	1966-10-07	\N	1243	1519	1965-05-19
1336	1	1965-05-13	1966-10-21	\N	1244	1520	1965-05-26
1337	1	1965-05-14	1992-07-04	\N	1245	1521	1965-06-23
1338	1	1965-05-14	1992-12-31	\N	1246	1522	1965-06-02
1339	1	1965-06-22	1997-12-21	\N	1247	1524	1965-07-07
1340	1	1965-07-05	1980-09-03	\N	1248	1525	1965-12-01
1341	1	1965-07-06	1989-06-06	\N	1249	1526	1965-07-28
1342	1	1965-07-07	1985-03-23	\N	1250	1527	1965-07-14
1343	1	1965-07-16	2000-02-21	\N	1251	1528	1965-07-28
1344	1	1965-07-20	1995-05-12	\N	1252	1529	1965-07-21
1345	1	1966-01-14	1994-12-26	\N	1253	1531	1966-01-27
1346	1	1966-01-15	1966-06-02	\N	1254	1532	1966-02-02
1347	1	1965-12-07	2002-10-31	\N	1255	1530	1965-12-15
1348	1	1966-01-17	1975-07-06	\N	1256	1533	1966-02-16
1349	1	1964-12-17	1982-11-08	\N	1257	1492	1965-01-21
1350	1	1964-12-18	1987-08-17	\N	1258	1493	1964-12-21
1351	1	1964-12-18	1985-06-04	\N	1259	1494	1964-12-21
1352	1	1966-06-06	1977-08-11	\N	1260	1540	1966-06-29
1353	1	1966-06-07	1979-01-01	\N	1261	1541	1966-06-14
1354	1	1966-06-09	1982-01-16	\N	1262	1542	1966-06-22
1355	1	1966-06-10	1983-04-28	\N	1263	1543	1966-07-06
1356	1	1966-06-15	1966-10-12	\N	1264	1545	1966-07-13
1357	1	1966-06-16	1978-01-17	\N	1265	1546	1966-07-06
1358	1	1966-06-23	1974-12-23	\N	1266	1547	1966-07-05
1359	1	1966-06-24	1996-01-14	\N	1267	1548	1966-07-12
1360	1	1966-07-04	1998-11-08	\N	1268	1549	1966-11-23
1361	1	1966-07-05	1982-01-31	\N	1269	1550	1966-07-20
1362	1	1966-07-11	1988-09-02	\N	1270	1551	1966-07-13
1363	1	1966-07-20	1984-03-29	\N	1271	1552	1966-07-26
1364	1	1966-09-19	1985-09-01	\N	1272	1553	1966-10-26
1365	1	1967-01-16	1978-06-30	\N	1273	1554	1967-02-01
1366	1	1967-01-17	1990-05-30	\N	1274	1555	1967-01-25
1367	1	1967-01-18	1986-07-31	\N	1275	1556	1967-02-22
1368	1	1967-01-20	2002-10-21	\N	1276	1558	1967-01-25
1369	1	1967-07-06	1982-11-20	\N	1277	1560	1967-07-12
1370	1	1967-07-07	1991-03-03	\N	1278	1561	1967-11-15
1371	1	1967-07-10	1990-03-13	\N	1279	1562	1967-07-19
1372	1	1967-07-11	1969-12-03	\N	1280	1563	1967-07-19
1373	1	1967-08-25	1982-08-28	\N	1281	1564	1967-10-25
1374	1	1967-08-26	1993-11-28	\N	1282	1565	1967-10-24
1375	1	1967-08-29	1997-11-06	\N	1283	1566	1967-10-25
1376	1	1967-08-30	1993-12-06	\N	1284	1567	1967-10-24
1377	1	1967-09-11	1976-10-01	\N	1285	1568	1967-11-01
1378	1	1967-09-12	1998-02-14	\N	1286	1569	1967-11-01
1379	1	1967-09-14	1975-03-12	\N	1287	1570	1967-11-08
1380	1	1967-09-15	1996-12-29	\N	1288	1571	1967-10-27
1381	1	1967-09-18	1975-01-13	\N	1289	1572	1967-10-26
1382	1	1967-09-19	1974-09-05	\N	1290	1573	1967-11-08
1383	1	1967-09-20	1994-04-30	\N	1291	1574	1967-11-22
1384	1	1967-09-21	1969-12-14	\N	1292	1575	1967-11-15
1385	1	1967-09-22	1978-04-05	\N	1293	1576	1967-10-27
1386	1	1967-10-13	1972-08-02	\N	1294	1577	1967-10-26
1387	1	1967-11-20	1998-03-08	\N	1295	1578	1967-11-22
1388	1	1966-01-19	1986-03-14	\N	1296	1535	1966-02-23
1389	1	1966-05-27	1968-08-28	\N	1297	1536	1966-06-14
1390	1	1967-11-27	1983-08-11	\N	1298	1579	1967-11-28
1391	1	1966-06-02	1985-08-06	\N	1299	1539	1966-07-27
1392	1	1968-01-22	1974-09-15	\N	1300	1586	1968-02-07
1393	1	1968-01-29	2001-07-13	\N	1301	1587	1968-01-31
1394	1	1968-02-12	1985-02-08	\N	1302	1588	1968-02-21
1395	1	1968-05-21	1978-12-05	\N	1303	1589	1968-05-29
1396	1	1968-06-20	1985-01-20	\N	1304	1590	1968-06-26
1397	1	1968-06-21	1984-12-27	\N	1305	1591	1968-07-17
1398	1	1968-06-28	1972-02-05	\N	1306	1592	1968-07-31
1399	1	1968-07-10	1985-06-27	\N	1307	1593	1968-07-24
1400	1	1968-07-11	1995-12-20	\N	1308	1594	1968-07-17
1401	1	1968-09-17	1999-10-17	\N	1309	1595	1968-10-16
1402	1	1968-09-30	1985-10-14	\N	1310	1596	1968-10-07
1403	1	1969-01-09	2008-07-21	\N	1311	1597	1969-01-22
1404	1	1969-01-27	1974-07-13	\N	1312	1598	1969-02-19
1405	1	1969-02-21	1983-12-10	\N	1313	1599	1969-04-23
1406	1	1969-03-24	1971-07-01	\N	1314	1601	1969-03-26
1407	1	1969-07-02	1984-06-29	\N	1315	1602	1969-07-23
1408	1	1969-07-03	1993-02-05	\N	1316	1603	1969-11-12
1409	1	1969-07-24	1983-05-21	\N	1317	1604	1969-11-12
1410	1	1970-01-16	1994-08-18	\N	1318	1606	1970-01-21
1411	1	1970-01-23	1990-06-12	\N	1319	1607	1970-01-28
1412	1	1970-02-05	1992-07-02	\N	1320	1608	1973-06-27
1413	1	1970-02-12	\N	\N	1321	1609	1970-02-25
1414	1	1970-06-19	1986-05-08	\N	1322	1610	1970-06-29
1415	1	1970-06-20	1982-05-04	\N	1323	1611	1970-07-01
1416	1	1970-06-30	2001-10-12	\N	1324	1612	1970-06-30
1417	1	1970-07-01	1978-03-11	\N	1325	1613	1970-07-01
1418	1	1970-07-02	1995-01-26	\N	1326	1614	1970-07-21
1419	1	1970-07-03	1981-09-28	\N	1327	1615	1970-07-21
1420	1	1970-07-04	1976-08-07	\N	1328	1616	1970-07-14
1421	1	1970-07-06	1980-03-17	\N	1329	1617	1970-07-15
1422	1	1970-07-07	1981-03-08	\N	1330	1618	1970-07-22
1423	1	1970-07-08	1977-04-21	\N	1331	1619	1970-07-15
1424	1	1970-07-09	1990-06-09	\N	1332	1620	1970-07-16
1425	1	1970-07-28	1988-07-28	\N	1333	1621	1970-11-04
1426	1	1970-07-31	1972-12-02	\N	1334	1622	1970-11-04
1427	1	1967-12-04	1994-06-04	\N	1335	1581	1967-12-06
1428	1	1967-12-06	2008-04-08	\N	1336	1583	1967-12-13
1429	1	1968-01-18	1983-12-22	\N	1337	1584	1968-02-07
1430	1	1970-10-12	1999-12-23	\N	1338	1627	1970-11-11
1431	1	1970-10-14	1993-03-24	\N	1339	1628	1970-10-29
1432	1	1970-11-05	1988-11-16	\N	1340	1629	1970-11-10
1433	1	1970-11-06	1985-06-02	\N	1341	1630	1970-11-10
1434	1	1971-01-29	1980-02-08	\N	1342	1631	1971-02-03
1435	1	1991-06-07	\N	\N	1343	2041	1991-06-11
1436	1	1971-02-09	1990-02-08	\N	1344	1633	1971-03-10
1437	1	1971-03-02	1986-09-03	\N	1345	1634	1971-03-31
1438	1	1971-03-05	1989-07-11	\N	1346	1635	1971-03-24
1439	1	1971-03-12	1989-08-04	\N	1347	1636	1971-03-15
1440	1	1971-04-20	1981-07-26	\N	1348	1637	1971-04-26
1441	1	1971-04-30	1999-08-19	\N	1349	1638	1971-05-04
1442	1	1971-05-01	1994-04-05	\N	1350	1639	1971-05-12
1443	1	1971-05-17	2003-09-20	\N	1351	1640	1971-06-08
1444	1	1971-05-18	1997-04-23	\N	1352	1641	1971-05-19
1445	1	1971-05-21	\N	\N	1353	1642	1971-05-25
1446	1	1971-05-24	2002-09-06	\N	1354	1643	1971-06-16
1447	1	1971-06-04	1999-11-17	\N	1355	1644	1971-06-09
1448	1	1971-06-18	1993-04-01	\N	1356	1645	1971-07-20
1449	1	1971-07-20	2002-05-17	\N	1357	1646	1971-12-08
1450	1	1971-10-04	1989-09-10	\N	1358	1647	1971-10-27
1451	1	1972-01-10	1991-11-07	\N	1359	1648	1972-01-26
1452	1	1972-04-20	1984-04-30	\N	1360	1649	1972-06-28
1453	1	1972-04-24	1985-05-09	\N	1361	1650	1972-05-03
1454	1	1972-04-26	1979-07-02	\N	1362	1651	1972-06-08
1455	1	1972-04-28	1990-12-15	\N	1363	1652	1972-06-07
1456	1	1972-05-01	1998-07-11	\N	1364	1653	1972-06-15
1457	1	1972-05-02	2009-10-17	\N	1365	1654	1972-05-10
1458	1	1972-05-09	1993-04-04	\N	1366	1655	1972-06-14
1459	1	1972-05-10	1983-11-02	\N	1367	1656	1972-06-07
1460	1	1972-07-03	1987-08-28	\N	1368	1657	1972-07-19
1461	1	1973-02-05	1994-01-01	\N	1369	1659	1973-02-07
1462	1	1973-03-14	1995-11-24	\N	1370	1660	1973-06-13
1463	1	1973-06-18	\N	\N	1371	1661	1973-06-27
1464	1	1973-06-22	1977-03-16	\N	1372	1662	1973-07-11
1465	1	1973-06-25	1987-12-28	\N	1373	1663	1973-11-13
1466	1	1973-07-06	1992-10-22	\N	1374	1665	1973-07-17
1467	1	1973-07-09	1987-02-16	\N	1375	1666	1973-07-25
1468	1	1973-07-16	1979-04-04	\N	1376	1667	1973-07-24
1469	1	1970-09-25	2004-04-03	\N	1377	1625	1970-11-03
1470	1	1970-09-28	1985-10-28	\N	1378	1626	1970-11-11
1471	1	1974-03-25	1981-07-22	\N	1379	1672	1974-03-26
1472	1	1974-03-26	2001-04-11	\N	1380	1673	1974-03-26
1473	1	1974-05-02	1987-11-26	\N	1381	1674	1974-05-21
1474	1	1974-05-03	1984-05-15	\N	1382	1675	1974-05-09
1475	1	1974-05-06	1984-09-12	\N	1383	1676	1974-05-09
1476	1	1974-05-08	1978-07-06	\N	1384	1678	1974-05-15
1477	1	1974-05-09	1994-01-17	\N	1385	1679	1974-06-25
1478	1	1974-05-10	2015-02-17	\N	1386	1680	1974-05-15
1479	1	1974-05-13	1985-07-03	\N	1387	1681	1974-06-12
1480	1	1974-05-14	1999-02-09	\N	1388	1682	1974-05-22
1481	1	1974-05-15	2004-01-11	\N	1389	1683	1974-07-03
1482	1	1974-05-16	2004-08-12	\N	1390	1684	1974-05-22
1483	1	1974-06-11	1996-07-01	\N	1391	1685	1974-07-24
1484	1	1974-06-18	1979-12-26	\N	1392	1686	1974-06-26
1485	1	1974-06-19	1979-10-12	\N	1393	1687	1974-07-16
1486	1	1974-06-20	1996-05-02	\N	1394	1688	1974-07-10
1487	1	1974-06-21	1980-03-23	\N	1395	1689	1974-07-10
1488	1	1974-06-24	1997-01-01	\N	1396	1690	1974-10-24
1489	1	1974-06-25	1996-06-08	\N	1397	1691	1974-07-11
1490	1	1974-06-26	2001-01-06	\N	1398	1692	1974-07-03
1491	1	1974-06-27	1997-11-22	\N	1399	1693	1974-07-29
1492	1	1974-06-28	1997-12-23	\N	1400	1694	1974-07-24
1493	1	1974-07-01	1984-02-04	\N	1401	1695	1974-07-08
1494	1	1974-07-02	2005-12-18	\N	1402	1696	1974-07-09
1495	1	1974-07-03	1985-10-18	\N	1403	1697	1974-07-09
1496	1	1974-07-04	1980-12-02	\N	1404	1698	1974-07-17
1497	1	1974-07-08	1992-04-28	\N	1405	1700	1974-07-18
1498	1	1974-07-09	1986-09-30	\N	1406	1701	1974-07-17
1499	1	1974-07-10	1985-01-14	\N	1407	1702	1974-11-13
1500	1	1974-07-11	2019-02-06	\N	1408	1703	1974-07-23
1501	1	1974-07-12	1985-01-18	\N	1409	1704	1974-11-27
1502	1	1974-10-01	1992-12-27	\N	1410	1706	1974-10-23
1503	1	1974-11-18	1988-04-23	\N	1411	1707	1975-01-29
1504	1	1975-01-02	1990-01-02	\N	1412	1709	1975-01-21
1505	1	1975-01-03	1977-07-23	\N	1413	1710	1975-03-05
1506	1	1975-01-06	2005-12-16	\N	1414	1711	1975-04-16
1507	1	1975-01-07	1997-06-15	\N	1415	1712	1975-02-11
1508	1	1974-03-06	1976-07-28	\N	1416	1669	1974-04-10
1509	1	1974-03-07	1987-07-21	\N	1417	1670	1974-03-27
1510	1	1974-03-11	1989-12-04	\N	1418	1671	1974-03-11
1511	1	1975-01-14	1983-01-25	\N	1419	1717	1975-01-28
1512	1	1975-01-15	1984-12-28	\N	1420	1718	1975-01-28
1513	1	1975-01-16	1992-03-27	\N	1421	1719	1975-02-11
1514	1	1975-01-17	2003-11-11	\N	1422	1720	1975-02-05
1515	1	1975-01-20	2005-04-18	\N	1423	1721	1975-01-27
1516	1	1975-01-21	2004-07-26	\N	1424	1722	1975-02-04
1517	1	1975-01-22	1978-01-18	\N	1425	1723	1975-02-04
1518	1	1975-01-23	1980-04-26	\N	1426	1724	1975-02-25
1519	1	1975-01-24	\N	\N	1427	1725	1975-03-05
1520	1	1975-01-27	1994-05-23	\N	1428	1726	1975-02-03
1521	1	1975-01-28	1978-01-05	\N	1429	1727	1975-02-19
1522	1	1975-01-29	1980-07-12	\N	1430	1728	1975-03-04
1523	1	1975-01-30	1995-10-16	\N	1431	1729	1975-02-25
1524	1	1975-01-31	2004-04-20	\N	1432	1730	1975-02-18
1525	1	1975-07-10	1977-07-26	\N	1433	1732	\N
1526	1	1975-07-11	2009-08-12	\N	1434	1733	1975-07-23
1527	1	1975-07-14	1981-03-12	\N	1435	1734	1975-10-22
1528	1	1975-07-15	2003-05-12	\N	1436	1735	1975-07-15
1529	1	1975-07-16	1988-08-13	\N	1437	1736	1975-11-03
1530	1	1975-07-17	\N	\N	1438	1737	1975-07-23
1531	1	1975-09-30	1986-06-23	\N	1439	1738	1975-10-27
1532	1	1976-01-14	2002-07-31	\N	1440	1739	1976-04-07
1533	1	1976-01-15	2012-02-17	\N	1441	1740	1976-03-10
1534	1	1976-01-16	1976-08-12	\N	1442	1741	1976-01-28
1535	1	1976-01-19	2012-11-18	\N	1443	1742	1976-02-11
1536	1	1976-01-20	2013-04-18	\N	1444	1743	1976-01-27
1537	1	1976-01-21	2004-09-01	\N	1445	1744	1976-01-27
1538	1	1976-01-22	1999-09-04	\N	1446	1745	1976-02-03
1539	1	1976-01-23	1993-07-18	\N	1447	1746	1976-02-04
1540	1	1976-01-26	1996-03-13	\N	1448	1747	1976-02-17
1541	1	1976-01-27	1995-01-07	\N	1449	1748	1976-02-10
1542	1	1976-01-29	1995-08-02	\N	1450	1749	1976-02-25
1543	1	1976-01-30	2004-02-02	\N	1451	1750	1976-02-17
1544	1	1976-02-03	1980-02-24	\N	1452	1751	1976-03-03
1545	1	1976-02-05	1980-12-29	\N	1453	1752	1976-03-17
1546	1	1976-03-08	1978-05-17	\N	1454	1753	1976-03-10
1547	1	1976-06-22	1998-12-13	\N	1455	1754	1976-06-23
1548	1	1976-06-23	1984-07-19	\N	1456	1755	1976-07-07
1549	1	1976-06-24	1986-07-17	\N	1457	1756	1976-07-14
1550	1	1975-01-13	1989-02-17	\N	1458	1716	1975-01-22
1551	1	1976-07-02	1976-12-04	\N	1459	1762	\N
1552	1	1976-07-12	2007-11-27	\N	1460	1763	1976-07-21
1553	1	1976-07-19	2016-03-15	\N	1461	1764	1976-12-08
1554	1	1976-08-02	2003-10-10	\N	1462	1765	1976-10-12
1555	1	1976-09-23	1988-08-26	\N	1463	1766	1976-09-27
1556	1	1976-10-18	1981-05-31	\N	1464	1768	1977-02-15
1557	1	1977-01-10	2002-06-21	\N	1465	1769	1977-01-10
1558	1	1977-01-28	2012-05-04	\N	1466	1770	1977-02-02
1559	1	1977-02-01	1985-09-09	\N	1467	1771	1977-02-15
1560	1	1977-02-07	1977-03-03	\N	1468	1772	1977-02-22
1561	1	1977-02-08	1989-11-26	\N	1469	1773	1977-03-09
1562	1	1977-03-23	2008-10-03	\N	1470	1774	1977-03-30
1563	1	1977-07-15	2001-12-09	\N	1471	1775	1977-07-19
1564	1	1977-07-18	2013-07-12	\N	1472	1776	1977-07-26
1565	1	1977-07-19	2005-03-30	\N	1473	1777	1977-07-20
1566	1	1977-07-20	2012-03-09	\N	1474	1778	1977-07-26
1567	1	1977-07-22	1982-10-08	\N	1475	1779	1977-11-16
1568	1	1978-02-08	2011-09-11	\N	1476	1782	1978-04-05
1569	1	1977-09-30	2004-12-08	\N	1477	1780	1977-10-26
1570	1	1978-02-09	1997-11-10	\N	1478	1783	1978-03-01
1571	1	1978-02-27	2019-04-29	\N	1479	1784	1978-03-15
1572	1	1978-03-20	2002-01-14	\N	1480	1785	1978-03-22
1573	1	1978-04-14	2007-01-08	\N	1481	1786	1978-04-19
1574	1	1978-04-17	2006-06-28	\N	1482	1787	1978-04-19
1575	1	1978-04-19	1987-09-16	\N	1483	1788	1978-04-26
1576	1	1978-04-21	2018-05-26	\N	1484	1789	1978-05-03
1577	1	1978-04-24	1992-03-22	\N	1485	1790	1978-04-26
1578	1	1978-04-26	2005-08-16	\N	1486	1791	1978-05-17
1579	1	1978-04-28	2009-11-29	\N	1487	1792	1978-05-03
1580	1	1978-05-02	1983-07-17	\N	1488	1793	1978-06-14
1581	1	1978-05-03	2001-09-09	\N	1489	1794	1978-05-24
1582	1	1978-05-04	2016-11-25	\N	1490	1795	1978-05-17
1583	1	1978-05-05	1992-10-11	\N	1491	1796	1978-05-10
1584	1	1978-05-09	1986-08-09	\N	1492	1797	1978-06-07
1585	1	1978-05-10	2006-01-27	\N	1493	1798	1978-06-28
1586	1	1978-05-19	1985-05-15	\N	1494	1801	1978-05-24
1587	1	1978-07-10	1998-08-22	\N	1495	1802	1978-07-19
1588	1	1976-06-29	1994-07-28	\N	1496	1759	1976-09-29
1589	1	1976-06-30	1995-01-17	\N	1497	1760	1976-07-06
1590	1	1976-07-01	2011-07-23	\N	1498	1761	1976-07-07
1591	1	1979-01-31	2000-11-02	\N	1499	1807	1979-07-24
1592	1	1979-02-02	2004-08-15	\N	1500	1808	1979-03-07
1593	1	1979-02-05	2004-05-16	\N	1501	1809	1979-03-21
1594	1	1979-02-07	1991-06-14	\N	1502	1810	1979-03-29
1595	1	1979-02-19	2004-01-27	\N	1503	1812	1979-02-21
1596	1	1979-02-20	2010-06-25	\N	1504	1813	1979-03-28
1597	1	1979-05-21	2001-02-11	\N	1505	1814	1979-05-23
1598	1	1979-07-03	1995-08-06	\N	1506	1815	1979-07-10
1599	1	1979-07-05	1990-03-10	\N	1507	1816	1979-07-17
1600	1	1979-07-06	\N	\N	1508	1817	1979-07-11
1601	1	1979-07-09	1993-06-05	\N	1509	1818	1979-07-11
1602	1	1979-07-10	1989-12-18	\N	1510	1819	1979-07-10
1603	1	1979-07-10	1993-09-23	\N	1511	1820	1979-07-16
1604	1	1979-07-11	2007-02-26	\N	1512	1821	1979-07-25
1605	1	1979-07-11	2007-05-24	\N	1513	1822	1979-07-16
1606	1	1979-07-12	1980-08-25	\N	1514	1823	1979-07-18
1607	1	1979-07-12	1993-03-12	\N	1515	1824	1979-07-17
1608	1	1979-07-16	2001-02-22	\N	1516	1825	1979-07-18
1609	1	1979-07-17	2016-03-04	\N	1517	1826	1979-07-23
1610	1	1979-07-19	2006-10-19	\N	1518	1828	1979-07-24
1611	1	1979-07-24	1988-06-10	\N	1519	1829	1979-07-25
1612	1	1979-07-25	2009-07-05	\N	1520	1830	1979-11-28
1613	1	1979-07-30	2012-05-13	\N	1521	1832	1979-11-20
1614	1	1979-08-06	1992-11-27	\N	1522	1833	1979-11-07
1615	1	1979-08-07	2002-08-11	\N	1523	1834	1979-11-14
1616	1	1979-09-07	2002-02-07	\N	1524	1835	1979-11-07
1617	1	1979-09-27	2003-01-26	\N	1525	1836	1979-11-14
1618	1	1979-10-02	1979-11-07	\N	1526	1838	1979-10-31
1619	1	1979-09-28	2005-08-21	\N	1527	1837	1979-10-24
1620	1	1980-01-28	2000-05-17	\N	1528	1839	1980-03-05
1621	1	1980-02-04	2018-11-26	\N	1529	1840	1980-02-06
1622	1	1980-02-06	2004-09-01	\N	1530	1841	1980-02-13
1623	1	1980-02-08	2008-07-17	\N	1531	1842	1980-02-20
1624	1	1980-02-11	2002-11-20	\N	1532	1843	1980-02-13
1625	1	1980-02-14	2001-02-23	\N	1533	1844	1980-03-05
1626	1	1978-07-17	1994-03-24	\N	1534	1804	1978-07-19
1627	1	1980-04-15	1996-10-04	\N	1535	1846	1980-04-16
1628	1	1978-07-18	1990-10-11	\N	1536	1805	1978-07-24
1629	1	1978-07-21	2008-05-16	\N	1537	1806	1978-07-25
1630	1	1981-02-02	1995-03-05	\N	1538	1853	1981-02-11
1631	1	1980-09-29	2007-11-20	\N	1539	1852	1980-10-08
1632	1	1981-02-16	1990-09-22	\N	1540	1854	1981-02-24
1633	1	1981-05-11	2019-06-22	\N	1541	1855	1981-05-20
1634	1	1981-05-14	2004-01-26	\N	1542	1857	1981-05-19
1635	1	1981-05-19	1988-04-17	\N	1543	1859	1981-06-09
1636	1	1981-05-21	1984-04-19	\N	1544	1860	1981-06-02
1637	1	1981-05-22	1992-10-08	\N	1545	1861	1981-06-03
1638	1	1981-05-26	1999-03-22	\N	1546	1862	1981-06-02
1639	1	1981-05-27	\N	\N	1547	1863	1981-06-16
1640	1	1981-05-28	2015-02-01	\N	1548	1864	1981-06-17
1641	1	1981-05-29	2009-10-02	\N	1549	1865	1981-07-01
1642	1	1981-06-01	2003-05-31	\N	1550	1866	1981-06-10
1643	1	1981-06-16	2017-05-07	\N	1551	1868	1981-07-07
1644	1	1981-07-06	1997-01-07	\N	1552	1870	1981-07-08
1645	1	1981-07-15	2011-07-29	\N	1553	1871	1981-07-28
1646	1	1981-07-21	2004-02-13	\N	1554	1872	1981-07-28
1647	1	1981-09-22	1993-08-25	\N	1555	1873	1981-10-14
1648	1	1982-02-02	2007-02-28	\N	1556	1875	1982-03-02
1649	1	1982-02-08	1999-04-16	\N	1557	1876	1982-03-24
1650	1	1981-09-24	1999-03-24	\N	1558	1874	1981-10-05
1651	1	1982-02-10	1996-11-19	\N	1559	1877	1982-03-03
1652	1	1982-03-12	2006-02-06	\N	1560	1878	1982-03-17
1653	1	1982-05-21	2000-05-27	\N	1561	1879	1982-07-21
1654	1	1982-07-14	2010-11-09	\N	1562	1880	1982-07-28
1655	1	1982-07-16	1993-02-23	\N	1563	1881	1982-10-20
1656	1	1982-07-20	1993-05-27	\N	1564	1882	1982-07-28
1657	1	1982-09-30	2014-06-04	\N	1565	1883	1982-10-13
1658	1	1982-11-19	1999-01-23	\N	1566	1884	1983-02-02
1659	1	1983-01-17	2010-08-27	\N	1567	1885	1983-01-26
1660	1	1983-01-20	2018-01-15	\N	1568	1886	1983-01-26
1661	1	1983-01-24	\N	\N	1569	1887	1983-03-02
1662	1	1983-01-27	1995-02-15	\N	1570	1888	1983-02-16
1663	1	1983-01-31	2002-02-07	\N	1571	1889	1983-02-02
1664	1	1983-02-02	2015-12-22	\N	1572	1890	1983-02-09
1665	1	1983-02-03	1998-06-26	\N	1573	1891	1983-02-09
1666	1	1980-07-11	1990-11-01	\N	1574	1848	1980-07-23
1667	1	1980-07-17	2002-07-23	\N	1575	1849	1980-10-15
1668	1	1980-09-01	1992-05-23	\N	1576	1851	1980-10-22
1669	1	1983-03-28	2004-01-04	\N	1577	1897	1983-03-30
1670	1	1983-06-30	2004-11-01	\N	1578	1899	1983-07-06
1671	1	1983-06-16	1999-07-01	\N	1579	1898	1983-06-16
1672	1	1983-07-01	1984-11-27	\N	1580	1900	1983-07-06
1673	1	1983-07-15	2005-07-12	\N	1581	1903	1983-07-26
1674	1	1983-07-04	2006-03-14	\N	1582	1901	1983-07-05
1675	1	1983-07-11	1997-09-22	\N	1583	1902	1983-07-19
1676	1	1983-09-05	1994-06-03	\N	1584	1904	1983-11-01
1677	1	1983-09-07	2008-03-29	\N	1585	1905	1983-11-09
1678	1	1983-09-09	1995-06-17	\N	1586	1906	1983-11-01
1679	1	1983-09-12	\N	\N	1587	1907	1983-10-25
1680	1	1983-09-14	\N	\N	1588	1908	1983-10-26
1681	1	1983-09-16	1995-05-24	\N	1589	1909	1983-11-15
1682	1	1983-09-21	1992-01-22	\N	1590	1911	1983-11-30
1683	1	1983-09-23	1991-03-13	\N	1591	1912	1983-11-09
1684	1	1983-09-27	2001-12-28	\N	1592	1913	1983-11-22
1685	1	1983-09-28	1999-02-26	\N	1593	1914	1983-11-02
1686	1	1983-09-30	2014-11-01	\N	1594	1915	1983-11-08
1687	1	1983-10-03	\N	\N	1595	1916	1983-11-16
1688	1	1983-10-05	2006-11-22	\N	1596	1917	1983-10-25
1689	1	1983-10-07	1990-04-15	\N	1597	1918	1983-11-15
1690	1	1983-10-12	1993-10-24	\N	1598	1920	1983-11-16
1691	1	1983-10-14	2005-08-26	\N	1599	1921	1983-10-26
1692	1	1984-01-30	1995-03-15	\N	1600	1922	1984-02-01
1693	1	1984-01-31	1995-11-03	\N	1601	1923	1984-02-15
1694	1	1984-02-02	2014-01-17	\N	1602	1925	1984-02-08
1695	1	1985-02-04	2004-10-19	\N	1603	1929	1985-02-06
1696	1	1984-06-08	\N	\N	1604	1927	1984-06-20
1697	1	1984-10-10	\N	\N	1605	1928	1984-10-16
1698	1	1985-02-06	2019-03-20	\N	1606	1930	1985-03-27
1699	1	1985-02-14	2004-05-20	\N	1607	1932	1985-02-20
1700	1	1985-05-09	2014-03-27	\N	1608	1933	1985-05-21
1701	1	1985-05-13	1988-08-17	\N	1609	1934	1985-05-15
1702	1	1985-05-15	2003-06-19	\N	1610	1935	1985-06-05
1703	1	1985-05-16	2011-05-20	\N	1611	1936	1985-05-22
1704	1	1983-02-09	2017-03-28	\N	1612	1893	1983-02-23
1705	1	1983-02-10	2002-05-03	\N	1613	1894	1983-03-16
1706	1	1983-03-14	1985-01-29	\N	1614	1896	1983-03-16
1707	1	1985-05-30	1995-04-26	\N	1615	1942	1985-06-12
1708	1	1985-06-05	\N	\N	1616	1943	1985-06-11
1709	1	1985-06-10	\N	\N	1617	1944	1985-06-12
1710	1	1985-06-13	2010-05-20	\N	1618	1945	1985-06-26
1711	1	1985-07-12	1998-05-09	\N	1619	1946	1985-07-17
1712	1	1985-07-22	1996-02-20	\N	1620	1947	1985-07-30
1713	1	1986-02-14	1997-12-05	\N	1621	1951	1986-07-22
1714	1	1986-01-30	2006-03-21	\N	1622	1948	1986-02-05
1715	1	1986-01-31	2007-10-17	\N	1623	1949	1986-02-05
1716	1	1986-02-06	2016-08-14	\N	1624	1950	1986-02-11
1717	1	1986-07-21	1994-09-04	\N	1625	1952	1986-07-30
1718	1	1986-07-22	2009-04-07	\N	1626	1953	1986-07-22
1719	1	1986-09-23	2007-08-17	\N	1627	1955	1986-10-15
1720	1	1987-02-03	1997-12-07	\N	1628	1956	1987-02-04
1721	1	1987-02-09	2019-11-12	\N	1629	1957	1987-02-17
1722	1	1987-03-18	\N	\N	1630	1958	1987-04-07
1723	1	1987-03-23	2006-12-18	\N	1631	1959	1987-03-24
1724	1	1987-03-24	2016-04-23	\N	1632	1960	1987-03-25
1725	1	1987-03-25	\N	\N	1633	1961	1987-03-25
1726	1	1987-03-27	\N	\N	1634	1962	1987-03-31
1727	1	1987-03-31	1989-01-25	\N	1635	1964	1987-03-31
1728	1	1984-02-24	1986-12-29	\N	1636	1926	1984-02-29
1729	1	1987-04-03	1989-09-16	\N	1637	1965	1987-04-07
1730	1	1987-04-06	\N	\N	1638	1966	1987-04-28
1731	1	1987-04-07	2005-05-31	\N	1639	1967	1987-05-06
1732	1	1987-04-08	1997-07-27	\N	1640	1968	1987-04-08
1733	1	1987-07-14	2012-07-08	\N	1641	1970	1987-07-15
1734	1	1987-07-22	2014-12-11	\N	1642	1971	1987-07-22
1735	1	1987-10-06	2001-03-26	\N	1643	1973	1987-10-20
1736	1	1987-10-07	2008-02-04	\N	1644	1974	1987-10-21
1737	1	1987-10-08	1996-03-06	\N	1645	1975	1987-10-21
1738	1	1987-10-09	2008-03-07	\N	1646	1976	1987-10-28
1739	1	1987-10-12	1994-12-10	\N	1647	1977	1987-10-28
1740	1	1987-10-13	2003-12-18	\N	1648	1978	1987-11-03
1741	1	1987-10-14	2016-12-12	\N	1649	1979	1987-11-11
1742	1	1987-10-15	2018-03-17	\N	1650	1980	1987-11-04
1743	1	1987-10-16	1996-10-04	\N	1651	1981	1987-11-10
1744	1	1985-05-21	\N	\N	1652	1938	1985-06-26
1745	1	1985-05-29	2018-02-26	\N	1653	1941	1985-06-18
1746	1	1985-05-23	2015-05-30	\N	1654	1940	1985-06-05
1747	1	1987-11-16	2008-11-30	\N	1655	1988	1987-11-24
1748	1	1987-11-20	2003-01-05	\N	1656	1989	1987-12-01
1749	1	1988-02-05	1999-10-31	\N	1657	1990	1988-02-09
1750	1	1988-02-08	1991-12-08	\N	1658	1991	1988-02-10
1751	1	1988-02-15	2005-08-31	\N	1659	1993	1988-02-24
1752	1	1988-02-26	\N	\N	1660	1994	1988-03-15
1753	1	1988-07-11	2005-11-06	\N	1661	1995	1988-07-12
1754	1	1988-08-08	2012-12-29	\N	1662	1996	1988-10-25
1755	1	1988-08-10	2000-07-22	\N	1663	1997	1988-11-09
1756	1	1988-10-18	2000-04-01	\N	1664	1998	1988-11-30
1757	1	1989-01-09	2014-06-12	\N	1665	1999	1989-01-18
1758	1	1989-01-31	\N	\N	1666	2000	1989-01-31
1759	1	1989-02-08	2014-07-17	\N	1667	2001	1989-02-08
1760	1	1989-02-09	\N	\N	1668	2002	1989-02-28
1761	1	1989-07-21	1994-05-02	\N	1669	2004	1989-07-26
1762	1	1989-07-24	2016-04-21	\N	1670	2005	1989-10-11
1763	1	1989-02-10	2013-06-22	\N	1671	2003	1989-02-22
1764	1	1989-07-25	\N	\N	1672	2006	1989-07-26
1765	1	1990-02-26	1992-02-17	\N	1673	2007	1990-03-07
1766	1	1990-02-27	2010-03-24	\N	1674	2008	1990-03-06
1767	1	1990-02-28	\N	\N	1675	2009	1990-03-13
1768	1	1990-05-08	\N	\N	1676	2010	1990-05-08
1769	1	1990-05-09	2001-04-30	\N	1677	2011	1990-05-09
1770	1	1990-05-10	\N	\N	1678	2012	1990-05-15
1771	1	1990-05-14	2018-03-18	\N	1679	2013	1990-05-15
1772	1	1990-05-16	2018-06-07	\N	1680	2014	1990-05-22
1773	1	1990-05-17	\N	\N	1681	2015	1990-06-06
1774	1	1990-05-18	\N	\N	1682	2016	1990-05-23
1775	1	1990-05-22	2017-05-08	\N	1683	2018	1990-06-12
1776	1	1990-05-29	2008-05-04	\N	1684	2019	1990-06-06
1777	1	1990-05-30	2008-07-29	\N	1685	2020	1990-06-05
1778	1	1990-06-01	2018-10-13	\N	1686	2021	1990-06-11
1779	1	1990-06-11	\N	\N	1687	2022	1990-06-19
1780	1	1990-06-18	\N	\N	1688	2023	1990-06-19
1781	1	1990-07-16	2002-08-31	\N	1689	2024	1990-07-24
1782	1	1987-10-20	2015-04-19	\N	1690	1983	1987-11-03
1783	1	1987-11-02	2005-07-14	\N	1691	1984	1987-11-10
1784	1	1987-11-04	1993-05-10	\N	1692	1986	1987-12-08
1785	1	1990-12-04	2017-02-24	\N	1693	2029	1990-12-04
1786	1	1991-01-25	1995-08-23	\N	1694	2031	1991-01-29
1787	1	1991-02-01	2000-07-11	\N	1695	2032	1991-02-26
1788	1	1991-02-04	\N	\N	1696	2033	1991-02-12
1789	1	1991-02-05	\N	\N	1697	2034	1991-02-20
1790	1	1991-02-08	2010-06-21	\N	1698	2036	1991-02-19
1791	1	1991-02-14	\N	\N	1699	2037	1991-02-26
1792	1	1991-03-26	\N	\N	1700	2038	1991-03-26
1793	1	1991-06-05	\N	\N	1701	2039	1991-06-18
1794	1	1991-06-06	\N	\N	1702	2040	1991-06-12
1795	1	1991-06-10	\N	\N	1703	2042	1991-06-25
1796	1	1991-06-11	2001-02-05	\N	1704	2043	1991-06-11
1797	1	1991-06-14	\N	\N	1705	2044	1991-07-02
1798	1	1991-06-19	\N	\N	1706	2045	1991-06-19
1799	1	1991-06-21	\N	\N	1707	2047	1991-07-03
1800	1	1991-06-24	\N	\N	1708	2048	1991-07-09
1801	1	1991-06-26	2001-02-21	\N	1709	2049	1991-06-26
1802	1	1991-07-15	\N	\N	1710	2050	1991-07-17
1803	1	1991-07-16	\N	\N	1711	2051	1991-07-16
1804	1	1991-07-17	1992-07-31	\N	1712	2052	1991-07-24
1805	1	1991-07-29	\N	\N	1713	2053	1991-10-15
1806	1	1991-07-30	\N	\N	1714	2054	1991-10-16
1807	1	1991-10-01	2018-07-25	\N	1715	2055	1991-10-15
1808	1	1992-01-10	2015-04-24	\N	1716	2056	1992-03-11
1809	1	1992-01-27	2016-08-20	\N	1717	2057	1992-02-12
1810	1	1992-01-30	2001-01-18	\N	1718	2058	1992-02-12
1811	1	1992-02-12	\N	\N	1719	2059	1992-02-25
1812	1	1992-02-14	\N	\N	1720	2060	1992-07-15
1813	1	1992-03-11	2009-04-07	\N	1721	2061	1992-03-11
1814	1	1992-04-24	\N	\N	1722	2062	1992-04-28
1815	1	1992-04-24	\N	\N	1723	2063	1992-04-28
1816	1	1992-04-27	1997-04-28	\N	1724	2064	1992-04-29
1817	1	1992-04-29	2011-06-26	\N	1725	2065	1992-04-29
1818	1	1992-06-26	2013-04-08	\N	1726	2066	1992-06-30
1819	1	1992-06-27	1996-10-07	\N	1727	2067	1992-07-13
1820	1	1992-06-29	2016-01-22	\N	1728	2068	1992-07-07
1821	1	1992-06-29	2015-10-03	\N	1729	2069	1992-07-01
1822	1	1990-07-17	2009-01-09	\N	1730	2026	1990-07-17
1823	1	1990-08-13	2002-11-02	\N	1731	2027	1990-10-17
1824	1	1991-01-17	\N	\N	1732	2030	1991-01-23
1825	1	1992-07-03	2019-05-20	\N	1733	2075	1992-07-06
1826	1	1992-07-06	\N	\N	1734	2076	1992-07-09
1827	1	1992-07-07	2003-01-26	\N	1735	2077	1992-07-14
1828	1	1992-07-08	1996-09-03	\N	1736	2078	1992-07-08
1829	1	1992-07-08	2010-06-23	\N	1737	2079	1992-10-21
1830	1	1992-07-09	2012-06-14	\N	1738	2080	1992-07-14
1831	1	1992-07-10	2012-04-20	\N	1739	2081	1992-07-13
1832	1	1992-07-14	\N	\N	1740	2082	1992-10-19
1833	1	1992-07-15	2007-05-06	\N	1741	2083	1992-07-15
1834	1	1992-07-17	2007-06-09	\N	1742	2084	1992-10-26
1835	1	1992-07-18	2004-04-17	\N	1743	2085	1992-10-27
1836	1	1992-07-20	2018-03-03	\N	1744	2086	1992-10-20
1837	1	1992-07-21	2004-10-04	\N	1745	2087	1992-10-28
1838	1	1992-07-24	\N	\N	1746	2088	1992-11-04
1839	1	1992-07-27	\N	\N	1747	2089	1992-10-20
1840	1	1992-07-28	1993-03-04	\N	1748	2090	1992-10-28
1841	1	1992-07-29	\N	\N	1749	2091	1992-10-21
1842	1	1992-07-30	2003-09-20	\N	1750	2092	1992-10-26
1843	1	1992-08-10	2000-01-05	\N	1751	2093	1992-11-02
1844	1	1992-08-11	2007-11-13	\N	1752	2094	1992-11-03
1845	1	1992-08-21	2013-09-07	\N	1753	2096	1992-11-03
1846	1	1992-08-25	2007-09-21	\N	1754	2097	1992-11-04
1847	1	1992-09-18	\N	\N	1755	2098	1992-10-27
1848	1	1993-02-01	\N	\N	1756	2100	1993-02-17
1849	1	1993-07-14	2013-11-24	\N	1757	2101	1993-07-21
1850	1	1993-07-15	2009-06-17	\N	1758	2102	1993-07-21
1851	1	1993-07-19	1999-03-12	\N	1759	2103	1993-07-20
1852	1	1993-07-30	2014-08-24	\N	1760	2104	1993-10-25
1853	1	1993-10-01	\N	\N	1761	2105	1993-10-12
1854	1	1993-10-04	\N	\N	1762	2106	1993-10-12
1855	1	1993-10-05	2009-04-01	\N	1763	2107	1993-10-13
1856	1	1993-10-06	\N	\N	1764	2108	1993-10-13
1857	1	1993-10-11	\N	\N	1765	2109	1993-10-19
1858	1	1993-10-12	2018-03-13	\N	1766	2110	1993-10-19
1859	1	1993-10-13	\N	\N	1767	2111	1993-11-03
1860	1	1993-10-14	2014-06-21	\N	1768	2112	1993-10-20
1861	1	1992-07-01	\N	\N	1769	2072	1992-07-06
1862	1	1992-07-02	1998-04-19	\N	1770	2074	1992-07-09
1863	1	1994-07-12	2017-12-20	\N	1771	2117	1994-07-20
1864	1	1994-07-14	1999-02-23	\N	1772	2118	1994-10-12
1865	1	1994-09-06	2015-03-25	\N	1773	2119	1994-10-26
1866	1	1994-09-26	2002-11-07	\N	1774	2120	1994-10-26
1867	1	1994-09-27	\N	\N	1775	2121	1994-10-19
1868	1	1994-09-28	2003-04-10	\N	1776	2122	1994-10-18
1869	1	1994-09-29	2018-03-30	\N	1777	2123	1994-10-11
1870	1	1994-09-30	\N	\N	1778	2124	1994-10-11
1871	1	1994-10-03	2019-09-25	\N	1779	2125	1994-10-19
1872	1	1994-10-04	\N	\N	1780	2126	1994-10-12
1873	1	1994-10-05	\N	\N	1781	2127	1994-10-18
1874	1	1994-10-06	\N	\N	1782	2128	1994-11-02
1875	1	1994-10-07	2009-07-12	\N	1783	2129	1994-11-02
1876	1	1994-10-10	2009-07-05	\N	1784	2130	1994-10-25
1877	1	1995-01-11	2017-11-28	\N	1785	2131	1995-01-18
1878	1	1995-02-03	\N	\N	1786	2132	1995-02-14
1879	1	1995-02-10	2000-10-25	\N	1787	2133	1995-02-15
1880	1	1995-02-17	\N	\N	1788	2134	1995-02-22
1881	1	1995-02-21	\N	\N	1789	2135	1995-03-01
1882	1	1995-07-24	\N	\N	1790	2137	1995-10-18
1883	1	1995-07-25	2008-10-30	\N	1791	2138	1995-10-18
1884	1	1995-08-25	\N	\N	1792	2139	1995-11-01
1885	1	1995-09-08	2019-03-06	\N	1793	2140	1995-10-25
1886	1	1995-12-13	2018-08-21	\N	1794	2141	1995-12-13
1887	1	1995-12-18	\N	\N	1795	2142	1995-12-20
1888	1	1995-12-19	\N	\N	1796	2143	1995-12-20
1889	1	1995-12-20	\N	\N	1797	2144	1996-01-09
1890	1	1995-12-21	2016-09-30	\N	1798	2145	1996-01-16
1891	1	1996-01-02	\N	\N	1799	2146	1996-01-10
1892	1	1996-01-10	\N	\N	1800	2147	1996-01-10
1893	1	1996-01-12	2011-02-14	\N	1801	2149	1996-02-07
1894	1	1996-01-15	2019-11-19	\N	1802	2150	1996-02-14
1895	1	1996-01-16	\N	\N	1803	2151	1996-02-13
1896	1	1996-02-16	2015-09-16	\N	1804	2154	1996-02-28
1897	1	1996-02-21	1999-03-20	\N	1805	2155	1996-02-28
1898	1	1996-06-04	2010-09-11	\N	1806	2157	1996-06-26
1899	1	1994-01-11	2007-01-22	\N	1807	2114	1994-01-18
1900	1	1996-02-05	\N	\N	1808	2153	1996-02-14
1901	1	1994-03-22	\N	\N	1809	2116	1994-05-04
1902	1	1996-10-01	\N	\N	1810	2163	1996-10-29
1903	1	1996-10-02	\N	\N	1811	2164	1996-10-30
1904	1	1996-10-04	\N	\N	1812	2165	1996-11-20
1905	1	1996-10-07	\N	\N	1813	2166	1996-11-27
1906	1	1996-10-08	\N	\N	1814	2167	1996-11-05
1907	1	1996-10-09	\N	\N	1815	2168	1996-11-12
1908	1	1996-10-11	\N	\N	1816	2169	1996-11-13
1909	1	1996-10-14	\N	\N	1817	2170	1996-11-05
1910	1	1996-10-15	\N	\N	1818	2171	1996-11-19
1911	1	1996-10-17	\N	\N	1819	2173	1996-12-03
1912	1	1996-10-18	\N	\N	1820	2174	1996-11-27
1913	1	1996-10-21	\N	\N	1821	2175	1996-11-19
1914	1	1997-02-17	\N	\N	1822	2178	1997-02-19
1915	1	1997-02-18	\N	\N	1823	2179	1997-02-26
1916	1	1997-05-14	\N	\N	1824	2180	1997-05-15
1917	1	1997-05-14	\N	\N	1825	2181	1997-05-15
1918	1	1997-05-16	\N	\N	1826	2182	1997-05-19
1919	1	1997-05-16	2013-06-02	\N	1827	2183	1997-05-21
1920	1	1997-06-03	2007-08-14	\N	1828	2185	1997-06-10
1921	1	1997-06-04	1998-03-27	\N	1829	2186	1997-06-04
1922	1	1997-05-21	\N	\N	1830	2184	1997-05-21
1923	1	1997-06-05	\N	\N	1831	2187	1997-06-17
1924	1	1997-06-05	2001-09-24	\N	1832	2188	1997-06-11
1925	1	1997-06-06	\N	\N	1833	2189	1997-06-18
1926	1	1997-06-06	\N	\N	1834	2190	1997-06-11
1927	1	1997-06-09	2017-02-19	\N	1835	2191	1997-06-17
1928	1	1997-06-09	\N	\N	1836	2192	1997-06-25
1929	1	1997-06-10	2016-03-05	\N	1837	2193	1997-06-12
1930	1	1997-06-10	2015-03-09	\N	1838	2194	1997-06-24
1931	1	1997-06-11	2012-11-01	\N	1839	2195	1997-06-12
1932	1	1997-06-11	2007-01-27	\N	1840	2196	1997-07-01
1933	1	1997-06-12	\N	\N	1841	2197	1997-07-08
1934	1	1997-06-12	2016-06-25	\N	1842	2198	1997-06-25
1935	1	1997-06-13	\N	\N	1843	2199	1997-06-25
1936	1	1997-06-16	\N	\N	1844	2200	1997-06-18
1937	1	1997-06-17	\N	\N	1845	2201	1997-07-02
1938	1	1997-07-18	2000-12-04	\N	1846	2202	1997-07-23
1939	1	1996-09-03	2018-09-08	\N	1847	2159	1996-10-30
1940	1	1996-09-11	2006-12-27	\N	1848	2160	1996-11-06
1941	1	1996-09-30	\N	\N	1849	2161	1996-10-29
1942	1	1997-09-23	\N	\N	1850	2207	1997-10-29
1943	1	1997-09-24	\N	\N	1851	2209	1997-10-23
1944	1	1997-09-24	2008-10-08	\N	1852	2210	1997-10-14
1945	1	1997-09-25	\N	\N	1853	2211	1997-10-15
1946	1	1997-09-25	2012-08-11	\N	1854	2212	1997-10-14
1947	1	1997-09-26	\N	\N	1855	2213	1997-10-21
1948	1	1997-09-26	2003-11-11	\N	1856	2214	1997-10-21
1949	1	1997-09-27	2003-12-16	\N	1857	2215	1997-10-15
1950	1	1997-09-27	\N	\N	1858	2216	1997-10-15
1951	1	1997-09-29	\N	\N	1859	2217	1997-10-28
1952	1	1997-09-29	\N	\N	1860	2218	1997-10-28
1953	1	1997-09-30	\N	\N	1861	2219	1997-10-23
1954	1	1997-09-30	\N	\N	1862	2220	1997-10-16
1955	1	1997-10-01	2013-12-13	\N	1863	2222	1997-10-22
1956	1	1997-10-02	2017-07-02	\N	1864	2223	1997-10-16
1957	1	1997-10-02	\N	\N	1865	2224	1997-10-29
1958	1	1997-10-03	\N	\N	1866	2226	1997-10-14
1959	1	1997-10-04	\N	\N	1867	2227	1997-10-28
1960	1	1997-10-04	\N	\N	1868	2228	1997-10-22
1961	1	1997-10-06	\N	\N	1869	2229	1997-11-04
1962	1	1997-10-18	2014-06-21	\N	1870	2231	1997-11-11
1963	1	1997-10-20	\N	\N	1871	2232	1997-11-05
1964	1	1997-10-20	\N	\N	1872	2233	1997-10-30
1965	1	1997-10-21	2005-04-28	\N	1873	2234	1997-11-04
1966	1	1997-10-21	2008-05-20	\N	1874	2235	1997-11-03
1967	1	1997-10-22	\N	\N	1875	2236	1997-11-03
1968	1	1997-10-22	\N	\N	1876	2237	1997-10-27
1969	1	1997-10-23	2017-01-10	\N	1877	2238	1997-11-12
1970	1	1997-10-23	\N	\N	1878	2239	1997-10-27
1971	1	1997-10-24	2015-05-02	\N	1879	2240	1997-11-10
1972	1	1997-10-24	\N	\N	1880	2241	1997-10-29
1973	1	1997-10-25	2015-12-19	\N	1881	2242	1997-10-30
1974	1	1997-10-25	2003-12-19	\N	1882	2243	1997-11-12
1975	1	1997-10-27	\N	\N	1883	2244	1997-11-05
1976	1	1997-10-27	\N	\N	1884	2245	1997-11-05
1977	1	1997-10-28	\N	\N	1885	2246	1997-11-11
1978	1	1997-10-28	\N	\N	1886	2247	1997-11-03
1979	1	1997-07-21	\N	\N	1887	2203	1997-07-22
1980	1	1997-07-22	\N	\N	1888	2205	1997-07-22
1981	1	1997-07-28	\N	\N	1889	2206	1997-07-29
1982	1	1997-10-31	2001-03-13	\N	1890	2252	1997-11-10
1983	1	1997-10-31	2012-03-25	\N	1891	2253	1997-11-11
1984	1	1997-11-01	\N	\N	1892	2255	1997-11-17
1985	1	1997-11-03	\N	\N	1893	2256	1997-11-18
1986	1	1997-11-03	\N	\N	1894	2257	1997-11-18
1987	1	1997-11-04	\N	\N	1895	2258	1997-11-24
1988	1	1997-11-04	\N	\N	1896	2259	1997-11-19
1989	1	1997-11-05	2018-07-01	\N	1897	2260	1997-11-19
1990	1	1997-11-05	\N	\N	1898	2261	1997-11-17
1991	1	1997-11-06	2006-08-30	\N	1899	2262	1997-11-18
1992	1	1997-11-06	\N	\N	1900	2263	1997-11-19
1993	1	1997-11-22	\N	\N	1901	2264	1997-11-24
1994	1	1997-11-24	\N	\N	1902	2265	1997-11-24
1995	1	1997-11-28	2016-05-28	\N	1903	2266	1998-01-13
1996	1	1998-02-12	\N	\N	1904	2267	1998-03-31
1997	1	1998-02-13	2009-02-19	\N	1905	2268	1998-03-17
1998	1	1998-02-23	2001-08-31	\N	1906	2270	1998-03-11
1999	1	1998-07-17	\N	\N	1907	2271	1998-07-20
2000	1	1998-07-17	\N	\N	1908	2272	1998-07-20
2001	1	1998-07-18	\N	\N	1909	2273	1998-07-21
2002	1	1998-07-18	\N	\N	1910	2274	1998-07-21
2003	1	1998-07-20	\N	\N	1911	2276	1998-07-29
2004	1	1998-07-21	\N	\N	1912	2277	1998-07-27
2005	1	1998-07-21	\N	\N	1913	2278	1998-07-22
2006	1	1998-07-23	\N	\N	1914	2279	1998-07-28
2007	1	1998-07-23	\N	\N	1915	2280	1998-07-27
2008	1	1998-07-24	\N	\N	1916	2281	1998-10-19
2009	1	1998-07-24	\N	\N	1917	2282	1998-10-05
2010	1	1998-07-25	\N	\N	1918	2283	1998-10-05
2011	1	1998-07-27	\N	\N	1919	2285	1998-07-29
2012	1	1998-07-27	\N	\N	1920	2286	1998-07-28
2013	1	1998-07-28	\N	\N	1921	2287	1998-10-06
2014	1	1998-07-28	\N	\N	1922	2288	1998-10-20
2015	1	1998-07-29	\N	\N	1923	2289	1998-10-12
2016	1	1998-07-29	\N	\N	1924	2290	1998-10-20
2017	1	1998-07-30	\N	\N	1925	2292	1998-11-03
2018	1	1998-07-31	\N	\N	1926	2293	1998-10-13
2019	1	1997-10-29	\N	\N	1927	2249	1997-11-06
2020	1	1997-10-30	\N	\N	1928	2250	1997-11-12
2021	1	1997-10-30	\N	\N	1929	2251	1997-11-06
2022	1	1998-08-04	\N	\N	1930	2299	1998-10-28
2023	1	1998-08-04	\N	\N	1931	2300	1998-10-14
2024	1	1998-08-05	\N	\N	1932	2301	1998-10-26
2025	1	1999-02-05	2015-08-30	\N	1933	2306	1999-02-17
2026	1	1998-10-02	\N	\N	1934	2304	1998-10-08
2027	1	1998-10-01	2004-03-15	\N	1935	2302	1998-10-07
2028	1	1998-10-01	\N	\N	1936	2303	1998-10-07
2029	1	1999-02-10	2017-11-13	\N	1937	2307	1999-02-23
2030	1	1999-02-25	\N	\N	1938	2308	1999-03-03
2031	1	1999-03-01	\N	\N	1939	2309	1999-03-03
2032	1	1999-03-02	2005-04-25	\N	1940	2310	1999-06-22
2033	1	1999-07-10	\N	\N	1941	2312	1999-07-15
2034	1	1999-07-12	\N	\N	1942	2313	1999-10-26
2035	1	1999-07-13	\N	\N	1943	2314	1999-07-13
2036	1	1999-07-13	\N	\N	1944	2315	1999-07-13
2037	1	1999-07-14	\N	\N	1945	2316	1999-07-15
2038	1	1999-07-14	\N	\N	1946	2317	1999-07-20
2039	1	1999-07-15	\N	\N	1947	2318	1999-07-26
2040	1	1999-07-15	\N	\N	1948	2319	1999-07-27
2041	1	1999-07-16	2018-07-10	\N	1949	2320	1999-07-22
2042	1	1999-07-16	\N	\N	1950	2321	1999-07-22
2043	1	1999-07-19	\N	\N	1951	2323	1999-07-21
2044	1	1999-07-20	\N	\N	1952	2324	1999-07-21
2045	1	1999-07-20	2012-03-29	\N	1953	2325	1999-07-20
2046	1	1999-07-21	\N	\N	1954	2326	1999-07-27
2047	1	1999-07-22	\N	\N	1955	2328	1999-07-26
2048	1	1999-07-22	2013-01-09	\N	1956	2329	1999-07-28
2049	1	1999-07-23	\N	\N	1957	2330	1999-07-28
2050	1	1999-07-23	\N	\N	1958	2331	1999-11-02
2051	1	1999-07-26	\N	\N	1959	2332	1999-10-27
2052	1	1999-07-26	\N	\N	1960	2333	1999-11-01
2053	1	1999-07-27	\N	\N	1961	2334	1999-10-12
2054	1	1999-07-27	\N	\N	1962	2335	1999-10-12
2055	1	1999-07-28	\N	\N	1963	2336	1999-10-26
2056	1	1999-07-28	\N	\N	1964	2337	1999-10-18
2057	1	1999-07-29	\N	\N	1965	2338	1999-10-19
2058	1	1999-07-29	\N	\N	1966	2339	1999-10-13
2059	1	1998-08-01	\N	\N	1967	2295	1998-10-06
2060	1	1998-08-01	\N	\N	1968	2296	1998-10-19
2061	1	1998-08-03	\N	\N	1969	2298	1998-10-13
2062	1	1999-08-02	\N	\N	1970	2344	1999-10-27
2063	1	1999-08-02	\N	\N	1971	2345	1999-10-20
2064	1	1999-08-03	\N	\N	1972	2346	1999-10-20
2065	1	1999-08-03	\N	\N	1973	2347	1999-10-19
2066	1	1999-08-04	\N	\N	1974	2348	1999-10-18
2067	1	1999-08-04	\N	\N	1975	2349	1999-11-29
2068	1	1999-08-05	\N	\N	1976	2350	1999-11-01
2069	1	1999-08-05	\N	\N	1977	2351	1999-11-03
2070	1	1999-08-06	2015-02-07	\N	1978	2352	1999-11-08
2071	1	1999-08-06	\N	\N	1979	2353	1999-10-25
2072	1	1999-08-24	\N	\N	1980	2354	2000-02-03
2073	1	2000-04-18	\N	\N	1981	2373	2000-04-18
2074	1	2000-04-18	\N	\N	1982	2374	2000-05-02
2075	1	2000-04-19	\N	\N	1983	2375	2000-05-02
2076	1	2000-04-19	\N	\N	1984	2376	2000-04-19
2077	1	2000-04-19	\N	\N	1985	2377	2000-04-19
2078	1	2000-06-05	\N	\N	1986	2399	2000-10-17
2079	1	2000-06-07	\N	\N	1987	2400	2000-07-12
2080	1	2000-06-07	\N	\N	1988	2401	2000-06-28
2081	1	2000-06-12	\N	\N	1989	2402	2000-07-12
2082	1	2000-07-17	\N	\N	1990	2403	2000-07-18
2083	1	2000-10-02	\N	\N	1991	2404	2000-10-17
2084	1	2000-10-20	\N	\N	1992	2405	2000-10-24
2085	1	2001-01-15	\N	\N	1993	2406	2001-01-16
2086	1	1999-11-16	2000-12-07	\N	1994	2355	1999-11-17
2087	1	1999-11-16	2000-09-14	\N	1995	2356	\N
2088	1	1999-11-16	2017-01-13	\N	1996	2357	1999-11-25
2089	1	2000-05-02	\N	\N	1997	2381	2000-05-03
2090	1	2000-05-03	\N	\N	1998	2382	2000-05-03
2091	1	1999-07-30	\N	\N	1999	2340	1999-10-13
2092	1	1999-07-31	\N	\N	2000	2342	1999-11-02
2093	1	1999-07-31	\N	\N	2001	2343	1999-10-11
2094	1	1999-11-17	2018-07-09	\N	2002	2364	1999-11-17
2095	1	2000-02-09	2015-01-21	\N	2003	2365	2000-02-29
2096	1	2000-02-10	\N	\N	2004	2366	2000-02-15
2097	1	2000-02-11	\N	\N	2005	2367	2000-03-07
2098	1	2000-02-14	2019-05-29	\N	2006	2368	2000-02-16
2099	1	2000-02-15	\N	\N	2007	2369	2000-03-07
2100	1	2000-02-16	2017-06-18	\N	2008	2370	2000-02-22
2101	1	2000-04-17	2010-10-10	\N	2009	2371	2000-04-17
2102	1	2000-05-09	2018-04-20	\N	2010	2387	2000-05-15
2103	1	2000-05-09	\N	\N	2011	2388	2000-05-22
2104	1	2000-05-10	\N	\N	2012	2389	2000-05-24
2105	1	2000-05-10	\N	\N	2013	2390	2000-05-23
2106	1	2000-05-11	\N	\N	2014	2391	2000-05-15
2107	1	2000-05-11	2016-07-06	\N	2015	2392	2000-05-17
2108	1	2000-05-12	\N	\N	2016	2393	2000-05-16
2109	1	2000-05-12	2016-01-29	\N	2017	2394	2000-05-17
2110	1	2000-05-15	\N	\N	2018	2395	2000-05-23
2111	1	2000-05-15	2010-04-12	\N	2019	2396	2000-05-22
2112	1	2000-05-16	2011-02-01	\N	2020	2397	2000-05-24
2113	1	2000-05-16	\N	\N	2021	2398	2000-06-05
2114	1	2000-05-01	\N	\N	2022	2378	2000-05-10
2115	1	2000-05-01	\N	\N	2023	2379	2000-05-08
2116	1	2000-05-02	\N	\N	2024	2380	2000-05-09
2117	1	2000-05-03	\N	\N	2025	2383	2000-05-10
2118	1	2000-05-04	\N	\N	2026	2384	2000-05-08
2119	1	2000-05-04	\N	\N	2027	2385	2000-05-09
2120	1	2000-05-05	\N	\N	2028	2386	2000-05-16
2121	1	2001-06-02	2006-01-21	\N	2029	2407	2001-07-02
2122	1	2001-06-04	\N	\N	2030	2408	2001-06-26
2123	1	2001-06-05	\N	\N	2031	2409	2001-07-09
2124	1	2001-06-16	\N	\N	2032	2410	2001-06-21
2125	1	2001-06-18	\N	\N	2033	2411	2001-06-26
2126	1	2001-06-19	\N	\N	2034	2412	2001-06-27
2127	1	1999-11-16	2010-12-21	\N	2035	2360	1999-11-22
2128	1	1999-11-17	\N	\N	2036	2363	1999-11-18
2129	1	2001-06-26	\N	\N	2037	2418	2001-07-10
2130	1	2001-06-27	\N	\N	2038	2419	2001-07-23
2131	1	2001-06-27	\N	\N	2039	2420	2001-07-17
2132	1	2001-06-28	\N	\N	2040	2421	2001-07-10
2133	1	2001-06-28	\N	\N	2041	2422	2001-07-18
2134	1	2001-06-29	\N	\N	2042	2423	2001-07-11
2135	1	2001-06-29	2018-01-29	\N	2043	2424	2001-07-18
2136	1	2001-06-30	\N	\N	2044	2425	2001-10-24
2137	1	2001-07-02	\N	\N	2045	2426	2001-07-03
2138	1	2001-07-02	\N	\N	2046	2427	2001-07-02
2139	1	2001-07-03	\N	\N	2047	2428	2001-07-04
2140	1	2001-07-03	\N	\N	2048	2429	2001-07-04
2141	1	2001-07-04	\N	\N	2049	2430	2001-07-11
2142	1	2001-07-04	\N	\N	2050	2431	2001-07-19
2143	1	2001-07-05	\N	\N	2051	2432	2001-07-23
2144	1	2001-07-05	2012-02-19	\N	2052	2433	2001-07-17
2145	1	2001-07-06	\N	\N	2053	2434	2001-07-19
2146	1	2001-07-09	\N	\N	2054	2435	2001-10-17
2147	1	2001-07-10	2018-12-22	\N	2055	2436	2001-07-24
2148	1	2001-07-11	\N	\N	2056	2437	2001-10-15
2149	1	2001-07-12	\N	\N	2057	2438	2001-10-23
2150	1	2001-07-14	2008-05-06	\N	2058	2440	2001-10-31
2151	1	2001-07-16	\N	\N	2059	2441	2001-10-23
2152	1	2001-07-17	\N	\N	2060	2442	2001-10-17
2153	1	2001-07-18	\N	\N	2061	2443	2001-10-15
2154	1	2001-07-19	2020-01-18	\N	2062	2444	2001-10-16
2155	1	2001-07-13	\N	\N	2063	2439	2001-10-22
2156	1	2001-07-20	\N	\N	2064	2445	2001-10-24
2157	1	2001-07-30	\N	\N	2065	2446	2001-10-22
2158	1	2001-10-30	\N	\N	2066	2448	2001-10-31
2159	1	2002-10-01	\N	\N	2067	2449	2002-10-08
2160	1	2002-11-01	\N	\N	2068	2450	2002-11-19
2161	1	2002-11-18	\N	\N	2069	2451	2003-01-15
2162	1	2003-06-16	\N	\N	2070	2452	2003-06-30
2163	1	2003-06-17	\N	\N	2071	2453	2003-06-24
2164	1	2004-01-09	\N	\N	2072	2454	2004-01-12
2165	1	2004-01-12	\N	\N	2073	2456	2004-01-13
2166	1	2001-06-22	2020-02-03	\N	2074	2414	2001-06-27
2167	1	2001-06-23	2015-09-04	\N	2075	2416	2001-07-09
2168	1	2001-06-25	\N	\N	2076	2417	2001-07-24
2169	1	2004-06-03	2019-03-01	\N	2077	2462	2004-06-09
2170	1	2004-06-03	2007-08-09	\N	2078	2463	2004-06-08
2171	1	2004-06-04	\N	\N	2079	2464	2004-06-16
2172	1	2004-06-04	2017-08-03	\N	2080	2465	2004-06-16
2173	1	2004-06-07	\N	\N	2081	2466	2004-07-05
2174	1	2004-06-07	2011-11-06	\N	2082	2467	2004-07-19
2175	1	2004-06-08	\N	\N	2083	2468	2004-06-15
2176	1	2004-06-08	\N	\N	2084	2469	2004-06-22
2177	1	2004-06-09	\N	\N	2085	2470	2004-06-29
2178	1	2004-06-10	\N	\N	2086	2472	2004-06-23
2179	1	2004-06-10	2017-01-25	\N	2087	2473	2004-06-23
2180	1	2004-06-11	\N	\N	2088	2474	2004-07-07
2181	1	2004-06-11	\N	\N	2089	2475	2004-07-05
2182	1	2004-06-14	\N	\N	2090	2477	2004-06-28
2183	1	2004-06-15	\N	\N	2091	2478	2004-07-12
2184	1	2004-06-15	\N	\N	2092	2479	2004-06-30
2185	1	2004-06-16	\N	\N	2093	2480	2004-06-29
2186	1	2004-06-16	\N	\N	2094	2481	2004-06-30
2187	1	2004-06-17	\N	\N	2095	2482	2004-06-28
2188	1	2004-06-17	\N	\N	2096	2483	2004-07-07
2189	1	2004-06-18	2014-03-13	\N	2097	2484	2004-07-12
2190	1	2004-06-18	\N	\N	2098	2485	2004-07-13
2191	1	2004-06-21	\N	\N	2099	2486	2004-07-14
2192	1	2004-06-21	\N	\N	2100	2487	2004-07-19
2193	1	2004-06-22	\N	\N	2101	2489	2004-09-08
2194	1	2004-06-23	2009-11-02	\N	2102	2490	2004-09-13
2195	1	2004-06-23	\N	\N	2103	2491	2004-07-21
2196	1	2004-06-24	2009-09-03	\N	2104	2492	2004-09-08
2197	1	2004-06-24	\N	\N	2105	2493	2004-07-13
2198	1	2004-06-25	\N	\N	2106	2494	2004-09-07
2199	1	2004-06-25	\N	\N	2107	2495	2004-10-11
2200	1	2004-06-28	\N	\N	2108	2496	2004-07-20
2201	1	2004-06-28	\N	\N	2109	2497	2004-07-14
2202	1	2004-06-29	\N	\N	2110	2498	2004-09-07
2203	1	2004-06-29	2009-04-18	\N	2111	2499	2004-09-14
2204	1	2004-06-30	\N	\N	2112	2501	2004-09-14
2205	1	2004-07-01	\N	\N	2113	2502	2004-09-15
2206	1	2004-07-01	\N	\N	2114	2503	2004-09-13
2207	1	2005-01-11	\N	\N	2115	2504	2005-01-19
2208	1	2004-06-01	\N	\N	2116	2459	2004-06-08
2209	1	2004-06-02	\N	\N	2117	2461	2004-06-21
2210	1	2005-05-17	\N	\N	2118	2509	2005-05-23
2211	1	2005-05-31	\N	\N	2119	2510	2005-07-19
2212	1	2005-06-10	\N	\N	2120	2511	2005-06-14
2213	1	2005-06-13	\N	\N	2121	2512	2005-06-14
2214	1	2005-06-14	\N	\N	2122	2513	2005-06-21
2215	1	2005-06-14	\N	\N	2123	2514	2005-06-15
2216	1	2005-06-15	\N	\N	2124	2515	2005-06-22
2217	1	2005-06-15	\N	\N	2125	2516	2005-06-15
2218	1	2005-06-17	\N	\N	2126	2519	2005-06-28
2219	1	2005-06-17	\N	\N	2127	2520	2005-06-27
2220	1	2005-06-20	\N	\N	2128	2521	2005-06-29
2221	1	2005-06-20	2014-02-25	\N	2129	2522	2005-07-05
2222	1	2005-06-21	\N	\N	2130	2523	2005-06-29
2223	1	2005-06-21	\N	\N	2131	2524	2005-07-13
2224	1	2005-06-22	\N	\N	2132	2525	2005-07-05
2225	1	2005-06-22	\N	\N	2133	2526	2005-07-18
2226	1	2005-06-23	\N	\N	2134	2527	2005-06-27
2227	1	2005-06-23	2006-01-08	\N	2135	2528	2005-07-04
2228	1	2005-06-24	\N	\N	2136	2529	2005-07-06
2229	1	2005-06-24	2019-11-09	\N	2137	2530	2005-07-06
2230	1	2005-06-27	\N	\N	2138	2531	2005-10-11
2231	1	2005-06-27	2010-08-30	\N	2139	2532	2005-07-04
2232	1	2005-06-28	\N	\N	2140	2533	2005-07-19
2233	1	2005-06-28	\N	\N	2141	2534	2005-07-18
2234	1	2005-06-29	\N	\N	2142	2536	2005-07-20
2235	1	2005-07-19	\N	\N	2143	2537	2005-07-20
2236	1	2005-09-06	\N	\N	2144	2538	2005-10-18
2237	1	2005-09-07	\N	\N	2145	2539	2005-10-12
2238	1	2005-10-03	\N	\N	2146	2540	2005-10-12
2239	1	2005-10-05	\N	\N	2147	2541	2005-10-25
2240	1	2005-10-10	\N	\N	2148	2542	2005-10-25
2241	1	2005-10-11	\N	\N	2149	2543	2005-12-07
2242	1	2005-10-12	\N	\N	2150	2544	2005-12-06
2243	1	2006-03-22	\N	\N	2151	2545	2006-03-28
2244	1	2006-04-28	\N	\N	2152	2546	2006-06-26
2245	1	2006-05-26	\N	\N	2153	2547	2006-06-12
2246	1	2006-05-30	\N	\N	2154	2549	2006-06-05
2247	1	2006-05-30	\N	\N	2155	2550	2006-06-13
2248	1	2005-03-31	\N	\N	2156	2506	2005-06-21
2249	1	2005-04-06	\N	\N	2157	2507	2005-05-24
2250	1	2005-05-16	\N	\N	2158	2508	2005-05-23
2251	1	2006-06-02	\N	\N	2159	2556	2006-06-22
2252	1	2006-06-05	\N	\N	2160	2558	2006-07-10
2253	1	2006-06-06	\N	\N	2161	2560	2006-06-27
2254	1	2006-06-07	\N	\N	2162	2561	2006-06-27
2255	1	2006-06-07	\N	\N	2163	2562	2006-06-13
2256	1	2006-06-08	\N	\N	2164	2563	2006-06-12
2257	1	2006-06-08	\N	\N	2165	2564	2006-07-10
2258	1	2006-06-09	2008-08-14	\N	2166	2565	2006-07-11
2259	1	2006-06-09	\N	\N	2167	2566	2006-07-20
2260	1	2006-06-12	\N	\N	2168	2567	2006-07-18
2261	1	2006-06-12	\N	\N	2169	2568	2006-07-24
2262	1	2006-06-13	\N	\N	2170	2570	2006-07-11
2263	1	2006-06-14	\N	\N	2171	2571	2006-07-03
2264	1	2006-06-14	\N	\N	2172	2572	2006-07-03
2265	1	2006-06-15	\N	\N	2173	2573	2006-07-20
2266	1	2012-01-10	\N	\N	2174	2743	2012-01-12
2267	1	2012-06-25	\N	\N	2175	2744	2012-06-26
2268	1	2012-07-03	\N	\N	2176	2745	2012-07-12
2269	1	2012-11-01	\N	\N	2177	2746	2012-11-01
2270	1	2013-01-21	\N	\N	2178	2748	2013-01-21
2271	1	2013-03-25	\N	\N	2179	2749	2013-03-26
2272	1	2013-03-26	\N	\N	2180	2750	2013-03-26
2273	1	2013-07-12	\N	\N	2181	2751	2013-07-15
2274	1	2013-09-04	\N	\N	2182	2753	2013-10-08
2275	1	2013-09-04	\N	\N	2183	2754	2013-10-08
2276	1	2013-07-19	\N	\N	2184	2752	2013-07-22
2277	1	2013-09-05	\N	\N	2185	2755	2013-10-09
2278	1	2013-09-05	\N	\N	2186	2756	2013-10-10
2279	1	2013-09-06	\N	\N	2187	2757	2013-10-10
2280	1	2013-09-06	\N	\N	2188	2758	2013-10-15
2281	1	2013-09-09	\N	\N	2189	2759	2013-10-14
2282	1	2013-09-09	\N	\N	2190	2760	2013-10-15
2283	1	2006-06-15	\N	\N	2191	2574	2006-10-10
2284	1	2006-06-16	\N	\N	2192	2575	2006-07-24
2285	1	2006-06-16	\N	\N	2193	2576	2006-10-10
2286	1	2006-06-30	\N	\N	2194	2577	2006-07-25
2287	1	2006-09-18	\N	\N	2195	2578	2006-10-12
2288	1	2006-12-19	\N	\N	2196	2579	2007-01-23
2289	1	2006-05-31	\N	\N	2197	2552	2006-06-06
2290	1	2006-06-01	\N	\N	2198	2554	2006-06-26
2291	1	2006-06-02	\N	\N	2199	2555	2006-06-06
2292	1	2007-03-28	\N	\N	2200	2584	2007-04-30
2293	1	2007-03-29	\N	\N	2201	2585	2007-04-30
2294	1	2007-07-09	\N	\N	2202	2587	2007-07-09
2295	1	2007-07-09	\N	\N	2203	2588	2007-07-09
2296	1	2007-07-11	\N	\N	2204	2590	2007-07-11
2297	1	2007-07-10	\N	\N	2205	2589	2007-07-10
2298	1	2007-07-12	\N	\N	2206	2591	2007-07-19
2299	1	2007-10-10	\N	\N	2207	2592	2007-10-18
2300	1	2007-10-11	\N	\N	2208	2593	2007-10-15
2301	1	2007-10-16	\N	\N	2209	2595	2007-10-18
2302	1	2007-10-17	\N	\N	2210	2596	2007-11-13
2303	1	2007-12-11	\N	\N	2211	2598	2007-12-13
2304	1	2008-05-28	\N	\N	2212	2599	2008-06-02
2305	1	2008-05-29	\N	\N	2213	2600	2008-07-14
2306	1	2008-06-02	\N	\N	2214	2601	2008-07-01
2307	1	2008-06-30	\N	\N	2215	2602	2008-07-07
2308	1	2008-10-01	\N	\N	2216	2603	2008-10-06
2309	1	2008-10-15	\N	\N	2217	2605	2008-10-16
2310	1	2008-10-16	\N	\N	2218	2606	2008-10-21
2311	1	2008-11-03	\N	\N	2219	2607	2008-11-03
2312	1	2008-11-10	\N	\N	2220	2608	2008-12-11
2313	1	2009-02-02	\N	\N	2221	2609	2009-02-02
2314	1	2009-04-21	\N	\N	2222	2610	2009-04-28
2315	1	2009-05-29	\N	\N	2223	2611	2009-06-01
2316	1	2009-06-27	\N	\N	2224	2612	2009-06-29
2317	1	2009-06-29	\N	\N	2225	2613	2009-06-29
2318	1	2009-06-30	\N	\N	2226	2614	2009-06-30
2319	1	2009-07-20	\N	\N	2227	2615	2009-07-20
2320	1	2009-09-01	\N	\N	2228	2617	2009-10-27
2321	1	2009-09-11	\N	\N	2229	2618	2009-10-27
2322	1	2009-08-25	2018-04-29	\N	2230	2616	2009-10-13
2323	1	2010-03-19	\N	\N	2231	2619	2010-03-22
2324	1	2010-03-22	\N	\N	2232	2620	2010-03-22
2325	1	2010-03-23	\N	\N	2233	2621	2010-03-29
2326	1	2010-03-24	\N	\N	2234	2622	2010-03-29
2327	1	2010-05-27	\N	\N	2235	2623	2010-05-27
2328	1	2010-05-28	\N	\N	2236	2624	2010-06-03
2329	1	2010-05-29	\N	\N	2237	2625	2010-06-03
2330	1	2010-06-17	\N	\N	2238	2626	2010-07-05
2331	1	2007-03-23	\N	\N	2239	2581	2007-04-24
2332	1	2007-03-26	\N	\N	2240	2582	2007-05-15
2333	1	2007-03-27	\N	\N	2241	2583	2007-04-26
2334	1	2010-06-18	2014-09-12	\N	2242	2631	2010-07-05
2335	1	2010-06-19	\N	\N	2243	2632	2010-06-21
2336	1	2010-06-20	\N	\N	2244	2633	2010-07-05
2337	1	2010-06-20	\N	\N	2245	2634	2010-07-14
2338	1	2010-06-21	\N	\N	2246	2635	2010-06-21
2339	1	2010-06-22	\N	\N	2247	2637	2010-06-22
2340	1	2010-06-22	\N	\N	2248	2638	2010-06-22
2341	1	2010-06-23	\N	\N	2249	2639	2010-06-23
2342	1	2010-06-23	\N	\N	2250	2640	2010-06-24
2343	1	2010-06-24	\N	\N	2251	2642	2010-06-29
2344	1	2010-06-25	\N	\N	2252	2643	2010-06-29
2345	1	2010-06-26	\N	\N	2253	2645	2010-06-28
2346	1	2010-06-26	\N	\N	2254	2646	2010-07-01
2347	1	2010-06-27	\N	\N	2255	2647	2010-07-01
2348	1	2010-06-27	\N	\N	2256	2648	2010-07-01
2349	1	2010-06-28	\N	\N	2257	2649	2010-06-28
2350	1	2010-06-28	\N	\N	2258	2650	2010-06-30
2351	1	2010-07-07	\N	\N	2259	2651	2010-07-08
2352	1	2010-07-07	\N	\N	2260	2652	2010-07-08
2353	1	2010-07-07	\N	\N	2261	2653	2010-07-08
2354	1	2010-07-07	\N	\N	2262	2654	2010-07-13
2355	1	2010-07-08	2019-05-29	\N	2263	2655	2010-07-12
2356	1	2010-07-08	\N	\N	2264	2656	2010-07-19
2357	1	2011-01-19	\N	\N	2265	2716	2011-01-24
2358	1	2010-07-09	\N	\N	2266	2657	2010-07-13
2359	1	2010-07-09	\N	\N	2267	2658	2010-07-13
2360	1	2010-07-10	\N	\N	2268	2660	2010-07-12
2361	1	2010-07-12	\N	\N	2269	2661	2010-07-19
2362	1	2014-11-28	\N	\N	2270	2806	2014-12-08
2363	1	2014-12-02	\N	\N	2271	2807	2015-01-12
2364	1	2014-12-03	\N	\N	2272	2808	2014-12-09
2365	1	2014-12-11	\N	\N	2273	2809	2015-01-22
2366	1	2014-12-16	\N	\N	2274	2810	2015-01-13
2367	1	2015-03-17	\N	\N	2275	2811	2015-03-19
2368	1	2015-05-19	\N	\N	2276	2812	2015-06-01
2369	1	2015-05-26	\N	\N	2277	2813	2015-05-28
2370	1	2015-05-28	\N	\N	2278	2815	2015-06-01
2371	1	2015-05-28	\N	\N	2279	2816	2015-06-02
2372	1	2010-06-18	\N	\N	2280	2628	2010-07-06
2373	1	2010-06-18	\N	\N	2281	2629	2010-07-07
2374	1	2010-06-18	\N	\N	2282	2630	2010-07-06
2375	1	2015-09-29	\N	\N	2283	2821	2015-10-12
2376	1	2015-09-29	\N	\N	2284	2822	2015-10-12
2377	1	2015-09-30	\N	\N	2285	2823	2015-10-15
2378	1	2010-07-13	\N	\N	2286	2663	2010-07-15
2379	1	2010-07-13	\N	\N	2287	2664	2010-07-20
2380	1	2010-07-14	\N	\N	2288	2665	2010-07-15
2381	1	2010-07-14	\N	\N	2289	2666	2010-07-15
2382	1	2010-07-15	\N	\N	2290	2667	2010-07-19
2383	1	2010-07-15	\N	\N	2291	2668	2010-07-26
2384	1	2010-07-16	\N	\N	2292	2669	2010-07-22
2385	1	2010-07-16	\N	\N	2293	2670	2010-07-22
2386	1	2010-07-19	\N	\N	2294	2671	2010-07-20
2387	1	2010-07-19	\N	\N	2295	2672	2010-07-21
2388	1	2010-07-20	\N	\N	2296	2673	2010-07-26
2389	1	2010-07-20	\N	\N	2297	2674	2010-07-27
2390	1	2010-07-21	\N	\N	2298	2675	2010-07-28
2391	1	2010-07-21	\N	\N	2299	2676	2010-07-22
2392	1	2010-07-22	\N	\N	2300	2678	2010-07-27
2393	1	2010-07-23	2017-04-23	\N	2301	2679	2010-10-18
2394	1	2010-07-26	\N	\N	2302	2680	2010-10-11
2395	1	2010-11-08	\N	\N	2303	2681	2011-11-25
2396	1	2010-11-15	\N	\N	2304	2682	2010-11-15
2397	1	2010-11-16	\N	\N	2305	2683	2010-11-22
2398	1	2010-11-22	\N	\N	2306	2684	2010-11-22
2399	1	2010-12-17	\N	\N	2307	2685	2010-12-20
2400	1	2010-12-17	\N	\N	2308	2686	2010-12-20
2401	1	2010-12-18	\N	\N	2309	2687	2010-12-20
2402	1	2010-12-18	\N	\N	2310	2688	2010-12-21
2403	1	2010-12-20	\N	\N	2311	2689	2010-12-21
2404	1	2010-12-21	\N	\N	2312	2691	2010-12-22
2405	1	2010-12-21	\N	\N	2313	2692	2010-12-22
2406	1	2010-12-22	\N	\N	2314	2693	2011-01-10
2407	1	2010-12-22	\N	\N	2315	2694	2011-01-10
2408	1	2010-12-23	\N	\N	2316	2695	2011-01-11
2409	1	2010-12-23	\N	\N	2317	2696	2011-01-10
2410	1	2010-12-24	\N	\N	2318	2697	2011-01-11
2411	1	2010-12-24	\N	\N	2319	2698	2011-01-11
2412	1	2011-01-10	\N	\N	2320	2700	2011-01-12
2413	1	2015-06-08	\N	\N	2321	2818	2015-06-09
2414	1	2015-09-28	\N	\N	2322	2819	2015-10-13
2415	1	2015-09-28	\N	\N	2323	2820	2015-10-13
2416	1	2011-01-13	\N	\N	2324	2706	2011-01-17
2417	1	2011-01-14	\N	\N	2325	2708	2011-01-18
2418	1	2011-01-15	\N	\N	2326	2709	2011-01-18
2419	1	2011-01-15	\N	\N	2327	2710	2011-01-19
2420	1	2011-01-17	\N	\N	2328	2711	2011-01-19
2421	1	2011-01-18	\N	\N	2329	2713	2011-01-20
2422	1	2011-01-18	\N	\N	2330	2714	2011-01-20
2423	1	2011-01-19	\N	\N	2331	2715	2011-01-24
2424	1	2011-01-20	\N	\N	2332	2717	2011-01-24
2425	1	2011-01-20	\N	\N	2333	2718	2011-01-25
2426	1	2011-01-21	\N	\N	2334	2719	2011-01-25
2427	1	2011-01-24	\N	\N	2335	2721	2011-01-26
2428	1	2011-01-24	\N	\N	2336	2722	2011-01-26
2429	1	2011-01-25	\N	\N	2337	2723	2011-01-27
2430	1	2011-01-25	\N	\N	2338	2724	2011-01-27
2431	1	2011-01-26	\N	\N	2339	2725	2011-01-27
2432	1	2011-01-26	\N	\N	2340	2726	2011-01-31
2433	1	2011-01-27	\N	\N	2341	2727	2011-01-31
2434	1	2011-01-27	2015-10-27	\N	2342	2728	2011-01-31
2435	1	2011-01-28	\N	\N	2343	2729	2011-02-01
2436	1	2011-01-28	\N	\N	2344	2730	2011-02-01
2437	1	2011-01-31	\N	\N	2345	2732	2011-02-02
2438	1	2011-02-01	\N	\N	2346	2733	2011-03-22
2439	1	2011-02-01	\N	\N	2347	2734	2011-02-03
2440	1	2011-02-02	\N	\N	2348	2735	2011-02-03
2441	1	2011-02-02	\N	\N	2349	2736	2011-02-07
2442	1	2011-02-04	\N	\N	2350	2737	2011-03-08
2443	1	2011-02-04	\N	\N	2351	2738	2011-02-10
2444	1	2011-02-28	\N	\N	2352	2739	2011-03-10
2445	1	2011-10-12	\N	\N	2353	2741	2011-10-24
2446	1	2011-10-13	\N	\N	2354	2742	2011-10-24
2447	1	2015-10-06	\N	\N	2355	2832	2015-10-29
2448	1	2015-10-06	\N	\N	2356	2833	2015-10-27
2449	1	2015-10-07	\N	\N	2357	2834	2015-10-29
2450	1	2015-10-07	\N	\N	2358	2835	2015-11-05
2451	1	2015-10-08	\N	\N	2359	2836	2015-11-03
2452	1	2015-10-08	\N	\N	2360	2837	2015-11-03
2453	1	2011-01-11	\N	\N	2361	2702	2011-01-13
2454	1	2011-01-12	\N	\N	2362	2704	2011-01-17
2455	1	2011-01-13	\N	\N	2363	2705	2011-01-17
2456	1	2015-10-13	\N	\N	2364	2842	2015-11-09
2457	1	2015-10-13	\N	\N	2365	2843	2015-11-05
2458	1	2015-10-14	\N	\N	2366	2844	2015-11-17
2459	1	2015-10-14	\N	\N	2367	2845	2015-11-30
2460	1	2015-10-15	\N	\N	2368	2846	2015-11-19
2461	1	2015-10-15	\N	\N	2369	2847	2015-11-17
2462	1	2015-10-16	\N	\N	2370	2848	2015-11-30
2463	1	2015-09-30	\N	\N	2371	2824	2015-10-15
2464	1	2015-10-01	\N	\N	2372	2825	2015-10-20
2465	1	2015-10-01	\N	\N	2373	2827	2015-10-22
2466	1	2015-10-02	\N	\N	2374	2828	2015-10-20
2467	1	2015-10-02	\N	\N	2375	2829	2015-10-26
2468	1	2015-10-05	\N	\N	2376	2830	2015-10-26
2469	1	2015-10-05	\N	\N	2377	2831	2015-10-27
2470	1	2015-10-16	\N	\N	2378	2849	2015-11-23
2471	1	2015-10-19	\N	\N	2379	2850	2015-11-19
2472	1	2015-10-19	\N	\N	2380	2851	2015-11-23
2473	1	2015-10-20	\N	\N	2381	2852	2015-11-24
2474	1	2015-10-20	\N	\N	2382	2853	2015-11-26
2475	1	2015-10-21	\N	\N	2383	2854	2015-12-03
2476	1	2015-10-21	\N	\N	2384	2855	2015-12-01
2477	1	2015-10-22	\N	\N	2385	2856	2015-11-24
2478	1	2014-09-05	\N	\N	2386	2785	2014-10-15
2479	1	2014-09-11	\N	\N	2387	2786	2014-10-22
2480	1	2014-09-11	\N	\N	2388	2787	2014-10-13
2481	1	2014-09-12	\N	\N	2389	2788	2014-10-21
2482	1	2014-09-15	\N	\N	2390	2791	2014-10-20
2483	1	2014-09-16	\N	\N	2391	2792	2014-10-23
2484	1	2014-09-16	\N	\N	2392	2793	2014-10-16
2485	1	2014-09-17	\N	\N	2393	2794	2014-10-30
2486	1	2014-09-18	\N	\N	2394	2796	2014-11-24
2487	1	2014-09-18	\N	\N	2395	2797	2014-10-16
2488	1	2014-09-19	\N	\N	2396	2798	2014-10-20
2489	1	2014-09-19	\N	\N	2397	2799	2014-10-23
2490	1	2014-09-22	\N	\N	2398	2800	2014-10-27
2491	1	2014-09-22	\N	\N	2399	2801	2014-11-06
2492	1	2014-09-23	\N	\N	2400	2802	2014-10-28
2493	1	2015-10-23	\N	\N	2401	2858	2015-12-01
2494	1	2015-10-09	\N	\N	2402	2839	2015-11-10
2495	1	2015-10-12	\N	\N	2403	2840	2015-11-09
2496	1	2015-10-12	\N	\N	2404	2841	2015-11-10
2497	1	2015-10-29	\N	\N	2405	2863	2016-01-19
2498	1	2015-10-30	\N	\N	2406	2864	2015-12-07
2499	1	2015-10-30	\N	\N	2407	2865	2015-12-17
2500	1	2015-11-02	\N	\N	2408	2866	2015-12-14
2501	1	2015-12-01	\N	\N	2409	2867	2015-12-10
2502	1	2016-02-29	\N	\N	2410	2868	2016-03-21
2503	1	2016-08-30	\N	\N	2411	2869	2016-10-11
2504	1	2016-08-31	\N	\N	2412	2871	2016-10-20
2505	1	2016-08-31	\N	\N	2413	2872	2016-09-12
2506	1	2016-09-01	\N	\N	2414	2873	2016-09-17
2507	1	2013-09-10	\N	\N	2415	2761	2013-10-29
2508	1	2013-09-10	\N	\N	2416	2762	2013-10-16
2509	1	2013-09-11	\N	\N	2417	2763	2013-10-24
2510	1	2013-09-11	\N	\N	2418	2764	2013-10-17
2511	1	2013-09-12	\N	\N	2419	2765	2013-10-28
2512	1	2013-09-12	\N	\N	2420	2766	2013-10-28
2513	1	2013-09-13	\N	\N	2421	2767	2013-10-22
2514	1	2013-09-13	\N	\N	2422	2768	2013-10-30
2515	1	2013-09-16	\N	\N	2423	2769	2013-10-22
2516	1	2013-09-16	\N	\N	2424	2770	2013-10-17
2517	1	2013-09-17	\N	\N	2425	2771	2013-10-21
2518	1	2013-09-17	\N	\N	2426	2772	2013-10-21
2519	1	2013-09-18	\N	\N	2427	2773	2013-10-24
2520	1	2013-09-18	\N	\N	2428	2774	2013-10-29
2521	1	2013-09-19	\N	\N	2429	2775	2013-10-31
2522	1	2013-09-20	\N	\N	2430	2778	2013-11-05
2523	1	2013-10-02	\N	\N	2431	2780	2013-10-31
2524	1	2013-10-03	\N	\N	2432	2781	2013-11-07
2525	1	2013-10-03	\N	\N	2433	2782	2013-11-11
2526	1	2013-10-04	\N	\N	2434	2783	2013-11-25
2527	1	2014-09-23	\N	\N	2435	2803	2014-10-27
2528	1	2014-09-24	\N	\N	2436	2804	2014-11-06
2529	1	2014-09-24	\N	\N	2437	2805	2014-11-10
2530	1	2016-09-02	\N	\N	2438	2875	2016-10-20
2531	1	2016-09-02	\N	\N	2439	2876	2016-10-18
2532	1	2016-09-05	\N	\N	2440	2877	2016-09-17
2533	1	2016-09-05	\N	\N	2441	2878	2016-09-13
2534	1	2015-10-26	\N	\N	2442	2860	2015-12-07
2535	1	2015-10-26	\N	\N	2443	2861	2015-12-08
2536	1	2015-10-27	2018-05-12	\N	2444	2862	2015-12-10
2537	1	2017-06-22	\N	\N	2445	2884	2017-06-26
2538	1	2017-07-14	\N	\N	2446	2885	2017-07-20
2539	1	2017-10-19	\N	\N	2447	2886	2017-10-24
2540	1	2017-10-19	\N	\N	2448	2887	2017-10-23
2541	1	2017-10-30	\N	\N	2449	2888	2017-11-20
2542	1	2014-02-24	\N	\N	2450	2784	2014-02-25
2543	1	2017-11-03	\N	\N	2451	2889	2017-11-16
2544	1	2017-11-07	\N	\N	2452	2890	2017-11-21
2545	1	2017-11-07	\N	\N	2453	2891	2017-11-16
2546	1	2018-06-12	\N	\N	2454	2893	2018-06-21
2547	1	2018-06-18	\N	\N	2455	2894	2018-06-25
2548	1	2018-06-18	\N	\N	2456	2895	2018-06-26
2549	1	2018-06-19	\N	\N	2457	2897	2018-07-09
2550	1	2018-06-20	\N	\N	2458	2898	2018-06-25
2551	1	2018-06-20	\N	\N	2459	2899	2018-07-02
2552	1	2018-06-21	\N	\N	2460	2900	2018-07-09
2553	1	2018-06-21	\N	\N	2461	2901	2018-07-02
2554	1	2018-06-22	\N	\N	2462	2902	2018-07-03
2555	1	2018-07-11	\N	\N	2463	2907	2018-07-17
2556	1	2018-10-26	2018-11-04	\N	2464	2909	\N
2557	1	2018-11-26	\N	\N	2465	2910	2018-12-04
2558	1	2019-10-07	\N	\N	2466	2914	2019-10-17
2559	1	2019-02-01	\N	\N	2467	2911	2019-02-04
2560	1	2019-10-08	\N	\N	2468	2915	2019-10-22
2561	1	2019-10-08	\N	\N	2469	2916	2019-10-22
2562	1	2019-10-09	\N	\N	2470	2917	2019-11-05
2563	1	2019-10-09	\N	\N	2471	2918	2019-10-15
2564	1	2019-10-10	\N	\N	2472	2919	2019-10-17
2565	1	2019-10-10	\N	\N	2473	2920	2019-10-21
2566	1	2019-10-11	\N	\N	2474	2921	2019-10-29
2567	1	2019-10-11	\N	\N	2475	2922	2020-01-23
2568	1	2019-10-14	\N	\N	2476	2923	2019-11-04
2569	1	2019-10-15	\N	\N	2477	2925	2019-10-28
2570	1	2019-10-15	\N	\N	2478	2926	2019-11-04
2571	1	2019-10-16	\N	\N	2479	2927	2019-10-28
2572	1	2019-10-16	\N	\N	2480	2928	2019-11-05
2573	1	2016-09-06	\N	\N	2481	2880	2016-10-11
2574	1	2016-10-17	\N	\N	2482	2882	2016-10-31
2575	1	2016-10-20	\N	\N	2483	2883	2016-10-31
2576	1	2020-01-11	\N	\N	2484	2934	2020-01-16
2577	1	2018-06-22	\N	\N	2485	2903	2018-07-05
2578	1	2018-06-25	\N	\N	2486	2904	2018-07-10
2579	1	2018-07-09	\N	\N	2487	2905	2018-07-12
2580	1	2018-07-10	\N	\N	2488	2906	2018-07-12
2581	1	2020-01-06	\N	\N	2489	2932	2020-01-13
2582	1	1837-08-11	1879-04-23	\N	2490	231	1837-12-14
2583	1	2006-05-31	\N	\N	2491	2551	2006-06-05
2584	1	1838-07-05	1844-07-11	\N	2492	236	1838-07-17
2585	1	2019-03-10	\N	\N	2493	2912	\N
2586	1	1846-05-02	1856-09-24	\N	2494	274	1848-03-20
2587	1	1856-01-16	1868-02-25	\N	244	296	\N
2588	1	1859-04-16	1875-04-16	\N	2495	316	1859-06-03
2589	1	1860-03-22	1868-05-07	\N	137	324	1868-06-26
2590	1	1868-07-06	1904-06-04	\N	2496	358	1868-07-14
2591	1	1869-12-07	1905-02-21	\N	2497	367	1870-02-08
2592	1	1874-02-28	1898-01-30	\N	2498	401	1874-03-10
2593	1	1874-03-02	1890-12-03	\N	2499	402	1874-03-06
2594	1	1880-05-26	1893-02-06	\N	2500	445	1880-05-27
2595	1	1884-06-17	1888-06-05	\N	2501	462	1884-06-24
2596	1	1885-12-31	1903-07-01	\N	2502	487	1886-01-19
2597	1	1886-08-13	1909-02-01	\N	488	496	1886-08-19
2598	1	1891-06-23	1921-11-29	\N	2503	525	1891-07-27
2599	1	1892-02-22	1901-11-15	\N	2504	530	1892-03-03
2600	1	1892-08-24	1908-07-08	\N	2505	542	1893-05-18
2601	1	1896-01-24	1896-01-25	\N	2506	574	\N
2602	1	1896-01-31	1907-09-13	\N	2507	575	1896-02-11
2603	1	1896-06-09	1902-03-06	\N	2508	577	1896-06-26
2604	1	1897-08-23	1914-01-21	\N	2509	588	1898-02-15
2605	1	1906-01-16	1907-10-27	\N	2510	660	1906-02-14
2606	1	1909-02-20	1937-06-28	\N	2511	683	1909-02-23
2607	1	1911-06-20	1912-10-02	\N	2512	704	1911-07-20
2608	1	1911-06-21	1934-01-23	\N	2513	705	1911-07-17
2609	1	2019-11-11	\N	\N	2514	2931	2020-01-16
2610	1	2020-01-07	\N	\N	2515	2933	2020-01-13
2611	1	1915-02-22	1916-04-30	\N	539	751	1915-03-02
2612	1	1916-12-19	1929-03-09	\N	679	773	1916-12-19
2613	1	1918-11-14	1928-03-29	\N	2516	819	1918-11-14
2614	1	1920-01-28	1934-12-05	\N	2517	851	1920-02-11
2615	1	1922-01-25	1922-03-13	\N	2518	879	1922-02-22
2616	1	1925-06-16	1927-01-17	\N	702	917	1925-06-17
2617	1	1922-11-27	1925-05-07	\N	650	892	1922-12-06
2618	1	1926-02-17	1942-08-21	\N	523	923	1926-03-03
2619	1	1929-06-24	1932-07-16	\N	720	962	1929-11-27
2620	1	1901-11-09	1936-01-20	\N	454	618	\N
2621	1	1928-01-12	1935-06-06	\N	687	938	1928-06-13
2622	1	1929-07-10	1955-11-27	\N	2519	968	1929-07-17
2623	1	1932-06-22	1935-04-28	\N	2520	1004	1932-07-06
2624	1	1929-11-18	1946-12-20	\N	2521	974	1929-11-20
2625	1	1933-02-24	1934-12-05	\N	622	1012	1933-03-08
2626	1	1935-06-26	1947-07-21	\N	2522	1036	1935-07-24
2627	1	1936-07-17	1950-08-07	\N	2523	1056	1936-11-11
2628	1	1937-02-22	1953-10-08	\N	2524	1059	1937-03-10
2629	1	1939-07-07	1964-12-14	\N	1056	1098	1939-07-26
2630	1	1941-01-20	1954-06-15	\N	783	1110	1941-01-29
2631	1	1944-01-29	1953-09-13	\N	2525	1142	1944-02-02
2632	1	1945-07-05	1988-09-21	\N	2526	1158	1945-08-01
2633	1	1946-01-28	1971-04-22	\N	2527	1193	1946-02-27
2634	1	1945-11-13	1952-03-18	\N	2528	1183	1945-12-05
2635	1	1946-06-28	1954-12-04	\N	2529	1208	1946-07-10
2636	1	1947-04-01	1948-05-14	\N	2530	1225	1947-04-02
2637	1	1951-06-26	1953-02-11	\N	2531	1270	1951-07-11
2638	1	1947-04-18	1973-07-18	\N	2532	1226	1947-04-23
2639	1	1949-06-01	1977-04-01	\N	1172	1247	1949-06-01
2640	1	1952-01-07	1958-08-08	\N	2533	1280	\N
2641	1	1954-07-30	1983-06-29	\N	2534	1307	1954-10-27
2642	1	1955-01-10	1965-07-27	\N	2535	1313	1955-03-30
2643	1	1913-03-04	1918-07-12	\N	2536	736	1913-03-06
2644	1	1958-08-08	1988-07-11	\N	2537	1360	1958-10-21
2645	1	1961-02-02	1967-03-29	\N	2538	1403	1961-02-07
2646	1	1960-01-07	1979-06-09	\N	2539	1385	1960-01-27
2647	1	1961-07-11	1973-12-18	\N	2540	1416	1961-07-27
2648	1	1963-11-08	1982-03-07	\N	2541	1447	1963-11-13
2649	1	1964-08-21	1975-02-01	\N	2542	1470	1964-10-28
2650	1	1963-11-09	1987-10-11	\N	2543	1448	1963-11-14
2651	1	1964-12-17	1988-04-28	\N	2544	1491	1964-12-21
2652	1	1966-01-18	1972-02-14	\N	2545	1534	1966-02-09
2653	1	1966-05-31	1994-03-16	\N	2546	1537	1966-06-15
2654	1	1967-01-19	1970-02-17	\N	2547	1557	1967-02-01
2655	1	1967-11-29	1999-10-11	\N	2548	1580	1967-12-13
2656	1	1969-03-03	1997-11-23	\N	2549	1600	1969-03-12
2657	1	1970-09-21	1982-01-24	\N	2550	1623	1970-10-28
2658	1	1971-02-05	2006-05-07	\N	2551	1632	1971-03-03
2659	1	1973-06-29	1991-01-30	\N	2552	1664	1973-07-04
2660	1	1974-01-31	2000-11-08	\N	2553	1668	1974-03-27
2661	1	1974-05-07	1989-04-06	\N	2554	1677	1974-06-19
2662	1	1974-07-05	2010-06-08	\N	2555	1699	1974-07-16
2663	1	1975-01-08	1998-05-17	\N	2556	1713	1975-02-26
2664	1	1975-02-03	1994-12-18	\N	2557	1731	1975-02-10
2665	1	1976-06-25	2016-01-20	\N	2558	1757	1976-06-30
2666	1	1976-06-28	1980-02-10	\N	2559	1758	1976-06-29
2667	1	1976-09-29	2017-07-20	\N	2560	1767	1976-10-06
2668	1	1978-05-11	2009-09-01	\N	2561	1799	1978-07-12
2669	1	1978-07-13	1998-07-01	\N	2562	1803	1978-07-26
2670	1	1979-02-09	2003-07-17	\N	2563	1811	1979-03-06
2671	1	1979-07-26	2012-02-21	\N	2564	1831	1979-10-31
2672	1	1980-07-10	2003-03-10	\N	2565	1847	1980-07-30
2673	1	1981-06-02	2013-06-30	\N	2566	1867	1981-06-24
2674	1	1983-02-07	2010-06-19	\N	2567	1892	1983-02-23
2675	1	1983-02-11	2010-01-22	\N	2568	1895	1983-03-23
2676	1	1983-10-10	2001-07-19	\N	2569	1919	1983-11-22
2677	1	1985-05-17	1986-07-16	\N	2570	1937	1985-06-04
2678	1	1957-07-10	1964-12-27	\N	2571	1346	1957-07-24
2679	1	1958-08-07	1988-02-01	\N	2572	1359	1958-10-22
2680	1	1988-02-09	2007-07-18	\N	2573	1992	1988-02-09
2681	1	1990-07-16	2002-05-03	\N	2574	2025	1990-07-18
2682	1	1990-08-24	\N	\N	2575	2028	1990-10-09
2683	1	1992-06-30	\N	\N	2576	2070	1992-07-08
2684	1	1992-07-01	2006-01-05	\N	2577	2073	1992-07-07
2685	1	1993-10-15	\N	\N	2578	2113	1993-10-27
2686	1	1994-02-10	2020-03-06	\N	2579	2115	1994-02-16
2687	1	1995-02-28	\N	\N	2580	2136	1995-03-28
2688	1	1996-08-19	2006-06-28	\N	2581	2158	1997-06-10
2689	1	1996-10-16	\N	\N	2582	2172	1996-11-06
2690	1	1997-01-06	\N	\N	2583	2176	1997-01-14
2691	1	1997-07-21	2008-07-27	\N	2584	2204	1997-07-23
2692	1	1997-10-06	2012-08-12	\N	2585	2230	1997-10-27
2693	1	1997-10-29	\N	\N	2586	2248	1997-11-17
2694	1	1997-11-01	1999-11-05	\N	2587	2254	1997-11-10
2695	1	1998-02-14	2005-03-05	\N	2588	2269	1998-04-28
2696	1	1998-07-31	2019-08-25	\N	2589	2294	1998-10-14
2697	1	1999-07-30	\N	\N	2590	2341	1999-10-11
2698	1	1999-01-12	\N	\N	2591	2305	1999-01-12
2699	1	1999-11-16	2001-04-05	\N	2592	2359	1999-11-18
2700	1	1999-11-17	2007-02-22	\N	2593	2361	1999-11-23
2701	1	2001-06-20	\N	\N	2594	2413	2001-06-21
2702	1	2001-06-22	2018-05-01	\N	2595	2415	2001-07-03
2703	1	2004-01-12	\N	\N	2596	2455	2004-01-12
2704	1	2004-06-01	\N	\N	2597	2458	2004-06-09
2705	1	2004-06-14	\N	\N	2598	2476	2004-06-21
2706	1	2005-01-28	\N	\N	2599	2505	2005-01-31
2707	1	2004-06-30	\N	\N	2600	2500	2004-07-21
2708	1	2005-06-29	\N	\N	2601	2535	2005-07-13
2709	1	1990-05-21	2004-04-30	\N	2602	2017	1990-05-23
2710	1	1987-06-22	1992-04-01	\N	2603	1969	1987-06-22
2711	1	2008-10-13	\N	\N	2604	2604	2008-10-13
2712	1	2010-06-17	\N	\N	2605	2627	2010-07-06
2713	1	2010-06-21	\N	\N	2606	2636	2010-06-28
2714	1	2010-07-10	\N	\N	2607	2659	2010-07-12
2715	1	2015-05-29	\N	\N	2608	2817	2015-06-02
2716	1	2010-07-22	\N	\N	2609	2677	2010-07-26
2717	1	2011-01-10	\N	\N	2610	2699	2011-01-12
2718	1	2011-01-11	\N	\N	2611	2701	2011-01-13
2719	1	2011-01-14	\N	\N	2612	2707	2011-01-18
2720	1	2011-01-31	\N	\N	2613	2731	2011-02-01
2721	1	2015-10-09	\N	\N	2614	2838	2015-11-26
2722	1	2015-10-01	\N	\N	2615	2826	2015-10-22
2723	1	2014-09-17	\N	\N	2616	2795	2014-10-21
2724	1	2015-10-23	\N	\N	2617	2859	2015-12-03
2725	1	2016-08-30	\N	\N	2618	2870	2016-09-12
2726	1	2013-10-02	\N	\N	2619	2779	2013-11-06
2727	1	2019-10-07	\N	\N	2620	2913	2019-10-15
2728	1	2016-09-06	\N	\N	2621	2879	2016-09-13
2729	1	2019-10-28	\N	\N	2622	2929	2019-10-29
2730	1	2019-10-30	\N	\N	2623	2930	\N
2731	1	2013-01-08	\N	\N	2624	2747	2013-01-15
2732	1	2007-01-11	\N	\N	2625	2580	2007-01-15
2733	1	1801-01-17	1822-12-22	\N	2626	1	1847-07-21
2734	1	1801-04-27	1823-03-13	\N	2627	7	1823-06-04
2735	1	1806-02-21	1819-12-14	\N	2628	43	1806-02-25
2736	1	1806-02-24	1837-06-09	\N	2629	45	1806-06-18
2737	1	1815-08-11	1829-05-19	\N	2630	92	1816-02-01
2738	1	1821-07-14	1825-08-22	\N	2631	110	1822-06-03
2739	1	1825-01-26	1855-05-29	\N	2632	136	1825-02-03
2740	1	1826-07-06	1840-04-26	\N	2633	141	1827-03-05
2741	1	1831-06-20	1836-07-30	\N	2634	171	1831-06-20
2742	1	1831-09-10	1839-07-01	\N	2635	183	1831-09-14
2743	1	1832-05-16	1832-06-30	\N	2636	200	1832-05-21
2744	1	1839-04-20	1853-01-29	\N	2637	245	1843-07-03
2745	1	1860-09-01	1878-01-07	\N	141	325	1878-01-25
2746	1	1873-04-09	1896-12-19	\N	2638	391	1873-05-12
2747	1	1893-06-24	1907-03-23	\N	2639	553	1893-06-27
2748	1	1898-01-19	1906-01-30	\N	2640	592	1898-02-17
2749	1	1902-07-12	1903-07-01	\N	2502	620	1902-07-25
2750	1	1910-07-20	1941-08-12	\N	895	698	1910-07-20
2751	1	1911-11-02	1925-03-20	\N	711	721	1912-02-21
2752	1	1918-01-15	1935-11-20	\N	2641	800	1918-04-09
2753	1	1919-10-28	1921-02-28	\N	2642	845	1919-11-05
2754	1	1933-01-17	1937-08-13	\N	2643	1007	1933-02-15
2755	1	1934-01-13	1963-08-22	\N	878	1020	1934-04-25
2756	1	1948-02-06	1964-12-27	\N	2571	1236	1948-02-25
2757	1	1957-02-04	1969-08-27	\N	2644	1339	1957-03-27
2758	1	1940-10-21	1971-06-16	\N	2645	1108	1940-11-06
2759	1	1966-06-01	1991-04-11	\N	2646	1538	1966-06-22
2760	1	1915-05-15	1934-03-07	\N	2647	753	1918-07-02
2761	1	1954-10-04	1960-11-18	\N	2648	1310	1954-10-20
2762	1	1967-12-05	1969-05-10	\N	2649	1582	1967-12-06
2763	1	1959-11-12	1961-02-03	\N	2650	1381	1959-11-18
2764	1	1963-11-15	1983-08-12	\N	2651	1449	1963-12-04
2765	1	1972-07-10	1980-11-28	\N	2652	1658	1972-07-27
2766	1	1974-09-02	1993-09-08	\N	2653	1705	1974-11-19
2767	1	1978-02-07	1999-12-23	\N	2654	1781	1978-02-22
2768	1	1979-07-18	1999-01-15	\N	2655	1827	1979-07-19
2769	1	1980-07-22	1995-12-05	\N	2656	1850	1980-07-23
2770	1	1983-09-19	1993-11-09	\N	2657	1910	1983-11-02
2771	1	1987-03-30	2002-04-30	\N	2658	1963	1987-04-29
2772	1	1991-02-07	2014-11-27	\N	2659	2035	1991-02-19
2773	1	1992-06-30	2015-10-09	\N	2660	2071	1992-07-01
2774	1	1992-10-01	\N	\N	2661	2099	1992-11-11
2775	1	1996-01-11	\N	\N	2662	2148	1996-02-07
2776	1	1997-09-23	\N	\N	2663	2208	1997-11-04
2777	1	1998-07-20	2012-07-05	\N	2664	2275	1998-07-22
2778	1	1924-06-23	1941-08-12	\N	895	912	1924-07-09
2779	1	1801-08-18	1805-10-21	\N	3	18	\N
2780	1	1806-03-13	1806-11-05	\N	2665	48	1806-04-25
2781	1	1816-01-16	1842-12-10	\N	54	102	\N
2782	1	1826-07-15	1845-07-01	\N	2666	146	1826-12-05
2783	1	1831-09-10	1852-04-13	\N	2667	184	1831-09-13
2784	1	1841-08-18	1883-10-20	\N	2668	266	1841-08-19
2785	1	1858-08-14	1881-02-18	\N	2669	311	1859-05-31
2786	1	1866-08-31	1872-10-27	\N	2670	351	1867-02-05
2787	1	2004-06-09	\N	\N	2671	2471	2004-06-22
2788	1	2005-06-16	\N	\N	2672	2517	2005-06-28
2789	1	2006-05-26	\N	\N	2673	2548	2006-06-15
2790	1	2006-06-05	\N	\N	2674	2557	2006-07-18
2791	1	2007-03-30	\N	\N	2675	2586	2007-04-24
2792	1	2010-06-24	2012-06-09	\N	2676	2641	2010-06-24
2793	1	2010-12-20	\N	\N	2677	2690	2010-12-21
2794	1	2011-01-12	\N	\N	2678	2703	2011-01-13
2795	1	2015-10-22	\N	\N	2679	2857	2015-12-08
2796	1	2016-09-01	\N	\N	2680	2874	2016-10-13
2797	1	2017-11-20	\N	\N	2681	2892	2017-12-12
2798	1	1955-09-02	1971-09-25	\N	2682	1323	1955-11-09
2799	1	1841-06-30	1861-06-23	\N	2683	261	1841-08-23
2800	1	1902-07-11	1916-06-05	\N	492	619	1911-04-26
2801	1	1962-01-29	2000-12-07	\N	1994	1423	1962-02-21
2802	1	1985-05-22	2019-12-30	\N	2684	1939	1985-06-04
2803	1	1987-10-19	2012-03-02	\N	2685	1982	1987-11-04
2804	1	2000-04-17	\N	\N	2686	2372	2000-04-18
2805	1	2006-06-01	\N	\N	2687	2553	2006-06-15
2806	1	2016-10-04	\N	\N	2688	2881	2016-10-24
2807	1	2001-08-28	2010-09-15	\N	2689	2447	2001-10-16
2808	1	1876-10-16	1896-01-08	\N	2690	423	1876-11-21
2809	1	1886-08-27	1908-06-14	\N	2691	501	1886-09-02
2810	1	1900-06-26	1914-01-21	\N	2509	612	1926-11-24
2811	1	1902-07-15	1925-05-13	\N	508	622	1905-07-27
2812	1	1914-07-27	1916-06-05	\N	492	749	1914-07-29
2813	1	1917-01-01	1921-11-02	\N	2692	774	1917-02-07
2814	1	1945-10-12	2001-08-03	\N	2693	1180	1945-10-16
2815	1	1960-05-16	1976-06-17	\N	2694	1392	1960-05-18
2816	1	1927-01-31	1934-05-24	\N	608	932	1927-02-09
2817	1	1926-02-20	1941-11-01	\N	616	924	1926-06-30
2818	1	1934-06-26	1949-04-20	\N	2695	1023	1934-07-11
2819	1	1941-07-04	1957-07-03	\N	1085	1117	1941-07-09
2820	1	1950-01-27	1965-01-11	\N	1177	1251	1950-03-01
2821	1	1957-08-22	1977-05-25	\N	2696	1347	1957-10-30
2822	1	1964-04-20	1968-01-20	\N	2697	1463	1964-07-01
2823	1	1911-07-03	1929-05-21	\N	2698	714	1929-11-06
2824	1	1961-10-06	2017-01-13	\N	1996	1419	1962-02-28
2825	1	1917-07-16	1927-10-24	\N	2699	793	1917-10-31
2826	1	1964-12-21	1969-02-19	\N	2700	1497	1964-12-23
2827	1	1966-06-13	1984-11-18	\N	2701	1544	1966-06-29
2828	1	1968-01-19	2001-04-03	\N	2702	1585	1968-02-21
2829	1	1970-09-22	1982-04-12	\N	2703	1624	1970-10-28
2830	1	1974-12-19	1995-10-09	\N	2704	1708	1975-01-22
2831	1	1975-01-10	2000-09-15	\N	2705	1715	1975-01-29
2832	1	1975-01-09	2005-04-26	\N	2706	1714	1975-01-21
2833	1	1978-05-16	2017-11-13	\N	2707	1800	1978-07-05
2834	1	1980-02-21	1990-01-07	\N	2708	1845	1980-02-27
2835	1	1981-05-18	1994-05-26	\N	2709	1858	1981-05-19
2836	1	1984-02-01	2000-01-13	\N	2710	1924	1984-02-02
2837	1	1987-10-05	1997-01-28	\N	2711	1972	1987-10-20
2838	1	1987-11-03	2016-12-20	\N	2712	1985	1987-11-11
2839	1	1996-01-17	\N	\N	2713	2152	1996-01-31
2840	1	1996-10-01	2009-03-06	\N	2714	2162	1996-10-16
2841	1	1850-01-22	1902-02-12	\N	457	285	1850-01-31
2842	1	1875-06-11	1881-07-04	\N	2715	409	1875-06-15
2843	1	1920-01-09	1948-11-04	\N	2716	850	1920-02-18
2844	1	1929-08-31	1948-09-10	\N	897	972	1929-11-06
2845	1	1936-01-17	1936-10-22	\N	751	1047	1937-11-17
2846	1	1943-07-05	1970-02-15	\N	2717	1138	1943-07-28
2847	1	1946-03-01	1969-06-16	\N	1047	1202	1946-03-13
2848	1	1953-02-13	1967-06-18	\N	2718	1292	1953-03-04
2849	1	1964-06-30	1989-06-22	\N	2719	1467	1964-07-01
2850	1	1965-05-17	1977-12-12	\N	2720	1523	1965-06-15
2851	1	1967-02-06	1991-06-27	\N	2721	1559	1967-02-15
2852	1	1969-10-28	1988-09-17	\N	2722	1605	1969-11-19
2853	1	1981-06-19	\N	\N	2723	1869	1981-06-23
2854	1	1987-11-05	2005-03-26	\N	2724	1987	1987-11-17
2855	1	1991-06-20	\N	\N	2725	2046	1991-06-25
2856	1	1998-07-25	\N	\N	2726	2284	1998-10-26
2857	1	2004-01-13	\N	\N	2727	2457	2004-01-13
2858	1	2004-06-02	\N	\N	2728	2460	2004-06-15
2859	1	2006-06-06	2016-06-12	\N	2729	2559	2006-06-22
2860	1	2007-10-15	\N	\N	2730	2594	2007-10-15
2861	1	2010-06-25	2012-04-24	\N	2731	2644	2010-06-29
2862	1	2011-01-17	\N	\N	2732	2712	2011-01-20
2863	1	2014-09-12	\N	\N	2733	2789	2014-10-28
2864	1	2013-09-19	\N	\N	2734	2776	2013-11-04
2865	1	2018-06-19	\N	\N	2735	2896	2018-06-26
2866	1	1964-12-19	2000-09-14	\N	1995	1495	1965-02-10
2867	1	1999-11-16	2001-08-03	\N	2693	2358	1999-11-17
2868	1	1881-11-24	1887-12-05	\N	2736	454	\N
2869	1	1998-08-03	\N	\N	2737	2297	1998-10-12
2870	1	1999-07-19	\N	\N	2738	2322	1999-11-03
2871	1	1945-09-17	1971-04-22	\N	2527	1177	1945-11-21
2872	1	1992-08-12	2017-11-21	\N	2739	2095	1992-11-02
2873	1	1996-04-03	2006-08-30	\N	2740	2156	1996-05-08
2874	1	1997-02-14	2017-04-26	\N	2741	2177	1997-02-26
2875	1	1997-10-03	\N	\N	2742	2225	1997-10-21
2876	1	1998-07-30	\N	\N	2743	2291	1998-10-21
2877	1	1999-07-21	\N	\N	2744	2327	1999-10-25
2878	1	2004-06-22	\N	\N	2745	2488	2004-07-20
2879	1	2005-06-16	2019-01-06	\N	2746	2518	2005-06-22
2880	1	2006-06-13	\N	\N	2747	2569	2006-07-25
2881	1	2007-12-10	\N	\N	2748	2597	2007-12-17
2882	1	2015-05-26	\N	\N	2749	2814	2015-05-28
2883	1	2010-07-12	\N	\N	2750	2662	2010-07-20
2884	1	2011-01-21	2017-01-18	\N	2751	2720	2011-01-25
2885	1	2014-09-15	\N	\N	2752	2790	2014-10-29
2886	1	2013-09-20	\N	\N	2753	2777	2013-11-05
2887	1	2019-10-14	\N	\N	2754	2924	2019-10-21
2888	1	1938-01-27	1958-08-15	\N	2755	1084	1938-02-09
2889	1	1919-05-16	1951-01-17	\N	2756	830	1919-05-28
2890	1	1925-06-29	1935-11-20	\N	2641	918	1926-02-17
2891	1	1997-10-01	2019-03-04	\N	2757	2221	1997-10-22
2892	1	1999-11-17	2005-12-03	\N	2758	2362	1999-11-23
2893	1	1803-10-26	1808-07-14	\N	2759	33	\N
2894	1	1861-10-21	1888-11-25	\N	2760	330	1889-04-01
2895	1	1881-05-24	1884-03-28	\N	2761	447	1881-06-20
2896	1	1892-04-07	1900-04-24	\N	2762	532	1892-06-13
2897	1	1822-02-04	1839-01-17	\N	2763	130	1822-02-07
2898	1	2011-05-26	\N	\N	2764	2740	\N
2899	1	1890-05-24	1892-01-14	\N	2765	521	1890-06-23
2900	1	1874-05-24	1942-01-16	\N	2766	408	1874-06-08
2901	1	1866-05-24	1900-07-30	\N	2767	341	1866-06-08
2902	1	1947-11-20	\N	\N	2768	1234	1948-07-21
2903	1	1899-10-16	1912-01-29	\N	453	604	1959-11-11
2904	1	1928-03-31	1974-06-10	\N	2769	942	1928-04-24
2905	1	1934-10-12	1942-08-25	\N	2770	1028	1934-11-07
2906	1	2018-07-16	\N	\N	2771	2908	\N
2907	1	1814-05-11	1852-09-14	\N	48	71	1814-06-28
2908	1	1937-03-08	1972-05-28	\N	2772	1062	\N
2909	1	1986-07-23	\N	\N	2773	1954	1987-02-11
2910	1	1920-06-03	1952-02-06	\N	2774	855	1920-06-23
2911	1	1961-07-12	1977-01-14	\N	2775	1417	1961-07-25
2912	1	1922-05-05	1930-03-19	\N	2776	882	1922-05-30
2913	1	1876-08-21	1881-04-19	\N	2777	421	1877-02-08
2914	1	1831-09-10	1834-05-04	\N	2778	177	1831-09-13
2915	1	1831-09-12	1859-12-22	\N	2779	193	1831-09-13
2916	1	1827-10-05	1833-03-06	\N	2780	156	1828-01-29
2917	1	1871-11-13	1902-02-12	\N	457	384	1872-02-06
2918	1	1885-07-13	1912-01-29	\N	453	480	1885-07-27
2919	1	1945-01-08	1955-05-02	\N	853	1151	1945-01-24
2920	1	1812-09-07	1820-04-03	\N	2781	67	1813-02-05
2921	1	1919-09-30	1927-10-07	\N	431	837	1919-10-29
2922	1	1837-08-12	1842-06-30	\N	2782	232	1837-11-20
2923	1	1905-12-22	1907-03-23	\N	2639	644	1906-02-13
2924	1	1917-12-20	1935-12-30	\N	609	798	1918-01-09
2925	1	1815-11-28	1823-11-17	\N	2783	98	1816-02-16
2926	1	1955-05-05	1972-07-27	\N	851	1318	1955-06-21
2927	1	1812-02-28	1852-09-14	\N	48	63	1814-06-28
2928	1	1999-06-19	\N	\N	2493	2311	\N
2929	1	1876-01-15	1899-05-13	\N	2784	416	1876-02-10
2930	1	1931-02-20	1941-08-12	\N	895	989	1931-02-25
2931	1	1801-06-26	1814-09-23	\N	2785	16	1801-06-29
2932	1	1911-07-03	1945-06-20	\N	494	713	1911-08-09
2933	1	1910-06-23	1972-05-28	\N	2772	691	1918-02-19
2934	1	1958-07-26	\N	\N	2786	1353	1970-02-11
2935	1	1801-11-27	1850-07-08	\N	31	2935	1801-12-15
2936	1	1812-09-07	1840-10-08	\N	49	2936	1812-11-28
2937	1	1815-11-22	1827-04-10	\N	76	2937	1816-03-20
2938	1	1817-02-13	1826-11-28	\N	116	2938	1825-06-03
2939	1	1831-09-12	1834-03-29	\N	195	2939	1831-09-15
2940	1	1841-12-08	1910-05-06	\N	232	2940	1863-02-05
2941	1	1866-05-24	1900-07-30	\N	2767	2941	1866-06-08
2942	1	1866-05-24	1900-07-30	\N	2767	2942	1866-06-08
2943	1	1822-02-04	1839-01-17	\N	2763	2943	1822-02-07
2944	1	1861-10-21	1888-11-25	\N	2760	2944	1889-04-01
2945	1	1805-11-20	1835-02-28	\N	23	2945	1806-01-21
2946	1	1801-06-18	1825-07-30	\N	34	2946	1801-10-30
2947	1	1822-02-04	1839-01-17	\N	2763	2947	1822-02-07
2948	1	1861-10-21	1888-11-25	\N	2760	2948	1889-04-01
2949	1	1801-06-22	1811-03-01	\N	37	2949	1801-06-29
2950	1	1801-06-26	1814-09-23	\N	2785	2950	1801-06-29
2951	1	1801-11-27	1843-04-21	\N	32	2951	1805-01-15
2952	1	1801-11-27	1850-07-08	\N	31	2952	1801-12-15
2953	1	1802-12-24	1811-05-29	\N	18	2953	1803-04-20
2954	1	1804-05-14	1839-05-16	\N	36	2954	1804-05-18
2955	1	1804-05-14	1839-05-16	\N	36	2955	1804-05-18
2956	1	1804-05-14	1839-05-16	\N	36	2956	1804-05-18
2957	1	1806-02-17	1818-07-31	\N	26	2957	1806-02-28
2958	1	1806-04-11	1807-11-14	\N	6	2958	1806-04-28
2959	1	1807-11-09	1843-06-16	\N	45	2959	1808-02-01
2960	1	1809-09-04	1852-09-14	\N	48	2960	1814-06-28
2961	1	1812-09-07	1820-04-03	\N	2781	2961	1813-02-05
2962	1	1812-09-07	1828-05-24	\N	77	2962	1812-11-28
2963	1	1812-09-07	1828-05-24	\N	77	2963	1812-11-28
2964	1	1813-02-24	1814-06-21	\N	71	2964	1816-03-22
2965	1	1814-05-11	1852-09-14	\N	48	2965	1814-06-28
2966	1	1815-11-24	1845-11-17	\N	74	2966	1816-02-01
2967	1	1815-11-25	1825-05-12	\N	50	2967	1818-01-27
2968	1	1815-11-27	1853-09-15	\N	78	2968	1816-02-01
2969	1	1815-11-30	1825-09-07	\N	109	2969	1816-02-02
2970	1	1815-12-01	1816-10-21	\N	30	2970	1816-05-06
2971	1	1817-02-13	1826-11-28	\N	116	2971	1825-06-03
2972	1	1821-07-07	1838-01-13	\N	110	2972	1821-07-09
2973	1	1821-07-17	1856-01-04	\N	114	2973	1822-02-05
2974	1	1821-07-17	1856-01-04	\N	114	2974	1822-02-05
2975	1	1821-07-18	1827-08-27	\N	113	2975	1822-02-05
2976	1	1823-07-08	1854-03-06	\N	100	2976	1823-07-16
2977	1	1826-06-30	1859-02-15	\N	156	2977	1826-11-28
2978	1	1826-12-19	1857-03-13	\N	119	2978	1829-02-05
2979	1	1827-10-05	1833-03-06	\N	2780	2979	1828-01-29
2980	1	1827-10-06	1860-11-07	\N	126	2980	1828-01-29
2981	1	1831-06-04	1842-03-20	\N	155	2981	1831-06-15
2982	1	1831-06-04	1842-03-20	\N	155	2982	1831-06-15
2983	1	1833-01-29	1842-01-29	\N	115	2983	1833-02-04
2984	1	1833-03-23	1840-07-28	\N	133	2984	1833-06-03
2985	1	1833-05-10	1846-01-08	\N	163	2985	1833-05-18
2986	1	1835-03-10	1845-07-21	\N	171	2986	1835-04-03
2987	1	1837-01-28	1840-06-22	\N	189	2987	1837-01-31
2988	1	1837-01-30	1846-09-05	\N	193	2988	1837-01-31
2989	1	1837-08-12	1842-06-30	\N	2782	2989	1837-11-20
2990	1	1838-06-30	1893-12-29	\N	192	2990	1838-07-03
2991	1	1841-08-16	1866-06-10	\N	229	2991	1841-08-24
2992	1	1844-10-22	1871-12-22	\N	228	2992	1845-02-04
2993	1	1846-07-06	1857-02-18	\N	268	2993	1847-02-01
2994	1	1847-09-18	1860-06-03	\N	175	2994	1847-11-23
2995	1	1850-06-11	1851-04-29	\N	177	2995	1851-07-11
2996	1	1857-04-11	1884-07-15	\N	247	2996	1857-06-05
2997	1	1860-02-17	1885-05-07	\N	267	2997	1860-03-01
2998	1	1868-07-25	1915-01-13	\N	341	2998	1868-12-15
2999	1	1801-11-27	1843-04-21	\N	32	2999	1805-01-15
3000	1	1876-01-14	1915-12-12	\N	343	3000	1876-02-10
3001	1	1881-05-24	1884-03-28	\N	2761	3001	1881-06-20
3002	1	1885-07-11	1922-10-19	\N	320	3002	1885-07-14
3003	1	1888-11-17	1902-02-12	\N	457	3003	1889-02-21
3004	1	1890-05-24	1892-01-14	\N	2765	3004	1890-06-23
3005	1	1892-05-24	1936-01-20	\N	454	3005	1892-06-17
3006	1	1892-08-22	1929-03-11	\N	458	3006	1893-01-31
3007	1	1901-11-09	1936-01-20	\N	454	3007	\N
3008	1	1874-04-02	1878-03-19	\N	342	3008	1874-04-30
3009	1	1911-07-03	1945-06-20	\N	494	3009	1911-08-09
3010	1	1915-05-15	1934-03-07	\N	2647	3010	1918-07-02
3011	1	1917-07-16	1927-10-24	\N	2699	3011	1917-10-31
3012	1	1917-07-17	1921-09-11	\N	710	3012	1917-07-25
3013	1	1917-07-18	1960-02-23	\N	675	3013	1918-03-06
3014	1	1920-06-03	1952-02-06	\N	2774	3014	1920-06-23
3015	1	1921-06-28	1925-03-20	\N	711	3015	1921-07-07
3016	1	1928-03-31	1974-06-10	\N	2769	3016	1928-04-24
3017	1	1889-07-29	1912-01-29	\N	453	3017	1890-02-13
3018	1	1901-02-11	1914-11-14	\N	436	3018	1901-02-14
3019	1	1914-07-27	1916-06-05	\N	492	3019	1914-07-29
3020	1	1914-07-27	1916-06-05	\N	492	3020	1914-07-29
3021	1	1922-05-05	1930-03-19	\N	2776	3021	1922-05-30
3022	1	1899-10-16	1912-01-29	\N	453	3022	1959-11-11
3023	1	1876-06-10	1904-11-15	\N	380	3023	1876-06-15
3024	1	1876-08-21	1881-04-19	\N	2777	3024	1877-02-08
3025	1	1878-09-27	1885-04-02	\N	288	3025	1878-12-06
3026	1	1880-05-04	1894-09-10	\N	357	3026	1880-05-27
3027	1	1881-05-24	1884-03-28	\N	2761	3027	1881-06-20
3028	1	1882-12-30	1895-05-04	\N	319	3028	1883-02-15
3029	1	1885-07-03	1887-01-12	\N	417	3029	1885-07-06
3030	1	1887-07-01	1900-04-19	\N	418	3030	1887-07-12
3031	1	1892-05-24	1936-01-20	\N	454	3031	1892-06-17
3032	1	1892-08-22	1906-10-30	\N	456	3032	1893-01-31
3033	1	1897-07-22	1909-03-16	\N	482	3033	1898-05-12
3034	1	1900-12-19	1904-11-28	\N	507	3034	1901-02-14
3035	1	1901-08-06	1917-01-29	\N	440	3035	1901-08-08
3036	1	1905-12-18	1923-03-06	\N	527	3036	1906-02-13
3037	1	1905-12-22	1907-03-23	\N	2639	3037	1906-02-13
3038	1	1911-07-03	1929-05-21	\N	2698	3038	1929-11-06
3039	1	1911-07-03	1929-05-21	\N	2698	3039	1929-11-06
3040	1	1911-07-05	1918-02-23	\N	409	3040	1911-08-01
3041	1	1911-07-06	1926-01-15	\N	594	3041	1911-07-25
3042	1	1915-02-22	1916-04-30	\N	539	3042	1915-03-02
3043	1	1917-01-03	1922-02-24	\N	641	3043	1917-02-07
3044	1	1917-07-16	1927-10-24	\N	2699	3044	1917-10-31
3045	1	1917-07-16	1957-01-16	\N	708	3045	1918-07-17
3046	1	1917-07-17	1921-09-11	\N	710	3046	1917-07-25
3047	1	1917-12-20	1935-12-30	\N	609	3047	1918-01-09
3048	1	1919-09-27	1936-03-11	\N	684	3048	1919-11-05
3049	1	1919-09-27	1936-03-11	\N	684	3049	1919-11-05
3050	1	1919-09-29	1928-01-29	\N	719	3050	1919-11-12
3051	1	1919-09-29	1928-01-29	\N	719	3051	1919-11-12
3052	1	1920-02-02	1942-02-13	\N	709	3052	1920-02-11
3053	1	1920-06-03	1952-02-06	\N	2774	3053	1920-06-23
3054	1	1922-11-28	1930-09-30	\N	673	3054	1922-11-30
3055	1	1925-02-09	1928-02-15	\N	784	3055	1925-02-17
3056	1	1925-06-29	1935-11-20	\N	2641	3056	1926-02-17
3057	1	1928-03-31	1974-06-10	\N	2769	3057	1928-04-24
3058	1	1929-06-20	1932-05-23	\N	588	3058	1929-06-26
3059	1	1801-06-19	1814-05-17	\N	35	3059	1801-10-29
3060	1	1809-07-19	1847-12-26	\N	69	3060	1810-01-23
3061	1	1874-05-24	1942-01-16	\N	2766	3061	1874-06-08
3062	1	1911-11-02	1925-03-20	\N	711	3062	1912-02-21
3063	1	1947-10-18	1979-08-27	\N	986	3063	1948-07-21
3064	1	1861-10-21	1888-11-25	\N	2760	3064	1889-04-01
3065	1	1812-09-07	1831-04-07	\N	72	3065	1812-11-24
3066	1	1821-07-17	1841-01-05	\N	83	3066	1822-02-05
3067	1	1839-12-21	1849-01-01	\N	226	3067	1843-02-02
3068	1	1861-07-30	1878-05-28	\N	265	3068	1861-07-30
3069	1	1898-01-19	1921-12-11	\N	386	3069	1898-02-08
3070	1	1917-07-18	1960-02-23	\N	675	3070	1918-03-06
3071	1	1929-07-10	1937-09-28	\N	790	3071	1929-07-24
3072	1	1911-11-02	1925-03-20	\N	711	3072	1912-02-21
3073	1	1815-11-29	1840-03-14	\N	112	3073	1816-06-06
3074	1	1831-09-10	1834-05-04	\N	2778	3074	1831-09-13
3075	1	1841-08-16	1866-06-10	\N	229	3075	1841-08-24
3076	1	1871-11-13	1902-02-12	\N	457	3076	1872-02-06
3077	1	1880-04-28	1891-11-24	\N	379	3077	1881-01-06
3078	1	1895-07-16	1928-06-13	\N	468	3078	1896-02-11
3079	1	1919-09-30	1927-10-07	\N	431	3079	1919-10-29
3080	1	1931-02-20	1941-08-12	\N	895	3080	1931-02-25
3081	1	1934-10-12	1942-08-25	\N	2770	3081	1934-11-07
3082	1	1937-06-08	1947-12-14	\N	869	3082	1937-06-09
3083	1	1945-01-08	1955-05-02	\N	853	3083	1945-01-24
3084	1	1945-02-12	1945-03-26	\N	940	3084	1945-06-13
3085	1	1947-05-01	1950-05-24	\N	932	3085	1947-06-04
3086	1	1947-11-20	\N	\N	2768	3086	1948-07-21
3087	1	1951-12-24	1957-08-16	\N	954	3087	1952-01-30
3088	1	1952-03-11	1969-06-16	\N	1047	3088	1952-03-12
3089	1	1955-05-05	1972-07-27	\N	851	3089	1955-06-21
3090	1	1955-12-16	1967-10-08	\N	1077	3090	1956-01-25
3091	1	1956-01-09	1964-12-14	\N	1056	3091	1956-02-01
3092	1	1961-07-12	1977-01-14	\N	2775	3092	1961-07-25
3093	1	1961-10-06	2017-01-13	\N	1996	3093	1962-02-28
3094	1	1962-07-20	1967-01-27	\N	1069	3094	1962-07-25
3095	1	1963-01-30	1965-01-11	\N	1177	3095	1963-01-31
3096	1	1984-02-24	1986-12-29	\N	1636	3096	1984-02-29
3097	1	1986-07-23	\N	\N	2773	3097	1987-02-11
3098	1	1999-06-19	\N	\N	2493	3098	\N
3099	1	2011-05-26	\N	\N	2764	3099	\N
3100	1	2018-07-16	\N	\N	2771	3100	\N
3101	1	1876-01-13	1903-09-27	\N	339	3101	1904-07-11
3102	1	1934-10-12	1942-08-25	\N	2770	3102	1934-11-07
3103	1	1947-11-20	\N	\N	2768	3103	1948-07-21
3104	1	1958-07-26	\N	\N	2786	3104	1970-02-11
3105	1	1986-07-23	\N	\N	2773	3105	1987-02-11
3106	1	2011-05-26	\N	\N	2764	3106	\N
3107	1	2018-07-16	\N	\N	2771	3107	\N
3108	1	1876-01-15	1899-05-13	\N	2784	3108	1876-02-10
3109	2	1936-05-14	1984-07-17	\N	2787	840	\N
3110	3	1984-07-17	2014-10-03	\N	2788	840	\N
3111	4	2014-10-03	\N	\N	2789	840	\N
3112	2	1930-03-19	1945-01-14	\N	2790	882	\N
3113	3	1945-01-14	1968-11-27	\N	2791	882	\N
3114	4	1968-11-27	2003-06-27	\N	2792	882	\N
3115	5	2003-06-27	\N	\N	2793	882	\N
3116	2	1908-07-08	1916-09-30	\N	2794	542	\N
3117	3	1916-09-30	1918-03-13	\N	2795	542	\N
3118	4	1918-03-13	1929-11-14	\N	2796	542	\N
3119	5	1929-11-14	1937-03-03	\N	2797	542	\N
3120	6	1937-03-03	1940-02-08	\N	2798	542	\N
3121	7	1940-02-08	1940-09-14	\N	2799	542	\N
3122	2	1868-05-07	1886-01-03	\N	2800	324	\N
3123	3	1886-01-03	1927-05-24	\N	2801	324	\N
3124	4	1927-05-24	1967-06-20	\N	2802	324	\N
3125	5	1967-06-20	\N	\N	2803	324	\N
3126	2	1899-05-13	1926-05-08	\N	2804	3108	\N
3127	3	1926-05-08	1953-05-16	\N	2805	3108	\N
3128	4	1953-05-16	1987-06-03	\N	2806	3108	\N
3129	5	1987-06-03	\N	\N	2807	3108	\N
3130	2	1909-01-16	1919-12-27	\N	2808	544	\N
3131	3	1919-12-27	1980-07-22	\N	2809	544	\N
3132	4	1980-07-22	2009-04-02	\N	2810	544	\N
3133	5	2009-04-02	\N	\N	2811	544	\N
3134	2	1916-06-05	1937-03-27	\N	2812	3019	\N
3135	3	1937-03-27	2011-12-16	\N	2813	3019	\N
3136	2	1909-02-01	1962-05-28	\N	2814	590	\N
3137	3	1962-05-28	2013-05-30	\N	2815	590	\N
3138	4	2013-05-30	\N	\N	2816	590	\N
3139	2	1893-08-07	1943-04-26	\N	2817	431	\N
3140	3	1943-04-26	1977-03-21	\N	2818	431	\N
3141	2	1888-11-25	1893-11-24	\N	2819	330	\N
3142	3	1895-02-25	1962-05-20	\N	2820	330	\N
3143	4	1962-05-20	1989-12-13	\N	2821	330	\N
3144	5	1989-12-13	\N	\N	2822	330	\N
3145	3	2014-03-14	\N	\N	2823	1122	\N
3146	3	2001-12-31	2020-08-01	\N	2824	1168	\N
3147	4	2020-08-01	\N	\N	2825	1168	\N
3148	2	1934-01-23	1953-05-23	\N	2826	705	\N
3149	3	1953-05-23	2003-02-04	\N	2827	705	\N
3150	4	2003-02-04	\N	Not on Peerage Roll	2828	705	\N
3151	2	1895-02-25	1929-02-20	\N	2829	394	\N
3152	3	1929-02-20	1957-10-04	\N	2830	394	\N
3153	4	1957-10-04	\N	Check date of death	2831	394	\N
3154	5	\N	\N	Add date of succession	2832	394	\N
3155	2	1934-03-07	1965-01-06	On Peerages a-z list date of Patent is wrong should be 04-01-1916	2833	753	\N
3156	3	1965-01-06	1972-04-16	\N	2834	753	\N
3157	4	1972-04-16	1974-09-13	\N	2835	753	\N
3158	5	1974-09-13	\N	Check date of death	2836	753	\N
3159	6	\N	2002-08-19	Add date of succession	2837	753	\N
3160	7	2002-08-19	2020-03-12	\N	2838	753	\N
3161	8	2020-03-12	\N	\N	2839	753	\N
3162	2	1915-12-02	1927-10-13	\N	2840	414	\N
3163	3	1927-10-13	1938-01-10	\N	2841	414	\N
3164	4	1938-01-10	1954-03-30	\N	2842	414	\N
3165	5	1954-03-30	2000-02-23	\N	2843	414	\N
3166	6	2000-02-23	\N	\N	2844	414	\N
3167	1	1706-12-30	\N	\N	2845	3109	\N
3168	1	1706-12-30	\N	\N	2845	3110	\N
3169	1	1706-12-27	\N	\N	2846	3111	\N
3170	1	1706-12-27	\N	\N	2846	3112	\N
3171	1	1706-12-26	\N	\N	2847	3113	\N
3172	1	1706-12-26	\N	\N	2847	3114	\N
3173	1	1706-12-24	\N	\N	2848	3115	\N
3174	1	1706-12-24	\N	\N	2848	3116	\N
3175	1	1706-12-23	\N	\N	2849	3117	\N
3176	1	1706-12-23	\N	\N	2849	3118	\N
3177	1	1706-12-23	\N	\N	2850	3119	\N
3178	1	1706-12-21	\N	\N	2851	3120	\N
3179	1	1706-12-16	\N	\N	2852	3121	\N
3180	1	1706-12-14	\N	\N	2853	3122	\N
3181	1	1800-12-29	\N	\N	2854	3123	\N
3182	1	1800-12-29	\N	\N	2854	3124	\N
3183	1	1800-12-27	\N	\N	2855	3125	\N
3184	1	1800-12-27	\N	\N	2855	3126	\N
3185	1	1800-06-16	\N	\N	2856	3127	\N
3186	1	1799-09-24	\N	\N	2857	3128	\N
3189	1	1868-12-21	\N	\N	2858	3131	\N
3190	1	1868-08-10	\N	\N	2859	3132	\N
3191	1	1868-08-10	\N	\N	2859	3133	\N
3193	1	1855-05-14	\N	\N	2860	3135	\N
3195	1	1848-07-10	\N	\N	2861	3137	\N
3196	1	1706-12-14	\N	\N	2862	3138	\N
3197	1	1706-12-14	\N	\N	2862	3139	\N
3198	1	1706-12-14	\N	\N	2862	3140	\N
3199	1	1706-12-09	\N	\N	2863	3141	\N
3200	1	1706-12-09	\N	\N	2863	3142	\N
3201	1	1706-12-09	\N	\N	2863	3143	\N
3202	1	1706-12-09	\N	\N	2863	3144	\N
3203	1	1706-12-09	\N	\N	2863	3145	\N
3204	1	1705-11-26	\N	\N	2864	3146	\N
3205	1	1705-11-26	\N	\N	2864	3147	\N
3206	1	1705-04-14	\N	\N	2865	3148	\N
3207	1	1705-04-14	\N	\N	2865	3149	\N
3208	1	1703-03-29	\N	\N	2866	3150	\N
3209	1	1703-03-29	\N	\N	2866	3151	\N
3210	1	1703-03-24	\N	\N	2867	3152	\N
3211	1	1703-03-23	\N	\N	2868	3153	\N
3212	1	1703-03-17	\N	\N	2869	3154	\N
3213	1	1703-03-16	\N	\N	2870	3155	\N
3214	1	1799-04-24	\N	\N	2871	3156	\N
3215	1	1799-04-24	\N	\N	2871	3157	\N
3216	1	1799-04-24	\N	\N	2872	3158	\N
3217	1	1799-04-24	\N	\N	2872	3159	\N
3219	1	1797-11-30	\N	\N	2873	3161	\N
3220	1	1797-10-30	\N	\N	2874	3162	\N
3221	1	1797-10-30	\N	\N	2874	3163	\N
3222	1	1797-10-26	\N	\N	2875	3164	\N
3223	1	1797-10-26	\N	\N	2876	3165	\N
3224	1	1797-10-26	\N	\N	2877	3166	\N
3225	1	1797-10-26	\N	\N	2878	3167	\N
3226	1	1845-06-03	\N	\N	2879	3168	\N
3227	1	1836-05-04	\N	\N	2880	3169	\N
3230	1	1831-05-28	\N	\N	2881	3172	\N
3231	1	1831-01-06	\N	\N	2882	3173	\N
3232	1	1831-01-06	\N	\N	2882	3174	\N
3233	1	1827-06-23	\N	\N	2883	3175	\N
3234	1	1827-06-23	\N	\N	2883	3176	\N
3235	1	1826-06-27	\N	\N	2884	3177	\N
3187	1	1799-07-18	1838-01-13	\N	110	3129	\N
3188	1	1898-11-11	1925-03-20	\N	711	3130	\N
3192	1	1863-12-14	1873-12-07	\N	279	3134	\N
3194	1	1852-02-11	1887-07-29	\N	278	3136	\N
3218	1	1798-11-06	1805-10-21	\N	3	3160	\N
3228	1	1834-06-13	1856-06-02	\N	185	3170	\N
3229	1	1831-09-14	1840-04-26	\N	2633	3171	\N
\.


--
-- Name: peerage_holdings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerage_holdings_id_seq', 3235, true);


--
-- Data for Name: peerage_types; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerage_types (name, id) FROM stdin;
Life peerage: Appellate Jurisdiction Act 1876	1
Hereditary peerage	2
Hereditary peerage (already peer of Ireland)	3
Hereditary peerage (already peer of Scotland)	4
Life peerage: Life Peerages Act 1958	5
Life peerage: already a hereditary peer	6
Promotion	7
New hereditary peerage: not a promotion	8
\.


--
-- Name: peerage_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerage_types_id_seq', 8, true);


--
-- Data for Name: peerages; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY peerages (title, territorial_designation, extinct_on, last_number, notes, id, peerage_type_id, rank_id, wikidata_id, of_title, special_remainder_id, letters_patent_id, kingdom_id, letter_id) FROM stdin;
Powis	in the County of Montgomery	\N	\N	7th E died 13 Aug 1993	34	7	6	\N	t	\N	31	5	17
Romney	\N	\N	\N	\N	13	7	6	\N	t	\N	32	5	19
Abercromby	of Aboukir and of Tullibody in the County of Clackmannan	1924-10-07	5	SR to heirs male by late husband	10	2	8	\N	f	3	33	5	2
Exeter	\N	\N	\N	\N	5	7	9	\N	t	\N	34	5	6
Sandys	of Ombersley in the County of Worcester	\N	\N	SR to younger sons before eldest	28	2	8	\N	f	1	35	5	20
Rivers	of Sudeley Castle in the County of Gloucester	1880-03-31	6	SR to (1) Wm Augustus Pitt (brother) & h m of b; (2) Wm Horace Beckford (son of deceased dau) & h m of b	26	8	8	\N	f	1	36	5	19
Keith	of Banheath in the County of Dumbarton	1867-11-11	2	SR to dau; cr V Keith 1814	32	8	8	\N	f	2	37	5	12
Butler	of Lanthony in the County of Monmouth	1820-08-10	1	cr M of Ormonde (I) 1816	3	3	8	\N	f	\N	1	5	3
Barham	of Barham Court and Teston in the County of Kent	\N	\N	SR to dau; 3rd L cr E of Gainsborough 1841	37	2	8	\N	f	2	38	5	3
Rosslyn	in the County of MidLothian	\N	\N	SR to heirs male of his sister Janet Erskine deceased	6	7	6	\N	t	1	40	5	19
Carysfort	of the Hundred of Norman Cross in the County of Huntingdon	1909-09-04	5	\N	4	3	8	\N	f	\N	2	5	4
Sussex	\N	1843-04-21	1	\N	20	2	4	\N	t	\N	27	5	20
Nelson	of the Nile and of Burnham Thorpe in the County of Norfolk	1805-10-21	1	cr L Nelson with special remainder 18 August 1801	8	7	12	\N	f	\N	3	5	15
Alvanley	of Alvanley in the County Palatine of Chester	1857-06-24	3	\N	9	2	8	\N	f	\N	4	5	2
Grey	of Howick in the County of Northumberland	\N	\N	cr E Grey 1806	15	2	8	\N	f	\N	5	5	8
Saint Helens	of Saint Helens, Isle of Wight and County of Southampton	1839-02-19	1	\N	17	3	8	\N	f	\N	6	5	20
Thomond	of Taplow Court in the County of Buckingham	1808-02-10	1	\N	19	3	8	\N	f	\N	7	5	21
Keith	of Stonehaven Marischal in the County of Kincardine	1823-03-10	1	cr L Keith (SR) 1803, V Keith 1814	22	3	8	\N	f	\N	8	5	12
Hutchinson	of Alexandria and of Knocklofty in the County of Tipperary	1832-06-29	1	succ as 2nd E of Donoughmore (I) 1825	23	2	8	\N	f	\N	9	5	9
Redesdale	of Redesdale in the County of Northumberland	1886-05-02	2	2nd L cr E of Redesdale 1877	24	2	8	\N	f	\N	10	5	19
Curzon	of Penn in the County of Buckingham	\N	\N	2nd V cr E Howe 1821	25	7	12	\N	f	\N	11	5	4
Ellenborough	of Ellenborough in the County of Cumberland	\N	\N	2nd L cr E of Ellenborough 1844,ext 1871	27	2	8	\N	f	\N	12	5	6
Arden	of Arden in the County of Warwick	1929-01-10	5	2nd L succ 1841 as 6th E of Egmont (I)\nIrish barony (also Arden) survived until 2011	29	3	8	\N	f	\N	13	5	2
Sheffield	of Sheffield in the County of York	1909-04-21	3	cr E of Sheffield (I) 1816	30	3	8	\N	f	\N	14	5	20
Melville	of Melville in the County of Edinburgh	\N	\N	\N	31	2	12	\N	f	\N	15	5	14
Lake	of Delhi and Laswary and of Aston Clinton in the County of Buckingham	1848-06-24	3	cr V Lake 1807	35	2	8	\N	f	\N	16	5	13
Sidmouth	of Sidmouth in the County of Devon	\N	\N	\N	36	2	12	\N	f	\N	17	5	20
Exmouth	of Canonteign in the County of Devon	\N	\N	cr V Exmouth 1816	78	2	8	\N	f	\N	18	5	6
Collingwood	of Coldbourne and Hethpoole in the County of Northumberland	1810-03-07	1	\N	39	2	8	\N	f	\N	19	5	4
Erskine	of Restormel Castle in the County of Cornwall	\N	\N	7th L succ 1960 as 16th E of Buchan	40	2	8	\N	f	\N	20	5	6
Anson	of Shugborough and Orgrave in the County of Stafford	\N	\N	2nd V cr E of Lichfield 1831	41	2	12	\N	f	\N	21	5	2
Monteagle	of Westport in the County of Mayo	\N	\N	\N	42	3	8	\N	f	\N	22	5	14
Loftus	of Long Loftus in the County of York	\N	\N	\N	2	3	8	\N	f	\N	23	5	13
Crewe	of Crewe in the County Palatine of Chester	1894-01-03	3	\N	46	2	8	\N	f	\N	24	5	4
Beauchamp	of Powyke in the County of Worcester	1979-01-03	8	cr E Beauchamp 1815	47	2	8	\N	f	\N	25	5	3
Cambridge	\N	1904-03-17	2	\N	21	2	4	\N	t	\N	26	5	4
Onslow	of Onslow in the County of Salop	\N	\N	had been cr 1st L Cranley 1776 before succeeding as 4th L Onslow	12	7	6	Q1277380	t	\N	30	5	16
Chichester	\N	\N	\N	\N	14	7	6	\N	t	\N	28	5	4
Mulgrave	\N	\N	\N	2nd E cr M of Normanby 1838	66	7	6	\N	t	\N	76	5	14
Orford	\N	1931-09-27	5	\N	50	7	6	\N	t	\N	77	5	16
Verulam	\N	\N	\N	Old title: also 2nd L Verulam (GB)	95	7	6	\N	t	\N	78	5	23
Anglesey	\N	\N	\N	\N	82	7	9	\N	t	\N	79	5	2
Cholmondeley	in the County Palatine of Chester	\N	\N	?th M died 13 March 1990	94	7	9	\N	t	\N	80	5	4
Northampton	\N	\N	\N	\N	64	7	9	\N	t	\N	81	5	15
Wellington	in the County of Somerset	\N	\N	cr D of Wellington 1814	68	7	9	\N	t	\N	82	5	24
Hopetoun	of Hopetoun in the County of Linlithgow	\N	\N	SR to heirs of father; 5th L cr M of Linlithgow	60	4	8	\N	f	1	83	5	9
Manvers	\N	1955-02-13	6	\N	49	7	6	\N	f	\N	41	5	14
Lonsdale	in the County of Westmorland	\N	\N	\N	55	7	6	\N	t	\N	74	5	13
Grey	\N	\N	\N	\N	51	7	6	\N	f	\N	42	5	8
Ailsa	of Ailsa in the County of Ayr	\N	\N	cr M of Ailsa 1831	52	4	8	\N	f	\N	43	5	2
Gardner	of Uttoxeter in the County of Stafford	\N	\N	dormant on death of 2nd L on 2 Nov 1883	54	3	8	\N	f	\N	45	5	8
Manners	of Foston in the County of Sutton	\N	\N	\N	56	2	8	\N	f	\N	46	5	14
Lake	of Delhi and Laswary and of Aston Clinton in the County of Buckingham	1848-06-24	3	\N	57	7	12	\N	f	\N	47	5	13
Cathcart	of Cathcart in the County of Renfrew	\N	\N	cr E Cathcart 1814	58	4	12	\N	f	\N	48	5	4
Gambier	of Iver in the County of Bucks	1833-04-19	1	\N	59	2	8	\N	f	\N	49	5	8
Wellington	of Talavera and of Wellington in the County of Somerset	\N	\N	cr E of Wellington 28 Feb 1812	62	2	12	\N	f	\N	50	5	24
Camden	\N	\N	\N	\N	65	7	9	\N	f	\N	51	5	4
Whitworth	of Adbaston in the County of Stafford	1825-05-12	1	cr E Whitworth 1815	70	3	12	\N	f	\N	52	5	24
Niddry	of Niddry in the County of Linlithgow	\N	\N	succ as L Hopetoun etc 1817; 4th L cr M of Linlithgow	72	2	8	\N	f	\N	53	5	15
Lynedoch	of Balgowan in the County of Perth	1843-12-18	1	\N	73	2	8	\N	f	\N	54	5	13
Combermere	of Combermere in the County Palatine of Chester	\N	\N	cr V Combermere 1827	74	2	8	\N	f	\N	55	5	4
Hill	of Almaraz and of Hawkestone in the County of Salop	1842-12-10	1	further grant (SR) 1816; cr V Hill 1842	75	2	8	\N	f	\N	56	5	9
Beresford	of Albuera and of Dungarvan in the County of Waterford	1854-01-08	1	cr V Beresford 1823	76	2	8	\N	f	\N	57	5	3
Keith	\N	1823-03-10	1	\N	77	7	12	\N	f	\N	58	5	12
Cathcart	\N	\N	\N	\N	80	7	6	\N	f	\N	60	5	4
Gordon	of Aberdeen in the County of Aberdeen	\N	\N	4th V cr M of Aberdeen and Temair	81	4	12	\N	f	\N	61	5	8
Trench	of Garbally in the County of Galway	\N	\N	cr V Clancarty 1823	83	3	8	\N	f	\N	62	5	21
Dalhousie	of Dalhousie Castle in the County of Edinburgh	1860-12-22	2	2nd L cr M of Dalhousie 1849	85	4	8	\N	f	\N	64	5	5
Meldrum	of Morven in the County of Aberdeen	\N	\N	succ as 9th M of Huntly (S) 1836	86	4	8	\N	f	\N	65	5	14
Ross	of Hawkhead in the County of Renfrew	1890-04-23	3	\N	87	4	8	\N	f	\N	66	5	19
Grinstead	of Grinstead in the County of Wilts	\N	\N	\N	88	3	8	\N	f	\N	67	5	8
Foxford	of Stackpole Court in the County of Clare	\N	\N	\N	89	3	8	\N	f	\N	68	5	7
Churchill	of Whichwood in the County of Oxford	\N	\N	3rd L cr V Churchill 1902	90	2	8	\N	f	\N	69	5	4
Melbourne	of Melbourne in the County of Derby	1853-01-29	2	\N	91	3	8	\N	f	\N	70	5	14
Lauderdale	of Thirlestone in the County of Berwick	1863-03-22	3	\N	44	4	8	\N	f	\N	71	5	13
Whitworth	\N	1825-05-12	1	\N	96	7	6	\N	f	\N	72	5	24
Harrowby	in the County of Lincoln	\N	\N	\N	61	7	6	\N	t	\N	73	5	9
Minto	in the County of Roxburgh	\N	\N	\N	69	7	6	\N	t	\N	75	5	14
Morley	in the County of Devon	\N	\N	\N	99	7	6	\N	t	\N	117	5	14
Stradbroke	in the County of Suffolk	\N	\N	\N	128	7	6	\N	t	\N	118	5	20
Ailesbury	in the County of Buckingham	\N	\N	\N	112	7	9	\N	t	\N	119	5	2
Cleveland	\N	1891-08-21	4	cr D of Cleveland 1833	155	7	9	\N	t	\N	120	5	4
De Grey	of Wrest in the County of Bedford	1923-09-22	4	SR to sister & her male issue; 3rd E cr M of Ripon 1871	103	7	6	\N	f	2	122	5	5
Ormonde	of Lanthony in the County of Monmouth	1997-10-25	7	SR to brother; cr M of Ormonde (I) 1825	116	3	8	\N	f	1	123	5	16
Brownlow	\N	1921-03-17	3	\N	97	7	6	\N	f	\N	84	5	3
Vane	\N	\N	\N	SR to h m of b lawfully begotten by his present wife Frances Ann; 2nd E succ as 5th M of Londonderry 1872	133	8	6	\N	f	3	124	5	23
Rayleigh	of Terling Place in the County of Essex	\N	\N	SR to heirs male by her husband	129	2	8	\N	f	3	125	5	19
Beauchamp	\N	1979-01-03	8	\N	101	7	6	\N	f	\N	85	5	3
Eldon	in the County Palatine of Durham	\N	\N	had been cr L Eldon 1799	108	7	6	\N	t	\N	115	5	6
Prudhoe	of Prudhoe Castle in the County of Northumberland	1865-02-12	1	succ as 4th D of Northumberland 1847	104	2	8	\N	f	\N	86	5	17
Exmouth	of Canonteign in the County of Devon	\N	\N	\N	105	7	12	\N	f	\N	87	5	6
Colchester	of Colchester in the County of Essex	1919-02-26	3	\N	107	2	8	\N	f	\N	88	5	4
Howe	\N	\N	\N	\N	111	7	6	\N	f	\N	89	5	9
Somers	\N	1883-09-26	3	\N	113	7	6	\N	f	\N	90	5	20
Ker	of Kersheugh in the County of Roxburgh	\N	\N	\N	114	4	8	\N	f	\N	91	5	12
Minster	of Minster Abbey in the County of Kent	\N	\N	\N	115	3	8	\N	f	\N	92	5	14
Wemyss	of Wemyss in the County of Fife	\N	\N	\N	117	4	8	\N	f	\N	93	5	24
Clanbrassill	of Hyde Hall in the County of Hertford and Dundalk in the County of Louth	1897-07-03	3	\N	118	3	8	\N	f	\N	94	5	4
Kingston	of Mitchelstown in the County of Cork	1869-09-08	3	\N	119	3	8	\N	f	\N	95	5	12
Silchester	of Silchester in the County of Southampton	\N	\N	\N	120	3	8	\N	f	\N	96	5	20
Glenlyon	of Glenlyon in the County of Perth	1957-05-08	5	2nd L succ 1846 as 6th D of Atholl	121	2	8	\N	f	\N	97	5	8
Maryborough	of Maryborough in the Queen's County	1863-07-25	3	succ 1842 as 3rd E of Mornington (I)	122	2	8	\N	f	\N	98	5	14
Oriel	of Ferrard in the County of Louth	\N	\N	wife cr Vss Ferrard (I); 2nd L succ her 1824; 3rd L succ his mother 1831 as V Massereene (I); ?th L died 27 Dec 1992	123	2	8	\N	f	\N	99	5	16
Stowell	of Stowell Park in the County of Gloucester	1836-01-28	1	bro of E of Eldon	124	2	8	\N	f	\N	100	5	20
Delamere	of Vale Royal in the County Palatine of Chester	\N	\N	\N	126	2	8	\N	f	\N	102	5	5
Forester	of Willey Park in the County of Salop	\N	\N	\N	127	2	8	\N	f	\N	103	5	7
Bexley	of Bexley in the County of Kent	1851-02-08	1	\N	131	2	8	\N	f	\N	104	5	3
Beresford	of Beresford in the County of Stafford	1854-01-08	1	\N	132	7	12	\N	f	\N	105	5	3
Clancarty	of the County of Cork	\N	\N	had been cr L Trench 1815	134	8	12	\N	f	\N	106	5	4
Gifford	of Saint Leonard in the County of Devon	\N	\N	\N	135	2	8	\N	f	\N	107	5	8
Granville	of Stone Park in the County of Stafford	\N	\N	cr E Granville 1833	93	2	12	\N	f	\N	108	5	8
Tadcaster	of Tadcaster in the County of York	1846-08-21	1	\N	138	3	8	\N	f	\N	109	5	21
Somerhill	of Somerhill in the County of Kent	1916-04-12	2	\N	139	3	8	\N	f	\N	110	5	20
Wigan	of Haigh Hall in the County Palatine of Lancaster	\N	\N	\N	140	4	8	\N	f	\N	111	5	24
Farnborough	of Bromley Hill Place in the County of Kent	1838-01-17	1	\N	142	2	8	\N	f	\N	112	5	7
de Tabley	of Tabley House in the County Palatine of Chester	1895-11-22	3	\N	143	2	8	\N	f	\N	113	5	5
Bradford	in the County of Salop	\N	\N	\N	100	7	6	\N	t	\N	114	5	3
Falmouth	in the County of Cornwall	1852-08-29	2	\N	109	7	6	\N	t	\N	116	5	7
Munster	\N	2000-12-30	7	SR to brothers	169	2	6	\N	t	1	167	5	14
Wharncliffe	of Wortley in the County of York	\N	\N	3rd L cr E of Wharncliffe 1876	144	2	8	\N	f	\N	126	5	24
Feversham	of Duncombe Place in the County of York	\N	\N	3rd L cr E of Feversham 1868 (ext(2) 1963)	145	2	8	\N	f	\N	127	5	7
Ailsa	of the Isle of Ailsa in the County of Ayr	\N	\N	7th M died 7 April 1994	176	7	9	\N	t	\N	165	5	2
Amherst	of Arracan in the East Indies	1993-03-04	5	\N	147	7	6	\N	f	\N	128	5	2
Lyndhurst	of Lyndhurst in the County of Southampton	1863-10-12	1	\N	149	2	8	\N	f	\N	130	5	13
Goderich	of Nocton in the County of Lincoln	1923-09-22	3	cr E of Ripon 1833	150	2	12	\N	f	\N	131	5	8
Fife	of the County of Fife	1857-03-09	1	\N	151	3	8	\N	f	\N	132	5	7
Tenterden	of Hendon in the County of Middlesex	1939-09-16	4	\N	152	2	8	\N	f	\N	133	5	21
Plunket	of Newtown in the County of Cork	\N	\N	\N	153	2	8	\N	f	\N	134	5	17
Melros	of Tynninghame in the County of Haddington	1858-12-01	1	succ father as 9th E of Haddington (S) 17 March 1828	154	2	8	\N	f	\N	135	5	14
Cawdor	of Castle Martin in the County of Pembroke	\N	\N	6th E died 20 June 1993	157	7	6	\N	f	\N	136	5	4
Cowley	of Wellesley in the County of Somerset	\N	\N	2nd L cr E Cowley 1857	158	2	8	\N	f	\N	137	5	4
Stuart de Rothesay	of the Isle of Bute	1845-11-06	1	\N	160	2	8	\N	f	\N	138	5	20
Heytesbury	of Heytesbury in the County of Wilts	\N	\N	\N	161	2	8	\N	f	\N	139	5	9
Clanwilliam	of Clanwilliam in the County of Tipperary	\N	\N	\N	163	3	8	\N	f	\N	141	5	4
Skelmersdale	of Skelmersdale in the County Palatine of Lancaster	\N	\N	2nd L cr E of Lathom 1880 (ext(3) 1930)	165	2	8	\N	f	\N	143	5	20
Wallace	of Knaresdale in the County of Northumberland	1844-02-23	1	\N	166	2	8	\N	f	\N	144	5	24
Wynford	of Wynford Eagle in the County of Dorset	\N	\N	\N	167	2	8	\N	f	\N	145	5	24
Brougham and Vaux	of Brougham in the County of Westmorland	1868-05-07	1	further creation (SR) 1860	168	2	8	\N	f	\N	146	5	3
Kilmarnock	of Kilmarnock in the County of Ayr	\N	\N	\N	170	4	8	\N	f	\N	147	5	12
Sefton	of Croxteth in the County Palatine of Lancaster	1972-04-13	6	\N	172	3	8	\N	f	\N	148	5	20
Clements	of Kilmacrenan in the County of Donegal	1952-06-09	4	\N	173	3	8	\N	f	\N	149	5	4
Rossie	of Rossie in the County of Perth	1878-01-07	1	further cr L Kinnaird 1860 with SR	174	4	8	\N	f	\N	150	5	19
Dover	of Dover in the County of Kent	1899-09-10	4	2nd L succ as 3rd V Clifden (I) 1836	175	2	8	\N	f	\N	151	5	5
Kenlis	of Kenlis or Kells in the County of Meath	\N	\N	\N	178	3	8	\N	f	\N	152	5	12
Chaworth	of Eaton Hall in the County of Hereford	\N	\N	\N	179	3	8	\N	f	\N	153	5	4
Dunmore	of Dunmore in the Forest of Athole in the County of Perth	1980-08-12	5	earldom not extinct with barony	180	4	8	\N	f	\N	154	5	5
Ludlow	\N	1842-04-16	1	\N	181	3	8	\N	f	\N	155	5	13
Hamilton	of Wishaw in the County of Lanark	1868-12-22	1	\N	182	4	8	\N	f	\N	156	5	9
Oakley	of Caversham in the County of Oxford	\N	\N	succ 1832 as 3rd E Cadogan	185	2	8	\N	f	\N	157	5	16
Poltimore	of Poltimore in the County of Devon	\N	\N	\N	186	2	8	\N	f	\N	158	5	17
Wenlock	of Wenlock in the County of Salop	1834-04-10	1	brother cr L Wenlock 1839	187	2	8	\N	f	\N	159	5	24
Mostyn	of Mostyn in the County of Flint	\N	\N	\N	188	2	8	\N	f	\N	160	5	14
Segrave	of Berkeley Castle in the County of Gloucester	1857-10-10	1	cr E Fitzhardinge 17 Aug 1841	189	2	8	\N	f	\N	161	5	20
Templemore	of Templemore in the County of Donegall	\N	\N	5th L succ 1975 as 7th M of Donegall (I) & 7th L Fisherwick	190	2	8	\N	f	\N	162	5	21
Dinorben	of Kinmell in the County of Denbigh	1852-10-06	2	\N	191	2	8	\N	f	\N	163	5	5
Canning	of Kilbrahan in the County of Kilkenny	1862-06-17	2	SR to heirs male of body by late husband George Canning	159	2	12	\N	f	3	164	5	4
Bristol	\N	\N	\N	\N	137	7	9	\N	t	\N	166	5	3
Durham	\N	\N	\N	6th E disclaimed	205	7	6	\N	t	\N	200	5	5
Effingham	in the County of Surrey	\N	\N	6th E died 23 Feb 1996	224	7	6	\N	t	\N	201	5	6
Lichfield	of Lichfield in the County of Stafford	\N	\N	\N	196	7	6	\N	t	\N	202	5	13
Lovelace	\N	2018-01-31	5	& V Ockham	234	7	6	\N	t	\N	203	5	13
Ripon	in the County of York	1923-09-22	3	2nd E succ as 3rd E de Grey 1859 & was cr M of Ripon 1871	206	7	6	\N	t	\N	204	5	19
Yarborough	\N	\N	\N	7th E died 21 March 1991	228	7	6	\N	t	\N	205	5	26
Zetland	\N	\N	\N	3rd E cr M of Zetland 1892	235	7	6	\N	t	\N	206	5	27
Breadalbane	\N	1862-11-08	2	\N	192	7	9	\N	t	\N	207	5	3
Westminster	\N	\N	\N	3rd M cr D of Westminster 1874	194	7	9	\N	t	\N	208	5	24
Wenman	of Thame Park and Swalcliffe in the County of Oxford	1870-08-09	1	\N	210	2	8	\N	f	\N	209	5	24
Cloncurry	of Cloncurry in the County of Kildare	1929-07-18	4	\N	195	3	8	\N	f	\N	168	5	4
de Saumarez	in the Island of Guernsey	\N	\N	6th L died 20 Jan 1991	197	2	8	\N	f	\N	169	5	5
Godolphin	of Farnham Royal in the County of Bucks	1964-03-20	6	2nd L succ as 8th D of Leeds 4 May 1859	198	2	8	\N	f	\N	170	5	8
Sutherland	in Scotland	\N	\N	\N	202	7	4	\N	t	\N	198	5	20
Hunsdon	of Scutterskelfe in the County of York	1884-03-12	1	\N	199	4	8	\N	f	\N	171	5	9
Stanley	of Bickerstaffe in the County Palatine of Lancaster	\N	\N	succ as 13th E of Derby 21 Oct 1834	201	2	8	\N	f	\N	172	5	20
Western	of Rivenhall in the County of Essex	1844-11-04	1	\N	203	2	8	\N	f	\N	173	5	24
Granville	\N	\N	\N	5th E died 31 Oct 1996	207	7	6	\N	f	\N	174	5	8
Solway	of Kinmount in the County of Dumfries	1837-12-03	1	\N	208	4	8	\N	f	\N	175	5	20
Denman	of Dovedale in the County of Derby	\N	\N	\N	209	2	8	\N	f	\N	176	5	5
Fitzgerald	of Desmond and of Clan Gibbon in the County of Cork	1843-05-11	1	\N	212	3	8	\N	f	\N	178	5	7
Abinger	of Abinger in the County of Surrey and of the City of Norwich	\N	\N	\N	213	2	8	\N	f	\N	179	5	2
De L'Isle and Dudley	of Penshurst in the County of Kent	\N	\N	6th L cr V De L'Isle 1956	214	2	8	\N	f	\N	180	5	5
Canterbury	of the City of Canterbury	1941-02-26	6	\N	215	2	12	\N	f	\N	181	5	4
Ashburton	of Ashburton in the County of Devon	\N	\N	6th L died 12 June 1991	216	2	8	\N	f	\N	182	5	2
Glenelg	of Glenelg in the County of Inverness	1866-04-23	1	\N	217	2	8	\N	f	\N	183	5	8
Hatherton	of Hatherton in the County of Stafford	\N	\N	\N	218	2	8	\N	f	\N	184	5	9
Strafford	of Harmondsworth in the County of Middlesex	\N	\N	cr E of Strafford 1847	219	2	8	\N	f	\N	185	5	20
Worlingham	of Beccles in the County of Suffolk	\N	\N	\N	220	3	8	\N	f	\N	186	5	24
Cottenham	of Cottenham in the County of Cambridge	\N	\N	cr E of Cottenham 1850	221	2	8	\N	f	\N	187	5	4
Langdale	of Langdale in the County of Westmorland	1851-04-18	1	\N	223	2	8	\N	f	\N	188	5	13
Lovat	of Lovat in the County of Inverness	\N	\N	was L Lovat (S) but for attainder, which was reversed 1857	227	2	8	\N	f	\N	190	5	13
Bateman	of Shobdon in the County of Hereford	1931-11-04	3	\N	229	2	8	\N	f	\N	191	5	3
Lismore	of Shanbally castle in the County of Tipperary	1898-10-29	2	\N	237	3	8	\N	f	\N	192	5	13
Rossmore	of Monaghan in the County of Monaghan	\N	\N	\N	238	3	8	\N	f	\N	193	5	19
Carew	of Castleboro' in the County of Wexford	\N	\N	6th L died 27 June 1994	239	3	8	\N	f	\N	194	5	4
De Mauley	of Canford in the County of Dorset	\N	\N	\N	240	2	8	\N	f	\N	195	5	5
Wrottesley	of Wrottesley in the County of Stafford	\N	\N	\N	241	2	8	\N	f	\N	196	5	24
Cleveland	\N	1891-08-21	4	\N	204	7	4	\N	t	\N	197	5	4
Ducie	\N	\N	\N	6th E died 12 Nov 1991	226	7	6	\N	t	\N	199	5	5
Ellenborough	in the County of Cumberland	1871-12-22	1	\N	271	7	6	\N	t	\N	242	5	6
Gainsborough	in the County of Lincoln	\N	\N	\N	262	7	6	\N	t	\N	243	5	8
Dalhousie	of Dalhousie Castle in the County of Edinburgh and of the Punjaub	1860-12-22	1	\N	282	7	9	\N	t	\N	244	5	5
Normanby	in the County of York	\N	\N	4th M died 30 Jan 1994	233	7	9	\N	t	\N	245	5	15
Wales	\N	1901-01-22	1	merged in Crown 22 January 1901	269	7	11	\N	t	\N	246	5	24
Inverness	\N	1873-08-01	1	\N	259	2	4	\N	t	\N	247	5	10
Hill	of Hawkstone and of Hardwick in the County of Salop	\N	\N	\N	270	7	12	\N	f	1	248	5	9
Charlemont	of Charlemont in the County of Armagh	1892-01-12	2	SR to brother	230	3	8	\N	f	1	249	5	4
Sudeley	of Toddington in the County of Gloucester	\N	\N	\N	242	2	8	\N	f	\N	211	5	20
Auckland	\N	1849-01-01	1	\N	257	7	6	\N	t	\N	240	5	2
Methuen	of Corsham in the County of Wilts	\N	\N	?th L died 24 Aug 1994	243	2	8	\N	f	\N	212	5	14
Ponsonby	of Imokilly in the County of Cork	1855-02-21	1	\N	244	7	12	\N	f	\N	213	5	17
Furnival	of Malahide in the County of Dublin	1849-10-29	1	\N	246	3	8	\N	f	\N	214	5	7
Stanley of Alderley	in the County of Chester	\N	\N	4th L succeeded 1909 as 4th L Sheffield (I)	247	2	8	\N	f	\N	215	5	20
Stuart de Decies	of Dromana within the Decies in the County of Waterford	1874-01-23	1	son failed to establish his legitimacy	248	2	8	\N	f	\N	216	5	20
Leigh	of Stoneleigh in the County of Warwick	\N	\N	\N	249	2	8	\N	f	\N	217	5	13
Wenlock	of Wenlock in the County of Salop	1932-06-14	6	brother had been cr L Wenlock 1831 (ext 1834)	250	2	8	\N	f	\N	218	5	24
Lurgan	of Lurgan in the County of Armagh	1991-09-17	5	\N	251	2	8	\N	f	\N	219	5	13
Colborne	of West Harling in the County of Norfolk	1854-05-03	1	\N	252	2	8	\N	f	\N	220	5	4
De Freyne	of Artagh in the County of Roscommon	1856-09-29	1	new patent with SR 5 April 1851	253	2	8	\N	f	\N	221	5	5
Dunfermline	of Dunfermline in the County of Fife	1868-07-02	2	mother had been cr B Abercromby	254	2	8	\N	f	\N	222	5	5
Monteagle of Brandon	in the County of Kerry	\N	\N	\N	255	2	8	\N	f	\N	223	5	14
Seaton	of Seaton in the County of Devon	1955-03-12	4	\N	256	2	8	\N	f	\N	224	5	20
Keane	of Ghuznee in Affghanistan and of Cappoquin in the County of Waterford	1901-11-27	3	\N	258	2	8	\N	f	\N	225	5	12
Sydenham	of Sydenham in the County of Kent and of Toronto in Canada	1841-09-19	1	\N	260	2	8	\N	f	\N	226	5	20
Fitzhardinge	\N	1857-10-10	1	brother cr L Fitzhardinge 1861	264	7	6	\N	f	\N	227	5	7
Kenmare	of Castle Rosse in the County of Kerry	1853-10-31	1	\N	265	3	8	\N	f	\N	228	5	12
Vivian	of Glynn and Truro in the County of Cornwall	\N	\N	5th L died 24 June 1991	267	2	8	\N	f	\N	229	5	23
Congleton	of Congleton in the County Palatine of Chester	\N	\N	\N	268	2	8	\N	f	\N	230	5	4
Metcalfe	of Fern Hill in the County of Berks	1846-09-12	1	never introduced	272	2	8	\N	f	\N	231	5	14
Dartrey	of Dartrey in the County of Monaghan	1933-02-09	3	cr E of Dartrey 1866	278	3	8	\N	f	\N	234	5	5
Milford	of Picton Castle in the County of Pembroke	1857-01-03	1	\N	279	2	8	\N	f	\N	235	5	14
Eddisbury	of Winnington in the County Palatine of Chester	\N	\N	succ 1850 as 2nd L Stanley of Alderley	280	2	8	\N	f	\N	236	5	6
Gough	of Goojerat of the Punjaub and of the City of Limerick in Ireland	\N	\N	\N	281	7	12	\N	f	\N	237	5	8
Elgin	of Elgin in Scotland	\N	\N	\N	283	4	8	\N	f	\N	238	5	6
Oxenfoord	of Cousland in the County of Edinburgh	\N	\N	\N	263	4	8	\N	f	1	239	5	16
Dublin	\N	1901-01-22	1	merged in Crown 22 January 1901	284	8	6	\N	t	\N	241	5	5
Strafford	\N	\N	\N	\N	276	7	6	\N	t	\N	287	5	20
Winton	\N	\N	\N	was also E of Winton (S) & 2nd L Ardrossan	319	8	6	\N	t	\N	288	5	24
de Freyne	of Coolavin in the County of Sligo	\N	\N	SR to 3 brothers	292	8	8	\N	f	1	289	5	5
Londesborough	of Londesborough in the East Riding of the County of York	\N	\N	2nd L cr E of Londesborough 1887 (ext 1937)	286	2	8	\N	f	\N	250	5	13
Dudley	of Dudley Castle in the County of Stafford	\N	\N	\N	323	7	6	\N	t	\N	285	5	5
Overstone	of Overstone and of Fotheringhay, both in the County of Northampton	1883-11-17	1	\N	287	2	8	\N	f	\N	251	5	16
Truro	of Bowes in the County of Middlesex	1899-03-08	3	\N	289	2	8	\N	f	\N	252	5	21
Cranworth	of Cranworth in the County of Norfolk	1868-07-26	1	\N	290	2	8	\N	f	\N	253	5	4
Broughton	of Broughton de Gyfford in the County of Wilts	1869-06-03	1	\N	291	2	8	\N	f	\N	254	5	3
Saint Leonards	of Slaugham in the County of Sussex	1985-06-01	4	\N	293	2	8	\N	f	\N	255	5	20
Stratford de Redcliffe	in the County of Somerset	1880-08-14	1	\N	294	2	12	\N	f	\N	256	5	20
Raglan	of Raglan in the County of Monmouth	\N	\N	\N	295	2	8	\N	f	\N	257	5	19
Kenmare	of Castlerosse in the County of Kerry	1952-02-14	5	\N	298	3	8	\N	f	\N	259	5	12
Lyons	of Christchurch in the County of Southampton	1887-12-05	2	2nd L cr V Lyons 1881	299	2	8	\N	f	\N	260	5	13
Wensleydale	of Walton in the County Palatine of Lancaster	1868-02-25	1	\N	300	8	8	\N	f	\N	261	5	24
Belper	of Belper in the County of Derby	\N	\N	\N	301	2	8	\N	f	\N	262	5	3
Talbot de Malahide	in the County of Dublin	1973-04-14	4	\N	302	3	8	\N	f	\N	263	5	21
Cowley	\N	\N	\N	\N	303	7	6	\N	f	\N	264	5	4
Eversley	of Heckfield in the County of Southampton	1888-12-28	1	\N	304	2	12	\N	f	\N	265	5	6
Ebury	of Ebury Manor in the County of Middlesex	\N	\N	6th L succeeded 1 Oct 1999 as 8th E of Wilton	305	2	8	\N	f	\N	266	5	6
Macaulay	of Rothley in the County of Leicester	1859-12-28	1	\N	306	2	8	\N	f	\N	267	5	14
Skene	of Skene in the County of Aberdeen	1912-01-29	2	2nd L cr D of Fife	307	3	8	\N	f	\N	268	5	20
Chesham	of Chesham in the County of Buckingham	\N	\N	\N	308	2	8	\N	f	\N	269	5	4
Chelmsford	of Chelmsford in the County of Essex	\N	\N	3rd L cr V Chelmsford 1921	309	2	8	\N	f	\N	270	5	4
Blachford	of Wisdome in the County of Devon	1889-11-21	1	\N	383	2	8	\N	f	\N	271	5	3
Clyde	of Clydesdale in Scotland	1863-08-14	1	\N	312	2	8	\N	f	\N	273	5	4
Kingsdown	of Kingsdown in the County of Kent	1867-10-07	1	\N	313	2	8	\N	f	\N	274	5	12
Egerton	of Tatton in the County Palatine of Chester	1958-01-30	4	2nd L cr E Egerton 1897 (ext on his death 1909)	315	2	8	\N	f	\N	276	5	6
Lyveden	of Lyveden in the County of Northampton	\N	\N	\N	320	2	8	\N	f	\N	277	5	13
Llanover	of Llanover and Abercarn in the County of Monmouth	1867-04-27	1	1	321	2	8	\N	f	\N	278	5	13
Taunton	of Taunton in the County of Somerset	1869-07-13	1	\N	322	2	8	\N	f	\N	279	5	21
Herbert	of Lea in the County of Wilts	\N	\N	2nd L succ 25 Apr 1862 as 13th E of Pembroke & 10th E of Montgomery	326	2	8	\N	f	\N	280	5	9
Westbury	of Westbury in the County of Wilts	\N	\N	\N	327	2	8	\N	f	\N	281	5	24
Russell	of Kingston Russell in the County of Dorset	\N	\N	& V Amberley	328	2	6	\N	f	\N	282	5	19
Fitzhardinge	of the City and County of the City of Bristol	1916-12-05	3	\N	329	2	8	\N	f	\N	283	5	7
Cottenham	of Cottenham in the County of Cambridge	\N	\N	\N	288	7	6	\N	t	\N	284	5	4
Ellesmere	of Ellesmere in the County of Salop	\N	\N	5th E succ 1963 as 6th D of Sutherland	275	2	6	\N	t	\N	286	5	6
Saint Maur	of Berry Pomeroy in the County of Devon	1885-11-28	1	granted so son (who dvp) might be summoned as L Seymour	331	8	6	\N	f	\N	290	5	20
Kimberley	of Kimberley in the County of Norfolk	\N	\N	\N	342	7	6	\N	t	\N	325	5	12
Annaly	of Annaly and Rathcline in the County of Longford	\N	\N	5th L died 30 Sep 1990	332	2	8	\N	f	\N	291	5	2
Houghton	of Great Houghton in the West Riding of the County of York	1945-06-20	2	2nd L cr E of Crewe 17 July 1895	333	2	8	\N	f	\N	292	5	9
Romilly	of Barry in the County of Glamorgan	1983-06-29	4	\N	335	2	8	\N	f	\N	293	5	19
Halifax	of Monk Bretton in the West Riding of the County of York	\N	\N	3rd V cr E of Halifax 1944	337	2	12	\N	f	\N	295	5	9
Barrogill	of Barrogill Castle in the County of Caithness	1889-05-25	2	\N	338	4	8	\N	f	\N	296	5	3
Clermont	of Clermont Park in the County of Louth	1887-07-29	1	\N	339	3	8	\N	f	\N	297	5	4
Meredyth	of Dollardstown in the County of Meath	1929-01-08	2	\N	340	3	8	\N	f	\N	298	5	14
Kenry	of Kenry in the County of Limerick	1926-06-14	2	\N	343	3	8	\N	f	\N	299	5	12
Monck	of Ballytrammon in the County of Wexford	\N	\N	\N	345	3	8	\N	f	\N	300	5	14
Hartismere	of Hartismere in the County of Suffolk	\N	\N	\N	346	3	8	\N	f	\N	301	5	9
Lytton	of Knebworth in the County of Hertford	\N	\N	2nd L cr E of Lytton 1880	347	2	8	\N	f	\N	302	5	13
Hylton	of Hylton in the County Palatine of Durham and of Petersfield in the County of Southampton	\N	\N	\N	348	2	8	\N	f	\N	303	5	9
Strathnairn	of Strathnairn in the County of Nairn and of Jhansi in the East Indies	1885-10-16	1	\N	349	2	8	\N	f	\N	304	5	20
Penrhyn	of Llandegai in the County of Carnarvon	\N	\N	\N	350	2	8	\N	f	\N	305	5	17
Colonsay	of Colonsay and Oronsay in the County of Argyll	1874-01-31	1	\N	352	2	8	\N	f	\N	306	5	4
Cairns	of Garmoyle in the County of Antrim	\N	\N	cr E Cairns 1878	353	2	8	\N	f	\N	307	5	4
Kesteven	of Casewick in the County of Lincoln	1915-11-05	3	\N	354	2	8	\N	f	\N	308	5	12
Ormathwaite	of Ormathwaite in the County of Cumberland	1984-03-08	6	\N	355	2	8	\N	f	\N	309	5	16
Fitzwalter	of Woodham Walter in the County of Essex	1875-12-06	1	\N	356	2	8	\N	f	\N	310	5	7
O'Neill	of Shanes Castle in the County of Antrim	\N	\N	\N	357	2	8	\N	f	\N	311	5	16
Canning	\N	1862-06-17	1	\N	317	7	6	\N	f	\N	312	5	4
Elphinstone	of Elphinstone in the County of Stirling	1860-07-19	1	\N	318	4	8	\N	f	\N	313	5	6
Gormanston	of Whitewood in the County of Meath	\N	\N	\N	362	3	8	\N	f	\N	314	5	8
Hatherley	of Down Hatherley in the County of Gloucester	1881-07-10	1	\N	363	2	8	\N	f	\N	315	5	9
Lawrence	of the Punjaub and of Grately in the County of Southampton	\N	\N	\N	364	2	8	\N	f	\N	316	5	13
Penzance	of Penzance in the County of Cornwall	1899-12-09	1	\N	365	2	8	\N	f	\N	317	5	17
Dunning	of Dunning and Pitcairns in the County of Perth	\N	\N	\N	366	4	8	\N	f	\N	318	5	5
Hare	of Convamore in the County of Cork	\N	\N	5th E of Listowel died 12 March 1997	368	3	8	\N	f	\N	319	5	9
Howard of Glossop	in the County of Derby	\N	\N	title passed 1972 to L Beaumont, who succ 1975 as D of Norfolk	369	2	8	\N	f	\N	320	5	9
Castletown	of Upper Ossory in the Queen's County	1937-05-29	2	\N	370	2	8	\N	f	\N	321	5	4
Acton	of Aldenham in the County of Salop	\N	\N	?th L died 23 Jan 1989	371	2	8	\N	f	\N	322	5	2
Dartrey	of Dartrey in the County of Monaghan	1933-02-09	3	also 1st L Dartrey (cr 1847)	344	7	6	\N	t	\N	324	5	5
Beaconsfield	of Beaconsfield in the County of Buckingham	1872-12-15	1	\N	361	2	12	\N	f	\N	326	5	3
Ravensworth	of Ravensworth Castle in the County Palatine of Durham	1904-02-07	3	\N	407	7	6	\N	t	\N	361	5	19
Abergavenny	in the County of Monmouth	\N	\N	\N	414	7	9	\N	t	\N	362	5	2
Ripon	in the County of York	1923-09-22	2	\N	381	7	9	\N	t	\N	363	5	19
Burdett-Coutts	of Highgate and Brookfield in the County of Middlesex	1906-12-30	1	\N	380	2	8	\N	f	\N	364	5	3
Harlech	of Harlech in the County of Merioneth	\N	\N	SR to brother	415	2	8	\N	f	1	365	5	9
Wolverton	of Wolverton in the County of Buckingham	\N	\N	\N	373	2	8	\N	f	\N	327	5	24
Westminster	\N	\N	\N	\N	399	7	4	\N	t	\N	359	5	24
Greville	of Clonyn in the County of Westmeath	1987-12-09	4	\N	374	2	8	\N	f	\N	328	5	8
Kildare	of Kildare in the County of Kildare	\N	\N	succ 1874 as 4th D of Leinster (I) & 4th V Leinster	375	2	8	\N	f	\N	329	5	12
O'Hagan	of Tullahogue in the County of Tyrone	\N	\N	\N	376	2	8	\N	f	\N	330	5	16
Lisgar	of Lisgar and Bailieborough in the County of Cavan	1876-10-06	1	\N	377	2	8	\N	f	\N	331	5	13
Dalling and Bulwer	of Dalling in the County of Norfolk	1872-05-23	1	\N	378	2	8	\N	f	\N	332	5	5
Sandhurst	of Sandhurst in the County of Berks	\N	\N	2nd L cr V Sandhurst 1917, ext(1) 1921	379	2	8	\N	f	\N	333	5	20
Bloomfield	of Ciamhalltha in the County of Tipperary	1879-08-17	1	\N	382	3	8	\N	f	\N	334	5	3
Ossington	of Ossington in the County of Nottingham	1873-03-07	1	\N	385	2	12	\N	f	\N	335	5	16
Ettrick	of Ettrick in the County of Selkirk	\N	\N	\N	386	4	8	\N	f	\N	336	5	6
Hanmer	of Hanmer and of Flint (both in the County of Flint)	1881-03-08	1	\N	387	2	8	\N	f	\N	337	5	9
Selborne	of Selborne in the County of Southampton	\N	\N	cr E of Selborne 1882	388	2	8	\N	f	\N	338	5	20
Breadalbane	of Kenmore in the County of Perth	1922-10-19	1	cr M of Breadalbane 1885	389	4	8	\N	f	\N	339	5	3
Portman	of Bryanston in the County of Dorset	\N	\N	\N	390	7	12	\N	f	\N	340	5	17
Waveney	of South Elmham in the County of Suffolk	1886-02-05	1	\N	392	2	8	\N	f	\N	341	5	24
Marjoribanks	of Ladykirk in the County of Berwick	1873-06-19	1	\N	393	2	8	\N	f	\N	342	5	14
Aberdare	of Duffryn in the County of Glamorgan	\N	\N	\N	394	2	8	\N	f	\N	343	5	2
Lanerton	of Lanerton in the County of Cumberland	1880-10-08	1	\N	395	2	8	\N	f	\N	344	5	13
Moncreiff	of Tulliebole in the County of Kinross	\N	\N	\N	396	2	8	\N	f	\N	345	5	14
Coleridge	of Ottery St Mary in the County of Devon	\N	\N	\N	397	2	8	\N	f	\N	346	5	4
Emly	of Jervoe in the County of Limerick	1932-11-24	2	\N	398	2	8	\N	f	\N	347	5	6
Sydney	of Scadbury in the County of Kent	1890-02-14	1	\N	400	7	6	\N	f	\N	348	5	20
Napier of Magdâla	in Abyssinia and of Caryngton in the County Palatine of Chester	\N	\N	\N	359	2	8	\N	f	\N	349	5	15
Hampton	of Hampton Lovett and of Westwood in the County of Worcester	\N	\N	\N	405	2	8	\N	f	\N	350	5	9
Winmarleigh	of Winmarleigh in the County Palatine of Lancaster	1892-07-11	1	\N	406	2	8	\N	f	\N	351	5	24
Ramsay	of Glenmark in the County of Forfar	\N	\N	\N	410	4	8	\N	f	\N	352	5	19
Fermanagh	of Lisnaskea in the County of Fermanagh	\N	\N	\N	413	3	8	\N	f	\N	354	5	7
Alington	of Crichel in the County of Dorset	1940-09-17	3	\N	417	2	8	\N	f	\N	355	5	2
Tollemache	of Helmingham Hall in the County of Suffolk	\N	\N	\N	418	2	8	\N	f	\N	356	5	21
Gerard	of Bryn in the County Palatine of Lancaster	\N	\N	4th L died 11 July 1992	419	2	8	\N	f	\N	357	5	8
Gordon	of Gordon Castle in Scotland	\N	\N	\N	412	4	4	\N	t	\N	358	5	8
Redesdale	in the County of Northumberland	1886-05-02	1	\N	426	7	6	\N	t	\N	400	5	19
Selborne	in the County of Southampton	\N	\N	\N	459	7	6	\N	t	\N	401	5	20
Sackville	of Knole in the County of Kent	\N	\N	SR to brothers	422	2	8	\N	f	1	402	5	20
Gordon of Drumearn	in the County of Stirling	1879-08-21	1	\N	424	1	8	\N	f	\N	366	5	8
Shute	of Beckett in the County of Berks	1990-04-06	5	\N	430	3	8	\N	f	1	403	5	20
Airey	of Killingworth in the County of Northumberland	1881-09-13	1	\N	425	2	8	\N	f	\N	367	5	2
Lytton	in the County of Derby	\N	\N	\N	432	7	6	\N	t	\N	398	5	13
Norton	of Norton-on-the-Moors in the County of Stafford	\N	\N	7th L died 24 Sep 1993	427	2	8	\N	f	\N	368	5	15
Cranbrook	of Hemsted in the County of Kent	\N	\N	cr E of Cranbrook 1892	428	2	12	\N	f	\N	369	5	4
Cairns	\N	\N	\N	\N	429	7	6	\N	f	\N	370	5	4
Watson	of Thankerton in the County of Lanark	1899-09-14	1	vice L Gordon of Drumearn deceased	433	1	8	\N	f	\N	371	5	24
Haldon	of Haldon in the County of Devon	1939-01-11	5	\N	434	2	8	\N	f	\N	372	5	9
Wimborne	of Canford Magna in the County of Dorset	\N	\N	2nd L cr V Wimborne 1918	435	2	8	\N	f	\N	373	5	24
Ardilaun	of Ashford in the County of Galway	1915-01-20	1	\N	436	2	8	\N	f	\N	374	5	2
Lamington	of Lamington in the County of Lanark	1951-09-20	3	\N	438	2	8	\N	f	\N	375	5	13
Sondes	of Lees Court in the County of Kent	1996-12-02	5	\N	439	7	6	\N	f	\N	376	5	20
Donington	of Donington Park in the County of Leicester	1927-05-31	3	\N	440	2	8	\N	f	\N	377	5	5
Trevor	of Brynkinalt in the County of Denbigh	\N	\N	4th L died 1 Jan 1997	441	2	8	\N	f	\N	378	5	21
Rowton	of Rowton Castle in the County of Salop	1903-11-09	1	\N	442	2	8	\N	f	\N	379	5	19
Sherbrooke	of Sherbrooke in the County of Surrey	1892-07-27	1	\N	443	2	12	\N	f	\N	380	5	20
Hammond	of Kirkella in the town and County of the town of Kingston upon Hull	1890-04-29	1	\N	403	2	8	\N	f	\N	382	5	9
Cardwell	of Ellerbeck in the County Palatine of Lancaster	1886-02-15	1	\N	404	2	12	\N	f	\N	383	5	4
Tweeddale	of Yester in the County of Haddington	\N	\N	\N	448	4	8	\N	f	\N	384	5	21
Howth	of Howth in the County of Dublin	1909-03-09	1	\N	449	3	8	\N	f	\N	385	5	9
Reay	of Durness in the County of Sutherland	1921-08-01	1	\N	450	4	8	\N	f	\N	386	5	19
Derwent	of Hackness in the North Riding of the County of York	\N	\N	\N	451	2	8	\N	f	\N	387	5	5
Hothfield	of Hothfield in the County of Kent	\N	\N	5th L died 5 Feb 1991	452	2	8	\N	f	\N	388	5	9
Tweedmouth	of Edington in the County of Berwick	1935-04-23	3	\N	453	2	8	\N	f	\N	389	5	21
Bramwell	of Hever in the County of Kent	1892-05-09	1	\N	455	2	8	\N	f	\N	390	5	3
FitzGerald	of Kilmarnock in the County of Dublin	1889-10-16	1	\N	456	1	8	\N	f	\N	391	5	7
Alcester	of Alcester in the County of Warwick	1895-03-30	1	\N	457	2	8	\N	f	\N	392	5	2
Tennyson	of Aldworth in the County of Sussex and of Freshwater in the Isle of Wight	\N	\N	4th L died 19 Oct 1991	460	2	8	\N	f	\N	394	5	21
Hampden	of Glynde in the County of Sussex	\N	\N	succ 1890 as 23rd L Dacre; titles separated 17 Oct 1965	461	2	12	\N	f	\N	395	5	9
Monk Bretton	of Conyboro and of Hurstpierpoint in the County of Sussex	\N	\N	\N	463	2	8	\N	f	\N	396	5	14
Lathom	in the County Palatine of Lancaster	1930-02-06	3	\N	437	7	6	\N	t	\N	397	5	13
Northbrook	in the County of Southampton	1929-04-12	2	\N	420	7	6	\N	t	\N	399	5	15
Deramore	of Belvoir in the County of Down	2006-08-20	6	SR to brother	484	2	8	\N	f	1	441	5	5
Grimthorpe	of Grimthorpe in the East Riding of the County of York	\N	\N	SR to father's heirs	491	2	8	\N	f	1	442	5	8
Northbourne	of Betteshanger in the County of Kent and of Jarrow Grange in the County Palatine of Durham	\N	\N	\N	464	2	8	\N	f	\N	405	5	15
Londesborough	in the County of York	1937-04-17	4	\N	505	7	6	\N	t	\N	439	5	13
Sudley	of Castle Gore in the County of Mayo	\N	\N	\N	465	3	8	\N	f	\N	406	5	20
de Vesci	of Abbey Leix in the Queen's Co	1903-07-06	1	\N	466	3	8	\N	f	\N	407	5	5
Herries	of Carlaverock Castle in the County of Dumfries and of Everingham in the East Riding of the County of York	1908-10-05	1	\N	467	4	8	\N	f	\N	408	5	9
Halsbury	of Halsbury in the County of Devon	2010-12-31	4	cr E of Halsbury 1898	468	2	8	\N	f	\N	409	5	9
Powerscourt	of Powerscourt in the County of Wicklow	\N	\N	\N	469	3	8	\N	f	\N	410	5	17
Northington	of Watford in the County of Northampton	\N	\N	\N	470	3	8	\N	f	\N	411	5	15
Rothschild	of Tring in the County of Hertford	\N	\N	3rd L died 20 March 1990	471	2	8	\N	f	\N	412	5	19
Revelstoke	of Membland in the County of Devon	\N	\N	4th L died 18 July 1994	472	2	8	\N	f	\N	413	5	19
Monkswell	of Monkswell in the County of Devon	\N	\N	4th L disclaimed 1964 & died 27 Jly 1984	473	2	8	\N	f	\N	414	5	14
Hobhouse	of Hadspen in the County of Somerset	1904-12-06	1	\N	474	2	8	\N	f	\N	415	5	9
Lingen	of Lingen in the County of Hereford	1905-07-22	1	\N	476	2	8	\N	f	\N	416	5	13
Ashbourne	of Ashbourne in the County of Meath	\N	\N	\N	477	2	8	\N	f	\N	417	5	2
Saint Oswald	of Nostell in the West Riding of the County of York	\N	\N	\N	478	2	8	\N	f	\N	418	5	20
Wantage	of Lockinge in the County of Berks	1901-06-10	1	\N	481	2	8	\N	f	\N	419	5	24
Esher	of Esher in the County of Surrey	\N	\N	cr V Esher 1897	482	2	8	\N	f	\N	420	5	6
Montagu of Beaulieu	in the County of Southampton	\N	\N	\N	485	2	8	\N	f	\N	421	5	14
Elphinstone	of Elphinstone in the County of Haddington	\N	\N	\N	486	4	8	\N	f	\N	422	5	6
Ampthill	of Ampthill in the County of Bedford	\N	\N	\N	446	2	8	\N	f	\N	423	5	2
Hindlip	of Hindlip in the County of Worcester and of Alsop-en-le-Dale in the County of Derby	\N	\N	\N	490	2	8	\N	f	\N	424	5	9
Stalbridge	of Stalbridge in the County of Dorset	1949-12-24	2	\N	492	2	8	\N	f	\N	425	5	20
Kensington	of Kensington in the County of Middlesex	\N	\N	\N	493	3	8	\N	f	\N	426	5	12
Farnborough	of Farnborough in the County of Southampton	1886-05-17	1	\N	494	2	8	\N	f	\N	427	5	7
Oxenbridge	of Burton in the County of Lincoln	1898-04-16	1	\N	495	7	12	\N	f	\N	428	5	16
Brassey	of Bulkeley in the County Palatine of Chester	1919-11-12	2	cr E Brassey 1911	498	2	8	\N	f	\N	430	5	3
Thring	of Alderhurst in the County of Surrey	1907-02-04	1	\N	499	2	8	\N	f	\N	431	5	21
de Montalt	of Dundrum in the County of Tipperary	1905-01-09	1	\N	502	3	6	\N	f	\N	433	5	5
Macnaghten	of Runkerry in the County of Antrim	1913-02-17	1	vice L Blackburn resigned	503	1	8	\N	f	\N	434	5	14
Connemara	of Connemara in the County of Galway	1902-09-03	1	\N	504	2	8	\N	f	\N	435	5	4
Bowes	of Streatlam Castle in the County of Durham and of Lunedale in the County of York	\N	\N	\N	506	4	8	\N	f	\N	436	5	3
Monckton	of Serlby in the County of Nottingham	1971-01-01	3	\N	507	3	8	\N	f	\N	437	5	14
Iddesleigh	in the County of Devon	\N	\N	\N	475	2	6	\N	t	\N	438	5	10
Breadalbane	\N	1922-10-19	1	\N	479	7	9	\N	t	\N	440	5	3
Cranbrook	in the County of Kent	\N	\N	\N	538	7	6	\N	t	\N	476	5	4
Dufferin and Ava	in the County of Down and in Burma	1988-05-29	5	\N	517	7	9	\N	t	\N	477	5	5
Zetland	\N	\N	\N	\N	537	7	9	\N	t	\N	478	5	27
Macdonald of Earnscliffe	in the Province of Ontario and Dominion of Canada	1920-09-05	1	\N	527	2	8	\N	f	\N	479	5	14
Savile	of Rufford in the County of Nottingham	\N	\N	SR to father's heirs	516	2	8	\N	f	1	480	5	20
Saint Levan	of Saint Michael's Mount in the County of Cornwall	\N	\N	\N	508	2	8	\N	f	\N	443	5	20
Amherst of Hackney	in the County of London	\N	\N	SR to eldest dau	544	2	8	\N	f	2	481	5	2
Hambleden	of Hambleden in the County of Buckingham	\N	\N	SR to heirs male by her late husband	528	2	12	\N	f	3	482	5	9
Magheramorne	of Magheramorne in the County of Antrim	1957-04-21	4	\N	509	2	8	\N	f	\N	444	5	14
York	\N	1910-05-06	1	merged in Crown 6 May 1910	533	2	4	\N	t	\N	474	5	26
Armstrong	of Cragside in the County of Northumberland	1900-12-27	1	\N	510	2	8	\N	f	\N	445	5	2
De Ramsey	of Ramsey Abbey in the County of Huntingdon	\N	\N	3rd L died 31 March 1993	512	2	8	\N	f	\N	447	5	5
Cheylesmore	of Cheylesmore in the City of Coventry and County of Warwick	1974-04-21	4	\N	513	2	8	\N	f	\N	448	5	4
Addington	of Addington in the County of Buckingham	\N	\N	\N	514	2	8	\N	f	\N	449	5	2
Knutsford	of Knutsford in the County Palatine of Chester	\N	\N	cr V Knutsford 1895	515	2	8	\N	f	\N	450	5	12
Morris	of Spiddal in the County of Galway	1901-09-08	1	vice L Fitzgerald deceased; cr L Killanin (hereditary) 1900	519	1	8	\N	f	\N	451	5	14
Field	of Bakeham in the County of Surrey	1907-01-23	1	\N	520	2	8	\N	f	\N	452	5	7
Sandford	of Sandford in the County of Salop	1893-12-31	1	\N	522	2	8	\N	f	\N	453	5	20
Iveagh	of Iveagh in the County of Down	\N	\N	cr V Iveagh 1905, E of Iveagh 1919	523	2	8	\N	f	\N	454	5	10
Hannen	of Burdock in the County of Sussex	1894-03-29	1	\N	524	1	8	\N	f	\N	455	5	9
Masham	of Swinton in the County of York	1924-01-04	3	\N	526	2	8	\N	f	\N	456	5	14
Roberts of Kandahar	in Afghanistan and of the City of Waterford	1914-11-14	1	cr E Roberts (SR) 1901	529	2	8	\N	f	\N	457	5	19
Herschell	of the City of Durham	2008-10-26	3	\N	488	2	8	\N	f	\N	458	5	9
Hillingdon	of Hillingdon in the County of Middlesex	1982-09-01	5	\N	489	2	8	\N	f	\N	459	5	9
Rookwood	of Rookwood Hall and Down Hall both in the County of Essex	1902-01-15	1	\N	534	2	8	\N	f	\N	460	5	19
Cromer	of Cromer in the County of Norfolk	\N	\N	cr V Cromer 1899, E of Cromer 1901	535	2	8	\N	f	\N	461	5	4
Shand	of Woodhouse in the County of Dumfries	1904-03-06	1	\N	536	2	8	\N	f	\N	462	5	20
Ashcombe	of Dorking in the County of Surrey and of Bodiam Castle in the County of Sussex	\N	\N	\N	539	2	8	\N	f	\N	463	5	2
Knightley	of Fawsley in the County of Northampton	1895-12-19	1	\N	541	2	8	\N	f	\N	464	5	12
Crawshaw	of Crawshaw in the County Palatine of Lancaster and of Whatton in the County of Leicester	\N	\N	\N	543	2	8	\N	f	\N	465	5	4
Newton	of Newton in Makerfield in the County Palatine of Lancaster	\N	\N	4th L died 16 June 1992	545	2	8	\N	f	\N	466	5	15
Dunleath	of Ballywalter in the County of Down	\N	\N	4th L died 9 Jan 1993	546	2	8	\N	f	\N	467	5	5
Llangattock	of the Hendre in the County of Monmouth	1916-10-31	2	\N	547	2	8	\N	f	\N	468	5	13
Playfair	of Saint Andrews in the County of Fife	1939-12-26	2	\N	548	2	8	\N	f	\N	469	5	17
Swansea	of Singleton in the County of Glamorgan	\N	\N	\N	550	2	8	\N	f	\N	471	5	20
Farrer	of Abinger in the County of Surrey	1964-12-16	5	\N	551	2	8	\N	f	\N	472	5	7
Fife	in Scotland	1912-01-29	1	further patent (SR) 1900	518	7	4	\N	t	\N	473	5	7
Overtoun	of Overtoun in the County of Dumbarton	1908-02-15	1	\N	552	2	8	\N	f	\N	483	5	16
Halsbury	in the County of Devon	2010-12-31	4	\N	591	7	6	\N	t	\N	521	5	9
Kelhead	of Kelhead in the County of Dumfries	1894-10-19	1	\N	554	2	8	\N	f	\N	484	5	12
Stanmore	of Great Stanmore in the County of Middlesex	1957-04-13	2	\N	555	2	8	\N	f	\N	485	5	20
Bowen	of Colwood in the County of Sussex	1894-04-10	1	vice L Hannen resigned	556	1	8	\N	f	\N	486	5	3
Rendel	of Hatchlands in the County of Surrey	1913-06-04	1	\N	557	2	8	\N	f	\N	487	5	19
Welby	of Allington in the County of Lincoln	1915-10-29	1	\N	558	2	8	\N	f	\N	488	5	24
Russell of Killowen	in the County of Down	1900-08-10	1	vice L Bowen deceased	559	1	8	\N	f	\N	489	5	19
Peel	of Sandy in the County of Bedford	\N	\N	2nd V cr E Peel 1929	561	2	12	\N	f	\N	491	5	17
Carrington	\N	1928-06-13	1	cr M of Lincolnshire 1912	562	7	6	\N	f	\N	492	5	4
Loch	of Drylaw in the County of Midlothian	1991-06-24	4	\N	564	2	8	\N	f	\N	493	5	13
Wandsworth	of Wandsworth in the County of London	1912-02-10	1	\N	565	2	8	\N	f	\N	494	5	24
Ashton	of Ashton in the County Palatine of Lancaster	1930-05-27	1	\N	566	2	8	\N	f	\N	495	5	2
Knutsford	of Knutsford in the County Palatine of Chester	\N	\N	\N	567	7	12	\N	f	\N	496	5	12
Burghclere	of Walden in the County of Essex	1921-05-06	1	\N	568	2	8	\N	f	\N	497	5	3
Llandaff	of Hereford in the County of Hereford	1913-04-03	1	\N	569	2	12	\N	f	\N	498	5	13
James of Hereford	in the County of Hereford	1911-08-18	1	\N	570	2	8	\N	f	\N	499	5	11
Rathmore	of Shanganagh in the County of Dublin	1919-08-22	1	\N	571	2	8	\N	f	\N	500	5	19
Pirbright	of Pirbright in the County of Surrey	1903-01-09	1	\N	572	2	8	\N	f	\N	501	5	17
Glenesk	of Glenesk in the County of Midlothian	1908-11-24	1	\N	573	2	8	\N	f	\N	502	5	8
Kelvin	of Largs in the County of Ayr	1907-12-17	1	\N	531	2	8	\N	f	\N	503	5	12
Kinnear	of Spurness in the County of Orkney	1917-12-20	1	\N	580	2	8	\N	f	\N	505	5	12
Lister	of Lyme Regis in the County of Dorset	1912-02-10	1	\N	581	2	8	\N	f	\N	506	5	13
Fairlie	of Fairlie in the County of Ayr	\N	\N	\N	583	4	8	\N	f	\N	508	5	7
Dawnay	of Danby in the North Riding of the County of York	\N	\N	\N	584	3	8	\N	f	\N	509	5	5
Ludlow	of Heywood in the County of Wilts	1922-11-08	2	\N	585	2	8	\N	f	\N	510	5	13
HolmPatrick	of HolmPatrick in the County of Dublin	\N	\N	3rd L died 15 Feb 1991	586	2	8	\N	f	\N	511	5	9
Inverclyde	of Castle Wemyss in the County of Renfrew	1957-06-17	4	\N	587	2	8	\N	f	\N	512	5	10
Esher	of Esher in the County of Surrey	\N	\N	\N	589	7	12	\N	f	\N	513	5	6
Farquhar	of Saint Marylebone in the County of London	1923-08-30	1	cr V Farquhar 1917, E Farquhar 1922	593	2	8	\N	f	\N	514	5	7
Muncaster	of Muncaster in the County of Cumberland	1917-03-30	1	\N	594	3	8	\N	f	\N	515	5	14
Haliburton	of Windsor in the Province of Nova Scotia and Dominion of Canada	1907-04-21	1	\N	595	2	8	\N	f	\N	516	5	9
Kitchener of Khartoum	and of Aspall in the County of Suffolk	1916-06-05	1	cr  V Kitchener of Khartoum (SR) 1902, E Kitchener (SR) 1914	596	2	8	\N	f	\N	517	5	12
Cromer	of Cromer in the County of Norfolk	\N	\N	cr E of Cromer 1901	597	7	12	\N	f	\N	518	5	4
Currie	of Hawley in the County of Southampton	1906-05-12	1	\N	598	2	8	\N	f	\N	519	5	4
Crewe	of Crewe in the County Palatine of Chester	1945-06-20	1	cr M of Crewe 1911	563	7	6	\N	t	\N	520	5	4
Burton	of Burton-on-Trent and of Rangemore both in the County of Stafford	\N	\N	SR to dau	590	8	8	\N	f	2	522	5	3
Dorchester	of Dorchester in the County of Oxford	1963-01-20	2	\N	602	2	8	\N	f	\N	559	5	5
Glanusk	of Glanusk Park in the County of Brecknock	\N	\N	\N	599	2	8	\N	f	\N	523	5	8
Plymouth	in the County of Devon	\N	\N	\N	638	7	6	\N	t	\N	557	5	17
Brampton	of Brampton in the County of Huntingdon	1907-10-06	1	\N	600	2	8	\N	f	\N	524	5	3
Cranworth	of Letton and Cranworth in the County of Norfolk	\N	\N	\N	601	2	8	\N	f	\N	525	5	4
Pauncefote	of Preston in the County of Gloucester	1902-05-24	1	\N	603	2	8	\N	f	\N	526	5	17
Robertson	of Forteviot in the County of Perth	1909-02-02	1	vice L Watson deceased	605	1	8	\N	f	\N	527	5	19
Northcote	of the City and County of the City of Exeter	1911-09-29	1	\N	606	2	8	\N	f	\N	528	5	15
Avebury	of Avebury in the County of Wilts	\N	\N	\N	607	2	8	\N	f	\N	529	5	2
Lindley	of East Carleton in the County of Norfolk	1921-12-09	1	vice L Morris resigned	608	1	8	\N	f	\N	530	5	13
Killanin	of Galway in the County of Galway	\N	\N	\N	609	8	8	\N	f	\N	531	5	12
O'Brien	of Kilfenora in the County of Clare	1914-09-07	1	\N	610	2	8	\N	f	\N	532	5	16
Goschen	of Hawkhurst in the County of Kent	\N	\N	\N	613	2	12	\N	f	\N	534	5	8
Ridley	\N	\N	\N	\N	614	2	12	\N	f	\N	535	5	19
Milner	of St James's in the County of London and of Capetwon in the Colony of the Cape of Good Hope	1925-05-13	1	cr V Milner 15 July 1902	616	2	8	\N	f	\N	536	5	14
Heneage	of Hainton in the County of Lincoln	1967-02-19	3	\N	576	2	8	\N	f	\N	537	5	9
Roos	of Belvoir in the County of Leicester	\N	\N	\N	578	8	8	\N	f	\N	538	5	19
Kinross	of Glasclune in the County of Haddington	\N	\N	\N	623	2	8	\N	f	\N	539	5	12
Shuttleworth	of Gawthorpe in the County Palatine of Lancaster	\N	\N	\N	624	2	8	\N	f	\N	540	5	20
Allerton	of Chapel Allerton, Leeds, in the West Riding of the County of York	1991-07-01	3	\N	625	2	8	\N	f	\N	541	5	2
Barrymore	of Barrymore in the County of Cork	1925-02-22	1	\N	626	2	8	\N	f	\N	542	5	3
Grenfell	of Kilvey in the County of Glamorgan	\N	\N	\N	627	2	8	\N	f	\N	543	5	8
Knollys	of Caversham in the County of Oxford	\N	\N	cr V Knollys 1911	628	2	8	\N	f	\N	544	5	12
Redesdale	of Redesdale in the County of Northumberland	\N	\N	5th L died 3 March 1991	629	2	8	\N	f	\N	545	5	19
Burnham	of Hall Barn in the parish of Beaconsfield in the County of Buckingham	\N	\N	subsumed in viscounty 1919-33; 5th L died 18 June 1993	631	2	8	\N	f	\N	546	5	3
Biddulph	of Ledbury in the County of Hereford	\N	\N	?th L died 3 Nov 1988	632	2	8	\N	f	\N	547	5	3
Estcourt	of Estcourt in the parish of Shipton Moyne in the County of Gloucester and of Darrington in the West Riding of the County of York	1915-01-12	1	\N	633	2	8	\N	f	\N	548	5	6
Armstrong	of Bamburgh and Cragside in the County of Northumberland	1987-10-01	3	\N	634	2	8	\N	f	\N	549	5	2
St Helier	of St Helier in the Island of Jersey and of Arlington Manor in the County of Berks	1905-04-09	1	St. Helier	635	2	8	\N	f	\N	550	5	20
Dunedin	of Stenton in the County of Perth	1942-08-21	1	cr V Dunedin 1926; apptd L of A in O 1913	636	2	8	\N	f	\N	551	5	5
Selby	of the City of Carlisle	\N	\N	4th V died 10 Jan 1997	637	2	12	\N	f	\N	552	5	20
Iveagh	of Iveagh in the County of Down	\N	\N	cr E of Iveagh 1919	639	7	12	\N	f	\N	553	5	10
Leith of Fyvie	of Fyvie in the County of Aberdeen	1925-11-14	1	\N	640	2	8	\N	f	\N	554	5	13
Althorp	of Great Brington in the County of Northampton	\N	\N	succ as 6th E Spencer 1910	641	2	12	\N	f	\N	555	5	2
Cromer	in the County of Norfolk	\N	\N	3rd E died 16 March 1991	617	7	6	\N	t	\N	556	5	4
Linlithgow	in the County of Linlithgow or West Lothian	\N	\N	already also 5th L Hopetoun (cr 1809)	630	7	9	\N	t	\N	558	5	13
Waleran	of Uffcalme in the County of Devon	1966-04-04	2	\N	646	2	8	\N	f	\N	564	5	24
Knaresborough	of Kirby Hall in the County of York	1929-03-03	1	\N	647	2	8	\N	f	\N	565	5	12
Northcliffe	of the Isle of Thanet in the County of Kent	1922-08-14	1	cr V Northcliffe 1918	648	2	8	\N	f	\N	566	5	15
Tredegar	of Tredegar in the County of Monmouth	1913-03-11	1	same title to 3rd L Tredegar, 1926	649	7	12	\N	f	\N	567	5	21
Michelham	of Hellingly in the County of Sussex	1984-03-29	2	\N	650	2	8	\N	f	\N	568	5	14
Faber	of Butterwick in the County of Lincoln	1920-09-17	1	\N	651	2	8	\N	f	\N	569	5	7
Desborough	of Taplow in the County of Buckingham	1945-01-09	1	\N	652	2	8	\N	f	\N	570	5	5
St Aldwyn	of Coln St Aldwyn in the County of Gloucester	\N	\N	cr E St Aldwyn 1915	653	2	12	\N	f	\N	571	5	20
Loreburn	of Dumfries in the County of Dumfries	1923-11-30	1	cr E Loreburn 1911	654	2	8	\N	f	\N	572	5	13
Weardale	of Stanhope in the County of Durham	1923-03-01	1	\N	656	2	8	\N	f	\N	573	5	24
Haversham	of Bracknell in the County of Berks	1917-05-10	1	\N	657	2	8	\N	f	\N	574	5	9
Hemphill	of Rathkenny and of Cashell in the County of Tipperary	\N	\N	\N	658	2	8	\N	f	\N	575	5	9
Joicey	of Chester-le-Street in the County of Durham	\N	\N	\N	659	2	8	\N	f	\N	576	5	11
Fitzmaurice	of Leigh in the County of Wilts	1935-06-21	1	\N	655	2	8	\N	f	\N	577	5	7
Churchill	of Rolleston in the County of Leicester	2017-10-18	3	\N	621	7	12	\N	f	\N	578	5	4
Courtney of Penwith	in the County of Cornwall	1918-05-11	1	\N	663	2	8	\N	f	\N	579	5	4
Eversley	of Old Ford in the County of London	1928-04-19	1	\N	664	2	8	\N	f	\N	580	5	6
Pirrie	of the City of Belfast	1924-06-06	1	cr V Pirrie 1921	665	2	8	\N	f	\N	581	5	17
Glantawe	of Swansea in the County of Glamorgan	1915-07-27	1	\N	666	2	8	\N	f	\N	582	5	8
Armitstead	of Castlehill in the City of Dundee	1915-12-07	1	\N	667	2	8	\N	f	\N	583	5	2
Collins	of Kensington in the County of London	1911-01-03	1	\N	669	1	8	\N	f	\N	585	5	4
Airedale	of Gledhow in the West Riding of the County of York	1996-03-19	4	\N	670	2	8	\N	f	\N	586	5	2
Swaythling	of Swaythling in the County of Southampton	\N	\N	\N	671	2	8	\N	f	\N	587	5	20
Blyth	of Blythwood in the County of Essex	\N	\N	\N	672	2	8	\N	f	\N	588	5	3
Peckover	of Wisbech in the County of Cambridge	1919-10-21	1	\N	673	2	8	\N	f	\N	589	5	17
Morley of Blackburn	in the County Palatine of Lancaster	1923-09-23	1	\N	674	2	8	\N	f	\N	590	5	14
Wolverhampton	of Wolverhampton in the County of Stafford	1943-03-09	2	\N	675	2	12	\N	f	\N	591	5	24
Lochee	of Gowrie in the County of Perth	1911-09-13	1	\N	676	2	8	\N	f	\N	592	5	13
MacDonnell	of Swinford in the County of Mayo	1925-06-09	1	\N	677	2	8	\N	f	\N	593	5	14
Marchamley	of Hawkstone in the County of Salop	\N	\N	3rd L died 26 May 1994	678	2	8	\N	f	\N	594	5	14
Holden	of Alston in the County of Cumberland	1951-07-06	3	\N	679	2	8	\N	f	\N	595	5	9
St Davids	of Roch Castle in the County of Pembroke	\N	\N	cr V St Davids 1918	680	2	8	\N	f	\N	596	5	20
Gorell	of Brampton in the County of Derby	\N	\N	\N	682	2	8	\N	f	\N	597	5	8
Fisher	of Kilverstone in the County of Norfolk	\N	\N	\N	685	2	8	\N	f	\N	599	5	7
Kilbracken	of Killegar in the County of Leitrim	\N	\N	\N	686	2	8	\N	f	\N	600	5	12
Gladstone	of the County of Lanark	1930-03-06	1	\N	687	2	12	\N	f	\N	601	5	8
Atkinson	of Glenwilliam in the County of Limerick	1932-03-13	1	vice L Lindley resigned	642	1	8	\N	f	\N	561	5	2
Sanderson	of Armthorpe in the County of York	1923-03-21	1	\N	643	2	8	\N	f	\N	562	5	20
Mersey	of Toxteth in the County Palatine of Lancaster	\N	\N	cr V Mersey 1916	689	2	8	\N	f	\N	603	5	14
Islington	of Islington in the County of London	1936-12-06	1	\N	690	2	8	\N	f	\N	604	5	10
Southwark	of Southwark in the County of London	1929-02-23	1	\N	692	2	8	\N	f	\N	605	5	20
Ilkeston	of Ilkeston in the County of Derby	1952-01-04	2	\N	693	2	8	\N	f	\N	606	5	10
Devonport	of Wittington in the County of Buckingham	\N	\N	cr V Devonport 1917	694	2	8	\N	f	\N	607	5	5
Cowdray	of Midhurst in the County of Sussex	\N	\N	cr V Cowdray 1917	695	2	8	\N	f	\N	608	5	4
Rotherham	of Broughton in the County Palatine of Lancaster	1950-01-24	2	\N	696	2	8	\N	f	\N	609	5	19
Furness	of Grantley in the West Riding of the County of York	1995-05-01	3	2nd L cr V Furness 1918	697	2	8	\N	f	\N	610	5	7
Hardinge of Penshurst	in the County of Kent	\N	\N	\N	699	2	8	\N	f	\N	611	5	9
de Villiers	of Wynberg in the Province of the Cape of Good Hope and Union of South Africa	\N	\N	de Villiers	700	2	8	\N	f	\N	612	5	5
Robson	of Jesmond in the County of Northumberland	1918-09-11	1	vice L Collins resigned	701	1	8	\N	f	\N	613	5	19
Haldane	of Cloan in the County of Perth	1928-08-19	1	\N	702	2	12	\N	f	\N	614	5	9
Glenconner	of Glen in the County of Peebles	\N	\N	\N	703	2	8	\N	f	\N	615	5	8
Winterstoke	of Blagdon in the County of Somerset	1911-01-29	1	\N	661	2	8	\N	f	\N	616	5	24
Colebrooke	of Stebunheath in the County of Middlesex	1939-02-28	1	\N	662	2	8	\N	f	\N	617	5	4
Pentland	of Lyth in the County of Caithness	1984-02-14	2	\N	681	2	8	\N	f	\N	618	5	17
Merthyr	of Senghenydd in the County of Glamorgan	\N	\N	\N	708	2	8	\N	f	\N	619	5	14
Inchcape	of Strathnaver in the County of Sutherland	\N	\N	cr V Inchcape 1924, E of Inchcape 1929	709	2	8	\N	f	\N	620	5	10
Rowallan	of Rowallan in the County of Ayr	\N	\N	3rd L died 24 June 1993	710	2	8	\N	f	\N	621	5	19
Ashton of Hyde	in the County of Chester	\N	\N	\N	711	2	8	\N	f	\N	622	5	2
Charnwood	of Castle Donington in the County of Leicester	1955-02-01	2	\N	712	2	8	\N	f	\N	623	5	4
Elibank	of Elibank in the County of Selkirk	1962-12-05	3	\N	715	4	12	\N	f	\N	624	5	6
Loreburn	\N	1923-11-30	1	\N	716	7	6	\N	f	\N	625	5	13
Knollys	of Caversham in the County of Oxford	\N	\N	\N	717	7	12	\N	f	\N	626	5	12
Brassey	\N	1919-11-12	2	\N	718	7	6	\N	f	\N	627	5	3
Chilston	of Boughton Malherbe in the County of Kent	\N	\N	\N	720	2	12	\N	f	\N	629	5	4
Emmott	of Oldham in the County Palatine of Lancaster	1926-12-13	1	\N	722	2	8	\N	f	\N	630	5	6
Strachie	of Sutton Court in the County of Somerset	1973-05-17	2	\N	723	2	8	\N	f	\N	631	5	20
Pontypridd	of Cardiff in the County of Glamorgan	1927-12-14	1	\N	725	2	8	\N	f	\N	632	5	17
Hollenden	of Leigh in the County of Kent	\N	\N	\N	726	2	8	\N	f	\N	633	5	9
Channing of Wellingborough	in the County of Northampton	1926-02-20	1	\N	729	2	8	\N	f	\N	635	5	4
Nicholson	of Roundhay in the County of York	1918-09-13	1	\N	730	2	8	\N	f	\N	636	5	15
Murray of Elibank	of Elibank in the County of Selkirk	1920-09-13	1	heir to V Elibank but d.v.p.	731	2	8	\N	f	\N	637	5	14
Moulton	of Bank in the County of Southampton	1921-03-09	1	\N	732	1	8	\N	f	\N	638	5	14
Whitburgh	of Whitburgh in the County of Midlothian	1967-09-29	1	father died 31.7.12, before LP	733	2	8	\N	f	\N	639	5	24
Sydenham of Combe	of Dulverton in the County of Devon	1933-02-07	1	\N	734	2	8	\N	f	\N	640	5	20
Lincolnshire	\N	1928-06-13	1	3rd L Carrington	727	7	9	\N	t	\N	641	5	13
Ashby St Ledgers	of Ashby St Ledgers in the County of Northampton	\N	\N	succ as 2nd L Wimborne 1914; cr V 1918	688	2	8	\N	f	\N	602	5	2
Reading	of Erleigh in the County of Berks	\N	\N	cr V Reading 1916 etc.	739	2	8	\N	f	\N	645	5	19
Strathclyde	of Sandyford in the County of Lanark	1928-10-02	1	\N	740	2	8	\N	f	\N	646	5	20
Parmoor	of Frieth in the County of Buckingham	\N	\N	\N	741	2	8	\N	f	\N	647	5	17
Rothermere	of Hemsted in the County of Kent	\N	\N	cr V Rothermere 1919	742	2	8	\N	f	\N	648	5	19
Bryce	of Dechmount in the County of Lanark	1922-01-22	1	\N	743	2	12	\N	f	\N	649	5	3
Buxton	of Newtimber in the County of Sussex	1934-10-15	1	cr E Buxton 1920	744	2	12	\N	f	\N	650	5	3
Cozens-Hardy	of Letheringsett in the County of Norfolk	1975-09-11	4	\N	745	2	8	\N	f	\N	651	5	4
D'Abernon	of Esher in the County of Surrey	1941-11-01	1	cr V D'Abernon 1926	746	2	8	\N	f	\N	652	5	5
Ranksborough	of Ranksborough in the County of Rutland	1921-02-28	1	\N	747	2	8	\N	f	\N	653	5	19
Lyell	of Kinnordy in the County of Forfar	2017-01-11	3	\N	748	2	8	\N	f	\N	654	5	13
St Audries	of St Audries in the County of Somerset	1971-10-16	2	St. Audries	706	2	8	\N	f	\N	655	5	20
Carmichael	of Skirling in the County of Peebles	1926-01-16	1	\N	724	2	8	\N	f	\N	656	5	4
Stamfordham	of Stamfordham in the County of Northumberland	1931-03-31	1	\N	707	2	8	\N	f	\N	657	5	20
Bertie of Thame	in the County of Oxford	1954-08-29	2	cr V Bertie of Thame 1918	755	2	8	\N	f	\N	659	5	3
Muir-Mackenzie	of Delvine in the County of Perth	1930-05-22	1	\N	756	2	8	\N	f	\N	660	5	14
French of Ypres	and of High Lake in the County of Roscommon	1988-03-04	3	cr E of Ypres 1922	757	2	12	\N	f	\N	661	5	7
Mersey	of Toxteth in the County Palatine of Lancaster	\N	\N	4th V succeeded as 13th L Nairne 20 Oct 1995	758	7	12	\N	f	\N	662	5	14
Beresford	of Metemmeh and of Curraghmore in the County of Waterford	1919-09-06	1	\N	759	2	8	\N	f	\N	663	5	3
Faringdon	of Buscot Park in the County of Berks	\N	\N	\N	760	2	8	\N	f	\N	664	5	7
Astor	of Hever Castle in the County of Kent	\N	\N	cr V Astor 1917	762	2	8	\N	f	\N	666	5	2
Rathcreedan	of Bellehatch Park in the County of Oxford	\N	\N	2nd L died 15 May 1990	763	2	8	\N	f	\N	667	5	19
Rhondda	of Llanwern in the County of Monmouth	1918-07-03	1	cr V Rhondda (with SR) 1918	764	2	8	\N	f	\N	668	5	19
Chaplin	of Saint Oswald's, Blankney, in the County of Lincoln	1981-12-18	3	\N	765	2	12	\N	f	\N	669	5	4
Reading	of Erleigh in the County of Berks	\N	\N	cr E of Reading 1917, etc.	766	7	12	\N	f	\N	670	5	19
Somerleyton	of Somerleyton in the County of Suffolk	\N	\N	\N	767	2	8	\N	f	\N	671	5	20
Carnock	of Carnock in the County of Stirling	\N	\N	\N	768	2	8	\N	f	\N	672	5	4
Anslow	of Iver in the County of Buckingham	1933-08-20	1	\N	769	2	8	\N	f	\N	673	5	2
Glentanar	of Glen Tanar in the County of Aberdeen	1971-06-28	2	\N	770	2	8	\N	f	\N	674	5	8
Roundway	of Devizes in the County of Wilts	1944-03-29	2	\N	771	2	8	\N	f	\N	675	5	19
Grey of Fallodon	in the County of Northumberland	1933-09-07	1	\N	772	2	12	\N	f	\N	676	5	8
Stuart of Wortley	of the City of Sheffield	1926-04-24	1	\N	775	2	8	\N	f	\N	677	5	20
Cowdray	of Cowdray in the County of Sussex	\N	\N	\N	776	7	12	\N	f	\N	678	5	4
Harcourt	of Stanton Harcourt in the County of Oxford	1979-01-03	2	\N	778	2	12	\N	f	\N	680	5	9
Gainford	of Headlam in the County of Durham	\N	\N	\N	779	2	8	\N	f	\N	681	5	8
Forteviot	of Dupplin in the County of Perth	\N	\N	3rd L died 25 March 1993	780	2	8	\N	f	\N	682	5	7
Sumner	of Ibstone in the County of Buckingham	1934-05-24	1	cr V Sumner 1927	737	1	8	\N	f	\N	643	5	20
Alverstone	of Alverstone in the County of Southampton	1915-12-15	1	never introduced	738	7	12	\N	f	\N	644	5	2
Doverdale	of Westwood Park in the County of Worcester	1949-01-18	3	\N	782	2	8	\N	f	\N	684	5	5
Atholstan	of Huntingdon in the Province of Quebec in the Dominion of Canada and of the City of Edinburgh	1938-01-28	1	\N	783	2	8	\N	f	\N	685	5	2
Annesley	of Bletchington in the County of Oxford	1949-10-06	2	\N	784	3	8	\N	f	\N	686	5	2
Lambourne	of Lambourne in the County of Essex	1928-12-26	1	\N	785	2	8	\N	f	\N	687	5	13
Treowen	of Treowen and Llanarth in the County of Monmouth	1933-10-18	1	\N	786	2	8	\N	f	\N	688	5	21
Leverhulme	of Bolton-le-Moors in the County Palatine of Lancaster	2000-07-04	3	cr V Leverhulme 1922	788	2	8	\N	f	\N	690	5	13
Devonport	of Wittington in the County of Buckingham	\N	\N	\N	789	7	12	\N	f	\N	691	5	5
Colwyn	of Colwyn Bay in the County of Denbigh	\N	\N	\N	790	2	8	\N	f	\N	692	5	4
Astor	of Hever Castle in the County of Kent	\N	\N	\N	791	7	12	\N	f	\N	693	5	2
Gisborough	of Cleveland in the County of York	\N	\N	\N	792	2	8	\N	f	\N	694	5	8
Cunliffe	of Headley in the County of Surrey	\N	\N	\N	750	2	8	\N	f	\N	695	5	4
Wrenbury	of Old Castle in the County of Sussex	\N	\N	\N	752	2	8	\N	f	\N	696	5	24
Southborough	of Southborough in the County of Kent	1992-06-15	4	\N	797	2	8	\N	f	\N	697	5	20
Northcliffe	of St Peter in the County of Kent	1922-08-14	1	\N	799	7	12	\N	f	\N	698	5	15
Morris	of St John's in the Dominion of Newfoundland and of the City of Waterford	\N	\N	\N	801	2	8	\N	f	\N	699	5	14
Furness	of Grantley in the West Riding of the County of York	1995-05-01	2	\N	802	7	12	\N	f	\N	700	5	7
Cawley	of Prestwich in the County Palatine of Lancaster	\N	\N	\N	803	2	8	\N	f	\N	701	5	4
Armaghdale	of Armagh in the County of Armagh	1924-06-08	1	\N	804	2	8	\N	f	\N	702	5	2
Queenborough	of Queenborough in the County of Kent	1949-09-22	1	\N	805	2	8	\N	f	\N	703	5	18
Terrington	of Huddersfield in the County of York	\N	\N	\N	806	2	8	\N	f	\N	704	5	21
Wimborne	of Canford Magna in the County of Dorset	\N	\N	1st L Ashby St. Ledgers 1910	807	7	12	\N	f	\N	705	5	24
Glenarthur	of Carlung in the County of Ayr	\N	\N	\N	811	2	8	\N	f	\N	706	5	8
Weir	of Eastwood in the County of Renfrew	\N	\N	cr V Weir 1938	810	2	8	\N	f	\N	707	5	24
Glanely	of St Fagans in the County of Glamorgan	1942-06-28	1	\N	812	2	8	\N	f	\N	708	5	8
Wittenham	of Wallingford in the County of Berks	1931-02-01	1	\N	813	2	8	\N	f	\N	709	5	24
Shandon	of the City of Cork	1930-09-10	1	\N	814	2	8	\N	f	\N	711	5	20
Phillimore	of Shiplake in the County of Oxford	\N	\N	3rd L died 26 Feb 1990; 4th L died 29 March 1994	815	2	8	\N	f	\N	712	5	17
Lee of Fareham	of Chequers in the County of Buckingham	1947-07-21	1	cr V Lee of Fareham 1922	816	2	8	\N	f	\N	713	5	13
Bertie of Thame	in the County of Oxford	1954-08-29	2	\N	817	7	12	\N	f	\N	714	5	3
Bledisloe	of Lydney in the County of Gloucster	\N	\N	cr V Bledisloe 1935	818	2	8	\N	f	\N	715	5	3
Sterndale	of King Sterndale in the County of Derby	1923-08-17	1	\N	820	2	8	\N	f	\N	716	5	20
Downham	of Fulham in the County of London	1920-07-02	1	\N	821	2	8	\N	f	\N	717	5	5
Birkenhead	of Birkenhead in the County of Chester	1985-02-18	3	cr V Birkenhead 1921, E of Birkenhead 1922	822	2	8	\N	f	\N	718	5	3
Ernle	of Chelsea in the County of London	1937-07-01	1	\N	823	2	8	\N	f	\N	719	5	6
Carisbrooke	\N	1960-02-23	1	\N	796	2	9	\N	t	\N	720	5	4
Roe	of the Borough of Derby	1923-06-07	1	\N	781	2	8	\N	f	\N	683	5	19
Allenby of Megiddo	and of Felixstowe in the County of Suffolk	\N	\N	SR to brother & hm of body	840	2	12	\N	f	1	760	5	2
Inverforth	of Southgate in the County of Middlesex	\N	\N	\N	824	2	8	\N	f	\N	722	5	10
Midleton	\N	1979-11-02	2	\N	852	7	6	\N	t	\N	758	5	14
Sinha	of Raipur in the Presidency of Bengal	\N	\N	3rd L died 6 Jan 1989; 4th L died 25 July 1992	825	2	8	\N	f	\N	723	5	20
Askwith	of Saint Ives in the County of Huntingdon	1942-06-02	1	\N	826	2	8	\N	f	\N	724	5	2
Finlay	of Nairn in the County of Nairn	1945-06-30	2	\N	827	7	12	\N	f	\N	725	5	7
Chalmers	of Northiam in the County of Sussex	1938-11-17	1	\N	828	2	8	\N	f	\N	726	5	4
Rothermere	of Hemsted in the County of Kent	\N	\N	\N	831	7	12	\N	f	\N	727	5	19
Wyfold	of Accrington in the County Palatine of Lancaster	1999-04-08	3	\N	832	2	8	\N	f	\N	728	5	24
Clwyd	of Abergele in the County of Denbigh	\N	\N	\N	833	2	8	\N	f	\N	729	5	4
Dewar	of Homestall in the County of Sussex	1930-04-11	1	\N	834	2	8	\N	f	\N	730	5	5
Beatty	\N	\N	\N	\N	835	2	6	\N	f	\N	731	5	3
Rawlinson	of Trent in the County of Dorset	1925-03-28	1	\N	839	2	8	\N	f	\N	733	5	19
Byng of Vimy	of Thorpe-le-Soken in the County of Essex	1935-06-06	1	cr V Byng of Vimy 1928	841	2	8	\N	f	\N	734	5	3
Horne	of Stirkoke in the County of Caithness	1929-08-14	1	\N	842	2	8	\N	f	\N	735	5	9
Wavertree	of Delamere in the County of Chester	1933-02-02	1	\N	844	2	8	\N	f	\N	736	5	24
Swinfen	of Chertsey in the County of Surrey	\N	\N	\N	846	2	8	\N	f	\N	737	5	20
Wester Wemyss	of Wemyss in the County of Fife	1933-05-24	1	\N	847	2	8	\N	f	\N	738	5	24
Forster	of Lepe in the County of Southampton	1936-01-15	1	\N	849	2	8	\N	f	\N	740	5	7
Dawson of Penn	of Penn in the County of Buckingham	1945-03-07	1	cr V Dawson of Penn 30 Oct 1936	853	2	8	\N	f	\N	741	5	5
Marshall of Chipstead	of Chipstead in the County of Surrey	1936-03-29	1	\N	858	2	8	\N	f	\N	742	5	14
Cullen of Ashbourne	of Roehampton in the County of Surrey	\N	\N	\N	854	2	8	\N	f	\N	743	5	4
Invernairn	of Strathnairn in the County of Inverness	1936-04-09	1	\N	859	2	8	\N	f	\N	744	5	10
Buxton	\N	1934-10-15	1	\N	856	7	6	\N	f	\N	745	5	3
Novar	of Raith in the County of Fife and of Novar in the County of Ross	1934-03-30	1	\N	857	2	12	\N	f	\N	746	5	15
Cable	of Ideford in the County of Devon	1927-03-28	1	\N	860	2	8	\N	f	\N	747	5	4
Ystwyth	of Tan-y-Bwlch in the County of Cardigan	1935-08-21	1	\N	861	2	8	\N	f	\N	748	5	26
Birkenhead	of Birkenhead in the County of Chester	1985-02-18	3	cr E of Birkenhead 1922	868	7	12	\N	f	\N	750	5	3
Bearsted	of Maidstone in the County of Kent	\N	\N	cr V Bearsted 1925	869	2	8	\N	f	\N	751	5	3
FitzAlan of Derwent	of Derwent in the County of Derby	1962-05-17	2	\N	863	2	12	\N	f	\N	752	5	7
Carson	of Duncairn in the County of Antrim	1935-10-22	1	vice L Moulton deceased	864	1	8	\N	f	\N	753	5	4
Chelmsford	of Chelmsford in the County of Essex	\N	\N	\N	865	7	12	\N	f	\N	754	5	4
Long	of Wraxall in the County of Wilts	\N	\N	\N	866	2	12	\N	f	\N	755	5	13
Illingworth	of Denton in the West Riding of the County of York	1942-01-23	1	\N	867	2	8	\N	f	\N	756	5	10
Athlone	\N	1957-01-16	1	\N	794	2	6	\N	t	\N	757	5	2
Milford Haven	\N	\N	\N	\N	795	2	9	\N	t	\N	759	5	14
Ypres	\N	1988-03-04	3	\N	883	7	6	\N	t	\N	801	5	26
Ailwyn	of Honingham in the County of Norfolk	1988-09-27	4	\N	872	2	8	\N	f	\N	763	5	2
Glendyne	of Sanquhar in the County of Dumfries	\N	\N	\N	877	2	8	\N	f	\N	764	5	8
Woolavington	of Lavington in the County of Sussex	1935-08-09	1	\N	878	2	8	\N	f	\N	765	5	24
Ullswater	of Campsea Ashe in the County of Suffolk	\N	\N	\N	873	2	12	\N	f	\N	766	5	22
Pirrie	of the City of Belfast	1924-06-06	1	\N	874	7	12	\N	f	\N	767	5	17
Glenavy	of Milltown in the County of Dublin	1984-06-01	4	\N	875	2	8	\N	f	\N	768	5	8
Trevethin	of Blaengawney in the County of Monmouth	\N	\N	\N	876	2	8	\N	f	\N	769	5	21
Haig	\N	\N	\N	\N	836	2	6	\N	f	\N	770	5	9
Plumer	of Messines and of Bilton in the County of York	1944-02-24	2	cr V Plumer 1929	838	2	8	\N	f	\N	771	5	17
Russell of Liverpool	in the County Palatine of Lancaster	\N	\N	\N	843	2	8	\N	f	\N	772	5	19
Vestey	of Kingswood in the County of Surrey	\N	\N	\N	885	2	8	\N	f	\N	773	5	23
Waring	of Foots Cray in the County of Kent	1940-01-09	1	\N	886	2	8	\N	f	\N	774	5	24
Borwick	of Hawkshead in the County of Lancaster	\N	\N	\N	887	2	8	\N	f	\N	775	5	3
Lawrence of Kingsgate	of Holland House, Kingsgate, in the County of Kent	1927-12-17	1	\N	899	2	8	\N	f	\N	776	5	13
Mildmay of Flete	of Totnes in the County of Devon	1950-05-12	2	\N	888	2	8	\N	f	\N	777	5	14
Maclay	of Glasgow in the County of Lanark	\N	\N	\N	889	2	8	\N	f	\N	778	5	14
Wargrave	of Wargrave Hall in the County of Berks	1936-07-17	1	\N	890	2	8	\N	f	\N	779	5	24
Bethell	of Romford in the County of Essex	\N	\N	\N	891	2	8	\N	f	\N	780	5	3
Lee of Fareham	of Bridport in the County of Dorset	1947-07-21	1	\N	894	7	12	\N	f	\N	781	5	13
Farquhar	\N	1923-08-30	1	\N	895	7	6	\N	f	\N	782	5	7
Daryngton	of Witley in the County of Surrey	1994-04-05	2	\N	896	2	8	\N	f	\N	783	5	5
Kylsant	of Carmarthen in the County of Carmarthen and of Amroth in the County of Pembroke	1937-06-05	1	\N	897	2	8	\N	f	\N	784	5	12
Younger of Leckie	of Alloa in the County of Clackmannan	\N	\N	\N	898	2	12	\N	f	\N	785	5	26
Jessel	of Westminster in the County of London	1990-06-13	2	\N	903	2	8	\N	f	\N	787	5	11
Blanesburgh	of Alloa in the County of Clackmannan	1946-08-17	1	vice V Cave, appointed Lord Chancellor	901	1	8	\N	f	\N	788	5	3
Cecil of Chelwood	of East Grinstead in the County of Sussex	1958-11-24	1	\N	902	2	12	\N	f	\N	789	5	4
Darling	of Langham in the County of Essex	\N	\N	\N	904	2	8	\N	f	\N	790	5	5
Inchcape	of Strathnaver in the County of Sutherland	\N	\N	cr E of Inchcape 1929	905	7	12	\N	f	\N	791	5	10
Banbury of Southam	of Southam in the County of Warwick	\N	\N	\N	906	2	8	\N	f	\N	792	5	3
Danesfort	of Danesfort in the County of Kerry	1935-06-30	1	\N	910	2	8	\N	f	\N	793	5	5
Olivier	of Ramsden in the County of Oxford	1943-02-15	1	\N	907	2	8	\N	f	\N	794	5	16
Thomson	of Cardington in the County of Bedford	1930-10-05	1	\N	908	2	8	\N	f	\N	795	5	21
Arnold	of Hale in the County of Chester	1945-08-03	1	\N	909	2	8	\N	f	\N	796	5	2
Stevenson	of Holmbury in the County of Surrey	1926-06-10	1	\N	911	2	8	\N	f	\N	797	5	20
Merrivale	of Walkhampton in the County of Devon	\N	\N	\N	913	2	8	\N	f	\N	798	5	14
Birkenhead	\N	1985-02-18	3	\N	893	7	6	\N	t	\N	800	5	3
Curzon of Kedleston	\N	1925-03-20	1	\N	870	7	9	\N	f	\N	761	5	4
Mereworth	of Mereworth Castle in the County of Kent	\N	\N	\N	921	3	8	\N	f	\N	802	5	14
Oxford and Asquith	\N	\N	\N	\N	915	2	6	\N	t	\N	840	5	16
Stonehaven	of Ury in the County of Kincardine	\N	\N	cr V Stonehaven 1938	916	2	8	\N	f	\N	803	5	20
Lloyd	of Dolobran in the County of Montgomery	1985-11-05	2	\N	919	2	8	\N	f	\N	804	5	13
Irwin	of Kirby Underdale in the County of York	\N	\N	succ as 3rd V Halifax 1934; cr E of H 1944	920	2	8	\N	f	\N	805	5	10
Hanworth	of Hanworth in the County of Middlesex	\N	\N	cr V Hanworth 1936	922	2	8	\N	f	\N	806	5	9
Barnby	of Blyth in the County of Nottingham	1982-04-30	2	\N	880	2	8	\N	f	\N	807	5	3
Forres	of Glenogil in the County of Forfar	\N	\N	\N	884	2	8	\N	f	\N	808	5	7
Hewart	of Bury in the County of Lancaster	1964-07-23	2	cr V Hewart 1940	881	2	8	\N	f	\N	809	5	9
Greenway	of Stanbridge Earls in the County of Southampton	\N	\N	\N	929	2	8	\N	f	\N	811	5	8
Warrington of Clyffe	of Market Lavington in the County of Wilts	1937-10-26	1	\N	928	2	8	\N	f	\N	812	5	24
Craigavon	of Stormont in the County of Down	\N	\N	\N	930	2	12	\N	f	\N	813	5	4
Hayter	of Chislehurst in the County of Kent	\N	\N	\N	931	2	8	\N	f	\N	814	5	9
Daresbury	of Walton in the County of Chester	\N	\N	2nd L died 15 Feb 1990; ?th L died 9 Sep 1996	934	2	8	\N	f	\N	816	5	5
Dalziel of Wooler	of Wooler in the County of Northumberland	1928-04-18	1	\N	935	2	8	\N	f	\N	817	5	5
Wraxall	of Clyst St George in the County of Devon	\N	\N	\N	937	2	8	\N	f	\N	818	5	24
Cushendun	of Cushendun in the County of Antrim	1934-10-12	1	\N	936	2	8	\N	f	\N	819	5	4
Strickland	of Sizergh Castle in the County of Westmorland	1940-08-22	1	\N	939	2	8	\N	f	\N	820	5	20
Lugard	of Abinger in the County of Surrey	1945-04-11	1	\N	941	2	8	\N	f	\N	821	5	13
Atkin	of Aberdovey in the County of Merioneth	1944-06-25	1	\N	940	1	8	\N	f	\N	822	5	2
Melchett	of Landford in the County of Southampton	2018-08-29	4	\N	945	2	8	\N	f	\N	823	5	14
Hailsham	of Hailsham in the County of Sussex	\N	\N	cr V Hailsham 1929	943	2	8	\N	f	\N	824	5	9
Remnant	of Wenhaston in the County of Suffolk	\N	\N	\N	946	2	8	\N	f	\N	825	5	19
Ebbisham	of Cobham in the County of Surrey	1991-04-12	2	\N	947	2	8	\N	f	\N	826	5	6
Trent	of Nottingham in the County of Nottingham	1956-03-08	2	\N	950	2	8	\N	f	\N	827	5	21
Davidson of Lambeth	of Lambeth in the County of London	1930-05-25	1	\N	948	2	8	\N	f	\N	828	5	5
Tomlin	of Ash in the County of Kent	1935-08-12	1	\N	949	1	8	\N	f	\N	829	5	21
Moynihan	of Leeds in the County of York	\N	\N	3rd L died 25 Nov 1991	951	2	8	\N	f	\N	830	5	14
Fairhaven	of Lode in the County of Cambridge	1966-08-20	1	father died before LP; further creation (SR) 1961	952	2	8	\N	f	\N	831	5	7
Brotherton	of Wakefield in the County of York	1930-10-21	1	\N	955	2	8	\N	f	\N	832	5	3
Thankerton	of Thankerton in the County of Lanark	1948-06-13	1	vice L Shaw resigned	953	1	8	\N	f	\N	833	5	21
Craigmyle	of Craigmyle in the County of Aberdeen	\N	\N	\N	954	8	8	\N	f	\N	834	5	4
Bridgeman	of Leigh in the County of Salop	\N	\N	\N	956	2	12	\N	f	\N	835	5	3
Bayford	of Stoke Trister in the County of Somerset	1940-02-24	1	\N	957	2	8	\N	f	\N	836	5	3
Camrose	of Long Cross in the County of Surrey	\N	\N	cr V Camrose 1941	958	2	8	\N	f	\N	837	5	4
Inchcape	\N	\N	\N	3rd E died 17 March 1994	959	7	6	\N	t	\N	839	5	10
Cave of Richmond	\N	1938-01-07	1	husband died before LP	944	2	6	\N	f	\N	841	5	4
Passfield	of Passfield Corner in the County of Southampton	1947-10-13	1	\N	961	2	8	\N	f	\N	843	5	17
Brentford	of Newick in the County of Sussex	\N	\N	\N	964	2	12	\N	f	\N	844	5	3
Dulverton	of Batsford in the County of Gloucester	\N	\N	2nd L died 17 Feb 1992	965	2	8	\N	f	\N	845	5	5
Luke	of Pavenham in the County of Bedford	\N	\N	2nd L died 25 May 1996	966	2	8	\N	f	\N	846	5	13
Peel	\N	\N	\N	\N	967	7	6	\N	f	\N	847	5	17
Buckland	of Bwlch in the County of Brecon	1928-05-23	1	\N	926	2	8	\N	f	\N	848	5	3
Marley	of Marley in the County of Sussex	1990-03-13	2	\N	975	2	8	\N	f	\N	849	5	14
Baden-Powell	of Gilwell in the County of Essex	\N	\N	\N	973	2	8	\N	f	\N	851	5	3
Dickinson	of Painswick in the County of Gloucester	\N	\N	\N	977	2	8	\N	f	\N	852	5	5
Wakefield	of Hythe in the County of Kent	1941-01-15	1	cr V Wakefield 28 June 1934	978	2	8	\N	f	\N	853	5	24
Kirkley	of Kirkley in the County of Northumberland	1935-09-11	1	\N	979	2	8	\N	f	\N	854	5	12
Trenchard	of Wolfeton in the County of Dorset	\N	\N	cr V Trenchard 31 Jan 1936	980	2	8	\N	f	\N	855	5	21
Noel-Buxton	of Aylsham in the County of Norfolk	\N	\N	\N	982	2	8	\N	f	\N	856	5	15
Sanderson	of Hunmanby in the County of York	1939-03-25	1	\N	983	2	8	\N	f	\N	857	5	20
Howard of Penrith	of Gowbarrow in the County of Cumberland	\N	\N	\N	984	2	8	\N	f	\N	859	5	9
Plender	of Sundridge in the County of Kent	1946-01-19	1	\N	985	2	8	\N	f	\N	860	5	17
Hyndley	of Meads in the County of Sussex	1963-01-05	1	cr V Hyndley 2 Feb 1948	986	2	8	\N	f	\N	861	5	9
Rutherford of Nelson	of Cambridge in the County of Cambridge	1937-10-19	1	\N	987	2	8	\N	f	\N	862	5	19
Rochester	of Rochester in the County of Kent	\N	\N	\N	988	2	8	\N	f	\N	863	5	19
Snowden	of Ickornshaw in the West Riding of the County of York	1937-05-15	1	\N	991	2	12	\N	f	\N	864	5	20
Mamhead	of Exeter in the County of Devon	1945-11-02	1	\N	992	2	8	\N	f	\N	865	5	14
Snell	of Plumstead in the County of Kent	1944-04-21	1	\N	990	2	8	\N	f	\N	866	5	20
Conway of Allington	of Allington in the County of Kent	1937-04-19	1	\N	993	2	8	\N	f	\N	867	5	4
Mount Temple	of Lee in the County of Southampton	1939-07-03	1	\N	994	2	8	\N	f	\N	868	5	14
Selsdon	of Croydon in the County of Surrey	\N	\N	\N	995	2	8	\N	f	\N	869	5	20
Allen of Hurtwood	of Hurtwood in the County of Surrey	1939-03-03	1	\N	996	2	8	\N	f	\N	870	5	2
Moyne	of Bury St Edmunds in the County of Suffolk	\N	\N	2nd L died 6 July 1992	997	2	8	\N	f	\N	871	5	14
Rhayader	of Rhayader in the County of Radnor	1939-09-26	1	\N	998	2	8	\N	f	\N	872	5	19
Sankey	of Moreton in the County of Gloucester	1948-02-06	1	\N	999	7	12	\N	f	\N	873	5	20
Woodbridge	of Ipswich in the County of Suffolk	1949-02-03	1	\N	1001	2	8	\N	f	\N	874	5	24
Essendon	of Essendon in the County of Hertford	1978-07-18	2	\N	1002	2	8	\N	f	\N	875	5	6
Wright	of Durley in the County of Wilts	1964-06-27	1	vice L Dunedin resigned	1000	1	8	\N	f	\N	876	5	24
Davies	of Llandinam in the County of Montgomery	\N	\N	\N	1003	2	8	\N	f	\N	877	5	5
Rankeillour	of Buxted in the County of Sussex	\N	\N	\N	1005	2	8	\N	f	\N	878	5	19
Hutchison of Montrose	of Kirkcaldy in the County of Fife	1950-06-13	1	\N	1006	2	8	\N	f	\N	879	5	9
Reading	\N	\N	\N	\N	925	7	9	\N	t	\N	880	5	19
Sankey	of Moreton in the County of Gloucester	1948-02-06	1	cr V Sankey 1932	960	2	8	\N	f	\N	842	5	20
Milne	of Salonika and of Rubislaw in the County of Aberdeen	\N	\N	\N	1010	2	8	\N	f	\N	883	5	14
Duveen	of Millbank in the City of Westminster	1939-05-25	1	\N	1011	2	8	\N	f	\N	884	5	5
Marks	of Woolwich in the County of Kent	1938-09-24	1	\N	969	2	8	\N	f	\N	885	5	14
Tyrrell	of Avon in the County of Southampton	1947-03-14	1	\N	971	2	8	\N	f	\N	887	5	21
Palmer	of Reading in the County of Berks	\N	\N	3rd L died 26 June 1990	1016	2	8	\N	f	\N	888	5	17
Bingley	of Bramham in the County of York	1947-12-11	1	\N	1017	2	8	\N	f	\N	889	5	3
Rockley	of Lytchett Heath in the County of Dorset	\N	\N	\N	1018	2	8	\N	f	\N	890	5	19
Portsea	of Portsmouth in the County of Southampton	1948-11-01	1	\N	1019	2	8	\N	f	\N	891	5	17
Eltisley	of Croxton in the County of Cambridge	1942-09-02	1	\N	1021	2	8	\N	f	\N	892	5	6
Elton	of Headington in the County of Oxford	\N	\N	\N	1022	2	8	\N	f	\N	893	5	6
Alness	of Alness in the County of Ross and Cromarty	1955-10-06	1	\N	1024	2	8	\N	f	\N	894	5	2
Wakefield	of Hythe in the County of Kent	1941-01-15	1	\N	1025	7	12	\N	f	\N	895	5	24
Hirst	of Witton in the County of Warwick	1943-01-22	1	\N	1026	2	8	\N	f	\N	896	5	9
Wakehurst	of Ardingly in the County of Sussex	\N	\N	\N	1027	2	8	\N	f	\N	897	5	24
Rushcliffe	of Blackfordby in the County of Leicester	1949-11-18	1	\N	1029	2	8	\N	f	\N	898	5	19
Hesketh	of Hesketh in the County Palatine of Lancaster	\N	\N	\N	1030	2	8	\N	f	\N	899	5	9
Bledisloe	of Lydney in the County of Gloucester	\N	\N	\N	1033	7	12	\N	f	\N	901	5	3
Tweedsmuir	of Elsfield in the County of Oxford	\N	\N	2nd L died 20 June 1996	1032	2	8	\N	f	\N	902	5	21
Sysonby	of Wonersh in the County of Surrey	2009-10-23	3	\N	1034	2	8	\N	f	\N	903	5	20
Wigram	of Clewer in the County of Berks	\N	\N	\N	1035	2	8	\N	f	\N	904	5	24
Riverdale	of Sheffield in the County of York	\N	\N	\N	1037	2	8	\N	f	\N	905	5	19
May	of Weybridge in the County of Surrey	\N	\N	\N	1038	2	8	\N	f	\N	906	5	14
Strathcarron	of Banchor in the County of Inverness	\N	\N	\N	1046	2	8	\N	f	\N	908	5	20
Kennet	of the Dene in the County of Wilts	\N	\N	\N	1040	2	8	\N	f	\N	909	5	12
Maugham	of Hartfield in the County of Sussex	1958-03-23	1	vice L Tomlin deceased; cr V Maugham 22 Sep 1939	1041	1	8	\N	f	\N	910	5	14
Roche	of Chadlington in the County of Oxford	1956-12-22	1	vice L Wright appointed MR	1042	1	8	\N	f	\N	911	5	19
Swinton	of Masham in the County of York	\N	\N	cr E of Swinton 5 May 1955	1043	2	12	\N	f	\N	912	5	20
Monsell	of Evesham in the County of Worcester	1993-11-28	2	\N	1044	2	12	\N	f	\N	913	5	14
Trenchard	of Wolfeton in the County of Dorset	\N	\N	\N	1048	7	12	\N	f	\N	915	5	21
Glenravel	of Kensington in the County of London	1937-06-13	1	\N	1049	2	8	\N	f	\N	916	5	8
Kemsley	of Farnham Royal in the County of Buckingham	\N	\N	cr V Kemsley 12 Sep 1945	1050	2	8	\N	f	\N	917	5	12
Catto	of Cairncatto in the County of Aberdeen	\N	\N	\N	1051	2	8	\N	f	\N	918	5	4
Cautley	of Lindfield in the County of Sussex	1946-09-21	1	\N	1053	2	8	\N	f	\N	919	5	4
Hailey	of Sharpur in the Punjab and of Newport Pagnell in the County of Buckingham	1969-06-01	1	\N	1054	2	8	\N	f	\N	920	5	9
Brocket	of Brocket Hall in the County of Hertford	\N	\N	\N	1008	2	8	\N	f	\N	881	5	3
Horder	of Ashford in the County of Southampton	1997-07-02	2	\N	1009	2	8	\N	f	\N	882	5	9
Austin	of Longbridge in the City of Birmingham	1941-05-23	1	\N	1055	2	8	\N	f	\N	921	5	2
Rennell	of Rodd in the County of Hereford	\N	\N	\N	1013	2	8	\N	f	\N	922	5	19
Mottistone	of Mottistone in the County of Southampton	\N	\N	\N	1014	2	8	\N	f	\N	923	5	14
Iliffe	of Yattendon in the County of Berks	\N	\N	2nd L died 15 Feb 1996	1015	2	8	\N	f	\N	924	5	10
McGowan	of Ardeer in the County of Ayr	\N	\N	\N	1061	2	8	\N	f	\N	925	5	14
Addison	of Stallingborough in the County of Lincoln	\N	\N	cr V Addison 2 July 1945	1063	2	8	\N	f	\N	926	5	2
Denham	of Weston Underwood in the County of Buckingham	\N	\N	\N	1064	2	8	\N	f	\N	927	5	5
Rea	of Eskdale in the County of Cumberland	\N	\N	\N	1067	2	8	\N	f	\N	928	5	19
Chatfield	of Ditchling in the County of Sussex	2007-09-30	2	\N	1068	2	8	\N	f	\N	929	5	4
Cadman	of Silverdale in the County of Stafford	\N	\N	\N	1069	2	8	\N	f	\N	930	5	4
Baldwin of Bewdley	\N	\N	\N	\N	1070	2	6	\N	f	\N	931	5	3
Samuel	of Mount Carmel and Toxteth in the City of Liverpool	\N	\N	\N	1071	2	12	\N	f	\N	932	5	20
Horne of Slamannan	of Slamannan in the County of Stirling	1940-09-03	1	\N	1073	2	12	\N	f	\N	934	5	9
Kenilworth	of Kenilworth in the County of Warwick	\N	\N	\N	1075	2	8	\N	f	\N	936	5	12
Davidson	of Little Gaddesden in the County of Hertford	\N	\N	\N	1076	2	12	\N	f	\N	937	5	5
Southwood	of Fernhurst in the County of Sussex	1946-04-10	1	cr V Southwood 25 Jan 1946	1077	2	8	\N	f	\N	938	5	20
Pender	of Porthcurnow in the County of Cornwall	\N	\N	\N	1078	2	8	\N	f	\N	939	5	17
Nuffield	of Nuffield in the County of Oxford	1963-08-22	1	\N	1080	7	12	\N	f	\N	940	5	15
Romer	of New Romney in the County of Kent	1944-08-19	1	vice L Roche resigned	1079	1	8	\N	f	\N	941	5	19
Roborough	of Maristow in the County of Devon	\N	\N	2nd L died 30 June 1992	1081	2	8	\N	f	\N	942	5	19
Birdwood	of Anzac and of Totnes in the County of Devon	2015-07-11	3	\N	1082	2	8	\N	f	\N	943	5	3
Brassey of Apethorpe	of Apethorpe in the County of Northampton	\N	\N	\N	1083	2	8	\N	f	\N	944	5	3
Perry	of Stock Harvard in the County of Essex	1956-06-17	1	\N	1085	2	8	\N	f	\N	945	5	17
Weir	of Eastwood in the County of Renfrew	\N	\N	\N	1087	7	12	\N	f	\N	946	5	24
Porter	of Longfield in the County of Tyrone	1956-02-13	1	vice L Maugham appointed Lord Chancellor	1086	1	8	\N	f	\N	947	5	17
Stonehaven	of Ury in the County of Kincardine	\N	\N	subsumed in E of Kintore Sep 1974	1088	7	12	\N	f	\N	948	5	20
Stamp	of Shortlands in the County of Kent	\N	\N	\N	1089	2	8	\N	f	\N	949	5	20
Bicester	of Tusmore in the County of Oxford	\N	\N	\N	1090	2	8	\N	f	\N	950	5	3
Fairfield	of Caldy in the County Palatine of Chester	1945-02-04	1	\N	1091	2	8	\N	f	\N	951	5	7
Milford	of Llanstephan in the County of Radnor	\N	\N	2nd L died 30 Nov 1993	1092	2	8	\N	f	\N	952	5	14
Hankey	of The Chart in the County of Surrey	\N	\N	2nd L died 28 Oct 1996	1093	2	8	\N	f	\N	953	5	9
Harmsworth	of Egham in the County of Surrey	\N	\N	?th L died 2 June 1990	1094	2	8	\N	f	\N	954	5	9
Brooke of Oakley	of Oakley in the County of Northampton	1944-11-17	1	\N	1095	2	8	\N	f	\N	955	5	3
Rotherwick	of Tylney in the County of Southampton	\N	\N	2nd L died 11 June 1996	1096	2	8	\N	f	\N	956	5	19
Bessborough	\N	1993-12-05	2	\N	1066	8	6	\N	t	\N	957	5	3
Willingdon	\N	1979-03-19	2	\N	1052	7	9	\N	t	\N	959	5	24
Mancroft	of Mancroft in the City of Norwich	\N	\N	\N	1060	2	8	\N	f	\N	963	5	14
Maugham	of Hartfield in the County of Sussex	1981-03-13	2	\N	1101	7	12	\N	f	\N	964	5	14
Tryon	of Durnford in the County of Wilts	\N	\N	\N	1102	2	8	\N	f	\N	965	5	21
Simon	of Stackpole Elidor in the County of Pembroke	\N	\N	2nd V died 5 Dec 1993	1103	2	12	\N	f	\N	966	5	20
Croft	of Bournemouth in the County of Southampton	\N	\N	\N	1104	2	8	\N	f	\N	967	5	4
Teviot	of Burghclere in the County of Southampton	\N	\N	\N	1106	2	8	\N	f	\N	968	5	21
Nathan	of Churt in the County of Surrey	\N	\N	\N	1107	2	8	\N	f	\N	969	5	15
Quickswood	of Clothall in the County of Hertford	1956-12-10	1	\N	1111	2	8	\N	f	\N	970	5	18
Hewart	of Bury in the County of Lancaster	1964-07-23	2	\N	1109	7	12	\N	f	\N	971	5	9
Merriman	of Knutdford in the County Palatine of Chester	1962-01-18	1	\N	1112	2	8	\N	f	\N	972	5	14
Kindersley	of West Hoathly in the County of Sussex	\N	\N	\N	1113	2	8	\N	f	\N	973	5	12
Ironside	of Archangel and Ironside in the County of Aberdeen	\N	\N	\N	1114	2	8	\N	f	\N	974	5	10
Vansittart	of Denham in the County of Buckingham	1957-02-14	1	\N	1116	2	8	\N	f	\N	975	5	23
Leathers	of Purfleet in the County of Essex	\N	\N	cr V Leathers 18 Jan 1954	1115	2	8	\N	f	\N	976	5	13
Bennett	of Mickleham in the County of Surrey and of Calgary and Hopewell in the Dominion of Canada	1947-06-27	1	\N	1118	2	12	\N	f	\N	977	5	3
Greene	of Holmbury St Mary in the County of Surrey	1952-04-16	1	\N	1119	2	8	\N	f	\N	978	5	8
Stansgate	of Stansgate in the County of Essex	\N	\N	2nd V disclaimed	1122	2	12	\N	f	\N	979	5	20
Soulbury	of Soulbury in the County of Buckingham	\N	\N	cr V Soulbury 16 July 1954	1120	2	8	\N	f	\N	980	5	20
Sherwood	of Calverton in the County of Nottingham	1970-04-01	1	\N	1121	2	8	\N	f	\N	981	5	20
Latham	of Hendon in the County of Middlesex	\N	\N	\N	1123	2	8	\N	f	\N	982	5	13
Wedgwood	of Barlaston in the County of Stafford	\N	\N	\N	1124	2	8	\N	f	\N	983	5	24
Geddes	of Rolvenden in the County of Kent	\N	\N	\N	1125	2	8	\N	f	\N	984	5	8
Winster	of Witherslack in the County of Westmorland	1961-06-07	1	\N	1126	2	8	\N	f	\N	985	5	24
Clauson	of Hawkshead in the County of Hertford	1946-03-15	1	\N	1127	2	8	\N	f	\N	986	5	4
Keynes	of Tilton in the County of Sussex	1946-04-21	1	\N	1132	2	8	\N	f	\N	987	5	12
Bruntisfield	of Boroughmuir in the City of Edinburgh	\N	\N	\N	1128	2	8	\N	f	\N	988	5	3
Lang of Lambeth	of Lambeth in the County of Surrey	1945-12-05	1	\N	1129	2	8	\N	f	\N	989	5	13
Margesson	of Rugby in the County of Warwick	\N	\N	\N	1130	2	12	\N	f	\N	990	5	14
Keyes	of Zeebrugge and of Dover in the County of Kent	\N	\N	\N	1133	2	8	\N	f	\N	992	5	12
Moran	of Manton in the County of Wilts	\N	\N	\N	1135	2	8	\N	f	\N	993	5	14
Hemingford	of Watford in the County of Hertford	\N	\N	\N	1134	2	8	\N	f	\N	994	5	9
Gretton	of Stapleford in the County of Leicester	\N	\N	\N	1140	2	8	\N	f	\N	996	5	8
Royden	of Frankby in the County Palatine of Chester	1950-11-06	1	\N	1141	2	8	\N	f	\N	997	5	19
Wavell	of Cyrenaica and of Winchester in the County of Southampton	1953-12-24	2	cr E Wavell 1 May 1947	1139	2	12	\N	f	\N	998	5	24
Glentoran	of Ballyalloly in the County of Down	\N	\N	2nd L died 22 July 1995	1099	2	8	\N	f	\N	999	5	8
Ennisdale	of Grateley in the County of Southampton	1963-08-17	1	\N	1097	2	8	\N	f	\N	960	5	6
Greenwood	of Holbourne in the County of London	2003-07-07	3	\N	1058	7	12	\N	f	\N	962	5	8
Caldecote	of Bristol in the County of Gloucester	\N	\N	\N	1100	2	12	\N	f	\N	1001	5	4
Portal	of Laverstoke in the County of Southampton	1949-05-06	1	\N	1152	7	12	\N	f	\N	1003	5	17
Templewood	of Chelsea in the County of Middlesex	1959-05-07	1	\N	1148	2	12	\N	f	\N	1004	5	21
Goddard	of Aldbourne in the County of Wilts	1971-05-29	1	vice L Atkin deceased	1149	1	8	\N	f	\N	1005	5	8
Norman	of St Clere in the County of Kent	1950-02-04	1	\N	1150	2	8	\N	f	\N	1006	5	15
Lloyd-George of Dwyfor	\N	\N	\N	\N	1153	2	6	\N	f	\N	1007	5	13
Hazlerigg	of Noseley in the County of Leicester	\N	\N	\N	1154	2	8	\N	f	\N	1008	5	9
Addison	of Stallingborough in the County of Lincoln	\N	\N	\N	1155	7	12	\N	f	\N	1009	5	2
Hacking	of Chorley in the County Palatine of Lancaster	\N	\N	\N	1156	2	8	\N	f	\N	1010	5	9
Courthope	of Whitligh in the County of Sussex	1955-09-02	1	\N	1157	2	8	\N	f	\N	1011	5	4
Jackson	of Glewstone in the County of Hereford	1954-05-02	1	\N	1159	2	8	\N	f	\N	1012	5	11
Quibell	of Scunthorpe in the County of Lincoln	1962-04-16	1	\N	1160	2	8	\N	f	\N	1013	5	18
Walkden	of Great Bookham in the County of Surrey	1951-04-25	1	\N	1161	2	8	\N	f	\N	1014	5	24
Chetwode	of Chetwode in the County of Buckingham	\N	\N	\N	1162	2	8	\N	f	\N	1015	5	4
Cope	of St Mellons in the County of Monmouth	1946-07-15	1	\N	1163	2	8	\N	f	\N	1016	5	4
Chattisham	of Clitheroe in the County Palatine of Lancaster	1945-08-24	1	\N	1165	2	8	\N	f	\N	1018	5	4
Sandford	of Banbury in the County of Oxford	\N	\N	\N	1166	2	8	\N	f	\N	1019	5	20
Lambert	of South Molton in the County of Devon	1999-10-22	3	\N	1167	2	12	\N	f	\N	1020	5	13
Altrincham	of Tormerton in the County of Gloucester	\N	\N	2nd L disclaimed & died 28.12.2001	1168	2	8	\N	f	\N	1021	5	2
Kemsley	of Dropmore in the County of Buckingham	\N	\N	\N	1171	7	12	\N	f	\N	1022	5	12
Jowitt	of Stevenage in the County of Hertford	1957-08-16	1	cr V Jowitt 20 Jan 1947, E Jowitt 24 Dec 1951	1169	2	8	\N	f	\N	1023	5	11
Pethick-Lawrence	of Peaslake in the County of Surrey	1961-09-17	1	\N	1170	2	8	\N	f	\N	1024	5	17
Llewellin	of Upton in the County of Dorset	1957-01-24	1	\N	1172	2	8	\N	f	\N	1025	5	13
Marchwood	of Penang and of Marchwood in the County of Southampton	\N	\N	\N	1173	7	12	\N	f	\N	1026	5	14
Lyle of Westbourne	of Canford Cliffs in the County of Dorset	1976-08-01	2	\N	1174	2	8	\N	f	\N	1027	5	13
Broadbridge	of Brighton in the County of Sussex	\N	\N	\N	1175	2	8	\N	f	\N	1028	5	3
Alanbrooke	of Brookeborough in the County of Fermanagh	2018-01-10	3	cr V Alanbrooke 29 Jan 1946 (intro as such)	1178	2	8	\N	f	\N	1030	5	2
Broughshane	of Kensington in the County of London	2006-03-24	3	2nd L died 22 Sep 1995	1179	2	8	\N	f	\N	1031	5	3
Ammon	of Camberwell in the County of Surrey	1960-04-02	1	\N	1143	2	8	\N	f	\N	1032	5	2
Henderson	of Westgate in the City and County of Newcastle upon Tyne	1984-04-04	1	\N	1181	2	8	\N	f	\N	1033	5	9
Mountevans	of Chelsea in the County of London	\N	\N	\N	1182	2	8	\N	f	\N	1034	5	14
Courtauld-Thomson	of Dorneywood in the County of Buckingham	1954-11-01	1	\N	1144	2	8	\N	f	\N	1035	5	4
Schuster	of Cerne in the County of Dorset	1956-06-28	1	\N	1146	2	8	\N	f	\N	1036	5	20
Chorley	of Kendal in the County of Westmorland	\N	\N	\N	1186	2	8	\N	f	\N	1037	5	4
Halifax	\N	\N	\N	had been cr 1st L Irwin (1925)	1147	7	6	\N	t	\N	1038	5	9
Abertay	of Tullybelton in the County of Perth	1940-12-06	1	\N	1105	2	8	\N	f	\N	1000	5	2
Southwood	of Fernhurst in the County of Sussex	1946-04-10	1	\N	1191	7	12	\N	f	\N	1042	5	20
Cunningham of Hyndhope	of Kirkhope in the County of Selkirk	1963-06-12	1	\N	1192	7	12	\N	f	\N	1043	5	4
Wavell	\N	1953-12-24	2	\N	1228	7	6	\N	f	\N	1044	5	24
Colgrain	of Everlands in the County of Kent	\N	\N	\N	1194	2	8	\N	f	\N	1045	5	4
Alanbrooke	of Brookeborough in the County of Fermanagh	2018-01-10	3	\N	1195	7	12	\N	f	\N	1046	5	2
Inman	of Knaresborough in the West Riding of the County of York	1979-08-26	1	\N	1196	2	8	\N	f	\N	1047	5	10
Montgomery of Alamein	of Hindhead in the County of Surrey	\N	\N	\N	1197	2	12	\N	f	\N	1048	5	14
Tovey	of Langton Matravers in the County of Dorset	1971-01-12	1	\N	1200	2	8	\N	f	\N	1049	5	21
Gort	of Hamsterley in the County of Durham	1946-03-31	1	\N	1199	3	12	\N	f	\N	1051	5	8
Darwen	of Heys-in-Bowland in the West Riding of the County of York	\N	\N	?th L died 9 Dec 1988	1201	2	8	\N	f	\N	1052	5	5
Wilson	of Libya and of Stowlangtoft in the County of Suffolk	2009-02-01	2	\N	1203	2	8	\N	f	\N	1053	5	24
Beveridge	of Tuggal in the County of Northumberland	1963-03-16	1	\N	1205	2	8	\N	f	\N	1054	5	3
Uvedale of North End	of North End in the County of Middlesex	1974-02-28	1	\N	1206	2	8	\N	f	\N	1055	5	22
Inverchapel	of Loch Eck in the County of Argyll	1951-07-05	1	\N	1204	2	8	\N	f	\N	1056	5	10
Lucas of Chilworth	of Chilworth in the County of Southampton	\N	\N	\N	1207	2	8	\N	f	\N	1057	5	13
Citrine	of Wembley in the County of Middlesex	2006-08-05	3	\N	1209	2	8	\N	f	\N	1058	5	4
Brand	of Eydon in the County of Northampton	1963-08-23	1	\N	1210	2	8	\N	f	\N	1059	5	3
Newall	of Clifton-upon-Dunsmoor in the County of Warwick	\N	\N	\N	1211	2	8	\N	f	\N	1060	5	15
Fraser of North Cape	of Molesey in the County of Surrey	1981-02-12	1	\N	1213	2	8	\N	f	\N	1061	5	7
Oaksey	of Oaksey in the County of Wilts	\N	\N	succ as 3rd L Trevethin 25 Jne 1959	1216	2	8	\N	f	\N	1062	5	16
Ismay	of Wormington in the County of Gloucester	1965-12-17	1	\N	1217	2	8	\N	f	\N	1063	5	10
Hall	of Cynon Valley in the County of Glamorgan	1985-07-24	2	\N	1214	2	12	\N	f	\N	1064	5	9
Normand	of Aberdour in the County of Fife	1962-10-05	1	vice L Macmillan resigned	1215	1	8	\N	f	\N	1065	5	15
Rugby	of Rugby in the County of Warwick	\N	\N	\N	1218	2	8	\N	f	\N	1066	5	19
Layton	of Danehill in the County of Sussex	\N	\N	?th L died 23 Jan 1989	1219	2	8	\N	f	\N	1067	5	13
Simon of Wythenshawe	of Didsbury in the City of Manchester	\N	\N	\N	1220	2	8	\N	f	\N	1068	5	20
Jowitt	of Stevenage in the County of Hertford	1957-08-16	1	cr E Jowitt 24 Dec 1951	1221	7	12	\N	f	\N	1069	5	11
Kershaw	of Prestwich in the County Palatine of Lancaster	\N	\N	\N	1222	2	8	\N	f	\N	1070	5	12
Trefgarne	of Cleddau in the County of Pembroke	\N	\N	\N	1223	2	8	\N	f	\N	1071	5	21
Bruce of Melbourne	of Westminster Gardens in the City of Westminster	1967-08-25	1	\N	1224	2	12	\N	f	\N	1072	5	3
Piercy	of Burford in the County of Oxford	\N	\N	\N	1184	2	8	\N	f	\N	1073	5	17
Morrison	of Tottenham in the County of Middlesex	1997-10-28	2	\N	1185	2	8	\N	f	\N	1074	5	14
Tedder	of Glenguin in the County of Stirling	\N	\N	2nd L died 18 Feb 1994	1190	2	8	\N	f	\N	1075	5	21
Amwell	of Islington in the County of London	\N	\N	2nd L died 12 Oct 1990	1231	2	8	\N	f	\N	1076	5	2
Hyndley	of Meads in the County of Sussex	1963-01-05	1	\N	1235	7	12	\N	f	\N	1078	5	9
Calverley	of the City of Bradford in the West Riding of the County of York	\N	\N	\N	1187	2	8	\N	f	\N	1039	5	4
Rusholme	of Rusholme in the City of Manchester	1977-08-18	1	\N	1188	2	8	\N	f	\N	1040	5	19
Braintree	of Braintree in the County of Essex	1961-05-21	1	\N	1238	2	8	\N	f	\N	1080	5	3
Webb-Johnson	of Stoke-on-Trent in the County of Stafford	1958-05-28	1	\N	1240	2	8	\N	f	\N	1082	5	24
Maenan	of Ellesmere in the County of Salop	1951-09-22	1	\N	1241	2	8	\N	f	\N	1083	5	14
Williams	of Ynyshir in the County of Glamorgan	1966-02-18	1	\N	1242	2	8	\N	f	\N	1084	5	24
Adams	of Ennerdale in the County of Cumberland	1960-08-23	1	\N	1244	2	8	\N	f	\N	1085	5	2
Reid	of Drem in the County of East Lothian	1975-03-29	1	vice L Thankerton deceased	1243	1	8	\N	f	\N	1086	5	19
Boyd-Orr	of Brechin Mearn in the County of Angus	1971-06-25	1	\N	1245	2	8	\N	f	\N	1087	5	3
Badeley	of Badley in the County of Suffolk	1951-09-27	1	\N	1248	2	8	\N	f	\N	1088	5	3
Macdonald of Gwaenysgor	of Gwaenysgor in the County of Flint	2002-01-27	2	\N	1246	2	8	\N	f	\N	1089	5	14
Dugan of Victoria	of Lurgan in the County of Armagh	1951-08-17	1	\N	1249	2	8	\N	f	\N	1090	5	5
Archibald	of Woodside in the City of Glasgow	1996-02-27	2	2nd L disclaimed	1250	2	8	\N	f	\N	1091	5	2
Wilmot of Selmeston	of Selmeston in the County of Sussex	1964-07-22	1	\N	1252	2	8	\N	f	\N	1092	5	24
Bilsland	of Kinrara in the County of Inverness	1970-12-10	1	\N	1253	2	8	\N	f	\N	1093	5	3
Burden	of Hazlebarrow in the County of Derby	\N	\N	\N	1254	2	8	\N	f	\N	1094	5	3
Haden-Guest	of Saling in the County of Essex	\N	\N	4th L died 8 April 1996	1255	2	8	\N	f	\N	1095	5	9
Henderson of Ardwick	of Morton Park in the City of Carlisle	1950-02-26	1	never introduced	1256	2	8	\N	f	\N	1096	5	9
Silkin	of Dulwich in the County of London	\N	\N	\N	1259	2	8	\N	f	\N	1097	5	20
Lawson	of Beamish in the County of Durham	1965-08-03	1	\N	1257	2	8	\N	f	\N	1098	5	13
Douglas of Barloch	of Maxfield in the County of Sussex	1980-03-31	1	\N	1258	2	8	\N	f	\N	1099	5	5
Hurcomb	of Campden Hill in the Royal Borough of Kensington	1975-08-07	1	\N	1260	2	8	\N	f	\N	1100	5	9
Campion	of Bowes in the County of Surrey	1958-04-06	1	\N	1261	2	8	\N	f	\N	1101	5	4
Hives	of Duffield in the County of Derby	\N	\N	\N	1262	2	8	\N	f	\N	1102	5	9
Greenhill	of Townhead in the City of Glasgow	2020-01-13	3	\N	1263	2	8	\N	f	\N	1103	5	8
Ogmore	of Bridgend in the County of Glamorgan	\N	\N	\N	1264	2	8	\N	f	\N	1104	5	16
Morris of Kenwood	of Kenwood in the City of Sheffield	\N	\N	\N	1265	2	8	\N	f	\N	1105	5	14
Molloy	of Ealing in Greater London	2001-05-26	1	\N	1856	5	8	\N	f	\N	1106	5	14
Tucker	of Great Bookham in the County of Surrey	1975-11-17	1	vice L Greene resigned	1266	1	8	\N	f	\N	1108	5	21
Hungarton	of Hungarton in the County of Leicester	1966-06-14	1	\N	1268	2	8	\N	f	\N	1109	5	9
Crook	of Carshalton in the County of Surrey	\N	\N	\N	1229	2	8	\N	f	\N	1110	5	4
Asquith of Bishopstone	of Bishopstone in the County of Sussex	1954-08-24	1	vice L MacDermott appointed LCJ of Northern Ireland	1269	1	8	\N	f	\N	1111	5	2
MacDermott	of Belmont in the City of Belfast	1979-07-13	1	MacDermott; vice L Wright resigned	1227	1	8	\N	f	\N	1112	5	14
Cohen	of Walmer in the County of Kent	1973-05-09	1	vice L Simonds appointed Lord Chancellor	1273	1	8	\N	f	\N	1114	5	4
Ruffside	of Hexham in the County of Northumberland	1958-05-05	1	\N	1274	2	12	\N	f	\N	1115	5	19
Kirkwood	of Bearsden in the County of Dunbarton	\N	\N	\N	1276	2	8	\N	f	\N	1116	5	12
Jowitt	\N	1957-08-16	1	\N	1277	7	6	\N	f	\N	1117	5	11
Mountbatten of Burma	\N	\N	\N	SR to daughters	1233	7	6	\N	f	2	1118	5	14
Douglas of Kirtleside	of Dornock in the County of Dumfries	1969-10-30	1	\N	1237	2	8	\N	f	\N	1079	5	5
Waverley	of Westdean in the County of Sussex	\N	\N	2nd V died 21 Feb 1990	1281	2	12	\N	f	\N	1121	5	24
Mathers	of Newtown St Boswells in the County of Roxburgh	1965-09-26	1	\N	1282	2	8	\N	f	\N	1122	5	14
Thurso	of Ulbster in the County of Caithness	\N	\N	\N	1285	2	12	\N	f	\N	1124	5	21
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	already a life peer; cr V Simonds 1954	1286	8	8	\N	f	\N	1126	5	20
Brookeborough	of Colebrooke in the County of Fermanagh	\N	\N	\N	1287	2	12	\N	f	\N	1127	5	3
Norwich	of Aldwick in the County of Sussex	\N	\N	\N	1288	2	12	\N	f	\N	1128	5	15
Jeffreys	of Burkham in the County of Southampton	\N	\N	\N	1289	2	8	\N	f	\N	1129	5	11
Rathcavan	of The Braid in the County of Antrim	\N	\N	\N	1290	2	8	\N	f	\N	1130	5	19
Percy of Newcastle	of Etchingham in the County of Sussex	1958-04-03	1	\N	1291	2	8	\N	f	\N	1131	5	17
Glyn	of Farnborough in the County of Berks	1960-05-01	1	\N	1293	2	8	\N	f	\N	1132	5	8
Grantchester	of Knightsbridge in the City of Westminster	\N	\N	2nd L died 12 Aug 1995	1294	2	8	\N	f	\N	1133	5	8
Bennett of Edgbaston	of Sutton Coldfield in the County of Warwick	1957-09-29	1	\N	1295	2	8	\N	f	\N	1134	5	3
Woolton	of Liverpool in the County Palatine of Lancaster	\N	\N	cr E of Woolton 1956	1296	7	12	\N	f	\N	1135	5	24
Hore-Belisha	of Devonport in the County of Devon	1957-02-16	1	\N	1299	2	8	\N	f	\N	1136	5	9
Strang	of Stonesfield in the County of Oxford	2014-12-19	2	\N	1300	2	8	\N	f	\N	1137	5	20
Salter	of Kidlington in the County of Oxford	1975-06-27	1	\N	1297	2	8	\N	f	\N	1138	5	20
Keith of Avonholm	of St Bernard's in the City of Edinburgh	1964-06-29	1	vice L Normand resigned	1298	1	8	\N	f	\N	1139	5	12
Leathers	of Purfleet in the County of Essex	\N	\N	2nd V died 21 Jan 1996	1301	7	12	\N	f	\N	1140	5	13
Dovercourt	of Harwich in the County of Essex	1961-04-22	1	\N	1302	2	8	\N	f	\N	1141	5	5
Moore	of Cobham in the County of Surrey	\N	\N	\N	1303	3	8	\N	f	\N	1142	5	14
Coleraine	of Haltemprice in the East Riding of the County of York	\N	\N	\N	1304	2	8	\N	f	\N	1143	5	4
Harvey of Tasburgh	of Tasburgh in the County of Norfolk	\N	\N	\N	1305	2	8	\N	f	\N	1144	5	9
Soulbury	of Soulbury in the County of Buckingham	\N	\N	\N	1306	7	12	\N	f	\N	1145	5	20
Cooper of Culross	of Dunnet in the County of Caithness	1955-07-15	1	\N	1308	2	8	\N	f	\N	1146	5	4
Kenswood	of Saint Marylebone in the County of London	\N	\N	\N	1271	2	8	\N	f	\N	1147	5	12
Chandos	of Aldershot in the County of Southampton	\N	\N	\N	1309	2	12	\N	f	\N	1149	5	4
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	originally cr life baron	1311	7	12	\N	f	\N	1150	5	20
Kilmuir	of Creich in the County of Sutherland	1967-01-27	1	cr E of Kilmuir 1962	1312	2	12	\N	f	\N	1151	5	12
Milner of Leeds	of Roundhay in the City of Leeds	\N	\N	\N	1275	2	8	\N	f	\N	1152	5	14
Malvern	of Rhodesia and of Bexley in the County of Kent	\N	\N	\N	1316	2	12	\N	f	\N	1153	5	14
Strathclyde	of Barskimming in the County of Ayr	\N	\N	\N	1317	2	8	\N	f	\N	1154	5	20
Conesford	of Chelsea in the County of London	1974-08-28	1	\N	1319	2	8	\N	f	\N	1155	5	4
Heyworth	of Oxton in the County Palatine of Chester	1974-06-15	1	\N	1321	2	8	\N	f	\N	1156	5	9
McNair	of Gleniffer in the County of Renfrew	\N	\N	\N	1322	2	8	\N	f	\N	1157	5	14
Wise	of King's Lynn in the County of Norfolk	\N	\N	\N	1278	2	8	\N	f	\N	1119	5	24
Hudson	of Pewsey in the County of Wilts	1963-08-28	2	\N	1279	2	12	\N	f	\N	1120	5	9
Evershed	of Stapenhill in the County of Derby	1966-10-03	1	\N	1331	2	8	\N	f	\N	1158	5	6
Elliot of Harwood	of Rulewater in the County of Roxburgh	1994-01-03	1	\N	1366	5	8	\N	f	\N	1195	5	6
Attlee	\N	\N	\N	2nd E died 27 July 1991	1324	2	6	\N	f	\N	1159	5	2
De L'Isle	of Penshurst in the County of Kent	\N	\N	\N	1326	7	12	\N	f	\N	1160	5	5
Crookshank	of Gainsborough in the County of Lincoln	1961-10-17	1	\N	1327	2	12	\N	f	\N	1161	5	4
Ingleby	of Snilesworth in the North Riding of the County of York	2008-10-14	2	\N	1328	2	12	\N	f	\N	1162	5	10
Cilcennin	of Hereford in the County of Hereford	1960-07-13	1	\N	1329	2	12	\N	f	\N	1163	5	4
Colyton	of Farway in the County of Devon and of Taunton in the County of Somerset	\N	\N	\N	1330	2	8	\N	f	\N	1164	5	4
Astor of Hever	of Hever Castle in the County of Kent	\N	\N	\N	1332	2	8	\N	f	\N	1165	5	2
Godber	of Mayfield in the County of Sussex	1976-04-10	1	\N	1333	2	8	\N	f	\N	1166	5	8
Cherwell	of Oxford in the County of Oxford	1957-07-03	1	\N	1334	7	12	\N	f	\N	1167	5	4
Weeks	of Ryton in the County Palatine of Durham	1960-08-19	1	\N	1335	2	8	\N	f	\N	1168	5	24
Cohen of Birkenhead	of Birkenhead in the County Palatine of Chester	1977-08-07	1	\N	1336	2	8	\N	f	\N	1169	5	4
Sinclair of Cleeve	of Cleeve in the County of Somerset	\N	\N	\N	1337	2	8	\N	f	\N	1170	5	20
Evans	of Merthyr Tydfil in the County of Glamorgan	1963-10-26	1	\N	1344	2	8	\N	f	\N	1171	5	6
Mills	of Studley in the County of Warwick	\N	\N	cr V Mills 1962	1338	2	8	\N	f	\N	1172	5	14
Tenby	of Bulford in the County of Pembroke	\N	\N	\N	1341	2	12	\N	f	\N	1174	5	21
Hailes	of Prestonkirk in the County of East Lothian	1974-11-05	1	\N	1342	2	8	\N	f	\N	1175	5	9
Rank	of Sutton Scotney in the County of Southampton	1972-03-29	1	\N	1345	2	8	\N	f	\N	1177	5	19
Birkett	of Ulverston in the County Palatine of Lancaster	\N	\N	\N	1349	2	8	\N	f	\N	1178	5	3
Brecon	of Llanfeigan in the County of Brecknock	1976-10-10	1	\N	1348	2	8	\N	f	\N	1179	5	3
Harding of Petherton	of Nether Compton in the County of Dorset	\N	\N	\N	1350	2	8	\N	f	\N	1180	5	9
Robins	of Rhodesia and of Chelsea in the County of London	1962-07-21	1	\N	1351	2	8	\N	f	\N	1181	5	19
Poole	of Aldgate in the City of London	\N	\N	\N	1352	2	8	\N	f	\N	1182	5	17
Fraser of Lonsdale	of Regent's Park in the County of London	1974-12-19	1	\N	1354	5	8	\N	f	\N	1183	5	7
Stonham	of Earl Stonham in the County of Suffolk	1971-12-22	1	\N	1355	5	8	\N	f	\N	1184	5	20
Geddes of Epsom	of Epsom in the County of Surrey	1983-05-02	1	\N	1356	5	8	\N	f	\N	1185	5	8
Stopford of Fallowfield	of Hindley Green in the County Palatine of Lancaster	1961-03-06	1	\N	1357	5	8	\N	f	\N	1186	5	20
Granville-West	of Pontypool in the County of Monmouth	1984-09-23	1	\N	1358	5	8	\N	f	\N	1187	5	8
Adrian	of Cambridge in the County of Cambridge	1995-04-04	2	\N	1314	2	8	\N	f	\N	1188	5	2
Strathalmond	of Pumpherston in the County of Midlothian	\N	\N	\N	1315	2	8	\N	f	\N	1189	5	20
Clitheroe	of Downham in the County Palatine of Lancaster	\N	\N	\N	1320	2	8	\N	f	\N	1190	5	4
Ferrier	of Culter in the County of Lanark	1992-06-04	1	\N	1365	5	8	\N	f	\N	1191	5	7
Parker of Waddington	of Lincoln's Inn in the Borough of Holborn	1972-09-15	1	same title as father	1367	5	8	\N	f	\N	1192	5	17
Shawcross	of Friston in the County of Sussex	2003-07-10	1	\N	1369	5	8	\N	f	\N	1193	5	20
Woolton	\N	\N	\N	\N	1325	7	6	\N	t	\N	1194	5	24
Swanborough	of Swanborough in the County of Sussex	1971-05-22	1	\N	1364	5	8	\N	f	\N	1197	5	20
James of Rusholme	of Fallowfield in the County Palatine of Lancaster	1992-05-16	1	\N	1372	5	8	\N	f	\N	1200	5	11
Netherthorpe	of Anston in the West Riding of the County of York	\N	\N	\N	1373	2	8	\N	f	\N	1201	5	15
Robbins	of Clare Market in the City of Westminster	1984-05-15	1	\N	1375	5	8	\N	f	\N	1202	5	19
Jenkins	of Ashley Gardens in the City of Westminster	1969-07-21	1	vice L Morton of Henryton resigned	1374	1	8	\N	f	\N	1203	5	11
Crathorne	of Crathorne in the North Riding of the County of York	\N	\N	\N	1376	2	8	\N	f	\N	1204	5	4
Forster of Harraby	of Beckenham in the County of Kent	1972-07-24	1	\N	1377	2	8	\N	f	\N	1205	5	7
Spens	of Blairsanquhar in the County of Fife	\N	\N	\N	1378	2	8	\N	f	\N	1206	5	20
Morrison of Lambeth	of Lambeth in the County of London	1965-03-06	1	\N	1379	5	8	\N	f	\N	1207	5	14
Stuart of Findhorn	of Findhorn in the County of Moray	\N	\N	\N	1382	2	12	\N	f	\N	1208	5	20
Craigton	of Renfield in the County of the City of Glasgow	1993-07-28	1	\N	1380	5	8	\N	f	\N	1209	5	4
MacAndrew	of the Firth of Clyde	\N	\N	MacAndrew	1383	2	8	\N	f	\N	1210	5	14
Rochdale	of Rochdale in the County Palatine of Lancaster	\N	\N	\N	1386	7	12	\N	f	\N	1211	5	19
Nelson of Stafford	of Hilcote Hall in the County of Stafford	\N	\N	\N	1387	2	8	\N	f	\N	1212	5	15
Dalton	of Forest and Frith in the County Palatine of Durham	1962-02-13	1	\N	1388	5	8	\N	f	\N	1213	5	5
Bossom	of Maidstone in the County of Kent	1965-09-04	1	\N	1389	5	8	\N	f	\N	1214	5	3
Howick of Glendale	of Howick in the County of Northumberland	\N	\N	\N	1390	2	8	\N	f	\N	1215	5	9
Sanderson of Ayot	of Welwyn in the County of Hertford	\N	\N	\N	1393	2	8	\N	f	\N	1216	5	20
Gladwyn	of Bramfield in the County of Suffolk	2017-08-15	2	\N	1391	2	8	\N	f	\N	1217	5	8
Shackleton	of Burley in the County of Southampton	1994-09-22	1	\N	1361	5	8	\N	f	\N	1219	5	20
Head	of Throope in the County of Wilts	\N	\N	\N	1395	2	12	\N	f	\N	1220	5	9
Nugent	of West Harling in the County of Norfolk	1973-04-27	1	\N	1396	2	8	\N	f	\N	1221	5	15
Amory	of Tiverton in the County of Devon	1981-01-19	1	\N	1397	2	12	\N	f	\N	1222	5	2
Boyd of Merton	of Merton-in-Penninghame in the County of Wigtown	\N	\N	\N	1398	2	12	\N	f	\N	1223	5	3
Ward of Witley	of Great Witley in the County of Worcester	1988-06-15	1	\N	1400	2	12	\N	f	\N	1225	5	24
Cobbold	of Knebworth in the County of Hertford	\N	\N	\N	1401	2	8	\N	f	\N	1226	5	4
Guest	of Graden in the County of Berwick	1984-09-25	1	vice L Keith of Avonholm resigned	1402	1	8	\N	f	\N	1227	5	8
Twining	of Tanganyika and of Godalming in the County of Surrey	1967-07-21	1	\N	1362	5	8	\N	f	\N	1228	5	21
Boothby	of Buchan and Rattray Head in the County of Aberdeen	1986-07-16	1	\N	1363	5	8	\N	f	\N	1229	5	3
Peddie	of the City and County of Kingston upon Hull	1978-04-13	1	\N	1407	5	8	\N	f	\N	1230	5	17
Lindgren	of Welwyn Garden City in the County of Hertford	1971-09-08	1	\N	1408	5	8	\N	f	\N	1231	5	13
Walston	of Newton in the County of Cambridge	1991-05-29	1	\N	1409	5	8	\N	f	\N	1232	5	24
Molson	of High Peak in the County of Derby	1991-10-13	1	\N	1411	5	8	\N	f	\N	1233	5	14
Alport	of Colchester in the County of Essex	1998-10-28	1	\N	1410	5	8	\N	f	\N	1234	5	2
Robens of Woldingham	of Woldingham in the County of Surrey	1999-06-27	1	\N	1413	5	8	\N	f	\N	1235	5	19
Fisher of Lambeth	of Lambeth in the County of London	1972-09-15	1	\N	1412	5	8	\N	f	\N	1236	5	7
Rootes	of Ramsbury in the County of Wilts	\N	\N	2nd L died 16 Jan 1992	1370	2	8	\N	f	\N	1198	5	19
Plowden	of Plowden in the County of Salop	2001-02-15	1	\N	1371	5	8	\N	f	\N	1199	5	17
Fairhaven	of Anglesey Abbey in the County of Cambridge	\N	\N	SR to brother	1418	8	8	\N	f	1	1276	5	7
Robertson of Oakridge	of Oakridge in the County of Gloucester	\N	\N	\N	1414	2	8	\N	f	\N	1237	5	19
Northchurch	of Chiswick in the County of Middlesex	1985-11-25	1	\N	1453	5	8	\N	f	\N	1274	5	15
Marks of Broughton	of Sunningdale in the Royal County of Berks	\N	\N	\N	1415	2	8	\N	f	\N	1238	5	14
Leighton of Saint Mellons	of Saint Mellons in the County of Monmouth	\N	\N	\N	1421	2	8	\N	f	\N	1239	5	13
Devlin	of West Wick in the County of Wilts	1992-08-09	1	\N	1420	1	8	\N	f	\N	1240	5	5
Brain	of Eynsham in the County of Oxford	\N	\N	\N	1422	2	8	\N	f	\N	1241	5	3
Lambury	of Northfield in the County of Warwick	1967-09-13	1	\N	1425	2	8	\N	f	\N	1242	5	13
Inchyra	of Saint Madoes in the County of Perth	\N	\N	\N	1424	2	8	\N	f	\N	1243	5	10
Todd	of Trumpington in the County of Cambridge	1997-01-10	1	\N	1428	5	8	\N	f	\N	1245	5	21
Sainsbury	of Drury Lane in the Borough of Holborn	1998-10-21	1	\N	1430	5	8	\N	f	\N	1246	5	20
Pearce	of Sweethaws in the County of Sussex	1990-11-26	1	\N	1429	1	8	\N	f	\N	1247	5	17
Franks	of Headington in the County of Oxford	1992-10-15	1	\N	1431	5	8	\N	f	\N	1248	5	7
Champion	of Pontypridd in the County of Glamorgan	1985-03-02	1	\N	1432	5	8	\N	f	\N	1249	5	4
Ilford	of Bury in the County Palatine of Lancaster	1974-08-20	1	\N	1433	5	8	\N	f	\N	1250	5	10
Williamson	of Eccleston in the Borough of Saint Helens	1983-02-27	1	\N	1434	5	8	\N	f	\N	1251	5	24
Mabane	of Rye in the County of Sussex	1969-11-16	1	\N	1435	2	8	\N	f	\N	1252	5	14
Radcliffe	of Hampton Lucy in the County of Warwick	1977-04-01	1	\N	1436	7	12	\N	f	\N	1253	5	19
Silsoe	of Silsoe in the County of Bedford	\N	\N	\N	1441	2	8	\N	f	\N	1254	5	20
Dilhorne	of Towcester in the County of Northampton	\N	\N	cr V Dilhorne 1964	1437	2	8	\N	f	\N	1255	5	5
Eccles	of Chute in the County of Wilts	\N	\N	cr V Eccles 1964	1439	2	8	\N	f	\N	1256	5	6
Mills	of Kensington in the County of London	\N	\N	?th V died 6 Dec 1988	1440	7	12	\N	f	\N	1257	5	14
Normanbrook	of Chelsea in the County of London	1967-06-15	1	\N	1442	2	8	\N	f	\N	1258	5	15
Alexander of Hillsborough	\N	1965-01-11	1	\N	1443	7	6	\N	f	\N	1259	5	2
Chelmer	of Margaretting in the County of Essex	1997-03-03	1	\N	1444	5	8	\N	f	\N	1260	5	4
Hill of Luton	of Harpenden in the County of Hertford	1989-08-22	1	\N	1445	5	8	\N	f	\N	1261	5	9
Balerno	of Currie in the County of Midlothian	1984-07-28	1	\N	1446	5	8	\N	f	\N	1262	5	3
Fleck	of Salcoats in the County of Ayr	1968-08-06	1	\N	1404	2	8	\N	f	\N	1263	5	7
Hughes	of Hawkhill in the County of the City of Dundee	1999-12-31	1	\N	1406	5	8	\N	f	\N	1264	5	9
Upjohn	of Little Tey in the County of Essex	1971-01-27	1	vice L Jenkins resigned	1450	1	8	\N	f	\N	1265	5	22
Donovan	of Winchester in the County of Southampton	1971-12-12	1	vice L Devlin resigned	1452	1	8	\N	f	\N	1266	5	5
Eccles	of Chute in the County of Wilts	\N	\N	\N	1454	7	12	\N	f	\N	1267	5	6
Gardiner	of Kittisford in the County of Somerset	1990-01-07	1	\N	1455	5	8	\N	f	\N	1268	5	8
Llewelyn-Davies	of Hastoe in the County of Hertford	1981-10-27	1	\N	1456	5	8	\N	f	\N	1269	5	13
Bowden	of Chesterfield in the County of Derby	1989-07-31	1	\N	1457	5	8	\N	f	\N	1270	5	3
Hobson	of Brent in the County of Middlesex	1966-02-17	1	\N	1458	5	8	\N	f	\N	1271	5	9
Kilmuir	\N	1967-01-27	1	\N	1438	7	6	\N	t	\N	1272	5	12
Willis	of Chislehurst in the County of Kent	1992-12-22	1	\N	1459	5	8	\N	f	\N	1277	5	24
Gaitskell	of Egremont in the County of Cumberland	1989-07-01	1	\N	1461	5	8	\N	f	\N	1315	5	8
Tangley	of Blackheath in the County of Surrey	1973-06-05	1	\N	1460	5	8	\N	f	\N	1278	5	21
Thomson of Fleet	of Northbridge in the City of Edinburgh	\N	\N	\N	1462	2	8	\N	f	\N	1279	5	21
Martonmere	of Blackpool in the County Palatine of Lancaster	\N	\N	\N	1464	2	8	\N	f	\N	1280	5	14
Sherfield	of Sherfield-on-Loddon in the County of Southampton	\N	\N	\N	1466	2	8	\N	f	\N	1282	5	20
Muirshiel	of Kilmacolm in the County of Renfrew	1992-08-17	1	\N	1468	2	12	\N	f	\N	1283	5	14
Glendevon	of Midhope in the County of Linlithgow	\N	\N	\N	1469	2	8	\N	f	\N	1284	5	8
Bourne	of Atherstone in the County of Warwick	1982-06-26	1	\N	1471	5	8	\N	f	\N	1285	5	3
Hurd	of Newbury in the Royal County of Berks	1966-02-12	1	\N	1472	5	8	\N	f	\N	1286	5	9
Royle	of Pendleton in the City of Salford	1975-09-30	1	\N	1473	5	8	\N	f	\N	1287	5	19
Rhodes	of Saddleworth in the West Riding of the County of York	1987-09-11	1	\N	1475	5	8	\N	f	\N	1288	5	19
Murray of Newhaven	of Newhaven in the County of the City of Edinburgh	1993-10-10	1	\N	1476	5	8	\N	f	\N	1289	5	14
Erskine of Rerrick	of Rerrick in the Stewartry of Kirkcudbright	1995-06-07	2	\N	1474	2	8	\N	f	\N	1290	5	6
Wilberforce	of the City and County of Kingston-upon-Hull	2003-02-15	1	\N	1477	1	8	\N	f	\N	1291	5	24
Mitchison	of Carradale in the County of Argyll	1970-02-14	1	\N	1478	5	8	\N	f	\N	1292	5	14
Dilhorne	of Greens Norton in the County of Northampton	\N	\N	\N	1482	7	12	\N	f	\N	1293	5	5
Caradon	of St Cleer in the County of Cornwall	1990-09-05	1	\N	1479	5	8	\N	f	\N	1294	5	4
Snow	of the City of Leicester	1980-07-01	1	\N	1480	5	8	\N	f	\N	1295	5	20
Chalfont	of Llantarnam in the County of Monmouth	2020-01-10	1	\N	1481	5	8	\N	f	\N	1296	5	4
Grimston of Westbury	of Westbury in the County of Wilts	\N	\N	\N	1485	2	8	\N	f	\N	1297	5	8
Bowles	of Nuneaton in the County of Warwick	1970-12-29	1	\N	1486	5	8	\N	f	\N	1298	5	3
Collison	of Cheshunt in the County of Hertford	1995-12-29	1	\N	1487	5	8	\N	f	\N	1299	5	4
Sorensen	of Leyton in the County of Essex	1971-10-08	1	\N	1488	5	8	\N	f	\N	1300	5	20
Leatherland	of Dunton in the County of Essex	1992-12-18	1	\N	1489	5	8	\N	f	\N	1301	5	13
Blyton	of South Shields in the County of Durham	1987-10-25	1	\N	1490	5	8	\N	f	\N	1302	5	3
Vinson	of Roddam Dene in the County of Northumberland	\N	\N	\N	1931	5	8	\N	f	\N	1303	5	23
Brown	of Machrihanish in the County of Argyll	1985-03-17	1	\N	1498	5	8	\N	f	\N	1305	5	3
Byers	of Lingfield in the County of Surrey	1984-02-06	1	\N	1499	5	8	\N	f	\N	1306	5	3
Renwick	of Coombe in the County of Surrey	\N	\N	\N	1500	2	8	\N	f	\N	1307	5	19
Arwyn	of Glais in the County of Glamorgan	1978-02-23	1	\N	1502	5	8	\N	f	\N	1309	5	2
Fraser of Allander	of Dineiddwg in the County of Stirling	1987-05-05	2	2nd L disclaimed 1966	1503	2	8	\N	f	\N	1310	5	7
St Helens	of St Helens in the County Palatine of Lancaster	\N	\N	St. Helens	1504	2	8	\N	f	\N	1311	5	20
Margadale	of Islay in the County of Argyll	\N	\N	\N	1505	2	8	\N	f	\N	1312	5	14
Chuter-Ede	of Epsom in the County of Surrey	1965-11-11	1	\N	1506	5	8	\N	f	\N	1313	5	4
Emmet of Amberley	of Amberley in the County of Sussex	1980-10-10	1	\N	1484	5	8	\N	f	\N	1314	5	6
Phillips	of Fulham in the County of London	1992-08-14	1	\N	1496	5	8	\N	f	\N	1316	5	17
Stocks	of the Royal Borough of Kensington and Chelsea	1975-07-06	1	\N	1533	5	8	\N	f	\N	1355	5	20
Holford	of Kemp Town in the County of Sussex	1975-10-17	1	\N	1508	5	8	\N	f	\N	1318	5	9
Florey	of Adelaide in the Commonwealth of Australia and of Marston in the County of Oxford	1968-02-21	1	\N	1509	5	8	\N	f	\N	1319	5	7
Cole	of Blackfriars in the County of London	1979-11-29	1	\N	1512	5	8	\N	f	\N	1320	5	4
Pearson	of Minnedosa in Canada and of the Royal Borough of Kensington	1980-01-31	1	\N	1510	1	8	\N	f	\N	1321	5	17
Butler of Saffron Walden	of Halstead in the County of Essex	1982-03-08	1	\N	1511	5	8	\N	f	\N	1322	5	3
Hilton of Upton	of Swaffham in the County of Norfolk	1977-05-03	1	\N	1516	5	8	\N	f	\N	1324	5	9
Caccia	of Abernant in the County of Brecknock	1990-10-31	1	\N	1515	5	8	\N	f	\N	1325	5	4
Soper	of Kingsway in the London Borough of Camden	1998-12-22	1	\N	1517	5	8	\N	f	\N	1326	5	20
Simey	of Toxteth in the County Palatine of Lancaster	1969-12-27	1	\N	1518	5	8	\N	f	\N	1327	5	20
Haire of Whiteabbey	of Newtown Abbey in the County of Antrim	1966-10-07	1	\N	1519	5	8	\N	f	\N	1328	5	9
Cohen of Brighton	of Brighton in the County of Sussex	1966-10-21	1	\N	1520	5	8	\N	f	\N	1329	5	4
Winterbottom	of Clopton in the County of Northampton	1992-07-04	1	\N	1521	5	8	\N	f	\N	1330	5	24
Lloyd of Hampstead	of Hampstead in the London Borough of Camden	1992-12-31	1	\N	1522	5	8	\N	f	\N	1331	5	13
Kings Norton	of Wotton Underwood in the County of Buckingham	1997-12-21	1	\N	1524	5	8	\N	f	\N	1332	5	12
Brock	of Wimbledon in the London Borough of Merton	1980-09-03	1	\N	1525	5	8	\N	f	\N	1333	5	3
Kahn	of Hampstead in the London Borough of Camden	1989-06-06	1	\N	1526	5	8	\N	f	\N	1334	5	12
Beeching	of East Grinstead in the County of Sussex	1985-03-23	1	\N	1527	5	8	\N	f	\N	1335	5	3
Goodman	of the City of Westminster	1995-05-12	1	\N	1529	5	8	\N	f	\N	1337	5	8
King-Hall	of Headley in the County of Southampton	1966-06-02	1	\N	1532	5	8	\N	f	\N	1339	5	12
Wynne-Jones	of Abergele in the County of Denbigh	1982-11-08	1	\N	1492	5	8	\N	f	\N	1340	5	24
Beswick	of Hucknall in the County of Nottingham	1987-08-17	1	\N	1493	5	8	\N	f	\N	1341	5	3
Segal	of Wytham in the Royal County of Berks	1985-06-04	1	\N	1494	5	8	\N	f	\N	1342	5	20
Popplewell	of Sherburn-in-Elmet in the West Riding of the County of York	1977-08-11	1	\N	1540	5	8	\N	f	\N	1343	5	17
Stow Hill	of Newport in the County of Monmouth	1979-01-01	1	\N	1541	5	8	\N	f	\N	1344	5	20
Pargiter	of Southall in the London Borough of Ealing	1982-01-16	1	\N	1542	5	8	\N	f	\N	1345	5	17
Redmayne	of Rushcliffe in the County of Nottingham	1983-04-28	1	\N	1543	5	8	\N	f	\N	1346	5	19
Monslow	of Barrow-in-Furness in the County Palatine of Lancaster	1966-10-12	1	\N	1545	5	8	\N	f	\N	1347	5	14
Buckton	of Settrington in the East Riding of the County of York	1978-01-17	1	\N	1546	5	8	\N	f	\N	1348	5	3
Moyle	of Llanidloes in the County of Montgomery	1974-12-23	1	\N	1547	5	8	\N	f	\N	1349	5	14
McFadzean	of Woldingham in the County of Surrey	1996-01-14	1	\N	1548	5	8	\N	f	\N	1350	5	14
Hunt	of Llanvair Waterdine in the County of Salop	1998-11-08	1	\N	1549	5	8	\N	f	\N	1351	5	9
Ritchie-Calder	of Balmashannar in the Royal Burgh of Forfar	1982-01-31	1	\N	1550	5	8	\N	f	\N	1352	5	19
Cooper of Stockton Heath	of Stockton Heath in the County Palatine of Chester	1988-09-02	1	\N	1551	5	8	\N	f	\N	1353	5	4
Plummer	of Toppesfield in the County of Essex	1972-06-13	1	\N	1513	5	8	\N	f	\N	1354	5	17
Hinton of Bankside	of Dulwich in the County of London	1983-06-22	1	\N	1507	5	8	\N	f	\N	1317	5	9
Brooke of Cumnor	of Cumnor in the Royal County of Berks	1984-03-29	1	\N	1552	5	8	\N	f	\N	1356	5	3
Serota	of Hampstead in Greater London	2002-10-21	1	\N	1558	5	8	\N	f	\N	1394	5	20
Platt	of Grindleford in the County of Derby	1978-06-30	1	\N	1554	5	8	\N	f	\N	1357	5	17
Morris of Grasmere	of Grasmere in the County of Westmorland	1990-05-30	1	\N	1555	5	8	\N	f	\N	1358	5	14
Woolley	of Hatton in the County Palatine of Chester	1986-07-31	1	\N	1556	5	8	\N	f	\N	1359	5	24
Redcliffe-Maud	of the City and County of Bristol	1982-11-20	1	\N	1560	5	8	\N	f	\N	1360	5	19
Penney	of East Hendred in the Royal County of Berks	1991-03-03	1	\N	1561	5	8	\N	f	\N	1361	5	17
Heycock	of Taibach in the Borough of Port Talbot	1990-03-13	1	\N	1562	5	8	\N	f	\N	1362	5	9
Carron	of the City and County of Kingston upon Hull	1969-12-03	1	\N	1563	5	8	\N	f	\N	1363	5	4
Mais	of Walbrook in the City of London	1993-11-28	1	\N	1565	5	8	\N	f	\N	1365	5	14
Hirshfield	of Holborn in Greater London	1993-12-06	1	\N	1567	5	8	\N	f	\N	1366	5	9
McLeavy	of the City of Bradford	1976-10-01	1	\N	1568	5	8	\N	f	\N	1367	5	14
Granville of Eye	of Eye in the County of Suffolk	1998-02-14	1	\N	1569	5	8	\N	f	\N	1368	5	8
Tayside	of Queens Well in the Royal Burgh of Forfar and County of Angus	1975-03-12	1	\N	1570	5	8	\N	f	\N	1369	5	21
Fiske	of Brent in Greater London	1975-01-13	1	\N	1572	5	8	\N	f	\N	1370	5	7
Garnsworthy	of Reigate in the County of Surrey	1974-09-05	1	\N	1573	5	8	\N	f	\N	1371	5	8
Aylestone	of Aylestone in the City of Leicester	1994-04-30	1	\N	1574	5	8	\N	f	\N	1372	5	2
Hill of Wivenhoe	of Wivenhoe in the County of Essex	1969-12-14	1	\N	1575	5	8	\N	f	\N	1373	5	9
Douglass of Cleveland	of Cleveland in the County of York	1978-04-05	1	\N	1576	5	8	\N	f	\N	1374	5	5
Delacourt-Smith	of New Windsor in the Royal County of Berks	1972-08-02	1	\N	1577	5	8	\N	f	\N	1375	5	5
Donaldson of Kingsbridge	of Kingsbridge in the County of Buckingham	1998-03-08	1	\N	1578	5	8	\N	f	\N	1376	5	5
Fulton	of Falmer in the County of Sussex	1986-03-14	1	\N	1535	5	8	\N	f	\N	1377	5	7
Rowley	of Rowley Regis in the County of Stafford	1968-08-28	1	\N	1536	5	8	\N	f	\N	1378	5	19
Wigg	of the Borough of Dudley	1983-08-11	1	\N	1579	5	8	\N	f	\N	1379	5	24
Kilmany	of Kilmany in the County of Fife	1985-08-06	1	\N	1539	5	8	\N	f	\N	1380	5	12
Wright of Ashton under Lyne	of Ashton under Lyne in the County Palatine of Lancaster	1974-09-15	1	\N	1586	5	8	\N	f	\N	1381	5	24
Taylor of Gryfe	of Bridge of Weir in the County of Renfrew	2001-07-13	1	\N	1587	5	8	\N	f	\N	1382	5	21
Trevelyan	of Saint Veep in the County of Cornwall	1985-02-08	1	\N	1588	5	8	\N	f	\N	1383	5	21
Helsby	of Logmore in the County of Surrey	1978-12-05	1	\N	1589	5	8	\N	f	\N	1384	5	9
Balogh	of Hampstead in Greater London	1985-01-20	1	\N	1590	5	8	\N	f	\N	1385	5	3
Black	of Barrow in Furness in the County Palatine of Lancaster	1984-12-27	1	\N	1591	5	8	\N	f	\N	1386	5	3
Energlyn	of Caerphilly in the County of Glamorgan	1985-06-27	1	\N	1593	5	8	\N	f	\N	1388	5	6
Jacques	of Portsea Island in the County of Southampton	1995-12-20	1	\N	1594	5	8	\N	f	\N	1389	5	11
Grey of Naunton	of Naunton in the County of Gloucester	1999-10-17	1	\N	1595	5	8	\N	f	\N	1390	5	8
Diplock	of Wansford in the County of Huntingdon and Peterborough	1985-10-14	1	\N	1596	1	8	\N	f	\N	1391	5	5
Stokes	of Leyland in the County Palatine of Lancaster	2008-07-21	1	\N	1597	5	8	\N	f	\N	1392	5	20
Sharp	of Hornsey in Greater London	1985-09-01	1	\N	1553	5	8	\N	f	\N	1395	5	20
White	of Rhymney in the County of Monmouth	1999-12-23	1	\N	1627	5	8	\N	f	\N	1434	5	24
Blackett	of Chelsea in Greater London	1974-07-13	1	\N	1598	5	8	\N	f	\N	1396	5	3
Masham of Ilton	of Masham in the North Riding of the County of York	\N	\N	\N	1609	5	8	\N	f	\N	1432	5	14
Garner	of Chiddingly in the County of Sussex	1983-12-10	1	\N	1599	5	8	\N	f	\N	1397	5	8
Constantine	of Maraval in Trinidad and Tobago and of Nelson in the County Palatine of Lancaster	1971-07-01	1	\N	1601	5	8	\N	f	\N	1398	5	4
Gore-Booth	of Maltby in the West Riding of the County of York	1984-06-29	1	\N	1602	5	8	\N	f	\N	1399	5	8
Bernstein	of Leigh in the County of Kent	1993-02-05	1	\N	1603	5	8	\N	f	\N	1400	5	3
Clark	of Saltwood in the County of Kent	1983-05-21	1	\N	1604	5	8	\N	f	\N	1401	5	4
Ardwick	of Barnes in the London Borough of Richmond upon Thames	1994-08-18	1	\N	1606	5	8	\N	f	\N	1402	5	2
O'Neill of the Maine	of Ahoghill in the County of Antrim	1990-06-12	1	\N	1607	5	8	\N	f	\N	1403	5	16
Kearton	of Whitchurch in the County of Buckingham	1992-07-02	1	\N	1608	5	8	\N	f	\N	1404	5	12
Shinwell	of Easington in the County of Durham	1986-05-08	1	\N	1610	5	8	\N	f	\N	1405	5	20
Janner	of the City of Leicester	1982-05-04	1	\N	1611	5	8	\N	f	\N	1406	5	11
Reigate	of Outwood in the County of Surrey	1995-01-26	1	\N	1614	5	8	\N	f	\N	1408	5	19
Boyle of Handsworth	of Salehurst in the County of Sussex	1981-09-28	1	\N	1615	5	8	\N	f	\N	1409	5	3
Hoy	of Leith in the County of the City of Edinburgh	1976-08-07	1	\N	1616	5	8	\N	f	\N	1410	5	9
Hamnett	of Warrington in the County Palatine of Lancaster	1980-03-17	1	\N	1617	5	8	\N	f	\N	1411	5	9
Slater	of Ferryhill in the County of Durham	1977-04-21	1	\N	1619	5	8	\N	f	\N	1413	5	20
Fletcher	of Islington in Greater London	1990-06-09	1	\N	1620	5	8	\N	f	\N	1414	5	7
Wheatley	of Shettleston in the County of the City of Glasgow	1988-07-28	1	\N	1621	5	8	\N	f	\N	1415	5	24
Rosenheim	of the London Borough of Camden	1972-12-02	1	\N	1622	5	8	\N	f	\N	1416	5	19
Thorneycroft	of Dunston in the County of Stafford	1994-06-04	1	\N	1581	5	8	\N	f	\N	1417	5	21
Beaumont of Whitley	of Child's Hill in Greater London	2008-04-08	1	\N	1583	5	8	\N	f	\N	1418	5	3
Pilkington	of St Helens in the County Palatine of Lancaster	1983-12-22	1	\N	1584	5	8	\N	f	\N	1419	5	17
George-Brown	of Jevington in the County of Sussex	1985-06-02	1	\N	1630	5	8	\N	f	\N	1420	5	8
Thomas	of Remenham in the Royal County of Berkshire	1980-02-08	1	\N	1631	5	8	\N	f	\N	1421	5	21
Marlesford	of Marlesford in the County of Suffolk	\N	\N	\N	2041	5	8	\N	f	\N	1422	5	14
Maclean	of Duart and Morven in the County of Argyll	1990-02-08	1	\N	1633	5	8	\N	f	\N	1423	5	14
Maybray-King	of the City of Southampton	1986-09-03	1	\N	1634	5	8	\N	f	\N	1424	5	14
Olivier	of Brighton in the County of Sussex	1989-07-11	1	\N	1635	5	8	\N	f	\N	1425	5	16
Cross of Chelsea	of the Royal Borough of Kensington and Chelsea	1989-08-04	1	\N	1636	1	8	\N	f	\N	1426	5	4
Widgery	of South Molton in the County of Devon	1981-07-26	1	\N	1637	5	8	\N	f	\N	1427	5	24
Orr-Ewing	of Little Berkhamsted in the County of Hertford	1999-08-19	1	\N	1638	5	8	\N	f	\N	1428	5	16
Harvey of Prestbury	of Prestbury in the County Palatine of Chester	1994-04-05	1	\N	1639	5	8	\N	f	\N	1429	5	9
Blake	of Braydeston in the County of Norfolk	2003-09-20	1	\N	1640	5	8	\N	f	\N	1430	5	3
Lee of Asheridge	of the City of Westminster	1988-11-16	1	\N	1629	5	8	\N	f	\N	1431	5	13
Tweedsmuir of Belhelvie	of Potterton in the County of Aberdeen	1978-03-11	1	\N	1613	5	8	\N	f	\N	1433	5	21
Robson of Kiddington	of Kiddington in Oxfordshire	1999-02-09	1	\N	1682	5	8	\N	f	\N	1472	5	19
Seear	of Paddington in the City of Westminster	1997-04-23	1	\N	1641	5	8	\N	f	\N	1473	5	20
Sharples	of Chawton in Hampshire	\N	\N	\N	1661	5	8	\N	f	\N	1474	5	20
Young	of Farnworth in the County Palatine of Lancaster	2002-09-06	1	\N	1643	5	8	\N	f	\N	1475	5	26
Tanlaw	of Tanlawhill in the County of Dumfries	\N	\N	\N	1642	5	8	\N	f	\N	1435	5	21
Macleod of Borve	of Borve in the Isle of Lewis	1999-11-17	1	\N	1644	5	8	\N	f	\N	1470	5	14
Moyola	of Castledawson in the County of Londonderry	2002-05-17	1	\N	1646	5	8	\N	f	\N	1437	5	14
Kilbrandon	of Kilbrandon in the County of Argyll	1989-09-10	1	\N	1647	1	8	\N	f	\N	1438	5	12
Salmon	of Sandwich in the County of Kent	1991-11-07	1	\N	1648	1	8	\N	f	\N	1439	5	20
Adeane	of Stamfordham in the County of Northumberland	1984-04-30	1	\N	1649	5	8	\N	f	\N	1440	5	2
Hale	of Oldham in the County Palatine of Lancaster	1985-05-09	1	\N	1650	5	8	\N	f	\N	1441	5	9
Hewlett	of Swettenham in the County of Chester	1979-07-02	1	\N	1651	5	8	\N	f	\N	1442	5	9
Seebohm	of Hertford in the County of Hertford	1990-12-15	1	\N	1652	5	8	\N	f	\N	1443	5	20
Boyd-Carpenter	of Crux Easton in the County of Southampton	1998-07-11	1	\N	1653	5	8	\N	f	\N	1444	5	3
Elworthy	of Timaru in New Zealand and of Elworthy in the County of Somerset	1993-04-04	1	\N	1655	5	8	\N	f	\N	1445	5	6
Watkins	of Glyntawe in the County of Brecknock	1983-11-02	1	\N	1656	5	8	\N	f	\N	1446	5	24
Samuel of Wych Cross	of Wych Cross in the County of Sussex	1987-08-28	1	\N	1657	5	8	\N	f	\N	1447	5	20
Porritt	of Wanganui in New Zealand and of Hampstead in Greater London	1994-01-01	1	\N	1659	5	8	\N	f	\N	1448	5	17
O'Brien of Lothbury	of the City of London	1995-11-24	1	\N	1660	5	8	\N	f	\N	1449	5	16
Brayley	of the City of Cardiff in the County of Glamorgan	1977-03-16	1	\N	1662	5	8	\N	f	\N	1450	5	3
Hunt of Fawley	of Fawley in the County of Buckingham	1987-12-28	1	\N	1663	5	8	\N	f	\N	1451	5	9
Ashby	of Brandon in the County of Suffolk	1992-10-22	1	\N	1665	5	8	\N	f	\N	1452	5	2
Allan of Kilmahew	of Cardross in the County of Dunbarton	1979-04-04	1	\N	1667	5	8	\N	f	\N	1454	5	2
Diamond	of the City of Gloucester	2004-04-03	1	\N	1625	5	8	\N	f	\N	1455	5	5
Davies of Leek	of Leek in the County of Stafford	1985-10-28	1	\N	1626	5	8	\N	f	\N	1456	5	5
Goronwy-Roberts	of Caernarvon and of Ogwen in the County of Caernarvon	1981-07-22	1	\N	1672	5	8	\N	f	\N	1457	5	8
Harris of Greenwich	of Greenwich in Greater London	2001-04-11	1	\N	1673	5	8	\N	f	\N	1458	5	9
Duncan-Sandys	of the City of Westminster	1987-11-26	1	\N	1674	5	8	\N	f	\N	1459	5	5
Glenkinglas	of Cairndow in the County of Argyll	1984-05-15	1	\N	1675	5	8	\N	f	\N	1460	5	8
Geoffrey-Lloyd	of Broomfield in the County of Kent	1984-09-12	1	\N	1676	5	8	\N	f	\N	1461	5	8
Marples	of Wallasey in the County of Merseyside	1978-07-06	1	\N	1678	5	8	\N	f	\N	1462	5	14
Mackie of Benshie	of Kirriemuir in the County of Angus	2015-02-17	1	\N	1680	5	8	\N	f	\N	1464	5	14
Wigoder	of Cheetham in the City of Manchester	2004-08-12	1	\N	1684	5	8	\N	f	\N	1465	5	24
Fraser of Kilmorack	of Rubislaw in the County of the City of Aberdeen	1996-07-01	1	\N	1685	5	8	\N	f	\N	1466	5	7
Castle	of Islington in Greater London	1979-12-26	1	\N	1686	5	8	\N	f	\N	1467	5	4
Fisher of Camden	of Camden in Greater London	1979-10-12	1	\N	1687	5	8	\N	f	\N	1468	5	7
Hornsby-Smith	of Chislehurst in Greater London	1985-07-03	1	\N	1681	5	8	\N	f	\N	1469	5	9
Pike	of Melton in Leicestershire	2004-01-11	1	\N	1683	5	8	\N	f	\N	1471	5	17
Vickers	of Devonport in the County of Devon	1994-05-23	1	\N	1726	5	8	\N	f	\N	1514	5	23
Houghton of Sowerby	of Sowerby in the County of West Yorkshire	1996-05-02	1	\N	1688	5	8	\N	f	\N	1476	5	9
Stedman	of Longthorpe in the City of Peterborough	1996-06-08	1	\N	1691	5	8	\N	f	\N	1512	5	20
Pannell	of the City of Leeds	1980-03-23	1	\N	1689	5	8	\N	f	\N	1477	5	17
Harvington	of Nantwich in Cheshire	1997-01-01	1	\N	1690	5	8	\N	f	\N	1478	5	9
Lovell-Davis	of Highgate in Greater London	2001-01-06	1	\N	1692	5	8	\N	f	\N	1479	5	13
Kissin	of Camden in Greater London	1997-11-22	1	\N	1693	5	8	\N	f	\N	1480	5	12
Wallace of Campsie	of Newlands in the County of the City of Glasgow	1997-12-23	1	\N	1694	5	8	\N	f	\N	1481	5	24
Lee of Newton	of Newton in the County of Merseyside	1984-02-04	1	\N	1695	5	8	\N	f	\N	1482	5	13
Darling of Hillsborough	of Crewe in Cheshire	1985-10-18	1	\N	1697	5	8	\N	f	\N	1483	5	5
Gordon-Walker	of Leyton in Greater London	1980-12-02	1	\N	1698	5	8	\N	f	\N	1484	5	8
Davies of Penrhys	of Rhondda in the County of Mid Glamorgan	1992-04-28	1	\N	1700	5	8	\N	f	\N	1485	5	5
Kaldor	of Newnham in the City of Cambridge	1986-09-30	1	\N	1701	5	8	\N	f	\N	1486	5	12
Allen of Fallowfield	of Fallowfield in Greater Manchester	1985-01-14	1	\N	1702	5	8	\N	f	\N	1487	5	2
Wolfenden	of Westcott in the County of Surrey	1985-01-18	1	\N	1704	5	8	\N	f	\N	1488	5	24
Edmund-Davies	of Aberpennar in the County of Mid Glamorgan	1992-12-27	1	\N	1706	1	8	\N	f	\N	1489	5	6
Ramsey of Canterbury	of Canterbury in the County of Kent	1988-04-23	1	\N	1707	5	8	\N	f	\N	1490	5	19
Paget of Northampton	of Lubenham in Leicestershire	1990-01-02	1	\N	1709	5	8	\N	f	\N	1491	5	17
Ashdown	of Chelwood in the County of East Sussex	1977-07-23	1	\N	1710	5	8	\N	f	\N	1492	5	2
Barber	of Wentbridge in West Yorkshire	2005-12-16	1	\N	1711	5	8	\N	f	\N	1493	5	3
Banks	of Kenton in Greater London	1997-06-15	1	\N	1712	5	8	\N	f	\N	1494	5	3
Feather	of the City of Bradford	1976-07-28	1	\N	1669	5	8	\N	f	\N	1495	5	7
Trend	of Greenwich in Greater London	1987-07-21	1	\N	1670	5	8	\N	f	\N	1496	5	21
Wilson of Radcliffe	of Radcliffe in Lancashire	1983-01-25	1	\N	1717	5	8	\N	f	\N	1498	5	24
Briginshaw	of Southwark in Greater London	1992-03-27	1	\N	1719	5	8	\N	f	\N	1499	5	3
Wallace of Coslany	of Coslany in the City of Norwich	2003-11-11	1	\N	1720	5	8	\N	f	\N	1500	5	24
Bruce of Donington	of Rickmansworth in Hertfordshire	2005-04-18	1	\N	1721	5	8	\N	f	\N	1501	5	3
Greene of Harrow Weald	of Harrow in Greater London	2004-07-26	1	\N	1722	5	8	\N	f	\N	1502	5	8
Balniel	of Pitcorthie in the County of Fife	\N	\N	succ as E of Crawford & Balcarres 1975	1725	5	8	\N	f	\N	1504	5	3
Plurenden	of Plurenden Manor in the County of Kent	1978-01-05	1	\N	1727	5	8	\N	f	\N	1505	5	17
Armstrong of Sanderstead	of the City of Westminster	1980-07-12	1	\N	1728	5	8	\N	f	\N	1506	5	2
Pritchard	of West Haddon in Northamptonshire	1995-10-16	1	\N	1729	5	8	\N	f	\N	1507	5	17
Gibson	of Penn's Rocks in the County of East Sussex	2004-04-20	1	\N	1730	5	8	\N	f	\N	1508	5	8
Lever	of Ardwick in the City of Manchester	1977-07-26	1	never introduced	1732	5	8	\N	f	\N	1509	5	13
Gregson	of Stockport in Greater Manchester	2009-08-12	1	\N	1733	5	8	\N	f	\N	1510	5	8
Fisher of Rednal	of Rednal in the City of Birmingham	2005-12-18	1	\N	1696	5	8	\N	f	\N	1511	5	7
Stewart of Alvechurch	of Fulham in Greater London	1984-12-28	1	\N	1718	5	8	\N	f	\N	1513	5	20
Ryder of Eaton Hastings	of Eaton Hastings in the County of Oxfordshire	2003-05-12	1	\N	1735	5	8	\N	f	\N	1516	5	19
Jacobson	of St Albans in Hertfordshire	1988-08-13	1	\N	1736	5	8	\N	f	\N	1517	5	11
Kirkhill	of Kirkhill in the District of the City of Aberdeen	\N	\N	\N	1737	5	8	\N	f	\N	1518	5	12
Russell of Killowen	of Killowen in the County of Down	1986-06-23	1	\N	1738	1	8	\N	f	\N	1519	5	19
Brookes	of West Bromwich in the County of West Midlands	2002-07-31	1	\N	1739	5	8	\N	f	\N	1520	5	3
Carr of Hadley	of Monken Hadley in Greater London	2012-02-17	1	\N	1740	5	8	\N	f	\N	1521	5	4
McCarthy	of Headington in the City of Oxford	2012-11-18	1	\N	1742	5	8	\N	f	\N	1523	5	14
Northfield	of Telford in the County of Salop	2013-04-18	1	\N	1743	5	8	\N	f	\N	1524	5	15
Parry	of Neyland in the County of Dyfed	2004-09-01	1	\N	1744	5	8	\N	f	\N	1525	5	17
Oram	of Brighton in the County of East Sussex	1999-09-04	1	\N	1745	5	8	\N	f	\N	1526	5	16
Winstanley	of Urmston in Greater Manchester	1993-07-18	1	\N	1746	5	8	\N	f	\N	1527	5	24
Schon	of Whitehaven in the County of Cumbria	1995-01-07	1	\N	1748	5	8	\N	f	\N	1528	5	20
Bullock	of Leafield in the County of Oxfordshire	2004-02-02	1	\N	1750	5	8	\N	f	\N	1530	5	3
Wilson of High Wray	of Kendal in the County of Cumbria	1980-02-24	1	\N	1751	5	8	\N	f	\N	1531	5	24
Wall	of Coombe in Greater London	1980-12-29	1	\N	1752	5	8	\N	f	\N	1532	5	24
Selwyn-Lloyd	of Wirral in the County of Merseyside	1978-05-17	1	\N	1753	5	8	\N	f	\N	1533	5	20
Grade	of Elstree in the County of Hertfordshire	1998-12-13	1	\N	1754	5	8	\N	f	\N	1534	5	8
Vaizey	of Greenwich in Greater London	1984-07-19	1	\N	1755	5	8	\N	f	\N	1535	5	23
Stone	of Hendon in Greater London	1986-07-17	1	\N	1756	5	8	\N	f	\N	1536	5	20
Fraser of Tullybelton	of Bankfoot in the County of Perth	1989-02-17	1	\N	1716	1	8	\N	f	\N	1537	5	7
Britten	of Aldeburgh in the County of Suffolk	1976-12-04	1	never introduced	1762	5	8	\N	f	\N	1538	5	3
Allen of Abbeydale	of the City of Sheffield	2007-11-27	1	\N	1763	5	8	\N	f	\N	1539	5	2
Briggs	of Lewes in the County of East Sussex	2016-03-15	1	\N	1764	5	8	\N	f	\N	1540	5	3
Rayne	of Prince's Meadow in Greater London	2003-10-10	1	\N	1765	5	8	\N	f	\N	1541	5	19
Peart	of Workington in the County of Cumbria	1988-08-26	1	\N	1766	5	8	\N	f	\N	1542	5	17
Keith of Kinkel	of Strathtummel in the District of Perth and Kinross	2002-06-21	1	vice L Kilbrandon; retired 30.9.1996	1769	1	8	\N	f	\N	1543	5	12
Glenamara	of Glenridding in the County of Cumbria	2012-05-04	1	\N	1770	5	8	\N	f	\N	1544	5	8
Baker	of Windrush in the County of Gloucestershire	1985-09-09	1	\N	1771	5	8	\N	f	\N	1545	5	3
Faulkner of Downpatrick	of Downpatrick in the County of Down	1977-03-03	1	\N	1772	5	8	\N	f	\N	1546	5	7
Saint Brides	of Hasguard in the County of Dyfed	1989-11-26	1	\N	1773	5	8	\N	f	\N	1547	5	20
Carver	of Shackleford in the County of Surrey	2001-12-09	1	\N	1775	5	8	\N	f	\N	1549	5	4
Chitnis	of Ryedale in the County of North Yorkshire	2013-07-12	1	\N	1776	5	8	\N	f	\N	1550	5	4
Roll of Ipsden	of Ipsden in the County of Oxfordshire	2005-03-30	1	\N	1777	5	8	\N	f	\N	1551	5	19
Wedderburn of Charlton	of Highgate in Greater London	2012-03-09	1	\N	1778	5	8	\N	f	\N	1552	5	24
Noel-Baker	of the City of Derby	1982-10-08	1	\N	1779	5	8	\N	f	\N	1553	5	15
Jackson of Lodsworth	of Lodsworth in the County of West Sussex	1981-05-31	1	\N	1768	5	8	\N	f	\N	1554	5	11
Barnetson	of Crowborough in the County of East Sussex	1981-03-12	1	\N	1734	5	8	\N	f	\N	1515	5	3
Ryder of Warsaw	of Warsaw in Poland and of Cavendish in the County of Suffolk	2000-11-02	1	\N	1807	5	8	\N	f	\N	1594	5	19
Croham	of the London Borough of Croydon	2011-09-11	1	\N	1782	5	8	\N	f	\N	1555	5	4
Jeger	of St Pancras in Greater London	2007-02-26	1	\N	1821	5	8	\N	f	\N	1592	5	11
Scarman	of Quatt in the County of Salop	2004-12-08	1	\N	1780	1	8	\N	f	\N	1556	5	20
McGregor of Durris	of Hampstead in Greater London	1997-11-10	1	\N	1783	5	8	\N	f	\N	1557	5	14
Young of Dartington	of Dartington in the County of Devon	2002-01-14	1	\N	1785	5	8	\N	f	\N	1558	5	26
Cockfield	of Dover in the County of Kent	2007-01-08	1	\N	1786	5	8	\N	f	\N	1559	5	4
Soames	of Fletching in the County of East Sussex	1987-09-16	1	\N	1788	5	8	\N	f	\N	1561	5	20
Howie of Troon	of Troon in the District of Kyle and Carrick	2018-05-26	1	\N	1789	5	8	\N	f	\N	1562	5	9
Evans of Claughton	of Claughton in the County of Merseyside	1992-03-22	1	\N	1790	5	8	\N	f	\N	1563	5	6
Whaddon	of Whaddon in the County of Cambridgeshire	2005-08-16	1	\N	1791	5	8	\N	f	\N	1564	5	24
Leonard	of the City of Cardiff in the County of South Glamorgan	1983-07-17	1	\N	1793	5	8	\N	f	\N	1565	5	13
Sefton of Garston	of Garston in the County of Merseyside	2001-09-09	1	\N	1794	5	8	\N	f	\N	1566	5	20
Taylor of Blackburn	of Blackburn in the County of Lancashire	2016-11-25	1	\N	1795	5	8	\N	f	\N	1567	5	21
Hatch of Lusby	of Oldfield in the County of West Yorkshire	1992-10-11	1	\N	1796	5	8	\N	f	\N	1568	5	9
Plant	of Benenden in the County of Kent	1986-08-09	1	\N	1797	5	8	\N	f	\N	1569	5	17
Mishcon	of Lambeth in Greater London	2006-01-27	1	\N	1798	5	8	\N	f	\N	1570	5	14
Donnet of Balgay	of Balgay in the District of the City of Dundee	1985-05-15	1	\N	1801	5	8	\N	f	\N	1571	5	5
Delfont	of Stepney in Greater London	1994-07-28	1	\N	1759	5	8	\N	f	\N	1572	5	5
Kagan	of Elland in the County of West Yorkshire	1995-01-17	1	\N	1760	5	8	\N	f	\N	1573	5	12
Boston of Faversham	of Faversham in the County of Kent	2011-07-23	1	\N	1761	5	8	\N	f	\N	1574	5	3
Richardson	of Lee in the County of Devon	2004-08-15	1	\N	1808	5	8	\N	f	\N	1575	5	19
Hill-Norton	of South Nutfield in the County of Surrey	2004-05-16	1	\N	1809	5	8	\N	f	\N	1576	5	9
Miles	of Blackfriars in the City of London	1991-06-14	1	\N	1810	5	8	\N	f	\N	1577	5	14
Scanlon	of Davyhulme in the County of Greater Manchester	2004-01-27	1	\N	1812	5	8	\N	f	\N	1578	5	20
Flowers	of Queen's Gate in the City of Westminster	2010-06-25	1	\N	1813	5	8	\N	f	\N	1579	5	7
Bellwin	of the City of Leeds	2001-02-11	1	\N	1814	5	8	\N	f	\N	1580	5	3
Lever of Manchester	of Cheetham in the City of Manchester	1995-08-06	1	\N	1815	5	8	\N	f	\N	1581	5	13
Stewart of Fulham	of Fulham in Greater London	1990-03-10	1	\N	1816	5	8	\N	f	\N	1582	5	20
Mackay of Clashfern	of Eddrachillis in the District of Sutherland	\N	\N	\N	1817	5	8	\N	f	\N	1583	5	14
Strauss	of Vauxhall in the London Borough of Lambeth	1993-06-05	1	\N	1818	5	8	\N	f	\N	1584	5	20
Galpern	of Shettleston in the District of the City of Glasgow	1993-09-23	1	\N	1820	5	8	\N	f	\N	1586	5	8
Renton	of Huntingdon in the County of Cambridgeshire	2007-05-24	1	\N	1822	5	8	\N	f	\N	1587	5	19
Underhill	of Leyton in Greater London	1993-03-12	1	\N	1824	5	8	\N	f	\N	1589	5	22
Cledwyn of Penrhos	of Holyhead in the Isle of Anglesey	2001-02-22	1	\N	1825	5	8	\N	f	\N	1590	5	4
Denington	of Stevenage in the County of Hertfordshire	1998-08-22	1	\N	1802	5	8	\N	f	\N	1591	5	5
Lockwood	of Dewsbury in the County of West Yorkshire	2019-04-29	1	\N	1784	5	8	\N	f	\N	1593	5	13
Platt of Writtle	of Writtle in the County of Essex	2015-02-01	1	\N	1864	5	8	\N	f	\N	1631	5	17
Skrimshire of Quarter	of Dunipace in the District of Falkirk	1979-11-07	1	\N	1838	5	8	\N	f	\N	1632	5	20
Trumpington	of Sandwich in the County of Kent	2018-11-26	1	\N	1840	5	8	\N	f	\N	1633	5	21
Brooks of Tremorfa	of Tremorfa in the County of South Glamorgan	2016-03-04	1	\N	1826	5	8	\N	f	\N	1595	5	3
Lane-Fox	of Bramham in the County of West Yorkshire	1988-04-17	1	\N	1859	5	8	\N	f	\N	1629	5	13
Harris of High Cross	of Tottenham in Greater London	2006-10-19	1	\N	1828	5	8	\N	f	\N	1596	5	9
Murton of Lindisfarne	of Hexham in the County of Northumberland	2009-07-05	1	\N	1830	5	8	\N	f	\N	1598	5	14
Holderness	of Bishop Wilton in the County of Humberside	2002-08-11	1	\N	1834	5	8	\N	f	\N	1599	5	9
Gibson-Watt	of the Wye District of Radnor	2002-02-07	1	\N	1835	5	8	\N	f	\N	1600	5	8
Lane	of St Ippollitts in the County of Hertfordshire	2005-08-21	1	\N	1837	1	8	\N	f	\N	1602	5	13
Coggan	of Canterbury and of Sissinghurst in the County of Kent	2000-05-17	1	\N	1839	5	8	\N	f	\N	1603	5	4
Keith of Castleacre	of Swaffham in the County of Norfolk	2004-09-01	1	\N	1841	5	8	\N	f	\N	1604	5	12
Emslie	of Potterton in the District of Gordon	2002-11-20	1	\N	1843	5	8	\N	f	\N	1606	5	6
Sieff of Brimpton	of Brimpton in the Royal County of Berkshire	2001-02-23	1	\N	1844	5	8	\N	f	\N	1607	5	20
Hunter of Newington	of Newington in the District of the City of Edinburgh	1994-03-24	1	\N	1804	5	8	\N	f	\N	1608	5	9
Roskill	of Newtown in the County of Hampshire	1996-10-04	1	\N	1846	1	8	\N	f	\N	1609	5	19
Reilly	of Brompton in the Royal Borough of Kensington and Chelsea	1990-10-11	1	\N	1805	5	8	\N	f	\N	1610	5	19
Blease	of Cromac in the City of Belfast	2008-05-16	1	\N	1806	5	8	\N	f	\N	1611	5	3
Benson	of Drovers in the County of West Sussex	1995-03-05	1	\N	1853	5	8	\N	f	\N	1612	5	3
Bridge of Harwich	of Harwich in the County of Essex	2007-11-20	1	vice V Dilhorne resigned & since died	1852	1	8	\N	f	\N	1613	5	3
Swann	of Coln St Denys in the County of Gloucestershire	1990-09-22	1	\N	1854	5	8	\N	f	\N	1614	5	20
Tordoff	of Knutsford in the County of Cheshire	2019-06-22	1	\N	1855	5	8	\N	f	\N	1615	5	21
Jenkins of Putney	of Wandsworth in Greater London	2004-01-26	1	\N	1857	5	8	\N	f	\N	1616	5	11
Bishopston	of Newark in the County of Nottinghamshire	1984-04-19	1	\N	1860	5	8	\N	f	\N	1617	5	3
Beloff	of Wolvercote in the County of Oxfordshire	1999-03-22	1	\N	1862	5	8	\N	f	\N	1618	5	3
Elystan-Morgan	of Aberteifi in the County of Dyfed	\N	\N	\N	1863	5	8	\N	f	\N	1619	5	6
Plummer of St. Marylebone	of the City of Westminster	2009-10-02	1	\N	1865	5	8	\N	f	\N	1620	5	17
Stodart of Leaston	of Humbie in the District of East Lothian	2003-05-31	1	\N	1866	5	8	\N	f	\N	1621	5	20
Thomas of Swynnerton	of Notting Hill in Greater London	2017-05-07	1	\N	1868	5	8	\N	f	\N	1622	5	21
Mayhew	of Wimbledon in Greater London	1997-01-07	1	\N	1870	5	8	\N	f	\N	1623	5	14
Marsh	of Mannington in the County of Wiltshire	2011-07-29	1	\N	1871	5	8	\N	f	\N	1624	5	14
Constantine of Stanmore	of Stanmore in Greater London	2004-02-13	1	\N	1872	5	8	\N	f	\N	1625	5	4
Kadoorie	of Kowloon in Kong Kong and of the City of Westminster	1993-08-25	1	\N	1873	5	8	\N	f	\N	1626	5	12
Forte	of Ripley in the County of Surrey	2007-02-28	1	\N	1875	5	8	\N	f	\N	1627	5	7
Ewart-Biggs	of Ellis Green in the County of Essex	1992-10-08	1	\N	1861	5	8	\N	f	\N	1628	5	6
McFarlane of Llandaff	of Llandaff in the County of South Glamorgan	2012-05-13	1	\N	1832	5	8	\N	f	\N	1630	5	14
Nicol	of Newnham in the County of Cambridgeshire	2018-01-15	1	\N	1886	5	8	\N	f	\N	1672	5	15
Brandon of Oakbrook	of Hammersmith in Greater London	1999-03-24	1	\N	1874	1	8	\N	f	\N	1635	5	3
Bancroft	of Coatham in the County of Cleveland	1996-11-19	1	\N	1877	5	8	\N	f	\N	1636	5	3
Brightman	of Ibthorpe in the County of Hampshire	2006-02-06	1	\N	1878	1	8	\N	f	\N	1637	5	3
Pennock	of Norton in the County of Cleveland	1993-02-23	1	\N	1881	5	8	\N	f	\N	1639	5	17
Gormley	of Ashton-in-Makerfield in Greater Manchester	1993-05-27	1	\N	1882	5	8	\N	f	\N	1640	5	8
Templeman	of White Lackington in the County of Somerset	2014-06-04	1	retired 30 Sep 1994	1883	1	8	\N	f	\N	1641	5	21
Lewin	of Greenwich in Greater London	1999-01-23	1	\N	1884	5	8	\N	f	\N	1642	5	13
McIntosh of Haringey	of Haringey in Greater London	2010-08-27	1	\N	1885	5	8	\N	f	\N	1643	5	14
Taylor of Hadfield	of Hadfield in the County of Derbyshire	1995-02-15	1	\N	1888	5	8	\N	f	\N	1644	5	21
Ingrow	of Keighley in the County of West Yorkshire	2002-02-07	1	\N	1889	5	8	\N	f	\N	1645	5	10
Ezra	of Horsham in the County of West Sussex	2015-12-22	1	\N	1890	5	8	\N	f	\N	1646	5	6
Rayner	of Crowborough in the County of East Sussex	1998-06-26	1	\N	1891	5	8	\N	f	\N	1647	5	19
Marshall of Leeds	of Shadwell in the City of Leeds	1990-11-01	1	\N	1848	5	8	\N	f	\N	1648	5	14
Weinstock	of Bowden in the County of Wiltshire	2002-07-23	1	\N	1849	5	8	\N	f	\N	1649	5	24
Gallacher	of Enfield in Greater London	2004-01-04	1	\N	1897	5	8	\N	f	\N	1651	5	8
Hanson	of Edgerton in the County of West Yorkshire	2004-11-01	1	\N	1899	5	8	\N	f	\N	1652	5	9
Whitelaw	of Penrith in the County of Cumbria	1999-07-01	1	\N	1898	2	12	\N	f	\N	1653	5	24
Howard of Henderskelfe	of Henderskelfe in the County of North Yorkshire	1984-11-27	1	\N	1900	5	8	\N	f	\N	1654	5	9
King of Wartnaby	of Wartnaby in the County of Leicestershire	2005-07-12	1	\N	1903	5	8	\N	f	\N	1655	5	12
Gray of Contin	of Contin in the District of Ross and Cromarty	2006-03-14	1	\N	1901	5	8	\N	f	\N	1656	5	8
Tonypandy	of Rhondda in the County of Mid Glamorgan	1997-09-22	1	\N	1902	2	12	\N	f	\N	1657	5	21
Blanch	of Bishopthorpe in the County of North Yorkshire	1994-06-03	1	\N	1904	5	8	\N	f	\N	1658	5	3
Stallard	of St Pancras in the London Borough of Camden	2008-03-29	1	\N	1905	5	8	\N	f	\N	1659	5	20
Ennals	of Norwich in the County of Norfolk	1995-06-17	1	\N	1906	5	8	\N	f	\N	1660	5	6
Graham of Edmonton	of Edmonton in Greater London	\N	\N	\N	1907	5	8	\N	f	\N	1661	5	8
Stoddart of Swindon	of Reading in the Royal County of Berkshire	\N	\N	\N	1908	5	8	\N	f	\N	1662	5	20
Wilson of Rievaulx	of Kirklees in the County of West Yorkshire	1995-05-24	1	\N	1909	5	8	\N	f	\N	1663	5	24
Broxbourne	of Broxbourne in the County of Hertfordshire	1992-01-22	1	\N	1911	5	8	\N	f	\N	1664	5	3
Kaberry of Adel	of Adel in the City of Leeds	1991-03-13	1	\N	1912	5	8	\N	f	\N	1665	5	12
Fanshawe of Richmond	of South Cerney in the County of Gloucestershire	2001-12-28	1	\N	1913	5	8	\N	f	\N	1666	5	7
Dean of Beswick	of West Leeds in the County of West Yorkshire	1999-02-26	1	\N	1914	5	8	\N	f	\N	1667	5	5
Barnett	of Heywood and Royton in Greater Manchester	2014-11-01	1	\N	1915	5	8	\N	f	\N	1668	5	3
Eden of Winton	of Rushyford in the County of Durham	\N	\N	\N	1916	5	8	\N	f	\N	1669	5	6
Peyton of Yeovil	of Yeovil in the County of Somerset	2006-11-22	1	\N	1917	5	8	\N	f	\N	1670	5	17
Cox	of Queensbury in Greater London	\N	\N	\N	1887	5	8	\N	f	\N	1671	5	4
Cayzer	of St Mary Axe in the City of London	1999-04-16	1	\N	1876	5	8	\N	f	\N	1634	5	4
Bruce-Gardyne	of Kirkden in the District of Angus	1990-04-15	1	\N	1918	5	8	\N	f	\N	1673	5	3
Hooper	of Liverpool and of St James's in the City of Westminster	\N	\N	\N	1944	5	8	\N	f	\N	1710	5	9
Grimond	of Firth in the County of Orkney	1993-10-24	1	\N	1920	5	8	\N	f	\N	1674	5	8
Fitt	of Bell's Hill in the County of Down	2005-08-26	1	\N	1921	5	8	\N	f	\N	1675	5	7
Mulley	of Manor Park in the City of Sheffield	1995-03-15	1	\N	1922	5	8	\N	f	\N	1676	5	14
Bottomley	of Middlesbrough in the County of Cleveland	1995-11-03	1	\N	1923	5	8	\N	f	\N	1677	5	3
Chapple	of Hoxton in Greater London	2004-10-19	1	\N	1929	5	8	\N	f	\N	1679	5	4
Cameron of Lochbroom	of Lochbroom in the District of Ross and Cromarty	\N	\N	\N	1927	5	8	\N	f	\N	1680	5	4
Young of Graffham	of Graffham in the County of West Sussex	\N	\N	\N	1928	5	8	\N	f	\N	1681	5	26
Murray of Epping Forest	of Telford in the County of Shropshire	2004-05-20	1	\N	1932	5	8	\N	f	\N	1682	5	14
Kimball	of Easton in the County of Leicestershire	2014-03-27	1	\N	1933	5	8	\N	f	\N	1683	5	12
Silkin of Dulwich	of North Leigh in the County of Oxfordshire	1988-08-17	1	\N	1934	5	8	\N	f	\N	1684	5	20
Butterworth	of Warwick in the County of Warwickshire	2003-06-19	1	\N	1935	5	8	\N	f	\N	1685	5	3
Prys-Davies	of Llanegryn in the County of Gwynedd	2017-03-28	1	\N	1893	5	8	\N	f	\N	1687	5	17
Bauer	of Market Ward in the City of Cambridge	2002-05-03	1	\N	1894	5	8	\N	f	\N	1688	5	3
Cameron of Balhousie	of Balhousie in the District of Perth and Kinross	1985-01-29	1	\N	1896	5	8	\N	f	\N	1689	5	4
Morton of Shuna	of Stockbridge in the District of the City of Edinburgh	1995-04-26	1	\N	1942	5	8	\N	f	\N	1690	5	14
Sanderson of Bowden	of Melrose in the District of Ettrick and Lauderdale	\N	\N	\N	1943	5	8	\N	f	\N	1691	5	20
Wolfson	of Marylebone in the City of Westminster	2010-05-20	1	\N	1945	5	8	\N	f	\N	1692	5	24
Mellish	of Bermondsey in Greater London	1998-05-09	1	\N	1946	5	8	\N	f	\N	1693	5	14
Marshall of Goring	of South Stoke in the County of Oxfordshire	1996-02-20	1	\N	1947	5	8	\N	f	\N	1694	5	14
Dainton	of Hallam Moors in South Yorkshire	1997-12-05	1	\N	1951	5	8	\N	f	\N	1695	5	5
Ackner	of Sutton in the County of West Sussex	2006-03-21	1	resigned 30 Sep 1992	1948	1	8	\N	f	\N	1696	5	2
Oliver of Aylmerton	of Aylmerton in the County of Norfolk	2007-10-17	1	\N	1949	1	8	\N	f	\N	1697	5	16
Goff of Chieveley	of Chieveley in the Royal County of Berkshire	2016-08-14	1	\N	1950	1	8	\N	f	\N	1698	5	8
Bonham-Carter	of Yarnbury in the County of Wiltshire	1994-09-04	1	\N	1952	5	8	\N	f	\N	1699	5	3
Moore of Wolvercote	of Wolvercote in the City of Oxford	2009-04-07	1	\N	1953	5	8	\N	f	\N	1700	5	14
Deedes	of Aldington in the County of Kent	2007-08-17	1	\N	1955	5	8	\N	f	\N	1701	5	5
Wyatt of Weeford	of Weeford in the County of Staffordshire	1997-12-07	1	\N	1956	5	8	\N	f	\N	1702	5	24
Bramall	of Bushfield in the County of Hampshire	2019-11-12	1	\N	1957	5	8	\N	f	\N	1703	5	3
Carter	of Devizes in the County of Wiltshire	2006-12-18	1	\N	1959	5	8	\N	f	\N	1704	5	4
Peston	of Mile End in Greater London	2016-04-23	1	\N	1960	5	8	\N	f	\N	1705	5	17
Irvine of Lairg	of Lairg in the District of Sutherland	\N	\N	\N	1961	5	8	\N	f	\N	1706	5	10
Stevens of Ludgate	of Ludgate in the City of London	\N	\N	\N	1962	5	8	\N	f	\N	1707	5	20
Basnett	of Leatherhead in the County of Surrey	1989-01-25	1	\N	1964	5	8	\N	f	\N	1708	5	3
Stockton	\N	\N	\N	\N	1926	2	6	\N	t	\N	1709	5	20
Warnock	of Weeke in the City of Winchester	2019-03-20	1	\N	1930	5	8	\N	f	\N	1711	5	24
Turner of Camden	of Camden in Greater London	2018-02-26	1	some sources give date of birth as 18 Sep 1927	1941	5	8	\N	f	\N	1749	5	21
Trafford	of Falmer in the County of East Sussex	1989-09-16	1	\N	1965	5	8	\N	f	\N	1712	5	21
Hart of South Lanark	of Lanark in the County of Lanark	1991-12-08	1	\N	1991	5	8	\N	f	\N	1747	5	9
Plumb	of Coleshill in the County of Warwickshire	\N	\N	\N	1966	5	8	\N	f	\N	1713	5	17
Goold	of Waterfoot in the District of Eastwood	1997-07-27	1	\N	1968	5	8	\N	f	\N	1714	5	8
Chilver	of Cranfield in the County of Bedfordshire	2012-07-08	1	\N	1970	5	8	\N	f	\N	1715	5	4
Knights	of Edgbaston in the County of West Midlands	2014-12-11	1	\N	1971	5	8	\N	f	\N	1716	5	12
Cocks of Hartcliffe	of Chinnor in the County of Oxfordshire	2001-03-26	1	\N	1973	5	8	\N	f	\N	1717	5	4
Thomas of Gwydir	of Llanrwst in the County of Gwynedd	2008-02-04	1	\N	1974	5	8	\N	f	\N	1718	5	21
Jay	of Battersea in Greater London	1996-03-06	1	\N	1975	5	8	\N	f	\N	1719	5	11
Pym	of Sandy in the County of Bedfordshire	2008-03-07	1	\N	1976	5	8	\N	f	\N	1720	5	17
Joseph	of Portsoken in the City of London	1994-12-10	1	\N	1977	5	8	\N	f	\N	1721	5	11
Dormand of Easington	of Easington in the County of Durham	2003-12-18	1	\N	1978	5	8	\N	f	\N	1722	5	5
Prior	of Brampton in the County of Suffolk	2016-12-12	1	\N	1979	5	8	\N	f	\N	1723	5	17
Crickhowell	of Pont Esgob in the Black Mountains and the County of Powys	2018-03-17	1	\N	1980	5	8	\N	f	\N	1724	5	4
Colnbrook	of Waltham St Lawrence in the Royal County of Berkshire	1996-10-04	1	\N	1981	5	8	\N	f	\N	1725	5	4
Donoughue	of Ashton in the County of Northamptonshire	\N	\N	\N	1938	5	8	\N	f	\N	1726	5	5
Griffiths	of Govilon in the County of Gwent	2015-05-30	1	\N	1940	1	8	\N	f	\N	1727	5	8
Rees	of Goytre in the County of Gwent	2008-11-30	1	\N	1988	5	8	\N	f	\N	1728	5	19
Jenkins of Hillhead	of Pontypool in the County of Gwent	2003-01-05	1	\N	1989	5	8	\N	f	\N	1729	5	11
Jakobovits	of Regent's Park in Greater London	1999-10-31	1	\N	1990	5	8	\N	f	\N	1730	5	11
Donaldson of Lymington	of Lymington in the County of Hampshire	2005-08-31	1	\N	1993	5	8	\N	f	\N	1731	5	5
Armstrong of Ilminster	of Ashill in the County of Somerset	\N	\N	\N	1994	5	8	\N	f	\N	1732	5	2
Alexander of Weedon	of Newcastle-under-Lyme in the County of Staffordshire	2005-11-06	1	\N	1995	5	8	\N	f	\N	1733	5	2
Rees-Mogg	of Hinton Blewitt in the County of Avon	2012-12-29	1	\N	1996	5	8	\N	f	\N	1734	5	19
Butterfield	of Stechford in the County of West Midlands	2000-07-22	1	\N	1997	5	8	\N	f	\N	1735	5	3
Mackenzie-Stuart	of Dean in the District of the City of Edinburgh	2000-04-01	1	\N	1998	5	8	\N	f	\N	1736	5	14
Macaulay of Bragar	of Bragar in the County of Ross and Cromarty	2014-06-12	1	\N	1999	5	8	\N	f	\N	1737	5	14
Sainsbury of Preston Candover	of Preston Candover in the County of Hampshire	\N	\N	\N	2000	5	8	\N	f	\N	1738	5	20
Lewis of Newnham	of Newnham in the County of Cambridgeshire	2014-07-17	1	\N	2001	5	8	\N	f	\N	1739	5	13
Sharp of Grimsdyke	of Stanmore in the London Borough of Harrow	1994-05-02	1	\N	2004	5	8	\N	f	\N	1740	5	20
Walton of Detchant	of Detchant in the County of Northumberland	2016-04-21	1	\N	2005	5	8	\N	f	\N	1741	5	24
Fraser of Carmyllie	of Carmyllie in the District of Angus	2013-06-22	1	\N	2003	5	8	\N	f	\N	1742	5	7
McColl of Dulwich	of Bermondsey in the London Borough of Southwark	\N	\N	\N	2006	5	8	\N	f	\N	1743	5	14
Tombs	of Brailes in the County of Warwickshire	\N	\N	\N	2009	5	8	\N	f	\N	1745	5	21
Blatch	of Hinchingbrooke in the County of Cambridgeshire	2005-05-31	1	\N	1967	5	8	\N	f	\N	1746	5	3
Hilton of Eggardon	of Eggardon in the County of Dorset	\N	\N	\N	2044	5	8	\N	f	\N	1783	5	9
Hollis of Heigham	of Heigham in the City of Norwich	2018-10-13	1	\N	2021	5	8	\N	f	\N	1784	5	9
Mallalieu	of Studdridge in the County of Buckinghamshire	\N	\N	\N	2045	5	8	\N	f	\N	1785	5	14
O'Cathain	of The Barbican in the City of London	\N	\N	\N	2047	5	8	\N	f	\N	1786	5	16
Perry of Southwark	of Charlbury in the County of Oxfordshire	\N	\N	\N	2051	5	8	\N	f	\N	1787	5	17
Seccombe	of Kineton in the County of Warwickshire	\N	\N	\N	2037	5	8	\N	f	\N	1788	5	20
Clinton-Davis	of Hackney in the London Borough of Hackney	\N	\N	surname was "Davis" at time of announcement of the peerage	2010	5	8	\N	f	\N	1750	5	4
Flather	of Windsor and Maidenhead in the Royal County of Berkshire	\N	\N	\N	2022	5	8	\N	f	\N	1781	5	7
Morris of Castle Morris	of St Dogmaels in the County of Dyfed	2001-04-30	1	\N	2011	5	8	\N	f	\N	1751	5	14
Richard	of Ammanford in the County of Dyfed	2018-03-18	1	\N	2013	5	8	\N	f	\N	1752	5	19
Wade of Chorlton	of Chester in the County of Cheshire	2018-06-07	1	\N	2014	5	8	\N	f	\N	1753	5	24
Cavendish of Furness	of Cartmel in the County of Cumbria	\N	\N	\N	2015	5	8	\N	f	\N	1754	5	4
Holme of Cheltenham	of Cheltenham in the County of Gloucestershire	2008-05-04	1	\N	2019	5	8	\N	f	\N	1756	5	9
Varley	of Chesterfield in the County of Derbyshire	2008-07-29	1	\N	2020	5	8	\N	f	\N	1757	5	23
Pearson of Rannoch	of Bridge of Gaur in the District of Perth and Kinross	\N	\N	\N	2023	5	8	\N	f	\N	1758	5	17
Porter of Luddenham	of Luddenham in the County of Kent	2002-08-31	1	\N	2024	5	8	\N	f	\N	1759	5	17
Mason of Barnsley	of Barnsley in South Yorkshire	2015-04-19	1	\N	1983	5	8	\N	f	\N	1760	5	14
Carlisle of Bucklow	of Mobberley in the County of Cheshire	2005-07-14	1	\N	1984	5	8	\N	f	\N	1761	5	4
Ross of Newport	of Newport in the County of the Isle of Wight	1993-05-10	1	\N	1986	5	8	\N	f	\N	1762	5	19
Waddington	of Read in the County of Lancashire	2017-02-24	1	\N	2029	5	8	\N	f	\N	1763	5	24
White of Hull	of Hull in the County of Humberside	1995-08-23	1	\N	2031	5	8	\N	f	\N	1764	5	24
Runcie	of Cuddesdon in the County of Oxfordshire	2000-07-11	1	\N	2032	5	8	\N	f	\N	1765	5	19
Palumbo	of Walbrook in the City of London	\N	\N	\N	2033	5	8	\N	f	\N	1766	5	17
Griffiths of Fforestfach	of Fforestfach in the County of West Glamorgan	\N	\N	\N	2034	5	8	\N	f	\N	1767	5	8
Laing of Dunphail	of Dunphail in the District of Moray	2010-06-21	1	\N	2036	5	8	\N	f	\N	1768	5	13
Wolfson of Sunningdale	of Trevose in the County of Cornwall	\N	\N	\N	2038	5	8	\N	f	\N	1769	5	24
Desai	of St Clement Danes in the City of Westminster	\N	\N	\N	2039	5	8	\N	f	\N	1770	5	5
Judd	of Portsea in the County of Hampshire	\N	\N	\N	2042	5	8	\N	f	\N	1771	5	11
Renfrew of Kaimsthorn	of Hurlet in the District of Renfrew	\N	\N	\N	2048	5	8	\N	f	\N	1772	5	19
Skidelsky	of Tilton in the County of East Sussex	\N	\N	\N	2050	5	8	\N	f	\N	1774	5	20
Cheshire	of Woodhall in the County of Lincolnshire	1992-07-31	1	\N	2052	5	8	\N	f	\N	1775	5	4
Macfarlane of Bearsden	of Bearsden in the District of Bearsden and Milngavie	\N	\N	\N	2053	5	8	\N	f	\N	1776	5	14
Craig of Radley	of Helhoughton in the County of Norfolk	\N	\N	\N	2054	5	8	\N	f	\N	1777	5	4
Browne-Wilkinson	of Camden in the London Borough of Camden	2018-07-25	1	\N	2055	1	8	\N	f	\N	1778	5	3
Mustill	of Pateley Bridge in the County of North Yorkshire	2015-04-24	1	\N	2056	1	8	\N	f	\N	1779	5	14
Eccles of Moulton	of Moulton in the County of North Yorkshire	\N	\N	\N	2012	5	8	\N	f	\N	1780	5	6
Hamwee	of Richmond upon Thames in the London Borough of Richmond upon Thames	\N	\N	\N	2040	5	8	\N	f	\N	1782	5	9
Thatcher	of Kesteven in the County of Lincolnshire	2013-04-08	1	\N	2066	5	8	\N	f	\N	1826	5	21
Prentice	of Daventry in the County of Northamptonshire	2001-01-18	1	\N	2058	5	8	\N	f	\N	1790	5	17
Rodgers of Quarry Bank	of Kentish Town in the London Borough of Camden	\N	\N	\N	2059	5	8	\N	f	\N	1791	5	19
Wilson of Tillyorn	of Finzean in the District of Kincardine and Deeside and of Fanling in Hong Kong	\N	\N	\N	2060	5	8	\N	f	\N	1792	5	24
Slynn of Hadley	of Eggington in the County of Bedfordshire	2009-04-07	1	vice L Bridge of Harwich resigned	2061	1	8	\N	f	\N	1793	5	20
Wakeham	of Maldon in the County of Essex	\N	\N	\N	2062	5	8	\N	f	\N	1794	5	24
Taylor of Gosforth	of Embleton in the County of Northumberland	1997-04-28	1	\N	2064	5	8	\N	f	\N	1795	5	21
Rodger of Earlsferry	of Earlsferry in the District of North East Fife	2011-06-26	1	\N	2065	5	8	\N	f	\N	1796	5	19
Finsberg	of Hampstead in the London Borough of Camden	1996-10-07	1	\N	2067	5	8	\N	f	\N	1797	5	7
Parkinson	of Carnforth in the County of Lancashire	2016-01-22	1	\N	2068	5	8	\N	f	\N	1798	5	17
Healey	of Riddlesden in the County of West Yorkshire	2015-10-03	1	\N	2069	5	8	\N	f	\N	1799	5	9
Lane of Horsell	of Woking in the County of Surrey	2009-01-09	1	\N	2026	5	8	\N	f	\N	1800	5	13
Haslam	of Bolton in the County of Greater Manchester	2002-11-02	1	\N	2027	5	8	\N	f	\N	1801	5	9
Moore of Lower Marsh	of Lower Marsh in the London Borough of Lambeth	2019-05-20	1	\N	2075	5	8	\N	f	\N	1803	5	14
Tebbit	of Chingford in the London Borough of Waltham Forest	\N	\N	\N	2076	5	8	\N	f	\N	1804	5	21
Amery of Lustleigh	of Preston in the County of Lancashire and of Brighton in the County of East Sussex	1996-09-03	1	\N	2078	5	8	\N	f	\N	1806	5	2
Walker of Worcester	of Abbots Morton in the County of Hereford and Worcester	2010-06-23	1	\N	2079	5	8	\N	f	\N	1807	5	24
Archer of Sandwell	of Sandwell in the County of West Midlands	2012-06-14	1	\N	2080	5	8	\N	f	\N	1808	5	2
Ashley of Stoke	of Widnes in the County of Cheshire	2012-04-20	1	\N	2081	5	8	\N	f	\N	1809	5	2
Eatwell	of Stratton St Margaret in the County of Wiltshire	\N	\N	\N	2082	5	8	\N	f	\N	1810	5	6
Weatherill	of North East Croydon in the London Borough of Croydon	2007-05-06	1	\N	2083	5	8	\N	f	\N	1811	5	24
Ewing of Kirkford	of Cowdenbeath in the District of Dunfermline	2007-06-09	1	\N	2084	5	8	\N	f	\N	1812	5	6
Geraint	of Ponterwyd in the County of Dyfed	2004-04-17	1	\N	2085	5	8	\N	f	\N	1813	5	8
Stewartby	of Portmoak in the District of Perth and Kinross	2018-03-03	1	\N	2086	5	8	\N	f	\N	1814	5	20
Clark of Kempston	of Kempston in the County of Bedfordshire	2004-10-04	1	\N	2087	5	8	\N	f	\N	1815	5	4
Plant of Highfield	of Weelsby in the County of Humberside	\N	\N	\N	2088	5	8	\N	f	\N	1816	5	17
Archer of Weston-Super-Mare	of Mark in the County of Somerset	\N	\N	\N	2089	5	8	\N	f	\N	1817	5	2
Ridley of Liddesdale	of Willimontswick in the County of Northumberland	1993-03-04	1	\N	2090	5	8	\N	f	\N	1818	5	19
Williams of Mostyn	of Great Tew in the County of Oxfordshire	2003-09-20	1	\N	2092	5	8	\N	f	\N	1819	5	24
Braine of Wheatley	of Rayleigh in the County of Essex	2000-01-05	1	\N	2093	5	8	\N	f	\N	1820	5	3
Cooke of Islandreagh	of Islandreagh in the County of Antrim	2007-11-13	1	\N	2094	5	8	\N	f	\N	1821	5	4
Hayhoe	of Isleworth in the London Borough of Hounslow	2013-09-07	1	\N	2096	5	8	\N	f	\N	1822	5	9
Elis-Thomas	of Nant Conwy in the County of Gwynedd	\N	\N	surname changed from Thomas after peerage announced	2098	5	8	\N	f	\N	1824	5	6
Jay of Paddington	of Paddington in the City of Westminster	\N	\N	dau of L Callaghan of Cardiff	2091	5	8	\N	f	\N	1825	5	11
Rix	of Whitehall in the City of Westminster and of Hornsea in Yorkshire	2016-08-20	1	\N	2057	5	8	\N	f	\N	1789	5	19
Miller of Hendon	of Gore in the London Borough of Barnet	2014-06-21	1	\N	2112	5	8	\N	f	\N	1862	5	14
Rawlings	of Burnham Westgate in the County of Norfolk	\N	\N	\N	2127	5	8	\N	f	\N	1863	5	19
Thomas of Walliswood	of Dorking in the County of Surrey	\N	\N	\N	2128	5	8	\N	f	\N	1864	5	21
Williams of Crosby	of Stevenage in the County of Hertfordshire	\N	\N	\N	2100	5	8	\N	f	\N	1865	5	24
Kingsdown	of Pemberton in the County of Lancashire	2013-11-24	1	\N	2101	5	8	\N	f	\N	1827	5	12
Gould of Potternewton	of Leeds in the County of West Yorkshire	\N	\N	\N	2108	5	8	\N	f	\N	1860	5	8
Dahrendorf	of Clare Market in the City of Westminster	2009-06-17	1	\N	2102	5	8	\N	f	\N	1828	5	5
Menuhin	of Stoke d'Abernon in the County of Surrey	1999-03-12	1	\N	2103	5	8	\N	f	\N	1829	5	14
Attenborough	of Richmond upon Thames in the London Borough of Richmond upon Thames	2014-08-24	1	\N	2104	5	8	\N	f	\N	1830	5	2
Lloyd of Berwick	of Ludlay in the County of East Sussex	\N	\N	vice L Griffiths	2105	1	8	\N	f	\N	1831	5	13
Haskel	of Higher Broughton in the County of Greater Manchester	\N	\N	\N	2106	5	8	\N	f	\N	1832	5	9
Dean of Harptree	of Wedmore in the County of Somerset	2009-04-01	1	\N	2107	5	8	\N	f	\N	1833	5	5
Dixon-Smith	of Bocking in the County of Essex	\N	\N	\N	2109	5	8	\N	f	\N	1834	5	5
Lester of Herne Hill	of Herne Hill in the London Borough of Southwark	\N	\N	\N	2111	5	8	\N	f	\N	1835	5	13
Lawson of Blaby	of Newnham in the County of Northamptonshire	\N	\N	\N	2072	5	8	\N	f	\N	1836	5	13
Howell	of Aston Manor in the City of Birmingham	1998-04-19	1	\N	2074	5	8	\N	f	\N	1837	5	9
Quirk	of Bloomsbury in the London Borough of Camden	2017-12-20	1	\N	2117	5	8	\N	f	\N	1838	5	18
Phillips of Ellesmere	of Ellesmere in the County of Shropshire	1999-02-23	1	\N	2118	5	8	\N	f	\N	1839	5	17
Sheppard of Didgemere	of Roydon in the County of Essex	2015-03-25	1	\N	2119	5	8	\N	f	\N	1840	5	20
Hambro	of Dixton and Dumbleton in the County of Gloucestershire	2002-11-07	1	\N	2120	5	8	\N	f	\N	1841	5	9
Dubs	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2121	5	8	\N	f	\N	1842	5	5
Gladwin of Clee	of Great Grimsby in the County of Humberside	2003-04-10	1	\N	2122	5	8	\N	f	\N	1843	5	8
Shaw of Northstead	of Liversedge in the County of West Yorkshire	\N	\N	\N	2124	5	8	\N	f	\N	1844	5	20
Tope	of Sutton in the London Borough of Sutton	\N	\N	\N	2126	5	8	\N	f	\N	1846	5	21
Kingsland	of Shrewsbury in the County of Shropshire	2009-07-12	1	\N	2129	5	8	\N	f	\N	1847	5	12
Steyn	of Swafield in the County of Norfolk	2017-11-28	1	\N	2131	1	8	\N	f	\N	1849	5	20
McConnell	of Lisburn in the County of Antrim	2000-10-25	1	\N	2133	5	8	\N	f	\N	1850	5	14
Hoffmann	of Chedworth in the County of Gloucestershire	\N	\N	\N	2135	1	8	\N	f	\N	1851	5	9
Blyth of Rowington	of Rowington in the County of Warwickshire	\N	\N	\N	2137	5	8	\N	f	\N	1852	5	3
Cuckney	of Millbank in the City of Westminster	2008-10-30	1	\N	2138	5	8	\N	f	\N	1853	5	4
Eames	of Armagh in the County of Armagh	\N	\N	\N	2139	5	8	\N	f	\N	1854	5	6
Habgood	of Calverton in the County of Buckinghamshire	2019-03-06	1	\N	2140	5	8	\N	f	\N	1855	5	9
Mackay of Drumadoon	of Blackwaterfoot in the District of Cunninghame	2018-08-21	1	\N	2141	5	8	\N	f	\N	1856	5	14
Winston	of Hammersmith in the London Borough of Hammersmith and Fulham	\N	\N	\N	2142	5	8	\N	f	\N	1857	5	24
Wallace of Saltaire	of Shipley in the County of West Yorkshire	\N	\N	\N	2143	5	8	\N	f	\N	1858	5	24
Farrington of Ribbleton	of Fulwood in the County of Lancashire	2018-03-30	1	\N	2123	5	8	\N	f	\N	1859	5	7
Hogg	of Kettlethorpe in the County of Lincolnshire	\N	\N	\N	2132	5	8	\N	f	\N	1861	5	9
Lestor of Eccles	of Tooting Bec in the London Borough of Wandsworth	1998-03-27	1	\N	2186	5	8	\N	f	\N	1903	5	13
Ramsay of Cartvale	of Langside in the City of Glasgow	\N	\N	\N	2169	5	8	\N	f	\N	1904	5	19
Symons of Vernham Dean	of Vernham Dean in the County of Hampshire	\N	\N	\N	2166	5	8	\N	f	\N	1905	5	20
Wilcox	of Plymouth in the County of Devon	\N	\N	\N	2151	5	8	\N	f	\N	1906	5	24
McNally	of Blackpool in the County of Lancashire	\N	\N	\N	2144	5	8	\N	f	\N	1866	5	14
Borrie	of Abbots Morton in the County of Hereford and Worcester	2016-09-30	1	\N	2145	5	8	\N	f	\N	1867	5	3
Sewel	of Gilcomstoun in the District of the City of Aberdeen	\N	\N	\N	2147	5	8	\N	f	\N	1868	5	20
Pilkington of Oxenford	of West Dowlish in the County of Somerset	2011-02-14	1	\N	2149	5	8	\N	f	\N	1869	5	17
Feldman	of Frognal in the London Borough of Camden	2019-11-19	1	\N	2150	5	8	\N	f	\N	1870	5	7
Kilpatrick of Kincraig	of Dysart in the District of Kirkcaldy	2015-09-16	1	\N	2154	5	8	\N	f	\N	1871	5	12
Gillmore of Thamesfield	of Putney in the London Borough of Wandsworth	1999-03-20	1	\N	2155	5	8	\N	f	\N	1872	5	8
Bingham of Cornhill	of Boughrood in the County of Powys	2010-09-11	1	\N	2157	5	8	\N	f	\N	1873	5	3
Nolan	of Brasted in the County of Kent	2007-01-22	1	vice L Lowry resigned	2114	1	8	\N	f	\N	1874	5	15
Taverne	of Pimlico in the City of Westminster	\N	\N	\N	2153	5	8	\N	f	\N	1875	5	21
Nickson	of Renagour in the District of Stirling	\N	\N	\N	2116	5	8	\N	f	\N	1876	5	15
Taylor of Warwick	of Warwick in the County of Warwickshire	\N	\N	\N	2164	5	8	\N	f	\N	1878	5	21
Saatchi	of Staplefield in the County of West Sussex	\N	\N	\N	2165	5	8	\N	f	\N	1879	5	20
Alderdice	of Knock in the City of Belfast	\N	\N	\N	2167	5	8	\N	f	\N	1880	5	2
Paul	of Marylebone in the City of Westminster	\N	\N	\N	2168	5	8	\N	f	\N	1881	5	17
Rogers of Riverside	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2173	5	8	\N	f	\N	1882	5	19
MacLaurin of Knebworth	of Knebworth in the County of Hertfordshire	\N	\N	\N	2174	5	8	\N	f	\N	1883	5	14
Whitty	of Camberwell in the London Borough of Southwark	\N	\N	\N	2175	5	8	\N	f	\N	1884	5	24
Lloyd-Webber	of Sydmonton in the County of Hampshire	\N	\N	\N	2179	5	8	\N	f	\N	1885	5	13
Hoyle	of Warrington in the County of Cheshire	\N	\N	\N	2180	5	8	\N	f	\N	1886	5	9
Falconer of Thoroton	of Thoroton in the County of Nottinghamshire	\N	\N	\N	2181	5	8	\N	f	\N	1887	5	7
Simon of Highbury	of Canonbury in the London Borough of Islington	\N	\N	\N	2182	5	8	\N	f	\N	1888	5	20
Gilbert	of Dudley in the County of West Midlands	2013-06-02	1	\N	2183	5	8	\N	f	\N	1889	5	8
Biffen	of Tanat in the County of Shropshire	2007-08-14	1	\N	2185	5	8	\N	f	\N	1890	5	3
Hardie	of Blackford in the City of Edinburgh	\N	\N	\N	2184	5	8	\N	f	\N	1891	5	9
Jopling	of Ainderby Quernhow in the County of North Yorkshire	\N	\N	\N	2187	5	8	\N	f	\N	1892	5	11
Shore of Stepney	of Stepney in the London Borough of Tower Hamlets	2001-09-24	1	\N	2188	5	8	\N	f	\N	1893	5	20
Howell of Guildford	of Penton Mewsey in the County of Hampshire	\N	\N	\N	2189	5	8	\N	f	\N	1894	5	9
Steel of Aikwood	of Ettrick Forest in The Scottish Borders	\N	\N	\N	2190	5	8	\N	f	\N	1895	5	20
Dixon	of Jarrow in the County of Tyne and Wear	2017-02-19	1	\N	2191	5	8	\N	f	\N	1896	5	5
Renton of Mount Harry	of Offham in the County of East Sussex	\N	\N	\N	2192	5	8	\N	f	\N	1897	5	19
Evans of Parkside	of St Helens in the County of Merseyside	2016-03-05	1	\N	2193	5	8	\N	f	\N	1898	5	6
Byford	of Rothley in the County of Leicestershire	\N	\N	\N	2171	5	8	\N	f	\N	1900	5	3
Hayman	of Dartmouth Park in the London Borough of Camden	\N	\N	\N	2146	5	8	\N	f	\N	1902	5	9
Lofthouse of Pontefract	of Pontefract in the County of West Yorkshire	2012-11-01	1	\N	2195	5	8	\N	f	\N	1907	5	13
Ludford	of Clerkenwell in the London Borough of Islington	\N	\N	\N	2219	5	8	\N	f	\N	1944	5	13
Kelvedon	of Ongar in the County of Essex	2007-01-27	1	\N	2196	5	8	\N	f	\N	1908	5	12
Alton of Liverpool	of Mossley Hill in the County of Merseyside	\N	\N	\N	2197	5	8	\N	f	\N	1909	5	2
Mayhew of Twysden	of Kilndown in the County of Kent	2016-06-25	1	\N	2198	5	8	\N	f	\N	1910	5	14
Hurd of Westwell	of Westwell in the County of Oxfordshire	\N	\N	\N	2199	5	8	\N	f	\N	1911	5	9
Baker of Dorking	of Iford in the County of East Sussex	\N	\N	\N	2200	5	8	\N	f	\N	1912	5	3
Patten	of Wincanton in the County of Somerset	\N	\N	\N	2201	5	8	\N	f	\N	1913	5	17
Cowdrey of Tonbridge	of Tonbridge in the County of Kent	2000-12-04	1	\N	2202	5	8	\N	f	\N	1914	5	4
Vincent of Coleshill	of Shrivenham in the County of Oxfordshire	2018-09-08	1	\N	2159	5	8	\N	f	\N	1915	5	23
Hussey of North Bradley	of North Bradley in the County of Wiltshire	2006-12-27	1	\N	2160	5	8	\N	f	\N	1916	5	9
Thomas of Gresford	of Gresford in the County Borough of Wrexham	\N	\N	\N	2161	5	8	\N	f	\N	1917	5	21
Levy	of Mill Hill in the London Borough of Barnet	\N	\N	\N	2207	5	8	\N	f	\N	1918	5	13
Hogg of Cumbernauld	of Cumbernauld in North Lanarkshire	2008-10-08	1	\N	2210	5	8	\N	f	\N	1919	5	9
Newby	of Rothwell in the County of West Yorkshire	\N	\N	\N	2211	5	8	\N	f	\N	1920	5	15
Randall of St Budeaux	of St Budeaux in the County of Devon	2012-08-11	1	St. in writ	2212	5	8	\N	f	\N	1921	5	19
Renwick of Clifton	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2213	5	8	\N	f	\N	1922	5	19
Walker of Doncaster	of Audenshaw in the County of Greater Manchester	2003-11-11	1	\N	2214	5	8	\N	f	\N	1923	5	24
Hardy of Wath	of Wath upon Dearne in the County of South Yorkshire	2003-12-16	1	\N	2215	5	8	\N	f	\N	1924	5	9
Hughes of Woodside	of Woodside in the City of Aberdeen	\N	\N	\N	2216	5	8	\N	f	\N	1925	5	9
Selkirk of Douglas	of Cramond in the City of Edinburgh	\N	\N	\N	2217	5	8	\N	f	\N	1926	5	20
Lang of Monkton	of Merrick and the Rhinns of Kells in Dumfries and Galloway	\N	\N	\N	2218	5	8	\N	f	\N	1927	5	13
Roberts of Conwy	of Talyfan in the County of Gwynedd	2013-12-13	1	\N	2222	5	8	\N	f	\N	1928	5	19
Sandberg	of Passfield in the County of Hampshire	2017-07-02	1	\N	2223	5	8	\N	f	\N	1929	5	20
Blackwell	of Woodcote in the County of Surrey	\N	\N	\N	2224	5	8	\N	f	\N	1930	5	3
Davies of Oldham	of Broxbourne in the County of Hertfordshire	\N	\N	\N	2226	5	8	\N	f	\N	1931	5	5
Gordon of Strathblane	of Deil's Craig in Stirling	\N	\N	\N	2227	5	8	\N	f	\N	1932	5	8
Cope of Berkeley	of Berkeley in the County of Gloucestershire	\N	\N	\N	2228	5	8	\N	f	\N	1933	5	4
Jacobs	of Belgravia in the City of Westminster	2014-06-21	1	\N	2231	5	8	\N	f	\N	1934	5	11
Hunt of Wirral	of Wirral in the County of Merseyside	\N	\N	\N	2233	5	8	\N	f	\N	1936	5	9
Orme	of Salford in the County of Greater Manchester	2005-04-28	1	\N	2234	5	8	\N	f	\N	1937	5	16
Razzall	of Mortlake in the London Borough of Richmond	\N	\N	\N	2236	5	8	\N	f	\N	1939	5	19
Garel-Jones	of Watford in the County of Hertfordshire	\N	\N	\N	2237	5	8	\N	f	\N	1940	5	8
Goodhart	of Youlbury in the County of Oxfordshire	2017-01-10	1	\N	2238	5	8	\N	f	\N	1941	5	8
Brooke of Alverthorpe	of Alverthorpe in the County of West Yorkshire	\N	\N	\N	2239	5	8	\N	f	\N	1942	5	3
Fookes	of Plymouth in the County of Devon	\N	\N	\N	2220	5	8	\N	f	\N	1943	5	7
Pitkeathley	of Caversham in the Royal County of Berkshire	\N	\N	\N	2229	5	8	\N	f	\N	1945	5	17
Linklater of Butterstone	of Riemore in Perth and Kinross	\N	\N	\N	2255	5	8	\N	f	\N	1981	5	13
Nicholson of Winterbourne	of Winterbourne in the Royal County of Berkshire	\N	\N	\N	2257	5	8	\N	f	\N	1982	5	15
Thornton	of Manningham in the County of West Yorkshire	\N	\N	\N	2280	5	8	\N	f	\N	1983	5	21
Uddin	of Bethnal Green in the London Borough of Tower Hamlets	\N	\N	\N	2274	5	8	\N	f	\N	1984	5	22
Young of Old Scone	of Old Scone in Perth and Kinross	\N	\N	\N	2258	5	8	\N	f	\N	1985	5	26
Dholakia	of Waltham Brooks in the County of West Sussex	\N	\N	\N	2241	5	8	\N	f	\N	1946	5	5
Crawley	of Edgbaston in the County of West Midlands	\N	\N	\N	2282	5	8	\N	f	\N	1979	5	4
Janner of Braunstone	of Leicester in the County of Leicestershire	2015-12-19	1	\N	2242	5	8	\N	f	\N	1947	5	11
Islwyn	of Casnewydd in the County of Gwent	2003-12-19	1	\N	2243	5	8	\N	f	\N	1948	5	10
Puttnam	of Queensgate in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2244	5	8	\N	f	\N	1949	5	17
Naseby	of Sandy in the County of Bedfordshire	\N	\N	\N	2246	5	8	\N	f	\N	1950	5	15
Higgins	of Worthing in the County of West Sussex	\N	\N	\N	2247	5	8	\N	f	\N	1951	5	9
Inge	of Richmond in the County of North Yorkshire	\N	\N	\N	2203	5	8	\N	f	\N	1952	5	10
Levene of Portsoken	of Portsoken in the City of London	\N	\N	\N	2205	5	8	\N	f	\N	1953	5	13
Saville of Newdigate	of Newdigate in the County of Surrey	\N	\N	vice L Mustill resigned	2206	1	8	\N	f	\N	1954	5	20
Onslow of Woking	of Woking in the County of Surrey	2001-03-13	1	\N	2252	5	8	\N	f	\N	1955	5	16
Newton of Braintree	of Coggeshall in the County of Essex	2012-03-25	1	\N	2253	5	8	\N	f	\N	1956	5	15
Bassam of Brighton	of Brighton in the County of East Sussex	\N	\N	\N	2256	5	8	\N	f	\N	1957	5	3
Smith of Clifton	of Mountsandel in the County of Londonderry	\N	\N	\N	2259	5	8	\N	f	\N	1958	5	20
Simpson of Dunkeld	of Dunkeld in Perth and Kinross	\N	\N	\N	2261	5	8	\N	f	\N	1960	5	20
Monro of Langholm	of Westerkirk in Dumfries and Galloway	2006-08-30	1	\N	2262	5	8	\N	f	\N	1961	5	14
Watson of Invergowrie	of Invergowrie in Perth and Kinross	\N	\N	\N	2263	5	8	\N	f	\N	1962	5	24
Ryder of Wensum	of Wensum in the County of Norfolk	\N	\N	\N	2264	5	8	\N	f	\N	1963	5	19
Hattersley	of Sparkbrook in the County of West Midlands	\N	\N	\N	2265	5	8	\N	f	\N	1964	5	9
Neill of Bladen	of Briantspuddle in the County of Dorset	2016-05-28	1	\N	2266	5	8	\N	f	\N	1965	5	15
Butler of Brockwell	of Herne Hill in the London Borough of Lambeth	\N	\N	\N	2267	5	8	\N	f	\N	1966	5	3
Hamlyn	of Edgeworth in the County of Gloucestershire	2001-08-31	1	\N	2270	5	8	\N	f	\N	1968	5	9
Mackenzie of Framwellgate	of Durham in the County of Durham	\N	\N	\N	2271	5	8	\N	f	\N	1969	5	14
Clement-Jones	of Clapham in the London Borough of Lambeth	\N	\N	\N	2272	5	8	\N	f	\N	1970	5	4
Alli	of Norbury in the London Borough of Croydon	\N	\N	\N	2273	5	8	\N	f	\N	1971	5	2
Burns	of Pitshanger in the London Borough of Ealing	\N	\N	\N	2276	5	8	\N	f	\N	1972	5	3
Tomlinson	of Walsall in the County of West Midlands	\N	\N	\N	2278	5	8	\N	f	\N	1973	5	21
Lamont of Lerwick	of Lerwick in the Shetland Islands	\N	\N	\N	2281	5	8	\N	f	\N	1974	5	13
Phillips of Sudbury	of Sudbury in the County of Suffolk	\N	\N	\N	2283	5	8	\N	f	\N	1975	5	17
Laming	of Tewin in the County of Hertfordshire	\N	\N	\N	2285	5	8	\N	f	\N	1976	5	13
Bach	of Lutterworth in the County of Leicestershire	\N	\N	\N	2286	5	8	\N	f	\N	1977	5	3
Buscombe	of Goring in the County of Oxfordshire	\N	\N	\N	2279	5	8	\N	f	\N	1978	5	3
Goudie	of Roundwood in the London Borough of Brent	\N	\N	\N	2277	5	8	\N	f	\N	1980	5	8
Miller of Chilthorne Domer	of Chilthorne Domer in the County of Somerset	\N	\N	\N	2287	5	8	\N	f	\N	2021	5	14
O'Neill of Bengarve	of The Braid in the County of Antrim	\N	\N	\N	2308	5	8	\N	f	\N	2022	5	16
Prashar	of Runnymede in the County of Surrey	\N	\N	\N	2318	5	8	\N	f	\N	2023	5	17
Scotland of Asthal	of Asthal in the County of Oxfordshire	\N	\N	\N	2251	5	8	\N	f	\N	2024	5	20
Stern	of Vauxhall in the London Borough of Lambeth	\N	\N	\N	2315	5	8	\N	f	\N	2025	5	20
Evans of Watford	of Chipperfield in the County of Hertfordshire	\N	\N	\N	2288	5	8	\N	f	\N	1986	5	6
Maddock	of Christchurch in the County of Dorset	\N	\N	\N	2250	5	8	\N	f	\N	2019	5	14
Warner	of Brockley in the London Borough of Lewisham	\N	\N	\N	2289	5	8	\N	f	\N	1987	5	24
Clarke of Hampstead	of Hampstead in the London Borough of Camden	\N	\N	\N	2290	5	8	\N	f	\N	1988	5	4
Brookman	of Ebbw Vale in the County of Gwent	\N	\N	\N	2292	5	8	\N	f	\N	1989	5	3
Hanningfield	of Chelmsford in the County of Essex	\N	\N	\N	2293	5	8	\N	f	\N	1990	5	9
Freeman	of Dingley in the County of Northamptonshire	\N	\N	\N	2249	5	8	\N	f	\N	1991	5	7
Bragg	of Wigton in the County of Cumbria	\N	\N	\N	2299	5	8	\N	f	\N	1992	5	3
Sawyer	of Darlington in the County of Durham	\N	\N	\N	2300	5	8	\N	f	\N	1993	5	20
Williamson of Horton	of Horton in the County of Somerset	2015-08-30	1	\N	2306	5	8	\N	f	\N	1995	5	24
Hobhouse of Woodborough	of Woodborough in the County of Wiltshire	2004-03-15	1	vice L Goff of Chieveley resigned	2302	1	8	\N	f	\N	1997	5	9
Millett	of St Marylebone in the City of Westminster	\N	\N	vice L Nolan resigned	2303	1	8	\N	f	\N	1998	5	14
Imbert	of New Romney in the County of Kent	2017-11-13	1	\N	2307	5	8	\N	f	\N	1999	5	10
Patel	of Dunkeld in Perth and Kinross	\N	\N	\N	2309	5	8	\N	f	\N	2000	5	17
Trotman	of Osmotherley in the County of North Yorkshire	2005-04-25	1	\N	2310	5	8	\N	f	\N	2001	5	21
Fellowes	of Shotesham in the County of Norfolk	\N	\N	\N	2313	5	8	\N	f	\N	2002	5	7
Stevenson of Coddenham	of Coddenham in the County of Suffolk	\N	\N	\N	2314	5	8	\N	f	\N	2003	5	20
Forsyth of Drumlean	of Drumlean in Stirling	\N	\N	\N	2316	5	8	\N	f	\N	2004	5	7
Faulkner of Worcester	of Wimbledon in the London Borough of Merton	\N	\N	\N	2317	5	8	\N	f	\N	2005	5	7
Laird	of Artigarvan in the County of Tyrone	2018-07-10	1	\N	2320	5	8	\N	f	\N	2006	5	13
Rogan	of Lower Iveagh in the County of Down	\N	\N	\N	2321	5	8	\N	f	\N	2007	5	19
Elder	of Kirkcaldy in Fife	\N	\N	\N	2323	5	8	\N	f	\N	2008	5	6
Lea of Crondall	of Crondall in the County of Hampshire	\N	\N	\N	2324	5	8	\N	f	\N	2009	5	13
Brett	of Lydd in the County of Kent	2012-03-29	1	\N	2325	5	8	\N	f	\N	2010	5	3
Rennard	of Wavertree in the County of Merseyside	\N	\N	\N	2326	5	8	\N	f	\N	2011	5	19
Bradshaw	of Wallingford in the County of Oxfordshire	\N	\N	\N	2328	5	8	\N	f	\N	2012	5	3
King of West Bromwich	of West Bromwich in the County of West Midlands	2013-01-09	1	\N	2329	5	8	\N	f	\N	2013	5	12
Watson of Richmond	of Richmond in the London Borough of Richmond upon Thames	\N	\N	\N	2330	5	8	\N	f	\N	2014	5	24
Kirkham	of Old Cantley in the County of South Yorkshire	\N	\N	\N	2331	5	8	\N	f	\N	2015	5	12
Grabiner	of Aldwych in the City of Westminster	\N	\N	\N	2332	5	8	\N	f	\N	2016	5	8
Carlile of Berriew	of Berriew in the County of Powys	\N	\N	\N	2334	5	8	\N	f	\N	2017	5	4
Hanham	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2319	5	8	\N	f	\N	2018	5	9
Massey of Darwen	of Darwen in the County of Lancashire	\N	\N	\N	2333	5	8	\N	f	\N	2020	5	14
Harris of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2353	5	8	\N	f	\N	2056	5	9
McIntosh of Hudnall	of Hampstead in the London Borough of Camden	\N	\N	\N	2346	5	8	\N	f	\N	2057	5	14
Noakes	of Goudhurst in the County of Sussex	\N	\N	\N	2400	5	8	\N	f	\N	2058	5	15
Sharp of Guildford	of Guildford in the County of Surrey	\N	\N	\N	2296	5	8	\N	f	\N	2059	5	20
Whitaker	of Beeston in the County of Nottinghamshire	\N	\N	\N	2351	5	8	\N	f	\N	2060	5	24
Oxburgh	of Liverpool in the County of Merseyside	\N	\N	\N	2335	5	8	\N	f	\N	2027	5	16
Boothroyd	of Sandwell in the County of West Midlands	\N	\N	\N	2406	5	8	\N	f	\N	2054	5	3
Harrison	of Chester in the County of Cheshire	\N	\N	\N	2336	5	8	\N	f	\N	2028	5	9
Waldegrave of North Hill	of Chewton Mendip in the County of Somerset	\N	\N	\N	2337	5	8	\N	f	\N	2029	5	24
Goldsmith	of Allerton in the County of Merseyside	\N	\N	\N	2338	5	8	\N	f	\N	2030	5	8
Filkin	of Pimlico in the City of Westminster	\N	\N	\N	2339	5	8	\N	f	\N	2031	5	7
Norton of Louth	of Louth in the County of Lincolnshire	\N	\N	\N	2295	5	8	\N	f	\N	2032	5	15
Ahmed	of Rotherham in the County of South Yorkshire	\N	\N	\N	2298	5	8	\N	f	\N	2033	5	2
Sharman	of Redlynch in the County of Wiltshire	\N	\N	\N	2344	5	8	\N	f	\N	2034	5	20
MacKenzie of Culkein	of Assynt in Highland	\N	\N	\N	2349	5	8	\N	f	\N	2036	5	14
Smith of Leigh	of Wigan in the County of Greater Manchester	\N	\N	\N	2350	5	8	\N	f	\N	2037	5	20
Gavron	of Highgate in the London Borough of Camden	2015-02-07	1	\N	2352	5	8	\N	f	\N	2038	5	8
Robertson of Port Ellen	of Islay in Argyll and Bute	\N	\N	\N	2354	5	8	\N	f	\N	2039	5	19
Lyttelton of Aldershot	of Aldershot in the County of Hampshire	\N	\N	Succeeded as 3rd V Chandos 1980; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 a.m.	2375	6	8	\N	f	\N	2042	5	13
Erskine of Alloa Tower	of Alloa in Clackmannanshire	\N	\N	Succeeded as 14th E of Mar & 16th E of Kellie 1993; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2376	6	8	\N	f	\N	2043	5	6
Ponsonby of Roehampton	of Shulbrede in the County of West Sussex	\N	\N	Succeeded as 4th L Ponsonby of Shulbrede 1900; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 12 noon.	2377	6	8	\N	f	\N	2044	5	17
Jordan	of Bournville in the County of West Midlands	\N	\N	\N	2399	5	8	\N	f	\N	2045	5	11
Hodgson of Astley Abbotts	of Nash in the County of Shropshire	\N	\N	\N	2401	5	8	\N	f	\N	2046	5	9
Morgan	of Aberdyfi in the County of Gwynedd	\N	\N	\N	2402	5	8	\N	f	\N	2047	5	14
Scott of Foscote	of Foscote in the County of Buckinghamshire	\N	\N	vice L Phillips of Worth Matravers, appointed MR	2403	1	8	\N	f	\N	2048	5	20
Luce	of Adur in the County of West Sussex	\N	\N	\N	2404	5	8	\N	f	\N	2049	5	13
Ashcroft	of Chichester in the County of West Sussex	\N	\N	\N	2405	5	8	\N	f	\N	2050	5	2
Low	of Bispham in the County of Lancashire	2000-12-07	1	Cr 1st L Aldington 29 Jan 1962; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2355	6	8	\N	f	\N	2051	5	13
Erroll of Kilmun	of Kilmun in Argyll and Bute	2000-09-14	1	Cr 1st L Erroll of Hale 19 Dec 1964; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 12 noon	2356	6	8	\N	f	\N	2052	5	6
Ashton of Upholland	of St Albans in the County of Hertfordshire	\N	\N	\N	2345	5	8	\N	f	\N	2053	5	2
Gale	of Blaenrhondda in the County of Mid Glamorgan	\N	\N	\N	2348	5	8	\N	f	\N	2055	5	8
Cohen of Pimlico	of Pimlico in the City of Westminster	\N	\N	\N	2382	5	8	\N	f	\N	2092	5	4
Gibson of Market Rasen	of Market Rasen in the County of Lincolnshire	2018-04-20	1	\N	2387	5	8	\N	f	\N	2093	5	8
Greenfield	of Ot Moor in the County of Oxfordshire	\N	\N	\N	2411	5	8	\N	f	\N	2094	5	8
Greengross	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2366	5	8	\N	f	\N	2095	5	8
Scott of Needham Market	of Needham Market in the County of Suffolk	\N	\N	\N	2391	5	8	\N	f	\N	2096	5	20
Walmsley	of West Derby in the County of Merseyside	\N	\N	\N	2395	5	8	\N	f	\N	2097	5	24
Brennan	of Bibury in the County of Gloucestershire	\N	\N	\N	2381	5	8	\N	f	\N	2062	5	3
Billingham	of Banbury in the County of Oxfordshire	\N	\N	\N	2380	5	8	\N	f	\N	2090	5	3
Lipsey	of Tooting in the London Borough of Wandsworth	\N	\N	\N	2340	5	8	\N	f	\N	2063	5	13
Brittan of Spennithorne	of Spennithorne in the County of North Yorkshire	2015-01-21	1	\N	2365	5	8	\N	f	\N	2065	5	3
Birt	of Liverpool in the County of Merseyside	\N	\N	\N	2367	5	8	\N	f	\N	2066	5	3
Patel of Blackburn	of Langho in the County of Lancashire	2019-05-29	1	\N	2368	5	8	\N	f	\N	2067	5	17
Powell of Bayswater	of Canterbury in the County of Kent	\N	\N	\N	2369	5	8	\N	f	\N	2068	5	17
Joffe	of Liddington in the County of Wiltshire	2017-06-18	1	\N	2370	5	8	\N	f	\N	2069	5	11
Acton of Bridgnorth	of Aldenham in the County of Shropshire	2010-10-10	1	Succeeded as 4th L Acton 1989; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2371	6	8	\N	f	\N	2070	5	2
Mitchell	of Hampstead in the London Borough of Camden	\N	\N	\N	2389	5	8	\N	f	\N	2071	5	14
Parekh	of Kingston upon Hull in the East Riding of Yorkshire	\N	\N	\N	2390	5	8	\N	f	\N	2072	5	17
Evans of Temple Guiting	of Temple Guiting in the County of Gloucestershire	2016-07-06	1	\N	2392	5	8	\N	f	\N	2073	5	6
Shutt of Greetland	of Greetland and Stainland in the County of West Yorkshire	\N	\N	\N	2393	5	8	\N	f	\N	2074	5	20
Roper	of Thorney Island in the City of Westminster	2016-01-29	1	\N	2394	5	8	\N	f	\N	2075	5	19
Bernstein of Craigweil	of Craigweil in the County of West Sussex	2010-04-12	1	\N	2396	5	8	\N	f	\N	2076	5	3
Fyfe of Fairfield	of Sauchie in the County of Clackmannanshire	2011-02-01	1	\N	2397	5	8	\N	f	\N	2077	5	7
Coe	of Ranmore in the County of Surrey	\N	\N	\N	2398	5	8	\N	f	\N	2078	5	4
Oakeshott of Seagrove Bay	of Seagrove Bay in the County of Isle of Wight	\N	\N	\N	2379	5	8	\N	f	\N	2079	5	16
Layard	of Highgate in the London Borough of Haringey	\N	\N	\N	2383	5	8	\N	f	\N	2080	5	13
Greaves	of Pendle in the County of Lancashire	\N	\N	\N	2384	5	8	\N	f	\N	2081	5	8
Turnberg	of Cheadle in the County of Cheshire	\N	\N	\N	2385	5	8	\N	f	\N	2082	5	21
Hunt of Chesterton	of Chesterton in the County of Cambridgeshire	\N	\N	\N	2386	5	8	\N	f	\N	2083	5	9
Chan	of Oxton in the County of Merseyside	2006-01-21	1	\N	2407	5	8	\N	f	\N	2084	5	4
Best	of Godmanstone in the County of Dorset	\N	\N	\N	2408	5	8	\N	f	\N	2085	5	3
Bhatia	of Hampton in the London Borough of Richmond	\N	\N	\N	2409	5	8	\N	f	\N	2086	5	3
Rooker	of Perry Barr in the County of West Midlands	\N	\N	\N	2410	5	8	\N	f	\N	2087	5	19
Hannay of Chiswick	of Bedford Park in the London Borough of Ealing	\N	\N	\N	2412	5	8	\N	f	\N	2088	5	9
Barker	of Anagach in Highland	\N	\N	\N	2343	5	8	\N	f	\N	2089	5	3
Blood	of Blackwatertown in the County of Armagh	\N	\N	\N	2342	5	8	\N	f	\N	2091	5	3
Ouseley	of Peckham Rye in the London Borough of Southwark	\N	\N	\N	2418	5	8	\N	f	\N	2100	5	16
Howe of Idlicote	of Shipston-on-Stow in the County of Warwickshire	\N	\N	Lady Howe of Aberavon	2423	5	8	\N	f	\N	2134	5	9
Guthrie of Craigiebank	of Craigiebank in the City of Dundee	\N	\N	\N	2419	5	8	\N	f	\N	2101	5	8
Condon	of Langton Green in the County of Kent	\N	\N	\N	2420	5	8	\N	f	\N	2102	5	4
Browne of Madingley	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2422	5	8	\N	f	\N	2103	5	3
Sutherland of Houndwood	of Houndwood in the Scottish Borders	2018-01-29	1	\N	2424	5	8	\N	f	\N	2104	5	20
Adebowale	of Thornes in the County of West Yorkshire	\N	\N	\N	2425	5	8	\N	f	\N	2105	5	2
Grocott	of Telford in the County of Shropshire	\N	\N	\N	2426	5	8	\N	f	\N	2106	5	8
Clark of Windermere	of Windermere in the County of Cumbria	\N	\N	\N	2427	5	8	\N	f	\N	2107	5	4
Morris of Aberavon	of Aberavon in the County of West Glamorgan and of Ceredigion in the County of Dyfed	\N	\N	\N	2428	5	8	\N	f	\N	2108	5	14
Fowler	of Sutton Coldfield in the County of West Midlands	\N	\N	\N	2429	5	8	\N	f	\N	2109	5	7
Pendry	of Stalybridge in the County of Greater Manchester	\N	\N	\N	2430	5	8	\N	f	\N	2110	5	17
Campbell-Savours	of Allerdale in the County of Cumbria	\N	\N	\N	2431	5	8	\N	f	\N	2111	5	4
MacGregor of Pulham Market	of Pulham Market in the County of Norfolk	\N	\N	\N	2432	5	8	\N	f	\N	2112	5	14
Corbett of Castle Vale	of Erdington in the County of West Midlands	2012-02-19	1	\N	2433	5	8	\N	f	\N	2113	5	4
Jones	of Deeside in the County of Clwyd	\N	\N	\N	2434	5	8	\N	f	\N	2114	5	11
King of Bridgwater	of Bridgwater in the County of Somerset	\N	\N	\N	2435	5	8	\N	f	\N	2115	5	12
Ashdown of Norton-sub-Hamdon	of Norton-sub-Hamdon in the County of Somerset	2018-12-22	1	\N	2436	5	8	\N	f	\N	2116	5	2
Fearn	of Southport in the County of Merseyside	\N	\N	\N	2437	5	8	\N	f	\N	2117	5	7
Heseltine	of Thenford in the County of Northamptonshire	\N	\N	\N	2438	5	8	\N	f	\N	2118	5	9
Radice	of Chester-le-Street in the County of Durham	\N	\N	\N	2441	5	8	\N	f	\N	2119	5	19
Kilclooney	of Armagh in the County of Armagh	\N	\N	\N	2442	5	8	\N	f	\N	2120	5	12
May of Oxford	of Oxford in the County of Oxfordshire	\N	\N	\N	2443	5	8	\N	f	\N	2121	5	14
Maclennan of Rogart	of Rogart in Sutherland	2020-01-18	1	\N	2444	5	8	\N	f	\N	2122	5	14
Maginnis of Drumglass	of Carnteel in the County of Tyrone	\N	\N	\N	2445	5	8	\N	f	\N	2123	5	14
Brooke of Sutton Mandeville	of Sutton Mandeville in the County of Wiltshire	\N	\N	\N	2446	5	8	\N	f	\N	2124	5	3
Black of Crossharbour	of Crossharbour in the London Borough of Tower Hamlets	\N	\N	\N	2448	5	8	\N	f	\N	2125	5	3
Walker of Gestingthorpe	of Gestingthorpe in the County of Essex	\N	\N	vice L Slynn of Hadley resigned	2449	1	8	\N	f	\N	2126	5	24
Carey of Clifton	of Clifton in the City and County of Bristol	\N	\N	\N	2450	5	8	\N	f	\N	2127	5	4
Wilson of Dinton	of Dinton in the County of Buckinghamshire	\N	\N	\N	2451	5	8	\N	f	\N	2128	5	24
Boyce	of Pimlico in the City of Westminster	\N	\N	\N	2452	5	8	\N	f	\N	2129	5	3
Cullen of Whitekirk	of Whitekirk in East Lothian	\N	\N	\N	2453	5	8	\N	f	\N	2130	5	4
Triesman	of Tottenham in the London Borough of Haringey	\N	\N	\N	2454	5	8	\N	f	\N	2131	5	21
Carswell	of Killeen in the County of Down	\N	\N	vice L Hutton resigned	2456	1	8	\N	f	\N	2132	5	4
Golding	of Newcastle-under-Lyme in the County of Staffordshire	\N	\N	\N	2439	5	8	\N	f	\N	2133	5	8
Michie of Gallanach	of Oban in Argyll and Bute	2008-05-06	1	dau of L Bannerman of Kildonan	2440	5	8	\N	f	\N	2135	5	14
Howarth of Breckland	of Parson Cross in the County of South Yorkshire	\N	\N	\N	2417	5	8	\N	f	\N	2169	5	9
McDonagh	of Mitcham and of Morden in the London Borough of Merton	\N	\N	\N	2493	5	8	\N	f	\N	2170	5	14
Morgan of Drefelin	of Drefelin in the County of Dyfed	\N	\N	\N	2475	5	8	\N	f	\N	2171	5	14
Murphy	of Aldgate in the City of London	\N	\N	\N	2482	5	8	\N	f	\N	2172	5	14
Neuberger	of Primrose Hill in the London Borough of Camden	\N	\N	\N	2478	5	8	\N	f	\N	2173	5	15
Prosser	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2474	5	8	\N	f	\N	2174	5	17
Royall of Blaisdon	of Blaisdon in the County of Gloucestershire	\N	\N	\N	2495	5	8	\N	f	\N	2175	5	19
Sheldon	of Ashton-under-Lyne in the County of Greater Manchester	2020-02-03	1	\N	2414	5	8	\N	f	\N	2136	5	20
D'Souza	of Wychwood in the County of Oxfordshire	\N	\N	\N	2502	5	8	\N	f	\N	2167	5	5
Moser	of Regents Park in the London Borough of Camden	2015-09-04	1	\N	2416	5	8	\N	f	\N	2137	5	14
Bhattacharyya	of Moseley in the County of West Midlands	2019-03-01	1	\N	2462	5	8	\N	f	\N	2138	5	3
Garden	of Hampstead in the London Borough of Camden	2007-08-09	1	\N	2463	5	8	\N	f	\N	2139	5	8
Howard of Rising	of Castle Rising in the County of Norfolk	\N	\N	\N	2464	5	8	\N	f	\N	2140	5	9
Hart of Chilton	of Chilton in the County of Suffolk	2017-08-03	1	\N	2465	5	8	\N	f	\N	2141	5	9
Leitch	of Oakley in Fife	\N	\N	\N	2466	5	8	\N	f	\N	2142	5	13
Gould of Brookwood	of Brookwood in the County of Surrey	2011-11-06	1	\N	2467	5	8	\N	f	\N	2143	5	8
Carter of Coles	of Westmill in the County of Hertfordshire	\N	\N	\N	2469	5	8	\N	f	\N	2144	5	4
Snape	of Wednesbury in the County of West Midlands	\N	\N	\N	2470	5	8	\N	f	\N	2145	5	20
Truscott	of St James's in the City of Westminster	\N	\N	\N	2472	5	8	\N	f	\N	2146	5	21
Rosser	of Ickenham in the London Borough of Hillingdon	\N	\N	\N	2477	5	8	\N	f	\N	2147	5	19
Giddens	of Southgate in the London Borough of Enfield	\N	\N	\N	2480	5	8	\N	f	\N	2149	5	8
Rana	of Malone in the County of Antrim	\N	\N	\N	2481	5	8	\N	f	\N	2150	5	19
Maxton	of Blackwaterfoot in Ayrshire and Arran	\N	\N	\N	2483	5	8	\N	f	\N	2151	5	14
Ballyedmond	of Mourne in the County of Down	2014-03-13	1	\N	2484	5	8	\N	f	\N	2152	5	3
McKenzie of Luton	of Luton in the County of Bedfordshire	\N	\N	\N	2485	5	8	\N	f	\N	2153	5	14
Dykes	of Harrow Weald in the London Borough of Harrow	\N	\N	\N	2486	5	8	\N	f	\N	2154	5	5
Broers	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2487	5	8	\N	f	\N	2155	5	3
Vallance of Tummel	of Tummel in Perth and Kinross	\N	\N	\N	2489	5	8	\N	f	\N	2156	5	23
Steinberg	of Belfast in the County of Antrim	2009-11-02	1	\N	2490	5	8	\N	f	\N	2157	5	20
Young of Norwood Green	of Norwood Green in the London Borough of Ealing	\N	\N	\N	2494	5	8	\N	f	\N	2158	5	26
Rowlands	of Merthyr Tydfil and of Rhymney in the County of Mid-Glamorgan	\N	\N	\N	2496	5	8	\N	f	\N	2159	5	19
Haworth	of Fisherfield in Ross and Cromarty	\N	\N	\N	2497	5	8	\N	f	\N	2160	5	9
Cameron of Dillington	of Dillington in the County of Somerset	\N	\N	\N	2498	5	8	\N	f	\N	2161	5	4
George	of St Tudy in the County of Cornwall	2009-04-18	1	\N	2499	5	8	\N	f	\N	2162	5	8
Kerr of Kinlochard	of Kinlochard in Perth and Kinross	\N	\N	\N	2501	5	8	\N	f	\N	2163	5	12
Alliance	of Manchester in the County of Greater Manchester	\N	\N	\N	2503	5	8	\N	f	\N	2164	5	2
Patten of Barnes	of Barnes in the London Borough of Richmond	\N	\N	\N	2504	5	8	\N	f	\N	2165	5	17
Henig	of Lancaster in the County of Lancashire	\N	\N	\N	2468	5	8	\N	f	\N	2168	5	9
Deech	of Cumnor in the County of Oxfordshire	\N	\N	\N	2541	5	8	\N	f	\N	2210	5	5
Fritchie	of Gloucester in the County of Gloucestershire	\N	\N	\N	2510	5	8	\N	f	\N	2211	5	7
Morris of Yardley	of Yardley in the County of West Midlands	\N	\N	\N	2513	5	8	\N	f	\N	2212	5	14
Quin	of Gateshead in the County of Tyne and Wear	\N	\N	\N	2550	5	8	\N	f	\N	2213	5	18
Taylor of Bolton	of Bolton in the County of Greater Manchester	\N	\N	\N	2512	5	8	\N	f	\N	2215	5	21
Tonge	of Kew in the London Borough of Richmond upon Thames	\N	\N	\N	2527	5	8	\N	f	\N	2216	5	21
Valentine	of Putney in the London Borough of Wandsworth	\N	\N	\N	2542	5	8	\N	f	\N	2217	5	23
Drayson	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2459	5	8	\N	f	\N	2177	5	5
Clark of Calton	of Calton in the City of Edinburgh	\N	\N	\N	2524	5	8	\N	f	\N	2208	5	4
Tunnicliffe	of Bracknell in the Royal County of Berkshire	\N	\N	\N	2461	5	8	\N	f	\N	2178	5	21
Ramsbotham	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2509	5	8	\N	f	\N	2179	5	19
Kirkwood of Kirkhope	of Kirkhope in Scottish Borders	\N	\N	\N	2511	5	8	\N	f	\N	2180	5	12
O'Neill of Clackmannan	of Clackmannan in Clackmannanshire	\N	\N	\N	2514	5	8	\N	f	\N	2181	5	16
Howarth of Newport	of Newport in the County of Gwent	\N	\N	\N	2515	5	8	\N	f	\N	2182	5	9
Tyler	of Linkinhorne in the County of Cornwall	\N	\N	\N	2516	5	8	\N	f	\N	2183	5	21
Chidgey	of Hamble-le-Rice in the County of Hampshire	\N	\N	\N	2520	5	8	\N	f	\N	2185	5	4
Jones of Cheltenham	of Cheltenham in the County of Gloucestershire	\N	\N	\N	2521	5	8	\N	f	\N	2186	5	11
Bilston	of Bilston in the County of West Midlands	2014-02-25	1	\N	2522	5	8	\N	f	\N	2187	5	3
Moonie	of Bennochy in Fife	\N	\N	\N	2525	5	8	\N	f	\N	2188	5	14
Smith of Finsbury	of Finsbury in the London Borough of Islington	\N	\N	\N	2526	5	8	\N	f	\N	2189	5	20
Stratford	of Stratford in the London Borough of Newham	2006-01-08	1	\N	2528	5	8	\N	f	\N	2190	5	20
Mawhinney	of Peterborough in the County of Cambridgeshire	2019-11-09	1	\N	2530	5	8	\N	f	\N	2191	5	14
Cunningham of Felling	of Felling in the County of Tyne and Wear	\N	\N	\N	2531	5	8	\N	f	\N	2192	5	4
Lyell of Markyate	of Markyate in the County of Hertfordshire	2010-08-30	1	\N	2532	5	8	\N	f	\N	2193	5	13
Anderson of Swansea	of Swansea in the County of West Glamorgan	\N	\N	\N	2533	5	8	\N	f	\N	2194	5	2
Goodlad	of Lincoln in the County of Lincolnshire	\N	\N	\N	2537	5	8	\N	f	\N	2195	5	8
Rees of Ludlow	of Ludlow in the County of Shropshire	\N	\N	\N	2538	5	8	\N	f	\N	2196	5	19
Turner of Ecchinswell	of Ecchinswell in the County of Hampshire	\N	\N	\N	2539	5	8	\N	f	\N	2197	5	21
Mance	of Frognal in the London Borough of Camden	\N	\N	\N	2540	1	8	\N	f	\N	2198	5	14
Turnbull	of Enfield in the London Borough of Enfield	\N	\N	\N	2543	5	8	\N	f	\N	2199	5	21
Hastings of Scarisbrick	of Scarisbrick in the County of Lancashire	\N	\N	\N	2544	5	8	\N	f	\N	2200	5	9
Davidson of Glen Clova	of Glen Clova in Angus	\N	\N	\N	2545	5	8	\N	f	\N	2201	5	5
Crisp	of Eaglescliffe in the County of Durham	\N	\N	\N	2546	5	8	\N	f	\N	2202	5	4
Lee of Trafford	of Bowdon in the County of Cheshire	\N	\N	\N	2547	5	8	\N	f	\N	2203	5	13
Cotter	of Congresbury in the County of Somerset	\N	\N	\N	2549	5	8	\N	f	\N	2204	5	4
Hope of Thornes	of Thornes in the County of West Yorkshire	\N	\N	\N	2506	5	8	\N	f	\N	2205	5	9
Bottomley of Nettlestone	of St Helens in the County of Isle of Wight	\N	\N	\N	2529	5	8	\N	f	\N	2207	5	3
Corston	of St George in the County and City of Bristol	\N	\N	\N	2536	5	8	\N	f	\N	2209	5	4
Lane-Fox of Soho	of Soho in the City of Westminster	\N	\N	\N	2749	5	8	\N	f	\N	2253	5	13
Lawrence of Clarendon	of Clarendon in the Commonwealth Realm of Jamaica	\N	\N	\N	2758	5	8	\N	f	\N	2254	5	13
Manzoor	of Knightsbridge in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2757	5	8	\N	f	\N	2255	5	14
Meacher	of Spitalfields in the London Borough of Tower Hamlets	\N	\N	\N	2576	5	8	\N	f	\N	2256	5	14
Paisley of St George's	of St George's in the County of Antrim	\N	\N	\N	2571	5	8	\N	f	\N	2257	5	17
Verma	of Leicester in the County of Leicestershire	\N	\N	\N	2556	5	8	\N	f	\N	2258	5	23
Adonis	of Camden Town in the London Borough of Camden	\N	\N	\N	2508	5	8	\N	f	\N	2218	5	2
Sheikh	of Cornhill in the City of London	\N	\N	\N	2560	5	8	\N	f	\N	2219	5	20
Morrow	of Clogher Valley in the County of Tyrone	\N	\N	\N	2561	5	8	\N	f	\N	2220	5	14
Morris of Handsworth	of Handsworth in the County of West Midlands	\N	\N	\N	2562	5	8	\N	f	\N	2221	5	14
Marland	of Odstock in the County of Wiltshire	\N	\N	\N	2563	5	8	\N	f	\N	2222	5	14
Patel of Bradford	of Bradford in the County of West Yorkshire	\N	\N	\N	2564	5	8	\N	f	\N	2223	5	17
Bruce-Lockhart	of The Weald in the County of Kent	2008-08-14	1	\N	2565	5	8	\N	f	\N	2224	5	3
James of Blackheath	of Wildbrooks in the County of West Sussex	\N	\N	\N	2566	5	8	\N	f	\N	2225	5	11
Bradley	of Withington in the County of Greater Manchester	\N	\N	\N	2567	5	8	\N	f	\N	2226	5	3
Browne of Belmont	of Belmont in the County of Antrim	\N	\N	\N	2568	5	8	\N	f	\N	2227	5	3
Low of Dalston	of Dalston in the London Borough of Hackney	\N	\N	\N	2570	5	8	\N	f	\N	2228	5	13
Boyd of Duncansby	of Duncansby in Caithness	\N	\N	\N	2572	5	8	\N	f	\N	2229	5	3
Rowe-Beddoe	of Kilgetty in the County of Dyfed	\N	\N	\N	2573	5	8	\N	f	\N	2230	5	19
O'Donnell	of Clapham in the London Borough of Wandsworth	\N	\N	\N	2743	5	8	\N	f	\N	2231	5	16
Trees	of The Ross in Perth and Kinross	\N	\N	\N	2745	5	8	\N	f	\N	2232	5	21
Deighton	of Carshalton in the County of Surrey	\N	\N	\N	2746	5	8	\N	f	\N	2233	5	5
Berkeley of Knighton	of Knighton in the County of Powys	\N	\N	\N	2750	5	8	\N	f	\N	2235	5	3
Livingston of Parkhead	of Parkhead in the City of Glasgow	\N	\N	\N	2751	5	8	\N	f	\N	2236	5	13
Horam	of Grimsargh in the County of Lancashire	\N	\N	\N	2753	5	8	\N	f	\N	2237	5	9
King of Lothbury	of Lothbury in the City of London	\N	\N	\N	2752	5	8	\N	f	\N	2238	5	12
Wrigglesworth	of Norton on Tees in the County of Durham	\N	\N	\N	2756	5	8	\N	f	\N	2240	5	24
Bourne of Aberystwyth	of Aberystwyth in the County of Ceredigion and of Wethersfield in the County of Essex	\N	\N	\N	2759	5	8	\N	f	\N	2241	5	3
Dear	of Willersey in the County of Gloucestershire	\N	\N	\N	2574	5	8	\N	f	\N	2242	5	5
Bilimoria	of Chelsea in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2575	5	8	\N	f	\N	2243	5	3
Harries of Pentregarth	of Ceinewydd in the County of Dyfed	\N	\N	\N	2577	5	8	\N	f	\N	2244	5	9
Jay of Ewelme	of Ewelme in the County of Oxfordshire	\N	\N	\N	2578	5	8	\N	f	\N	2245	5	11
Walker of Aldringham	of Aldringham in the County of Suffolk	\N	\N	\N	2579	5	8	\N	f	\N	2246	5	24
Burnett	of Whitchurch in the County of Devon	\N	\N	\N	2552	5	8	\N	f	\N	2247	5	3
Teverson	of Tregony in the County of Cornwall	\N	\N	\N	2554	5	8	\N	f	\N	2248	5	21
Trimble	of Lisnagarvey in the County of Antrim	\N	\N	\N	2555	5	8	\N	f	\N	2249	5	21
Ford	of Cunninghame in North Ayrshire	\N	\N	\N	2558	5	8	\N	f	\N	2250	5	7
Kidron	of Angel in the London Borough of Islington	\N	\N	\N	2744	5	8	\N	f	\N	2252	5	12
Grey-Thompson	of Eaglescliffe in the County of Durham	\N	\N	\N	2621	5	8	\N	f	\N	2294	5	8
Manningham-Buller	of Northampton in the County of Northamptonshire	\N	\N	\N	2601	5	8	\N	f	\N	2296	5	14
O'Loan	of Kirkinriola in the County of Antrim	\N	\N	\N	2618	5	8	\N	f	\N	2297	5	16
Sherlock	of Durham in the County of Durham	\N	\N	\N	2626	5	8	\N	f	\N	2298	5	20
Vadera	of Holland Park in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2590	5	8	\N	f	\N	2299	5	23
Warsi	of Dewsbury in the County of West Yorkshire	\N	\N	\N	2593	5	8	\N	f	\N	2300	5	24
Krebs	of Wytham in the County of Oxfordshire	\N	\N	\N	2584	5	8	\N	f	\N	2259	5	12
Coussins	of Whitehall Park in the London Borough of Islington	\N	\N	\N	2581	5	8	\N	f	\N	2292	5	4
Mawson	of Bromley-by-Bow in the London Borough of Tower Hamlets	\N	\N	\N	2585	5	8	\N	f	\N	2260	5	14
Malloch-Brown	of St Leonard's Forest in the County of West Sussex	\N	\N	\N	2587	5	8	\N	f	\N	2261	5	14
West of Spithead	of Seaview in the County of Isle of Wight	\N	\N	\N	2588	5	8	\N	f	\N	2262	5	24
Jones of Birmingham	of Alvechurch and of Bromsgrove in the County of Worcestershire	\N	\N	\N	2589	5	8	\N	f	\N	2263	5	11
Darzi of Denham	of Gerrards Cross in the County of Buckinghamshire	\N	\N	\N	2591	5	8	\N	f	\N	2264	5	5
Janvrin	of Chalford Hill in the County of Gloucestershire	\N	\N	\N	2592	5	8	\N	f	\N	2265	5	11
Wallace of Tankerness	of Tankerness in Orkney	\N	\N	\N	2596	5	8	\N	f	\N	2266	5	24
Mogg	of Queen's Park in the County of East Sussex	\N	\N	\N	2599	5	8	\N	f	\N	2267	5	14
Smith of Kelvin	of Kelvin in the City of Glasgow	\N	\N	\N	2600	5	8	\N	f	\N	2268	5	20
Bates	of Langbaurgh in the County of North Yorkshire	\N	\N	\N	2602	5	8	\N	f	\N	2269	5	3
Judge	of Draycote in the County of Warwickshire	\N	\N	\N	2603	5	8	\N	f	\N	2270	5	11
Myners	of Truro in the County of Cornwall	\N	\N	\N	2606	5	8	\N	f	\N	2272	5	14
Pannick	of Radlett in the County of Hertfordshire	\N	\N	\N	2607	5	8	\N	f	\N	2273	5	17
Davies of Abersoch	of Abersoch in the County of Gwynedd	\N	\N	\N	2609	5	8	\N	f	\N	2274	5	5
Collins of Mapesbury	of Hampstead Town in the London Borough of Camden	\N	\N	\N	2610	1	8	\N	f	\N	2275	5	4
Clarke of Stone-cum-Ebony	of Stone-cum-Ebony in the County of Kent	\N	\N	MR	2611	5	8	\N	f	\N	2276	5	4
Freud	of Eastry in the County of Kent	\N	\N	\N	2612	5	8	\N	f	\N	2277	5	7
Kerr of Tonaghmore	of Tonaghmore in the County of Down	\N	\N	LCJ of Northern Ireland	2613	1	8	\N	f	\N	2278	5	12
Sugar	of Clapton in the London Borough of Hackney	\N	\N	\N	2615	5	8	\N	f	\N	2279	5	20
Sacks	of Aldgate in the City of London	\N	\N	\N	2617	5	8	\N	f	\N	2280	5	20
Martin of Springburn	of Port Dundas in the City of Glasgow	2018-04-29	1	\N	2616	5	8	\N	f	\N	2281	5	14
Hall of Birkenhead	of Birkenhead in the County of Cheshire	\N	\N	\N	2619	5	8	\N	f	\N	2282	5	9
Kakkar	of Loxbeare in the County of Devon	\N	\N	\N	2620	5	8	\N	f	\N	2283	5	12
Bichard	of Nailsworth in the County of Gloucestershire	\N	\N	\N	2622	5	8	\N	f	\N	2284	5	3
Hill of Oareford	of Oareford in the County of Somerset	\N	\N	\N	2623	5	8	\N	f	\N	2285	5	9
Wei	of Shoreditch in the London Borough of Hackney	\N	\N	\N	2624	5	8	\N	f	\N	2286	5	24
Sassoon	of Ashley Park in the County of Surrey	\N	\N	\N	2625	5	8	\N	f	\N	2287	5	20
Bew	of Donegore in the County of Antrim	\N	\N	\N	2582	5	8	\N	f	\N	2288	5	3
Hameed	of Hampstead in the London Borough of Camden	\N	\N	\N	2583	5	8	\N	f	\N	2289	5	9
Bannside	of North Antrim in the County of Antrim	2014-09-12	1	\N	2631	5	8	\N	f	\N	2290	5	3
Garden of Frognal	of Hampstead in the London Borough of Camden	\N	\N	\N	2595	5	8	\N	f	\N	2293	5	8
Donaghy	of Peckham in the London Borough of Southwark	\N	\N	\N	2646	5	8	\N	f	\N	2333	5	5
Drake	of Shene in the County of Surrey	\N	\N	\N	2633	5	8	\N	f	\N	2334	5	5
Hayter of Kentish Town	of Kentish Town in the London Borough of Camden	\N	\N	\N	2637	5	8	\N	f	\N	2335	5	9
Hussein-Ece	of Highbury in the London Borough of Islington	\N	\N	\N	2643	5	8	\N	f	\N	2336	5	9
Liddell of Coatdyke	of Airdrie in Lanarkshire	\N	\N	\N	2654	5	8	\N	f	\N	2337	5	13
Smith of Basildon	of Basildon in the County of Essex	\N	\N	\N	2652	5	8	\N	f	\N	2338	5	20
Stedman-Scott	of Rolvenden in the County of Kent	\N	\N	\N	2661	5	8	\N	f	\N	2339	5	20
Wheeler	of Blackfriars in the City of London	\N	\N	\N	2634	5	8	\N	f	\N	2340	5	24
Wolf of Dulwich	of Dulwich in the London Borough of Southwark	\N	\N	\N	2807	5	8	\N	f	\N	2341	5	24
Liddle	of Carlisle in the County of Cumbria	\N	\N	\N	2632	5	8	\N	f	\N	2301	5	13
Benjamin	of Beckenham in the County of Kent	\N	\N	\N	2645	5	8	\N	f	\N	2331	5	3
Deben	of Winston in the County of Suffolk	\N	\N	\N	2635	5	8	\N	f	\N	2302	5	5
McAvoy	of Rutherglen in Lanarkshire	\N	\N	\N	2638	5	8	\N	f	\N	2303	5	14
Gardiner of Kimble	of Kimble in the County of Buckinghamshire	\N	\N	\N	2640	5	8	\N	f	\N	2305	5	8
German	of Llanfrechfa in the County Borough of Torfaen	\N	\N	\N	2642	5	8	\N	f	\N	2306	5	8
Hutton of Furness	of Aldingham in the County of Cumbria	\N	\N	\N	2647	5	8	\N	f	\N	2307	5	9
McConnell of Glenscorrodale	of the Isle of Arran in Ayrshire and Arran	\N	\N	\N	2649	5	8	\N	f	\N	2309	5	14
Touhig	of Islwyn and Glansychan in the County of Gwent	\N	\N	\N	2650	5	8	\N	f	\N	2310	5	21
Davies of Stamford	of Stamford in the County of Lincolnshire	\N	\N	\N	2651	5	8	\N	f	\N	2311	5	5
Prescott	of Kingston upon Hull in the County of East Yorkshire	\N	\N	\N	2653	5	8	\N	f	\N	2312	5	17
Boswell of Aynho	of Aynho in the County of Northamptonshire	\N	\N	\N	2656	5	8	\N	f	\N	2314	5	3
Wigley	of Caernarfon in the County of Gwynedd	\N	\N	\N	2716	5	8	\N	f	\N	2315	5	24
Black of Brentwood	of Brentwood in the County of Essex	\N	\N	\N	2657	5	8	\N	f	\N	2316	5	3
Popat	of Harrow in the London Borough of Harrow	\N	\N	\N	2660	5	8	\N	f	\N	2317	5	17
Green of Deddington	of Deddington in the County of Oxfordshire	\N	\N	\N	2806	5	8	\N	f	\N	2318	5	8
Evans of Weardale	of Toys Hill in Our County of Kent	\N	\N	\N	2808	5	8	\N	f	\N	2319	5	6
Lisvane	of Blakemere in the County of Herefordshire	\N	\N	\N	2809	5	8	\N	f	\N	2320	5	13
Hay of Ballyore	of Ballyore in the City of Londonderry	\N	\N	\N	2810	5	8	\N	f	\N	2321	5	9
Kerslake	of Endcliffe in the City of Sheffield	\N	\N	\N	2811	5	8	\N	f	\N	2322	5	12
Dunlop	of Helensburgh in the County of Dunbarton	\N	\N	\N	2813	5	8	\N	f	\N	2323	5	5
O'Neill of Gatley	of Gatley in the County of Greater Manchester	\N	\N	\N	2815	5	8	\N	f	\N	2324	5	16
Bridges of Headley	of Headley Heath in the County of Surrey	\N	\N	\N	2816	5	8	\N	f	\N	2325	5	3
Wolfson of Aspley Guise	of Aspley Guise in the County of Bedfordshire	\N	\N	\N	2628	5	8	\N	f	\N	2326	5	24
Willis of Knaresborough	of Harrogate in the County of North Yorkshire	\N	\N	\N	2629	5	8	\N	f	\N	2327	5	24
Young of Cookham	of Cookham in the Royal County of Berkshire	\N	\N	\N	2821	5	8	\N	f	\N	2328	5	26
Smith of Hindhead	of Hindhead in the County of Surrey	\N	\N	\N	2822	5	8	\N	f	\N	2329	5	20
Armstrong of Hill Top	of Crook in the County of Durham	\N	\N	\N	2630	5	8	\N	f	\N	2330	5	2
Browning	of Whimple in the County of Devon	\N	\N	\N	2658	5	8	\N	f	\N	2332	5	3
Jolly	of Congdon's Shop in the County of Cornwall	\N	\N	\N	2697	5	8	\N	f	\N	2376	5	11
Kramer	of Richmond Park in the London Borough of Richmond upon Thames	\N	\N	\N	2693	5	8	\N	f	\N	2377	5	12
Newlove	of Warrington in the County of Cheshire	\N	\N	\N	2666	5	8	\N	f	\N	2378	5	15
Nye	of Lambeth in the London Borough of Lambeth	\N	\N	\N	2671	5	8	\N	f	\N	2379	5	15
Parminter	of Godalming in the County of Surrey	\N	\N	\N	2667	5	8	\N	f	\N	2380	5	17
Shackleton of Belgravia	of Belgravia in the City of Westminster	\N	\N	\N	2691	5	8	\N	f	\N	2381	5	20
Wheatcroft	of Blackheath in the London Borough of Greenwich	\N	\N	\N	2694	5	8	\N	f	\N	2382	5	24
Gilbert of Panteg	of Panteg in the County of Monmouthshire	\N	\N	\N	2823	5	8	\N	f	\N	2342	5	8
Stevenson of Balmacara	of Little Missenden in the County of Buckinghamshire	\N	\N	\N	2663	5	8	\N	f	\N	2343	5	20
Healy of Primrose Hill	of Primrose Hill in the London Borough of Camden	\N	\N	\N	2672	5	8	\N	f	\N	2373	5	9
Howard of Lympne	of Lympne in the County of Kent	\N	\N	\N	2664	5	8	\N	f	\N	2344	5	9
Shipley	of Gosforth in the County of Tyne and Wear	\N	\N	\N	2665	5	8	\N	f	\N	2345	5	20
Taylor of Goss Moor	of Truro in the County of Cornwall	\N	\N	\N	2669	5	8	\N	f	\N	2346	5	21
Reid of Cardowan	of Stepps in Lanarkshire	\N	\N	\N	2670	5	8	\N	f	\N	2347	5	19
Blair of Boughton	of Boughton in the County of Cheshire	\N	\N	\N	2673	5	8	\N	f	\N	2348	5	3
Browne of Ladyton	of Ladyton in Ayrshire and Arran	\N	\N	\N	2678	5	8	\N	f	\N	2351	5	3
Williams of Baglan	of Neath Port Talbot in Glamorgan	2017-04-23	1	\N	2679	5	8	\N	f	\N	2352	5	24
Monks	of Blackley in the County of Greater Manchester	\N	\N	\N	2680	5	8	\N	f	\N	2353	5	14
Hennessy of Nympsfield	of Nympsfield in the County of Gloucestershire	\N	\N	\N	2681	5	8	\N	f	\N	2354	5	9
Green of Hurstpierpoint	of Hurstpierpoint in the County of West Sussex	\N	\N	\N	2683	5	8	\N	f	\N	2355	5	8
Kerr of Monteviot	of Monteviot in Roxburghshire	\N	\N	\N	2684	6	8	\N	f	\N	2356	5	12
Lingfield	of Lingfield in the County of Surrey	\N	\N	\N	2685	5	8	\N	f	\N	2357	5	13
Feldman of Elstree	of Elstree in the County of Hertfordshire	\N	\N	\N	2686	5	8	\N	f	\N	2358	5	7
Dobbs	of Wylye in the County of Wiltshire	\N	\N	\N	2687	5	8	\N	f	\N	2359	5	5
Cormack	of Enville in the County of Staffordshire	\N	\N	\N	2688	5	8	\N	f	\N	2360	5	4
Sharkey	of Niton Undercliff in the County of the Isle of Wight	\N	\N	\N	2689	5	8	\N	f	\N	2361	5	20
True	of East Sheen in the County of Surrey	\N	\N	\N	2695	5	8	\N	f	\N	2362	5	21
Lexden	of Lexden in the County of Essex and of Strangford in the County of Down	\N	\N	\N	2696	5	8	\N	f	\N	2363	5	13
Risby	of Haverhill in the County of Suffolk	\N	\N	\N	2698	5	8	\N	f	\N	2364	5	19
Strasburger	of Langridge in Our County of Somerset	\N	\N	\N	2700	5	8	\N	f	\N	2365	5	20
Keen of Elie	of Elie in Fife	\N	\N	\N	2818	5	8	\N	f	\N	2366	5	12
Blunkett	of Brightside and Hillsborough in the City of Sheffield	\N	\N	\N	2819	5	8	\N	f	\N	2367	5	3
Hayward	of Cumnor in the County of Oxfordshire	\N	\N	\N	2820	5	8	\N	f	\N	2368	5	9
Flight	of Worcester in the County of Worcestershire	\N	\N	\N	2706	5	8	\N	f	\N	2369	5	7
Framlingham	of Eye in the County of Suffolk	\N	\N	\N	2708	5	8	\N	f	\N	2370	5	7
Wood of Anfield	of Tonbridge in the County of Kent	\N	\N	\N	2709	5	8	\N	f	\N	2371	5	24
Eaton	of Cottingley in the County of West Yorkshire	\N	\N	\N	2676	5	8	\N	f	\N	2372	5	6
Hughes of Stretford	of Ellesmere Port in the County of Cheshire	\N	\N	\N	2668	5	8	\N	f	\N	2375	5	9
Finn	of Swansea in the County of West Glamorgan	\N	\N	\N	2845	5	8	\N	f	\N	2413	5	7
Jenkin of Kennington	of Hatfield Peverel in the County of Essex	\N	\N	\N	2725	5	8	\N	f	\N	2414	5	11
King of Bow	of Bow in the London Borough of Tower Hamlets	\N	\N	\N	2726	5	8	\N	f	\N	2415	5	12
Morgan of Ely	of Ely in the City of Cardiff	\N	\N	\N	2722	5	8	\N	f	\N	2417	5	14
Pidding	of Amersham in the County of Buckinghamshire	\N	\N	\N	2836	5	8	\N	f	\N	2418	5	17
Randerson	of Roath Park in the City of Cardiff	\N	\N	\N	2727	5	8	\N	f	\N	2419	5	19
Redfern	of the Isle of Axholme in the County of Lincolnshire	\N	\N	\N	2834	5	8	\N	f	\N	2420	5	19
Scott of Bybrook	of Upper Wraxall in the County of Wiltshire	\N	\N	\N	2837	5	8	\N	f	\N	2421	5	20
Tyler of Enfield	of Enfield in the London Borough of Enfield	\N	\N	\N	2729	5	8	\N	f	\N	2422	5	21
Worthington	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2732	5	8	\N	f	\N	2423	5	24
Empey	of Shandon in the City and County Borough of Belfast	\N	\N	\N	2710	5	8	\N	f	\N	2383	5	6
Berridge	of The Vale of Catmose in the County of Rutland	\N	\N	\N	2713	5	8	\N	f	\N	2411	5	3
Fink	of Northwood in the County of Middlesex	\N	\N	\N	2714	5	8	\N	f	\N	2385	5	7
Dannatt	of Keswick in the County of Norfolk	\N	\N	\N	2715	5	8	\N	f	\N	2386	5	5
Hussain	of Luton in the County of Bedfordshire	\N	\N	\N	2718	5	8	\N	f	\N	2388	5	9
Kestenbaum	of Foxcote in the County of Somerset	\N	\N	\N	2721	5	8	\N	f	\N	2389	5	12
Magan of Castletown	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2723	5	8	\N	f	\N	2390	5	14
Grade of Yarmouth	of Yarmouth in the County of Isle of Wight	\N	\N	\N	2724	5	8	\N	f	\N	2391	5	8
Noon	of St John's Wood in the London Borough of Camden	2015-10-27	1	\N	2728	5	8	\N	f	\N	2392	5	15
Stirrup	of Marylebone in the City of Westminster	\N	\N	\N	2730	5	8	\N	f	\N	2393	5	20
Glendonbrook	of Bowdon in the County of Cheshire	\N	\N	\N	2733	5	8	\N	f	\N	2394	5	8
Gold	of Westcliff-on-Sea in the County of Essex	\N	\N	\N	2734	5	8	\N	f	\N	2395	5	8
Storey	of Childwall in the City of Liverpool	\N	\N	\N	2735	5	8	\N	f	\N	2396	5	20
Stephen	of Lower Deeside in the City of Aberdeen	\N	\N	\N	2736	5	8	\N	f	\N	2397	5	20
Glasman	of Stoke Newington and of Stamford Hill in the London Borough of Hackney	\N	\N	\N	2737	5	8	\N	f	\N	2398	5	8
Blencathra	of Penrith in the County of Cumbria	\N	\N	\N	2739	5	8	\N	f	\N	2399	5	3
Singh of Wimbledon	of Wimbledon in the London Borough of Merton	\N	\N	\N	2741	5	8	\N	f	\N	2400	5	20
Curry of Kirkharle	of Kirkharle in the County of Northumberland	\N	\N	\N	2742	5	8	\N	f	\N	2401	5	4
Lupton	of Lovington in the County of Hampshire	\N	\N	\N	2832	5	8	\N	f	\N	2402	5	13
Foster of Bath	of Bath in the County of Somerset	\N	\N	\N	2835	5	8	\N	f	\N	2403	5	7
Wasserman	of Pimlico in the City of Westminster	\N	\N	\N	2702	5	8	\N	f	\N	2404	5	24
Loomba	of Moor Park in the County of Hertfordshire	\N	\N	\N	2704	5	8	\N	f	\N	2405	5	13
Ahmad of Wimbledon	of Wimbledon in the London Borough of Merton	\N	\N	\N	2705	5	8	\N	f	\N	2406	5	2
Robathan	of Poultney in the County of Leicestershire	\N	\N	\N	2842	5	8	\N	f	\N	2407	5	19
Campbell of Pittenweem	of Pittenweem in the County of Fife	\N	\N	\N	2843	5	8	\N	f	\N	2408	5	4
Shinkwin	of Balham in the London Borough of Wandsworth	\N	\N	\N	2844	5	8	\N	f	\N	2409	5	20
Bakewell	of Stockport in the County of Greater Manchester	\N	\N	\N	2719	5	8	\N	f	\N	2410	5	3
Brinton	of Kenardington in the County of Kent	\N	\N	\N	2738	5	8	\N	f	\N	2412	5	3
Featherstone	of Highgate in the London Borough of Haringey	\N	\N	\N	2853	5	8	\N	f	\N	2451	5	7
Harding of Winscombe	of Nether Compton in the County of Dorset	\N	\N	\N	2791	5	8	\N	f	\N	2452	5	9
Helic	of Millbank in the City of Westminster	\N	\N	\N	2796	5	8	\N	f	\N	2453	5	9
McGregor-Smith	of Sunninghill in the Royal County of Berkshire	\N	\N	\N	2848	5	8	\N	f	\N	2454	5	14
Mobarik	of Mearns in the County of Renfrewshire	\N	\N	\N	2798	5	8	\N	f	\N	2455	5	14
Mone	of Mayfair in the City of Westminster	\N	\N	\N	2824	5	8	\N	f	\N	2456	5	14
Rebuck	of Bloomsbury in the London Borough of Camden	\N	\N	\N	2797	5	8	\N	f	\N	2457	5	19
Rock	of Stratton in the County of Dorset	\N	\N	\N	2846	5	8	\N	f	\N	2458	5	19
Sheehan	of Wimbledon in the London Borough of Merton and of Tooting in the London Borough of Wandsworth	\N	\N	\N	2829	5	8	\N	f	\N	2459	5	20
Shields	of Maida Vale in the City of Westminster	\N	\N	\N	2793	5	8	\N	f	\N	2460	5	20
Smith of Newnham	of Crosby in the County of Merseyside	\N	\N	\N	2788	5	8	\N	f	\N	2461	5	20
Stroud	of Fulham in the London Borough of Hammersmith and Fulham	\N	\N	\N	2827	5	8	\N	f	\N	2462	5	20
Thornhill	of Watford in the County of Hertfordshire	\N	\N	\N	2854	5	8	\N	f	\N	2463	5	21
Watkins of Tavistock	of Buckland Monachorum in the County of Devon	\N	\N	\N	2866	5	8	\N	f	\N	2464	5	24
Porter of Spalding	of Spalding in the County of Lincolnshire	\N	\N	\N	2847	5	8	\N	f	\N	2424	5	17
Brown of Cambridge	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2865	5	8	\N	f	\N	2449	5	3
Arbuthnot of Edrom	of Edrom in the County of Berwick	\N	\N	\N	2825	5	8	\N	f	\N	2425	5	2
Polak	of Hertsmere in the County of Hertfordshire	\N	\N	\N	2828	5	8	\N	f	\N	2426	5	17
Lansley	of Orwell in the County of Cambridgeshire	\N	\N	\N	2830	5	8	\N	f	\N	2427	5	13
Oates	of Denby Grange in the County of West Yorkshire	\N	\N	\N	2831	5	8	\N	f	\N	2428	5	16
Willetts	of Havant in the County of Hampshire	\N	\N	\N	2849	5	8	\N	f	\N	2429	5	24
Bruce of Bennachie	of Torphins in the County of Aberdeen	\N	\N	\N	2850	5	8	\N	f	\N	2430	5	3
Beith	of Berwick upon Tweed in the County of Northumberland	\N	\N	\N	2851	5	8	\N	f	\N	2431	5	3
Murphy of Torfaen	of Abersychan in the County of Gwent	\N	\N	\N	2852	5	8	\N	f	\N	2432	5	14
Livermore	of Rotherhithe in the London Borough of Southwark	\N	\N	\N	2855	5	8	\N	f	\N	2433	5	13
Hain	of Neath in the County of West Glamorgan	\N	\N	\N	2856	5	8	\N	f	\N	2434	5	9
Farmer	of Bishopsgate in the City of London	\N	\N	\N	2785	5	8	\N	f	\N	2435	5	7
Fox	of Leominster in the County of Herefordshire	\N	\N	\N	2786	5	8	\N	f	\N	2436	5	7
Suri	of Ealing in the London Borough of Ealing	\N	\N	\N	2787	5	8	\N	f	\N	2437	5	20
Rose of Monewden	of Monewden in the County of Suffolk	\N	\N	\N	2794	5	8	\N	f	\N	2438	5	19
Scriven	of Hunters Bar in the City of Sheffield	\N	\N	\N	2799	5	8	\N	f	\N	2439	5	20
Cashman	of Limehouse in the London Borough of Tower Hamlets	\N	\N	\N	2802	5	8	\N	f	\N	2441	5	4
Mair	of Cambridge in the County of Cambridgeshire	\N	\N	\N	2863	5	8	\N	f	\N	2444	5	14
Bird	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2864	5	8	\N	f	\N	2445	5	3
Darling of Roulanish	Great Bernera in the County of Ross and Cromarty	\N	\N	\N	2867	5	8	\N	f	\N	2446	5	5
Price	of Sturminster Newton in the County of Dorset	\N	\N	\N	2868	5	8	\N	f	\N	2447	5	17
Brady	of Knightsbridge in the City of Westminster	\N	\N	\N	2801	5	8	\N	f	\N	2448	5	3
Burt of Solihull	of Solihull in the County of West Midlands	\N	\N	\N	2839	5	8	\N	f	\N	2450	5	3
Goldie	of Bishopton in the County of Renfrewshire	\N	\N	\N	2782	5	8	\N	f	\N	2494	5	8
Hodgson of Abinger	of Abinger in the County of Surrey	\N	\N	\N	2769	5	8	\N	f	\N	2495	5	9
Humphreys	of Llanrwst in the County of Conwy	\N	\N	\N	2773	5	8	\N	f	\N	2496	5	9
Janke	of Clifton in the City and County of Bristol	\N	\N	\N	2805	5	8	\N	f	\N	2497	5	11
Jones of Moulsecoomb	of Moulsecoomb in the County of East Sussex	\N	\N	\N	2778	5	8	\N	f	\N	2498	5	11
Jowell	of Brixton in the London Borough of Lambeth	2018-05-12	1	\N	2862	5	8	\N	f	\N	2499	5	11
Neville-Rolfe	of Chilmark in the County of Wiltshire	\N	\N	\N	2761	5	8	\N	f	\N	2500	5	15
Pinnock	of Cleckheaton in the County of West Yorkshire	\N	\N	\N	2803	5	8	\N	f	\N	2501	5	17
Primarolo	of Windmill Hill in the City of Bristol	\N	\N	\N	2861	5	8	\N	f	\N	2502	5	17
Sugg	of Coldharbour in the London Borough of Lambeth	\N	\N	\N	2869	5	8	\N	f	\N	2503	5	20
Suttie	of Hawick in the Scottish Borders	\N	\N	\N	2772	5	8	\N	f	\N	2504	5	20
Wyld	of Gosforth in the City of Newcastle upon Tyne	\N	\N	\N	2884	5	8	\N	f	\N	2505	5	24
Gadhia	of Northwood in the County of Middlesex	\N	\N	\N	2872	5	8	\N	f	\N	2466	5	8
Couttie	of Downe in the County of Kent	\N	\N	\N	2877	5	8	\N	f	\N	2492	5	4
McInnes of Kilwinning	of Kilwinning in the County of Ayrshire	\N	\N	\N	2873	5	8	\N	f	\N	2467	5	14
Whitby	of Harborne in the City of Birmingham	\N	\N	\N	2762	5	8	\N	f	\N	2468	5	24
Carrington of Fulham	of Fulham in the London Borough of Hammersmith and Fulham	\N	\N	\N	2764	5	8	\N	f	\N	2470	5	4
Sherbourne of Didsbury	of Didsbury in the City of Manchester	\N	\N	\N	2765	5	8	\N	f	\N	2471	5	20
Paddick	of Brixton in the London Borough of Lambeth	\N	\N	\N	2766	5	8	\N	f	\N	2472	5	17
Purvis of Tweed	of East March in the Scottish Borders	\N	\N	\N	2767	5	8	\N	f	\N	2473	5	17
Holmes of Richmond	of Richmond in the London Borough of Richmond upon Thames	\N	\N	\N	2768	5	8	\N	f	\N	2474	5	9
Leigh of Hurley	of Hurley in the Royal County of Berkshire	\N	\N	\N	2770	5	8	\N	f	\N	2475	5	13
Verjee	of Portobello in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2771	5	8	\N	f	\N	2476	5	23
Haughey	of Hutchesontown in the City of Glasgow	\N	\N	\N	2774	5	8	\N	f	\N	2477	5	9
Balfe	of Dulwich in the London Borough of Southwark	\N	\N	\N	2775	5	8	\N	f	\N	2478	5	3
Palumbo of Southwark	of Southwark in the London Borough of Southwark	\N	\N	\N	2780	5	8	\N	f	\N	2479	5	17
Bamford	of Daylesford in the County of Gloucestershire and of Wootton in the County of Staffordshire	\N	\N	\N	2781	5	8	\N	f	\N	2480	5	3
Callanan	of Low Fell in the County of Tyne and Wear	\N	\N	\N	2804	5	8	\N	f	\N	2482	5	4
Caine	of Temple Newsam in the City of Leeds	\N	\N	\N	2875	5	8	\N	f	\N	2483	5	4
Stunell	of Hazel Grove in the County of Greater Manchester	\N	\N	\N	2860	5	8	\N	f	\N	2484	5	20
Duncan of Springbank	of Springbank in the County of Perth	\N	\N	\N	2885	5	8	\N	f	\N	2485	5	5
Agnew of Oulton	of Oulton in the County of Norfolk	\N	\N	\N	2887	5	8	\N	f	\N	2486	5	2
Burnett of Maldon	of Maldon in the County of Essex	\N	\N	\N	2888	5	8	\N	f	\N	2487	5	3
Richards of Herstmonceux	of Emsworth in the County of Hampshire	\N	\N	\N	2784	5	8	\N	f	\N	2488	5	19
Geidt	of Crobeg in the County of Ross and Cromarty	\N	\N	\N	2889	5	8	\N	f	\N	2489	5	8
Chartres	of Wilton in the County of Wiltshire	\N	\N	\N	2890	5	8	\N	f	\N	2490	5	4
Bloomfield of Hinton Waldrist	of Hinton Waldrist in the County of Oxfordshire	\N	\N	\N	2878	5	8	\N	f	\N	2491	5	3
Fairhead	of Yarm in the County of North Yorkshire	\N	\N	\N	2886	5	8	\N	f	\N	2493	5	7
Blower	of Starch Green in the London Borough of Hammersmith and Fulham	\N	\N	\N	2926	5	8	\N	f	\N	2532	5	3
Boycott	of Whitefield in the County of Somerset	\N	\N	\N	2905	5	8	\N	f	\N	2533	5	3
Bryan of Partick	of Partick in the City of Glasgow	\N	\N	\N	2899	5	8	\N	f	\N	2534	5	3
Bull	of Aldwych in the City of Westminster	\N	\N	\N	2907	5	8	\N	f	\N	2535	5	3
Cavendish of Little Venice	of Mells in the County of Somerset	\N	\N	\N	2880	5	8	\N	f	\N	2536	5	4
Hallett	of Rye in the County of East Sussex	\N	\N	\N	2922	5	8	\N	f	\N	2537	5	9
Hunt of Bethnal Green	of Bethnal Green in the London Borough of Tower Hamlets	\N	\N	\N	2927	5	8	\N	f	\N	2538	5	9
Meyer	of Nine Elms in the London Borough of Wandsworth	\N	\N	\N	2897	5	8	\N	f	\N	2539	5	14
Morgan of Cotes	of Cotes in the County of Leicestershire	\N	\N	\N	2932	5	8	\N	f	\N	2540	5	14
Penn	of Teddington in the London Borough of Richmond	\N	\N	\N	2920	5	8	\N	f	\N	2542	5	17
Ritchie of Downpatrick	of Downpatrick in the County of Down	\N	\N	\N	2928	5	8	\N	f	\N	2543	5	19
Sanderson of Welton	of Welton in the East Riding of Yorkshire	\N	\N	\N	2916	5	8	\N	f	\N	2544	5	20
Sater	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2898	5	8	\N	f	\N	2545	5	20
Wilcox of Newport	of Newport in the City of Newport	\N	\N	\N	2923	5	8	\N	f	\N	2546	5	24
Hogan-Howe	of Sheffield in the County of South Yorkshire	\N	\N	\N	2891	5	8	\N	f	\N	2506	5	9
Tyrie	of Chichester in the County of West Sussex	\N	\N	\N	2893	5	8	\N	f	\N	2507	5	21
Barran	of Bathwick in the City of Bath	\N	\N	\N	2901	5	8	\N	f	\N	2530	5	3
Pickles	of Brentwood and Ongar in the County of Essex	\N	\N	\N	2894	5	8	\N	f	\N	2508	5	17
Lilley	of Offa in the County of Hertfordshire	\N	\N	\N	2895	5	8	\N	f	\N	2509	5	13
McNicol of West Kilbride	of West Kilbride in the County of Ayrshire	\N	\N	\N	2900	5	8	\N	f	\N	2510	5	14
Haselhurst	of Saffron Walden in the County of Essex	\N	\N	\N	2902	5	8	\N	f	\N	2511	5	9
Heywood of Whitehall	of Glossop in the County of Derbyshire	2018-11-04	1	never introduced	2909	5	8	\N	f	\N	2512	5	9
Barwell	of Croydon in the London Borough of Croydon	\N	\N	Theresa May's personal list	2914	5	8	\N	f	\N	2513	5	3
Parkinson of Whitley Bay	of Beyton in the County of Suffolk	\N	\N	\N	2915	5	8	\N	f	\N	2514	5	17
Choudrey	of Hampstead in the London Borough of Barnet	\N	\N	\N	2917	5	8	\N	f	\N	2515	5	4
Davies of Gower	of Gower in the County of Swansea	\N	\N	\N	2919	5	8	\N	f	\N	2517	5	5
Ranger	of Mayfair in the City of Westminster	\N	\N	\N	2921	5	8	\N	f	\N	2518	5	19
Hendy	of Hayes and Harlington in the London Borough of Hillingdon	\N	\N	\N	2925	5	8	\N	f	\N	2519	5	9
Ricketts	of Shortlands in the County of Kent	\N	\N	\N	2882	5	8	\N	f	\N	2520	5	19
Reed of Allermuir	of Sundridge Park in the London Borough of Bromley	\N	\N	\N	2934	5	8	\N	f	\N	2522	5	19
Garnier	of Harborough in the County of of Leicestershire	\N	\N	\N	2903	5	8	\N	f	\N	2523	5	8
Randall of Uxbridge	of Uxbridge in the London Borough of Hillingdon	\N	\N	\N	2904	5	8	\N	f	\N	2524	5	19
Anderson of Ipswich	of Ipswich in the County of Suffolk	\N	\N	\N	2906	5	8	\N	f	\N	2525	5	2
Innes	\N	\N	\N	\N	231	4	6	\N	f	\N	2526	5	10
Taylor of Holbeach	of South Holland in the County of Lincolnshire	\N	\N	\N	2551	5	8	\N	f	\N	2527	5	21
Kintore	of Kintore in the County of Aberdeen	1966-05-25	4	\N	236	4	8	\N	f	\N	2528	5	12
Forfar	\N	\N	\N	\N	2912	8	6	\N	t	\N	2529	5	7
Blackwood of North Oxford	of North Oxford in the County of Oxfordshire	\N	\N	\N	2911	5	8	\N	f	\N	2531	5	3
Hardinge	of Lahore and of King's Newton in the County of Derby	\N	\N	\N	274	2	12	\N	f	\N	2547	5	9
Wensleydale	of Wensleydale in the North Riding of the County of York	1868-02-25	1	life peerage created under prerogative; cr L Wensleydale (hereditary) 23 July 1856	296	5	8	\N	f	\N	2548	5	24
Tredegar	of Tredegar in the County of Monmouth	1962-11-17	6	2nd & 3rd L both cr V Tredegar - title extant 1905-13 & 1926-49	316	2	8	\N	f	\N	2549	5	21
Bridport	of Cricket Saint Thomas in the County of Somerset and of Bronté in the Kingdom of Italy	\N	\N	\N	358	3	12	\N	f	\N	2550	5	3
Balinhard	of Farnell in the County of Forfar	\N	\N	title passed to D of Fife on death of 11th Earl (16 Feb 1992)	367	4	8	\N	f	\N	2551	5	3
Carlingford	of Carlingford in the County of Louth	1898-01-30	1	succ 1887 as 2nd L Clermont (I)	401	2	8	\N	f	\N	2552	5	4
Cottesloe	of Swanbourne and of Hardwick in the County of Buckingham	\N	\N	4th L died 21 April 1994	402	2	8	\N	f	\N	2553	5	4
Brabourne	of Brabourne in the County of Kent	\N	\N	\N	445	2	8	\N	f	\N	2554	5	3
Colville of Culross	in the County of Perth	\N	\N	cr V Colville of Culross 1902	487	4	8	\N	f	\N	2556	5	4
Burton	of Rangemore and of Burton-upon-Trent both in the County of Stafford	1909-02-01	1	further patent with SR 1897	496	2	8	\N	f	\N	2557	5	3
Mount Stephen	of Mount Stephen in the Province of British Columbia and Dominion of Canada and of Dufftown in the County of Banff	1921-11-29	1	\N	525	2	8	\N	f	\N	2558	5	14
Hood of Avalon	in the County of Somerset	1901-11-15	1	\N	530	2	8	\N	f	\N	2559	5	9
Leighton	of Stretton in the County of Salop	1896-01-25	1	\N	574	2	8	\N	f	\N	2560	5	13
Aldenham	of Aldenham in the County of Hertford	\N	\N	\N	575	2	8	\N	f	\N	2561	5	2
Malcolm of Poltalloch	in the County of Argyll	1902-03-06	1	\N	577	2	8	\N	f	\N	2562	5	14
Strathcona and Mount Royal	of Glencoe in the County of Argyll and of Mount Royal in the Province of Quebec and Dominion of Canada	1914-01-21	1	further patent (SR) 1900	588	2	8	\N	f	\N	2563	5	20
Nunburnholme	of the city of Kingston upon Hull	\N	\N	\N	660	2	8	\N	f	\N	2564	5	15
Shaw	of Dunfermline in the County of Fife	1937-06-28	1	vice L Robertson deceased; cr L Craigmyle (hered.) 1929	683	1	8	\N	f	\N	2565	5	20
Mountgarret	of Nidd in the West Riding of the County of York	\N	\N	\N	704	3	8	\N	f	\N	2566	5	14
Aberconway	of Bodnant in the County of Denbigh	\N	\N	\N	705	2	8	\N	f	\N	2567	5	2
Darroch of Kew	of St Mawes in the County of Cornwall	\N	\N	\N	2931	5	8	\N	f	\N	2568	5	5
Goldsmith of Richmond Park	of Richmond Park in the London Borough of Richmond upon Thames	\N	\N	\N	2933	5	8	\N	f	\N	2569	5	8
St Aldwyn	of Coln St Aldwyn in the County of Gloucester	\N	\N	2nd E died 29 Jan 1992	751	7	6	\N	f	\N	2570	5	20
Finlay	of Nairn in the County of Nairn	1945-06-30	2	cr V Finlay 1919	773	2	8	\N	f	\N	2571	5	7
Cave	of Richmond in the County of Surrey	1928-03-29	1	widow cr C Cave of Richmond 1928	819	2	12	\N	f	\N	2572	5	4
Riddell	of Walton Heath in the County of Surrey	1934-12-05	1	described by John Grigg as first divorced man to be created a peer (Sunday Telegraph, 2 Feb 1997; date wringly given as 1917)	851	2	8	\N	f	\N	2573	5	19
Manton	of Compton Verney in the County of Warwick	\N	\N	\N	879	2	8	\N	f	\N	2574	5	14
Bearsted	of Maidstone in the County of Kent	\N	\N	4th V died 9 June 1996	917	7	12	\N	f	\N	2575	5	3
Leverhulme	of the Western Isles in the Counties of Inverness and Ross and Cromarty	2000-07-04	3	\N	892	7	12	\N	f	\N	2576	5	13
Dunedin	of Stenton in the County of Perth	1942-08-21	1	\N	923	7	12	\N	f	\N	2577	5	5
Plumer	of Messines and of Bolton in the County of York	1944-02-24	2	\N	962	7	12	\N	f	\N	2578	5	17
Wales	\N	1910-05-06	1	merged in Crown 1910	618	7	11	\N	t	\N	2579	5	24
Blythswood	of Blythswood in the County of Renfrew	1940-09-14	7	SR to 5 brothers	542	2	8	\N	f	1	2581	5	3
Alvingham	of Woodfold in the County Palatine of Lancaster	\N	\N	\N	968	2	8	\N	f	\N	2583	5	2
Gladstone of Hawarden	of Hawarden in the County of Flint	1935-04-28	1	\N	1004	2	8	\N	f	\N	2584	5	8
Russell of Killowen	of Killowen in the County of Down	1946-12-20	1	vice L Carson resigned; 4th son of L Russell of Killowen cr 1894	974	1	8	\N	f	\N	2585	5	19
Buckmaster	of Cheddington in the County of Buckingham	\N	\N	\N	1012	7	12	\N	f	\N	2586	5	3
Blackford	of Compton Pauncefoot in the County of Somerset	1988-05-15	4	\N	1036	2	8	\N	f	\N	2587	5	3
Wardington	of Alnmouth in the County of Northumberland	2019-03-19	3	3rd L Wardington was a younger son of the 1st	1056	2	8	\N	f	\N	2588	5	24
Woolton	of Liverpool in the County Palatine of Lancaster	\N	\N	cr V Woolton 2 July 1953, E of Woolton 1956	1098	2	8	\N	f	\N	2590	5	24
Camrose	of Hackwood Park in the County of Southampton	\N	\N	2nd V died 1995; 3rd V (= L Hartwell (life peer)) disclaimed 1995 & died 3 April 2001	1110	7	12	\N	f	\N	2591	5	4
Westwood	of Gosforth in the County of Northumberland	\N	\N	2nd L died 8 Nov 1991	1142	2	8	\N	f	\N	2592	5	24
Balfour of Inchrye	of Shefford in the County of Berks	2013-04-14	2	\N	1158	2	8	\N	f	\N	2593	5	3
Portal of Hungerford	of Hungerford in the County of Berks	1971-04-22	1	\N	1193	7	12	\N	f	\N	2594	5	17
Lindsay of Birker	of Low Ground in the County of Cumberland	\N	\N	2nd L died 13 Feb 1994	1183	2	8	\N	f	\N	2595	5	13
Dukeston	of Warrington in the County Palatine of Lancaster	1948-05-14	1	\N	1225	2	8	\N	f	\N	2597	5	5
McEntee	of Walthamstow in the County of Essex	1953-02-11	1	\N	1270	2	8	\N	f	\N	2598	5	14
Morton of Henryton	of Henryton in the County of Ayr	1973-07-18	1	pursuant to Appellate Jurisdiction Act 1947	1226	1	8	\N	f	\N	2599	5	14
Radcliffe	of Werneth in the County Palatine of Lancaster	1977-04-01	1	vice L du Parcq deceased; cr V Radcliffe 11 Jly 1962	1247	1	8	\N	f	\N	2600	5	19
Bracken	of Christchurch in the County of Southampton	1958-08-08	1	apparently never introduced	1280	2	12	\N	f	\N	2601	5	3
Glassary	of Glassary in the County of Argyll	\N	\N	\N	1307	4	8	\N	f	\N	2602	5	8
Gridley	of Stockport in the County Palatine of Chester	\N	\N	2nd L died 15 June 1996	1313	2	8	\N	f	\N	2603	5	8
Parker of Waddington	of Waddington in the County of York	1918-07-12	1	vice L Macnaghten deceased	736	1	8	\N	f	\N	2604	5	17
Williams of Barnburgh	of Barnburgh in the West Riding of the County of York	1967-03-29	1	\N	1403	5	8	\N	f	\N	2605	5	24
Morris of Borth-y-Gest	of Borth-y-Gest in the County of Caernarvon	1979-06-09	1	vice L Somervell of Harrow resigned	1385	1	8	\N	f	\N	2606	5	14
Coutanche	of Saint Brelade in the Island of Jersey	1973-12-18	1	\N	1416	5	8	\N	f	\N	2607	5	4
Blakenham	of Little Blakenham in the County of Suffolk	\N	\N	\N	1447	2	12	\N	f	\N	2608	5	3
Oakshott	of Bebington in the County Palatine of Chester	1975-02-01	1	\N	1470	5	8	\N	f	\N	2609	5	16
Drumalbyn	of Whitesands in the Royal Burgh of Dumfries	1987-10-11	1	\N	1448	2	8	\N	f	\N	2610	5	5
Brockway	of Eton and of Slough in the County of Buckingham	1988-04-28	1	\N	1491	5	8	\N	f	\N	2611	5	3
Sieff	of Brimpton in the Royal County of Berks	1972-02-14	1	\N	1534	5	8	\N	f	\N	2612	5	20
Nugent of Guildford	of Dunsfold in the County of Surrey	1994-03-16	1	\N	1537	5	8	\N	f	\N	2613	5	15
Jackson of Burnley	of Burnley in the County Palatine of Lancaster	1970-02-17	1	\N	1557	5	8	\N	f	\N	2614	5	11
Wootton of Abinger	of Abinger Common in the County of Surrey	1988-07-11	1	\N	1360	5	8	\N	f	\N	2615	5	24
Byng of Vimy	of Thorpe-le-Soken in the County of Essex	1935-06-06	1	\N	938	7	12	\N	f	\N	2582	5	3
Foot	of Buckland Monachorum in the County of Devon	1999-10-11	1	\N	1580	5	8	\N	f	\N	2616	5	7
Dunn	of Hong Kong Island in Hong Kong and of Knightsbridge in the Royal Borough of Kensington and Chelsea	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2028	5	8	\N	f	\N	2649	5	5
Wilson of Langside	of Broughton in the County and City of Edinburgh	1997-12-30	1	\N	1600	5	8	\N	f	\N	2617	5	24
Burntwood	of Burntwood in the County of Stafford	1982-01-24	1	\N	1623	5	8	\N	f	\N	2618	5	3
Simon of Glaisdale	of Glaisdale in the North Riding of the County of York	2006-05-07	1	apptd L of Appeal in Ord 19 April 1971	1632	5	8	\N	f	\N	2619	5	20
Lloyd of Kilgerran	of Llanwenog in the County of Cardigan	1991-01-30	1	\N	1664	5	8	\N	f	\N	2620	5	13
Greenhill of Harrow	of the Royal Borough of Kensington and Chelsea	2000-11-08	1	\N	1668	5	8	\N	f	\N	2621	5	8
Chelwood	of Lewes in the County of East Sussex	1989-04-06	1	\N	1677	5	8	\N	f	\N	2622	5	4
Cudlipp	of Aldingbourne in the County of West Sussex	1998-05-17	1	\N	1713	5	8	\N	f	\N	2623	5	4
Pitt of Hampstead	of Hampstead in Greater London and of Hampstead in Grenada	1994-12-18	1	\N	1731	5	8	\N	f	\N	2624	5	17
Weidenfeld	of Chelsea in Greater London	2016-01-20	1	\N	1757	5	8	\N	f	\N	2625	5	24
Murray of Gravesend	of Gravesend in the County of Kent	1980-02-10	1	\N	1758	5	8	\N	f	\N	2626	5	14
McCluskey	of Churchhill in the District of the City of Edinburgh	2017-07-20	1	\N	1767	5	8	\N	f	\N	2627	5	14
Buxton of Alsa	of Stiffkey in the County of Norfolk	2009-09-01	1	\N	1799	5	8	\N	f	\N	2628	5	3
Smith	of Marlow in the County of Buckinghamshire	1998-07-01	1	\N	1803	5	8	\N	f	\N	2629	5	20
Perry of Walton	of Walton in the County of Buckinghamshire	2003-07-17	1	\N	1811	5	8	\N	f	\N	2630	5	17
Hooson	of Montgomery in the County of Powys and of Colomendy in the County of Clwyd	2012-02-21	1	\N	1831	5	8	\N	f	\N	2631	5	9
Boardman	of Welford in the County of Northamptonshire	2003-03-10	1	\N	1847	5	8	\N	f	\N	2632	5	3
Campbell of Alloway	of Ayr in the District of Kyle and Carrick	2013-06-30	1	\N	1867	5	8	\N	f	\N	2633	5	4
Quinton	of Holywell in the City of Oxford and County of Oxfordshire	2010-06-19	1	\N	1892	5	8	\N	f	\N	2634	5	18
Carmichael of Kelvingrove	of Camlachie in the District of the City of Glasgow	2001-07-19	1	\N	1919	5	8	\N	f	\N	2636	5	4
Crawshaw of Aintree	of Salford in the County of Greater Manchester	1986-07-16	1	\N	1937	5	8	\N	f	\N	2637	5	4
Mackintosh of Halifax	of Hethersett in the County of Norfolk	\N	\N	\N	1346	7	12	\N	f	\N	2638	5	14
Taylor	of Harlow in the County of Essex	1988-02-01	1	\N	1359	5	8	\N	f	\N	2639	5	21
Jauncey of Tullichettle	of Comrie in the District of Perth and Kinross	2007-07-18	1	retired 30.9.1996	1992	1	8	\N	f	\N	2640	5	11
Owen	of the City of Plymouth	\N	\N	\N	2070	5	8	\N	f	\N	2641	5	16
Tugendhat	of Widdington in the County of Essex	\N	\N	\N	2113	5	8	\N	f	\N	2643	5	21
Wright of Richmond	of Richmond upon Thames in the London Borough of Richmond upon Thames	2020-03-06	1	\N	2115	5	8	\N	f	\N	2644	5	24
Hope of Craighead	of Bamff in the District of Perth and Kinross	\N	\N	appointed a Lord of Appeal in Ordinary 1 October 1996 vice L Keith of Kinkel	2136	5	8	\N	f	\N	2645	5	9
Chadlington	of Dean in the County of Oxfordshire	\N	\N	\N	2172	5	8	\N	f	\N	2646	5	4
Hutton	of Bresagh in the County of Down	\N	\N	No Downing St announcement: mentioned in Lord Chancellor's Dept announcement of appointment of successor as LCJ of NI; appointed vice L Woolf MR	2176	1	8	\N	f	\N	2647	5	9
Delacourt-Smith of Alteryn	of Alteryn in the County of Gwent	2010-06-08	1	\N	1699	5	8	\N	f	\N	2648	5	5
Lloyd of Highbury	of Highbury in the London Borough of Islington	2006-06-28	1	\N	2158	5	8	\N	f	\N	2650	5	13
Stowell of Beeston	of Beeston in Our County of Nottinghamshire	\N	\N	\N	2699	5	8	\N	f	\N	2683	5	20
Vere of Norbiton	of Norbiton in the Royal Borough of Kingston upon Thames	\N	\N	\N	2870	5	8	\N	f	\N	2684	5	23
Wilkins	of Chesham Bois in the County of Buckinghamshire	\N	\N	\N	2341	5	8	\N	f	\N	2685	5	24
Russell-Johnston	of Minginish in Highland	2008-07-27	1	surname changed from "Johnston" after announcement	2204	5	8	\N	f	\N	2651	5	19
Lister of Burtersett	of Nottingham in the County of Nottinghamshire	\N	\N	\N	2731	5	8	\N	f	\N	2681	5	13
Morris of Manchester	of Manchester in the County of Greater Manchester	2012-08-12	1	\N	2230	5	8	\N	f	\N	2652	5	14
Stone of Blackheath	of Blackheath in the London Borough of Greenwich	\N	\N	\N	2248	5	8	\N	f	\N	2653	5	20
Montague of Oxford	of Oxford in the County of Oxfordshire	1999-11-05	1	\N	2254	5	8	\N	f	\N	2654	5	14
Sheppard of Liverpool	of West Kirby in the County of Merseyside	2005-03-05	1	previously a member of HL as Bp of Liverpool	2269	5	8	\N	f	\N	2655	5	20
Bell	of Belgravia in the City of Westminster	2019-08-25	1	\N	2294	5	8	\N	f	\N	2656	5	3
Phillips of Worth Matravers	of Belsize Park in the London Borough of Camden	\N	\N	vice L Lloyd of Berwick resigned; appointed MR 17 July 2000	2305	1	8	\N	f	\N	2657	5	17
Temple-Morris	of Llandaff in the County of South Glamorgan and of Leominster in the County of Herefordshire	2018-05-01	1	\N	2415	5	8	\N	f	\N	2660	5	21
Kalms	of Edgware in the London Borough of Barnet	\N	\N	\N	2458	5	8	\N	f	\N	2661	5	12
Laidlaw	of Rothiemay in Banffshire	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2476	5	8	\N	f	\N	2662	5	13
Kinnock	of Bedwellty in the County of Gwent	\N	\N	\N	2505	5	8	\N	f	\N	2663	5	12
Griffiths of Burry Port	of Pembrey and Burry Port in the County of Dyfed	\N	\N	\N	2500	5	8	\N	f	\N	2664	5	8
Soley	of Hammersmith in the London Borough of Hammersmith and Fulham	\N	\N	\N	2535	5	8	\N	f	\N	2665	5	20
Havers	of St Edmundsbury in the County of Suffolk	1992-04-01	1	apptd Lord Chancellor	1969	5	8	\N	f	\N	2666	5	9
Mandelson	of Foy in the County of Herefordshire and of Hartlepool in the County of Durham	\N	\N	\N	2604	5	8	\N	f	\N	2667	5	14
McFall of Alcluith	of Dumbarton in Dunbartonshire	\N	\N	\N	2627	5	8	\N	f	\N	2668	5	14
Kennedy of Southwark	of Newington in the London Borough of  Southwark	\N	\N	\N	2636	5	8	\N	f	\N	2669	5	12
Wills	of North Swindon in the County of Wiltshire and of Woodside Park in the London Borough of Barnet	\N	\N	\N	2659	5	8	\N	f	\N	2670	5	24
Prior of Brampton	of Swannington in the County of Norfolk	\N	\N	\N	2817	5	8	\N	f	\N	2671	5	17
Allan of Hallam	of Ecclesall in the County of South Yorkshire	\N	\N	\N	2677	5	8	\N	f	\N	2672	5	2
Marks of Henley-on-Thames	of Henley-on-Thames in the County of Oxfordshire	\N	\N	\N	2701	5	8	\N	f	\N	2673	5	14
Edmiston	of Lapworth in the County of Warwickshire	\N	\N	\N	2707	5	8	\N	f	\N	2674	5	6
Hague of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2838	5	8	\N	f	\N	2675	5	9
O'Shaughnessy	of Maidenhead in the Royal County of Berkshire	\N	\N	\N	2826	5	8	\N	f	\N	2676	5	16
Cooper of Windrush	of Chipping Norton in the County of Oxfordshire	\N	\N	\N	2795	5	8	\N	f	\N	2677	5	4
Watts	of Ravenhead in the County of Merseyside	\N	\N	\N	2859	5	8	\N	f	\N	2678	5	24
Allen of Kensington	of Kensington in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2779	5	8	\N	f	\N	2679	5	2
Hale of Richmond	of Easby in the County of North Yorkshire	\N	\N	vice L Millett resigned	2455	1	8	\N	f	\N	2680	5	9
Morgan of Huyton	of Huyton in the County of Merseyside	\N	\N	\N	2413	5	8	\N	f	\N	2682	5	14
Hutchinson	of Knocklofty in the County of Tipperary	\N	\N	SR to heirs male of his mother by his father; was 2nd L Donoughmore (I)	110	3	12	\N	f	1	2716	5	9
Kinnaird	of Rossie in the County of Perth	1997-02-27	5	also 1st L Rossie (cr 1831); SR to brother	325	8	8	\N	f	1	2717	5	12
Curzon of Kedleston	in the County of Derby	1925-03-20	1	NB 2 different special remainders for subsidiary titles	721	3	6	\N	f	5	2718	5	4
Mann	of Holbeck Moor in the City of Leeds	\N	\N	\N	2929	5	8	\N	f	\N	2686	5	14
Bennett of Manor Castle	of Camden in the London Borough of Camden	\N	\N	\N	2913	5	8	\N	f	\N	2713	5	3
Carter of Haslemere	of Haslemere in the County of Surrey	\N	\N	\N	2930	5	8	\N	f	\N	2687	5	4
Williams of Oystermouth	of Oystermouth in the City and County of Swansea	\N	\N	\N	2747	5	8	\N	f	\N	2688	5	24
Neuberger of Abbotsbury	of Abbotsbury in the County of Dorset	\N	\N	vice L Nicholls of Birkenhead	2580	1	8	\N	f	\N	2689	5	15
Moore	of Moore Place in the County of Kent	1892-06-29	3	\N	1	3	8	\N	f	\N	2690	5	14
Ardrossan	of Ardrossan in the County of Ayr	\N	\N	2nd L cr E of Winton 1859	43	4	8	\N	f	\N	2691	5	2
Granard	of Castle Donnington in the County of Leicester	\N	\N	9th E died 19 Nov 1992	45	3	8	\N	f	\N	2692	5	8
Penshurst	of Penshurst in the County of Kent	1869-01-09	3	\N	136	3	8	\N	f	\N	2694	5	17
Ranfurly	of Ramphorlie in the County of Renfrew	\N	\N	cr E of Ranfurly (I) 1831; ?th L died 6 Nov 1988	141	3	8	\N	f	\N	2695	5	19
Fingall	of Woolhampton Lodge in the County of Berks	1984-03-05	5	\N	171	3	8	\N	f	\N	2696	5	7
Howden	of Howden and Grimston in the County of York	1873-10-09	2	\N	183	3	8	\N	f	\N	2697	5	9
Amesbury	of Kintbury, Amesbury and of Barton Bourt in the County of Berks and of Aston Hall in the County of Flint	1832-06-30	1	\N	200	2	8	\N	f	\N	2698	5	2
Beauvale	of Beauvale in the County of Nottingham	1853-01-29	1	succ 1848 as 3rd V Melbourne (I) & L Melbourne	245	2	8	\N	f	\N	2699	5	3
Somerton	of Somerley in the County of Southampton	\N	\N	4th L succ 1974 as 9th L Mendip (cr 1794)	391	3	8	\N	f	\N	2700	5	20
Hawkesbury	of Haselbech in the County of Northampton and of Ollerton, Sherwood Forest, in the County of Nottingham	\N	\N	cr E of Liverpool 1905	553	2	8	\N	f	\N	2701	5	9
Newlands	of Newlands and Barrowfield in the County of the City of Glasgow and of Mauldslie Castle in the County of Lanark	1929-09-05	2	\N	592	2	8	\N	f	\N	2702	5	15
Colville of Culross	in the County of Perth	\N	\N	also 10th L C of C (Sc)	620	7	12	\N	f	\N	2703	5	4
Willingdon	of Ratton in the County of Sussex	1979-03-19	2	cr V Willingdon 1924, E of Willingdon 1931, M of Willingdon 1936	698	2	8	\N	f	\N	2704	5	24
Ruthven of Gowrie	of Gowrie in the County of Perth	\N	\N	subsumed in E of Gowrie on death of 2nd L 1956-04-16	845	4	8	\N	f	\N	2705	5	19
Runciman	of Shoreston in the County of Northumberland	\N	\N	subsumed in V Runciman of Doxford 13.8.1937	1007	2	8	\N	f	\N	2706	5	19
Nuffield	of Nuffield in the County of Oxford	1963-08-22	1	cr V Nuffield 24 Jan 1938	1020	2	8	\N	f	\N	2707	5	15
Mackintosh of Halifax	of Hethersett in the County of Norfolk	\N	\N	cr V Mackintosh of Halifax 10 Jly 1957	1236	2	8	\N	f	\N	2708	5	14
Bridges	of Headley in the County of Surrey and of Saint Nicholas at Wade in the County of Kent	\N	\N	\N	1339	2	8	\N	f	\N	2709	5	3
Reith	of Stonehaven in the County of Kincardine	\N	\N	2nd L disclaimed	1108	2	8	\N	f	\N	2710	5	19
Taylor of Mansfield	of Mansfield in the County of Nottingham	1991-04-11	1	\N	1538	5	8	\N	f	\N	2711	5	21
Aberdeen and Temair	in the County of Aberdeen and in the County of Meath and in the County of Argyll	\N	\N	\N	753	4	9	\N	t	\N	2712	5	2
St Vincent	of Meaford in the County of Stafford	\N	\N	SR to (1) William Henry Ricketts & h m of b; (2) Edward Jervis Ricketts (bro of (1)) & h m of b; (3) Mary C of Northesk & h m of b	7	8	12	\N	f	\N	2715	5	20
Chakrabarti	of Kennington in the London Borough of Lambeth	\N	\N	\N	2879	5	8	\N	f	\N	2714	5	4
Knight of Collingtree	of Collingtree in the County of Northamptonshire	\N	\N	\N	2208	5	8	\N	f	\N	2749	5	12
Morris of Bolton	of Bolton in the County of Greater Manchester	\N	\N	born 1953	2471	5	8	\N	f	\N	2750	5	14
Thomas of Winchester	of Winchester in the County of Hampshire	\N	\N	\N	2548	5	8	\N	f	\N	2751	5	21
Nelson	of the Nile and of Hilborough in the County of Norfolk	\N	\N	SR to (1) his father; (2) h m of his sister Susanna; (3) h m of his sister Catherine; 2nd L cr E Nelson 1805	18	8	8	\N	f	1	2752	5	15
Hill	of Almaraz and of Hawkstone and Hardwicke in the County of Salop	\N	\N	SR in default of h m of b to issue of late brother John Hill; cr V Hill 1842 with similar remainder	102	8	8	\N	f	1	2753	5	9
Somervell of Harrow	of Ewelme in the County of Oxford	1960-11-18	1	vice L Asquith of Bishopstone deceased	1310	1	8	\N	f	\N	2720	5	20
James of Holland Park	of Southwold in the County of Suffolk	2014-11-27	1	James = maiden surname; also described as "(Mrs White)" in Gazette announcement of 31.12.90.	2035	5	8	\N	f	\N	2747	5	11
Bannerman of Kildonan	of Kildonan in the County of Sutherland	1969-05-10	1	\N	1582	5	8	\N	f	\N	2721	5	3
Dunrossil	of Vallaquie in the Isle of North Uist and County of Inverness	\N	\N	\N	1381	2	12	\N	f	\N	2722	5	5
Wakefield of Kendal	of Kendal in the County of Westmorland	1983-08-12	1	\N	1449	2	8	\N	f	\N	2723	5	24
Ballantrae	of Auchairne in the County of Ayr and of the Bay of Islands in New Zealand	1980-11-28	1	\N	1658	5	8	\N	f	\N	2724	5	3
Alexander of Potterhill	of Paisley in the County of Renfrew	1993-09-08	1	\N	1705	5	8	\N	f	\N	2725	5	2
Charteris of Amisfield	of Amisfield in the District of East Lothian	1999-12-23	1	\N	1781	5	8	\N	f	\N	2726	5	4
Lowry	of Crossgar in the County of Down	1999-01-15	1	cr Lord of Appeal in Ordinary 5 Aug 1988; resigned 7 Jan 1994	1827	5	8	\N	f	\N	2727	5	13
Matthews	of Southgate in the London Borough of Enfield	1995-12-05	1	\N	1850	5	8	\N	f	\N	2728	5	14
Maude of Stratford-upon-Avon	of Stratford-upon-Avon in the County of Warwickshire	1993-11-09	1	\N	1910	5	8	\N	f	\N	2729	5	14
Johnston of Rockport	of Caversham in the Royal County of Berkshire	2002-04-30	1	\N	1963	5	8	\N	f	\N	2730	5	11
Howe of Aberavon	of Tandridge in the County of Surrey	2015-10-09	1	\N	2071	5	8	\N	f	\N	2731	5	9
Harris of Peckham	of Peckham in the London Borough of Southwark	\N	\N	\N	2148	5	8	\N	f	\N	2733	5	9
Marshall of Knightsbridge	of Knightsbridge in the City of Westminster	2012-07-05	1	\N	2275	5	8	\N	f	\N	2734	5	14
Willingdon	of Ratton in the County of Sussex	1979-03-19	2	cr E of Willingdon 1931	912	7	12	\N	f	\N	2735	5	24
Ponsonby	of Imokilly in the County of Cork	1866-09-10	4	title subsumed 12 April 1839-21 Feb 1855	48	2	8	\N	f	\N	2736	5	17
Panmure	of Brechin and Navar in the County of Forfar	1874-07-06	2	2nd L succ as 11th E of Dalhousie 22 Dec 1860	184	2	8	\N	f	\N	2738	5	17
Ennishowen and Carrickfergus	of Ennishowen in the County of Donegal and of Carrickfergus in the County of Antrim	1883-10-20	1	succ as 3rd M of Donegall (I) & L Fisherwick	266	2	8	\N	f	\N	2739	5	6
Strathspey	of Strathspey in the Counties of Inverness and Moray	1884-03-31	2	5th L died 27 Jan 1992	311	4	8	\N	f	\N	2740	5	20
Brancepeth	of Brancepeth in the County Palatine of Durham	\N	\N	4th L died 14 Dec 1995	351	3	8	\N	f	\N	2741	5	3
Foulkes of Cumnock	of Cumnock in East Ayrshire	\N	\N	\N	2517	5	8	\N	f	\N	2742	5	7
Maples	of Stratford-upon-Avon in the County of Warwickshire	2012-06-09	1	\N	2641	5	8	\N	f	\N	2743	5	14
Ribeiro	of Achimota in the Republic of Ghana and of Ovington in the County of Hampshire	\N	\N	\N	2690	5	8	\N	f	\N	2744	5	19
Fellowes of West Stafford	of West Stafford in the County of Dorset	\N	\N	\N	2703	5	8	\N	f	\N	2745	5	7
Fall	of Ladbroke Grove in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2857	5	8	\N	f	\N	2746	5	7
Jones of Whitchurch	of Whitchurch in the County of South Glamorgan	\N	\N	\N	2557	5	8	\N	f	\N	2748	5	11
Kingsmill	of Holland Park in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2553	5	8	\N	f	\N	2780	5	12
Kitchener of Khartoum	and of the Vaal in the Colony of Transvaal, and of Aspall in the County of Suffolk	2011-12-16	3	SR to daughters & brothers; cr E Kitchener 1914	619	7	12	\N	f	1	2781	5	12
Strathcona and Mount Royal	of Mount Royal in the Province of Quebec and Dominion of Canada and of Glencoe in the County of Argyll	\N	\N	SR to dau	612	8	8	\N	f	2	2782	5	20
Kitchener	of Khartoum and of Broome in the County of Kent	2011-12-16	3	SR to daughters then 2 named brothers	749	7	6	\N	f	2	2783	5	12
Kirkhope of Harrogate	of Harrogate in the County of North Yorkshire	\N	\N	\N	2874	5	8	\N	f	\N	2754	5	12
Snowdon	\N	\N	\N	subsequently created L. Armstrong-Jones (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1419	2	6	\N	t	\N	2778	5	20
Houghton of Richmond	of Richmond in the County of North Yorkshire	\N	\N	\N	2892	5	8	\N	f	\N	2755	5	9
McCorquodale of Newton	of Newton-le-Willows in the County Palatine of Lancaster	1971-09-25	1	\N	1323	2	8	\N	f	\N	2756	5	14
Campbell	of Saint Andrews in the County of Fife	\N	\N	wife had been cr B Stratheden 1836; title passed to 2nd L Stratheden	261	2	8	\N	f	\N	2757	5	4
Williams of Elvel	of Llansantffraed in Elvel in the County of Powys	2019-12-30	1	\N	1939	5	8	\N	f	\N	2759	5	24
St John of Fawsley	of Preston Capes in the County of Northamptonshire	2012-03-02	1	\N	1982	5	8	\N	f	\N	2760	5	20
Grenfell of Kilvey	of Kilvey in the County of Swansea	\N	\N	Succeeded as 3rd L Grenfell 1976; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2372	6	8	\N	f	\N	2761	5	8
Macpherson of Earl's Court	of Earl's Court in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2881	5	8	\N	f	\N	2762	5	14
Livsey of Talgarth	of Talgarth in the County of Powys	2010-09-15	1	\N	2447	5	8	\N	f	\N	2763	5	13
Blackburn	of Killearn in the County of Stirling	1896-01-08	1	1st Lord of Appeal in Ordinary; lost seat by resignation Dec 1886, reinstated by Act of 1887.	423	1	8	\N	f	\N	2764	5	3
Stanley of Preston	in the County Palatine of Lancaster	\N	\N	succ 1893 as 16th E of Derby	501	2	8	\N	f	\N	2765	5	20
Milner	of Saint James's in the County of London and of Cape Town in the Cape Colony	1925-05-13	1	\N	622	7	12	\N	f	\N	2766	5	14
Sandhurst	of Sandhurst in the County of Berks	1921-11-02	1	barony passed to brother	774	7	12	\N	f	\N	2767	5	20
Casey	of Berwick in the State of Victoria and Commonwealth of Australia and of the City of Westminster	1976-06-17	1	\N	1392	5	8	\N	f	\N	2769	5	4
Sumner	of Ibstone in the County of Buckingham	1934-05-24	1	\N	932	7	12	\N	f	\N	2770	5	20
D'Abernon	of Esher and of Stoke D'Abernon in the County of Surrey	1941-11-01	1	\N	924	7	12	\N	f	\N	2771	5	5
Bingham	of Melcombe Bingham in the County of Dorset	\N	\N	elected I. rep peer 1914	1023	3	8	\N	f	\N	2772	5	3
Cherwell	of Oxford in the County of Oxford	1957-07-03	1	cr V Cherwell 26 June 1956	1117	2	8	\N	f	\N	2773	5	4
Alexander of Hillsborough	of Hillsborough in the City of Sheffield	1965-01-11	1	cr E Alexander of Hillsborough 30 Jan 1963	1251	2	12	\N	f	\N	2774	5	2
Norrie	of Wellington, New Zealand, and of Hawkesbury Upton in the County of Gloucester	\N	\N	\N	1347	2	8	\N	f	\N	2775	5	15
Runcorn	of Heswall in the County Palatine of Chester	1968-01-20	1	\N	1463	5	8	\N	f	\N	2776	5	19
Midlothian	\N	\N	\N	grantee was also 2nd L Rosebery (cr 1828)	714	7	6	\N	t	\N	2777	5	14
Cambridge	\N	1981-04-16	2	full names: Adolphus Charles Alexander Albert Edward George Philip Louis Ladislaus	793	2	9	\N	t	\N	2779	5	4
Spencer-Churchill	of Chartwell in the County of Kent	1977-12-12	1	\N	1523	5	8	\N	f	\N	2817	5	20
Maelor	of Rhosllanerchrugog in the County of Denbigh	1984-11-18	1	\N	1544	5	8	\N	f	\N	2784	5	14
Gardner of Parkes	of Southgate in Greater London and of Parkes in the State of New South Wales and Commonwealth of Australia	\N	\N	\N	1869	5	8	\N	f	\N	2815	5	8
Hartwell	of Peterborough Court in the City of London	2001-04-03	1	succ 15 Feb 1995 as 3rd V Camrose; disclaimed that year	1585	5	8	\N	f	\N	2785	5	9
Greenwood of Rossendale	of East Mersea in the County of Essex	1982-04-12	1	\N	1624	5	8	\N	f	\N	2786	5	8
Home of the Hirsel	of Coldstream in the County of Berwick	1995-10-09	1	had disclaimed Earldom of Home	1708	5	8	\N	f	\N	2787	5	9
Harmar-Nicholls	of Peterborough in Cambridgeshire	2000-09-15	1	\N	1715	5	8	\N	f	\N	2788	5	9
Campbell of Croy	of Croy in the County of Nairn	2005-04-26	1	\N	1714	5	8	\N	f	\N	2789	5	4
Hutchinson of Lullington	of Lullington in the County of East Sussex	2017-11-13	1	\N	1800	5	8	\N	f	\N	2790	5	9
McAlpine of Moffat	of Medmenham in the County of Buckinghamshire	1990-01-07	1	\N	1845	5	8	\N	f	\N	2791	5	14
John-Mackie	of Nazeing in the County of Essex	1994-05-26	1	surname changed from Mackie	1858	5	8	\N	f	\N	2792	5	11
Henderson of Brompton	of Brompton in the Royal Borough of Kensington and Chelsea and of Brough in the County of Cumbria	2000-01-13	1	\N	1924	5	8	\N	f	\N	2793	5	9
Rippon of Hexham	of Hesleyside in the County of Northumberland	1997-01-28	1	\N	1972	5	8	\N	f	\N	2794	5	19
Jenkin of Roding	of Wanstead and Woodford in Greater London	2016-12-20	1	\N	1985	5	8	\N	f	\N	2795	5	11
Bowness	of Warlingham in the County of Surrey and of Croydon in the London Borough of Croydon	\N	\N	\N	2152	5	8	\N	f	\N	2796	5	3
Clyde	of Briglands in Perthshire and Kinross	2009-03-06	1	vice L Jauncey of Tullichettle	2162	1	8	\N	f	\N	2797	5	4
Douglas	of Douglas in the County of Lanark	\N	\N	4th L disclaimed 1963 & died 9 Oct 1995	409	4	8	\N	f	\N	2799	5	5
Ashfield	of Southwell in the County of Nottingham	1948-11-04	1	\N	850	2	8	\N	f	\N	2800	5	2
Greenwood	of Llanbister in the County of Radnor	2003-07-07	3	cr V Greenwood 16 Feb 1937	972	2	8	\N	f	\N	2801	5	8
Hanworth	of Hanworth in the County of Middlesex	\N	\N	2nd V died 31 Aug 1996	1047	7	12	\N	f	\N	2802	5	9
Dowding	of Bentley Priory in the County of Middlesex	\N	\N	2nd L died 22 Nov 1992	1138	2	8	\N	f	\N	2803	5	5
Alexander of Tunis	of Errigal in the County of Donegal	\N	\N	cr E Alexander of Tunis 11 Mch 1952	1202	2	12	\N	f	\N	2804	5	2
Baillieu	of Sefton in the Commonwealth of Australia and of Parkwood in the County of Surrey	\N	\N	\N	1292	2	8	\N	f	\N	2805	5	3
Inglewood	of Hutton in the Forest in the County of Cumberland	\N	\N	\N	1467	2	8	\N	f	\N	2806	5	10
MacLeod of Fuinary	of Fuinary in Morven in the County of Argyll	1991-06-27	1	\N	1559	5	8	\N	f	\N	2807	5	14
Callaghan of Cardiff	of the City of Cardiff in the County of South Glamorgan	2005-03-26	1	\N	1987	5	8	\N	f	\N	2809	5	4
Hollick	of Notting Hill in the Royal Borough of Kensington and Chelsea	\N	\N	\N	2046	5	8	\N	f	\N	2810	5	9
Haskins	of Skidby in the County of the East Riding of Yorkshire	\N	\N	\N	2284	5	8	\N	f	\N	2811	5	9
Brown of Eaton-under-Heywood	of Eaton-under-Heywood in the County of Shropshire	\N	\N	vice L Hobhouse of Woodborough resigned	2457	1	8	\N	f	\N	2812	5	3
Leach of Fairford	of Fairford in the County of Gloucestershire	2016-06-12	1	\N	2559	5	8	\N	f	\N	2813	5	13
Falkner of Margravine	of Barons Court in the London Borough of Hammersmith and Fulham	\N	\N	\N	2460	5	8	\N	f	\N	2814	5	7
Neville-Jones	of Hutton Roof in the County of Cumbria	\N	\N	\N	2594	5	8	\N	f	\N	2816	5	15
Howells of St Davids	of Charlton in the London Borough of Greenwich	\N	\N	\N	2327	5	8	\N	f	\N	2842	5	9
Kennedy of Cradley	of Cradley in the Metropolitan Borough of Dudley	\N	\N	\N	2776	5	8	\N	f	\N	2843	5	12
Richardson of Calow	of Calow in the County of Derbyshire	\N	\N	\N	2297	5	8	\N	f	\N	2844	5	19
Ritchie of Brompton	of Brompton in the Royal Borough of Kensington and Chelsea	2012-04-24	1	\N	2644	5	8	\N	f	\N	2845	5	19
Williams of Trafford	of Hale in the County of Greater Manchester	\N	\N	\N	2777	5	8	\N	f	\N	2846	5	24
Young of Hornsey	of Hornsey in the London Borough of Haringey	\N	\N	\N	2488	5	8	\N	f	\N	2847	5	26
Stoneham of Droxford	of the Meon Valley in the County of Hampshire	\N	\N	\N	2712	5	8	\N	f	\N	2818	5	20
Evans of Bowes Park	of Bowes Park in the London Borough of Haringey	\N	\N	\N	2789	5	8	\N	f	\N	2840	5	6
McCrea of Magherafelt and Cookstown	of Magherafelt in the County of Londonderry and Cookstown in the County of Tyrone	\N	\N	\N	2896	5	8	\N	f	\N	2819	5	14
Erroll of Hale	of Kilmun in the County of Argyll	2000-09-14	1	subsequently created L Erroll of Kilmun (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1495	2	8	\N	f	\N	2820	5	6
Lyons	of Christ Church in the County of Southampton	1887-12-05	1	said to have died while a patent for an earldom was in preparation	454	7	12	\N	f	\N	2822	5	13
Foster of Thames Bank	of Reddish in the County of Greater Manchester	\N	\N	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2322	5	8	\N	f	\N	2823	5	7
Barber of Tewkesbury	of Gotherington in the County of Gloucestershire	2017-11-21	1	\N	2095	5	8	\N	f	\N	2824	5	3
Cooke of Thorndon	of Wellington in New Zealand and of Cambridge in the County of Cambridgeshire	2006-08-30	1	New Zealand judge	2156	5	8	\N	f	\N	2825	5	4
Bagri	of Regent's Park in the City of Westminster	2017-04-26	1	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	2177	5	8	\N	f	\N	2826	5	3
Sainsbury of Turville	of Turville in the County of Buckinghamshire	\N	\N	\N	2225	5	8	\N	f	\N	2827	5	20
Christopher	of Leckhampton in the County of Gloucestershire	\N	\N	\N	2291	5	8	\N	f	\N	2828	5	4
Foster of Bishop Auckland	of Bishop Auckland in the County of Durham	2019-01-06	1	\N	2518	5	8	\N	f	\N	2829	5	7
Stern of Brentford	of Elsted in the County of West Sussex and of Wimbledon in the London Borough of Merton	\N	\N	\N	2597	5	8	\N	f	\N	2830	5	20
Maude of Horsham	of Shipley in the County of West Sussex	\N	\N	\N	2814	5	8	\N	f	\N	2831	5	14
Macdonald of River Glaven	of Cley-next-the-Sea in the County of Norfolk	\N	\N	\N	2662	5	8	\N	f	\N	2832	5	14
Goddard of Stockport	of Stockport in the County of Greater Manchester	\N	\N	\N	2790	5	8	\N	f	\N	2833	5	8
Woolley of Woodford	of Woodford in the London Borough of Redbridge	\N	\N	\N	2924	5	8	\N	f	\N	2834	5	24
Belstead	of Ipswich in the County of Suffolk	2005-12-03	2	2nd L. created L. Ganzoni (life peer) 17 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1084	2	8	\N	f	\N	2835	5	3
Cochrane of Cults	of Crawford Priory in the County of Fife	\N	\N	3rd L died 15 June 1990	830	2	8	\N	f	\N	2836	5	4
Jellicoe	\N	\N	\N	2nd E. created L. Jellicoe of Southampton (life peer) 17 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999; he died 22 Feb 2007	918	7	6	\N	f	\N	2837	5	11
Davies of Coity	of Penybont in the County of Mid Glamorgan	2019-03-04	1	\N	2221	5	8	\N	f	\N	2838	5	5
Butler-Sloss	of Marsh Green in the County of Devon	\N	\N	\N	2569	5	8	\N	f	\N	2839	5	3
Heyhoe Flint	of Wolverhampton in the County of West Midlands	2017-01-18	1	\N	2720	5	8	\N	f	\N	2841	5	9
Saint Germans	in the County of Cornwall	\N	\N	SR in default of h m of b to his brother Wm Eliot & h m of b	98	7	6	\N	t	1	2884	5	20
Wilton	of Wilton Castle in the County of Hereford	\N	\N	SR to 2nd & subsequent sons of his dau Eleanor	16	7	6	\N	t	1	2885	5	24
Savernake	of Savernake Forest, Wilts	\N	0	\N	2974	7	12	\N	f	\N	119	5	20
Argyll	in Scotland	\N	\N	already 4th L Sundridge (GB) cr 1766, succ 1847	532	8	4	\N	t	\N	2850	5	2
Cambridge	\N	\N	\N	not introduced as not a member of the House of Lords	2740	2	4	\N	t	\N	2851	5	4
Clarence and Avondale	\N	1892-01-14	1	\N	521	2	4	\N	t	\N	2852	5	4
Connaught and Strathearn	\N	1943-04-26	2	\N	408	2	4	\N	t	\N	2853	5	4
Edinburgh	\N	1900-07-30	1	\N	341	2	4	\N	t	\N	2854	5	6
Edinburgh	\N	\N	\N	\N	1234	2	4	\N	t	\N	2855	5	6
Gloucester	\N	\N	\N	\N	942	2	4	\N	t	\N	2856	5	8
Kent	\N	\N	\N	\N	1028	2	4	\N	t	\N	2857	5	12
Sussex	\N	\N	\N	not introduced as not a member of the House of Lords	2908	2	4	\N	t	\N	2858	5	20
Wellington	in the County of Somerset	\N	\N	\N	71	7	4	\N	t	\N	2859	5	24
Windsor	\N	1972-05-28	1	\N	1062	2	4	\N	t	\N	2860	5	24
York	\N	\N	\N	\N	1954	2	4	\N	t	\N	2861	5	26
York	\N	1936-12-11	1	merged in Crown 11 Dec 1936	855	2	4	\N	t	\N	2862	5	26
Avon	\N	1985-08-17	2	& V Eden	1417	2	6	\N	t	\N	2863	5	2
Beaconsfield	in the County of Buckingham	1881-04-19	1	\N	421	2	6	\N	t	\N	2864	5	3
Burlington	\N	\N	\N	2nd E succ as 7th D of Devonshire 1858	177	2	6	\N	t	\N	2865	5	3
Dudley	of Dudley Castle in the County of Stafford	1833-03-06	1	\N	156	7	6	\N	t	\N	2867	5	5
Dufferin	in the County of Down	1988-05-29	5	cr M of Dufferin and Ava 1888	384	7	6	\N	t	\N	2868	5	5
Fife	\N	1912-01-29	1	was already 2nd L Skene (cr 1857, succ 1879); cr D of Fife 1889 & (SR) 1900	480	8	6	\N	t	\N	2869	5	7
Gowrie	\N	\N	\N	\N	1151	7	6	\N	t	\N	2870	5	8
Harewood	in the County of York	\N	\N	Earldom of Mulgrave created same day	67	7	6	\N	t	\N	2871	5	9
Iveagh	\N	\N	\N	3rd E died 18 June 1992	837	7	6	\N	t	\N	2872	5	10
Leicester	of Holkham in the County of Norfolk	\N	\N	6th E died 19 June 1994	232	2	6	\N	t	\N	2873	5	13
Liverpool	\N	\N	\N	\N	644	7	6	\N	t	\N	2874	5	13
Reading	\N	\N	\N	cr M of Reading 1926	798	7	6	\N	t	\N	2875	5	19
Swinton	\N	\N	\N	2nd E. died 24 March 2006	1318	7	6	\N	t	\N	2876	5	20
Wellington	in the County of Somerset	\N	\N	cr M of Wellington 3 Oct 1812	63	7	6	\N	t	\N	2877	5	24
Wessex	\N	\N	\N	created also E of Forfar 10 March 2019	2311	2	6	\N	t	\N	2878	5	24
Willingdon	\N	1979-03-19	2	cr Marquess of Willingdon 1936	989	7	6	\N	t	\N	2879	5	24
Crewe	\N	1945-06-20	1	\N	713	7	9	\N	t	\N	2880	5	4
Buckingham and Chandos	\N	1889-03-26	3	SR for E Temple of Stowe (extant 2006)	130	7	4	\N	t	5	2881	5	3
Seaham	of Seaham in the County Palatine of Durham	\N	0	\N	2976	8	12	\N	f	\N	124	5	20
Dunwich	in the County of Suffolk	\N	0	\N	2975	7	12	\N	f	\N	118	5	5
Albany	\N	1919-03-28	2	2nd L struck from roll 28 Mch 1919	447	2	4	\N	t	\N	2849	5	2
Cromartie	\N	\N	\N	SR to younger children, inc daughters, but to be separate from earldom of Sutherland	330	2	6	\N	t	\N	2886	5	4
Fife	\N	\N	\N	SR to 2 named daus	604	8	4	\N	t	2	2882	5	7
Adams of Craigielea	of Craigielea in Renfrewshire	\N	\N	\N	2534	5	8	\N	f	\N	2889	5	2
Afshar	of Heslington in the County of North Yorkshire	\N	\N	\N	2598	5	8	\N	f	\N	2890	5	2
Airey of Abingdon	of Abingdon in the County of Oxford	1992-11-27	1	\N	1833	5	8	\N	f	\N	2891	5	2
Altmann	of Tottenham in the London Borough of Haringey	\N	\N	\N	2812	5	8	\N	f	\N	2892	5	2
Amos	of Brondesbury in the London Borough of Brent	\N	\N	\N	2209	5	8	\N	f	\N	2893	5	2
Andrews	of Southover in the County of East Sussex	\N	\N	\N	2388	5	8	\N	f	\N	2894	5	2
Anelay of St Johns	of St Johns in the County of Surrey	\N	\N	\N	2170	5	8	\N	f	\N	2895	5	2
Bacon	of the City of Leeds and of Normanton in the West Riding of the County of York	1993-03-24	1	\N	1628	5	8	\N	f	\N	2897	5	3
Bakewell of Hardington Mandeville	of Hardington Mandeville in the County of Somerset	\N	\N	\N	2760	5	8	\N	f	\N	2898	5	3
Bertin	of Battersea in the London Borough of Wandsworth	\N	\N	\N	2876	5	8	\N	f	\N	2899	5	3
Birk	of Regent's Park in Greater London	1996-12-29	1	\N	1571	5	8	\N	f	\N	2900	5	3
Blackstone	of Stoke Newington in Greater London	\N	\N	\N	1958	5	8	\N	f	\N	2901	5	3
Bonham-Carter of Yarnbury	of Yarnbury in the County of Wiltshire	\N	\N	\N	2491	5	8	\N	f	\N	2902	5	3
Bowles of Berkhamsted	of Bourne End in the County of Hertfordshire	\N	\N	\N	2858	5	8	\N	f	\N	2903	5	3
Brigstocke	of Kensington in the Royal Borough of Kensington and Chelsea	2004-04-30	1	\N	2017	5	8	\N	f	\N	2904	5	3
Brooke of Ystradfellte	of Ystradfellte in the County of Brecknock	2000-09-01	1	\N	1483	5	8	\N	f	\N	2905	5	3
Campbell of Surbiton	of Surbiton in the Royal Borough of Kingston upon Thames	\N	\N	\N	2586	5	8	\N	f	\N	2906	5	4
Carnegy of Lour	of Lour in the District of Angus	2010-11-09	1	\N	1880	5	8	\N	f	\N	2907	5	4
Castle of Blackburn	of Ibstone in the County of Buckinghamshire	2002-05-03	1	\N	2025	5	8	\N	f	\N	2908	5	4
Chalker of Wallasey	of Leigh-on-Sea in the County of Essex	\N	\N	\N	2063	5	8	\N	f	\N	2909	5	4
Cumberlege	of Newick in the County of East Sussex	\N	\N	\N	2016	5	8	\N	f	\N	2911	5	4
David	of Romsey in the City of Cambridge	2009-11-29	1	\N	1792	5	8	\N	f	\N	2912	5	5
Dean of Thornton-le-Fylde	of Eccles in the County of Greater Manchester	2018-03-13	1	\N	2110	5	8	\N	f	\N	2913	5	5
Denton of Wakefield	of Wakefield in the County of West Yorkshire	2001-02-05	1	\N	2043	5	8	\N	f	\N	2914	5	5
Doocey	of Hampton in the London Borough of Richmond upon Thames	\N	\N	\N	2692	5	8	\N	f	\N	2915	5	5
Elles	of the City of Westminster	2009-10-17	1	\N	1654	5	8	\N	f	\N	2916	5	6
Faithfull	of Wolvercote in the County of Oxfordshire	1996-03-13	1	\N	1747	5	8	\N	f	\N	2917	5	7
Falkender	of West Haddon in Northamptonshire	2019-02-06	1	\N	1703	5	8	\N	f	\N	2918	5	7
Finlay of Llandaff	of Llandaff in the County of South Glamorgan	\N	\N	\N	2421	5	8	\N	f	\N	2919	5	7
Horsbrugh	of Horsbrugh in the County of Peebles	1969-12-06	1	\N	1384	5	8	\N	f	\N	2920	5	9
Hylton-Foster	of the City of Westminster	2002-10-31	1	\N	1530	5	8	\N	f	\N	2921	5	9
Kennedy of The Shaws	of Cathcart in the City of Glasgow	\N	\N	\N	2245	5	8	\N	f	\N	2922	5	12
Northover	of Cissbury in the County of West Sussex	\N	\N	Title = husband's surname	2378	5	8	\N	f	\N	2923	5	15
Rendell of Babergh	of Aldeburgh in the County of Suffolk	2015-05-02	1	\N	2240	5	8	\N	f	\N	2925	5	19
Wales	\N	1936-01-20	1	& E of Chester; cr D Windsor 1937	691	7	11	\N	t	\N	2887	5	24
Wales	\N	\N	\N	\N	1353	7	11	\N	t	\N	2888	5	24
Daventry	of Daventry in the County of Northampton	\N	\N	husband died 3 Mch 1943	1136	2	12	\N	f	\N	2929	5	5
Wolseley	of Wolseley in the County of Stafford	1936-12-24	2	SR to daughter	483	7	12	\N	f	2	2930	5	24
Mountbatten of Burma	of Romsey in the County of Southampton	\N	\N	SR to daus; cr E Mountbatten of Burma 18 Oct 1947	1212	2	12	\N	f	2	2931	5	14
Wharncliffe	in the West Riding of the County of York	\N	\N	SR to brother	416	7	6	\N	t	1	2933	5	24
Buckhurst	of Buckhurst in the County of Sussex	\N	\N	SR to younger branches of family; 2nd L succ 1873 as 7th E De La Warr	334	2	8	\N	f	3	2934	5	3
Jermyn	of Horningsherth in the County of Suffolk	\N	0	\N	2977	7	6	\N	f	\N	166	5	11
Stewart of Stewart's Court	and of Ballilawn in the County of Donegal	\N	\N	cr E Vane 1823; succ as 3rd M of Londonderry (I) 1822	79	2	8	\N	f	\N	59	5	20
Ravensworth	of Ravensworth Castle in the County Palatine of Durham and of Elsington in the County of Northumberland	\N	\N	2nd L cr E of Ravensworth 1874 (extinct on death of 3rd E 1904)	125	2	8	\N	f	\N	101	5	19
Rosebery	of Rosebery in the County of Edinburgh	\N	\N	2nd L cr E of Midlothian 1911	162	4	8	\N	f	\N	140	5	19
Portman	of Orchard Portman in the County of Somerset	\N	\N	cr V Portman 1873	225	2	8	\N	f	\N	189	5	17
Gough	of Chinkeangfoo in China and of Maharajpore and the Sutlej in the East Indies	\N	\N	cr V Gough 15 June 1849, introduced as such	273	2	8	\N	f	\N	232	5	8
Aveland	of Aveland in the County of Lincoln	1983-03-29	4	2nd L succ 1888 as 24th L Willoughby de Eresby & was cr E of Ancaster 1892	297	2	8	\N	f	\N	258	5	2
Grey de Radcliffe	in the County Palatine of Lancaster	1885-01-18	1	succ 1882 as 3rd E of Wilton	411	2	8	\N	f	\N	353	5	8
Mount-Temple	of Mount Temple in the County of Sligo	1888-10-17	1	\N	444	2	8	\N	f	\N	381	5	14
Bolsover	of Bolsover Castle in the County of Derby	1990-07-30	5	SR to sons of late husband; 2nd L = 6th D of Portland	431	2	8	\N	f	3	404	5	3
Cross	of Broughton-in-Furness in the County Palatine of Lancaster	2004-12-05	3	\N	500	2	12	\N	f	\N	432	5	4
Basing	of Basing Byflete and of Hoddington both in the County of Southampton	\N	\N	\N	511	2	8	\N	f	\N	446	5	3
Battersea	of Battersea in the County of London and Overstrand in the County of Norfolk	1907-11-27	1	\N	549	2	8	\N	f	\N	470	5	3
Rosmead	of Rosmead in the County of Westmeath and of Tafelberg in South Africa	1933-05-26	2	\N	579	2	8	\N	f	\N	504	5	19
Alverstone	of Alverstone in the Isle of Wight and County of Southampton	1915-12-15	1	cr V Alverstone 1913	611	2	8	\N	f	\N	533	5	2
Ritchie of Dundee	of Welders in the parish of Chalfont St Giles in the County of Buckingham	\N	\N	\N	645	2	8	\N	f	\N	563	5	19
Desart	of Desart in the County of Kilkenny	1934-11-04	1	\N	684	3	8	\N	f	\N	598	5	5
Allendale	of Allendale and Hexham in the County of Northumberland	\N	\N	\N	719	7	12	\N	f	\N	628	5	2
Rochdale	of Rochdale in the County Palatine of Lancaster	\N	\N	2nd L cr V Rochdale 1960	735	2	8	\N	f	\N	642	5	19
Buckmaster	of Cheddington in the County of Buckingham	\N	\N	cr V Buckmaster 1933	754	2	8	\N	f	\N	658	5	3
Beaverbrook	of Beaverbrook in the Province of New Brunswick in the Dominion of Canada and of Cherkley in the County of Surrey	\N	\N	\N	777	2	8	\N	f	\N	679	5	3
Farquhar	of Saint Marylebone in the County of London	1923-08-30	1	cr E Farquhar 1922	787	7	12	\N	f	\N	689	5	7
Ward of North Tyneside	of North Tyneside in the County of Tyne and Wear	1980-04-26	1	\N	1724	5	8	\N	f	\N	2927	5	24
Holmesdale	in the County of Kent	1993-03-04	5	\N	2978	7	12	\N	f	\N	128	5	9
Ednam	of Ednam in the County of Roxburgh	1833-03-06	1	\N	2979	7	12	\N	f	\N	2867	5	6
Emlyn	of Emlyn in the County of Carmarthen	\N	0	\N	2980	7	12	\N	f	\N	136	5	6
FitzClarence	\N	2000-12-30	7	\N	2981	2	12	\N	f	\N	167	5	7
Tewkesbury	\N	2000-12-30	7	\N	2982	2	8	\N	f	\N	167	5	21
Bath	in the County of Somerset	1808-07-14	1	\N	33	7	6	\N	t	\N	2928	5	3
Dalziel of Kirkcaldy	of Marylebone in the County of London	1935-07-15	1	\N	871	2	8	\N	f	\N	762	5	5
Hunsdon of Hunsdon	of Briggens in the County of Hertford	\N	\N	2nd L succ 1939 as 4th L Aldenham	900	2	8	\N	f	\N	786	5	9
Tredegar	of Tredegar in the County of Monmouth	1949-04-27	2	\N	927	7	12	\N	f	\N	810	5	21
Hailsham	of Hailsham in the County of Sussex	\N	\N	2nd V. disclaimed 1963 & died 12 Oct 2001	963	7	12	\N	f	\N	838	5	9
Macmillan	of Aberfeldy in the County of Perth	1952-09-05	1	vice V Sumner resigned	981	1	8	\N	f	\N	858	5	14
Amulree	of Strathbraan in the County of Perth	1983-12-15	2	\N	970	2	8	\N	f	\N	886	5	2
Marchwood	of Penang and of Marchwood in the County of Southampton	\N	\N	cr V Marchwood 13 Sep 1945	1072	2	8	\N	f	\N	933	5	14
Dawson of Penn	of Penn in the County of Buckingham	1945-03-07	1	\N	1057	7	12	\N	f	\N	961	5	5
Brabazon of Tara	of Sandwich in the County of Kent	\N	\N	\N	1131	2	8	\N	f	\N	991	5	3
Simonds	of Sparsholt in the County of Southampton	1971-06-28	1	vice L Romer resigned; cr hereditary L 24 Jne 1952, V 18 Oct 1954	1145	1	8	\N	f	\N	1002	5	20
Cunningham of Hyndhope	of Kirkhope in the County of Selkirk	1963-06-12	1	cr V Cunningham of Hyndhope 26 Jan 1946	1176	2	8	\N	f	\N	1029	5	4
du Parcq	of Grouville in the Island of Jersey	1949-04-27	1	du Parcq; vice L Goddard appointed LCJ	1198	1	8	\N	f	\N	1050	5	5
Milverton	of Lagos and of Clifton in the City of Bristol	\N	\N	\N	1232	2	8	\N	f	\N	1077	5	14
Clydesmuir	of Braidwood in the County of Lanark	\N	\N	Gazette announcement says "as on the 14th August, 1947"; ?th L died 2 Oct 1996	1239	2	8	\N	f	\N	1081	5	4
Robinson	of Kielder Forest in the County of Northumberland and of Adelaide in the Commonwealth of Australia	1952-09-05	1	\N	1230	2	8	\N	f	\N	1113	5	19
Alexander of Tunis	\N	\N	\N	\N	1284	7	6	\N	f	\N	1125	5	2
Freyberg	of Wellington New Zealand and of Munstead in the County of Surrey	\N	\N	2nd L died 26 May 1993	1272	2	8	\N	f	\N	1148	5	7
Monckton of Brenchley	of Brenchley in the County of Kent	\N	\N	\N	1340	2	12	\N	f	\N	1173	5	14
Ravensdale of Kedleston	of Kedleston in the County of Derby	1966-02-09	1	peeress in her own right	1368	6	8	\N	f	\N	1196	5	19
Slim	of Yarralumla in the Capital Territory of Australia and of Bishopston in the City and County of Bristol	\N	\N	\N	1394	2	12	\N	f	\N	1218	5	20
Francis-Williams	of Abinger in the County of Surrey	1970-06-05	1	\N	1427	5	8	\N	f	\N	1244	5	7
Burton of Coventry	of Coventry in the County of Warwick	1991-10-06	1	\N	1426	5	8	\N	f	\N	1273	5	3
Watkinson	of Woking in the County of Surrey	1995-12-19	1	\N	1465	2	12	\N	f	\N	1281	5	24
Wade	of Huddersfield in the West Riding of the County of York	1988-11-06	1	\N	1501	5	8	\N	f	\N	1308	5	24
Annan	of the Royal Burgh of Annan in the County of Dumfries	2000-02-21	1	\N	1528	5	8	\N	f	\N	1336	5	2
Evans of Hungershall	of the Borough of Royal Tunbridge Wells	1982-08-28	1	\N	1564	5	8	\N	f	\N	1364	5	6
Crowther	of Headingley in the West Riding of the County of York	1972-02-05	1	\N	1592	5	8	\N	f	\N	1387	5	4
Rhyl	of Holywell in the parish of Swanmore in the County of Southampton	1981-03-08	1	\N	1618	5	8	\N	f	\N	1412	5	19
Zuckerman	of Burnham Thorpe in the County of Norfolk	1993-04-01	1	\N	1645	5	8	\N	f	\N	1436	5	27
Tranmire	of Upsall in the County of North Yorkshire	1994-01-17	1	\N	1679	5	8	\N	f	\N	1463	5	21
Lyons of Brighton	of Brighton in the County of East Sussex	1978-01-18	1	\N	1723	5	8	\N	f	\N	1503	5	13
Brimelow	of Tyldesley in the County of Lancashire	1995-08-02	1	\N	1749	5	8	\N	f	\N	1529	5	3
Thomson of Monifieth	of Monifieth in the District of the City of Dundee	2008-10-03	1	\N	1774	5	8	\N	f	\N	1548	5	21
Raby	of Raby Castle in the County of Durham	1891-08-21	4	\N	2983	7	8	\N	f	\N	197	5	19
McFadzean of Kelvinside	of Kelvinside in the District of the City of Glasgow	1992-05-23	1	\N	1851	5	8	\N	f	\N	1650	5	14
Elliott of Morpeth	of Morpeth in the County of Northumberland and of the City of Newcastle upon Tyne	2011-05-20	1	\N	1936	5	8	\N	f	\N	1686	5	6
Fieldhouse	of Gosport in the County of Hampshire	1992-02-17	1	\N	2007	5	8	\N	f	\N	1744	5	7
Mackay of Ardbrecknish	of Tayvallich in the District of Argyll and Bute	2001-02-21	1	\N	2049	5	8	\N	f	\N	1773	5	14
Sterling of Plaistow	of Pall Mall in the City of Westminster	\N	\N	\N	2030	5	8	\N	f	\N	1802	5	20
Gilmour of Craigmillar	of Craigmillar in the District of the City of Edinburgh	2007-09-21	1	\N	2097	5	8	\N	f	\N	1823	5	8
Blaker	of Blackpool in the County of Lancashire and of Lindfield in the County of West Sussex	2009-07-05	1	\N	2130	5	8	\N	f	\N	1848	5	3
Currie of Marylebone	of Marylebone in the City of Westminster	\N	\N	\N	2163	5	8	\N	f	\N	1877	5	4
Molyneaux of Killead	of Killead in the County of Antrim	2015-03-09	1	\N	2194	5	8	\N	f	\N	1899	5	14
Hunt of Kings Heath	of Birmingham in the County of West Midlands	\N	\N	\N	2232	5	8	\N	f	\N	1935	5	9
Dearing	of Kingston upon Hull in the County of the East Riding of Yorkshire	2009-02-19	1	\N	2268	5	8	\N	f	\N	1967	5	5
Macdonald of Tradeston	of Tradeston in the City of Glasgow	\N	\N	appointed a Minister	2304	5	8	\N	f	\N	1996	5	14
Warwick of Undercliffe	of Undercliffe in the County of West Yorkshire	\N	\N	\N	2312	5	8	\N	f	\N	2026	5	24
Woolmer of Leeds	of Leeds in the County of West Yorkshire	\N	\N	\N	2347	5	8	\N	f	\N	2035	5	24
Armstrong-Jones	of Nymans in the County of West Sussex	2017-01-13	1	Cr 1st E of Snowdon 6 Oct 1961; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 3 p.m.	2357	6	8	\N	f	\N	2061	5	2
Hennessy	of Windlesham in the County of Surrey	2010-12-21	1	Succeeded as 3rd L Windlesham 1962; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 11 p.m.	2360	6	8	\N	f	\N	2098	5	9
Roberts of Llandudno	of Llandudno in the County of Gwynedd	\N	\N	\N	2479	5	8	\N	f	\N	2148	5	19
Chapman	of Leeds in the County of West Yorkshire	2009-09-03	1	\N	2492	5	8	\N	f	\N	2166	5	4
Hamilton of Epsom	of West Anstey in the County of Devon	\N	\N	\N	2519	5	8	\N	f	\N	2184	5	9
Stevens of Kirkwhelpington	of Kirkwhelpington in the County of Northumberland	\N	\N	\N	2507	5	8	\N	f	\N	2206	5	20
Mendelsohn	of Finchley in the London Borough of Barnet	\N	\N	\N	2755	5	8	\N	f	\N	2239	5	14
Carter of Barnes	of Barnes in the London Borough of Richmond upon Thames	\N	\N	\N	2605	5	8	\N	f	\N	2271	5	4
Campbell of Loughborough	of Loughborough in the County of Leicestershire	\N	\N	\N	2608	5	8	\N	f	\N	2291	5	4
Spicer	of Cropthorne in the County of Worcestershire	2019-05-29	1	\N	2655	5	8	\N	f	\N	2313	5	20
Beecham	of Benwell and Newcastle upon Tyne in the County of Tyne and Wear	\N	\N	\N	2674	5	8	\N	f	\N	2349	5	3
Collins of Highbury	of Highbury in the London Borough of Islington	\N	\N	\N	2717	5	8	\N	f	\N	2387	5	4
McIntosh of Pickering	of the Vale of York in the County of North Yorkshire	\N	\N	\N	2833	5	8	\N	f	\N	2416	5	14
Hailsham of Kettlethorpe	of Kettlethorpe in the County of Lincolnshire	\N	\N	\N	2840	6	8	\N	f	\N	2442	5	9
Fraser of Corriegarth	of Corriegarth in the County of Inverness	\N	\N	\N	2871	5	8	\N	f	\N	2465	5	7
Thomas of Cwmgiedd	of Cwmgiedd in the County of Powys	\N	\N	LCJ from 1 Oct 2013; as a judge, disqualified from sitting in the House of Lords!	2783	5	8	\N	f	\N	2481	5	21
Lambton	\N	\N	0	\N	2984	7	12	\N	f	\N	200	5	13
Leveson	of Stone in the County of Stafford	\N	0	\N	2985	7	8	\N	f	\N	174	5	13
Irving of Dartford	of Dartford in the County of Kent	1989-12-18	1	\N	1819	5	8	\N	f	\N	1585	5	10
Richardson of Duntisbourne	of Duntisbourne in the County of Gloucestershire	2010-01-22	1	\N	1895	5	8	\N	f	\N	2635	5	19
Shepherd of Spalding	of Spalding in the County of Lincolnshire	2001-04-05	1	Succeeded as 2nd L Shepherd 4 Dec 1954;  ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 p.m.	2359	6	8	\N	f	\N	2658	5	20
Harris	of Seringapatam and Mysore in the East Indies and of Belmont in the County of Kent	\N	\N	6th L died 17 Sep 1995; 7th L died 30 June 1996	92	2	8	\N	f	\N	2693	5	9
Jellicoe	of Scapa in the County of Orkney	\N	\N	cr E Jellicoe 1925 (no SR)\nNB SR not needed as son born 1918\n2nd V cr L Jellicoe of Southampton 1999 & died 22 Feb 2007	800	2	12	\N	f	2	2719	5	11
Woolf	of Barnes in the London Borough of Richmond	\N	\N	vice L Ackner resigned; appointed Master of the Rolls 1996; appointed LCJ 17 July 2000	2099	1	8	\N	f	\N	2732	5	24
Aldington	of Bispham in the County of the Borough of Blackpool	\N	\N	subsequently created L Low (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1423	2	8	\N	f	\N	2758	5	2
Roberthall	of Silverspur in the State of Queensland and Commonwealth of Australia and of Trenance in the County of Cornwall	1988-09-17	1	\N	1605	5	8	\N	f	\N	2808	5	19
Balfour	\N	\N	\N	SR to named brother & heirs male, then 2 named nephews & heirs male	882	2	6	\N	t	1	2883	5	3
Chisholm of Owlpen	of Owlpen in the County of Gloucestershire	\N	\N	\N	2792	5	8	\N	f	\N	2910	5	4
Smith of Gilmorehill	of Gilmorehill in the District of the City of Glasgow	\N	\N	\N	2134	5	8	\N	f	\N	2926	5	20
Portal of Hungerford	of Hungerford in the County of Berks	1990-09-29	2	created V Portal of Hungerford (usual remainder) 28 Jan 1946; special remainder in default of male issue to eldest dau Rosemary Ann Portal & heirs male & in default to every other dau by seniority	1177	2	8	\N	f	2	2932	5	17
Tipperary	\N	1904-03-17	2	\N	2935	2	6	\N	t	\N	26	5	21
Brecknock	\N	\N	0	\N	2936	7	6	\N	t	\N	51	5	3
Rocksavage	in the County Palatine of Chester	\N	0	\N	2937	7	6	\N	t	\N	80	5	19
Rawdon	\N	1868-11-01	4	\N	2938	7	6	\N	t	\N	121	5	19
Ormelie	\N	1862-11-08	2	\N	2939	7	6	\N	t	\N	207	5	16
Chester	\N	1901-01-22	1	\N	2940	7	6	\N	t	\N	246	5	4
Kent	\N	1900-07-30	1	\N	2941	2	6	\N	t	\N	2854	5	12
Ulster	\N	1900-07-30	1	\N	2942	2	6	\N	t	\N	2854	5	22
Chandos	\N	1889-03-26	3	\N	2943	7	9	\N	t	\N	2881	5	4
Temple of Stowe	in the County of Buckingham	\N	0	\N	2947	7	6	\N	f	\N	2881	5	21
Merton	of Trafalgar and of Merton in the County of Surrey	\N	0	\N	2945	7	12	\N	f	1	39	5	14
Uffington	in the County of Berks	\N	0	\N	2946	7	12	\N	f	\N	29	5	22
Macleod	of Castle Leod in the County of Cromartie	\N	0	\N	2948	2	8	\N	f	\N	2886	5	14
Marsham	of the Mote in the County of Kent	\N	0	\N	2949	7	12	\N	f	\N	32	5	14
Grey de Wilton	\N	\N	0	\N	2950	7	12	\N	f	\N	2885	5	8
Arklow	\N	1843-04-21	1	\N	2951	2	8	\N	f	\N	27	5	2
Culloden	\N	1904-03-17	2	\N	2952	2	8	\N	f	\N	26	5	4
Dunira	in the County of Perth	\N	0	\N	2953	2	8	\N	f	\N	15	5	5
Clive	of Ludlow in the County of Salop	\N	0	\N	2954	7	12	\N	f	\N	31	5	4
Herbert	of Chirbury in the County of Salop	\N	0	\N	2955	7	8	\N	f	\N	31	5	9
Powis	of Powis Castle in the County of Montgomery	\N	0	\N	2956	7	8	\N	f	\N	31	5	17
Soberton	of Soberton in the County of Southampton	\N	0	\N	2957	2	8	\N	f	\N	21	5	20
Howick	in the County of Northumberland	\N	0	\N	2958	7	12	\N	f	\N	42	5	9
Greenock	of Greenock in the County of Renfrew	\N	0	\N	2959	4	8	\N	f	\N	48	5	8
Douro	of Wellesley in the County of Somerset	\N	0	\N	2960	2	8	\N	f	\N	50	5	5
Lascelles	\N	\N	0	\N	2961	7	12	\N	f	\N	2871	5	13
Compton	of Compton in the County of Warwick	\N	0	\N	2962	7	6	\N	f	\N	81	5	4
Wilmington	of Wilmington in the County of Sussex	\N	0	\N	2963	7	8	\N	f	\N	81	5	24
Melgund	of Melgund in the County of Forfar	\N	0	\N	2964	7	12	\N	f	\N	75	5	14
Douro	\N	\N	0	\N	2965	7	9	\N	f	\N	2859	5	5
Grimston	\N	\N	0	\N	2966	7	12	\N	f	\N	78	5	8
Adbaston	of Adbaston in the County of Stafford	1825-05-12	1	\N	2967	7	8	\N	f	\N	72	5	2
Alford	\N	1921-03-17	3	\N	2968	7	12	\N	f	\N	84	5	2
Newport	in the County of Salop	\N	0	\N	2969	7	12	\N	f	\N	114	5	15
Elmley	in the County of Worcester	1979-01-03	8	\N	2970	7	12	\N	f	\N	85	5	6
Loudoun	\N	1868-11-01	4	\N	2971	7	12	\N	f	\N	121	5	13
Encombe	of Encombe in the County of Dorset	\N	0	\N	2972	7	12	\N	f	\N	115	5	6
Bruce	of Whorlton in the County of York	\N	0	\N	2973	7	6	\N	f	\N	119	5	3
Tarbat	of Tarbat in the County of Cromartie	\N	0	\N	2944	2	12	\N	f	\N	2886	5	21
Worsley	of Apuldurcombe in the Isle of Wight	\N	0	\N	2988	7	8	\N	f	\N	205	5	24
Coke	\N	\N	0	\N	2989	2	12	\N	f	\N	2873	5	4
Ockham	of Ockham in the County of Surrey	\N	0	\N	2990	7	12	\N	f	\N	203	5	16
Campden	of Campden in the County of Gloucester	\N	0	\N	2991	7	12	\N	f	\N	243	5	4
Southam	of Southam in the County of Gloucester	1871-12-22	1	\N	2992	7	12	\N	f	\N	242	5	20
Brackley	of Brackley in the County of Northampton	\N	0	\N	2993	2	12	\N	f	\N	286	5	3
Enfield	of Enfield in the County of Middlesex	\N	0	\N	2994	7	12	\N	f	\N	287	5	6
Crowhurst	of Crowhurst in the County of Surrey	\N	0	\N	2995	7	12	\N	f	\N	284	5	4
Dangan	in the County of Meath	\N	0	\N	2996	7	12	\N	f	\N	264	5	5
Ednam	of Ednam in the County of Roxburgh	\N	0	\N	2997	7	12	\N	f	\N	285	5	6
Inverness	\N	1843-04-21	1	\N	2999	2	6	\N	t	\N	27	5	10
Lewes	in the County of Sussex	\N	0	\N	3000	7	6	\N	t	\N	362	5	13
Clarence	\N	1919-03-28	2	\N	3001	2	6	\N	t	\N	2849	5	4
Ormelie	in the County of Caithness	1922-10-19	1	\N	3002	7	6	\N	t	\N	440	5	16
Ava	in the province of Burma	1988-05-29	5	\N	3003	7	6	\N	t	\N	477	5	2
Athlone	\N	1892-01-14	1	\N	3004	2	6	\N	t	\N	2852	5	2
Inverness	\N	1910-05-06	1	\N	3005	2	6	\N	t	\N	474	5	10
Ronaldshay	in the County of Orkney and Zetland	\N	0	\N	3006	7	6	\N	t	\N	478	5	19
Chester	\N	1910-05-06	1	\N	3007	7	6	\N	t	\N	2579	5	4
Eslington	of Eslington Park in the County of Northumberland	1904-02-07	3	\N	3008	7	8	\N	f	\N	361	5	6
Madeley	\N	1945-06-20	1	\N	3009	7	6	\N	t	\N	2880	5	14
Haddo	in the County of Aberdeen	\N	0	\N	3010	4	6	\N	t	\N	2712	5	9
Eltham	\N	1981-04-16	2	\N	3011	2	6	\N	t	\N	2779	5	6
Medina	\N	\N	0	\N	3012	2	6	\N	t	\N	759	5	14
Berkhampsted	\N	1960-02-23	1	\N	3013	2	6	\N	t	\N	720	5	3
Inverness	\N	1936-12-11	0	\N	3014	2	6	\N	t	\N	2862	5	10
Kedleston	in the County of Derby	1925-03-20	1	\N	3015	7	6	\N	t	\N	761	5	12
Ulster	\N	\N	0	\N	3016	2	6	\N	t	\N	2856	5	22
Macduff	in the County of Banff	1912-01-29	1	\N	3017	7	9	\N	t	\N	473	5	14
St Pierre	\N	1955-02-21	3	\N	3018	7	12	\N	f	2	560	5	20
Traprain	of Whittingehame in the County of Haddington	\N	0	\N	3021	2	12	\N	f	1	2883	5	21
Macduff	in the County of Banff	\N	0	\N	3022	8	6	\N	t	2	2882	5	14
Baring	of Lee in the County of Kent	1929-04-12	2	\N	3023	7	12	\N	f	\N	399	5	3
Hughenden	of Hughenden in the County of Buckingham	1881-04-19	1	\N	3024	2	12	\N	f	\N	2864	5	9
Garmoyle	in the County of Antrim	\N	0	\N	3025	7	12	\N	f	\N	370	5	8
Throwley	in the County of Kent	\N	0	\N	3026	7	12	\N	f	\N	376	5	21
Arklow	\N	1919-03-28	2	\N	3027	2	8	\N	f	\N	2849	5	2
Wolmer	of Blackmoor in the County of Southampton	\N	0	\N	3028	7	12	\N	f	\N	401	5	24
Saint Cyres	of Newton Saint Cyres in the County of Devon	\N	0	\N	3029	2	12	\N	f	\N	438	5	20
Raincliffe	of Raincliffe in the North Riding of the County of York	1937-04-17	4	\N	3030	7	12	\N	f	\N	439	5	19
Killarney	\N	1910-05-06	1	\N	3031	2	8	\N	f	\N	474	5	12
Medway	\N	\N	0	\N	3032	7	8	\N	f	\N	476	5	14
Salford	in the County Palatine of Lancaster	1909-03-16	1	\N	3033	7	12	\N	f	\N	507	5	20
Errington	of Hexham in the County of Northumberland	\N	0	\N	3035	7	12	\N	f	\N	556	5	6
Windsor	of Saint Fagans in the County of Glamorgan	\N	0	\N	3036	7	12	\N	f	\N	557	5	24
Hawkesbury	of Kirkham in the County of York and of Mansfield in the County of Nottingham	\N	0	\N	3037	7	12	\N	f	\N	2874	5	9
Mentmore	of Mentmore in the County of Buckingham	\N	0	\N	3038	7	12	\N	f	\N	2777	5	14
Epsom	of Epsom in the County of Surrey	\N	0	\N	3039	7	8	\N	f	\N	2777	5	6
Hythe	of Hythe in the County of Kent	1919-11-12	2	\N	3040	7	12	\N	f	\N	627	5	9
Douglas of Baads	in the County of Midlothian	\N	0	\N	3041	2	8	\N	f	\N	629	5	5
Quenington	of Quenington in the County of Gloucester	\N	0	\N	3042	7	12	\N	f	\N	2570	5	18
Nuneham	of Nuneham Courtenay in the County of Oxford	1979-01-03	2	\N	3043	2	8	\N	f	\N	680	5	15
Northallerton	in the County of York	1981-04-16	2	\N	3044	2	12	\N	f	\N	2779	5	15
Trematon	in the County of Cambridge	1957-01-16	1	\N	3045	2	12	\N	f	\N	757	5	21
Alderney	in the County of Southampton	\N	0	\N	3046	2	12	\N	f	\N	759	5	2
Borodale	of Wexford in the County of Wexford	\N	0	\N	3048	2	12	\N	f	\N	731	5	3
Beatty	of the North Sea and of Brooksby in the County of Leicester	\N	0	\N	3049	2	8	\N	f	\N	731	5	3
Dawick	\N	\N	0	\N	3050	2	12	\N	f	\N	770	5	5
Haig	of Bemersyde in the County of Berwick	\N	0	\N	3051	2	8	\N	f	\N	770	5	9
Dunsford	of Dunsford in the County of Surrey	1979-11-02	2	\N	3052	7	12	\N	f	\N	758	5	5
Killarney	\N	1936-12-11	0	\N	3053	2	8	\N	f	\N	2862	5	12
Furneaux	of Charlton in the County of Northampton	1985-02-18	3	\N	3054	7	12	\N	f	\N	800	5	7
Asquith	of Morley in the West Riding of the County of York	\N	0	\N	3055	2	12	\N	f	\N	840	5	2
Brocas	of Southampton in the County of Southampton	\N	0	\N	3056	7	12	\N	f	\N	2837	5	3
Culloden	\N	\N	0	\N	3057	2	8	\N	f	\N	2856	5	4
Glandine	\N	\N	\N	\N	3176	7	12	\N	f	3	2980	3	8
Fitzgerald and Vesey	\N	\N	\N	\N	3177	2	8	\N	f	\N	2981	3	7
Sandon	of Sandon in the County of Stafford	\N	0	\N	3060	7	12	\N	f	\N	73	5	20
Sussex	\N	1943-04-26	2	\N	3061	2	6	\N	t	\N	2853	5	20
Scarsdale	of Scarsdale in the County of Derby	\N	0	SR to his father & heirs male of his body	3062	3	12	\N	f	1	2718	5	20
Romsey	of Romsey in the County of Southampton	\N	0	\N	3063	7	8	\N	f	2	1118	5	19
Normanby	of Normanby in the County of York	\N	0	\N	3065	7	12	\N	f	\N	76	5	15
Eastnor	of Eastnor Castle in the County of Hereford	1883-09-26	3	\N	3066	7	12	\N	f	\N	90	5	6
Eden	of Norwood in the County of Surrey	1849-01-01	1	\N	3067	7	8	\N	f	\N	240	5	6
Tiverton	of Tiverton in the County of Devon	\N	0	\N	3069	7	12	\N	f	\N	521	5	21
Launceston	in the County of Cornwall	1960-02-23	1	\N	3070	2	12	\N	f	\N	720	5	13
Clanfield	of Clanfield in the County of Southampton	\N	0	\N	3071	7	12	\N	f	\N	847	5	4
Ravensdale	of Ravensdale in the County of Derby	\N	0	SR to his daughters & heirs male of their bodies	3072	3	8	\N	f	2	2718	5	19
Boringdon	of North Molton in the County of Devon	\N	0	\N	3073	7	12	\N	f	\N	117	5	3
Cavendish	of Keighley in the County of York	\N	0	\N	3074	2	8	\N	f	\N	2865	5	4
Noel	of Ridlington in the County of Rutland	\N	0	\N	3075	7	8	\N	f	\N	243	5	15
Clandeboye	of Clandeboye in the County of Down	1988-05-29	5	\N	3076	7	12	\N	f	\N	2868	5	4
Knebworth	of Knebworth in the County of Hertford	\N	0	\N	3077	7	12	\N	f	\N	398	5	12
Wendover	of Chepping Wycombe in the County of Buckingham	1928-06-13	1	\N	3078	7	12	\N	f	\N	492	5	24
Elveden	of Elveden in the County of Suffolk	\N	0	\N	3079	7	12	\N	f	\N	2872	5	6
Ratendone	of Willingdon in the County of Sussex	1979-03-19	2	\N	3080	7	12	\N	f	\N	2879	5	19
Downpatrick	\N	\N	0	\N	3081	2	8	\N	f	\N	2857	5	5
Corvedale	of Corvedale in the County of Salop	\N	0	\N	3082	2	12	\N	f	\N	931	5	4
Ruthven of Canberra	of Dirleton in the County of East Lothian	\N	0	\N	3083	7	12	\N	f	\N	2870	5	19
Gwynedd	of Dwyfor in the County of Caernarvon	\N	0	\N	3084	2	12	\N	f	\N	1007	5	8
Greenwich	of Greenwich in the County of London	\N	0	\N	3086	2	8	\N	f	\N	2855	5	8
Stevenage	of Stevenage in the County of Hertford	1957-08-16	1	\N	3087	7	12	\N	f	\N	1117	5	20
Rideau	of Ottawa and of Castle Derg in the County of Tyrone	\N	3	\N	3088	7	8	\N	f	\N	1125	5	19
Masham	of Ellington in the County of York	\N	0	\N	3089	7	8	\N	f	\N	2876	5	14
Prestwood	of Walthamstow in the County of Essex	\N	0	\N	3090	2	12	\N	f	\N	1159	5	17
Warbleton	of Warbleton in the County of Sussex	\N	0	\N	3091	7	12	\N	f	\N	1194	5	24
Eden	of Royal Leamington Spa in the County of Warwick	1985-08-17	2	\N	3092	2	12	\N	f	\N	2863	5	6
Linley	of Nymans in the County of Sussex	\N	0	\N	3093	2	12	\N	f	\N	2778	5	13
Fyfe of Dornoch	of Dornoch in the County of Sutherland	1967-01-27	1	\N	3094	7	8	\N	f	\N	1272	5	7
Weston-super-Mare	of Weston-super-Mare in the County of Somerset	1965-01-11	1	\N	3095	7	8	\N	f	\N	1259	5	24
Macmillan of Ovenden	of Chelwood Gate in the County of East Sussex and Stockton-on-Tees in the County of Cleveland	\N	0	\N	3096	2	12	\N	f	\N	1709	5	14
Killyleagh	\N	\N	0	\N	3097	2	8	\N	f	\N	2861	5	12
Severn	\N	\N	0	\N	3098	2	12	\N	f	\N	2878	5	20
Carrickfergus	\N	\N	\N	\N	3099	2	8	\N	f	\N	2851	5	4
Kilkeel	\N	\N	\N	\N	3100	2	8	\N	f	\N	2858	5	12
Kinrara	in the County of Inverness	\N	0	\N	3101	4	6	\N	t	\N	358	5	12
St Andrews	\N	\N	0	\N	3102	2	6	\N	t	\N	2857	5	20
Merioneth	\N	\N	0	\N	3103	2	6	\N	t	\N	2855	5	14
Chester	\N	\N	0	\N	3104	7	6	\N	t	\N	2888	5	4
Inverness	\N	\N	0	\N	3105	2	6	\N	t	\N	2861	5	10
Strathearn	\N	\N	\N	\N	3106	2	6	\N	t	\N	2851	5	20
Dumbarton	\N	\N	\N	\N	3107	2	6	\N	t	\N	2858	5	5
Castlehaven	of Castlehaven in the County of Cromartie	\N	0	\N	3064	2	8	\N	f	\N	2886	5	4
Combermere	of Bhurtpore in the East Indies and of Combermere in the County Palatine of Chester	\N	\N	\N	148	7	12	\N	f	\N	129	5	4
Stratheden	of Cupar in the County of Fife	\N	\N	SR to h m by her husband (cr L Campbell 1841)	222	2	8	\N	f	3	210	5	20
Acheson	of Clancairney in the County of Armagh	\N	\N	succ 1849 as 3rd E of Gosford (I) & 2nd L Worlingham	277	2	8	\N	f	\N	233	5	2
Churston	of Churston Ferrers and Lupton in the County of Devon	\N	\N	4th L died 9 April 1991	310	2	8	\N	f	\N	272	5	4
Northbrook	of Stratton in the County of Southampton	\N	\N	2nd L cr E of Northbrook 1876, ext(2) 1929; 5th L died 4 Dec 1990	336	2	8	\N	f	\N	294	5	15
Hamilton of Dalzell	in the County of Lanark	\N	\N	3rd L died 31 Jan 1990	497	2	8	\N	f	\N	429	5	9
Davey	of Fernhurst in the County of Sussex	1907-02-20	1	vice L Russell of Killowen resigned	560	1	8	\N	f	\N	490	5	5
Allendale	of Allendale and Hexham in the County of Northumberland	\N	\N	2nd L cr V Allendale 1911	668	2	8	\N	f	\N	584	5	2
Cranley	of Cranley in the County of Surrey	\N	0	\N	3059	7	12	\N	f	\N	30	5	4
St Davids	of Lydstep Haven in the County of Pembroke	\N	\N	2nd V died 10 June 1991	808	7	12	\N	f	\N	732	5	20
Bradbury	of Winsford in the County of Chester	\N	\N	2nd L died 31 March 1994	914	2	8	\N	f	\N	799	5	3
Ponsonby of Shulbrede	of Shulbrede in the County of Sussex	\N	\N	3rd L died 13 June 1990	976	2	8	\N	f	\N	850	5	17
Portal	of Laverstoke in the County of Southampton	1949-05-06	1	cr V Portal 1 Feb 1945	1031	2	8	\N	f	\N	900	5	17
Strathmore and Kinghorne	\N	\N	\N	\N	1065	8	6	\N	t	\N	958	5	20
Killearn	of Killearn in the County of Stirling	\N	\N	2nd L died 27 July 1996	1137	2	8	\N	f	\N	995	5	12
Hodson	of Rotherfield Greys in the County of Oxford	1984-03-11	1	vice L Cohen resigned	1399	1	8	\N	f	\N	1224	5	9
Egremont	of Petworth in the County of Sussex	\N	\N	succ as 6th L Leconfield 1967	1451	2	8	\N	f	\N	1304	5	6
Wells-Pestell	of Combs in the County of Suffolk	1991-01-17	1	\N	1514	5	8	\N	f	\N	1323	5	24
Llewelyn-Davies of Hastoe	of Hastoe in the County of Hertford	1997-11-06	1	\N	1566	5	8	\N	f	\N	1393	5	13
Hailsham of Saint Marylebone	of Herstmonceux in the County of Sussex	2001-10-12	1	had disclaimed viscounty 1963	1612	5	8	\N	f	\N	1407	5	9
Crowther-Hunt	of Eccleshill in the West Riding of the County of York	1987-02-16	1	\N	1666	5	8	\N	f	\N	1453	5	4
Elwyn-Jones	of Llanelli in the County of Carmarthen and of Newham in Greater London	1989-12-04	1	\N	1671	5	8	\N	f	\N	1497	5	6
Godber of Willington	of Willington in the County of Bedfordshire	1980-08-25	1	\N	1823	5	8	\N	f	\N	1588	5	8
Ross of Marnock	of Kilmarnock in the District of Kilmarnock and Loudoun	1988-06-10	1	\N	1829	5	8	\N	f	\N	1597	5	19
McAlpine of West Green	of West Green in the County of Hampshire	2014-01-17	1	resigned from House of Lords 2010 under Constitutional Reform and Governance Act 2010	1925	5	8	\N	f	\N	1678	5	14
Soulsby of Swaffham Prior	of Swaffham Prior in the County of Cambridgeshire	2017-05-08	1	\N	2018	5	8	\N	f	\N	1755	5	20
Nicholls of Birkenhead	of Stoke D'Abernon in the County of Surrey	2019-09-25	1	vice L Templeman resigned	2125	1	8	\N	f	\N	1845	5	15
Burlison	of Rowlands Gill in the County of Tyne and Wear	2008-05-20	1	\N	2235	5	8	\N	f	\N	1938	5	3
Thomas of Macclesfield	of Prestbury in the County of Cheshire	2018-07-01	1	\N	2260	5	8	\N	f	\N	1959	5	21
Grender	of Kingston upon Thames in the London Borough of Kingston upon Thames	\N	\N	\N	2754	5	8	\N	f	\N	2251	5	8
Knight of Weymouth	of Weymouth in the County of Dorset	\N	\N	\N	2639	5	8	\N	f	\N	2304	5	12
Hollins	of Wimbledon in the London Borough of Merton and of Grenoside in the County of South Yorkshire	\N	\N	\N	2682	5	8	\N	f	\N	2374	5	9
Lennie	of Longsands Tynemouth in the County of Tyne and Wear	\N	\N	\N	2800	5	8	\N	f	\N	2440	5	13
Osamor	of Tottenham in the London Borough of Haringey and of Asaba in the Republic of Nigeria	\N	\N	\N	2910	5	8	\N	f	\N	2541	5	16
Brougham and Vaux	of Brougham in the County of Westmorland and of Highhead Castle in the County of Cumberland	\N	\N	SR to brother	324	8	8	\N	f	1	2580	5	3
Shepherd	of Spalding in the County of Lincoln	\N	\N	2nd L. created L Shepherd of Spalding (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999, and died 5 Apr 2001	1208	2	8	\N	f	\N	2596	5	20
Merlyn-Rees	of Morley and South Leeds in the County of West Yorkshire and of Cilfynydd in the County of Mid Glamorgan	2006-01-05	1	surname changed from "Rees" after announcement	2073	5	8	\N	f	\N	2642	5	14
Seaford	of Seaford in the County of Sussex	\N	\N	2nd L was already 6th L Howard de Walden; title separated again on death of 9th L Howard de Walden & 5th L Seaford on 9 July 1999.	146	2	8	\N	f	\N	2737	5	20
Bowes	of Streatlam Castle in the County of Durham and of Lunedale in the County of York	1820-07-03	1	\N	84	4	8	\N	f	\N	63	5	3
Hastings	\N	1868-11-01	4	Old title also 1st L Rawdon (cr 1783) & 14th L Hastings (succ 1808)	106	7	9	\N	t	\N	121	5	9
Durham	of the City of Durham and of Lambton Castle in the County Palatine of Durham	\N	\N	cr E of Durham 1833	164	2	8	\N	f	\N	142	5	5
Duncannon	of Bessborough in the County of Kilkenny	\N	\N	succ 1844 as 4th E of Bessborough (I) & 4th L Ponsonby	211	2	8	\N	f	\N	177	5	5
Leconfield	of Leconfield in the East Riding of the County of York	\N	\N	6th L (succ 1967) had been cr L Egremont 1963	314	2	8	\N	f	\N	275	5	13
Robartes	of Lanhydrock and of Truro in the County of Cornwall	1974-12-22	6	2nd L succ as 6th V Clifden (I) & 2nd L Mendip	372	2	8	\N	f	\N	323	5	19
Feversham	of Ryedale in the North Riding of the County of York	1963-09-04	3	\N	360	7	6	\N	t	\N	360	5	7
Wolseley	of Cairo and of Wolseley in the County of Stafford	1913-03-25	1	cr V Wolseley (SR) 1885	458	2	8	\N	f	\N	393	5	24
Ancaster	in the County of Lincoln	1983-03-29	3	\N	540	7	6	\N	t	\N	475	5	2
Egerton	of Tatton in the County Palatine of Chester	1909-03-16	1	\N	582	7	6	\N	f	\N	507	5	6
Shaughnessy	of the City of Montreal in the Dominion of Canada and of Ashford in the County of Limerick	\N	\N	\N	761	2	8	\N	f	\N	665	5	20
Burnham	of Hall Barn in the County of Buckingham	1933-07-20	1	\N	829	7	12	\N	f	\N	710	5	3
Seaforth	of Brahan in Urray, in the County of Ross and Cromarty	1923-03-03	1	\N	862	2	8	\N	f	\N	749	5	20
Cornwallis	of Linton in the County of Kent	\N	\N	\N	933	2	8	\N	f	\N	815	5	4
Ganzoni	of Ipswich in the County of Suffolk	2005-12-03	1	Succeeded as 2nd L Belstead 15 Aug 1958; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 9 a.m.	2362	6	8	\N	f	\N	2848	5	8
Asquith of Yarnbury	of Yarnbury in the County of Wilts	1969-02-19	1	dau of 1st E of Oxford & Asquith	1497	5	8	\N	f	\N	2896	5	2
Craven	in the County of York	\N	\N	8th E died 30 Aug 1990	11	7	6	\N	t	\N	29	5	4
Nelson	of Trafalgar and of Merton in the County of Surrey	\N	\N	SR to heirs male of the bodies of Susanna wife of Thomas Bolton Esquire and of Catharine wife of George Matcham Esquire (both sisters of late Horatio Viscount Nelson)	38	7	6	\N	f	1	39	5	15
Rhondda	of Llanwern in the County of Monmouth	1958-07-20	2	SR to only daughter & her heirs male	809	7	12	\N	f	2	721	5	19
St Just	of St Just in Penwith in the County of Cornwall	1984-10-14	2	St. Just	1039	2	8	\N	f	\N	907	5	20
Rawlinson of Ewell	of Ewell in the County of Surrey	2006-06-28	1	\N	1787	5	8	\N	f	\N	1560	5	19
Hunt of Tanworth	of Stratford-upon-Avon in the County of Warwickshire	2008-07-17	1	\N	1842	5	8	\N	f	\N	1605	5	9
Mitford	of Redesdale in the County of Northumberland	\N	\N	Succeeded as 6th L Redesdale 1991; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2373	6	8	\N	f	\N	2040	5	14
Brownlow of Shurlock Row	of Shurlock Row in the Royal County of Berkshire	\N	\N	\N	2918	5	8	\N	f	\N	2516	5	3
Windlesham	of Windlesham in the County of Surrey	\N	\N	3rd L. created L Hennessy (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1059	2	8	\N	f	\N	2589	5	24
Bottesford	of Bottesford in the County of Leicester	1941-02-26	6	\N	2986	2	8	\N	f	\N	181	5	3
Helmsley	of Helmsley in the North Riding of the County of York	1963-09-04	3	\N	2998	7	12	\N	f	\N	360	5	9
Denton	of Denton in the County of Kent	2011-12-16	3	\N	3020	7	8	\N	f	2	2783	5	5
Wensleydale	of Blagdon and Blyth, both in the County of Northumberland	\N	0	\N	3034	2	8	\N	f	\N	535	5	24
Glenapp	of Strathnaver in the County of Sutherland	\N	0	\N	3058	7	12	\N	f	\N	839	5	8
Amberley	of Amberley in the County of Gloucester and of Ardsalla in the County of Meath	\N	0	\N	3068	2	12	\N	f	\N	282	5	2
Keren	of Eritrea and of Winchester in the County of Southampton	1953-12-24	2	\N	3085	7	12	\N	f	\N	1044	5	12
Carlton	of Carlton in the West Riding of the County of York	\N	0	\N	3108	7	12	\N	f	1	2933	5	4
Gowrie	of Canberra in the Commonwealth of Australia and of Dirleton in the County of East Lothian	\N	\N	cr E of Gowrie 8 Jan 1945	1045	2	8	\N	f	\N	914	5	8
Runciman of Doxford	of Doxford in the County of Northumberland	\N	\N	succ as 2nd L Runciman 13 Aug 1937	1074	2	12	\N	f	\N	935	5	19
Ramsden	of Birkenshaw in the West Riding of the County of York	1955-08-09	1	\N	1164	2	8	\N	f	\N	1017	5	19
Uthwatt	of Lathbury in the County of Buckingham	1949-04-24	1	vice L Russell of Killowen resigned	1189	1	8	\N	f	\N	1041	5	22
Macpherson of Drumochter	of Great Warley in the County of Essex	\N	\N	\N	1267	2	8	\N	f	\N	1107	5	14
Turnour	of Shillinglee in the County of Sussex	1962-08-26	1	\N	1283	3	8	\N	f	\N	1123	5	21
Denning	of Whitchurch in the County of Southampton	1999-03-05	1	vice L Oaksey resigned	1343	1	8	\N	f	\N	1176	5	5
Summerskill	of Ken Wood in the County of London	1980-02-04	1	surname also given as Samuel	1405	5	8	\N	f	\N	1275	5	20
Campbell of Eskan	of Camis Eskan in the County of Dumbarton	1994-12-26	1	\N	1531	5	8	\N	f	\N	1338	5	4
Bradwell	of Bradwell juxta Mare in the County of Essex	1976-08-12	1	\N	1741	5	8	\N	f	\N	1522	5	3
Dacre of Glanton	of Glanton in the County of Northumberland	2003-01-26	1	\N	1836	5	8	\N	f	\N	1601	5	5
Oppenheim-Barnes	of Gloucester in the County of Gloucestershire	\N	\N	\N	2002	5	8	\N	f	\N	1748	5	16
Younger of Prestwick	of Ayr in the District of Kyle and Carrick	2003-01-26	1	succeeded 25 June 1997 as 4th V Younger of Leckie	2077	5	8	\N	f	\N	1805	5	26
Emerton	of Tunbridge Wells in the County of Kent and of Clerkenwell in the London Borough of Islington	\N	\N	\N	2178	5	8	\N	f	\N	1901	5	6
Harris of Haringey	of Hornsey in the London Borough of Haringey	\N	\N	\N	2301	5	8	\N	f	\N	1994	5	9
Gueterbock	of Cranford in the London Borough of Hilllingdon	\N	\N	Succeeded as 18th L Berkeley 1992; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999.	2374	6	8	\N	f	\N	2041	5	8
Carington of Upton	of Upton in the County of Nottinghamshire	2018-07-09	1	Succeeded as 6th L Carrington1938; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 3 p.m.	2364	6	8	\N	f	\N	2064	5	4
Wall of New Barnet	of New Barnet in the London Borough of Barnet	2017-01-25	1	\N	2473	5	8	\N	f	\N	2176	5	24
Shephard of Northwold	of Northwold in the County of Norfolk	\N	\N	\N	2523	5	8	\N	f	\N	2214	5	20
Nash	of Ewelme in the County of Oxfordshire	\N	\N	appointed as a minister	2748	5	8	\N	f	\N	2234	5	15
Kinnock of Holyhead	of Holyhead in the County of Ynys Môn	\N	\N	wife of Lord Kinnock	2614	5	8	\N	f	\N	2295	5	12
Boateng	of Akyem in the Republic of Ghana and of Wembley in the London Borough of Brent	\N	\N	\N	2648	5	8	\N	f	\N	2308	5	3
Faulks	of Donnington in the Royal County of Berkshire	\N	\N	\N	2675	5	8	\N	f	\N	2350	5	7
Palmer of Childs Hill	of Childs Hill in the London Borough of Barnet	\N	\N	\N	2711	5	8	\N	f	\N	2384	5	17
Barker of Battle	of Battle in the County of East Sussex	\N	\N	\N	2841	5	8	\N	f	\N	2443	5	3
Finkelstein	of Pinner in the County of Middlesex	\N	\N	\N	2763	5	8	\N	f	\N	2469	5	7
Llewellyn of Steep	of Steep in the County of Hampshire	\N	\N	\N	2883	5	8	\N	f	\N	2521	5	13
Jellicoe of Southampton	of Southampton in the County of Hampshire	2007-02-22	1	Succeeded as 2nd E Jellicoe 20 Nov 1935; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 a.m.	2361	6	8	\N	f	\N	2659	5	11
Pakenham	of Cowley in the City of Oxford	\N	\N	succ 4 Feb 1961 as L Silchester & E Longford (I); subsequently created L Pakenham of Cowley (life peer) 16 Nov 1999, having ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999	1180	2	8	\N	f	\N	2768	5	17
Clandeboye	of Clandeboye in the County of Down	1988-05-29	5	cr E of Dufferin 1871, M of Dufferin and Ava 1888	285	3	8	\N	f	\N	2798	5	4
Camperdown	of Lundie in the County of Forfar and of Gleneagles in the County of Perth	1933-12-05	4	\N	193	7	6	\N	t	\N	2866	5	4
Park of Monmouth	of Broadway in the County of Hereford and Worcester	2010-03-24	1	\N	2008	5	8	\N	f	\N	2924	5	17
Roberts	of Kandahar in Afghanistan and Pretoria in the Transvaal Colony, and of the City of Waterford	1955-02-21	3	SR to daus	615	7	6	\N	f	2	560	5	19
Meston	of Agra in the Indian Empire and Dunottar in the County of Kincardine	\N	\N	\N	848	2	8	\N	f	\N	739	5	14
Strathspey	of Strathspey in the Counties of Inverness and Moray	\N	\N	title separated from E of Seafield 1915	462	4	8	\N	f	\N	2555	5	20
Moreton	of Tortworth in the County of Gloucester	\N	0	\N	2987	7	8	\N	f	\N	199	5	14
Broome	of Broome in the County of Kent	2011-12-16	3	\N	3019	7	12	\N	f	2	2783	5	3
Erleigh	of Erleigh in the County of Berks	\N	0	\N	3047	7	12	\N	f	\N	2875	5	6
Breadalbane	of Taymouth Castle in the County of Perth	1862-11-08	2	cr M of Breadalbane 12 Sep 1831	53	4	8	\N	f	\N	44	5	3
Butler of Mount Juliet	in the County of Kilkenny	\N	\N	3rd L died 5 Oct 1992	728	3	8	\N	f	\N	634	5	3
MacLehose of Beoch	of Maybole in the District of Kyle and Carrick and of Victoria in Hong Kong	2000-05-27	1	MacLehose of Beoch	1879	5	8	\N	f	\N	1638	5	14
Gascoyne-Cecil	of Essendon in the County of Rutland	\N	\N	Son & heir of 6th M. of Salisbury; summoned in father's barony of Cecil 29.4.92; known as V. Cranborne; ceased to be a member of the House of Lords on enactment of House of Lords Act 1999 on 11.11.99; patent sealed 12 noon; succeeded father 11.7.03	2363	6	8	\N	f	\N	2099	5	8
Pakenham of Cowley	of Cowley in the County of Oxfordshire	2001-08-03	1	Cr 1st L Pakenham 25 Sep 1945; ceased to be a member of the House of Lords on the enactment of the House of Lords Act 1999 on 11 Nov 1999\nLetters patent sealed 6 p.m.\n(had also succeeded as 7th E of Longford (I) and L Silchester 1961)	2358	6	8	\N	f	\N	2821	5	17
Bindon	\N	\N	\N	\N	3109	2	6	\N	f	\N	2935	1	3
Chesterford	\N	\N	\N	\N	3110	2	8	\N	f	\N	2935	1	4
Cholmondeley	\N	\N	\N	\N	3111	7	6	\N	f	1	2936	1	4
Malpas	\N	\N	\N	\N	3112	7	12	\N	f	1	2936	1	14
Godolphin	\N	\N	\N	\N	3113	7	6	\N	f	\N	2937	1	8
Rialton	\N	\N	\N	\N	3114	7	12	\N	f	\N	2937	1	19
Poulett	\N	\N	\N	\N	3115	7	6	\N	f	\N	2938	1	17
Hinton	\N	\N	\N	\N	3116	7	12	\N	f	\N	2938	1	9
Wharton	\N	\N	\N	\N	3117	7	6	\N	f	\N	2939	1	24
Winchendon	\N	\N	\N	\N	3118	7	12	\N	f	\N	2939	1	24
Dorchester	\N	\N	\N	\N	3119	7	9	\N	f	1	2940	1	5
Lindsey	\N	\N	\N	\N	3120	7	9	\N	f	3	2941	1	13
Pelham	\N	\N	\N	\N	3121	2	8	\N	f	\N	2942	1	17
Cowper	\N	\N	\N	\N	3122	2	8	\N	f	\N	2943	1	4
Malmesbury	\N	\N	\N	\N	3123	7	6	\N	f	\N	2944	4	14
Fitzharris	\N	\N	\N	\N	3124	7	12	\N	f	\N	2944	4	7
Cadogan	\N	\N	\N	\N	3125	7	6	\N	f	\N	2945	4	4
Chelsea	\N	\N	\N	\N	3126	7	12	\N	f	\N	2945	4	4
Bridport	\N	\N	\N	\N	3127	7	12	\N	f	\N	2946	4	3
Fitzgibbon	\N	\N	\N	\N	3128	3	8	\N	f	\N	2947	4	7
Eldon	\N	\N	\N	\N	3129	2	8	\N	f	\N	2948	4	6
Curzon of Kedleston	\N	\N	\N	\N	3130	2	8	\N	f	\N	2949	3	4
Rathdonnell	\N	\N	\N	\N	3131	2	8	\N	f	1	2950	3	19
Abercorn	\N	\N	\N	\N	3132	7	4	\N	f	\N	2951	3	2
Hamilton	\N	\N	\N	\N	3133	7	9	\N	f	\N	2951	3	9
Athlumney	\N	\N	\N	\N	3134	2	8	\N	f	\N	2952	3	2
Fermoy	\N	\N	\N	\N	3135	2	8	\N	f	\N	2953	3	7
Clermont	\N	\N	\N	\N	3136	2	8	\N	f	1	2954	3	4
Bellew	\N	\N	\N	\N	3137	2	8	\N	f	\N	2955	3	3
Kent	\N	\N	\N	\N	3138	7	9	\N	f	\N	2956	1	12
Harold	\N	\N	\N	\N	3139	7	6	\N	f	\N	2956	1	9
Goderich	\N	\N	\N	\N	3140	7	12	\N	f	\N	2956	1	8
Cambridge	\N	\N	\N	\N	3141	2	4	\N	f	\N	2957	1	4
Cambridge	\N	\N	\N	\N	3142	2	9	\N	f	\N	2957	1	4
Milford Haven	\N	\N	\N	\N	3143	2	6	\N	f	\N	2957	1	14
Northallerton	\N	\N	\N	\N	3144	2	12	\N	f	\N	2957	1	15
Tewkesbury	\N	\N	\N	\N	3145	2	8	\N	f	\N	2957	1	21
Greenwich	\N	\N	\N	\N	3146	4	6	\N	f	\N	2958	1	8
Chatham	\N	\N	\N	\N	3147	4	8	\N	f	\N	2958	1	4
Montagu	\N	\N	\N	\N	3148	7	4	\N	f	\N	2959	1	14
Monthermer	\N	\N	\N	\N	3149	7	9	\N	f	\N	2959	1	14
Rutland	\N	\N	\N	\N	3150	7	4	\N	f	\N	2960	1	19
Granby	\N	\N	\N	\N	3151	7	9	\N	f	\N	2960	1	8
Buckingham and Normanby	\N	\N	\N	\N	3152	7	4	\N	f	\N	2961	1	3
Hervey	\N	\N	\N	\N	3153	2	8	\N	f	\N	2962	1	9
Conway	\N	\N	\N	\N	3154	2	8	\N	f	1	2963	1	4
Gower	\N	\N	\N	\N	3155	2	8	\N	f	\N	2964	1	8
Cumberland and Teviotdale	\N	\N	\N	\N	3156	2	4	\N	f	\N	2965	4	4
Armagh	\N	\N	\N	\N	3157	2	6	\N	f	\N	2965	4	2
Kent and Strathearn	\N	\N	\N	\N	3158	2	4	\N	f	\N	2966	4	12
Dublin	\N	\N	\N	\N	3159	2	6	\N	f	\N	2966	4	5
Nelson	\N	\N	\N	\N	3160	2	8	\N	f	\N	2967	4	15
Basset	\N	\N	\N	\N	3161	8	8	\N	f	2	2968	4	3
Duncan	\N	\N	\N	\N	3162	2	12	\N	f	\N	2969	4	5
Duncan	\N	\N	\N	\N	3163	2	8	\N	f	\N	2969	4	5
Seaforth	\N	\N	\N	\N	3164	2	8	\N	f	\N	2970	4	20
Perth	\N	\N	\N	\N	3165	2	8	\N	f	\N	2971	4	17
Ribblesdale	\N	\N	\N	\N	3166	2	8	\N	f	\N	2972	4	19
Lilford	\N	\N	\N	\N	3167	2	8	\N	f	\N	2973	4	13
Dunsandle and Clanconal	\N	\N	\N	\N	3168	2	8	\N	f	\N	2974	3	5
Oranmore and Browne	\N	\N	\N	\N	3169	2	8	\N	f	\N	2975	3	16
Carew	\N	\N	\N	\N	3170	2	8	\N	f	\N	2976	3	4
Ranfurly	\N	\N	\N	\N	3171	7	6	\N	f	\N	2977	3	19
Talbot de Malahide	\N	\N	\N	\N	3172	2	8	\N	f	3	2978	3	21
Guillamore	\N	\N	\N	\N	3173	2	12	\N	f	\N	2979	3	8
O'Grady	\N	\N	\N	\N	3174	2	8	\N	f	\N	2979	3	16
Norbury	\N	\N	\N	\N	3175	7	6	\N	f	3	2980	3	15
\.


--
-- Name: peerages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('peerages_id_seq', 3177, true);


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY people (id, forenames, surname, date_of_birth, date_of_death, notes, letter_id, gender_id, wikidata_id, mnis_id, rush_id) FROM stdin;
2787	Dudley Jaffray Hynman	Allenby	1903-01-08	1984-07-17	\N	2	1	\N	\N	\N
3	Horatio	Nelson	1758-09-29	1805-10-21	\N	15	1	\N	\N	\N
4	Richard Pepper	Arden	1745-05-20	1804-03-19	\N	2	1	\N	\N	\N
5	Mary Anne	Abercromby	\N	1821-02-11	\N	2	2	\N	\N	\N
6	Charles	Grey	1729-10-23	1807-11-14	\N	8	1	\N	\N	\N
8	Murrough	O'Brien	\N	1808-02-10	\N	16	1	\N	\N	\N
10	John	Hely Hutchinson	1757-05-15	1832-06-29	\N	9	1	\N	\N	\N
11	John	Mitford	1748-08-18	1830-01-16	\N	14	1	\N	\N	\N
12	Asheton	Curzon	1730-02-02	1820-03-21	\N	4	1	\N	\N	\N
13	George	Pitt	1721-05-01	1803-05-07	\N	17	1	\N	\N	\N
14	Edward	Law	1750-11-16	1818-12-13	\N	13	1	\N	\N	\N
15	Mary	Hill	\N	1836-08-01	\N	9	2	\N	\N	\N
16	Charles George	Percival	1756-10-01	1840-07-05	\N	17	1	\N	\N	\N
17	John	Baker Holroyd	1735-12-21	1821-05-30	\N	3	1	\N	\N	\N
18	Henry	Dundas	1742-04-28	1811-05-29	\N	5	1	\N	\N	\N
19	Gerard	Lake	1744-07-27	1808-02-20	\N	13	1	\N	\N	\N
20	Henry	Addington	1757-05-30	1844-02-15	\N	2	1	\N	\N	\N
21	Charles	Middleton	1726-10-14	1813-06-17	\N	14	1	\N	\N	\N
23	William	Nelson	1757-04-20	1835-02-28	\N	15	1	\N	\N	\N
25	Thomas	Erskine	1750-01-10	1823-11-17	\N	6	1	\N	\N	\N
26	Thomas	Anson	1767-02-14	1818-07-31	\N	2	1	\N	\N	\N
27	John Denis	Brown	1756-06-11	1809-06-02	\N	3	1	\N	\N	\N
28	Charles	Tottenham Loftus	1738-01-23	1806-03-22	\N	21	1	\N	\N	\N
29	John	Crewe	1742-09-27	1829-04-28	\N	4	1	\N	\N	\N
30	William	Lygon	1747-07-25	1816-10-21	\N	13	1	\N	\N	\N
32	Augustus Frederick	-	1773-01-27	1843-04-21	\N	1	1	\N	\N	\N
33	Thomas	Pelham	1728-02-28	1805-01-08	\N	17	1	\N	\N	\N
34	William	Craven	1770-09-01	1825-07-30	\N	4	1	\N	\N	\N
35	George	Onslow	1731-10-13	1814-05-17	\N	16	1	\N	\N	\N
36	Edward	Clive	1754-03-07	1839-05-16	\N	4	1	\N	\N	\N
37	Charles	Marsham	1744-09-28	1811-03-01	\N	14	1	\N	\N	\N
38	Alexander	Wedderburn	1733-02-13	1805-01-03	\N	24	1	\N	\N	\N
39	Henry	Cecil	1754-03-14	1804-05-01	\N	4	1	\N	\N	\N
41	Archibald	Kennedy	1770-02-01	1846-09-08	\N	12	1	\N	\N	\N
42	John	Campbell	1762-03-30	1834-03-29	\N	4	1	\N	\N	\N
43	Alan	Gardner	1742-02-12	1809-01-01	\N	8	1	\N	\N	\N
45	William	Cathcart	1755-08-01	1843-06-16	\N	4	1	\N	\N	\N
46	James	Gambier	1756-10-13	1833-04-19	\N	8	1	\N	\N	\N
47	James	Hope	1741-08-23	1816-05-29	\N	9	1	\N	\N	\N
48	Arthur	Wellesley	1769-04-29	1852-09-14	\N	24	1	\N	\N	\N
49	John Jeffreys	Pratt	1759-02-11	1840-10-08	\N	17	1	\N	\N	\N
50	Charles	Whitworth	1752-05-29	1825-05-12	\N	24	1	\N	\N	\N
51	John	Hope	1765-08-17	1823-08-27	\N	9	1	\N	\N	\N
52	Thomas	Graham	1748-10-19	1843-12-18	\N	8	1	\N	\N	\N
54	Rowland	Hill	1772-08-11	1842-12-10	\N	9	1	\N	\N	\N
55	William Carr	Beresford	1768-10-02	1854-01-08	\N	3	1	\N	\N	\N
56	George	Elphinstone	1746-01-07	1823-03-10	\N	6	1	\N	\N	\N
57	Charles William	Stewart	1778-05-18	1854-03-06	\N	20	1	\N	\N	\N
58	George	Gordon	1784-01-28	1860-12-14	\N	8	1	\N	\N	\N
60	John	Bowes	1769-04-14	1820-07-03	\N	3	1	\N	\N	\N
61	George	Ramsay	1770-10-23	1838-03-21	\N	19	1	\N	\N	\N
62	George	Gordon	1761-06-28	1853-06-17	\N	8	1	\N	\N	\N
63	George	Boyle	1765-03-26	1843-07-03	\N	3	1	\N	\N	\N
65	Edmund Henry	Pery	1758-01-08	1844-12-07	\N	17	1	\N	\N	\N
66	Francis Almeric	Spencer	1779-12-26	1845-03-10	\N	20	1	\N	\N	\N
67	Peniston	Lamb	1748-01-29	1828-07-22	\N	13	1	\N	\N	\N
68	James	Maitland	1759-01-26	1839-09-15	\N	14	1	\N	\N	\N
69	Dudley	Ryder	1762-12-22	1847-12-26	\N	19	1	\N	\N	\N
70	William	Lowther	1757-12-29	1844-03-19	\N	13	1	\N	\N	\N
72	Henry	Phipps	1755-02-14	1831-04-07	\N	17	1	\N	\N	\N
73	Horatio	Walpole	1723-06-12	1809-02-24	\N	24	1	\N	\N	\N
74	James Walter	Grimston	1775-09-26	1845-11-17	\N	8	1	\N	\N	\N
75	Henry William	Paget	1768-05-17	1854-04-29	\N	17	1	\N	\N	\N
76	George James	Cholmondeley	1749-05-11	1827-04-10	\N	4	1	\N	\N	\N
77	Charles	Compton	1760-03-24	1828-05-24	\N	4	1	\N	\N	\N
78	John	Cust	1779-08-19	1853-09-15	\N	4	1	\N	\N	\N
79	Amabell	Hume-Campbell	1750-01-22	1833-05-04	\N	9	2	\N	\N	\N
80	Algernon	Percy	1792-12-15	1865-02-12	\N	17	1	\N	\N	\N
81	Charles	Abbot	1757-10-14	1829-05-08	\N	2	1	\N	\N	\N
83	John Somers	Cocks	1760-05-06	1841-01-05	\N	4	1	\N	\N	\N
85	Henry	Conyngham	1766-12-26	1832-12-28	\N	4	1	\N	\N	\N
86	James Wandesford	Butler	1777-07-15	1838-05-18	\N	3	1	\N	\N	\N
87	Francis Charteris Wemyss	Douglas	1772-04-15	1853-06-28	\N	5	1	\N	\N	\N
88	Robert	Jocelyn	1788-10-27	1870-03-20	\N	11	1	\N	\N	\N
89	George	King	1771-04-08	1839-10-18	\N	12	1	\N	\N	\N
90	Thomas	Pakenham	1774-05-14	1835-05-24	\N	17	1	\N	\N	\N
92	William Wellesley	Pole	1763-05-20	1845-02-22	\N	17	1	\N	\N	\N
93	John	Foster	\N	1828-08-16	\N	7	1	\N	\N	\N
94	William	Scott	1745-10-17	1836-01-28	\N	20	1	\N	\N	\N
95	Thomas Henry	Liddell	1775-02-08	1855-03-07	\N	13	1	\N	\N	\N
96	Thomas	Cholmondeley	1767-08-09	1855-10-30	\N	4	1	\N	\N	\N
97	Cecil Weld	Forester	\N	1828-05-23	\N	7	1	\N	\N	\N
99	Nicholas	Vansittart	1766-04-29	1851-02-08	\N	23	1	\N	\N	\N
100	Charles William	Vane	1778-05-18	1854-03-06	\N	23	1	\N	\N	\N
101	Richard	Trench	1767-05-18	1837-11-24	\N	21	1	\N	\N	\N
102	Robert	Gifford	1779-02-24	1826-09-04	\N	8	1	\N	\N	\N
103	Granville Leveson	Gower	1773-10-12	1846-01-08	\N	8	1	\N	\N	\N
104	William	O'Bryen	\N	1846-08-21	\N	16	1	\N	\N	\N
105	Ulick John	de Burgh	1802-12-20	1826-12-13	\N	5	1	\N	\N	\N
106	James	Lindsay	1783-04-24	1869-12-15	\N	13	1	\N	\N	\N
107	Charles	Long	\N	1838-01-17	\N	13	1	\N	\N	\N
109	Orlando	Bridgeman	1762-03-19	1825-09-07	\N	3	1	\N	\N	\N
110	John	Scott	1751-06-04	1838-01-13	\N	20	1	\N	\N	\N
112	John	Parker	1772-05-03	1840-03-14	\N	17	1	\N	\N	\N
113	John	Rous	1750-05-30	1827-08-27	\N	19	1	\N	\N	\N
114	Charles	Brudenell-Bruce	1773-02-14	1856-01-04	\N	3	1	\N	\N	\N
115	William Harry	Vane	1766-07-27	1842-01-29	\N	23	1	\N	\N	\N
2	John Joshua	Proby	1751-08-12	1828-04-07	\N	17	1	\N	\N	\N
2788	Michael Jaffray Hynman	Allenby	1931-04-20	2014-10-03	\N	2	1	\N	\N	\N
119	William Pitt	Amherst	1773-01-14	1857-03-13	\N	2	1	\N	\N	\N
121	Frederick John	Robinson	1782-11-01	1859-01-28	\N	19	1	\N	\N	\N
122	James	Duff	1776-10-06	1857-03-09	\N	5	1	\N	\N	\N
123	Charles	Abbott	1762-10-07	1832-11-04	\N	2	1	\N	\N	\N
124	William Conyngham	Plunket	1765-07-01	1854-01-05	\N	17	1	\N	\N	\N
125	Thomas	Hamilton	1780-06-21	1858-12-01	\N	9	1	\N	\N	\N
126	John Frederick	Campbell	1790-11-08	1860-11-07	\N	4	1	\N	\N	\N
127	Henry	Wellesley	1773-01-20	1847-04-27	\N	24	1	\N	\N	\N
128	Joan	Canning	\N	1837-03-15	\N	4	2	\N	\N	\N
129	Charles	Stuart	1779-01-02	1845-11-06	\N	20	1	\N	\N	\N
131	Archibald John	Primrose	1783-10-14	1868-03-04	\N	17	1	\N	\N	\N
132	Richard	Meade	1795-08-15	1879-10-07	\N	14	1	\N	\N	\N
133	John George	Lambton	1792-04-12	1840-07-28	\N	13	1	\N	\N	\N
134	Edward Bootle	Wilbraham	1771-03-07	1853-04-03	\N	24	1	\N	\N	\N
135	Thomas	Wallace	\N	1844-02-23	\N	24	1	\N	\N	\N
136	William Draper	Best	1767-12-13	1845-03-03	\N	3	1	\N	\N	\N
137	Henry	Brougham	1778-09-19	1868-05-07	\N	3	1	\N	\N	\N
139	William Philip	Molyneux	1772-09-18	1838-11-20	\N	14	1	\N	\N	\N
140	Nathaniel	Clements	1768-05-09	1854-12-31	\N	4	1	\N	\N	\N
141	George William Fox	Kinnaird	1807-04-14	1878-01-07	\N	12	1	\N	\N	\N
142	George James Welbore	Agar Ellis	1797-01-17	1833-07-10	\N	2	1	\N	\N	\N
143	Thomas	Taylour	1787-05-04	1870-12-06	\N	21	1	\N	\N	\N
144	John Chambre	Brabazon	1772-04-09	1851-03-15	\N	3	1	\N	\N	\N
145	George	Murray	1762-04-30	1836-11-11	\N	14	1	\N	\N	\N
147	Robert Montgomery	Hamilton	\N	1868-12-22	\N	9	1	\N	\N	\N
148	George	Cadogan	1783-05-05	1864-09-15	\N	4	1	\N	\N	\N
150	Robert	Lawley	\N	1834-04-10	\N	13	1	\N	\N	\N
151	Edward Pryce	Lloyd	1768-09-17	1854-04-03	\N	13	1	\N	\N	\N
152	William Fitzhardinge	Berkeley	1786-09-26	1857-10-10	\N	3	1	\N	\N	\N
153	Arthur	Chichester	1797-01-08	1837-09-26	\N	4	1	\N	\N	\N
154	William Lewis	Hughes	1767-11-10	1852-02-10	\N	9	1	\N	\N	\N
155	George	FitzClarence	1794-01-29	1842-03-20	\N	7	1	\N	\N	\N
156	Frederick William	Hervey	1769-10-02	1859-02-15	\N	9	1	\N	\N	\N
157	Valentine Browne	Lawless	1773-08-19	1853-10-28	\N	13	1	\N	\N	\N
158	James	Saumarez	1757-03-11	1836-10-09	\N	20	1	\N	\N	\N
160	Lucius Bentinck	Cary	1803-11-05	1884-03-12	\N	4	1	\N	\N	\N
161	Edward	Smith Stanley	1775-04-21	1851-06-30	\N	20	1	\N	\N	\N
162	Charles Callis	Western	1767-08-09	1844-11-04	\N	24	1	\N	\N	\N
163	Granville	Leveson Gower	1773-10-12	1846-01-08	\N	13	1	\N	\N	\N
164	Charles	Douglas	\N	1837-12-03	\N	5	1	\N	\N	\N
165	Thomas	Denman	1779-02-23	1854-09-22	\N	5	1	\N	\N	\N
166	Sophia Elizabeth	Wykam	1790-03-10	1870-08-09	\N	24	2	\N	\N	\N
167	John William	Ponsonby	1781-08-31	1847-05-16	\N	17	1	\N	\N	\N
169	James	Scarlett	1769-12-13	1844-04-07	\N	20	1	\N	\N	\N
171	Charles	Manners Sutton	1780-01-29	1845-07-21	\N	14	1	\N	\N	\N
172	Alexander	Baring	1774-10-27	1848-05-12	\N	3	1	\N	\N	\N
173	Charles	Grant	1778-10-26	1866-04-23	\N	8	1	\N	\N	\N
174	Edward John	Littleton	1791-03-18	1863-05-04	\N	13	1	\N	\N	\N
175	John	Byng	\N	1860-06-03	\N	3	1	\N	\N	\N
176	Archibald	Acheson	1776-08-01	1849-03-27	\N	2	1	\N	\N	\N
177	Charles Christopher	Pepys	1781-04-29	1851-04-29	\N	17	1	\N	\N	\N
178	Mary Elizabeth	Campbell	\N	1860-03-25	\N	4	2	\N	\N	\N
179	Henry	Bickersteth	1783-06-18	1851-04-18	\N	3	1	\N	\N	\N
181	Thomas Alexander	Fraser	1802-06-17	1875-06-28	\N	7	1	\N	\N	\N
182	William	Hanbury	1780-06-24	1845-07-22	\N	9	1	\N	\N	\N
183	Cornelius	O'Callaghan	1775-10-02	1857-05-30	\N	16	1	\N	\N	\N
184	Warner William	Westenra	1765-10-14	1842-08-10	\N	24	1	\N	\N	\N
185	Robert Shapland	Carew	1787-03-09	1856-06-02	\N	4	1	\N	\N	\N
186	William Francis Spencer	Ponsonby	1787-07-31	1855-05-16	\N	17	1	\N	\N	\N
187	John	Wrottesley	1771-10-25	1841-03-16	\N	24	1	\N	\N	\N
189	Thomas	Moreton	1776-08-31	1840-06-22	\N	14	1	\N	\N	\N
190	Kenneth Alexander	Howard	1767-11-29	1845-02-13	\N	9	1	\N	\N	\N
191	Thomas William	Anson	1795-10-20	1854-03-18	\N	2	1	\N	\N	\N
192	William	King	1805-02-20	1893-12-29	\N	12	1	\N	\N	\N
193	Charles	Pelham	1781-08-08	1846-09-05	\N	17	1	\N	\N	\N
194	Lawrence	Dundas	1766-04-10	1839-02-19	\N	5	1	\N	\N	\N
195	John	Campbell	\N	1834-03-29	\N	4	1	\N	\N	\N
196	Robert	Grosvenor	1767-03-22	1845-02-17	\N	8	1	\N	\N	\N
198	Paul	Methuen	1779-06-21	1849-09-11	\N	14	1	\N	\N	\N
199	John	Ponsonby	\N	1855-02-21	\N	17	1	\N	\N	\N
200	Richard Wogan	Talbot	\N	1849-10-29	\N	21	1	\N	\N	\N
202	Henry	Villiers Stuart	1803-06-08	1874-01-23	\N	23	1	\N	\N	\N
203	Chandos	Leigh	1791-06-27	1850-09-27	\N	13	1	\N	\N	\N
204	Paul Beilby	Thompson	\N	1852-05-09	\N	21	1	\N	\N	\N
205	Charles	Brownlow	1795-04-17	1847-04-30	\N	3	1	\N	\N	\N
207	Arthur	French	\N	1856-09-29	\N	7	1	\N	\N	\N
208	James	Abercromby	1776-11-07	1858-04-17	\N	2	1	\N	\N	\N
209	Thomas Spring	Rice	1790-02-08	1866-02-07	\N	19	1	\N	\N	\N
210	John	Colborne	1778-02-16	1863-04-17	\N	4	1	\N	\N	\N
211	John	Keane	1781-02-06	1844-08-26	\N	12	1	\N	\N	\N
212	Charles	Poulett Thomson	1799-09-13	1841-09-19	\N	17	1	\N	\N	\N
213	John	Dalrymple	1771-06-15	1853-01-10	\N	5	1	\N	\N	\N
214	Valentine	Browne	1788-01-15	1853-10-31	\N	3	1	\N	\N	\N
215	Richard Hussey	Vivian	1775-07-28	1842-08-20	\N	23	1	\N	\N	\N
216	Henry Brooke	Parnell	1776-07-03	1842-06-08	\N	17	1	\N	\N	\N
218	Hugh	Gough	1779-11-03	1869-03-02	\N	8	1	\N	\N	\N
219	Francis William	Caulfeild	1775-01-03	1863-12-26	\N	4	1	\N	\N	\N
220	Archibald	Acheson	1806-08-20	1864-06-15	\N	2	1	\N	\N	\N
221	Richard	Dawson	1817-09-07	1897-05-12	\N	5	1	\N	\N	\N
223	Edward John	Stanley	1802-11-13	1869-06-16	\N	20	1	\N	\N	\N
224	James	Bruce	1811-07-20	1863-11-20	\N	3	1	\N	\N	\N
225	Cecilia Letitia	Underwood	\N	1873-08-01	\N	22	2	\N	\N	\N
226	George	Eden	1784-08-25	1849-01-01	\N	6	1	\N	\N	\N
227	Edward	-	1841-11-09	1910-05-06	\N	1	1	\N	\N	\N
118	Charles	Duncombe	1764-12-05	1841-07-16	\N	5	1	\N	\N	\N
2789	Henry Jaffray Hynman	Allenby	1968-07-29	\N	\N	2	1	\N	\N	\N
230	James Andrew	Ramsay	1812-04-22	1860-12-22	\N	19	1	\N	\N	\N
231	Constantine Henry	Phipps	1797-05-15	1863-07-28	\N	17	1	\N	\N	\N
232	Albert Edward	-	1841-11-09	1910-05-06	\N	1	1	\N	\N	\N
234	Samuel Jones	Loyd	1796-09-25	1883-11-17	\N	13	1	\N	\N	\N
235	Thomas	Wilde	1782-07-07	1855-11-11	\N	24	1	\N	\N	\N
236	Robert Monsey	Rolfe	1790-12-18	1868-07-26	\N	19	1	\N	\N	\N
237	John Cam	Hobhouse	1786-06-27	1869-06-03	\N	9	1	\N	\N	\N
238	Edward Burtenshaw	Sugden	1781-02-12	1875-01-29	\N	20	1	\N	\N	\N
239	Stratford	Canning	1786-11-04	1880-08-14	\N	4	1	\N	\N	\N
241	Gilbert John	Heathcote	1795-01-16	1867-09-06	\N	9	1	\N	\N	\N
242	Thomas	Browne	1789-01-15	1871-12-26	\N	3	1	\N	\N	\N
243	Edmund	Lyons	1790-11-21	1858-11-23	\N	13	1	\N	\N	\N
244	James	Parke	1782-03-22	1868-02-25	\N	17	1	\N	\N	\N
245	Edward	Strutt	1801-10-26	1880-06-30	\N	20	1	\N	\N	\N
246	James	Talbot	1805-11-22	1883-04-14	\N	21	1	\N	\N	\N
248	Charles	Shaw Lefevre	1794-02-22	1888-12-28	\N	20	1	\N	\N	\N
249	Robert	Grosvenor	1801-04-24	1893-11-18	\N	8	1	\N	\N	\N
250	Thomas Babington	Macaulay	1800-10-25	1859-12-28	\N	14	1	\N	\N	\N
251	James	Duff	1814-07-06	1879-08-07	\N	5	1	\N	\N	\N
252	Charles Compton	Cavendish	1793-08-28	1863-11-10	\N	4	1	\N	\N	\N
254	Frederic	Rogers	1811-01-31	1889-11-21	\N	19	1	\N	\N	\N
255	John	Buller Yarde Buller	1799-04-12	1871-09-04	\N	3	1	\N	\N	\N
256	Colin	Campbell	1792-10-20	1863-08-14	\N	4	1	\N	\N	\N
257	Thomas	Pemberton Leigh	1793-02-11	1867-10-07	\N	17	1	\N	\N	\N
258	George	Wyndham	1787-06-05	1869-03-18	\N	24	1	\N	\N	\N
260	Robert Vernon	Smith	1800-02-01	1873-11-10	\N	20	1	\N	\N	\N
261	Benjamin	Hall	1802-11-08	1867-04-27	\N	9	1	\N	\N	\N
262	Henry	Labouchere	1798-08-15	1869-07-13	\N	13	1	\N	\N	\N
263	Sidney	Herbert	1810-09-16	1861-08-02	\N	9	1	\N	\N	\N
264	Richard	Bethell	1800-06-30	1873-07-20	\N	3	1	\N	\N	\N
265	John	Russell	1792-08-18	1878-05-28	\N	19	1	\N	\N	\N
266	Maurice Frederick Fitzhardinge	Berkeley	1788-01-03	1867-10-17	\N	3	1	\N	\N	\N
267	William	Ward	1817-03-27	1885-05-07	\N	24	1	\N	\N	\N
268	Francis	Egerton	1800-01-01	1857-02-18	\N	6	1	\N	\N	\N
270	Edward Adolphus	Seymour	1804-12-20	1885-11-28	\N	20	1	\N	\N	\N
271	Henry	White	\N	1873-09-01	\N	24	1	\N	\N	\N
272	Richard Monckton	Milnes	1809-06-19	1885-08-11	\N	14	1	\N	\N	\N
273	Elizabeth	Sackville West	\N	1870-01-01	\N	20	2	\N	\N	\N
274	John	Romilly	1802-01-10	1874-12-23	\N	19	1	\N	\N	\N
275	Francis Thornhill	Baring	1796-04-20	1866-09-06	\N	3	1	\N	\N	\N
276	Charles	Wood	1800-12-20	1885-08-08	\N	24	1	\N	\N	\N
277	James	Sinclair	1821-12-16	1881-03-28	\N	20	1	\N	\N	\N
278	Thomas	Fortescue	1815-03-09	1887-07-29	\N	7	1	\N	\N	\N
281	Charles Stanley	Monck	1819-10-10	1894-11-29	\N	14	1	\N	\N	\N
282	John	Henniker-Major	1801-02-03	1870-04-16	\N	9	1	\N	\N	\N
283	Edward George Earle Lytton	Bulwer Lytton	1803-05-25	1873-01-18	\N	3	1	\N	\N	\N
284	William George Hylton	Jolliffe	1800-12-07	1876-06-01	\N	11	1	\N	\N	\N
285	Hugh Henry	Rose	1801-04-06	1885-10-16	\N	19	1	\N	\N	\N
286	Edward Gordon	Douglas Pennant	1800-06-20	1886-03-31	\N	5	1	\N	\N	\N
287	Duncan	McNeill	1793-08-20	1874-01-31	\N	14	1	\N	\N	\N
289	John	Trollope	1800-05-05	1874-12-17	\N	21	1	\N	\N	\N
290	John Benn	Walsh	1798-12-09	1881-02-03	\N	24	1	\N	\N	\N
291	Brook William	Bridges	1801-06-02	1875-12-06	\N	3	1	\N	\N	\N
292	William	O'Neill	1813-03-04	1883-04-18	\N	16	1	\N	\N	\N
293	Charles John	Canning	1812-12-14	1862-06-17	\N	4	1	\N	\N	\N
294	John	Elphinstone	1807-06-23	1860-07-19	\N	6	1	\N	\N	\N
295	Mary Anne	Disraeli	1792-11-11	1872-12-15	\N	5	2	\N	\N	\N
296	Edward Anthony John	Preston	1796-06-03	1876-09-28	\N	17	1	\N	\N	\N
297	William Page	Wood	1801-11-29	1881-07-10	\N	24	1	\N	\N	\N
299	James Plaisted	Wilde	1816-07-12	1899-12-09	\N	24	1	\N	\N	\N
300	John	Rogerson Rollo	1835-10-24	1916-10-02	\N	19	1	\N	\N	\N
301	William	Hare	1833-05-29	1924-06-05	\N	9	1	\N	\N	\N
303	John Wilson	FitzPatrick	1811-09-23	1883-01-22	\N	7	1	\N	\N	\N
304	John Emerich Edward	Dalberg-Acton	1834-01-10	1902-06-19	\N	5	1	\N	\N	\N
305	Thomas James	Agar-Robartes	1808-03-18	1882-03-09	\N	2	1	\N	\N	\N
306	John	Wodehouse	1826-01-07	1902-04-08	\N	24	1	\N	\N	\N
307	George Carr	Glyn	1797-04-27	1873-07-24	\N	8	1	\N	\N	\N
309	Charles William	Fitzgerald	1819-03-30	1887-02-10	\N	7	1	\N	\N	\N
310	Thomas	O'Hagan	1812-05-29	1885-02-01	\N	16	1	\N	\N	\N
311	John	Young	1807-08-31	1876-10-06	\N	26	1	\N	\N	\N
312	William Henry Lytton Earle	Bulwer	1801-02-13	1872-05-23	\N	3	1	\N	\N	\N
313	William Rose	Mansfield	1819-06-21	1876-06-23	\N	14	1	\N	\N	\N
314	Angela Georgina	Burdett-Coutts	1814-04-21	1906-12-30	\N	3	2	\N	\N	\N
315	John Arthur Douglas	Bloomfield	1802-11-12	1879-08-17	\N	3	1	\N	\N	\N
316	John Evelyn	Denison	1800-01-27	1873-03-07	\N	5	1	\N	\N	\N
317	Francis	Napier	1819-09-15	1898-12-19	\N	15	1	\N	\N	\N
318	John	Hanmer	1809-12-22	1881-03-08	\N	9	1	\N	\N	\N
320	Gavin	Campbell	1851-04-09	1922-10-19	\N	4	1	\N	\N	\N
321	Robert Alexander Shafto	Adair	1811-08-25	1886-02-05	\N	2	1	\N	\N	\N
322	David	Robertson	1797-04-02	1873-06-19	\N	19	1	\N	\N	\N
323	Henry Austin	Bruce	1815-04-16	1895-02-25	\N	3	1	\N	\N	\N
324	Edward Granville George	Howard	1809-12-23	1880-10-08	\N	9	1	\N	\N	\N
325	James	Moncreiff	1811-11-29	1895-04-27	\N	14	1	\N	\N	\N
326	John Duke	Coleridge	1820-12-03	1894-06-14	\N	4	1	\N	\N	\N
328	John Robert	Townshend	1805-08-09	1890-02-14	\N	21	1	\N	\N	\N
329	Robert Cornelis	Napier	1810-12-05	1890-01-14	\N	15	1	\N	\N	\N
330	John Somerset	Pakington	1799-02-20	1880-04-09	\N	17	1	\N	\N	\N
331	John	Wilson Patten	1802-04-26	1892-07-11	\N	24	1	\N	\N	\N
332	George	Ramsay	1806-04-26	1880-07-20	\N	19	1	\N	\N	\N
334	John	Crichton	1802-07-30	1885-10-03	\N	4	1	\N	\N	\N
335	John Ralph	Ormsby-Gore	1816-06-03	1876-06-15	\N	16	1	\N	\N	\N
336	Henry Gerard	Sturt	1825-05-16	1904-02-17	\N	20	1	\N	\N	\N
337	John	Tollemache	1805-12-05	1890-12-09	\N	21	1	\N	\N	\N
2790	Gerald William	Balfour	1853-04-09	1945-01-14	\N	3	1	\N	\N	\N
340	Hugh Lupus	Grosvenor	1825-10-13	1899-12-22	\N	8	1	\N	\N	\N
341	William Ernest	Duncombe	1829-01-28	1915-01-13	\N	5	1	\N	\N	\N
342	Henry Thomas	Liddell	1797-03-10	1878-03-19	\N	13	1	\N	\N	\N
343	William	Nevill	1826-09-16	1915-12-12	\N	15	1	\N	\N	\N
345	Mortimer	Sackville-West	1820-09-22	1888-10-01	\N	20	1	\N	\N	\N
346	Edward Strathearn	Gordon	1814-04-10	1879-08-21	\N	8	1	\N	\N	\N
347	Richard	Airey	1803-04-01	1881-09-13	\N	2	1	\N	\N	\N
348	Charles Bowyer	Adderley	1814-08-02	1905-03-28	\N	2	1	\N	\N	\N
349	Gathorne	Hardy	1814-10-01	1906-10-30	\N	9	1	\N	\N	\N
350	George William	Barrington	1824-02-14	1886-11-07	\N	3	1	\N	\N	\N
352	William	Watson	1827-08-25	1899-09-14	\N	24	1	\N	\N	\N
353	Lawrence	Palk	1818-01-05	1883-03-22	\N	17	1	\N	\N	\N
354	Ivor Bertie	Guest	1835-08-29	1914-02-22	\N	8	1	\N	\N	\N
355	Arthur Edward	Guinness	1840-11-01	1915-01-20	\N	8	1	\N	\N	\N
357	George Watson	Milles	1824-10-02	1894-09-10	\N	14	1	\N	\N	\N
358	Charles Frederick	Abney Hastings	1822-06-17	1895-07-24	\N	2	1	\N	\N	\N
359	Arthur Edwin	Hill-Trevor	1819-11-04	1894-12-25	\N	9	1	\N	\N	\N
360	Montague William	Lowry Corry	1838-10-08	1903-11-09	\N	13	1	\N	\N	\N
361	Robert	Lowe	1811-12-04	1892-07-27	\N	13	1	\N	\N	\N
363	Edmund	Hammond	1802-06-25	1890-04-29	\N	9	1	\N	\N	\N
364	Edward	Cardwell	1813-07-24	1886-02-15	\N	4	1	\N	\N	\N
365	William Montagu	Hay	1826-01-27	1911-11-25	\N	9	1	\N	\N	\N
366	William Ulick Tristram	St Lawrence	1827-06-25	1909-03-09	\N	20	1	\N	\N	\N
367	Donald James	Mackay	1839-12-22	1921-08-01	\N	14	1	\N	\N	\N
368	Harcourt	Van den Bempde-Johnstone	1829-01-03	1916-03-01	\N	23	1	\N	\N	\N
369	Henry James	Tufton	1844-06-04	1926-10-29	\N	21	1	\N	\N	\N
370	Dudley Coutts	Marjoribanks	1820-12-29	1894-03-04	\N	14	1	\N	\N	\N
371	George William Wilshere	Bramwell	1808-06-12	1892-05-09	\N	3	1	\N	\N	\N
372	John David	FitzGerald	1816-05-01	1889-10-16	\N	7	1	\N	\N	\N
374	Garnet Joseph	Wolseley	1833-06-04	1913-03-25	\N	24	1	\N	\N	\N
375	Alfred	Tennyson	1809-08-06	1892-10-06	\N	21	1	\N	\N	\N
376	Henry Bouverie William	Brand	1814-12-24	1892-03-14	\N	3	1	\N	\N	\N
377	John George	Dodson	1825-10-18	1897-05-25	\N	5	1	\N	\N	\N
378	Edward	Bootle-Wilbraham	1837-12-12	1898-11-19	\N	3	1	\N	\N	\N
379	Edward Robert Lytton	Bulwer-Lytton	1831-11-08	1891-11-24	\N	3	1	\N	\N	\N
380	Thomas George	Baring	1826-01-22	1904-11-15	\N	3	1	\N	\N	\N
382	Walter Charles	James	1816-06-03	1893-02-04	\N	11	1	\N	\N	\N
383	Arthur Saunders William Charles Fox	Gore	1839-01-06	1901-03-14	\N	8	1	\N	\N	\N
384	John Robert William	Vesey	1844-05-21	1903-07-06	\N	23	1	\N	\N	\N
386	Hardinge Stanley	Giffard	1823-09-03	1921-12-11	\N	8	1	\N	\N	\N
387	Mervyn Edward	Wingfield	1836-10-13	1904-06-05	\N	24	1	\N	\N	\N
388	Anthony Henley	Henley	1825-04-12	1898-11-27	\N	9	1	\N	\N	\N
389	Nathaniel Mayer	Rothschild	1840-11-08	1915-03-31	\N	19	1	\N	\N	\N
390	Edward Charles	Baring	1828-04-13	1897-07-17	\N	3	1	\N	\N	\N
391	Robert Porrett	Collier	1817-06-21	1886-10-27	\N	4	1	\N	\N	\N
392	Arthur	Hobhouse	1819-11-10	1904-12-06	\N	9	1	\N	\N	\N
393	Ralph Robert Wheeler	Lingen	1819-02-19	1905-07-22	\N	13	1	\N	\N	\N
394	Edward	Gibson	1837-09-04	1913-05-22	\N	8	1	\N	\N	\N
395	Rowland	Winn	1820-02-19	1893-01-20	\N	24	1	\N	\N	\N
396	Robert James	Loyd-Lindsay	1832-04-16	1901-06-10	\N	13	1	\N	\N	\N
397	William Baliol	Brett	1815-08-13	1899-05-24	\N	3	1	\N	\N	\N
398	Thomas	Bateson	1819-06-04	1890-12-01	\N	3	1	\N	\N	\N
400	William Buller Fullerton	Elphinstone	1828-11-18	1893-01-18	\N	6	1	\N	\N	\N
401	Odo William Leopold	Russell	1829-02-20	1884-08-25	\N	19	1	\N	\N	\N
402	Henry	Allsopp	1811-02-19	1887-04-03	\N	2	1	\N	\N	\N
403	Edmund	Beckett	1816-05-12	1905-04-29	\N	3	1	\N	\N	\N
405	William	Edwardes	1835-05-11	1896-10-07	\N	6	1	\N	\N	\N
406	Thomas Erskine	May	1815-02-08	1886-05-17	\N	14	1	\N	\N	\N
407	William John	Monson	1829-02-18	1898-04-16	\N	14	1	\N	\N	\N
408	John Glencairn Carter	Hamilton	1829-11-16	1900-10-15	\N	9	1	\N	\N	\N
409	Thomas	Brassey	1836-02-11	1918-02-23	\N	3	1	\N	\N	\N
410	Henry	Thring	1818-11-03	1907-02-04	\N	21	1	\N	\N	\N
412	Cornwallis	Maude	1817-04-04	1905-01-09	\N	14	1	\N	\N	\N
413	Edward	Macnaghten	1830-02-03	1913-02-17	\N	14	1	\N	\N	\N
414	Robert	Bourke	1827-06-11	1902-09-03	\N	3	1	\N	\N	\N
415	Claude	Bowes Lyon	1824-07-21	1904-02-16	\N	3	1	\N	\N	\N
416	George Edmund Milnes	Monckton-Arundell	1844-11-18	1931-03-07	\N	14	1	\N	\N	\N
417	Stafford Henry	Northcote	1818-10-27	1887-01-12	\N	15	1	\N	\N	\N
419	John	St Aubyn	1829-10-23	1908-05-14	\N	20	1	\N	\N	\N
420	James Macnaghten	McGarel-Hogg	1823-05-03	1890-06-27	\N	14	1	\N	\N	\N
421	William George	Armstrong	1810-11-26	1900-12-27	\N	2	1	\N	\N	\N
422	George	Sclater-Booth	1826-05-19	1894-10-22	\N	20	1	\N	\N	\N
423	Edward	Fellowes	1809-04-14	1887-08-09	\N	7	1	\N	\N	\N
424	Henry William	Eaton	1816-03-13	1891-10-02	\N	6	1	\N	\N	\N
425	John Gellibrand	Hubbard	1805-03-21	1889-08-28	\N	9	1	\N	\N	\N
426	Henry Thurstan	Holland	1825-08-03	1914-01-29	\N	9	1	\N	\N	\N
427	John	Savile	1818-01-06	1896-11-28	\N	20	1	\N	\N	\N
428	Michael	Morris	1826-11-14	1901-09-08	\N	14	1	\N	\N	\N
429	William Ventris	Field	1813-08-21	1907-01-23	\N	7	1	\N	\N	\N
432	James	Hannen	1821-03-19	1894-03-29	\N	9	1	\N	\N	\N
433	Samuel	Cunliffe Lister	1815-01-01	1906-02-02	\N	4	1	\N	\N	\N
434	Susan Agnes	Macdonald	\N	1920-09-05	\N	14	2	\N	\N	\N
435	Emily	Smith	\N	1913-08-13	\N	20	2	\N	\N	\N
436	Frederick Sleigh	Roberts	1832-09-30	1914-11-14	\N	19	1	\N	\N	\N
437	Farrer	Herschell	1837-11-02	1899-03-01	\N	9	1	\N	\N	\N
438	Charles Henry	Mills	1830-04-26	1898-04-03	\N	14	1	\N	\N	\N
440	Evelyn	Baring	1841-02-26	1917-01-29	\N	3	1	\N	\N	\N
441	Alexander Burns	Shand	1828-12-13	1904-03-06	\N	20	1	\N	\N	\N
442	George	Cubitt	1828-06-04	1917-02-26	\N	4	1	\N	\N	\N
443	Rainald	Knightley	1819-10-22	1895-12-19	\N	12	1	\N	\N	\N
444	Thomas	Brooks	1825-05-15	1908-02-05	\N	3	1	\N	\N	\N
339	Charles Henry	Gordon-Lennox	1818-02-27	1903-09-27	\N	8	1	\N	\N	\N
2791	Robert Arthur Lytton	Balfour	1902-12-31	1968-11-27	\N	3	1	\N	\N	\N
447	John	Mulholland	1819-12-16	1895-12-11	\N	14	1	\N	\N	\N
448	John Allan	Rolls	1837-02-19	1912-09-24	\N	19	1	\N	\N	\N
449	Lyon	Playfair	1818-05-21	1898-05-29	\N	17	1	\N	\N	\N
450	Cyril	Flower	1843-08-30	1907-11-27	\N	7	1	\N	\N	\N
451	Henry Hussey	Vivian	1821-07-06	1894-11-28	\N	23	1	\N	\N	\N
452	Thomas Henry	Farrer	1819-06-24	1899-10-11	\N	7	1	\N	\N	\N
454	George Frederick Ernest Albert	-	1865-06-03	1936-01-20	\N	1	1	\N	\N	\N
456	Gathorne	Gathorne-Hardy	1814-10-01	1906-10-30	\N	8	1	\N	\N	\N
457	Frederick Temple	Blackwood	1826-06-21	1902-02-12	\N	3	1	\N	\N	\N
458	Lawrence	Dundas	1844-08-16	1929-03-11	\N	5	1	\N	\N	\N
459	John Campbell	White	1843-11-21	1908-02-15	\N	24	1	\N	\N	\N
460	Francis Archibald	Douglas	1867-02-03	1894-10-19	\N	5	1	\N	\N	\N
461	Arthur	Hamilton-Gordon	1829-11-26	1912-01-30	\N	9	1	\N	\N	\N
463	Stuart	Rendel	1834-07-02	1913-06-04	\N	19	1	\N	\N	\N
464	Reginald Earle	Welby	1832-08-03	1915-10-29	\N	24	1	\N	\N	\N
465	Charles	Russell	1832-11-10	1900-08-10	\N	19	1	\N	\N	\N
466	Horace	Davey	1833-08-29	1907-02-20	\N	5	1	\N	\N	\N
467	Arthur Wellesley	Peel	1829-08-03	1912-10-24	\N	17	1	\N	\N	\N
468	Charles Robert	Carington	1843-05-16	1928-06-13	\N	4	1	\N	\N	\N
469	Henry Brougham	Loch	1827-05-23	1900-06-20	\N	13	1	\N	\N	\N
470	Sydney James	Stern	\N	1912-02-10	\N	20	1	\N	\N	\N
471	James	Williamson	1842-12-31	1930-05-27	\N	24	1	\N	\N	\N
472	Herbert Coulstoun	Gardner	1846-06-09	1921-05-06	\N	8	1	\N	\N	\N
473	Henry	Matthews	1826-01-13	1913-04-03	\N	14	1	\N	\N	\N
474	Henry	James	1828-10-30	1911-08-18	\N	11	1	\N	\N	\N
476	Henry	de Worms	1840-10-20	1903-01-09	\N	5	1	\N	\N	\N
477	Algernon	Borthwick	1830-12-27	1908-11-24	\N	3	1	\N	\N	\N
478	William	Thomson	1824-06-26	1907-12-17	\N	21	1	\N	\N	\N
479	Hercules George Robert	Robinson	1824-12-19	1897-10-28	\N	19	1	\N	\N	\N
480	Alexander Smith	Kinnear	1833-11-03	1917-12-20	\N	12	1	\N	\N	\N
481	Joseph	Lister	1827-04-05	1912-02-10	\N	13	1	\N	\N	\N
482	Wilbraham	Egerton	1832-01-17	1909-03-16	\N	6	1	\N	\N	\N
483	David	Boyle	1833-05-31	1915-12-13	\N	3	1	\N	\N	\N
485	Henry Charles	Lopes	1828-10-03	1899-12-25	\N	13	1	\N	\N	\N
486	Ion Trant	Hamilton	1839-07-14	1898-03-06	\N	9	1	\N	\N	\N
487	John	Burns	1829-06-24	1901-02-12	\N	3	1	\N	\N	\N
489	Horace Brand	Townsend-Farquhar	1844-05-18	1923-08-30	\N	21	1	\N	\N	\N
490	Josslyn Francis	Pennington	1834-12-25	1917-03-30	\N	17	1	\N	\N	\N
491	Arthur Lawrence	Haliburton	1832-09-26	1907-04-21	\N	9	1	\N	\N	\N
492	Horatio Herbert	Kitchener	1850-06-24	1916-06-05	\N	12	1	\N	\N	\N
493	Philip Henry Wodehouse	Currie	1834-10-13	1906-05-12	\N	4	1	\N	\N	\N
495	Joseph Russell	Bailey	1840-04-07	1906-01-06	\N	3	1	\N	\N	\N
496	Henry	Hawkins	1817-09-14	1907-10-06	\N	9	1	\N	\N	\N
497	Robert Thornhaugh	Gurdon	1829-06-18	1902-10-13	\N	8	1	\N	\N	\N
498	Henrietta Anne	Carleton	\N	1925-03-02	\N	4	2	\N	\N	\N
499	Julian	Pauncefote	1828-09-13	1902-05-24	\N	17	1	\N	\N	\N
500	James Patrick Bannerman	Robertson	1845-08-10	1909-02-02	\N	19	1	\N	\N	\N
501	Henry Stafford	Northcote	1846-11-18	1911-09-29	\N	15	1	\N	\N	\N
502	John	Lubbock	1834-04-30	1913-05-28	\N	13	1	\N	\N	\N
503	Nathaniel	Lindley	1828-11-29	1921-12-09	\N	13	1	\N	\N	\N
504	Peter	O'Brien	1842-06-29	1914-09-07	\N	16	1	\N	\N	\N
505	Richard Everard	Webster	1842-12-22	1915-12-15	\N	24	1	\N	\N	\N
507	Matthew White	Ridley	1842-07-25	1904-11-28	\N	19	1	\N	\N	\N
508	Alfred	Milner	1854-03-23	1925-05-13	\N	14	1	\N	\N	\N
510	John James Robert	Manners	1818-12-13	1906-08-04	\N	14	1	\N	\N	\N
511	John Blair	Balfour	1837-07-11	1905-01-22	\N	3	1	\N	\N	\N
512	Ughtred James	Kay-Shuttleworth	1844-12-18	1939-12-20	\N	12	1	\N	\N	\N
513	William Lawies	Jackson	1840-02-16	1917-04-04	\N	11	1	\N	\N	\N
514	Arthur Hugh	Smith-Barry	1843-01-17	1925-02-22	\N	20	1	\N	\N	\N
516	Francis	Knollys	1837-07-16	1924-08-15	\N	12	1	\N	\N	\N
517	Algernon Bertram	Freeman-Mitford	1837-02-24	1916-08-17	\N	7	1	\N	\N	\N
518	Edward	Levy-Lawson	1833-12-28	1916-01-09	\N	13	1	\N	\N	\N
519	Michael	Biddulph	1834-02-17	1923-04-06	\N	3	1	\N	\N	\N
520	George Thomas John	Sotheron-Estcourt	1839-01-21	1915-01-12	\N	20	1	\N	\N	\N
521	William Henry Armstrong Fitzpatrick	Watson-Armstrong	1863-05-03	1941-10-16	\N	24	1	\N	\N	\N
522	Francis Henry	Jeune	1843-03-17	1905-04-09	\N	11	1	\N	\N	\N
523	Andrew Graham	Murray	1849-11-21	1942-08-21	\N	14	1	\N	\N	\N
524	William Court	Gully	1835-08-29	1909-11-06	\N	8	1	\N	\N	\N
526	Charles Robert	Spencer	1857-10-30	1922-09-26	\N	20	1	\N	\N	\N
528	John Adrian Louis	Hope	1860-09-25	1908-02-29	\N	9	1	\N	\N	\N
529	John	Atkinson	1844-12-13	1932-03-13	\N	2	1	\N	\N	\N
530	Thomas Henry	Sanderson	1841-01-11	1923-03-21	\N	20	1	\N	\N	\N
531	Charles Thomson	Ritchie	1838-11-19	1906-01-09	\N	19	1	\N	\N	\N
532	William Hood	Walrond	1849-02-26	1925-05-17	\N	24	1	\N	\N	\N
533	Henry Meysey	Meysey-Thompson	1845-08-30	1929-03-03	\N	14	1	\N	\N	\N
534	Alfred Charles William	Harmsworth	1865-07-15	1922-08-14	\N	9	1	\N	\N	\N
535	Godfrey Charles	Morgan	1831-04-28	1913-03-11	\N	14	1	\N	\N	\N
536	Herbert	Stern	1851-09-28	1919-01-07	\N	20	1	\N	\N	\N
537	Edmund Beckett	Faber	1847-02-09	1920-09-17	\N	7	1	\N	\N	\N
539	Michael Edward	Hicks-Beach	1837-10-23	1916-04-30	\N	9	1	\N	\N	\N
540	Robert Threshie	Reid	1846-04-03	1923-11-30	\N	19	1	\N	\N	\N
541	Philip James	Stanhope	1847-02-08	1923-03-01	\N	20	1	\N	\N	\N
542	Arthur Dyvett	Hayter	1835-08-09	1917-05-10	\N	9	1	\N	\N	\N
543	Charles Hare	Hemphill	\N	1908-03-04	\N	9	1	\N	\N	\N
544	James	Joicey	1846-04-04	1936-11-21	\N	11	1	\N	\N	\N
546	Victor Albert Francis Charles	Spencer	1864-10-23	1934-01-03	\N	20	1	\N	\N	\N
547	Leonard Henry	Courtney	1832-07-06	1918-05-11	\N	4	1	\N	\N	\N
548	George John	Shaw-Lefevre	1831-06-12	1928-04-19	\N	20	1	\N	\N	\N
549	William James	Pirrie	1847-05-31	1924-06-06	\N	17	1	\N	\N	\N
551	George	Armitstead	1824-02-28	1915-12-07	\N	2	1	\N	\N	\N
446	William John	Legh	1828-12-19	1898-12-15	\N	13	1	\N	\N	\N
2792	Gerald Arthur James	Balfour	1925-12-23	2003-06-27	\N	3	1	\N	\N	\N
554	James	Kitson	1835-09-22	1911-03-16	\N	12	1	\N	\N	\N
556	James	Blyth	1841-09-10	1925-02-08	\N	3	1	\N	\N	\N
557	Alexander	Peckover	1830-08-16	1919-10-21	\N	17	1	\N	\N	\N
558	John	Morley	1838-12-24	1923-09-23	\N	14	1	\N	\N	\N
560	Edmund	Robertson	1845-10-28	1911-09-13	\N	19	1	\N	\N	\N
561	Antony Patrick	MacDonnell	1844-03-07	1925-06-09	\N	14	1	\N	\N	\N
562	George	Whiteley	1855-08-30	1925-10-21	\N	24	1	\N	\N	\N
563	Angus	Holden	1833-03-16	1912-03-25	\N	9	1	\N	\N	\N
564	John Wynford	Philipps	1860-05-30	1938-03-28	\N	17	1	\N	\N	\N
565	John Gorell	Barnes	1848-05-16	1913-04-22	\N	3	1	\N	\N	\N
567	John Arbuthnot	Fisher	1841-01-25	1920-07-10	\N	7	1	\N	\N	\N
568	Arthur	Godley	1847-06-17	1932-06-27	\N	8	1	\N	\N	\N
569	Herbert John	Gladstone	1854-01-07	1930-03-06	\N	8	1	\N	\N	\N
570	Ivor Churchill	Guest	1873-01-16	1939-06-14	\N	8	1	\N	\N	\N
571	John Charles	Bigham	1840-08-03	1929-09-03	\N	3	1	\N	\N	\N
573	Richard Knight	Causton	1843-09-25	1929-02-23	\N	4	1	\N	\N	\N
574	Balthazar Walter	Foster	1840-07-17	1913-01-31	\N	7	1	\N	\N	\N
575	Hudson Ewbanke	Kearley	1856-09-01	1934-09-05	\N	12	1	\N	\N	\N
576	Weetman Dickinson	Pearson	1856-07-15	1927-05-01	\N	17	1	\N	\N	\N
577	William Henry	Holland	1849-12-15	1927-12-26	\N	9	1	\N	\N	\N
578	Christopher	Furness	1852-04-23	1912-11-10	\N	7	1	\N	\N	\N
579	Charles	Hardinge	1858-06-20	1944-08-02	\N	9	1	\N	\N	\N
581	William Snowdon	Robson	1852-09-10	1918-09-11	\N	19	1	\N	\N	\N
582	Richard Burdon	Haldane	1856-07-30	1928-08-19	\N	9	1	\N	\N	\N
583	Edward Priaulx	Tennant	1859-05-31	1920-11-21	\N	21	1	\N	\N	\N
584	William Henry	Wills	1830-09-01	1911-01-29	\N	24	1	\N	\N	\N
585	Edward Arthur	Colebrooke	1861-10-12	1939-02-28	\N	4	1	\N	\N	\N
586	John	Sinclair	1860-07-07	1925-01-11	\N	20	1	\N	\N	\N
587	William Thomas	Lewis	1837-08-05	1914-08-27	\N	13	1	\N	\N	\N
588	James Lyle	Mackay	1852-09-11	1932-05-23	\N	14	1	\N	\N	\N
590	Thomas Gair	Ashton	1855-02-05	1933-05-01	\N	2	1	\N	\N	\N
591	Godfrey Rathbone	Benson	1864-11-06	1945-02-03	\N	3	1	\N	\N	\N
592	Montolieu Fox	Murray	1840-04-27	1927-02-20	\N	14	1	\N	\N	\N
593	Wentworth Canning Blackett	Beaumont	1860-12-02	1923-12-12	\N	3	1	\N	\N	\N
594	Aretas	Akers-Douglas	1851-10-21	1926-01-15	\N	2	1	\N	\N	\N
595	Alfred	Emmott	1858-05-08	1926-12-13	\N	6	1	\N	\N	\N
596	Edward	Strachey	1858-10-30	1936-07-25	\N	20	1	\N	\N	\N
597	Alfred	Thomas	1840-09-16	1927-12-14	\N	21	1	\N	\N	\N
600	Francis Allston	Channing	1841-03-21	1926-02-20	\N	4	1	\N	\N	\N
601	William Gustavus	Nicholson	1845-03-02	1918-09-13	\N	15	1	\N	\N	\N
602	Alexander William Charles Oliphant	Murray	1870-04-12	1920-09-13	\N	14	1	\N	\N	\N
603	John Fletcher	Moulton	1844-11-18	1921-03-09	\N	14	1	\N	\N	\N
604	Thomas Banks	Borthwick	1874-08-21	1967-09-29	\N	3	1	\N	\N	\N
605	George Sydenham	Clarke	1848-07-04	1933-02-07	\N	4	1	\N	\N	\N
606	Charles Robert	Wynn-Carrington	1843-05-16	1928-06-13	\N	24	1	\N	\N	\N
607	George	Kemp	1866-06-09	1945-03-24	\N	12	1	\N	\N	\N
608	John Andrew	Hamilton	1859-02-03	1934-05-24	\N	9	1	\N	\N	\N
609	Rufus Daniel	Isaacs	1860-10-10	1935-12-30	\N	10	1	\N	\N	\N
610	Alexander	Ure	1853-02-24	1928-10-02	\N	22	1	\N	\N	\N
611	Charles Alfred	Cripps	1852-10-03	1941-06-30	\N	4	1	\N	\N	\N
612	Harold Sidney	Harmsworth	1868-04-26	1940-11-26	\N	9	1	\N	\N	\N
613	James	Bryce	1838-05-10	1922-01-22	\N	3	1	\N	\N	\N
614	Sydney Charles	Buxton	1853-10-25	1934-10-15	\N	3	1	\N	\N	\N
616	Edgar	Vincent	1857-08-19	1941-11-01	\N	23	1	\N	\N	\N
618	Leonard	Lyell	1850-10-21	1926-09-18	\N	13	1	\N	\N	\N
619	Alexander	Fuller-Acland-Hood	1853-09-26	1917-06-04	\N	7	1	\N	\N	\N
620	Thomas David	Gibson-Carmichael	1859-03-18	1926-01-16	\N	8	1	\N	\N	\N
621	Arthur John	Bigge	1849-06-18	1931-03-31	\N	3	1	\N	\N	\N
622	Stanley Owen	Buckmaster	1861-01-09	1934-12-05	\N	3	1	\N	\N	\N
623	Francis Leveson	Bertie	1844-08-17	1919-09-26	\N	3	1	\N	\N	\N
625	John Denton Pinkstone	French	1852-09-28	1925-05-22	\N	7	1	\N	\N	\N
626	Charles William de la Poer	Beresford	1846-02-10	1919-09-06	\N	3	1	\N	\N	\N
627	Alexander	Henderson	1850-09-28	1934-03-17	\N	9	1	\N	\N	\N
628	Thomas George	Shaughnessy	1853-10-06	1923-12-10	\N	20	1	\N	\N	\N
629	William Waldorf	Astor	1848-03-31	1919-10-18	\N	2	1	\N	\N	\N
630	Cecil William	Norton	1850-06-23	1930-12-07	\N	15	1	\N	\N	\N
631	David Alfred	Thomas	1856-03-26	1918-07-03	\N	21	1	\N	\N	\N
632	Henry	Chaplin	1840-12-22	1923-05-29	\N	4	1	\N	\N	\N
634	Arthur	Nicolson	1849-09-19	1928-11-05	\N	15	1	\N	\N	\N
635	Tonman	Mosley	1850-01-16	1933-08-20	\N	14	1	\N	\N	\N
636	George	Coats	1849-02-11	1918-11-26	\N	4	1	\N	\N	\N
638	Edward	Grey	1862-04-25	1933-09-07	\N	8	1	\N	\N	\N
639	Charles Beilby	Stuart-Wortley	1851-09-15	1926-04-24	\N	20	1	\N	\N	\N
640	William Maxwell	Aitken	1879-05-25	1964-06-09	\N	2	1	\N	\N	\N
641	Lewis	Harcourt	1863-01-31	1922-02-24	\N	9	1	\N	\N	\N
642	Joseph Albert	Pease	1860-01-17	1943-02-15	\N	17	1	\N	\N	\N
643	John Alexander	Dewar	1856-06-06	1929-11-23	\N	5	1	\N	\N	\N
644	Thomas	Roe	1832-07-13	1923-06-07	\N	19	1	\N	\N	\N
645	Edward	Partington	\N	1925-01-05	\N	17	1	\N	\N	\N
646	Hugh	Graham	1848-07-18	1938-01-28	\N	8	1	\N	\N	\N
647	Arthur	Annesley	1843-08-23	1927-01-20	\N	2	1	\N	\N	\N
649	Ivor John Caradoc	Herbert	1851-07-15	1933-10-18	\N	9	1	\N	\N	\N
650	William Hesketh	Lever	1851-09-19	1925-05-07	\N	13	1	\N	\N	\N
651	Frederick Henry	Smith	1859-01-24	1946-01-26	\N	20	1	\N	\N	\N
652	Richard Godolphin Walmesley	Chaloner	1856-10-12	1938-01-23	\N	4	1	\N	\N	\N
653	Walter	Cunliffe	1855-12-04	1920-01-06	\N	4	1	\N	\N	\N
654	Henry Burton	Buckley	1845-09-15	1935-10-27	\N	3	1	\N	\N	\N
656	Edward Patrick	Morris	1858-05-08	1935-10-24	\N	14	1	\N	\N	\N
657	Marmaduke	Furness	1883-10-29	1940-10-06	\N	7	1	\N	\N	\N
658	Frederick	Cawley	1850-10-09	1937-03-30	\N	4	1	\N	\N	\N
659	John Brownlee	Lonsdale	1850-03-23	1924-06-08	\N	13	1	\N	\N	\N
553	Richard Henn	Collins	1842-01-01	1911-01-03	\N	4	1	\N	\N	\N
2793	Roderick Francis Arthur	Balfour	1948-12-09	\N	\N	3	1	\N	\N	\N
663	William Douglas	Weir	1877-05-12	1959-07-02	\N	24	1	\N	\N	\N
664	William James	Tatem	1868-03-06	1942-06-28	\N	21	1	\N	\N	\N
665	George Denison	Faber	1851-12-14	1931-02-01	\N	7	1	\N	\N	\N
666	Harry Lawson Webster	Levy-Lawson	1862-12-18	1933-07-20	\N	13	1	\N	\N	\N
667	Ignatius John	O'Brien	1857-07-31	1930-09-10	\N	16	1	\N	\N	\N
668	Walter George Frank	Phillimore	1845-11-21	1929-03-13	\N	17	1	\N	\N	\N
669	Arthur Hamilton	Lee	1868-11-08	1947-07-21	\N	13	1	\N	\N	\N
670	Charles	Bathurst	1867-09-21	1958-07-03	\N	3	1	\N	\N	\N
671	William	Pickford	1848-10-01	1923-08-17	\N	17	1	\N	\N	\N
673	Frederick Edwin	Smith	1872-07-12	1930-09-30	\N	20	1	\N	\N	\N
674	Rowland Edmund	Prothero	1851-09-06	1937-07-01	\N	17	1	\N	\N	\N
676	Andrew	Weir	1865-04-24	1955-09-17	\N	24	1	\N	\N	\N
677	Satyendra Prasanna	Sinha	1864-06-01	1928-03-05	\N	20	1	\N	\N	\N
678	George Ranken	Askwith	1861-02-17	1942-06-02	\N	2	1	\N	\N	\N
679	Robert Bannatyne	Finlay	1842-07-11	1929-03-09	\N	7	1	\N	\N	\N
680	Robert	Chalmers	1858-08-18	1938-11-17	\N	4	1	\N	\N	\N
682	John Herbert	Roberts	1863-08-08	1955-12-19	\N	19	1	\N	\N	\N
683	Thomas Robert	Dewar	1864-01-06	1930-04-11	\N	5	1	\N	\N	\N
684	David	Beatty	1871-01-17	1936-03-11	\N	3	1	\N	\N	\N
685	Henry Seymour	Rawlinson	1864-02-20	1925-03-28	\N	19	1	\N	\N	\N
686	Edmund Henry Hynman	Allenby	1861-04-23	1936-05-14	\N	2	1	\N	\N	\N
687	Julian Hedworth George	Byng	1862-09-11	1935-06-06	\N	3	1	\N	\N	\N
688	Henry Sinclair	Horne	1861-02-19	1929-08-14	\N	9	1	\N	\N	\N
689	William Hall	Walker	1856-12-25	1933-02-02	\N	24	1	\N	\N	\N
690	Charles Swinfen	Eady	1851-07-31	1919-11-15	\N	6	1	\N	\N	\N
691	Rosslyn Erskine	Wemyss	1864-04-12	1933-05-24	\N	24	1	\N	\N	\N
692	James Scorgie	Meston	1865-06-12	1943-10-07	\N	14	1	\N	\N	\N
694	Bertrand Edward	Dawson	1864-03-09	1945-03-07	\N	5	1	\N	\N	\N
696	Brien Ibrican	Cokayne	1864-07-12	1932-11-03	\N	4	1	\N	\N	\N
697	William	Beardmore	1856-10-16	1936-04-09	\N	3	1	\N	\N	\N
698	Ronald Craufurd	Munro-Ferguson	1860-03-06	1934-03-30	\N	14	1	\N	\N	\N
699	Ernest	Cable	1859-12-01	1927-03-28	\N	4	1	\N	\N	\N
700	Mathew Lewis	Vaughan-Davies	1840-12-17	1935-08-21	\N	23	1	\N	\N	\N
701	James Alexander Francis Humberston	Stewart-Mackenzie	1847-10-09	1923-03-03	\N	20	1	\N	\N	\N
702	Marcus	Samuel	1853-11-05	1927-01-17	\N	20	1	\N	\N	\N
703	Edmund Bernard	Talbot	1855-06-01	1947-05-18	\N	21	1	\N	\N	\N
704	Edward Henry	Carson	1854-02-09	1935-10-22	\N	4	1	\N	\N	\N
705	Frederic John Napier	Thesiger	1868-08-12	1933-04-01	\N	21	1	\N	\N	\N
706	Walter Hume	Long	1854-07-13	1924-09-26	\N	13	1	\N	\N	\N
707	Albert Holden	Illingworth	1865-05-25	1942-01-23	\N	10	1	\N	\N	\N
710	Louis Alexander	Mountbatten	1854-05-24	1921-09-11	\N	14	1	\N	\N	\N
711	George Nathaniel	Curzon	1859-01-11	1925-03-20	\N	4	1	\N	\N	\N
712	James Henry	Dalziel	1868-04-24	1935-07-15	\N	5	1	\N	\N	\N
713	Ailwyn Edward	Fellowes	1855-11-10	1924-09-23	\N	7	1	\N	\N	\N
714	Robert	Nivison	1849-07-03	1930-06-14	\N	15	1	\N	\N	\N
715	James	Buchanan	1849-08-16	1935-08-09	\N	3	1	\N	\N	\N
716	James William	Lowther	1855-04-01	1949-03-27	\N	13	1	\N	\N	\N
717	James Henry Mussen	Campbell	1851-04-04	1931-03-22	\N	4	1	\N	\N	\N
718	Alfred Tristram	Lawrence	1843-11-24	1936-08-03	\N	13	1	\N	\N	\N
719	Douglas	Haig	1861-06-19	1928-01-29	\N	9	1	\N	\N	\N
720	Herbert Charles Onslow	Plumer	1857-03-13	1932-07-16	\N	17	1	\N	\N	\N
721	Edward Richard	Russell	1834-08-09	1920-02-20	\N	19	1	\N	\N	\N
722	William	Vestey	1859-01-21	1940-12-10	\N	23	1	\N	\N	\N
724	Robert Hudson	Borwick	1845-01-21	1936-01-27	\N	3	1	\N	\N	\N
725	Charles Napier	Lawrence	1855-05-27	1927-12-17	\N	13	1	\N	\N	\N
726	Francis Bingham	Mildmay	1861-04-26	1947-02-08	\N	14	1	\N	\N	\N
727	Joseph Paton	Maclay	1857-09-06	1951-04-24	\N	14	1	\N	\N	\N
728	Edward Alfred	Goulding	1862-11-05	1936-07-17	\N	8	1	\N	\N	\N
729	John Henry	Bethell	1861-09-23	1945-05-27	\N	3	1	\N	\N	\N
730	Herbert Pike	Pease	1867-05-07	1949-05-10	\N	17	1	\N	\N	\N
731	Owen Cosby	Philipps	1863-03-25	1937-06-05	\N	17	1	\N	\N	\N
732	George	Younger	1851-10-13	1929-04-29	\N	26	1	\N	\N	\N
734	Herbert Merton	Jessel	1866-10-27	1950-11-01	\N	11	1	\N	\N	\N
735	Robert	Younger	1861-09-12	1946-08-17	\N	26	1	\N	\N	\N
737	Charles John	Darling	1849-12-06	1936-05-29	\N	5	1	\N	\N	\N
738	Frederick George	Banbury	1850-12-02	1936-08-13	\N	3	1	\N	\N	\N
739	John George	Butcher	1853-11-15	1935-06-30	\N	3	1	\N	\N	\N
740	Sydney Haldane	Olivier	1859-04-16	1943-02-15	\N	16	1	\N	\N	\N
741	Christopher Birdwood	Thomson	1875-04-13	1930-10-05	\N	21	1	\N	\N	\N
742	Sydney	Arnold	1878-01-13	1945-08-03	\N	2	1	\N	\N	\N
743	James	Stevenson	1873-04-02	1926-06-10	\N	20	1	\N	\N	\N
745	John Swanwick	Bradbury	1872-09-23	1950-05-03	\N	3	1	\N	\N	\N
746	John Denton Pinkstan	French	1852-09-28	1925-05-22	\N	7	1	\N	\N	\N
747	Geoffrey Henry	Browne	1861-01-06	1927-06-30	\N	3	1	\N	\N	\N
748	John Lawrence	Baird	1874-04-27	1941-08-20	\N	3	1	\N	\N	\N
749	George Ambrose	Lloyd	1879-09-19	1941-02-04	\N	13	1	\N	\N	\N
750	Edward Frederick Lindley	Wood	1881-04-16	1959-12-23	\N	24	1	\N	\N	\N
751	Ernest Murray	Pollock	1861-11-25	1936-10-22	\N	17	1	\N	\N	\N
752	Francis	Willey	1841-02-27	1929-02-16	\N	24	1	\N	\N	\N
753	Archibald	Williamson	1860-09-13	1931-10-29	\N	24	1	\N	\N	\N
754	Gordon	Hewart	1870-01-07	1943-05-05	\N	9	1	\N	\N	\N
757	Thomas Rolls	Warrington	1851-05-29	1937-10-26	\N	24	1	\N	\N	\N
758	James	Craig	1871-01-08	1940-11-24	\N	4	1	\N	\N	\N
759	George Hayter	Chubb	1848-08-29	1946-11-07	\N	4	1	\N	\N	\N
760	Fiennes Stanley Wykeham	Cornwallis	1864-05-27	1935-09-26	\N	4	1	\N	\N	\N
761	Gilbert	Greenall	1867-03-30	1938-10-24	\N	8	1	\N	\N	\N
762	Davison Alexander	Dalziel	1852-10-17	1928-04-18	\N	5	1	\N	\N	\N
763	George Abraham	Gibbs	1873-07-06	1931-10-28	\N	8	1	\N	\N	\N
764	Ronald John	McNeill	1861-04-30	1934-10-12	\N	14	1	\N	\N	\N
765	Gerald	Strickland	1861-05-24	1940-08-22	\N	20	1	\N	\N	\N
873	Walter	Runciman	1870-11-19	1949-11-14	\N	19	1	\N	\N	\N
2794	Sholto Douglas	Campbell	1839-06-28	1916-09-30	\N	4	1	\N	\N	\N
768	Alfred Moritz	Mond	1868-10-23	1930-12-27	\N	14	1	\N	\N	\N
769	Douglas McGarel	Hogg	1872-02-28	1950-08-16	\N	9	1	\N	\N	\N
771	James Farquharson	Remnant	1862-02-13	1933-01-30	\N	19	1	\N	\N	\N
772	George Rowland	Blades	1868-04-15	1953-05-24	\N	3	1	\N	\N	\N
773	Jesse	Boot	1850-06-02	1931-06-13	\N	3	1	\N	\N	\N
775	Thomas James Chesshyre	Tomlin	1867-05-06	1935-08-12	\N	21	1	\N	\N	\N
776	Berkeley George Andrew	Moynihan	1865-10-02	1936-09-07	\N	14	1	\N	\N	\N
777	Urban Huttleston Rogers	Broughton	1896-08-31	1966-08-20	\N	3	1	\N	\N	\N
778	Edward Allen	Brotherton	1856-04-01	1930-10-21	\N	3	1	\N	\N	\N
779	William	Watson	1873-12-08	1948-06-13	\N	24	1	\N	\N	\N
780	Thomas, L	Shaw	1850-05-23	1937-06-28	\N	20	1	\N	\N	\N
781	William Clive	Bridgeman	1864-12-31	1935-08-14	\N	3	1	\N	\N	\N
782	Robert Arthur	Sanders	1867-06-20	1940-02-24	\N	20	1	\N	\N	\N
784	Herbert Henry	Asquith	1852-09-12	1928-02-15	\N	2	1	\N	\N	\N
785	John	Sankey	1866-10-26	1948-02-06	\N	20	1	\N	\N	\N
786	Sidney James	Webb	1859-07-13	1947-10-13	\N	24	1	\N	\N	\N
787	William	Joynson-Hicks	1865-06-23	1932-06-08	\N	11	1	\N	\N	\N
788	Gilbert Alan Hamilton	Wills	1880-03-28	1956-12-01	\N	24	1	\N	\N	\N
789	George	Lawson-Johnston	1873-09-09	1943-02-23	\N	13	1	\N	\N	\N
790	William Robert Wellesley	Peel	1867-01-07	1937-09-28	\N	17	1	\N	\N	\N
791	Henry Seymour	Berry	1877-09-17	1928-05-23	\N	3	1	\N	\N	\N
792	Dudley Leigh	Aman	1884-05-16	1952-02-29	\N	2	1	\N	\N	\N
795	Willoughby Hyett	Dickinson	1859-04-09	1943-05-31	\N	5	1	\N	\N	\N
796	Charles Cheers	Wakefield	1859-12-12	1941-01-15	\N	24	1	\N	\N	\N
797	William Joseph	Noble	1863-01-13	1935-09-11	\N	15	1	\N	\N	\N
798	Hugh Montague	Trenchard	1873-02-03	1956-02-10	\N	21	1	\N	\N	\N
799	Noel Edward	Buxton	1869-01-09	1948-09-12	\N	3	1	\N	\N	\N
800	Henry Sanderson	Furniss	1868-10-01	1939-03-25	\N	7	1	\N	\N	\N
801	Hugh Pattison	Macmillan	1873-02-20	1952-09-05	\N	14	1	\N	\N	\N
802	Esme William	Howard	1863-09-15	1939-08-01	\N	9	1	\N	\N	\N
803	William	Plender	1861-08-20	1946-01-19	\N	17	1	\N	\N	\N
804	John Scott	Hindley	1883-10-24	1963-01-05	\N	9	1	\N	\N	\N
805	Ernest	Rutherford	1871-08-30	1937-10-19	\N	19	1	\N	\N	\N
806	Ernest Henry	Lamb	1876-09-04	1955-01-13	\N	13	1	\N	\N	\N
808	Robert Hunt Stapylton Dudley Lydston	Newman	1871-10-27	1945-11-02	\N	15	1	\N	\N	\N
809	Henry	Snell	1865-04-01	1944-04-21	\N	20	1	\N	\N	\N
810	William Martin	Conway	1856-04-12	1937-04-19	\N	4	1	\N	\N	\N
811	Wilfrid William	Ashley	1867-09-13	1939-07-03	\N	2	1	\N	\N	\N
812	William Lowson	Mitchell-Thomson	1877-04-15	1938-12-24	\N	14	1	\N	\N	\N
813	Reginald Clifford	Allen	1889-05-09	1939-03-03	\N	2	1	\N	\N	\N
815	Leifchild Stratten	Jones	1862-01-16	1939-09-26	\N	11	1	\N	\N	\N
816	Arthur Charles	Churchman	1867-09-07	1949-02-03	\N	4	1	\N	\N	\N
817	Frederick William	Lewis	1870-05-25	1944-06-24	\N	13	1	\N	\N	\N
818	Robert Alderson	Wright	1869-10-15	1964-06-27	\N	24	1	\N	\N	\N
819	David	Davies	1880-05-11	1944-06-16	\N	5	1	\N	\N	\N
820	James Fitzalan	Hope	1870-12-11	1949-02-14	\N	9	1	\N	\N	\N
821	Robert	Hutchison	1873-09-05	1950-06-13	\N	9	1	\N	\N	\N
822	Charles Alexander	Nall-Cain	1866-05-29	1934-11-21	\N	15	1	\N	\N	\N
823	Thomas Jeeves	Horder	1871-01-07	1955-08-13	\N	9	1	\N	\N	\N
825	Joseph	Duveen	1869-10-14	1939-05-25	\N	5	1	\N	\N	\N
827	William Warrender	Mackenzie	1860-08-19	1942-05-05	\N	14	1	\N	\N	\N
828	William George	Tyrrell	1866-08-17	1947-03-14	\N	21	1	\N	\N	\N
829	Samuel Ernest	Palmer	1858-03-28	1948-12-08	\N	17	1	\N	\N	\N
830	George Richard	Lane-Fox	1870-12-15	1947-12-11	\N	13	1	\N	\N	\N
831	Evelyn	Cecil	1865-05-30	1941-04-01	\N	4	1	\N	\N	\N
832	Bertram Godfray	Falle	1859-11-21	1948-11-01	\N	7	1	\N	\N	\N
833	George Douglas Cochrane	Newton	1879-07-14	1942-09-02	\N	15	1	\N	\N	\N
834	Godfrey	Elton	1892-03-29	1973-04-18	\N	6	1	\N	\N	\N
835	Robert	Munro	1868-05-28	1955-10-06	\N	14	1	\N	\N	\N
836	Hugo	Hirst	1863-11-26	1943-01-22	\N	9	1	\N	\N	\N
838	Henry Bucknall	Betterton	1872-08-15	1949-11-18	\N	3	1	\N	\N	\N
839	Thomas	Fermor-Hesketh	1881-11-17	1944-07-20	\N	7	1	\N	\N	\N
841	John	Buchan	1875-08-26	1940-02-11	\N	3	1	\N	\N	\N
842	Frederick Edward Grey	Ponsonby	1867-09-16	1935-10-20	\N	17	1	\N	\N	\N
843	Clive	Wigram	1873-07-05	1960-09-03	\N	24	1	\N	\N	\N
844	Arthur	Balfour	1873-01-09	1957-07-07	\N	3	1	\N	\N	\N
845	George Ernest	May	1871-06-20	1946-04-10	\N	14	1	\N	\N	\N
846	Edward Charles	Grenfell	1870-05-29	1941-11-26	\N	8	1	\N	\N	\N
848	Edward Hilton	Young	1879-03-20	1960-07-11	\N	26	1	\N	\N	\N
849	Frederic Herbert	Maugham	1866-10-21	1958-03-23	\N	14	1	\N	\N	\N
850	Alexander Adair	Roche	1871-07-24	1956-12-22	\N	19	1	\N	\N	\N
851	Philip	Cunliffe-Lister	1884-05-01	1972-07-27	\N	4	1	\N	\N	\N
852	Bolton Meredith	Eyres-Monsell	1881-02-22	1969-03-21	\N	6	1	\N	\N	\N
853	Alexander Gore Arkwright	Hore-Ruthven	1872-07-06	1955-05-02	\N	9	1	\N	\N	\N
854	Arthur Shirley	Benn	1858-12-20	1937-06-13	\N	3	1	\N	\N	\N
855	James Gomer	Berry	1883-05-07	1968-02-06	\N	3	1	\N	\N	\N
856	Thomas Sivewright	Catto	1879-03-15	1959-08-23	\N	4	1	\N	\N	\N
858	William Malcolm	Hailey	1872-02-15	1969-06-01	\N	9	1	\N	\N	\N
859	Herbert	Austin	1866-11-08	1941-05-23	\N	2	1	\N	\N	\N
860	James Rennell	Rodd	1858-11-09	1941-07-26	\N	19	1	\N	\N	\N
861	John Edward Bernard	Seely	1868-05-31	1947-11-07	\N	20	1	\N	\N	\N
862	Edward Mauger	Iliffe	1877-05-17	1960-07-25	\N	10	1	\N	\N	\N
863	Harry Duncan	McGowan	1874-06-03	1961-07-13	\N	14	1	\N	\N	\N
865	George Edward Wentworth	Bowyer	1886-01-16	1948-11-30	\N	3	1	\N	\N	\N
866	Walter Russell	Rea	1873-05-18	1948-05-26	\N	19	1	\N	\N	\N
868	John	Cadman	1877-09-07	1941-05-31	\N	4	1	\N	\N	\N
869	Stanley	Baldwin	1867-08-03	1947-12-14	\N	3	1	\N	\N	\N
870	Herbert Louis	Samuel	1870-11-06	1963-02-05	\N	20	1	\N	\N	\N
871	Frederick George	Penny	1876-03-10	1955-01-01	\N	17	1	\N	\N	\N
872	Robert Stevenson	Horne	1871-02-28	1940-09-03	\N	9	1	\N	\N	\N
767	James Richard	Atkin	1867-11-28	1944-06-25	\N	2	1	\N	\N	\N
2795	Barrington Bulkeley Douglas	Campbell	1845-02-18	1918-03-13	\N	4	1	\N	\N	\N
876	Julius Salter	Elias	1873-01-05	1946-04-10	\N	6	1	\N	\N	\N
877	John Cuthbert	Denison-Pender	1882-05-11	1949-12-04	\N	5	1	\N	\N	\N
878	William Richard	Morris	1877-10-10	1963-08-22	\N	14	1	\N	\N	\N
879	Mark Lemon	Romer	1866-08-09	1944-08-19	\N	19	1	\N	\N	\N
880	Henry Yarde Buller	Lopes	1859-03-24	1938-04-14	\N	13	1	\N	\N	\N
882	Henry Leonard Campbell	Brassey	1870-03-07	1958-10-22	\N	3	1	\N	\N	\N
883	Percival Lea Dewhurst	Perry	1878-03-18	1956-06-17	\N	17	1	\N	\N	\N
884	Samuel Lowry	Porter	1877-02-07	1956-02-13	\N	17	1	\N	\N	\N
885	Josiah Charles	Stamp	1880-06-21	1941-04-16	\N	20	1	\N	\N	\N
886	Vivian Hugh	Smith	1867-12-09	1956-02-17	\N	20	1	\N	\N	\N
887	Frederick Arthur	Greer	1863-10-01	1945-02-04	\N	8	1	\N	\N	\N
888	Laurence Richard	Philipps	1874-01-24	1962-12-07	\N	17	1	\N	\N	\N
889	Maurice Paschal Alers	Hankey	1877-04-01	1963-01-25	\N	9	1	\N	\N	\N
891	Arthur Richard de Capell	Brooke	1869-10-12	1944-11-17	\N	3	1	\N	\N	\N
892	Herbert Robin	Cayzer	1881-07-23	1958-03-17	\N	4	1	\N	\N	\N
893	Vere Brabazon	Ponsonby	1880-10-27	1956-03-10	\N	17	1	\N	\N	\N
894	Claude George	Bowes-Lyon	1855-03-14	1944-11-07	\N	3	1	\N	\N	\N
895	Freeman	Freeman-Thomas	1866-09-12	1941-08-12	\N	7	1	\N	\N	\N
896	Henry Edward	Lyons	1878-08-29	1963-08-17	\N	13	1	\N	\N	\N
897	Hamar	Greenwood	1870-02-07	1948-09-10	\N	8	1	\N	\N	\N
899	George Clement	Tryon	1871-05-15	1940-11-24	\N	21	1	\N	\N	\N
900	John Allsebrook	Simon	1873-02-28	1954-01-11	\N	20	1	\N	\N	\N
902	Charles Iain	Kerr	1874-05-03	1968-01-07	\N	12	1	\N	\N	\N
903	Harry Louis	Nathan	1889-02-02	1963-10-23	\N	15	1	\N	\N	\N
904	Hugh Richard Heathcote	Gascoyne-Cecil	1869-10-14	1956-12-10	\N	8	1	\N	\N	\N
905	Frank Boyd	Merriman	1880-04-28	1962-01-18	\N	14	1	\N	\N	\N
906	Robert Molesworth	Kindersley	1871-11-21	1954-07-20	\N	12	1	\N	\N	\N
907	William Edmund	Ironside	1880-05-06	1959-09-22	\N	10	1	\N	\N	\N
908	Robert Gilbert	Vansittart	1881-06-25	1957-02-14	\N	23	1	\N	\N	\N
909	Frederick James	Leathers	1883-11-21	1965-03-18	\N	13	1	\N	\N	\N
911	Wilfred Arthur	Greene	1883-12-30	1952-04-16	\N	8	1	\N	\N	\N
912	William Wedgwood	Benn	1877-05-10	1960-11-17	\N	3	1	\N	\N	\N
913	Herwald	Ramsbotham	1887-03-06	1971-01-31	\N	19	1	\N	\N	\N
915	Charles	Latham	1888-12-26	1970-03-31	\N	13	1	\N	\N	\N
916	Josiah Clement	Wedgwood	1872-03-16	1943-07-26	\N	24	1	\N	\N	\N
917	Auckland Campbell	Geddes	1879-06-21	1954-01-08	\N	8	1	\N	\N	\N
918	Reginald Thomas Herbert	Fletcher	1885-03-27	1961-06-07	\N	7	1	\N	\N	\N
920	John Maynard	Keynes	1883-06-05	1946-04-21	\N	12	1	\N	\N	\N
921	Victor Alexander George Anthony	Warrender	1899-06-23	1993-01-14	\N	24	1	\N	\N	\N
922	Cosmo Gordon	Lang	1864-10-31	1945-12-05	\N	13	1	\N	\N	\N
923	Henry David	Margesson	1890-07-26	1965-12-24	\N	14	1	\N	\N	\N
924	John Theodore Cuthbert	Moore-Brabazon	1884-02-08	1964-05-17	\N	14	1	\N	\N	\N
925	Roger John Brownlow	Keyes	1872-10-04	1945-12-26	\N	12	1	\N	\N	\N
926	Charles McMoran	Wilson	1882-11-10	1977-04-12	\N	24	1	\N	\N	\N
927	Dennis Henry	Herbert	1869-02-25	1947-12-10	\N	9	1	\N	\N	\N
928	Miles Wedderburn	Lampson	1880-08-24	1964-09-18	\N	13	1	\N	\N	\N
929	Muriel	FitzRoy	1869-08-08	1962-07-08	\N	7	2	\N	\N	\N
931	Thomas	Royden	1871-05-22	1950-11-06	\N	19	1	\N	\N	\N
932	Archibald Percival	Wavell	1883-05-05	1950-05-24	\N	24	1	\N	\N	\N
933	Herbert	Dixon	1880-01-23	1950-07-20	\N	5	1	\N	\N	\N
934	Charles Coupar	Barrie	\N	1940-12-06	\N	3	1	\N	\N	\N
935	Thomas Walker Hobart	Inskip	1876-03-05	1947-10-11	\N	10	1	\N	\N	\N
936	Gavin Turnbull	Simonds	1881-11-28	1971-06-28	\N	20	1	\N	\N	\N
938	Rayner	Goddard	1877-04-10	1971-05-29	\N	8	1	\N	\N	\N
939	Montagu Collet	Norman	1871-09-06	1950-02-04	\N	15	1	\N	\N	\N
940	David	Lloyd-George	1863-01-17	1945-03-26	\N	13	1	\N	\N	\N
942	Douglas Hewitt	Hacking	1884-08-04	1950-07-29	\N	9	1	\N	\N	\N
943	George Loyd	Courthope	1877-06-12	1955-09-02	\N	4	1	\N	\N	\N
944	William Frederick	Jackson	1893-11-29	1954-05-02	\N	11	1	\N	\N	\N
945	David John Kinsley	Quibell	1879-12-21	1962-04-16	\N	18	1	\N	\N	\N
946	Alexander George	Walkden	1873-05-11	1951-04-25	\N	24	1	\N	\N	\N
947	Philip Walhouse	Chetwode	1869-09-21	1950-07-06	\N	4	1	\N	\N	\N
948	William	Cope	1870-08-18	1946-07-15	\N	4	1	\N	\N	\N
950	William	Brass	1886-02-11	1945-08-24	\N	3	1	\N	\N	\N
951	Albert James	Edmondson	1886-06-29	1959-05-16	\N	6	1	\N	\N	\N
952	George	Lambert	1866-06-25	1958-02-17	\N	13	1	\N	\N	\N
953	Edward William Macleay	Grigg	1879-09-08	1955-12-01	\N	8	1	\N	\N	\N
954	William Allen	Jowitt	1885-04-15	1957-08-16	\N	11	1	\N	\N	\N
955	Frederick William	Pethick-Lawrence	1871-12-28	1961-09-17	\N	17	1	\N	\N	\N
956	John Jestyn	Llewellin	1893-02-06	1957-01-24	\N	13	1	\N	\N	\N
958	George Thomas	Broadbridge	1869-02-13	1952-04-17	\N	3	1	\N	\N	\N
959	Andrew Browne	Cunningham	1883-01-07	1963-06-12	\N	4	1	\N	\N	\N
960	Alan Francis	Brooke	1883-07-23	1963-06-17	\N	3	1	\N	\N	\N
961	William Henry	Davison	\N	1953-01-19	\N	5	1	\N	\N	\N
963	William Watson	Henderson	1891-08-08	1984-04-04	\N	9	1	\N	\N	\N
964	Edward Ratcliffe Garth Russell	Evans	1881-10-28	1957-08-20	\N	6	1	\N	\N	\N
965	Courtauld Greenwood	Courtauld-Thomson	1865-08-16	1954-11-01	\N	4	1	\N	\N	\N
966	Claud	Schuster	1869-08-22	1956-06-28	\N	20	1	\N	\N	\N
967	Robert Samuel Theodore	Chorley	1895-05-29	1978-01-27	\N	4	1	\N	\N	\N
968	George	Muff	1877-02-10	1955-09-20	\N	14	1	\N	\N	\N
969	Robert Alexander	Palmer	1890-11-29	1977-08-18	\N	17	1	\N	\N	\N
971	Colin Frederick	Campbell	1866-06-13	1954-11-03	\N	4	1	\N	\N	\N
972	Philip Albert	Inman	1892-06-12	1979-08-26	\N	10	1	\N	\N	\N
973	Bernard Law	Montgomery	1887-11-17	1976-03-24	\N	14	1	\N	\N	\N
974	John Cronyn	Tovey	1885-03-07	1971-01-12	\N	21	1	\N	\N	\N
975	Herbert	du Parcq	1880-08-05	1949-04-27	\N	5	1	\N	\N	\N
976	John Standish Surtees Prendergast	Vereker	1886-07-10	1946-03-31	\N	23	1	\N	\N	\N
977	John Percival	Davies	1885-03-28	1950-12-26	\N	5	1	\N	\N	\N
978	Henry Maitland	Wilson	1881-09-05	1964-12-31	\N	24	1	\N	\N	\N
875	John Colin Campbell	Davidson	1889-02-23	1970-12-11	\N	5	1	\N	\N	\N
2796	Archibald	Campbell	1870-04-25	1929-11-14	\N	4	1	\N	\N	\N
982	George William	Lucas	1896-03-29	1967-10-11	\N	13	1	\N	\N	\N
983	Walter McLennan	Citrine	1887-08-22	1983-01-22	\N	4	1	\N	\N	\N
984	Robert Henry	Brand	1878-10-30	1963-08-23	\N	3	1	\N	\N	\N
985	Cyril Louis Norton	Newall	1886-02-15	1963-11-30	\N	15	1	\N	\N	\N
987	Bruce Austin	Fraser	1888-02-05	1981-02-12	\N	7	1	\N	\N	\N
988	Geoffrey	Lawrence	1880-12-02	1971-08-28	\N	13	1	\N	\N	\N
989	Hastings Lionel	Ismay	1887-06-21	1965-12-17	\N	10	1	\N	\N	\N
990	George Henry	Hall	1881-12-31	1965-11-08	\N	9	1	\N	\N	\N
992	John Loader	Maffey	1877-07-01	1969-04-20	\N	14	1	\N	\N	\N
993	Walter Thomas	Layton	1884-03-15	1966-02-14	\N	13	1	\N	\N	\N
994	Ernest Darwin	Simon	1879-10-09	1960-10-03	\N	20	1	\N	\N	\N
995	Fred	Kershaw	1881-11-06	1961-02-05	\N	12	1	\N	\N	\N
996	George Morgan	Garro-Jones	1894-09-14	1960-09-27	\N	8	1	\N	\N	\N
997	Stanley Melbourne	Bruce	1883-04-15	1967-08-25	\N	3	1	\N	\N	\N
998	William	Piercy	1886-02-07	1966-07-07	\N	17	1	\N	\N	\N
999	Robert Craigmyle	Morrison	1881-10-29	1953-12-25	\N	14	1	\N	\N	\N
1000	Arthur William	Tedder	1890-07-11	1967-06-03	\N	21	1	\N	\N	\N
1001	Frederick	Montague	1876-10-08	1966-10-15	\N	14	1	\N	\N	\N
1003	William Sholto	Douglas	1893-12-23	1969-10-30	\N	5	1	\N	\N	\N
1004	Valentine George	Crittall	1884-06-28	1961-05-21	\N	4	1	\N	\N	\N
1005	David John	Colville	1894-02-13	1954-10-31	\N	4	1	\N	\N	\N
1006	Alfred Edward	Webb-Johnson	1880-09-04	1958-05-28	\N	24	1	\N	\N	\N
1008	Thomas Edward	Williams	1892-07-26	1966-02-18	\N	24	1	\N	\N	\N
1009	John Jackson	Adams	1890-10-12	1960-08-23	\N	2	1	\N	\N	\N
1010	James Scott Cumberland	Reid	1890-07-30	1975-03-29	\N	19	1	\N	\N	\N
1011	John	Boyd-Orr	1880-09-23	1971-06-25	\N	3	1	\N	\N	\N
1012	Henry John Fanshawe	Badeley	1874-06-27	1951-09-27	\N	3	1	\N	\N	\N
1013	Gordon	Macdonald	1888-05-27	1966-01-20	\N	14	1	\N	\N	\N
1015	George	Archibald	1898-07-21	1975-02-25	\N	2	1	\N	\N	\N
1016	John	Wilmot	1895-04-02	1964-07-22	\N	24	1	\N	\N	\N
1017	Alexander Steven	Bilsland	1892-09-13	1970-12-10	\N	3	1	\N	\N	\N
1018	Thomas William	Burden	1885-01-29	1970-05-27	\N	3	1	\N	\N	\N
1019	Leslie Haden	Haden-Guest	1877-03-10	1960-08-20	\N	9	1	\N	\N	\N
1020	Joseph	Henderson	\N	1950-02-26	\N	9	1	\N	\N	\N
1021	Lewis	Silkin	1889-11-14	1972-05-11	\N	20	1	\N	\N	\N
1022	John James	Lawson	1881-10-16	1965-08-03	\N	13	1	\N	\N	\N
1024	Cyril William	Hurcomb	1883-02-18	1975-08-07	\N	9	1	\N	\N	\N
1025	Gilbert Francis Montriou	Campion	1882-05-11	1958-04-06	\N	4	1	\N	\N	\N
1026	Ernest Walter	Hives	1886-04-21	1965-04-24	\N	9	1	\N	\N	\N
1027	Ernest	Greenhill	1887-04-23	1967-02-18	\N	8	1	\N	\N	\N
1028	David Rees	Rees-Williams	1903-11-22	1976-08-30	\N	19	1	\N	\N	\N
1029	Harry	Morris	1893-10-07	1954-07-01	\N	14	1	\N	\N	\N
1031	Thomas	Macpherson	1888-07-09	1965-06-13	\N	14	1	\N	\N	\N
1032	Frederick James	Tucker	1888-05-22	1975-11-17	\N	21	1	\N	\N	\N
1033	Archibald	Crawford	1890-09-12	1966-06-14	\N	4	1	\N	\N	\N
1035	Cyril	Asquith	1890-02-05	1954-08-24	\N	2	1	\N	\N	\N
1036	John Clarke	MacDermott	1896-04-12	1979-07-13	\N	14	1	\N	\N	\N
1037	Roy Lister	Robinson	1883-03-08	1952-09-05	\N	19	1	\N	\N	\N
1038	Lionel Leonard	Cohen	1888-03-01	1973-05-09	\N	4	1	\N	\N	\N
1039	Douglas Clifton	Brown	1879-08-16	1958-05-05	\N	3	1	\N	\N	\N
1040	David	Kirkwood	1872-07-08	1955-04-16	\N	12	1	\N	\N	\N
1041	Frederick John	Wise	1887-04-10	1968-11-20	\N	24	1	\N	\N	\N
1042	Robert Spear	Hudson	1886-08-15	1957-02-02	\N	9	1	\N	\N	\N
1043	John	Anderson	1882-07-08	1958-01-04	\N	2	1	\N	\N	\N
1044	George	Mathers	1886-02-28	1965-09-26	\N	14	1	\N	\N	\N
1045	Edward	Turnour	1883-04-04	1962-08-26	\N	21	1	\N	\N	\N
1048	Basil Stanlake	Brooke	1888-06-09	1973-08-18	\N	3	1	\N	\N	\N
1049	Alfred Duff	Cooper	1890-02-22	1954-01-01	\N	4	1	\N	\N	\N
1050	George Darell	Jeffreys	1878-03-08	1960-12-19	\N	11	1	\N	\N	\N
1051	Robert William Hugh	O'Neill	1883-06-08	1982-11-28	\N	16	1	\N	\N	\N
1052	Eustace Sutherland Campbell	Percy	1887-03-21	1958-04-03	\N	17	1	\N	\N	\N
1053	Ralph George Campbell	Glyn	1885-03-03	1960-05-01	\N	8	1	\N	\N	\N
1054	Alfred Jesse	Suenson-Taylor	1893-08-14	1976-07-02	\N	20	1	\N	\N	\N
1055	Peter Frederick Blaker	Bennett	1880-04-16	1957-09-29	\N	3	1	\N	\N	\N
1056	Frederick James	Marquis	1883-08-24	1964-12-14	\N	14	1	\N	\N	\N
1057	Leslie	Hore-Belisha	1893-09-07	1957-02-16	\N	9	1	\N	\N	\N
1058	William	Strang	1893-01-02	1978-05-27	\N	20	1	\N	\N	\N
1060	James	Keith	1886-05-20	1964-06-29	\N	12	1	\N	\N	\N
1061	Joseph Stanley	Holmes	1878-10-31	1961-04-22	\N	9	1	\N	\N	\N
1062	Henry Charles Ponsonby	Moore	1884-04-21	1957-11-22	\N	14	1	\N	\N	\N
1063	Richard Kidston	Law	1901-02-27	1980-11-15	\N	13	1	\N	\N	\N
1064	Oliver Charles	Harvey	1893-11-26	1968-11-29	\N	9	1	\N	\N	\N
1065	Thomas Mackay	Cooper	1892-09-24	1955-07-15	\N	4	1	\N	\N	\N
1066	Ernest Albert	Whitfield	1887-09-15	1963-04-21	\N	24	1	\N	\N	\N
1067	Bernard	Freyberg	1889-03-21	1963-07-04	\N	7	1	\N	\N	\N
1068	Oliver	Lyttelton	1893-03-15	1972-01-21	\N	13	1	\N	\N	\N
1070	James	Milner	1889-08-12	1967-06-16	\N	14	1	\N	\N	\N
1072	Thomas Dunlop	Galbraith	1891-03-20	1985-07-12	\N	8	1	\N	\N	\N
1073	Henry George	Strauss	1892-06-24	1974-08-28	\N	20	1	\N	\N	\N
1074	Geoffrey	Heyworth	1894-10-18	1974-06-15	\N	9	1	\N	\N	\N
1075	Arnold Duncan	McNair	1885-03-04	1975-05-22	\N	14	1	\N	\N	\N
1076	Francis Raymond	Evershed	1899-08-08	1966-10-03	\N	6	1	\N	\N	\N
1077	Clement Richard	Attlee	1883-01-03	1967-10-08	\N	2	1	\N	\N	\N
1078	William Philip	Sidney	1909-05-23	1991-04-05	\N	20	1	\N	\N	\N
1080	Osbert	Peake	1897-12-30	1966-10-11	\N	17	1	\N	\N	\N
1081	James Purdon Lewes	Thomas	1903-10-13	1960-07-13	\N	21	1	\N	\N	\N
1082	Henry Lennox d'Aubigné	Hopkinson	1902-01-03	1996-01-06	\N	9	1	\N	\N	\N
1083	John Jacob	Astor	1886-05-20	1971-07-19	\N	2	1	\N	\N	\N
1084	Frederick	Godber	1888-11-06	1976-04-10	\N	8	1	\N	\N	\N
1085	Frederick Alexander	Lindemann	1886-04-05	1957-07-03	\N	13	1	\N	\N	\N
1086	Ronald Morce	Weeks	1890-11-13	1960-08-19	\N	24	1	\N	\N	\N
981	Archibald John Kerr	Clark Kerr	1882-03-17	1951-07-05	\N	4	1	\N	\N	\N
1089	Horace	Evans	1903-01-01	1963-10-26	\N	6	1	\N	\N	\N
1090	Percy Herbert	Mills	1890-01-04	1968-09-10	\N	14	1	\N	\N	\N
1092	Gwilym	Lloyd-George	1894-12-04	1967-02-14	\N	13	1	\N	\N	\N
1094	Alfred Thompson	Denning	1899-01-23	1999-03-05	\N	5	1	\N	\N	\N
1095	Joseph Arthur	Rank	1888-12-22	1972-03-29	\N	19	1	\N	\N	\N
1096	William Norman	Birkett	1883-09-06	1962-02-10	\N	3	1	\N	\N	\N
1097	David Vivian Penrose	Lewis	1905-08-14	1976-10-10	\N	13	1	\N	\N	\N
1098	Allan Francis	Harding	1896-02-10	1989-01-20	\N	9	1	\N	\N	\N
1099	Thomas Ellis	Robins	1884-10-31	1962-07-21	\N	19	1	\N	\N	\N
1100	Oliver Brian Sanderson	Poole	1911-08-11	1993-01-28	\N	17	1	\N	\N	\N
1101	William Jocelyn Ian	Fraser	1897-08-30	1974-12-19	\N	7	1	\N	\N	\N
1102	Victor John	Collins	1903-07-01	1971-12-22	\N	4	1	\N	\N	\N
1103	Charles John	Geddes	1897-03-01	1983-05-02	\N	8	1	\N	\N	\N
1104	John Sebastian Bach	Stopford	1888-06-25	1961-03-06	\N	20	1	\N	\N	\N
1105	Daniel Granville	West	1904-03-17	1984-09-23	\N	24	1	\N	\N	\N
1106	Edgar Douglas	Adrian	1889-11-30	1977-08-04	\N	2	1	\N	\N	\N
1107	William	Fraser	1888-11-03	1970-04-01	\N	7	1	\N	\N	\N
1109	Stella	Isaacs	1894-01-06	1971-05-22	\N	10	2	\N	\N	\N
1110	Victor Ferrier	Noel-Paton	1900-01-29	1992-06-04	\N	15	1	\N	\N	\N
1111	Katharine	Elliot	1903-01-15	1994-01-03	\N	6	2	\N	\N	\N
1112	Mary Irene	Curzon	1896-01-20	1966-02-09	\N	4	2	\N	\N	\N
1113	Hubert Lister	Parker	1900-05-28	1972-09-15	\N	17	1	\N	\N	\N
1116	Edwin Noel	Plowden	1907-01-06	2001-02-15	\N	17	1	\N	\N	\N
1117	Eric John Francis	James	1909-04-13	1992-05-16	\N	11	1	\N	\N	\N
1118	James	Turner	1908-01-06	1980-11-08	\N	21	1	\N	\N	\N
1119	Lionel Charles	Robbins	1898-11-22	1984-05-15	\N	19	1	\N	\N	\N
1120	David Llewelyn	Jenkins	1899-04-08	1969-07-21	\N	11	1	\N	\N	\N
1121	Thomas Lionel	Dugdale	1897-07-20	1977-03-26	\N	5	1	\N	\N	\N
1122	John	Forster	1888-09-15	1972-07-24	\N	7	1	\N	\N	\N
1123	William Patrick	Spens	1885-08-09	1973-11-15	\N	20	1	\N	\N	\N
1124	Herbert Stanley	Morrison	1888-01-03	1965-03-06	\N	14	1	\N	\N	\N
1125	James Gray	Stuart	1897-02-09	1971-02-20	\N	20	1	\N	\N	\N
1127	Charles Glen	MacAndrew	1888-01-13	1979-11-11	\N	14	1	\N	\N	\N
1128	Florence Gertrude	Horsbrugh	1889-10-13	1969-12-06	\N	9	2	\N	\N	\N
1129	John Durival	Kemp	1906-06-05	1993-05-24	\N	12	1	\N	\N	\N
1130	George Horatio	Nelson	1887-10-26	1962-07-16	\N	15	1	\N	\N	\N
1131	Edward Hugh John Neale	Dalton	1887-08-26	1962-02-13	\N	5	1	\N	\N	\N
1132	Alfred Charles	Bossom	1881-10-16	1965-09-04	\N	3	1	\N	\N	\N
1133	Evelyn	Baring	1903-09-29	1973-03-10	\N	3	1	\N	\N	\N
1134	Basil	Sanderson	1894-06-19	1971-08-15	\N	20	1	\N	\N	\N
1137	Edward Arthur Alexander	Shackleton	1911-07-15	1994-09-22	\N	20	1	\N	\N	\N
1138	Antony Henry	Head	1906-12-19	1983-03-29	\N	9	1	\N	\N	\N
1139	Terence Edmund Gascoigne	Nugent	1895-08-11	1973-04-27	\N	15	1	\N	\N	\N
1140	Derick Heathcoat	Amory	1899-12-26	1981-01-19	\N	2	1	\N	\N	\N
1141	Alan Tindal	Lennox-Boyd	1904-11-18	1983-03-08	\N	13	1	\N	\N	\N
1142	Francis Lord Charlton	Hodson	1895-09-17	1984-03-11	\N	9	1	\N	\N	\N
1143	George Reginald	Ward	1907-11-20	1988-06-15	\N	24	1	\N	\N	\N
1145	Christopher William Graham	Guest	1901-11-07	1984-09-25	\N	8	1	\N	\N	\N
1146	Edward Francis	Twining	1899-06-24	1967-07-21	\N	21	1	\N	\N	\N
1147	Robert John Graham	Boothby	1900-02-12	1986-07-16	\N	3	1	\N	\N	\N
1148	James Mortimer	Peddie	1905-04-04	1978-04-13	\N	17	1	\N	\N	\N
1149	George Samuel	Lindgren	1900-11-11	1971-09-08	\N	13	1	\N	\N	\N
1150	Henry David Leonard George	Walston	1912-06-16	1991-05-29	\N	24	1	\N	\N	\N
1151	Arthur Hugh Elsdale	Molson	1903-06-29	1991-10-13	\N	14	1	\N	\N	\N
1152	Cuthbert James McCall	Alport	1912-03-22	1998-10-28	\N	2	1	\N	\N	\N
1153	Alfred	Robens	1910-12-18	1999-06-27	\N	19	1	\N	\N	\N
1155	Brian Hubert	Robertson	1896-07-22	1974-04-29	\N	19	1	\N	\N	\N
1156	Simon	Marks	1888-07-09	1964-12-08	\N	14	1	\N	\N	\N
1158	Patrick Arthur	Devlin	1905-11-25	1992-08-09	\N	5	1	\N	\N	\N
1159	Walter Russell	Brain	1895-10-23	1966-12-29	\N	3	1	\N	\N	\N
1160	Leonard Percy	Lord	1896-11-15	1967-09-13	\N	13	1	\N	\N	\N
1161	Frederick Robert Hoyer	Millar	1900-06-06	1989-10-16	\N	14	1	\N	\N	\N
1162	Elaine Frances	Burton	1904-03-02	1991-10-06	\N	3	2	\N	\N	\N
1163	Edward Francis	Williams	1903-03-10	1970-06-05	\N	24	1	\N	\N	\N
1164	Alexander Robertus	Todd	1907-10-02	1997-01-10	\N	21	1	\N	\N	\N
1165	Alan John	Sainsbury	1902-08-13	1998-10-21	\N	20	1	\N	\N	\N
1166	Edward Holroyd	Pearce	1901-02-09	1990-11-26	\N	17	1	\N	\N	\N
1167	Oliver Shewell	Franks	1905-02-16	1992-10-15	\N	7	1	\N	\N	\N
1168	Arthur Joseph	Champion	1897-07-26	1985-03-02	\N	4	1	\N	\N	\N
1170	Thomas	Williamson	1897-09-02	1983-02-27	\N	24	1	\N	\N	\N
1171	William	Mabane	1895-01-12	1969-11-16	\N	14	1	\N	\N	\N
1172	Cyril John	Radcliffe	1899-03-30	1977-04-01	\N	19	1	\N	\N	\N
1174	Reginald Edward	Manningham-Buller	1905-08-01	1980-09-07	\N	14	1	\N	\N	\N
1175	David McAdam	Eccles	1904-09-18	1999-02-24	\N	6	1	\N	\N	\N
1176	Norman Craven	Brook	1902-04-29	1967-06-15	\N	3	1	\N	\N	\N
1177	Albert Victor	Alexander	1885-05-01	1965-01-11	\N	2	1	\N	\N	\N
1178	Eric Cyril Boyd	Edwards	1914-10-09	1997-03-03	\N	6	1	\N	\N	\N
1179	Charles	Hill	1904-01-15	1989-08-22	\N	9	1	\N	\N	\N
1181	Alexander	Fleck	1889-11-11	1968-08-06	\N	7	1	\N	\N	\N
1182	Edith Clara	Summerskill	1901-04-19	1980-02-04	\N	20	2	\N	\N	\N
1183	William	Hughes	1911-01-22	1999-12-31	\N	9	1	\N	\N	\N
1184	Gerald Ritchie	Upjohn	1903-02-25	1971-01-27	\N	22	1	\N	\N	\N
1185	Frances Joan	Davidson	1894-05-29	1985-11-25	\N	5	2	\N	\N	\N
1186	Terence Norbert	Donovan	1898-06-13	1971-12-12	\N	5	1	\N	\N	\N
1187	Gerald Austin	Gardiner	1900-05-30	1990-01-07	\N	8	1	\N	\N	\N
1189	Bertram Vivian	Bowden	1910-01-18	1989-07-31	\N	3	1	\N	\N	\N
1190	Charles Rider	Hobson	1903-02-18	1966-02-17	\N	9	1	\N	\N	\N
1191	Edward Henry	Willis	1918-01-13	1992-12-22	\N	24	1	\N	\N	\N
1192	Edwin Savory	Herbert	1899-06-29	1973-06-05	\N	9	1	\N	\N	\N
1193	Anna Dora	Gaitskell	1901-04-25	1989-07-01	\N	8	2	\N	\N	\N
1088	Robert John	Sinclair	1893-07-29	1979-03-04	\N	20	1	\N	\N	\N
2797	Barrington Sholto	Campbell	1877-07-15	1937-03-03	\N	4	1	\N	\N	\N
1196	Harold Arthur	Watkinson	1910-01-25	1995-12-19	\N	24	1	\N	\N	\N
1197	Roger Mellor	Makins	1904-02-03	1996-11-09	\N	14	1	\N	\N	\N
1198	John Scott	Maclay	1905-10-26	1992-08-17	\N	14	1	\N	\N	\N
1199	John Adrian	Hope	1912-04-07	1996-01-18	\N	9	1	\N	\N	\N
1200	Geoffrey Kemp	Bourne	1902-10-05	1982-06-26	\N	3	1	\N	\N	\N
1201	Anthony Richard	Hurd	1901-05-02	1966-02-12	\N	9	1	\N	\N	\N
1202	Charles	Royle	1896-01-23	1975-09-30	\N	19	1	\N	\N	\N
1203	Hervey	Rhodes	1895-08-12	1987-09-11	\N	19	1	\N	\N	\N
1205	John Maxwell	Erskine	1893-12-14	1980-12-14	\N	6	1	\N	\N	\N
1206	Richard Orme	Wilberforce	1907-03-11	2003-02-15	\N	24	1	\N	\N	\N
1207	Gilbert Richard	Mitchison	1894-03-23	1970-02-14	\N	14	1	\N	\N	\N
1208	Barbara Muriel	Brooke	1908-01-14	2000-09-01	\N	3	2	\N	\N	\N
1210	Charles Percy	Snow	1905-10-15	1980-07-01	\N	20	1	\N	\N	\N
1211	Arthur Gwynne	Jones	1919-12-05	2020-01-10	\N	11	1	\N	\N	\N
1212	Evelyn Violet Elizabeth	Emmet	1899-03-18	1980-10-10	\N	6	2	\N	\N	\N
1213	Robert Villiers	Grimston	1897-06-08	1979-12-08	\N	8	1	\N	\N	\N
1214	Francis George	Bowles	1902-05-02	1970-12-29	\N	3	1	\N	\N	\N
1216	Reginald William	Sorensen	1891-06-19	1971-10-08	\N	20	1	\N	\N	\N
1217	Charles Edward	Leatherland	1898-04-18	1992-12-18	\N	13	1	\N	\N	\N
1218	William Reid	Blyton	1899-05-02	1987-10-25	\N	3	1	\N	\N	\N
1219	Nigel	Vinson	1931-01-27	\N	\N	23	1	\N	\N	\N
1220	John Edward Reginald	Wyndham	1920-06-05	1972-06-06	\N	24	1	\N	\N	\N
1221	Norah	Phillips	1910-08-12	1992-08-14	\N	17	2	\N	\N	\N
1222	Wilfred Banks Duncan	Brown	1908-11-29	1985-03-17	\N	3	1	\N	\N	\N
1223	Charles Frank	Byers	1915-07-24	1984-02-06	\N	3	1	\N	\N	\N
1225	Donald William	Wade	1904-06-16	1988-11-06	\N	24	1	\N	\N	\N
1226	Arwyn Randall	Davies	1897-04-17	1978-02-23	\N	5	1	\N	\N	\N
1227	Hugh	Fraser	1903-01-15	1966-11-06	\N	7	1	\N	\N	\N
1229	John Granville	Morrison	1906-12-16	1996-05-25	\N	14	1	\N	\N	\N
1230	James Chuter	Ede	1882-09-11	1965-11-11	\N	6	1	\N	\N	\N
1231	Christopher	Hinton	1901-05-12	1983-06-22	\N	9	1	\N	\N	\N
1232	William Graham	Holford	1907-03-22	1975-10-17	\N	9	1	\N	\N	\N
1233	Howard Walter	Florey	1898-09-24	1968-02-21	\N	7	1	\N	\N	\N
1234	George James	Cole	1906-02-03	1979-11-29	\N	4	1	\N	\N	\N
1235	Colin Hargreaves	Pearson	1899-07-28	1980-01-31	\N	17	1	\N	\N	\N
1236	Richard Austen	Butler	1902-12-09	1982-03-08	\N	3	1	\N	\N	\N
1237	Beatrice	Plummer	1903-04-14	1972-06-13	\N	17	2	\N	\N	\N
1239	Albert Victor	Hilton	1908-02-14	1977-05-03	\N	9	1	\N	\N	\N
1240	Harold Anthony	Caccia	1905-12-21	1990-10-31	\N	4	1	\N	\N	\N
1241	Donald Oliver	Soper	1903-01-31	1998-12-22	\N	20	1	\N	\N	\N
1242	Thomas Spensley	Simey	1906-11-25	1969-12-27	\N	20	1	\N	\N	\N
1243	John Edwin	Haire	1908-11-14	1966-10-07	\N	9	1	\N	\N	\N
1245	Ian	Winterbottom	1913-04-06	1992-07-04	\N	24	1	\N	\N	\N
1246	Dennis	Lloyd	1915-10-22	1992-12-31	\N	13	1	\N	\N	\N
1247	Harold Roxbee	Cox	1902-06-06	1997-12-21	\N	4	1	\N	\N	\N
1248	Russell Claude	Brock	1903-10-24	1980-09-03	\N	3	1	\N	\N	\N
1249	Richard Ferdinand	Kahn	1905-08-10	1989-06-06	\N	12	1	\N	\N	\N
1251	Noel Gilroy	Annan	1916-12-25	2000-02-21	\N	2	1	\N	\N	\N
1252	Arnold Abraham	Goodman	1913-08-21	1995-05-12	\N	8	1	\N	\N	\N
1253	John Middleton	Campbell	1912-08-08	1994-12-26	\N	4	1	\N	\N	\N
1254	William Stephen Richard	King-Hall	1893-01-21	1966-06-02	\N	12	1	\N	\N	\N
1255	Audrey Pellew	Hylton-Foster	1908-05-19	2002-10-31	\N	9	2	\N	\N	\N
1256	Mary Danvers	Stocks	1891-07-25	1975-07-06	\N	20	2	\N	\N	\N
1258	Frank	Beswick	1911-08-21	1987-08-17	\N	3	1	\N	\N	\N
1259	Samuel	Segal	1902-04-02	1985-06-04	\N	20	1	\N	\N	\N
1260	Ernest	Popplewell	1899-12-10	1977-08-11	\N	17	1	\N	\N	\N
1261	Frank	Soskice	1902-07-23	1979-01-01	\N	20	1	\N	\N	\N
1262	George Albert	Pargiter	1897-03-16	1982-01-16	\N	17	1	\N	\N	\N
1263	Martin	Redmayne	1910-11-16	1983-04-28	\N	19	1	\N	\N	\N
1264	Walter	Monslow	1895-01-26	1966-10-12	\N	14	1	\N	\N	\N
1265	Samuel	Storey	1896-01-18	1978-01-17	\N	20	1	\N	\N	\N
1266	Arthur	Moyle	1894-09-25	1974-12-23	\N	14	1	\N	\N	\N
1268	Henry Cecil John	Hunt	1910-06-22	1998-11-08	\N	9	1	\N	\N	\N
1269	Peter Ritchie	Calder	1906-07-01	1982-01-31	\N	4	1	\N	\N	\N
1270	John	Cooper	1908-06-07	1988-09-02	\N	4	1	\N	\N	\N
1271	Henry	Brooke	1903-04-09	1984-03-29	\N	3	1	\N	\N	\N
1273	Robert	Platt	1900-04-16	1978-06-30	\N	17	1	\N	\N	\N
1274	Charles Richard	Morris	1898-01-25	1990-05-30	\N	14	1	\N	\N	\N
1275	Harold	Woolley	1905-02-06	1986-07-31	\N	24	1	\N	\N	\N
1276	Beatrice	Serota	1919-10-15	2002-10-21	\N	20	2	\N	\N	\N
1277	John Primatt Redcliffe	Redcliffe-Maud	1906-02-03	1982-11-20	\N	19	1	\N	\N	\N
1278	William George	Penney	1909-06-24	1991-03-03	\N	17	1	\N	\N	\N
1279	Llewellyn	Heycock	1905-08-12	1990-03-13	\N	9	1	\N	\N	\N
1280	William John	Carron	1902-11-19	1969-12-03	\N	4	1	\N	\N	\N
1281	Benjamin Ifor	Evans	1899-08-19	1982-08-28	\N	6	1	\N	\N	\N
1282	Alan Raymond	Mais	1911-07-07	1993-11-28	\N	14	1	\N	\N	\N
1284	Desmond Barel	Hirshfield	1913-05-17	1993-12-06	\N	9	1	\N	\N	\N
1285	Frank	McLeavy	1899-01-01	1976-10-01	\N	14	1	\N	\N	\N
1287	David Lauchlan	Urquhart	1912-09-13	1975-03-12	\N	22	1	\N	\N	\N
1288	Alma	Birk	1917-09-22	1996-12-29	\N	3	2	\N	\N	\N
1289	William Geoffrey	Fiske	1905-07-03	1975-01-13	\N	7	1	\N	\N	\N
1290	Charles James	Garnsworthy	1906-12-10	1974-09-05	\N	8	1	\N	\N	\N
1292	Edward James	Hill	1899-08-20	1969-12-14	\N	9	1	\N	\N	\N
1293	Harry	Douglass	1902-01-01	1978-04-05	\N	5	1	\N	\N	\N
1294	Charles George Percy	Smith	1917-04-25	1972-08-02	\N	20	1	\N	\N	\N
1295	John George Stuart	Donaldson	1907-10-09	1998-03-08	\N	5	1	\N	\N	\N
1296	John Scott	Fulton	1902-05-27	1986-03-14	\N	7	1	\N	\N	\N
1297	Arthur	Henderson	1893-08-27	1968-08-28	\N	9	1	\N	\N	\N
1298	George Edward Cecil	Wigg	1900-11-28	1983-08-11	\N	24	1	\N	\N	\N
1300	Lewis Tatham	Wright	1903-10-11	1974-09-15	\N	24	1	\N	\N	\N
1301	Thomas Johnston	Taylor	1912-04-27	2001-07-13	\N	21	1	\N	\N	\N
1302	Humphrey	Trevelyan	1905-11-27	1985-02-08	\N	21	1	\N	\N	\N
1195	John Roland	Robinson	1907-02-22	1989-05-03	\N	19	1	\N	\N	\N
2798	Leopold Colin Henry Douglas	Campbell	1881-03-05	1940-02-08	\N	4	1	\N	\N	\N
1305	William Rushton	Black	1893-01-12	1984-12-27	\N	3	1	\N	\N	\N
1306	Geoffrey	Crowther	1907-05-13	1972-02-05	\N	4	1	\N	\N	\N
1308	John Henry	Jacques	1905-01-11	1995-12-20	\N	11	1	\N	\N	\N
1309	Ralph Francis Alnwick	Grey	1910-04-15	1999-10-17	\N	8	1	\N	\N	\N
1311	Donald Gresham	Stokes	1914-03-22	2008-07-21	\N	20	1	\N	\N	\N
1312	Patrick Maynard Stuart	Blackett	1897-11-18	1974-07-13	\N	3	1	\N	\N	\N
1313	Joseph John Saville	Garner	1908-02-14	1983-12-10	\N	8	1	\N	\N	\N
1314	Learie Nicholas	Constantine	1901-09-21	1971-07-01	\N	4	1	\N	\N	\N
1315	Paul Henry	Gore-Booth	1909-02-03	1984-06-29	\N	8	1	\N	\N	\N
1316	Sidney Lewis	Bernstein	1899-01-30	1993-02-05	\N	3	1	\N	\N	\N
1317	Kenneth Mackenzie	Clark	1903-07-13	1983-05-21	\N	4	1	\N	\N	\N
1318	John Cowburn	Beavan	1910-04-29	1994-08-18	\N	3	1	\N	\N	\N
1319	Terence Marne	O'Neill	1914-09-10	1990-06-12	\N	16	1	\N	\N	\N
1321	Susan Lilian Primrose	Cunliffe-Lister	1935-04-14	\N	\N	4	2	\N	\N	\N
1322	Emanuel	Shinwell	1884-10-18	1986-05-08	\N	20	1	\N	\N	\N
1323	Barnett	Janner	1892-06-20	1982-05-04	\N	11	1	\N	\N	\N
1324	Quintin McGarel	Hogg	1907-10-09	2001-10-12	\N	9	1	\N	\N	\N
1325	Priscilla Jean Fortescue	Buchan	1915-01-25	1978-03-11	\N	3	2	\N	\N	\N
1326	John Kenyon	Vaughan-Morgan	1905-02-02	1995-01-26	\N	23	1	\N	\N	\N
1327	Edward Charles Gurney	Boyle	1923-08-31	1981-09-28	\N	3	1	\N	\N	\N
1328	James Hutchison	Hoy	1909-01-21	1976-08-07	\N	9	1	\N	\N	\N
1329	Cyril	Hamnett	1906-05-20	1980-03-17	\N	9	1	\N	\N	\N
1331	Joseph	Slater	1904-06-13	1977-04-21	\N	20	1	\N	\N	\N
1333	John	Wheatley	1908-01-17	1988-07-28	\N	24	1	\N	\N	\N
1334	Max Leonard	Rosenheim	1908-03-15	1972-12-02	\N	19	1	\N	\N	\N
1335	George Edward Peter	Thorneycroft	1909-07-26	1994-06-04	\N	21	1	\N	\N	\N
1336	Timothy Wentworth	Beaumont	1928-11-22	2008-04-08	\N	3	1	\N	\N	\N
1337	William Henry	Pilkington	1905-04-19	1983-12-22	\N	17	1	\N	\N	\N
1338	Eirene Lloyd	White	1909-11-07	1999-12-23	\N	24	2	\N	\N	\N
1339	Alice Martha	Bacon	1909-09-10	1993-03-24	\N	3	2	\N	\N	\N
1340	Janet	Bevan	1904-11-03	1988-11-16	\N	3	2	\N	\N	\N
1341	George Alfred	Brown	1914-09-02	1985-06-02	\N	3	1	\N	\N	\N
1342	William Miles Webster	Thomas	1897-03-02	1980-02-08	\N	21	1	\N	\N	\N
1343	Mark Shuldham	Schreiber	1931-09-11	\N	\N	20	1	\N	\N	\N
1346	Laurence Kerr	Olivier	1907-05-22	1989-07-11	\N	16	1	\N	\N	\N
1347	Arthur Geoffrey Neale	Cross	1904-12-01	1989-08-04	\N	4	1	\N	\N	\N
1348	John Passmore	Widgery	1911-07-24	1981-07-26	\N	24	1	\N	\N	\N
1349	Charles Ian	Orr-Ewing	1912-02-10	1999-08-19	\N	16	1	\N	\N	\N
1350	Arthur Vere	Harvey	1906-01-31	1994-04-05	\N	9	1	\N	\N	\N
1351	Robert Norman William	Blake	1916-12-23	2003-09-20	\N	3	1	\N	\N	\N
1352	Beatrice Nancy	Seear	1913-08-07	1997-04-23	\N	20	2	\N	\N	\N
1353	Simon Brooke	Mackay	1934-03-30	\N	\N	14	1	\N	\N	\N
1354	Janet Mary	Young	1926-10-23	2002-09-06	\N	26	2	\N	\N	\N
1355	Evelyn Hester	Macleod	1915-02-19	1999-11-17	\N	14	2	\N	\N	\N
1356	Solly	Zuckerman	1904-05-30	1993-04-01	\N	27	1	\N	\N	\N
1357	James Dawson	Chichester-Clark	1923-02-12	2002-05-17	\N	4	1	\N	\N	\N
1359	Cyril Barnet	Salmon	1903-12-28	1991-11-07	\N	20	1	\N	\N	\N
1360	Michael Edward	Adeane	1910-09-30	1984-04-30	\N	2	1	\N	\N	\N
1361	Charles Leslie	Hale	1902-07-13	1985-05-09	\N	9	1	\N	\N	\N
1362	Thomas Clyde	Hewlett	1923-08-04	1979-07-02	\N	9	1	\N	\N	\N
1364	John Archibald	Boyd-Carpenter	1908-06-02	1998-07-11	\N	3	1	\N	\N	\N
1365	Diana Louie	Elles	1921-07-19	2009-10-17	\N	6	2	\N	\N	\N
1366	Samuel Charles	Elworthy	1911-03-23	1993-04-04	\N	6	1	\N	\N	\N
1367	Tudor Elwyn	Watkins	1903-05-09	1983-11-02	\N	24	1	\N	\N	\N
1368	Harold	Samuel	1912-04-23	1987-08-28	\N	20	1	\N	\N	\N
1369	Arthur Espie	Porritt	1900-08-10	1994-01-01	\N	17	1	\N	\N	\N
1370	Leslie Kenneth	O'Brien	1908-02-08	1995-11-24	\N	16	1	\N	\N	\N
1371	Pamela	Sharples	1923-02-11	\N	\N	20	2	\N	\N	\N
1372	John Desmond	Brayley	1917-01-29	1977-03-16	\N	3	1	\N	\N	\N
1373	John Henderson	Hunt	1905-07-03	1987-12-28	\N	9	1	\N	\N	\N
1374	Eric	Ashby	1904-08-24	1992-10-22	\N	2	1	\N	\N	\N
1377	John	Diamond	1907-04-30	2004-04-03	\N	5	1	\N	\N	\N
1378	Harold	Davies	1904-07-31	1985-10-28	\N	5	1	\N	\N	\N
1379	Goronwy Owen	Goronwy-Roberts	1913-09-20	1981-07-22	\N	8	1	\N	\N	\N
1380	John Henry	Harris	1930-04-05	2001-04-11	\N	9	1	\N	\N	\N
1381	Duncan Edwin	Sandys	1908-01-24	1987-11-26	\N	20	1	\N	\N	\N
1382	Michael Antony Cristobal	Noble	1913-03-19	1984-05-15	\N	15	1	\N	\N	\N
1383	Geoffrey William	Lloyd	1902-01-17	1984-09-12	\N	13	1	\N	\N	\N
1384	Alfred Ernest	Marples	1907-12-09	1978-07-06	\N	14	1	\N	\N	\N
1386	George Yull	Mackie	1919-07-10	2015-02-17	\N	14	1	\N	\N	\N
1387	Margaret Patricia	Hornsby-Smith	1914-03-17	1985-07-03	\N	9	2	\N	\N	\N
1388	Inga-Stina	Robson	1919-08-20	1999-02-09	\N	19	2	\N	\N	\N
1389	Irene Mervyn Parnicott	Pike	1918-09-16	2004-01-11	\N	17	2	\N	\N	\N
1390	Basil Thomas	Wigoder	1921-02-12	2004-08-12	\N	24	1	\N	\N	\N
1391	Richard Michael	Fraser	1915-10-28	1996-07-01	\N	7	1	\N	\N	\N
1392	Edward Cyril	Castle	1907-05-05	1979-12-26	\N	4	1	\N	\N	\N
1393	Samuel	Fisher	1905-01-20	1979-10-12	\N	7	1	\N	\N	\N
1396	Robert Grant	Grant-Ferris	1907-12-30	1997-01-01	\N	8	1	\N	\N	\N
1397	Phyllis	Stedman	1916-07-14	1996-06-08	\N	20	2	\N	\N	\N
1398	Peter Lovell	Davis	1924-07-08	2001-01-06	\N	5	1	\N	\N	\N
1399	Harry	Kissin	1912-08-23	1997-11-22	\N	12	1	\N	\N	\N
1400	George	Wallace	1915-02-13	1997-12-23	\N	24	1	\N	\N	\N
1401	Frederick	Lee	1906-08-03	1984-02-04	\N	13	1	\N	\N	\N
1402	Doris Mary Gertrude	Fisher	1919-09-13	2005-12-18	\N	7	2	\N	\N	\N
1403	George	Darling	1905-07-01	1985-10-18	\N	5	1	\N	\N	\N
1404	Patrick Chrestien	Gordon-Walker	1907-04-07	1980-12-02	\N	8	1	\N	\N	\N
1405	Gwilym Elfed	Davies	1913-10-09	1992-04-28	\N	5	1	\N	\N	\N
1406	Nicholas	Kaldor	1908-05-12	1986-09-30	\N	12	1	\N	\N	\N
1408	Marcia Matilda	Williams	1932-03-10	2019-02-06	\N	24	2	\N	\N	\N
1409	John Frederick	Wolfenden	1906-06-26	1985-01-18	\N	24	1	\N	\N	\N
1304	Thomas	Balogh	1905-11-02	1985-01-20	\N	3	1	\N	\N	\N
2799	Philip Archibald Douglas	Campbell	1919-02-19	1940-09-14	\N	4	1	\N	\N	\N
1412	Reginald Thomas	Paget	1908-09-02	1990-01-02	\N	17	1	\N	\N	\N
1413	Arnold	Silverstone	1911-09-28	1977-07-23	\N	20	1	\N	\N	\N
1414	Anthony Perrinott Lysberg	Barber	1920-07-04	2005-12-16	\N	3	1	\N	\N	\N
1415	Desmond Anderson Harvie	Banks	1918-10-23	1997-06-15	\N	3	1	\N	\N	\N
1416	Victor Grayson Hardie	Feather	1908-04-10	1976-07-28	\N	7	1	\N	\N	\N
1417	Burke St. John	Trend	1914-01-02	1987-07-21	\N	21	1	\N	\N	\N
1418	Frederick Elwyn	Jones	1909-10-24	1989-12-04	\N	11	1	\N	\N	\N
1419	Alfred	Wilson	1909-06-10	1983-01-25	\N	24	1	\N	\N	\N
1421	Richard William	Briginshaw	1908-05-15	1992-03-27	\N	3	1	\N	\N	\N
1422	George Douglas	Wallace	1906-04-18	2003-11-11	\N	24	1	\N	\N	\N
1424	Sidney Francis	Greene	1910-02-12	2004-07-26	\N	8	1	\N	\N	\N
1425	Braham Jack Dennis	Lyons	1918-09-11	1978-01-18	\N	13	1	\N	\N	\N
1426	Irene Mary Bewick	Ward	1895-02-23	1980-04-26	\N	24	2	\N	\N	\N
1427	Robert Alexander	Lindsay	1927-03-05	\N	\N	13	1	\N	\N	\N
1428	Joan Helen	Vickers	1907-06-03	1994-05-23	\N	23	2	\N	\N	\N
1429	Rudy	Sternberg	1917-04-17	1978-01-05	\N	20	1	\N	\N	\N
1430	William	Armstrong	1915-03-03	1980-07-12	\N	2	1	\N	\N	\N
1432	Richard Patrick Tallentyre	Gibson	1916-02-05	2004-04-20	\N	8	1	\N	\N	\N
1433	Leslie Maurice	Lever	1905-04-29	1977-07-26	\N	13	1	\N	\N	\N
1434	John	Gregson	1924-01-29	2009-08-12	\N	8	1	\N	\N	\N
1435	William Denholm	Barnetson	1917-03-21	1981-03-12	\N	3	1	\N	\N	\N
1436	Sydney Thomas Franklin	Ryder	1916-09-16	2003-05-12	\N	19	1	\N	\N	\N
1437	Sydney	Jacobson	1908-10-26	1988-08-13	\N	11	1	\N	\N	\N
1438	John Farquharson	Smith	1930-05-07	\N	\N	20	1	\N	\N	\N
1439	Charles Ritchie	Russell	1908-01-12	1986-06-23	\N	19	1	\N	\N	\N
1440	Raymond Percival	Brookes	1909-04-10	2002-07-31	\N	3	1	\N	\N	\N
1442	Thomas Edward Neil	Driberg	1905-05-22	1976-08-12	\N	5	1	\N	\N	\N
1443	William Edward John	McCarthy	1925-07-30	2012-11-18	\N	14	1	\N	\N	\N
1444	William Donald	Chapman	1923-11-25	2013-04-18	\N	4	1	\N	\N	\N
1445	Gordon Samuel David	Parry	1925-11-30	2004-09-01	\N	17	1	\N	\N	\N
1446	Albert Edward	Oram	1913-08-13	1999-09-04	\N	16	1	\N	\N	\N
1447	Michael Platt	Winstanley	1918-08-27	1993-07-18	\N	24	1	\N	\N	\N
1448	Lucy	Faithfull	1910-12-26	1996-03-13	\N	7	2	\N	\N	\N
1449	Frank	Schon	1912-05-18	1995-01-07	\N	20	1	\N	\N	\N
1450	Thomas	Brimelow	1915-10-25	1995-08-02	\N	3	1	\N	\N	\N
1453	John Edward	Wall	1913-02-15	1980-12-29	\N	24	1	\N	\N	\N
1454	John Selwyn Brooke	Lloyd	1904-07-28	1978-05-17	\N	13	1	\N	\N	\N
1455	Lew	Grade	1906-12-25	1998-12-13	\N	8	1	\N	\N	\N
1456	John Ernest	Vaizey	1929-10-01	1984-07-19	\N	23	1	\N	\N	\N
1457	Joseph Ellis	Stone	1903-05-27	1986-07-17	\N	20	1	\N	\N	\N
1458	Walter Ian Reid	Fraser	1911-02-03	1989-02-17	\N	7	1	\N	\N	\N
1459	Edward Benjamin	Britten	1913-11-22	1976-12-04	\N	3	1	\N	\N	\N
1460	Philip	Allen	1912-07-08	2007-11-27	\N	2	1	\N	\N	\N
1461	Asa	Briggs	1921-05-07	2016-03-15	\N	3	1	\N	\N	\N
1462	Max	Rayne	1918-02-08	2003-10-10	\N	19	1	\N	\N	\N
1464	Barbara Mary	Jackson	1914-05-23	1981-05-31	\N	11	2	\N	\N	\N
1465	Henry Shanks	Keith	1922-02-07	2002-06-21	\N	12	1	\N	\N	\N
1466	Edward Watson	Short	1912-12-17	2012-05-04	\N	20	1	\N	\N	\N
1467	John Fleetwood	Baker	1901-03-19	1985-09-09	\N	3	1	\N	\N	\N
1469	Morrice	James	1916-04-30	1989-11-26	\N	11	1	\N	\N	\N
1470	George Morgan	Thomson	1921-01-16	2008-10-03	\N	21	1	\N	\N	\N
1471	Richard Michael Power	Carver	1915-04-24	2001-12-09	\N	4	1	\N	\N	\N
1472	Pratap Chidamber	Chitnis	1936-05-01	2013-07-12	\N	4	1	\N	\N	\N
1473	Eric	Roll	1907-12-01	2005-03-30	\N	19	1	\N	\N	\N
1475	Philip John	Noel-Baker	1889-11-01	1982-10-08	\N	15	1	\N	\N	\N
1476	Douglas Albert Vivian	Allen	1917-12-15	2011-09-11	\N	2	1	\N	\N	\N
1477	Leslie George	Scarman	1911-07-29	2004-12-08	\N	20	1	\N	\N	\N
1478	Oliver Ross	McGregor	1921-08-25	1997-11-10	\N	14	1	\N	\N	\N
1479	Betty	Lockwood	1924-01-22	2019-04-29	\N	13	2	\N	\N	\N
1480	Michael	Young	1915-08-09	2002-01-14	\N	26	1	\N	\N	\N
1481	Francis Arthur	Cockfield	1916-09-28	2007-01-08	\N	4	1	\N	\N	\N
1482	Peter Anthony Grayson	Rawlinson	1919-06-26	2006-06-28	\N	19	1	\N	\N	\N
1484	William	Howie	1924-03-02	2018-05-26	\N	9	1	\N	\N	\N
1485	David Thomas Gruffydd	Evans	1928-02-09	1992-03-22	\N	6	1	\N	\N	\N
1486	John Derek	Page	1927-08-14	2005-08-16	\N	17	1	\N	\N	\N
1487	Nora Ratcliff	David	1913-09-23	2009-11-29	\N	5	2	\N	\N	\N
1488	John Denis	Leonard	1909-10-19	1983-07-17	\N	13	1	\N	\N	\N
1490	Thomas	Taylor	1929-06-10	2016-11-25	\N	21	1	\N	\N	\N
1491	John Charles	Hatch	1917-11-01	1992-10-11	\N	9	1	\N	\N	\N
1492	Cyril Thomas Howe	Plant	1910-08-27	1986-08-09	\N	17	1	\N	\N	\N
1493	Victor	Mishcon	1915-08-14	2006-01-27	\N	14	1	\N	\N	\N
1494	Alexander Mitchell	Donnet	1916-06-26	1985-05-15	\N	5	1	\N	\N	\N
1495	Evelyn Joyce	Denington	1907-08-09	1998-08-22	\N	5	2	\N	\N	\N
1496	Bernard	Delfont	1909-09-05	1994-07-28	\N	5	1	\N	\N	\N
1497	Joseph	Kagan	1915-06-06	1995-01-17	\N	12	1	\N	\N	\N
1499	Margaret Susan	Ryder	1923-07-03	2000-11-02	\N	19	2	\N	\N	\N
1500	John Samuel	Richardson	1910-06-16	2004-08-15	\N	19	1	\N	\N	\N
1501	Peter John	Hill-Norton	1915-02-08	2004-05-16	\N	9	1	\N	\N	\N
1502	Bernard James	Miles	1907-09-27	1991-06-14	\N	14	1	\N	\N	\N
1503	Hugh Parr	Scanlon	1913-10-26	2004-01-27	\N	20	1	\N	\N	\N
1504	Brian Hilton	Flowers	1924-09-13	2010-06-25	\N	7	1	\N	\N	\N
1505	Irwin Norman	Bellow	1923-02-07	2001-02-11	\N	3	1	\N	\N	\N
1506	Norman Harold	Lever	1914-01-15	1995-08-06	\N	13	1	\N	\N	\N
1508	James Peter Hymers	Mackay	1927-07-02	\N	\N	14	1	\N	\N	\N
1510	Sydney	Irving	1918-07-01	1989-12-18	\N	10	1	\N	\N	\N
1511	Myer	Galpern	1903-01-01	1993-09-23	\N	8	1	\N	\N	\N
1512	Lena May	Jeger	1915-11-19	2007-02-26	\N	11	2	\N	\N	\N
1513	David Lockhart-Mure	Renton	1908-08-12	2007-05-24	\N	19	1	\N	\N	\N
1514	Joseph Bradshaw	Godber	1914-03-17	1980-08-25	\N	8	1	\N	\N	\N
1515	Henry Reginall	Underhill	1914-05-08	1993-03-12	\N	22	1	\N	\N	\N
1516	Cledwyn	Hughes	1916-09-14	2001-02-22	\N	9	1	\N	\N	\N
1517	John Edward	Brooks	1927-04-12	2016-03-04	\N	3	1	\N	\N	\N
2800	William	Brougham	1795-09-26	1886-01-03	\N	3	1	\N	\N	\N
1522	Diana Josceline Barbara	Neave	1919-07-07	1992-11-27	\N	15	2	\N	\N	\N
1523	Richard Frederick	Wood	1920-10-05	2002-08-11	\N	24	1	\N	\N	\N
1524	James David	Gibson-Watt	1918-09-11	2002-02-07	\N	8	1	\N	\N	\N
1525	Hugh Redwald	Trevor-Roper	1914-01-15	2003-01-26	\N	21	1	\N	\N	\N
1526	Margaret Betty	Harvie Anderson	1915-08-01	1979-11-07	\N	9	2	\N	\N	\N
1527	Geoffrey Dawson	Lane	1918-07-17	2005-08-21	\N	13	1	\N	\N	\N
1529	Jean Alys	Barker	1922-10-23	2018-11-26	\N	3	2	\N	\N	\N
1530	Kenneth Alexander	Keith	1916-08-30	2004-09-01	\N	12	1	\N	\N	\N
1531	John Joseph Benedict	Hunt	1919-10-23	2008-07-17	\N	9	1	\N	\N	\N
1532	George Carlyle	Emslie	1919-12-06	2002-11-20	\N	6	1	\N	\N	\N
1533	Marcus Joseph	Sieff	1913-07-02	2001-02-23	\N	20	1	\N	\N	\N
1534	Robert Brockie	Hunter	1915-07-14	1994-03-24	\N	9	1	\N	\N	\N
1535	Eustace Wentworth	Roskill	1911-02-06	1996-10-04	\N	19	1	\N	\N	\N
1536	Paul	Reilly	1912-05-29	1990-10-11	\N	19	1	\N	\N	\N
1537	William John	Blease	1914-05-28	2008-05-16	\N	3	1	\N	\N	\N
1539	Nigel Cyprian	Bridge	1917-02-26	2007-11-20	\N	3	1	\N	\N	\N
1540	Michael Meredith	Swann	1920-03-01	1990-09-22	\N	20	1	\N	\N	\N
1541	Geoffrey Johnson	Tordoff	1928-10-11	2019-06-22	\N	21	1	\N	\N	\N
1542	Hugh Gater	Jenkins	1908-07-27	2004-01-26	\N	11	1	\N	\N	\N
1543	Felicity	Lane-Fox	1918-06-22	1988-04-17	\N	13	2	\N	\N	\N
1545	Felicity Jane	Ewart-Biggs	1929-08-22	1992-10-08	\N	6	2	\N	\N	\N
1546	Max	Beloff	1913-07-02	1999-03-22	\N	3	1	\N	\N	\N
1547	Dafydd Elystan	Morgan	1932-12-07	\N	\N	14	1	\N	\N	\N
1548	Beryl Catherine	Platt	1923-04-18	2015-02-01	\N	17	2	\N	\N	\N
1550	James Anthony	Stodart	1916-06-06	2003-05-31	\N	20	1	\N	\N	\N
1551	Hugh Swynnerton	Thomas	1931-10-21	2017-05-07	\N	21	1	\N	\N	\N
1552	Christopher Paget	Mayhew	1915-06-12	1997-01-07	\N	14	1	\N	\N	\N
1553	Richard William	Marsh	1928-03-14	2011-07-29	\N	14	1	\N	\N	\N
1554	Theodore	Constantine	1910-03-15	2004-02-13	\N	4	1	\N	\N	\N
1555	Lawrence	Kadoorie	1899-06-02	1993-08-25	\N	12	1	\N	\N	\N
1556	Charles	Forte	1908-11-26	2007-02-28	\N	7	1	\N	\N	\N
1557	William Nicholas	Cayzer	1910-01-21	1999-04-16	\N	4	1	\N	\N	\N
1558	Henry Vivian	Brandon	1920-06-03	1999-03-24	\N	3	1	\N	\N	\N
1559	Ian Powell	Bancroft	1922-12-23	1996-11-19	\N	3	1	\N	\N	\N
1560	John Anson	Brightman	1911-06-20	2006-02-06	\N	3	1	\N	\N	\N
1563	Raymond William	Pennock	1920-06-16	1993-02-23	\N	17	1	\N	\N	\N
1564	Joseph	Gormley	1917-07-05	1993-05-27	\N	8	1	\N	\N	\N
1565	Sydney William	Templeman	1920-03-03	2014-06-04	\N	21	1	\N	\N	\N
1566	Terence Thornton	Lewin	1920-11-19	1999-01-23	\N	13	1	\N	\N	\N
1567	Andrew Robert	McIntosh	1933-04-30	2010-08-27	\N	14	1	\N	\N	\N
1568	Olive Mary Wendy	Nicol	1923-03-21	2018-01-15	\N	15	2	\N	\N	\N
1569	Caroline Anne	Cox	1937-07-06	\N	\N	4	2	\N	\N	\N
1571	John Aked	Taylor	1917-08-15	2002-02-07	\N	21	1	\N	\N	\N
1572	Derek	Ezra	1919-02-23	2015-12-22	\N	6	1	\N	\N	\N
1573	Derek George	Rayner	1926-03-30	1998-06-26	\N	19	1	\N	\N	\N
1574	Frank Shaw	Marshall	1915-09-26	1990-11-01	\N	14	1	\N	\N	\N
1575	Arnold	Weinstock	1924-07-29	2002-07-23	\N	24	1	\N	\N	\N
1576	Francis Scott	McFadzean	1915-11-26	1992-05-23	\N	14	1	\N	\N	\N
1577	John	Gallacher	1920-05-07	2004-01-04	\N	8	1	\N	\N	\N
1579	William Stephen Ian	Whitelaw	1918-06-28	1999-07-01	\N	24	1	\N	\N	\N
1580	George Anthony Geoffrey	Howard	1920-05-22	1984-11-27	\N	9	1	\N	\N	\N
1581	John Leonard	King	1918-08-29	2005-07-12	\N	12	1	\N	\N	\N
1582	James Hector Northey (Hamish)	Gray	1927-06-28	2006-03-14	\N	8	1	\N	\N	\N
1583	Thomas George	Thomas	1909-01-29	1997-09-22	\N	21	1	\N	\N	\N
1584	Stuart Yarworth	Blanch	1918-02-02	1994-06-03	\N	3	1	\N	\N	\N
1585	Albert William	Stallard	1921-11-05	2008-03-29	\N	20	1	\N	\N	\N
1586	David Hedley	Ennals	1922-08-19	1995-06-17	\N	6	1	\N	\N	\N
1587	Thomas Edward	Graham	1925-03-26	\N	\N	8	1	\N	\N	\N
1589	James Harold	Wilson	1916-03-11	1995-05-24	\N	24	1	\N	\N	\N
1591	Donald	Kaberry	1907-08-18	1991-03-13	\N	12	1	\N	\N	\N
1592	Anthony Henry Fanshawe	Royle	1927-03-27	2001-12-28	\N	19	1	\N	\N	\N
1593	Joseph Jabez	Dean	1922-06-03	1999-02-26	\N	5	1	\N	\N	\N
1594	Joel	Barnett	1923-10-14	2014-11-01	\N	3	1	\N	\N	\N
1595	John Benedict	Eden	1925-09-15	\N	\N	6	1	\N	\N	\N
1596	John Wynne William	Peyton	1919-02-13	2006-11-22	\N	17	1	\N	\N	\N
1597	John	Bruce-Gardyne	1930-04-12	1990-04-15	\N	3	1	\N	\N	\N
1599	Gerard	Fitt	1926-04-09	2005-08-26	\N	7	1	\N	\N	\N
1600	Frederick William	Mulley	1918-07-03	1995-03-15	\N	14	1	\N	\N	\N
1601	Arthur George	Bottomley	1907-02-07	1995-11-03	\N	3	1	\N	\N	\N
1602	Robert Alistair	McAlpine	1942-05-14	2014-01-17	\N	14	1	\N	\N	\N
1603	Francis Joseph	Chapple	1921-08-08	2004-10-19	\N	4	1	\N	\N	\N
1604	Kenneth John	Cameron	1931-06-11	\N	\N	4	1	\N	\N	\N
1605	David Ivor	Young	1932-02-27	\N	\N	26	1	\N	\N	\N
1607	Lionel	Murray	1922-08-02	2004-05-20	\N	14	1	\N	\N	\N
1608	Marcus Richard	Kimball	1928-10-18	2014-03-27	\N	12	1	\N	\N	\N
1609	Samuel Charles	Silkin	1918-03-06	1988-08-17	\N	20	1	\N	\N	\N
1610	John Blackstock	Butterworth	1918-03-13	2003-06-19	\N	3	1	\N	\N	\N
1611	Robert William	Elliott	1920-12-11	2011-05-20	\N	6	1	\N	\N	\N
1612	Gwilym Prys	Davies	1923-12-08	2017-03-28	\N	5	1	\N	\N	\N
1613	Peter Thomas	Bauer	1915-11-06	2002-05-03	\N	3	1	\N	\N	\N
1614	Neil	Cameron	1920-07-08	1985-01-29	\N	4	1	\N	\N	\N
1616	Charles Russell	Sanderson	1933-04-30	\N	\N	20	1	\N	\N	\N
1617	Gloria	Hooper	1939-05-25	\N	\N	9	2	\N	\N	\N
1619	Robert Joseph	Mellish	1913-03-03	1998-05-09	\N	14	1	\N	\N	\N
1620	Walter Charles	Marshall	1932-03-05	1996-02-20	\N	14	1	\N	\N	\N
1621	Frederick Sydney	Dainton	1914-11-11	1997-12-05	\N	5	1	\N	\N	\N
1622	Desmond James Conrad	Ackner	1920-09-18	2006-03-21	\N	2	1	\N	\N	\N
1623	Peter Raymond	Oliver	1921-03-07	2007-10-17	\N	16	1	\N	\N	\N
1624	Robert Lionel Archibald	Goff	1926-11-12	2016-08-14	\N	8	1	\N	\N	\N
1625	Mark Raymond	Bonham Carter	1922-02-11	1994-09-04	\N	3	1	\N	\N	\N
1626	Philip Brian Cecil	Moore	1921-04-06	2009-04-07	\N	14	1	\N	\N	\N
1519	William	Ross	1911-04-07	1988-06-10	\N	19	1	\N	\N	\N
1629	Edwin Noel Westby	Bramall	1923-12-18	2019-11-12	\N	3	1	\N	\N	\N
1630	Tessa Ann Vosper	Blackstone	1942-09-27	\N	\N	3	2	\N	\N	\N
1631	Denis Victor	Carter	1932-01-17	2006-12-18	\N	4	1	\N	\N	\N
1632	Maurice Harry	Peston	1931-03-19	2016-04-23	\N	17	1	\N	\N	\N
1634	David Robert	Stevens	1936-05-26	\N	\N	20	1	\N	\N	\N
1635	David	Basnett	1924-02-09	1989-01-25	\N	3	1	\N	\N	\N
1637	Joseph Anthony Porteous	Trafford	1932-07-20	1989-09-16	\N	21	1	\N	\N	\N
1638	Charles Henry	Plumb	1925-03-27	\N	\N	17	1	\N	\N	\N
1639	Emily May	Blatch	1937-07-24	2005-05-31	\N	3	2	\N	\N	\N
1640	James Duncan	Goold	1934-05-28	1997-07-27	\N	8	1	\N	\N	\N
1641	Amos Henry	Chilver	1926-10-30	2012-07-08	\N	4	1	\N	\N	\N
1642	Philip Douglas	Knights	1920-10-03	2014-12-11	\N	12	1	\N	\N	\N
1644	Peter John Mitchell	Thomas	1920-07-31	2008-02-04	\N	21	1	\N	\N	\N
1645	Douglas Patrick Thomas	Jay	1907-03-23	1996-03-06	\N	11	1	\N	\N	\N
1646	Francis Leslie	Pym	1922-02-13	2008-03-07	\N	17	1	\N	\N	\N
1647	Keith Sinjohn	Joseph	1918-01-17	1994-12-10	\N	11	1	\N	\N	\N
1648	John Donkin	Dormand	1919-08-27	2003-12-18	\N	5	1	\N	\N	\N
1649	James Michael Leathes	Prior	1927-10-11	2016-12-12	\N	17	1	\N	\N	\N
1650	Roger Nicholas	Edwards	1934-02-25	2018-03-17	\N	6	1	\N	\N	\N
1651	Humphrey Edward Gregory	Atkins	1922-08-12	1996-10-04	\N	2	1	\N	\N	\N
1652	Bernard	Donoughue	1934-09-08	\N	\N	5	1	\N	\N	\N
1653	Muriel Winifred	Turner	1922-09-18	2018-02-26	\N	21	2	\N	\N	\N
1654	William Hugh	Griffiths	1923-09-26	2015-05-30	\N	8	1	\N	\N	\N
1656	Roy Harris	Jenkins	1920-11-11	2003-01-05	\N	11	1	\N	\N	\N
1658	Judith Constance Mary	Hart	1924-09-18	1991-12-08	\N	9	2	\N	\N	\N
1659	John Francis	Donaldson	1920-10-06	2005-08-31	\N	5	1	\N	\N	\N
1660	Robert Temple	Armstrong	1927-03-30	\N	\N	2	1	\N	\N	\N
1661	Robert Scott	Alexander	1936-09-05	2005-11-06	\N	2	1	\N	\N	\N
1662	William	Rees-Mogg	1928-07-14	2012-12-29	\N	19	1	\N	\N	\N
1663	William John Hughes	Butterfield	1920-03-28	2000-07-22	\N	3	1	\N	\N	\N
1665	Donald	Macaulay	1933-11-14	2014-06-12	\N	14	1	\N	\N	\N
1666	John Davan	Sainsbury	1927-11-02	\N	\N	20	1	\N	\N	\N
1667	Jack	Lewis	1928-02-13	2014-07-17	\N	13	1	\N	\N	\N
1668	Sally	Oppenheim-Barnes	1930-07-26	\N	\N	16	2	\N	\N	\N
1669	Eric	Sharp	1916-08-17	1994-05-02	\N	20	1	\N	\N	\N
1670	John Nicholas	Walton	1922-09-16	2016-04-21	\N	24	1	\N	\N	\N
1671	Peter Lovat	Fraser	1945-05-29	2013-06-22	\N	7	1	\N	\N	\N
1672	Ian	McColl	1933-01-06	\N	\N	14	1	\N	\N	\N
1673	John David Elliott	Fieldhouse	1928-02-12	1992-02-17	\N	7	1	\N	\N	\N
1675	Francis Leonard	Tombs	1924-05-17	\N	\N	21	1	\N	\N	\N
1676	Stanley Clinton	Clinton-Davis	1928-12-06	\N	\N	4	1	\N	\N	\N
1677	Brian Robert	Morris	1930-12-04	2001-04-30	\N	14	1	\N	\N	\N
1678	Diana Catherine	Eccles	1933-10-04	\N	\N	6	2	\N	\N	\N
1680	William Oulton	Wade	1932-12-24	2018-06-07	\N	24	1	\N	\N	\N
1681	Richard Hugh	Cavendish	1941-11-02	\N	\N	4	1	\N	\N	\N
1682	Julia Frances	Cumberlege	1943-01-27	\N	\N	4	2	\N	\N	\N
1683	Ernest Jackson Lawson	Soulsby	1926-06-23	2017-05-08	\N	20	1	\N	\N	\N
1684	Richard Gordon	Holme	1936-05-27	2008-05-04	\N	9	1	\N	\N	\N
1685	Eric Graham	Varley	1932-08-11	2008-07-29	\N	23	1	\N	\N	\N
1686	Patricia Lesley	Hollis	1941-05-24	2018-10-13	\N	9	2	\N	\N	\N
1687	Shreela	Flather	1934-02-13	\N	\N	7	2	\N	\N	\N
1688	Malcolm Everard MacLaren	Pearson	1942-07-20	\N	\N	17	1	\N	\N	\N
1689	George	Porter	1920-12-06	2002-08-31	\N	17	1	\N	\N	\N
1690	Roy	Mason	1924-04-18	2015-04-19	\N	14	1	\N	\N	\N
1691	Mark	Carlisle	1929-07-07	2005-07-14	\N	4	1	\N	\N	\N
1694	Vincent Gordon Lindsay	White	1923-05-11	1995-08-23	\N	24	1	\N	\N	\N
1695	Robert Alexander Kennedy	Runcie	1921-10-02	2000-07-11	\N	19	1	\N	\N	\N
1696	Peter Garth	Palumbo	1935-07-20	\N	\N	17	1	\N	\N	\N
1697	Brian	Griffiths	1941-12-27	\N	\N	8	1	\N	\N	\N
1698	Hector	Laing	1923-05-12	2010-06-21	\N	13	1	\N	\N	\N
1699	Joan Anna Dalziel	Seccombe	1930-05-03	\N	\N	20	2	\N	\N	\N
1700	David	Wolfson	1935-11-09	\N	\N	24	1	\N	\N	\N
1701	Meghnad Jagdishchandra	Desai	1940-07-10	\N	\N	5	1	\N	\N	\N
1702	Sally Rachel	Hamwee	1947-01-12	\N	\N	9	2	\N	\N	\N
1704	Jean	Denton	1935-12-29	2001-02-05	\N	5	2	\N	\N	\N
1705	Jennifer	Hilton	1936-01-12	\N	\N	9	2	\N	\N	\N
1706	Ann	Mallalieu	1945-11-27	\N	\N	14	2	\N	\N	\N
1707	Detta	O'Cathain	1938-02-03	\N	\N	16	2	\N	\N	\N
1708	Andrew Colin	Renfrew	1937-07-25	\N	\N	19	1	\N	\N	\N
1709	John Jackson	Mackay	1938-11-15	2001-02-21	\N	14	1	\N	\N	\N
1710	Robert Jacob Alexander	Skidelsky	1939-04-25	\N	\N	20	1	\N	\N	\N
1711	Pauline	Perry	1931-10-15	\N	\N	17	2	\N	\N	\N
1713	Norman Somerville	Macfarlane	1926-03-05	\N	\N	14	1	\N	\N	\N
1714	David Brownrigg	Craig	1929-09-17	\N	\N	4	1	\N	\N	\N
1716	Michael John	Mustill	1931-05-10	2015-04-24	\N	14	1	\N	\N	\N
1717	Brian Norman Roger	Rix	1924-01-27	2016-08-20	\N	19	1	\N	\N	\N
1718	Reginald Ernest	Prentice	1923-07-16	2001-01-18	\N	17	1	\N	\N	\N
1719	William Thomas	Rodgers	1928-10-28	\N	\N	19	1	\N	\N	\N
1720	David Clive	Wilson	1935-02-14	\N	\N	24	1	\N	\N	\N
1721	Gordon	Slynn	1930-02-17	2009-04-07	\N	20	1	\N	\N	\N
1722	John	Wakeham	1932-06-22	\N	\N	24	1	\N	\N	\N
1724	Peter Murray	Taylor	1930-05-01	1997-04-28	\N	21	1	\N	\N	\N
1725	Alan Ferguson	Rodger	1944-09-18	2011-06-26	\N	19	1	\N	\N	\N
1726	Margaret Hilda	Thatcher	1925-10-13	2013-04-08	\N	21	2	\N	\N	\N
1727	Geoffrey	Finsberg	1926-06-13	1996-10-07	\N	7	1	\N	\N	\N
1729	Denis Winston	Healey	1917-08-30	2015-10-03	\N	9	1	\N	\N	\N
1730	Peter Stewart	Lane	1925-01-29	2009-01-09	\N	13	1	\N	\N	\N
1731	Robert	Haslam	1923-02-04	2002-11-02	\N	9	1	\N	\N	\N
1732	Jeffrey Maurice	Sterling	1934-12-27	\N	\N	20	1	\N	\N	\N
1733	John Edward Michael	Moore	1937-11-26	2019-05-20	\N	14	1	\N	\N	\N
1734	Norman Beresford	Tebbit	1931-03-29	\N	\N	21	1	\N	\N	\N
1735	George Kenneth Hotson	Younger	1931-09-22	2003-01-26	\N	26	1	\N	\N	\N
1628	Woodrow Lyle	Wyatt	1918-07-04	1997-12-07	\N	24	1	\N	\N	\N
1738	Peter Kingsley	Archer	1926-11-20	2012-06-14	\N	2	1	\N	\N	\N
1739	Jack	Ashley	1922-12-06	2012-04-20	\N	2	1	\N	\N	\N
1740	John Leonard	Eatwell	1945-02-02	\N	\N	6	1	\N	\N	\N
1742	Harry	Ewing	1931-01-20	2007-06-09	\N	6	1	\N	\N	\N
1744	Bernard Harold Ian Halley	Stewart	1935-08-10	2018-03-03	\N	20	1	\N	\N	\N
1745	William Gibson Haig	Clark	1917-10-18	2004-10-04	\N	4	1	\N	\N	\N
1746	Raymond	Plant	1945-03-19	\N	\N	17	1	\N	\N	\N
1747	Jeffrey Howard	Archer	1940-04-15	\N	\N	2	1	\N	\N	\N
1748	Nicholas	Ridley	1929-02-17	1993-03-04	\N	19	1	\N	\N	\N
1749	Margaret Ann	Jay	1939-11-18	\N	\N	11	2	\N	\N	\N
1750	Gareth Wyn	Williams	1941-02-05	2003-09-20	\N	24	1	\N	\N	\N
1752	Victor Alexander	Cooke	1920-10-18	2007-11-13	\N	4	1	\N	\N	\N
1753	Bernard John	Hayhoe	1925-08-08	2013-09-07	\N	9	1	\N	\N	\N
1754	Ian Hedworth John Little	Gilmour	1926-07-08	2007-09-21	\N	8	1	\N	\N	\N
1755	Dafydd Elis	Elis-Thomas	1946-10-18	\N	\N	6	1	\N	\N	\N
1756	Shirley Vivien Teresa Brittain	Williams	1930-07-27	\N	\N	24	2	\N	\N	\N
1757	Robert	Leigh-Pemberton	1927-01-05	2013-11-24	\N	13	1	\N	\N	\N
1758	Ralf	Dahrendorf	1929-05-01	2009-06-17	\N	5	1	\N	\N	\N
1759	Yehudi	Menuhin	1916-04-22	1999-03-12	\N	14	1	\N	\N	\N
1761	Anthony John Leslie	Lloyd	1929-05-09	\N	\N	13	1	\N	\N	\N
1762	Simon	Haskel	1934-10-09	\N	\N	9	1	\N	\N	\N
1763	Arthur Paul	Dean	1924-09-14	2009-04-01	\N	5	1	\N	\N	\N
1764	Joyce Brenda	Gould	1932-10-29	\N	\N	8	2	\N	\N	\N
1765	Robert William	Dixon-Smith	1934-09-30	\N	\N	5	1	\N	\N	\N
1766	Brenda	Dean	1943-04-29	2018-03-13	\N	5	2	\N	\N	\N
1767	Anthony Paul	Lester	1936-07-03	\N	\N	13	1	\N	\N	\N
1768	Doreen	Miller	1933-06-13	2014-06-21	\N	14	2	\N	\N	\N
1769	Nigel	Lawson	1932-03-11	\N	\N	13	1	\N	\N	\N
1772	David Chilton	Phillips	1924-03-07	1999-02-23	\N	17	1	\N	\N	\N
1773	Allen John George	Sheppard	1932-12-25	2015-03-25	\N	20	1	\N	\N	\N
1774	Charles Eric Alexander	Hambro	1930-07-24	2002-11-07	\N	9	1	\N	\N	\N
1775	Alfred	Dubs	1932-12-05	\N	\N	5	1	\N	\N	\N
1776	Derek Oliver	Gladwin	1930-06-06	2003-04-10	\N	8	1	\N	\N	\N
1777	Josephine	Farrington	1940-06-29	2018-03-30	\N	7	2	\N	\N	\N
1778	Michael Norman	Shaw	1920-10-09	\N	\N	20	1	\N	\N	\N
1779	Donald James	Nicholls	1933-01-25	2019-09-25	\N	15	1	\N	\N	\N
1780	Graham Norman	Tope	1943-11-30	\N	\N	21	1	\N	\N	\N
1782	Susan Petronella	Thomas	1935-12-20	\N	\N	21	2	\N	\N	\N
1783	Christopher James	Prout	1942-01-01	2009-07-12	\N	17	1	\N	\N	\N
1784	Peter Allan Renshaw	Blaker	1922-10-04	2009-07-05	\N	3	1	\N	\N	\N
1785	Johan van Zyl	Steyn	1932-08-15	2017-11-28	\N	20	1	\N	\N	\N
1786	Sarah Elizabeth Mary	Hogg	1946-05-14	\N	\N	9	2	\N	\N	\N
1788	Elizabeth Margaret	Smith	1940-06-04	\N	\N	20	2	\N	\N	\N
1789	Leonard Hubert	Hoffmann	1934-05-08	\N	\N	9	1	\N	\N	\N
1790	James	Blyth	1940-05-08	\N	\N	3	1	\N	\N	\N
1791	John Graham	Cuckney	1925-07-12	2008-10-30	\N	4	1	\N	\N	\N
1793	John Stapylton	Habgood	1927-06-23	2019-03-06	\N	9	1	\N	\N	\N
1794	Donald Sage	Mackay	1946-01-30	2018-08-21	\N	14	1	\N	\N	\N
1795	Robert Maurice Lipson	Winston	1940-07-15	\N	\N	24	1	\N	\N	\N
1796	William John Lawrence	Wallace	1941-03-12	\N	\N	24	1	\N	\N	\N
1797	Tom	McNally	1943-02-20	\N	\N	14	1	\N	\N	\N
1798	Gordon Johnson	Borrie	1931-03-13	2016-09-30	\N	3	1	\N	\N	\N
1799	Helene Valerie	Hayman	1949-03-26	\N	\N	9	2	\N	\N	\N
1800	John Buttifant	Sewel	1946-01-15	\N	\N	20	1	\N	\N	\N
1802	Basil	Feldman	1926-09-23	2019-11-19	\N	7	1	\N	\N	\N
1803	Judith Ann	Wilcox	1940-10-31	\N	\N	24	2	\N	\N	\N
1804	Robert	Kilpatrick	1926-07-29	2015-09-16	\N	12	1	\N	\N	\N
1805	David Howe	Gillmore	1934-08-16	1999-03-20	\N	8	1	\N	\N	\N
1806	Thomas Henry	Bingham	1933-10-13	2010-09-11	\N	3	1	\N	\N	\N
1807	Michael Patrick	Nolan	1928-09-10	2007-01-22	\N	15	1	\N	\N	\N
1808	Dick	Taverne	1928-10-18	\N	\N	21	1	\N	\N	\N
1809	David Wigley	Nickson	1929-11-27	\N	\N	15	1	\N	\N	\N
1811	John David Beckett	Taylor	1952-09-21	\N	\N	21	1	\N	\N	\N
1812	Maurice	Saatchi	1946-06-21	\N	\N	20	1	\N	\N	\N
1814	John	Alderdice	1955-03-28	\N	\N	2	1	\N	\N	\N
1815	Swraj	Paul	1931-02-18	\N	\N	17	1	\N	\N	\N
1816	Meta	Ramsay	1936-07-12	\N	\N	19	2	\N	\N	\N
1817	Joyce Anne	Anelay	1947-07-17	\N	\N	2	2	\N	\N	\N
1818	Hazel	Byford	1941-01-14	\N	\N	3	2	\N	\N	\N
1819	Richard George	Rogers	1933-07-23	\N	\N	19	1	\N	\N	\N
1821	John Lawrence	Whitty	1943-06-15	\N	\N	24	1	\N	\N	\N
1822	Audrey Caroline	Emerton	1935-09-10	\N	\N	6	2	\N	\N	\N
1823	Andrew	Lloyd Webber	1948-03-22	\N	\N	13	1	\N	\N	\N
1824	Eric Douglas Harvey	Hoyle	1930-02-17	\N	\N	9	1	\N	\N	\N
1825	Charles Leslie	Falconer	1951-11-19	\N	\N	7	1	\N	\N	\N
1826	David Alec Gwyn	Simon	1939-07-24	\N	\N	20	1	\N	\N	\N
1827	John William	Gilbert	1927-04-05	2013-06-02	\N	8	1	\N	\N	\N
1828	William John	Biffen	1930-11-10	2007-08-14	\N	3	1	\N	\N	\N
1829	Joan	Lestor	1931-11-13	1998-03-27	\N	13	2	\N	\N	\N
1831	Thomas Michael	Jopling	1930-12-10	\N	\N	11	1	\N	\N	\N
1832	Peter David	Shore	1924-05-20	2001-09-24	\N	20	1	\N	\N	\N
1834	David Martin Scott	Steel	1938-03-31	\N	\N	20	1	\N	\N	\N
1835	Donald	Dixon	1929-03-06	2017-02-19	\N	5	1	\N	\N	\N
1836	Ronald Timothy	Renton	1932-05-28	\N	\N	19	1	\N	\N	\N
1837	John	Evans	1930-10-19	2016-03-05	\N	6	1	\N	\N	\N
1838	James Henry	Molyneaux	1920-08-27	2015-03-09	\N	14	1	\N	\N	\N
1839	Geoffrey	Lofthouse	1925-12-18	2012-11-01	\N	13	1	\N	\N	\N
1840	Henry Paul Guinness	Channon	1935-10-09	2007-01-27	\N	4	1	\N	\N	\N
1841	David Patrick Paul	Alton	1951-03-15	\N	\N	2	1	\N	\N	\N
1843	Douglas Richard	Hurd	1930-03-08	\N	\N	9	1	\N	\N	\N
1844	Kenneth Wilfred	Baker	1934-11-03	\N	\N	3	1	\N	\N	\N
1845	John Haggitt Charles	Patten	1945-07-17	\N	\N	17	1	\N	\N	\N
1846	Michael Colin	Cowdrey	1932-12-24	2000-12-04	\N	4	1	\N	\N	\N
1847	Richard Frederick	Vincent	1931-08-23	2018-09-08	\N	23	1	\N	\N	\N
1737	Peter Edward	Walker	1932-03-25	2010-06-23	\N	24	1	\N	\N	\N
2801	Henry Charles	Brougham	1836-09-02	1927-05-24	\N	3	1	\N	\N	\N
1850	Michael Abraham	Levy	1944-07-11	\N	\N	13	1	\N	\N	\N
1851	Valerie Ann	Amos	1954-03-13	\N	\N	2	2	\N	\N	\N
1852	Norman	Hogg	1938-03-12	2008-10-08	\N	9	1	\N	\N	\N
1853	Richard Mark	Newby	1953-02-14	\N	\N	15	1	\N	\N	\N
1855	Robin William	Renwick	1937-12-13	\N	\N	19	1	\N	\N	\N
1856	Harold	Walker	1927-07-12	2003-11-11	\N	24	1	\N	\N	\N
1857	Peter	Hardy	1931-07-17	2003-12-16	\N	9	1	\N	\N	\N
1858	Robert	Hughes	1932-01-03	\N	\N	9	1	\N	\N	\N
1860	Ian Bruce	Lang	1940-06-27	\N	\N	13	1	\N	\N	\N
1861	Sarah Ann	Ludford	1951-03-14	\N	\N	13	2	\N	\N	\N
1862	Janet Evelyn	Fookes	1936-02-21	\N	\N	7	2	\N	\N	\N
1863	Ieuan Wyn Pritchard	Roberts	1930-07-10	2013-12-13	\N	19	1	\N	\N	\N
1865	Norman Roy	Blackwell	1952-07-29	\N	\N	3	1	\N	\N	\N
1866	Bryan	Davies	1939-11-09	\N	\N	5	1	\N	\N	\N
1867	James Stuart	Gordon	1936-05-17	\N	\N	8	1	\N	\N	\N
1868	John Ambrose	Cope	1937-05-13	\N	\N	4	1	\N	\N	\N
1869	Jill Elizabeth	Pitkeathley	1940-01-04	\N	\N	17	2	\N	\N	\N
1870	David Anthony	Jacobs	1931-11-13	2014-06-21	\N	11	1	\N	\N	\N
1871	Philip Alexander	Hunt	1949-05-19	\N	\N	9	1	\N	\N	\N
1872	David James Fletcher	Hunt	1942-05-21	\N	\N	9	1	\N	\N	\N
1873	Stanley	Orme	1923-04-05	2005-04-28	\N	16	1	\N	\N	\N
1874	Thomas Henry	Burlison	1936-05-23	2008-05-20	\N	3	1	\N	\N	\N
1875	Edward Timothy	Razzall	1943-06-12	\N	\N	19	1	\N	\N	\N
1877	William Howard	Goodhart	1933-01-18	2017-01-10	\N	8	1	\N	\N	\N
1878	Clive	Brooke	1942-06-21	\N	\N	3	1	\N	\N	\N
1879	Ruth Barbara	Rendell	1930-02-17	2015-05-02	\N	19	2	\N	\N	\N
1880	Navnit	Dholakia	1937-03-04	\N	\N	5	1	\N	\N	\N
1882	Royston John	Hughes	1925-06-09	2003-12-19	\N	9	1	\N	\N	\N
1883	David Terence	Puttnam	1941-02-25	\N	\N	17	1	\N	\N	\N
1884	Helena Ann	Kennedy	1950-05-12	\N	\N	12	2	\N	\N	\N
1885	Michael Wolfgang Laurence	Morris	1936-11-25	\N	\N	14	1	\N	\N	\N
1886	Terence Langley	Higgins	1928-01-18	\N	\N	9	1	\N	\N	\N
1887	Peter Anthony	Inge	1935-08-05	\N	\N	10	1	\N	\N	\N
1888	Peter Keith	Levene	1941-12-08	\N	\N	13	1	\N	\N	\N
1890	Cranley Gordon Douglas	Onslow	1926-06-08	2001-03-13	\N	16	1	\N	\N	\N
1891	Antony Harold	Newton	1937-08-29	2012-03-25	\N	15	1	\N	\N	\N
1892	Veronica	Linklater	1943-04-15	\N	\N	13	2	\N	\N	\N
1893	John Steven	Bassam	1953-06-11	\N	\N	3	1	\N	\N	\N
1894	Emma Harriet	Nicholson	1941-10-16	\N	\N	15	2	\N	\N	\N
1895	Barbara Scott	Young	1948-04-08	\N	\N	26	2	\N	\N	\N
1896	Trevor Arthur	Smith	1937-06-14	\N	\N	20	1	\N	\N	\N
1897	Terence James	Thomas	1937-10-19	2018-07-01	\N	21	1	\N	\N	\N
1898	George	Simpson	1942-07-02	\N	\N	20	1	\N	\N	\N
1900	Michael Goodall	Watson	1949-05-01	\N	\N	24	1	\N	\N	\N
1901	Richard Andrew	Ryder	1949-02-04	\N	\N	19	1	\N	\N	\N
1903	Francis Patrick	Neill	1926-08-08	2016-05-28	\N	15	1	\N	\N	\N
1904	Frederick Edward Robin	Butler	1938-01-03	\N	\N	3	1	\N	\N	\N
1905	Ronald Ernest	Dearing	1930-07-27	2009-02-19	\N	5	1	\N	\N	\N
1906	Paul Bertrand	Hamlyn	1926-02-12	2001-08-31	\N	9	1	\N	\N	\N
1907	Brian	Mackenzie	1943-03-21	\N	\N	14	1	\N	\N	\N
1908	Timothy Francis	Clement-Jones	1949-10-26	\N	\N	4	1	\N	\N	\N
1909	Waheed	Alli	1964-11-16	\N	\N	2	1	\N	\N	\N
1911	Terence	Burns	1944-03-13	\N	\N	3	1	\N	\N	\N
1912	Mary Teresa	Goudie	1946-09-02	\N	\N	8	2	\N	\N	\N
1913	John Edward	Tomlinson	1939-08-01	\N	\N	21	1	\N	\N	\N
1914	Peta Jane	Buscombe	1954-03-12	\N	\N	3	2	\N	\N	\N
1915	Dorothea Glenys	Thornton	1952-10-16	\N	\N	21	2	\N	\N	\N
1917	Christine Mary	Crawley	1950-01-01	\N	\N	4	2	\N	\N	\N
1918	Andrew Wyndham	Phillips	1939-03-15	\N	\N	17	1	\N	\N	\N
1919	William Herbert	Laming	1936-07-19	\N	\N	13	1	\N	\N	\N
1920	William Stephen Goulden	Bach	1946-12-25	\N	\N	3	1	\N	\N	\N
1921	Susan Elizabeth	Miller	1954-01-01	\N	\N	14	2	\N	\N	\N
1922	David Charles	Evans	1942-11-30	\N	\N	6	1	\N	\N	\N
1923	Norman Reginald	Warner	1940-09-08	\N	\N	24	1	\N	\N	\N
1924	Anthony James	Clarke	1932-04-17	\N	\N	4	1	\N	\N	\N
1925	David Keith	Brookman	1937-01-03	\N	\N	3	1	\N	\N	\N
1927	Roger Norman	Freeman	1942-05-27	\N	\N	7	1	\N	\N	\N
1929	Patricia Janet	Scotland	1955-08-19	\N	\N	20	2	\N	\N	\N
1930	Melvyn	Bragg	1939-10-06	\N	\N	3	1	\N	\N	\N
1931	Lawrence	Sawyer	1943-05-12	\N	\N	20	1	\N	\N	\N
1932	Jonathan Toby	Harris	1953-10-11	\N	\N	9	1	\N	\N	\N
1933	David Francis	Williamson	1934-05-08	2015-08-30	\N	24	1	\N	\N	\N
1934	Angus John	Macdonald	1940-08-20	\N	\N	14	1	\N	\N	\N
1935	John Stewart	Hobhouse	1932-01-31	2004-03-15	\N	9	1	\N	\N	\N
1936	Peter Julian	Millett	1932-06-23	\N	\N	14	1	\N	\N	\N
1938	Onora Sylvia	O'Neill	1941-08-23	\N	\N	16	2	\N	\N	\N
1939	Narendra Babubhai	Patel	1938-05-11	\N	\N	17	1	\N	\N	\N
1940	Alexander James	Trotman	1933-07-22	2005-04-25	\N	21	1	\N	\N	\N
1941	Diana Mary	Warwick	1945-07-16	\N	\N	24	2	\N	\N	\N
1942	Robert	Fellowes	1941-12-11	\N	\N	7	1	\N	\N	\N
1943	Henry Dennistoun	Stevenson	1945-07-19	\N	\N	20	1	\N	\N	\N
1944	Vivien Helen	Stern	1941-09-25	\N	\N	20	2	\N	\N	\N
1946	Richard Oliver	Faulkner	1946-03-22	\N	\N	7	1	\N	\N	\N
1947	Usha Kumari	Prashar	1948-06-29	\N	\N	17	2	\N	\N	\N
1948	Joan Brownlow	Hanham	1939-09-23	\N	\N	9	2	\N	\N	\N
1949	John Dunn	Laird	1944-04-23	2018-07-10	\N	13	1	\N	\N	\N
1950	Dennis Robert David	Rogan	1942-06-30	\N	\N	19	1	\N	\N	\N
1951	Thomas Murray	Elder	1950-05-09	\N	\N	6	1	\N	\N	\N
1952	David Edward	Lea	1937-11-02	\N	\N	13	1	\N	\N	\N
1953	William Henry	Brett	1942-03-06	2012-03-29	\N	3	1	\N	\N	\N
1956	Tarsem	King	1937-04-24	2013-01-09	\N	12	1	\N	\N	\N
1957	Alan John	Watson	1941-02-03	\N	\N	24	1	\N	\N	\N
1958	Graham	Kirkham	1944-12-14	\N	\N	12	1	\N	\N	\N
1959	Anthony Stephen	Grabiner	1945-03-21	\N	\N	8	1	\N	\N	\N
1960	Doreen Elizabeth	Massey	1938-09-05	\N	\N	14	2	\N	\N	\N
1849	Donald Martin	Thomas	1937-03-13	\N	\N	21	1	\N	\N	\N
2802	Victor Henry Peter	Brougham	1909-10-23	1967-06-20	\N	3	1	\N	\N	\N
1963	Lyndon Henry Arthur	Harrison	1947-09-28	\N	\N	9	1	\N	\N	\N
1964	William Arthur	Waldegrave	1946-08-15	\N	\N	24	1	\N	\N	\N
1965	Peter Henry	Goldsmith	1950-01-05	\N	\N	8	1	\N	\N	\N
1967	Philip	Norton	1951-03-05	\N	\N	15	1	\N	\N	\N
1968	Margaret Lucy	Sharp	1938-11-21	\N	\N	20	2	\N	\N	\N
1969	Nazir	Ahmed	1957-04-24	\N	\N	2	1	\N	\N	\N
1970	Colin Morven	Sharman	1943-02-19	\N	\N	20	1	\N	\N	\N
1971	Catherine Margaret	Ashton	1956-03-20	\N	\N	2	2	\N	\N	\N
1972	Genista Mary	McIntosh	1946-09-23	\N	\N	14	2	\N	\N	\N
1974	Anita	Gale	1940-11-28	\N	\N	8	2	\N	\N	\N
1975	Hector Uisdean	MacKenzie	1940-02-25	\N	\N	14	1	\N	\N	\N
1976	Peter Richard Charles	Smith	1945-07-24	\N	\N	20	1	\N	\N	\N
1977	Janet Alison	Whitaker	1936-02-20	\N	\N	24	2	\N	\N	\N
1978	Robert	Gavron	1930-09-13	2015-02-07	\N	8	1	\N	\N	\N
1979	Angela Felicity	Harris	1944-01-04	\N	\N	9	2	\N	\N	\N
1981	Rupert Bertram	Mitford	1967-07-18	\N	\N	14	1	\N	\N	\N
1983	Thomas Orlando	Lyttelton	1953-02-12	\N	\N	13	1	\N	\N	\N
1984	James Thorne	Erskine	1949-03-10	\N	\N	6	1	\N	\N	\N
1985	Frederick Matthew Thomas	Ponsonby	1958-10-27	\N	\N	17	1	\N	\N	\N
1986	William Brian	Jordan	1936-01-28	\N	\N	11	1	\N	\N	\N
1987	Sheila Valerie	Masters	1949-06-23	\N	\N	14	2	\N	\N	\N
1988	Robin Granville	Hodgson	1942-04-25	\N	\N	9	1	\N	\N	\N
1989	Kenneth Owen	Morgan	1934-05-16	\N	\N	14	1	\N	\N	\N
1990	Richard Rashleigh Folliott	Scott	1934-10-02	\N	\N	20	1	\N	\N	\N
1991	Richard Napier	Luce	1936-10-14	\N	\N	13	1	\N	\N	\N
1992	Michael Anthony	Ashcroft	1946-03-04	\N	\N	2	1	\N	\N	\N
1993	Betty	Boothroyd	1929-10-08	\N	\N	3	2	\N	\N	\N
1994	Austin Richard William	Low	1914-05-25	2000-12-07	\N	13	1	\N	\N	\N
1997	Daniel Joseph	Brennan	1942-03-19	\N	\N	3	1	\N	\N	\N
1998	Janet	Cohen	1940-07-04	\N	\N	4	2	\N	\N	\N
1999	David Lawrence	Lipsey	1948-04-21	\N	\N	13	1	\N	\N	\N
2000	May	Blood	1938-05-26	\N	\N	3	2	\N	\N	\N
2001	Elizabeth Jean	Barker	1961-01-31	\N	\N	3	2	\N	\N	\N
2002	Peter Alexander Rupert	Carington	1919-06-06	2018-07-09	\N	4	1	\N	\N	\N
2003	Leon	Brittan	1939-09-25	2015-01-21	\N	3	1	\N	\N	\N
2004	Sally Ralea	Greengross	1935-06-29	\N	\N	8	2	\N	\N	\N
2005	John	Birt	1944-12-10	\N	\N	3	1	\N	\N	\N
2007	Charles David	Powell	1941-07-06	\N	\N	17	1	\N	\N	\N
2008	Joel Goodman	Joffe	1932-05-12	2017-06-18	\N	11	1	\N	\N	\N
2009	Richard Gerald	Lyon-Dalberg-Acton	1941-07-30	2010-10-10	\N	13	1	\N	\N	\N
2010	Anne	Gibson	1940-12-10	2018-04-20	\N	8	2	\N	\N	\N
2011	Elizabeth Kay	Andrews	1943-05-16	\N	\N	2	2	\N	\N	\N
2012	Parry Andrew	Mitchell	1943-05-06	\N	\N	14	1	\N	\N	\N
2013	Bhikhu Chotalal	Parekh	1935-01-04	\N	\N	17	1	\N	\N	\N
2014	Rosalind Carol	Scott	1957-08-10	\N	\N	20	2	\N	\N	\N
2015	Matthew	Evans	1941-08-07	2016-07-06	\N	6	1	\N	\N	\N
2017	John Francis Hodgess	Roper	1935-09-10	2016-01-29	\N	19	1	\N	\N	\N
2018	Joan Margaret	Walmsley	1943-04-12	\N	\N	24	2	\N	\N	\N
2019	Alexander	Bernstein	1936-03-15	2010-04-12	\N	3	1	\N	\N	\N
2020	George Lennox	Fyfe	1941-04-10	2011-02-01	\N	7	1	\N	\N	\N
2021	Sebastian Newbold	Coe	1956-09-29	\N	\N	4	1	\N	\N	\N
2023	Matthew Alan	Oakeshott	1947-01-10	\N	\N	16	1	\N	\N	\N
2024	Angela Theodora	Billingham	1939-07-31	\N	\N	3	2	\N	\N	\N
2025	Peter Richard Grenville	Layard	1934-03-15	\N	\N	13	1	\N	\N	\N
2026	Anthony Robert	Greaves	1942-07-27	\N	\N	8	1	\N	\N	\N
2027	Leslie Arnold	Turnberg	1934-03-22	\N	\N	21	1	\N	\N	\N
2029	Michael Chew Koon	Chan	1940-03-06	2006-01-21	\N	4	1	\N	\N	\N
2030	Richard Stuart	Best	1945-06-22	\N	\N	3	1	\N	\N	\N
2031	Amirali Alibhai	Bhatia	1932-03-18	\N	\N	3	1	\N	\N	\N
2032	Jeffrey William	Rooker	1941-06-05	\N	\N	19	1	\N	\N	\N
2033	Susan Adele	Greenfield	1950-10-01	\N	\N	8	2	\N	\N	\N
2034	David Hugh Alexander	Hannay	1935-09-28	\N	\N	9	1	\N	\N	\N
2035	David James George	Hennessy	1932-01-28	2010-12-21	\N	9	1	\N	\N	\N
2037	Herman George	Ouseley	1945-03-24	\N	\N	16	1	\N	\N	\N
2039	Paul Leslie	Condon	1947-03-10	\N	\N	4	1	\N	\N	\N
2040	Ilora Gillian	Finlay	1949-02-23	\N	\N	7	2	\N	\N	\N
2041	Edmund John Phillip	Browne	1948-02-20	\N	\N	3	1	\N	\N	\N
2042	Elspeth Rosamund Morton	Howe	1932-02-08	\N	\N	9	2	\N	\N	\N
2043	Stewart Ross	Sutherland	1941-02-25	2018-01-29	\N	20	1	\N	\N	\N
2044	Victor Olufemi	Adebowale	1962-07-21	\N	\N	2	1	\N	\N	\N
2045	Bruce Joseph	Grocott	1940-11-01	\N	\N	8	1	\N	\N	\N
2047	John	Morris	1931-11-05	\N	\N	14	1	\N	\N	\N
2049	Thomas	Pendry	1934-06-10	\N	\N	17	1	\N	\N	\N
2050	Dale Norman	Campbell-Savours	1943-08-23	\N	\N	4	1	\N	\N	\N
2051	John Roddick Russell	MacGregor	1937-02-14	\N	\N	14	1	\N	\N	\N
2052	Robin	Corbett	1933-12-22	2012-02-19	\N	4	1	\N	\N	\N
2053	Stephen Barry	Jones	1937-06-26	\N	\N	11	1	\N	\N	\N
2055	Jeremy John Durham	Ashdown	1941-02-27	2018-12-22	\N	2	1	\N	\N	\N
2056	Ronald Cyril	Fearn	1931-02-06	\N	\N	7	1	\N	\N	\N
2057	Michael Ray Dibdin	Heseltine	1933-03-21	\N	\N	9	1	\N	\N	\N
2058	Janet Ray	Michie	1934-02-04	2008-05-06	\N	14	2	\N	\N	\N
2059	Giles Heneage	Radice	1936-10-04	\N	\N	19	1	\N	\N	\N
2060	John David	Taylor	1937-12-24	\N	\N	21	1	\N	\N	\N
2061	Robert McCredie	May	1936-01-08	\N	\N	14	1	\N	\N	\N
2063	Llinos	Golding	1933-03-21	\N	\N	8	2	\N	\N	\N
2064	Kenneth Wiggins	Maginnis	1938-01-21	\N	\N	14	1	\N	\N	\N
2065	Peter Leonard	Brooke	1934-03-03	\N	\N	3	1	\N	\N	\N
2066	Conrad Moffat	Black	1944-08-25	\N	\N	3	1	\N	\N	\N
2067	Robert	Walker	1938-03-17	\N	\N	24	1	\N	\N	\N
2068	George Leonard	Carey	1935-11-13	\N	\N	4	1	\N	\N	\N
2069	Richard Thomas James	Wilson	1942-10-11	\N	\N	24	1	\N	\N	\N
2070	Michael Cecil	Boyce	1943-04-02	\N	\N	3	1	\N	\N	\N
2072	David Maxim	Triesman	1943-10-30	\N	\N	21	1	\N	\N	\N
1962	Ernest Ronald	Oxburgh	1934-11-02	\N	\N	16	1	\N	\N	\N
2803	Michael John	Brougham	1938-08-02	\N	\N	3	1	\N	\N	\N
2075	Claus Adolf	Moser	1922-11-24	2015-09-04	\N	14	1	\N	\N	\N
2076	Valerie Georgina	Howarth	1940-09-05	\N	\N	9	2	\N	\N	\N
2078	Timothy	Garden	1944-04-23	2007-08-09	\N	8	1	\N	\N	\N
2080	Garry Richard Rushby	Hart	1940-06-29	2017-08-03	\N	9	1	\N	\N	\N
2081	Alexander Park	Leitch	1947-10-20	\N	\N	13	1	\N	\N	\N
2082	Philip	Gould	1950-03-30	2011-11-06	\N	8	1	\N	\N	\N
2083	Ruth Beatrice	Henig	1943-11-10	\N	\N	9	2	\N	\N	\N
2084	Patrick Robert	Carter	1946-02-09	\N	\N	4	1	\N	\N	\N
2085	Peter Charles	Snape	1942-02-12	\N	\N	20	1	\N	\N	\N
2086	Peter Derek	Truscott	1959-03-20	\N	\N	21	1	\N	\N	\N
2088	Margaret Theresa	Prosser	1937-08-22	\N	\N	17	2	\N	\N	\N
2089	Delyth Jane	Morgan	1961-08-30	\N	\N	14	2	\N	\N	\N
2090	Richard Andrew	Rosser	1944-10-05	\N	\N	19	1	\N	\N	\N
2091	Julia Babette Sarah	Neuberger	1950-02-27	\N	\N	15	2	\N	\N	\N
2092	John Roger	Roberts	1935-10-23	\N	\N	19	1	\N	\N	\N
2093	Anthony	Giddens	1938-01-18	\N	\N	8	1	\N	\N	\N
2094	Diljit Singh	Rana	1938-09-20	\N	\N	19	1	\N	\N	\N
2095	Elaine	Murphy	1947-01-16	\N	\N	14	2	\N	\N	\N
2097	Edward Enda	Haughey	1944-01-05	2014-03-13	\N	9	1	\N	\N	\N
2098	William David	McKenzie	1946-07-24	\N	\N	14	1	\N	\N	\N
2099	Hugh John Maxwell	Dykes	1939-05-17	\N	\N	5	1	\N	\N	\N
2100	Alec Nigel	Broers	1938-09-17	\N	\N	3	1	\N	\N	\N
2101	Iain David Thomas	Vallance	1943-05-20	\N	\N	23	1	\N	\N	\N
2102	Leonard	Steinberg	1936-08-01	2009-11-02	\N	20	1	\N	\N	\N
2103	Jane	Bonham Carter	1957-10-20	\N	\N	3	2	\N	\N	\N
2104	Nicola Jane	Chapman	1961-08-03	2009-09-03	\N	4	2	\N	\N	\N
2106	Anthony Ian	Young	1942-04-16	\N	\N	26	1	\N	\N	\N
2107	Janet Anne	Royall	1955-08-20	\N	\N	19	2	\N	\N	\N
2109	Alan Robert	Haworth	1948-04-26	\N	\N	9	1	\N	\N	\N
2110	Ewen James Hanning	Cameron	1949-11-24	\N	\N	4	1	\N	\N	\N
2111	Edward Alan John	George	1938-09-11	2009-04-18	\N	8	1	\N	\N	\N
2112	John Olav	Kerr	1942-02-22	\N	\N	12	1	\N	\N	\N
2113	Frances Gertrude Claire	D'Souza	1944-04-18	\N	\N	5	2	\N	\N	\N
2114	David	Alliance	1932-06-15	\N	\N	2	1	\N	\N	\N
2115	Christopher Francis	Patten	1944-05-12	\N	\N	17	1	\N	\N	\N
2116	Paul Rudd	Drayson	1960-03-05	\N	\N	5	1	\N	\N	\N
2117	Denis	Tunnicliffe	1943-01-17	\N	\N	21	1	\N	\N	\N
2119	Irene Tordoff	Fritchie	1942-04-29	\N	\N	7	2	\N	\N	\N
2120	Archibald Johnstone	Kirkwood	1946-04-22	\N	\N	12	1	\N	\N	\N
2121	Winifred Ann	Taylor	1947-07-02	\N	\N	21	2	\N	\N	\N
2122	Estelle	Morris	1952-06-17	\N	\N	14	2	\N	\N	\N
2123	Martin John	O'Neill	1945-01-06	\N	\N	16	1	\N	\N	\N
2124	Alan Thomas	Howarth	1944-06-11	\N	\N	9	1	\N	\N	\N
2125	Paul Archer	Tyler	1941-10-29	\N	\N	21	1	\N	\N	\N
2128	Nigel David	Jones	1948-03-30	\N	\N	11	1	\N	\N	\N
2129	Dennis	Turner	1942-08-26	2014-02-25	\N	21	1	\N	\N	\N
2130	Gillian Patricia	Shephard	1940-01-22	\N	\N	20	2	\N	\N	\N
2131	Lynda Margaret	Clark	1949-02-26	\N	\N	4	2	\N	\N	\N
2132	Lewis George	Moonie	1947-02-25	\N	\N	14	1	\N	\N	\N
2133	Christopher Robert	Smith	1951-07-24	\N	\N	20	1	\N	\N	\N
2134	Jennifer Louise	Tonge	1941-02-19	\N	\N	21	2	\N	\N	\N
2135	Anthony Louis	Banks	1943-04-08	2006-01-08	\N	3	1	\N	\N	\N
2137	Brian Stanley	Mawhinney	1940-07-26	2019-11-09	\N	14	1	\N	\N	\N
2138	John Anderson	Cunningham	1939-08-04	\N	\N	4	1	\N	\N	\N
2139	Nicholas Walter	Lyell	1938-12-06	2010-08-30	\N	13	1	\N	\N	\N
2140	Donald	Anderson	1939-06-17	\N	\N	2	1	\N	\N	\N
2142	Jean Ann	Corston	1942-05-05	\N	\N	4	2	\N	\N	\N
2143	Alastair Robertson	Goodlad	1943-07-04	\N	\N	8	1	\N	\N	\N
2144	Martin John	Rees	1942-06-23	\N	\N	19	1	\N	\N	\N
2145	Jonathan Adair	Turner	1955-10-05	\N	\N	21	1	\N	\N	\N
2146	Jonathan Hugh	Mance	1943-06-06	\N	\N	14	1	\N	\N	\N
2147	Ruth Lynn	Deech	1943-04-29	\N	\N	5	2	\N	\N	\N
2148	Josephine Clare	Valentine	1958-12-08	\N	\N	23	2	\N	\N	\N
2149	Andrew	Turnbull	1945-01-21	\N	\N	21	1	\N	\N	\N
2150	Michael John	Hastings	1958-01-29	\N	\N	9	1	\N	\N	\N
2152	Edmund Nigel Ramsay	Crisp	1952-01-14	\N	\N	4	1	\N	\N	\N
2153	John Robert Louis	Lee	1942-06-21	\N	\N	13	1	\N	\N	\N
2154	Brian Joseph Michael	Cotter	1936-08-24	\N	\N	4	1	\N	\N	\N
2155	Joyce Gwendolen	Quin	1944-11-26	\N	\N	18	2	\N	\N	\N
2156	David Michael	Hope	1940-04-14	\N	\N	9	1	\N	\N	\N
2157	John Arthur	Stevens	1942-10-21	\N	\N	20	1	\N	\N	\N
2159	Sandip	Verma	1959-06-30	\N	\N	23	2	\N	\N	\N
2160	Margaret Anne	Ford	1957-12-16	\N	\N	7	2	\N	\N	\N
2161	Mohamed Iltaf	Sheikh	1941-06-13	\N	\N	20	1	\N	\N	\N
2162	Maurice George	Morrow	1948-09-27	\N	\N	14	1	\N	\N	\N
2164	Jonathan Peter	Marland	1956-08-14	\N	\N	14	1	\N	\N	\N
2165	Kamlesh Kumar	Patel	1960-09-28	\N	\N	17	1	\N	\N	\N
2166	Alexander John	Bruce-Lockhart	1942-05-04	2008-08-14	\N	3	1	\N	\N	\N
2167	David Noel	James	1937-12-07	\N	\N	11	1	\N	\N	\N
2168	Keith John Charles	Bradley	1950-05-17	\N	\N	3	1	\N	\N	\N
2169	Wallace Hamilton	Browne	1947-10-29	\N	\N	3	1	\N	\N	\N
2170	Colin MacKenzie	Low	1942-09-23	\N	\N	13	1	\N	\N	\N
2171	Eileen Emily	Paisley	1931-11-02	\N	\N	17	2	\N	\N	\N
2172	Colin David	Boyd	1953-06-07	\N	\N	3	1	\N	\N	\N
2175	Beeban Tania	Kidron	1961-05-02	\N	\N	12	2	\N	\N	\N
2176	Alexander John	Trees	1946-06-12	\N	\N	21	1	\N	\N	\N
2177	Paul Clive	Deighton	1956-01-18	\N	\N	5	1	\N	\N	\N
2178	John Alfred Stoddard	Nash	1949-03-22	\N	\N	15	1	\N	\N	\N
2179	Martha	Lane Fox	1973-02-10	\N	\N	13	2	\N	\N	\N
2180	Michael Fitzhardinge	Berkeley	1948-05-29	\N	\N	3	1	\N	\N	\N
2182	John Rhodes	Horam	1939-03-07	\N	\N	9	1	\N	\N	\N
2183	Rosalind Mary	Grender	1962-08-19	\N	\N	8	2	\N	\N	\N
2184	Mervyn Allister	King	1948-03-30	\N	\N	12	1	\N	\N	\N
2185	Jonathan Neil	Mendelsohn	1966-12-30	\N	\N	14	1	\N	\N	\N
2186	Ian William	Wrigglesworth	1939-12-08	\N	\N	24	1	\N	\N	\N
2074	Robert Edward	Sheldon	1923-09-13	2020-02-03	\N	20	1	\N	\N	\N
2804	Francis John	Montagu-Stuart-Wortley	1856-06-09	1926-05-08	\N	14	1	\N	\N	\N
2189	Nicholas Henry	Bourne	1952-01-01	\N	\N	3	1	\N	\N	\N
2190	Catherine Mary	Bakewell	1949-03-07	\N	\N	3	2	\N	\N	\N
2191	Geoffrey James	Dear	1937-09-20	\N	\N	5	1	\N	\N	\N
2192	Karan Faridoon	Bilimoria	1961-11-26	\N	\N	3	1	\N	\N	\N
2194	Richard Douglas	Harries	1936-06-02	\N	\N	9	1	\N	\N	\N
2195	Michael Hastings	Jay	1946-06-19	\N	\N	11	1	\N	\N	\N
2197	John Patrick Aubone	Burnett	1945-09-19	\N	\N	3	1	\N	\N	\N
2198	Robin	Teverson	1952-03-31	\N	\N	21	1	\N	\N	\N
2199	William David	Trimble	1944-10-15	\N	\N	21	1	\N	\N	\N
2200	John Richard	Krebs	1945-04-11	\N	\N	12	1	\N	\N	\N
2201	Andrew	Mawson	1954-11-08	\N	\N	14	1	\N	\N	\N
2202	George Mark	Malloch Brown	1953-09-16	\N	\N	14	1	\N	\N	\N
2203	Alan William John	West	1948-04-21	\N	\N	24	1	\N	\N	\N
2204	Shriti	Vadera	1962-06-23	\N	\N	23	2	\N	\N	\N
2205	Digby Marritt	Jones	1955-10-28	\N	\N	11	1	\N	\N	\N
2207	Robin Berry	Janvrin	1946-09-20	\N	\N	11	1	\N	\N	\N
2208	Sayeeda Hussain	Warsi	1971-03-28	\N	\N	24	2	\N	\N	\N
2209	Susan Elizabeth	Garden	1944-02-22	\N	\N	8	2	\N	\N	\N
2210	James Robert	Wallace	1954-08-25	\N	\N	24	1	\N	\N	\N
2211	Haleh	Afshar	1944-05-21	\N	\N	2	2	\N	\N	\N
2212	John Frederick	Mogg	1943-10-05	\N	\N	14	1	\N	\N	\N
2214	Elizabeth Lydia	Manningham-Buller	1948-07-14	\N	\N	14	2	\N	\N	\N
2215	Michael Walton	Bates	1961-05-22	\N	\N	3	1	\N	\N	\N
2216	Igor	Judge	1941-05-19	\N	\N	11	1	\N	\N	\N
2217	Stephen Andrew	Carter	1964-02-12	\N	\N	4	1	\N	\N	\N
2218	Paul	Myners	1948-04-01	\N	\N	14	1	\N	\N	\N
2219	David Philip	Pannick	1956-03-07	\N	\N	17	1	\N	\N	\N
2221	Evan Mervyn	Davies	1952-11-21	\N	\N	5	1	\N	\N	\N
2222	Lawrence Antony	Collins	1941-05-07	\N	\N	4	1	\N	\N	\N
2223	Anthony Peter	Clarke	1943-05-13	\N	\N	4	1	\N	\N	\N
2224	David Anthony	Freud	1950-06-24	\N	\N	7	1	\N	\N	\N
2225	Brian Francis	Kerr	1948-02-22	\N	\N	12	1	\N	\N	\N
2226	Glenys Elizabeth	Kinnock	1944-07-07	\N	\N	12	2	\N	\N	\N
2227	Alan Michael	Sugar	1947-03-24	\N	\N	20	1	\N	\N	\N
2229	Nuala Patricia	O'Loan	1951-12-20	\N	\N	16	2	\N	\N	\N
2230	Michael John	Martin	1945-07-03	2018-04-29	\N	14	1	\N	\N	\N
2231	Anthony William	Hall	1951-03-03	\N	\N	9	1	\N	\N	\N
2232	Ajay Kumar	Kakkar	1964-04-28	\N	\N	12	1	\N	\N	\N
2234	Michael George	Bichard	1947-01-31	\N	\N	3	1	\N	\N	\N
2235	Jonathan Hopkin	Hill	1960-07-24	\N	\N	9	1	\N	\N	\N
2237	James Meyer	Sassoon	1955-09-11	\N	\N	20	1	\N	\N	\N
2238	Maeve Christina Mary	Sherlock	1960-11-10	\N	\N	20	2	\N	\N	\N
2239	Jean Elizabeth	Coussins	1950-10-26	\N	\N	4	2	\N	\N	\N
2240	Paul Anthony Elliott	Bew	1950-01-22	\N	\N	3	1	\N	\N	\N
2241	Khalid	Hameed	1941-07-01	\N	\N	9	1	\N	\N	\N
2242	Ian Richard Kyle	Paisley	1926-04-06	2014-09-12	\N	17	1	\N	\N	\N
2243	Roger John	Liddle	1947-06-14	\N	\N	13	1	\N	\N	\N
2244	Jean Lesley Patricia	Drake	1948-01-16	\N	\N	5	2	\N	\N	\N
2246	John Selwyn	Gummer	1939-11-26	\N	\N	8	1	\N	\N	\N
2247	Dianne	Hayter	1949-09-07	\N	\N	9	2	\N	\N	\N
2248	Thomas McLaughlin	McAvoy	1943-12-14	\N	\N	14	1	\N	\N	\N
2249	James Philip	Knight	1965-03-06	\N	\N	12	1	\N	\N	\N
2250	John Eric	Gardiner	1956-03-17	\N	\N	8	1	\N	\N	\N
2251	Michael James	German	1945-05-08	\N	\N	8	1	\N	\N	\N
2252	Meral	Hussein Ece	1953-10-10	\N	\N	9	2	\N	\N	\N
2254	Rita Margaret	Donaghy	1944-10-09	\N	\N	5	2	\N	\N	\N
2255	John Matthew Patrick	Hutton	1955-05-06	\N	\N	9	1	\N	\N	\N
2256	Paul Yaw	Boateng	1951-06-14	\N	\N	3	1	\N	\N	\N
2257	Jack Wilson	McConnell	1960-06-30	\N	\N	14	1	\N	\N	\N
2258	James Donnelly	Touhig	1947-12-05	\N	\N	21	1	\N	\N	\N
2259	John Quentin	Davies	1944-05-29	\N	\N	5	1	\N	\N	\N
2260	Angela Evans	Smith	1959-01-07	\N	\N	20	2	\N	\N	\N
2262	Helen Lawrie	Liddell	1950-12-06	\N	\N	13	2	\N	\N	\N
2263	William Michael Hardy	Spicer	1943-01-22	2019-05-29	\N	20	1	\N	\N	\N
2264	Timothy Eric	Boswell	1942-12-02	\N	\N	3	1	\N	\N	\N
2265	Dafydd Wynne	Wigley	1943-04-01	\N	\N	24	1	\N	\N	\N
2266	Guy Vaughan	Black	1964-08-06	\N	\N	3	1	\N	\N	\N
2268	Dolar Amarshi	Popat	1953-06-14	\N	\N	17	1	\N	\N	\N
2269	Deborah	Stedman-Scott	1955-11-23	\N	\N	20	2	\N	\N	\N
2271	Alison Margaret	Wolf	1949-10-31	\N	\N	24	2	\N	\N	\N
2272	Jonathan Douglas	Evans	1958-02-17	\N	\N	6	1	\N	\N	\N
2273	Robert James	Rogers	1950-02-05	\N	\N	19	1	\N	\N	\N
2274	William Alexander	Hay	1950-04-16	\N	\N	9	1	\N	\N	\N
2275	Robert Walter	Kerslake	1955-02-28	\N	\N	12	1	\N	\N	\N
2276	Rosalind Miriam	Altmann	1956-04-08	\N	\N	2	2	\N	\N	\N
2277	Andrew James	Dunlop	1959-06-21	\N	\N	5	1	\N	\N	\N
2279	James George Robert	Bridges	1970-07-15	\N	\N	3	1	\N	\N	\N
2280	Simon Adam	Wolfson	1967-10-27	\N	\N	24	1	\N	\N	\N
2281	George Philip	Willis	1941-11-30	\N	\N	24	1	\N	\N	\N
2282	Hilary Jane	Armstrong	1945-11-30	\N	\N	2	2	\N	\N	\N
2283	George Samuel Knatchbull	Young	1941-07-16	\N	\N	26	1	\N	\N	\N
2284	Philip Roland	Smith	1966-02-16	\N	\N	20	1	\N	\N	\N
2285	Stephen	Gilbert	1963-07-24	\N	\N	8	1	\N	\N	\N
2287	Michael	Howard	1941-07-07	\N	\N	9	1	\N	\N	\N
2288	John Warren	Shipley	1946-07-05	\N	\N	20	1	\N	\N	\N
2289	Helen Margaret	Newlove	1961-12-28	\N	\N	15	2	\N	\N	\N
2290	Kathryn Jane	Parminter	1964-06-24	\N	\N	17	2	\N	\N	\N
2291	Beverley June	Hughes	1950-03-30	\N	\N	9	2	\N	\N	\N
2292	Matthew Owen John	Taylor	1963-01-03	\N	\N	21	1	\N	\N	\N
2293	John	Reid	1947-05-08	\N	\N	19	1	\N	\N	\N
2295	Anna Mary	Healy	1955-05-10	\N	\N	9	2	\N	\N	\N
2296	Ian Warwick	Blair	1953-03-19	\N	\N	3	1	\N	\N	\N
2297	Jeremy Hugh	Beecham	1944-11-17	\N	\N	3	1	\N	\N	\N
2299	Ellen Margaret	Eaton	1942-06-01	\N	\N	6	2	\N	\N	\N
2300	Desmond Henry	Browne	1952-03-22	\N	\N	3	1	\N	\N	\N
2301	Michael Charles	Williams	1949-06-11	2017-04-23	\N	24	1	\N	\N	\N
2188	Doreen Delceita	Lawrence	1952-10-24	\N	\N	13	2	\N	\N	\N
2048	Peter Norman	Fowler	1938-02-02	\N	\N	7	1	Q332919	315	289
2304	Sheila Clare	Hollins	1946-06-22	\N	\N	9	2	\N	\N	\N
2305	Stephen Keith	Green	1948-11-07	\N	\N	8	1	\N	\N	\N
2307	Robert George Alexander	Balchin	1942-07-31	\N	\N	3	1	\N	\N	\N
2308	Andrew Simon	Feldman	1966-02-25	\N	\N	7	1	\N	\N	\N
2309	Michael John	Dobbs	1948-11-14	\N	\N	5	1	\N	\N	\N
2310	Patrick Thomas	Cormack	1939-05-18	\N	\N	4	1	\N	\N	\N
2311	John Kevin	Sharkey	1947-09-24	\N	\N	20	1	\N	\N	\N
2312	Fiona Sara	Shackleton	1956-05-26	\N	\N	20	2	\N	\N	\N
2313	Elizabeth Deirdre	Doocey	1948-05-02	\N	\N	5	2	\N	\N	\N
2314	Susan Veronica	Kramer	1950-07-21	\N	\N	12	2	\N	\N	\N
2315	Patience Jane	Wheatcroft	1951-09-28	\N	\N	24	2	\N	\N	\N
2316	Nicholas Edward	True	1951-07-31	\N	\N	21	1	\N	\N	\N
2318	Judith Anne	Jolly	1951-04-27	\N	\N	11	2	\N	\N	\N
2319	Richard John Grenville	Spring	1946-09-24	\N	\N	20	1	\N	\N	\N
2320	Paul Cline	Strasburger	1946-07-31	\N	\N	20	1	\N	\N	\N
2321	Richard Sanderson	Keen	1954-03-29	\N	\N	12	1	\N	\N	\N
2322	David	Blunkett	1947-06-06	\N	\N	3	1	\N	\N	\N
2324	Howard Emerson	Flight	1948-06-16	\N	\N	7	1	\N	\N	\N
2325	Michael Nicholson	Lord	1938-10-17	\N	\N	13	1	\N	\N	\N
2326	Stewart Martin	Wood	1968-03-25	\N	\N	24	1	\N	\N	\N
2328	Monroe Edward	Palmer	1938-11-30	\N	\N	17	1	\N	\N	\N
2329	Elizabeth Rose	Berridge	1972-03-22	\N	\N	3	2	\N	\N	\N
2330	Stanley	Fink	1957-09-15	\N	\N	7	1	\N	\N	\N
2331	Francis Richard	Dannatt	1950-12-23	\N	\N	5	1	\N	\N	\N
2332	Raymond Edward Harry	Collins	1954-12-21	\N	\N	4	1	\N	\N	\N
2333	Qurban	Hussain	1956-03-27	\N	\N	9	1	\N	\N	\N
2334	Joan Dawson	Bakewell	1933-04-16	\N	\N	3	2	\N	\N	\N
2336	Mair Eluned	Morgan	1967-02-16	\N	\N	14	2	\N	\N	\N
2337	George Morgan	Magan	1945-11-14	\N	\N	14	1	\N	\N	\N
2338	Michael Ian	Grade	1943-03-08	\N	\N	8	1	\N	\N	\N
2339	Anne Caroline	Jenkin	1955-12-08	\N	\N	11	2	\N	\N	\N
2340	Oona Tamsyn	King	1967-10-22	\N	\N	12	2	\N	\N	\N
2341	Jennifer Elizabeth	Randerson	1948-05-26	\N	\N	19	2	\N	\N	\N
2342	Gulam Kaderbhoy	Noon	1936-01-24	2015-10-27	\N	15	1	\N	\N	\N
2343	Claire	Tyler	1957-06-04	\N	\N	21	2	\N	\N	\N
2344	Graham Eric	Stirrup	1949-12-04	\N	\N	20	1	\N	\N	\N
2346	Michael David	Bishop	1942-02-10	\N	\N	3	1	\N	\N	\N
2347	David Laurence	Gold	1951-03-01	\N	\N	8	1	\N	\N	\N
2348	Michael John	Storey	1949-05-25	\N	\N	20	1	\N	\N	\N
2349	Nicol Ross	Stephen	1960-03-23	\N	\N	20	1	\N	\N	\N
2350	Maurice Mark	Glasman	1961-03-08	\N	\N	8	1	\N	\N	\N
2351	Sarah Virginia	Brinton	1955-04-01	\N	\N	3	2	\N	\N	\N
2353	Indarjit	Singh	1932-09-17	\N	\N	20	1	\N	\N	\N
2355	James Roger Crompton	Lupton	1955-06-15	\N	\N	13	1	\N	\N	\N
2356	Anne Caroline Ballingall	McIntosh	1954-09-20	\N	\N	14	2	\N	\N	\N
2357	Elizabeth Marie	Redfern	1947-09-25	\N	\N	19	2	\N	\N	\N
2358	Donald Michael Ellison	Foster	1947-03-31	\N	\N	7	1	\N	\N	\N
2359	Emma Samantha	Pidding	1966-01-13	\N	\N	17	2	\N	\N	\N
2360	Jane Antoinette	Scott	1955-06-15	\N	\N	20	2	\N	\N	\N
2362	Rajinder Paul	Loomba	1943-11-13	\N	\N	13	1	\N	\N	\N
2363	Tariq Mahmood	Ahmad	1968-04-03	\N	\N	2	1	\N	\N	\N
2364	Andrew Robert George	Robathan	1951-07-17	\N	\N	19	1	\N	\N	\N
2365	Walter Menzies	Campbell	1941-05-22	\N	\N	4	1	\N	\N	\N
2366	Kevin Joseph Maximilian	Shinkwin	1971-06-07	\N	\N	20	1	\N	\N	\N
2367	Simone Jari	Finn	1968-06-10	\N	\N	7	2	\N	\N	\N
2368	Kate Harriet Alexandra	Rock	1968-10-09	\N	\N	19	2	\N	\N	\N
2369	Gary Andrew	Porter	1960-09-08	\N	\N	17	1	\N	\N	\N
2371	Michelle Georgina	Mone	1971-10-07	\N	\N	14	2	\N	\N	\N
2372	James Norwich	Arbuthnot	1952-08-04	\N	\N	2	1	\N	\N	\N
2373	Philippa Claire	Stroud	1965-04-02	\N	\N	20	2	\N	\N	\N
2374	Stuart	Polak	1961-03-28	\N	\N	17	1	\N	\N	\N
2375	Shaista Ahmad	Sheehan	1959-07-29	\N	\N	20	2	\N	\N	\N
2376	Andrew David	Lansley	1956-12-11	\N	\N	13	1	\N	\N	\N
2377	Jonathan	Oates	1969-12-28	\N	\N	16	1	\N	\N	\N
2380	Alan James	Beith	1943-04-20	\N	\N	3	1	\N	\N	\N
2381	Paul Peter	Murphy	1948-11-25	\N	\N	14	1	\N	\N	\N
2382	Lynne Choona	Featherstone	1951-12-20	\N	\N	7	2	\N	\N	\N
2383	Dorothy	Thornhill	1955-05-26	\N	\N	21	2	\N	\N	\N
2384	Spencer Elliot	Livermore	1975-06-12	\N	\N	13	1	\N	\N	\N
2385	Peter Gerald	Hain	1950-02-16	\N	\N	9	1	\N	\N	\N
2386	Michael Stahel	Farmer	1944-12-17	\N	\N	7	1	\N	\N	\N
2387	Christopher Francis	Fox	1957-09-27	\N	\N	7	1	\N	\N	\N
2388	Ranbir Singh	Suri	1935-02-10	\N	\N	20	1	\N	\N	\N
2389	Julie Elizabeth	Smith	1969-06-01	\N	\N	20	2	\N	\N	\N
2390	Diana Mary	Harding	1967-11-09	\N	\N	9	2	\N	\N	\N
2392	Joanna	Shields	1962-07-12	\N	\N	20	2	\N	\N	\N
2394	Arminka	Helic	1968-04-20	\N	\N	9	2	\N	\N	\N
2395	Gail Ruth	Rebuck	1952-02-10	\N	\N	19	2	\N	\N	\N
2396	Nosheena Shaheen	Mobarik	1957-10-16	\N	\N	14	2	\N	\N	\N
2397	Paul James	Scriven	1966-02-07	\N	\N	20	1	\N	\N	\N
2398	Christopher John	Lennie	1953-02-22	\N	\N	13	1	\N	\N	\N
2399	Karren Rita	Brady	1969-04-04	\N	\N	3	2	\N	\N	\N
2400	Michael Maurice	Cashman	1950-12-17	\N	\N	4	1	\N	\N	\N
2401	Sharon Margaret	Bowles	1953-06-12	\N	\N	3	2	\N	\N	\N
2402	Lorely Jane	Burt	1954-09-10	\N	\N	3	2	\N	\N	\N
2403	Douglas Martin	Hogg	1945-02-05	\N	\N	9	1	\N	\N	\N
2405	Robert James	Mair	1950-04-20	\N	\N	14	1	\N	\N	\N
2406	John Anthony	Bird	1946-01-30	\N	\N	3	1	\N	\N	\N
2407	Julia Elizabeth	King	1954-07-11	\N	\N	12	2	\N	\N	\N
2408	Mary Jane	Watkins	1955-03-05	\N	\N	24	2	\N	\N	\N
2410	Mark Ian	Price	1961-03-02	\N	\N	17	1	\N	\N	\N
2411	Elizabeth Grace	Sugg	1977-05-02	\N	\N	20	2	\N	\N	\N
2412	Alexander Andrew Macdonell	Fraser	1946-12-02	\N	\N	7	1	\N	\N	\N
2413	Jitesh Kishorekumar	Gadhia	1970-05-27	\N	\N	8	1	\N	\N	\N
2414	Mark	McInnes	1976-11-04	\N	\N	14	1	\N	\N	\N
2303	Peter John	Hennessy	1947-03-28	\N	\N	9	1	\N	\N	\N
2805	Archibald Ralph	Montagu-Stuart-Wortley-Mackenzie	1892-04-17	1953-05-16	\N	14	1	\N	\N	\N
2418	Matthew Hadrian Marshall	Carrington	1947-10-19	\N	\N	4	1	\N	\N	\N
2419	Stephen Ashley	Sherbourne	1945-10-15	\N	\N	20	1	\N	\N	\N
2420	Brian Leonard	Paddick	1958-04-24	\N	\N	17	1	\N	\N	\N
2421	Jeremy	Purvis	1974-01-15	\N	\N	17	1	\N	\N	\N
2423	Fiona Ferelith	Hodgson	1954-11-07	\N	\N	9	2	\N	\N	\N
2424	Howard Darryl	Leigh	1959-04-03	\N	\N	13	1	\N	\N	\N
2425	Rumi	Verjee	1957-06-26	\N	\N	23	1	\N	\N	\N
2426	Alison Mary	Suttie	1968-08-27	\N	\N	20	2	\N	\N	\N
2428	William	Haughey	1956-07-02	\N	\N	9	1	\N	\N	\N
2429	Richard Andrew	Balfe	1944-05-14	\N	\N	3	1	\N	\N	\N
2430	Jennifer Helen	Jones	1949-12-23	\N	\N	11	2	\N	\N	\N
2432	Anthony Paul	Bamford	1945-10-23	\N	\N	3	1	\N	\N	\N
2433	Annabel MacNicoll	Goldie	1950-02-27	\N	\N	8	2	\N	\N	\N
2434	Roger John Laugharne	Thomas	1947-10-22	\N	\N	21	1	\N	\N	\N
2435	Kathryn Mary	Pinnock	1946-09-25	\N	\N	17	2	\N	\N	\N
2436	Martin John	Callanan	1961-08-08	\N	\N	4	1	\N	\N	\N
2437	Barbara Lilian	Janke	1947-06-05	\N	\N	11	2	\N	\N	\N
2439	Gabrielle Louise	Bertin	1978-03-14	\N	\N	3	2	\N	\N	\N
2440	Philippa Marion	Roe	1962-09-25	\N	\N	19	2	\N	\N	\N
2441	Olivia Caroline	Bloomfield	1960-06-30	\N	\N	3	2	\N	\N	\N
2442	Robert Andrew	Stunell	1942-11-24	\N	\N	20	1	\N	\N	\N
2443	Dawn	Primarolo	1954-05-02	\N	\N	17	2	\N	\N	\N
2444	Tessa Jane Helen Douglas	Jowell	1947-09-17	2018-05-12	\N	11	2	\N	\N	\N
2445	Laura Lee	Wyld	\N	\N	\N	24	2	\N	\N	\N
2446	Ian James	Duncan	1973-02-13	\N	\N	5	1	\N	\N	\N
2448	Theodore Thomas More	Agnew	1961-01-17	\N	\N	2	1	\N	\N	\N
2449	Ian Duncan	Burnett	1958-02-28	\N	\N	3	1	\N	\N	\N
2450	David Julian	Richards	1952-03-04	\N	\N	19	1	\N	\N	\N
2452	Richard John Carew	Chartres	1947-07-11	\N	\N	4	1	\N	\N	\N
2453	Bernard	Hogan-Howe	1957-10-25	\N	\N	9	1	\N	\N	\N
2454	Andrew Guy	Tyrie	1957-01-15	\N	\N	21	1	\N	\N	\N
2455	Eric Jack	Pickles	1952-04-20	\N	\N	17	1	\N	\N	\N
2456	Peter Bruce	Lilley	1943-08-23	\N	\N	13	1	\N	\N	\N
2457	Catherine Irene Jacqueline	Meyer	1953-01-26	\N	\N	14	2	\N	\N	\N
2458	Amanda Jacqueline	Sater	\N	\N	\N	20	2	\N	\N	\N
2459	Pauline Christina	Bryan	\N	\N	\N	3	2	\N	\N	\N
2460	Iain Mackenzie	McNicol	1969-08-17	\N	\N	14	1	\N	\N	\N
2462	Alan Gordon Barraclough	Haselhurst	1937-06-23	\N	\N	9	1	\N	\N	\N
2463	Deborah Clare	Bull	1963-03-22	\N	\N	3	2	\N	\N	\N
2464	Jeremy John	Heywood	1961-12-31	2018-11-04	\N	9	1	\N	\N	\N
2465	Martha Otito	Osamor	\N	\N	\N	16	2	\N	\N	\N
2467	Nicola Claire	Blackwood	1979-10-16	\N	\N	3	2	\N	\N	\N
2468	Stephen Graeme	Parkinson	\N	\N	\N	17	1	\N	\N	\N
2469	Elizabeth Jenny Rosemary	Sanderson	\N	\N	\N	20	2	\N	\N	\N
2470	Zameer Mohammed	Choudrey	\N	\N	\N	4	1	\N	\N	\N
2471	David Ellis	Brownlow	\N	\N	\N	3	1	\N	\N	\N
2472	Henry Byron	Davies	1952-09-04	\N	\N	5	1	\N	\N	\N
2473	Joanna Carolyn	Penn	\N	\N	\N	17	2	\N	\N	\N
2474	Raminder Singh	Ranger	\N	\N	\N	19	1	\N	\N	\N
2475	Heather Carol	Hallett	1949-12-16	\N	\N	9	2	\N	\N	\N
2476	Deborah Ann	Wilcox	\N	\N	\N	24	2	\N	\N	\N
2477	John	Hendy	1948-04-11	\N	\N	9	1	\N	\N	\N
2479	Ruth Elizabeth	Hunt	1980-03-12	\N	\N	9	2	\N	\N	\N
2480	Margaret Mary	Ritchie	1958-03-25	\N	\N	19	2	\N	\N	\N
2481	Hilary Camilla	Cavendish	1968-08-20	\N	\N	4	2	\N	\N	\N
2482	Peter Forbes	Ricketts	1952-09-30	\N	\N	19	1	\N	\N	\N
2484	Robert John	Reed	1956-09-07	\N	\N	19	1	\N	\N	\N
2485	Edward Henry	Garnier	1952-10-26	\N	\N	8	1	\N	\N	\N
2487	Rosel Marie	Boycott	1951-05-13	\N	\N	3	2	\N	\N	\N
2488	David William Kinloch	Anderson	1961-07-05	\N	\N	2	1	\N	\N	\N
2489	Nicola Ann	Morgan	1972-10-01	\N	\N	14	2	\N	\N	\N
2490	James Henry Robert	Innes-Ker	1816-07-12	1879-04-23	\N	10	1	\N	\N	\N
2491	John Derek	Taylor	1943-11-12	\N	\N	21	1	\N	\N	\N
2492	Anthony Adrian	Keith Falconer	1794-04-20	1844-07-11	\N	12	1	\N	\N	\N
2493	Edward Antony Richard Louis	-	1964-03-10	\N	\N	1	1	\N	\N	\N
2494	Henry	Hardinge	1785-03-30	1856-09-24	\N	9	1	\N	\N	\N
2496	Alexander Nelson	Hood	1814-12-23	1904-06-04	\N	9	1	\N	\N	\N
2497	James	Carnegie	1827-11-16	1905-02-21	\N	4	1	\N	\N	\N
2498	Chichester Samuel	Parkinson Fortescue	1823-01-18	1898-01-30	\N	17	1	\N	\N	\N
2499	Thomas Francis	Fremantle	1798-03-11	1890-12-03	\N	7	1	\N	\N	\N
2501	James	Ogilvie Grant	1817-12-27	1888-06-05	\N	16	1	\N	\N	\N
2502	Charles John	Colville	1818-11-23	1903-07-01	\N	4	1	\N	\N	\N
2503	George	Stephen	1829-06-05	1921-11-29	\N	20	1	\N	\N	\N
2504	Arthur William Acland	Hood	1824-07-14	1901-11-15	\N	9	1	\N	\N	\N
2505	Archibald Campbell	Campbell	1835-02-22	1908-07-08	\N	4	1	\N	\N	\N
2506	Frederic	Leighton	1830-12-03	1896-01-25	\N	13	1	\N	\N	\N
2507	Henry Hucks	Gibbs	1819-08-31	1907-09-13	\N	8	1	\N	\N	\N
2509	Donald Alexander	Smith	1818-08-06	1914-01-21	\N	20	1	\N	\N	\N
2510	Charles Henry	Wilson	1833-04-22	1907-10-27	\N	24	1	\N	\N	\N
2511	Thomas	Shaw	1850-05-23	1937-06-28	\N	20	1	\N	\N	\N
2512	Henry Edmund	Butler	1844-12-18	1912-10-02	\N	3	1	\N	\N	\N
2513	Charles Benjamin Bright	McLaren	1850-05-12	1934-01-23	\N	14	1	\N	\N	\N
2514	Nigel Kim	Darroch	1954-04-30	\N	\N	5	1	\N	\N	\N
2515	Frank Zacharias Robin	Goldsmith	1975-01-20	\N	\N	8	1	\N	\N	\N
2516	George	Cave	1856-02-23	1928-03-29	\N	4	1	\N	\N	\N
2517	George Allardice	Riddell	1865-05-25	1934-12-05	\N	19	1	\N	\N	\N
2518	Joseph	Watson	1873-02-10	1922-03-13	\N	24	1	\N	\N	\N
2520	Henry Neville	Gladstone	1852-04-02	1935-04-28	\N	8	1	\N	\N	\N
2521	Frank	Russell	1867-07-02	1946-12-20	\N	19	1	\N	\N	\N
2522	William James Peake	Mason	1862-11-11	1947-07-21	\N	14	1	\N	\N	\N
2524	George Richard James	Hennessy	1877-03-23	1953-10-08	\N	9	1	\N	\N	\N
2525	William	Westwood	1880-08-28	1953-09-13	\N	24	1	\N	\N	\N
2526	Harold Harington	Balfour	1897-11-01	1988-09-21	\N	3	1	\N	\N	\N
2417	Daniel William	Finkelstein	1962-08-30	\N	\N	7	1	\N	\N	\N
2806	Alan James	Montagu-Stuart-Wortley-Mackenzie	1935-03-23	1987-06-03	\N	14	1	\N	\N	\N
2530	Charles	Dukes	1881-10-28	1948-05-14	\N	5	1	\N	\N	\N
2532	Fergus Dunlop	Morton	1887-10-17	1973-07-18	\N	14	1	\N	\N	\N
2533	Brendan	Bracken	1901-02-15	1958-08-08	\N	3	1	\N	\N	\N
2534	Henry James	Scrymgeour-Wedderburn	1902-05-03	1983-06-29	\N	20	1	\N	\N	\N
2535	Arnold Babb	Gridley	1878-07-16	1965-07-27	\N	8	1	\N	\N	\N
2536	Robert John	Parker	1857-02-25	1918-07-12	\N	17	1	\N	\N	\N
2537	Barbara Frances	Wright	1897-04-14	1988-07-11	\N	24	2	\N	\N	\N
2538	Thomas	Williams	1888-03-18	1967-03-29	\N	24	1	\N	\N	\N
2539	John William	Morris	1896-09-11	1979-06-09	\N	14	1	\N	\N	\N
2540	Alexander Moncrieff	Coutanche	1892-05-09	1973-12-18	\N	4	1	\N	\N	\N
2541	John Hugh	Hare	1911-01-22	1982-03-07	\N	9	1	\N	\N	\N
2543	Niall Malcolm Stewart	Macpherson	1908-08-03	1987-10-11	\N	14	1	\N	\N	\N
2544	Archibald Fenner	Brockway	1888-11-01	1988-04-28	\N	3	1	\N	\N	\N
2545	Israel Moses	Sieff	1889-05-04	1972-02-14	\N	20	1	\N	\N	\N
2546	George Richard Hodges	Nugent	1907-06-06	1994-03-16	\N	15	1	\N	\N	\N
2547	Willis	Jackson	1904-10-29	1970-02-17	\N	11	1	\N	\N	\N
2548	John Mackintosh	Foot	1909-02-17	1999-10-11	\N	7	1	\N	\N	\N
2549	Henry Stephen	Wilson	1916-03-21	1997-11-23	\N	24	1	\N	\N	\N
2550	Julian Ward	Snow	1910-02-24	1982-01-24	\N	20	1	\N	\N	\N
2552	Rhys Gerran	Lloyd	1907-08-12	1991-01-30	\N	13	1	\N	\N	\N
2554	Tufton Victor Hamilton	Beamish	1917-01-27	1989-04-06	\N	3	1	\N	\N	\N
2555	Margaret Rosalind	Delacourt-Smith	1916-04-05	2010-06-08	\N	5	2	\N	\N	\N
2556	Hugh Kinsman	Cudlipp	1913-08-28	1998-05-17	\N	4	1	\N	\N	\N
2557	David Thomas	Pitt	1913-10-03	1994-12-18	\N	17	1	\N	\N	\N
2558	Arthur George	Weidenfeld	1919-09-13	2016-01-20	\N	24	1	\N	\N	\N
2559	Albert James	Murray	1930-01-09	1980-02-10	\N	14	1	\N	\N	\N
2560	John Herbert	McCluskey	1929-06-12	2017-07-20	\N	14	1	\N	\N	\N
2562	Edwin Rodney	Smith	1914-05-10	1998-07-01	\N	20	1	\N	\N	\N
2563	Walter Laing Macdonald	Perry	1921-06-16	2003-07-17	\N	17	1	\N	\N	\N
2564	Hugh Emlyn	Hooson	1925-03-26	2012-02-21	\N	9	1	\N	\N	\N
2565	Thomas Gray	Boardman	1919-01-12	2003-03-10	\N	3	1	\N	\N	\N
2566	Alan Robertson	Campbell	1917-05-24	2013-06-30	\N	4	1	\N	\N	\N
2567	Anthony Meredith	Quinton	1925-03-25	2010-06-19	\N	18	1	\N	\N	\N
2568	Gordon William Humphreys	Richardson	1915-11-25	2010-01-22	\N	19	1	\N	\N	\N
2569	Neil George	Carmichael	1921-10-10	2001-07-19	\N	4	1	\N	\N	\N
2570	Richard	Crawshaw	1917-09-25	1986-07-16	\N	4	1	\N	\N	\N
2572	Stephen James Lake	Taylor	1910-12-30	1988-02-01	\N	21	1	\N	\N	\N
2573	Charles Eliot	Jauncey	1925-05-08	2007-07-18	\N	11	1	\N	\N	\N
2574	Barbara Anne	Castle	1910-10-06	2002-05-03	\N	4	2	\N	\N	\N
2575	Lydia Selina	Dunn	1940-02-29	\N	\N	5	2	\N	\N	\N
2576	David Anthony Llewellyn	Owen	1938-07-02	\N	\N	16	1	\N	\N	\N
2577	Merlyn	Merlyn-Rees	1920-12-18	2006-01-05	\N	14	1	\N	\N	\N
2579	Patrick Richard Henry	Wright	1931-06-28	2020-03-06	\N	24	1	\N	\N	\N
2580	James Arthur David	Hope	1938-06-27	\N	\N	9	1	\N	\N	\N
2581	June Kathleen	Lloyd	1928-01-01	2006-06-28	\N	13	2	\N	\N	\N
2582	Peter Selwyn	Gummer	1942-08-24	\N	\N	8	1	\N	\N	\N
2583	James Brian Edward	Hutton	1931-06-29	\N	\N	9	1	\N	\N	\N
2585	Alfred	Morris	1928-03-23	2012-08-12	\N	14	1	\N	\N	\N
2586	Andrew Zelig	Stone	1942-09-07	\N	\N	20	1	\N	\N	\N
2587	Michael Jacob	Montague	1932-03-10	1999-11-05	\N	14	1	\N	\N	\N
2588	David Stuart	Sheppard	1929-03-06	2005-03-05	\N	20	1	\N	\N	\N
2589	Timothy John Leigh	Bell	1941-10-18	2019-08-25	\N	3	1	\N	\N	\N
2590	Rosalie Catherine	Wilkins	1946-05-06	\N	\N	24	2	\N	\N	\N
2591	Nicholas Addison	Phillips	1938-01-21	\N	\N	17	1	\N	\N	\N
2592	Malcolm Newton	Shepherd	1918-09-27	2001-04-05	\N	20	1	\N	\N	\N
2594	Sally	Morgan	1959-06-28	\N	\N	14	2	\N	\N	\N
2595	Peter	Temple-Morris	1938-02-12	2018-05-01	\N	21	1	\N	\N	\N
2596	Brenda Marjorie	Hale	1945-01-31	\N	\N	9	2	\N	\N	\N
2597	Harold Stanley	Kalms	1931-11-21	\N	\N	12	1	\N	\N	\N
2598	Irvine Alan Stewart	Laidlaw	1942-12-22	\N	\N	13	1	\N	\N	\N
2599	Neil Gordon	Kinnock	1942-03-28	\N	\N	12	1	\N	\N	\N
2600	Leslie John	Griffiths	1942-02-15	\N	\N	8	1	\N	\N	\N
2601	Clive Stafford	Soley	1939-05-07	\N	\N	20	1	\N	\N	\N
2604	Peter Benjamin	Mandelson	1953-10-21	\N	\N	14	1	\N	\N	\N
2605	John Francis	McFall	1944-10-04	\N	\N	14	1	\N	\N	\N
2606	Roy Francis	Kennedy	1962-11-09	\N	\N	12	1	\N	\N	\N
2607	Michael David	Wills	1952-05-20	\N	\N	24	1	\N	\N	\N
2608	David Gifford Leathes	Prior	1954-12-03	\N	\N	17	1	\N	\N	\N
2609	Richard Beecroft	Allan	1966-02-11	\N	\N	2	1	\N	\N	\N
2610	Tina Wendy	Stowell	1967-07-02	\N	\N	20	2	\N	\N	\N
2611	Jonathan Clive	Marks	1952-10-19	\N	\N	14	1	\N	\N	\N
2612	Robert Norman	Edmiston	1946-10-06	\N	\N	6	1	\N	\N	\N
2613	Margot Ruth Aline	Lister	1949-05-03	\N	\N	13	2	\N	\N	\N
2614	William Jefferson	Hague	1961-03-26	\N	\N	9	1	\N	\N	\N
2616	Andrew Timothy	Cooper	1963-06-09	\N	\N	4	1	\N	\N	\N
2617	David Leonard	Watts	1951-08-26	\N	\N	24	1	\N	\N	\N
2618	Charlotte Sarah Emily	Vere	1969-03-09	\N	\N	23	2	\N	\N	\N
2619	Charles Lamb	Allen	1957-01-04	\N	\N	2	1	\N	\N	\N
2620	Natalie Louise	Bennett	1966-02-10	\N	\N	3	2	\N	\N	\N
2621	Sharmishta	Chakrabarti	1969-06-16	\N	\N	4	2	\N	\N	\N
2622	John	Mann	1960-01-10	\N	\N	14	1	\N	\N	\N
2623	Harold Mark	Carter	1958-09-21	\N	\N	4	1	\N	\N	\N
2625	David Edmond	Neuberger	1948-01-10	\N	\N	15	1	\N	\N	\N
2626	Charles	Moore	1730-06-29	1822-12-22	\N	14	1	\N	\N	\N
2627	John	Jervis	1734-01-19	1823-03-13	\N	11	1	\N	\N	\N
2628	Hugh	Montgomery	1739-11-05	1819-12-14	\N	14	1	\N	\N	\N
2629	George	Forbes	1760-06-14	1837-06-09	\N	7	1	\N	\N	\N
2631	Richard	Hely-Hutchinson	1756-01-29	1825-08-22	\N	9	1	\N	\N	\N
2632	Percy Clinton Sydney	Smythe	1780-08-31	1855-05-29	\N	20	1	\N	\N	\N
2633	Thomas	Knox	1754-08-05	1840-04-26	\N	12	1	\N	\N	\N
2634	Arthur James	Plunkett	1759-09-09	1836-07-30	\N	17	1	\N	\N	\N
2635	John Francis	Cradock	1762-08-12	1839-07-01	\N	4	1	\N	\N	\N
2528	Alexander Dunlop	Lindsay	1879-05-14	1952-03-18	\N	13	1	\N	\N	\N
2807	Richard Alan Montagu Stuart	Wortley	1953-05-26	\N	\N	24	1	\N	\N	\N
2639	Cecil George Savile	Foljambe	1846-11-07	1907-03-23	\N	7	1	\N	\N	\N
2640	William Wallace	Hozier	1825-02-24	1906-01-30	\N	9	1	\N	\N	\N
2641	John Rushworth	Jellicoe	1859-12-05	1935-11-20	\N	11	1	\N	\N	\N
2642	Walter James	Hore-Ruthven	1838-06-14	1921-02-28	\N	9	1	\N	\N	\N
2643	Walter	Runciman	1847-07-06	1937-08-13	\N	19	1	\N	\N	\N
2644	Edward Ettingdean	Bridges	1892-08-04	1969-08-27	\N	3	1	\N	\N	\N
2645	John Charles Walsham	Reith	1889-07-20	1971-06-16	\N	19	1	\N	\N	\N
2646	Harry Bernard	Taylor	1895-09-18	1991-04-11	\N	21	1	\N	\N	\N
2647	John Campbell	Gordon	1847-08-03	1934-03-07	\N	8	1	\N	\N	\N
2648	Donald Bradley	Somervell	1889-08-24	1960-11-18	\N	20	1	\N	\N	\N
2649	John MacDonald	Bannerman	1901-09-01	1969-05-10	\N	3	1	\N	\N	\N
2651	William Wavell	Wakefield	1898-03-10	1983-08-12	\N	24	1	\N	\N	\N
2652	Bernard Edward	Fergusson	1911-05-06	1980-11-28	\N	7	1	\N	\N	\N
2653	William Picken	Alexander	1905-12-13	1993-09-08	\N	2	1	\N	\N	\N
2654	Martin Michael Charles	Charteris	1913-09-07	1999-12-23	\N	4	1	\N	\N	\N
2655	Robert Lynd Erskine	Lowry	1919-01-30	1999-01-15	\N	13	1	\N	\N	\N
2656	Victor Collin	Matthews	1919-12-05	1995-12-05	\N	14	1	\N	\N	\N
2658	Charles Collier	Johnston	1915-03-04	2002-04-30	\N	11	1	\N	\N	\N
2659	Phyllis Dorothy	James	1920-08-03	2014-11-27	\N	11	2	\N	\N	\N
2660	Richard Edward Geoffrey	Howe	1926-12-20	2015-10-09	\N	9	1	\N	\N	\N
2661	Harry Kenneth	Woolf	1933-05-02	\N	\N	24	1	\N	\N	\N
2662	Philip Charles	Harris	1942-09-15	\N	\N	9	1	\N	\N	\N
2663	Joan Christabel Jill	Knight	1927-07-09	\N	\N	12	2	\N	\N	\N
2664	Colin Marsh	Marshall	1933-11-16	2012-07-05	\N	14	1	\N	\N	\N
2665	William Brabazon	Ponsonby	1744-09-15	1806-11-05	\N	17	1	\N	\N	\N
2667	William	Maule	1771-10-27	1852-04-13	\N	14	1	\N	\N	\N
2669	John Charles	Grant	1815-09-04	1881-02-18	\N	8	1	\N	\N	\N
2670	Gustavus Frederick	Hamilton Russell	1797-05-11	1872-10-27	\N	9	1	\N	\N	\N
2671	Patricia	Morris	1953-01-16	\N	\N	14	2	\N	\N	\N
2672	George	Foulkes	1942-01-21	\N	\N	7	1	\N	\N	\N
2673	Celia Marjorie	Thomas	1945-10-14	\N	\N	21	2	\N	\N	\N
2674	Margaret Beryl	Jones	1955-05-22	\N	\N	11	2	\N	\N	\N
2675	Jane Susan	Campbell	1959-04-19	\N	\N	4	2	\N	\N	\N
2676	John Cradock	Maples	1943-04-22	2012-06-09	\N	14	1	\N	\N	\N
2677	Bernard Francisco	Ribeiro	1944-01-20	\N	\N	19	1	\N	\N	\N
2678	Julian Alexander	Fellowes	1949-08-17	\N	\N	7	1	\N	\N	\N
2680	Timothy John Robert	Kirkhope	1945-04-29	\N	\N	12	1	\N	\N	\N
2681	John Nicholas Reynolds	Houghton	1954-10-18	\N	\N	9	1	\N	\N	\N
2682	Malcolm Stewart	McCorquodale	1901-03-29	1971-09-25	\N	14	1	\N	\N	\N
2683	John	Campbell	1779-09-15	1861-06-23	\N	4	1	\N	\N	\N
2685	Norman Antony Francis	St John-Stevas	1929-05-18	2012-03-02	\N	20	1	\N	\N	\N
2686	Julian Pascoe Francis St Leger	Grenfell	1935-05-23	\N	\N	8	1	\N	\N	\N
2687	Denise Patricia Byrne	Kingsmill	1947-04-24	\N	\N	12	2	\N	\N	\N
2688	Nicholas Ian	Macpherson	1959-07-14	\N	\N	14	1	\N	\N	\N
2689	Richard Arthur Lloyd	Livsey	1935-05-02	2010-09-15	\N	13	1	\N	\N	\N
2690	Colin	Blackburn	1813-05-18	1896-01-08	\N	3	1	\N	\N	\N
2692	William	Mansfield	1855-08-31	1921-11-02	\N	14	1	\N	\N	\N
2693	Francis Aungier	Pakenham	1905-12-05	2001-08-03	\N	17	1	\N	\N	\N
2694	Richard Gardiner	Casey	1890-08-29	1976-06-17	\N	4	1	\N	\N	\N
2695	George Charles	Bingham	1860-12-13	1949-04-20	\N	3	1	\N	\N	\N
2696	Charles Willoughby Moke	Norrie	1893-09-26	1977-05-25	\N	15	1	\N	\N	\N
2697	Dennis Forwood	Vosper	1916-01-02	1968-01-20	\N	23	1	\N	\N	\N
2700	Helen Violet	Bonham Carter	1887-04-15	1969-02-19	\N	3	2	\N	\N	\N
2701	Thomas William	Jones	1898-02-10	1984-11-18	\N	11	1	\N	\N	\N
2702	William Michael	Berry	1911-05-18	2001-04-03	\N	3	1	\N	\N	\N
2703	Arthur William James	Greenwood	1911-09-14	1982-04-12	\N	8	1	\N	\N	\N
2704	Alexander Frederick	Douglas-Home	1903-07-02	1995-10-09	\N	5	1	\N	\N	\N
2705	Harmar	Nicholls	1912-11-01	2000-09-15	\N	15	1	\N	\N	\N
2707	Jeremy Nicolas	Hutchinson	1915-03-28	2017-11-13	\N	9	1	\N	\N	\N
2708	Robert Edwin	McAlpine	1907-04-23	1990-01-07	\N	14	1	\N	\N	\N
2709	John	John-Mackie	1909-11-24	1994-05-26	\N	11	1	\N	\N	\N
2710	Peter Gordon	Henderson	1922-09-16	2000-01-13	\N	9	1	\N	\N	\N
2711	Aubrey Geoffrey Frederick	Rippon	1924-05-28	1997-01-28	\N	19	1	\N	\N	\N
2712	Charles Patrick Fleeming	Jenkin	1926-09-07	2016-12-20	\N	11	1	\N	\N	\N
2713	Peter Spencer	Bowness	1943-05-19	\N	\N	3	1	\N	\N	\N
2714	James John	Clyde	1932-01-29	2009-03-06	\N	4	1	\N	\N	\N
2716	Albert Henry	Stanley	1874-11-08	1948-11-04	\N	20	1	\N	\N	\N
2717	Hugh Caswall Tremenheere	Dowding	1882-04-24	1970-02-15	\N	5	1	\N	\N	\N
2718	Clive Latham	Baillieu	1889-09-24	1967-06-18	\N	3	1	\N	\N	\N
2719	William Morgan	Fletcher-Vane	1909-04-12	1989-06-22	\N	7	1	\N	\N	\N
2720	Clementine Ogilvy	Spencer-Churchill	1885-04-01	1977-12-12	\N	20	2	\N	\N	\N
2721	George Fielden	MacLeod	1895-06-17	1991-06-27	\N	14	1	\N	\N	\N
2722	Robert Lowe	Hall	1901-03-06	1988-09-17	\N	9	1	\N	\N	\N
2723	Rachel Trixie Anne	Gardner	1927-07-17	\N	\N	8	2	\N	\N	\N
2724	Leonard James	Callaghan	1912-03-27	2005-03-26	\N	4	1	\N	\N	\N
2725	Clive Richard	Hollick	1945-05-20	\N	\N	9	1	\N	\N	\N
2727	Simon Denis	Brown	1937-04-09	\N	\N	3	1	\N	\N	\N
2728	Kishwer	Falkner	1955-03-09	\N	\N	7	2	\N	\N	\N
2729	Charles Guy Rodney	Leach	1934-06-01	2016-06-12	\N	13	1	\N	\N	\N
2730	Lilian Pauline	Neville-Jones	1939-11-02	\N	\N	15	2	\N	\N	\N
2731	Shireen Olive	Ritchie	1945-06-22	2012-04-24	\N	19	2	\N	\N	\N
2732	Benjamin Russell Mackintosh	Stoneham	1948-08-24	\N	\N	20	1	\N	\N	\N
2733	Natalie Jessica	Evans	1975-11-29	\N	\N	6	2	\N	\N	\N
2734	Alicia Pamela	Kennedy	1969-03-22	\N	\N	12	2	\N	\N	\N
2736	Richard Bickerton Pemell	Lyons	1817-04-26	1887-12-05	\N	13	1	\N	\N	\N
2737	Kathleen Margaret	Richardson	1938-02-24	\N	\N	19	2	\N	\N	\N
2738	Norman Robert	Foster	1935-06-01	\N	\N	7	1	\N	\N	\N
2739	Derek Coates	Barber	1918-06-17	2017-11-21	\N	3	1	\N	\N	\N
2740	Robin Brunskill	Cooke	1926-05-09	2006-08-30	\N	4	1	\N	\N	\N
2741	Raj Kumar	Bagri	1930-08-24	2017-04-26	\N	3	1	\N	\N	\N
2808	Mary Rothes Margaret	Cecil	1857-04-25	1919-12-27	\N	4	2	\N	\N	\N
2746	Derek	Foster	1937-06-15	2019-01-06	\N	7	1	\N	\N	\N
2747	Ann Elizabeth Oldfield	Butler-Sloss	1933-08-10	\N	\N	3	2	\N	\N	\N
2748	Nicholas Herbert	Stern	1946-04-22	\N	\N	20	1	\N	\N	\N
2749	Francis Anthony Aylmer	Maude	1953-07-04	\N	\N	14	1	\N	\N	\N
2750	Kenneth Donald John	Macdonald	1953-01-04	\N	\N	14	1	\N	\N	\N
2751	Rachael	Heyhoe Flint	1939-06-11	2017-01-18	\N	9	2	\N	\N	\N
2752	David	Goddard	1952-10-02	\N	\N	8	1	\N	\N	\N
2753	Susan Frances Maria	Williams	1967-05-16	\N	\N	24	2	\N	\N	\N
2754	Simon Andrew	Woolley	1961-12-24	\N	\N	24	1	\N	\N	\N
2756	Thomas Horatio Arthur Ernest	Cochrane	1857-04-02	1951-01-17	\N	4	1	\N	\N	\N
2757	David Garfield	Davies	1935-06-24	2019-03-04	\N	5	1	\N	\N	\N
2758	John Julian	Ganzoni	1932-09-30	2005-12-03	\N	8	1	\N	\N	\N
2759	Henrietta Laura	Murray-Pulteney	1766-12-26	1808-07-14	\N	14	2	\N	\N	\N
2761	Leopold George Duncan Albert	-	1853-04-07	1884-03-28	\N	1	1	\N	\N	\N
2762	George Douglas	Campbell	1823-04-30	1900-04-24	\N	4	1	\N	\N	\N
2763	Richard	Nugent-Temple-Grenville	1776-05-29	1839-01-17	\N	15	1	\N	\N	\N
2764	William Arthur Philip Louis	-	1982-06-21	\N	\N	1	1	\N	\N	\N
2766	Arthur William Patrick Albert	-	1850-05-01	1942-01-16	\N	1	1	\N	\N	\N
2767	Alfred Ernest Albert	-	1844-08-06	1900-07-30	\N	1	1	\N	\N	\N
2768	Philip	Mountbatten	1921-06-10	\N	\N	14	1	\N	\N	\N
2769	Henry William Frederick Albert	-	1900-03-31	1974-06-10	\N	1	1	\N	\N	\N
2770	George Edward Alexander Edmund	-	1902-12-20	1942-08-25	\N	1	1	\N	\N	\N
2771	Henry Charles Albert David	-	1984-09-15	\N	\N	1	1	\N	\N	\N
2773	Andrew Albert Christian Edward	-	1960-02-19	\N	\N	1	1	\N	\N	\N
2774	Albert Frederick Arthur George	-	1895-12-14	1952-02-06	\N	1	1	\N	\N	\N
2775	Robert Anthony	Eden	1897-06-12	1977-01-14	\N	6	1	\N	\N	\N
2776	Arthur James	Balfour	1848-07-25	1930-03-19	\N	3	1	\N	\N	\N
2777	Benjamin	Disraeli	1804-12-21	1881-04-19	\N	5	1	\N	\N	\N
2778	George Augustus Henry	Cavendish	1754-03-21	1834-05-04	\N	4	1	\N	\N	\N
2779	Robert Dundas	Haldane-Duncan	1785-03-21	1859-12-22	\N	9	1	\N	\N	\N
2780	John William	Ward	1781-08-09	1833-03-06	\N	24	1	\N	\N	\N
2781	Edward	Lascelles	1740-01-07	1820-04-03	\N	13	1	\N	\N	\N
2782	Thomas William	Coke	1754-05-06	1842-06-30	\N	4	1	\N	\N	\N
2783	John	Eliot	1761-09-28	1823-11-17	\N	6	1	\N	\N	\N
2785	Thomas Grey	Egerton	\N	1814-09-23	\N	6	1	\N	\N	\N
2786	Charles Philip Arthur George	-	1948-11-14	\N	\N	1	1	\N	\N	\N
1	Walter	Butler	1770-02-05	1820-08-10	\N	3	1	\N	\N	\N
9	George Keith	Elphinstone	1746-01-07	1823-03-10	\N	6	1	\N	\N	\N
22	Edward	Pellew	1757-04-19	1833-01-23	\N	17	1	\N	\N	\N
31	Adolphus Frederick	-	1774-02-24	1850-07-08	\N	1	1	\N	\N	\N
44	Thomas	Manners Sutton	1756-02-24	1842-05-31	\N	14	1	\N	\N	\N
53	Stapleton	Cotton	1773-11-14	1865-02-21	\N	4	1	\N	\N	\N
64	John Willoughby	Cole	1768-03-23	1840-03-31	\N	4	1	\N	\N	\N
71	Gilbert	Elliot Murray Kynynmound	1751-04-23	1814-06-21	\N	6	1	\N	\N	\N
84	William	Ker	1763-10-04	1824-04-27	\N	12	1	\N	\N	\N
91	James	Murray	1782-05-29	1837-10-12	\N	14	1	\N	\N	\N
98	Charlotte Mary Gertrude	Strutt	1758-05-29	1836-09-01	\N	20	2	\N	\N	\N
111	Edward	Boscawen	1787-05-10	1841-12-29	\N	3	1	\N	\N	\N
116	Francis	Rawdon-Hastings	1754-12-07	1826-11-28	\N	19	1	\N	\N	\N
130	William	A'Court	1779-07-11	1860-05-31	\N	2	1	\N	\N	\N
138	William George	Hay Carr	1801-02-21	1846-04-19	\N	9	1	\N	\N	\N
149	George Warwick	Bampfylde	1786-03-23	1858-12-19	\N	3	1	\N	\N	\N
159	Francis Godolphin	Osborne	1777-10-18	1850-02-15	\N	16	1	\N	\N	\N
168	William Fitz Gerald	Vesey-FitzGerald	\N	1843-05-11	\N	23	1	\N	\N	\N
180	Edward Berkeley	Portman	1799-07-09	1888-11-19	\N	17	1	\N	\N	\N
188	George Granville	Leveson Gower	1758-01-09	1833-07-19	\N	13	1	\N	\N	\N
197	Charles	Hanbury Tracy	1777-12-28	1858-02-10	\N	9	1	\N	\N	\N
206	Nicholas William	Ridley Colborne	1779-04-14	1854-05-03	\N	19	1	\N	\N	\N
217	Charles Theophilus	Metcalfe	1785-01-30	1846-09-12	\N	14	1	\N	\N	\N
228	Edward	Law	1790-09-08	1871-12-22	\N	13	1	\N	\N	\N
233	Albert Denison	Denison	1805-10-21	1860-01-15	\N	5	1	\N	\N	\N
240	FitzRoy James Henry	Somerset	1788-09-30	1855-06-28	\N	20	1	\N	\N	\N
253	Frederic	Thesiger	1794-07-15	1878-10-05	\N	21	1	\N	\N	\N
259	William Tatton	Egerton	1806-12-30	1883-02-21	\N	6	1	\N	\N	\N
269	Archibald William	Montgomerie	1812-09-29	1861-10-04	\N	14	1	\N	\N	\N
288	Hugh MacCalmont	Cairns	1819-12-27	1885-04-02	\N	4	1	\N	\N	\N
298	John Laird Mair	Lawrence	1811-03-04	1879-06-27	\N	13	1	\N	\N	\N
308	Fulke Southwell	Greville-Nugent	1821-02-17	1883-01-25	\N	8	1	\N	\N	\N
319	Roundell	Palmer	1812-11-27	1895-05-04	\N	17	1	\N	\N	\N
327	William	Monsell	1812-09-21	1894-04-20	\N	14	1	\N	\N	\N
338	Robert Tolver	Gerard	1808-05-12	1887-03-15	\N	8	1	\N	\N	\N
344	George Frederick Samuel	Robinson	1827-10-24	1900-07-09	\N	19	1	\N	\N	\N
351	Augusta Mary Elizabeth	Cavendish-Bentinck	1834-11-08	1893-08-07	\N	4	2	\N	\N	\N
362	William Francis	Cowper-Temple	1811-12-13	1888-10-17	\N	4	1	\N	\N	\N
373	Frederick Beauchamp Paget	Seymour	1821-04-12	1895-03-30	\N	20	1	\N	\N	\N
385	Marmaduke Francis	Constable Maxwell	1837-10-04	1908-10-05	\N	4	1	\N	\N	\N
399	Henry John	Montagu-Douglas-Scott	1832-11-05	1905-11-04	\N	14	1	\N	\N	\N
411	Richard Assheton	Cross	1823-05-30	1914-01-08	\N	4	1	\N	\N	\N
430	Francis Richard	Sandford	1824-05-14	1893-12-31	\N	20	1	\N	\N	\N
439	Henry John Selwyn	Ibbetson	1826-09-26	1902-01-15	\N	10	1	\N	\N	\N
445	William Amhurst	Tyssen Amherst	1835-04-25	1909-01-16	\N	21	1	\N	\N	\N
453	Alexander William George	Duff	1849-11-10	1912-01-29	\N	5	1	\N	\N	\N
462	Charles Synge Christopher	Bowen	1831-08-29	1894-04-10	\N	3	1	\N	\N	\N
475	David Robert	Plunket	1838-12-03	1919-08-22	\N	17	1	\N	\N	\N
484	Hugh Richard	Dawnay	1844-07-20	1924-01-21	\N	5	1	\N	\N	\N
494	Robert Offley Ashburton	Crewe-Milnes	1858-01-12	1945-06-20	\N	4	1	\N	\N	\N
506	George Joachim	Goschen	1831-08-10	1907-02-07	\N	8	1	\N	\N	\N
515	Francis Wallace	Grenfell	1841-04-29	1925-01-27	\N	8	1	\N	\N	\N
2744	Rosalind Patricia-Anne	Howells	1931-01-10	\N	\N	9	2	\N	\N	\N
538	William Henry	Grenfell	1855-10-30	1945-01-09	\N	8	1	\N	\N	\N
550	John Jones	Jenkins	1835-05-10	1915-07-27	\N	11	1	\N	\N	\N
552	Wentworth Blackett	Beaumont	1829-04-11	1907-02-13	\N	3	1	\N	\N	\N
555	Montagu	Samuel-Montagu	1832-12-21	1911-01-12	\N	20	1	\N	\N	\N
566	Hamilton John Agmondesham	Cuffe	1848-08-30	1934-11-04	\N	4	1	\N	\N	\N
580	John Henry	de Villiers	1842-06-15	1914-09-02	\N	5	1	\N	\N	\N
589	Archibald Cameron	Corbett	1856-05-23	1933-03-19	\N	4	1	\N	\N	\N
615	Herbert Hardy	Cozens-Hardy	1838-11-22	1920-06-18	\N	4	1	\N	\N	\N
624	Kenneth Augustus	Muir Mackenzie	1845-06-01	1930-05-22	\N	14	1	\N	\N	\N
637	Charles Edward Hungerford Atholl	Colston	1854-05-16	1925-06-17	\N	4	1	\N	\N	\N
655	Francis John Stephens	Hopwood	1860-12-02	1947-01-17	\N	9	1	\N	\N	\N
660	Almeric Hugh	Paget	1861-03-14	1949-09-22	\N	17	1	\N	\N	\N
661	James Thomas	Woodhouse	1852-07-16	1921-02-08	\N	24	1	\N	\N	\N
672	William Hayes	Fisher	1853-03-18	1920-07-02	\N	7	1	\N	\N	\N
681	Robert Trotter	Hermon-Hodge	1851-09-23	1937-06-03	\N	9	1	\N	\N	\N
695	Horace Brooks	Marshall	1865-08-05	1936-03-29	\N	14	1	\N	\N	\N
723	Samuel James	Waring	1860-04-19	1940-01-09	\N	24	1	\N	\N	\N
733	Herbert Cokayne	Gibbs	1854-05-14	1935-05-22	\N	8	1	\N	\N	\N
744	Henry Edward	Duke	1855-11-05	1939-05-20	\N	5	1	\N	\N	\N
755	Courtenay Charles Evan	Morgan	1867-04-10	1934-05-03	\N	14	1	\N	\N	\N
766	Frederick John Dealtry	Lugard	1858-01-22	1945-04-11	\N	13	1	\N	\N	\N
774	Randall Thomas	Davidson	1848-04-07	1930-05-25	\N	5	1	\N	\N	\N
783	William Ewert	Berry	1879-06-23	1954-06-15	\N	3	1	\N	\N	\N
793	Arthur Augustus William Harry	Ponsonby	1871-02-16	1946-03-24	\N	17	1	\N	\N	\N
807	Philip	Snowden	1864-07-18	1937-05-15	\N	20	1	\N	\N	\N
814	Walter Edward	Guinness	1880-03-29	1944-11-06	\N	8	1	\N	\N	\N
826	George Croydon	Marks	1858-06-09	1938-09-24	\N	14	1	\N	\N	\N
837	Gerald Walter Erskine	Loder	1861-10-25	1936-04-30	\N	13	1	\N	\N	\N
847	James Ian	Macpherson	1880-05-14	1937-08-14	\N	14	1	\N	\N	\N
857	Henry Strother	Cautley	1863-12-09	1946-09-21	\N	4	1	\N	\N	\N
867	Alfred Ernle Montacute	Chatfield	1873-09-27	1967-11-15	\N	4	1	\N	\N	\N
874	John Davenport	Siddeley	1866-08-05	1953-11-03	\N	20	1	\N	\N	\N
881	William Riddell	Birdwood	1865-09-13	1951-05-17	\N	3	1	\N	\N	\N
901	Henry Page	Croft	1881-06-22	1947-12-07	\N	4	1	\N	\N	\N
910	Richard Bedford	Bennett	1870-07-03	1947-06-27	\N	3	1	\N	\N	\N
919	Albert Charles	Clauson	1870-01-14	1946-03-15	\N	4	1	\N	\N	\N
930	John	Gretton	1867-09-01	1947-06-02	\N	8	1	\N	\N	\N
937	Samuel John Gurney	Hoare	1880-02-24	1959-05-07	\N	9	1	\N	\N	\N
949	Eugene Joseph Squire Hargreaves	Ramsden	1883-02-02	1955-08-09	\N	19	1	\N	\N	\N
962	Charles George	Ammon	1873-04-22	1960-04-02	\N	2	1	\N	\N	\N
970	Augustus Andrewes	Uthwatt	1879-04-25	1949-04-24	\N	22	1	\N	\N	\N
979	William Henry	Beveridge	1879-03-05	1963-03-16	\N	3	1	\N	\N	\N
980	Ambrose Edgar	Woodall	1885-04-24	1974-02-28	\N	24	1	\N	\N	\N
1002	Arthur Frederick	Richards	1885-02-21	1978-10-27	\N	19	1	\N	\N	\N
1014	Winston Joseph	Dugan	1877-05-08	1951-08-17	\N	5	1	\N	\N	\N
1023	Francis Campbell Ross	Douglas	1889-10-21	1980-03-31	\N	5	1	\N	\N	\N
1034	Reginald Douglas	Crook	1901-03-02	1989-03-10	\N	4	1	\N	\N	\N
1046	Archibald Henry Macdonald	Sinclair	1890-10-22	1970-06-15	\N	20	1	\N	\N	\N
1059	James Arthur	Salter	1881-03-15	1975-06-27	\N	20	1	\N	\N	\N
1069	David Patrick Maxwell	Fyfe	1900-05-29	1967-01-27	\N	7	1	\N	\N	\N
1079	Harry Frederick Comfort	Crookshank	1893-05-27	1961-10-17	\N	4	1	\N	\N	\N
1087	Henry	Cohen	1900-02-21	1977-08-07	\N	4	1	\N	\N	\N
1091	Walter Turner	Monckton	1891-01-17	1965-01-09	\N	14	1	\N	\N	\N
1108	Ralph	Assheton	1901-02-24	1984-09-20	\N	2	1	\N	\N	\N
1115	William Edward	Rootes	1894-08-17	1964-12-12	\N	19	1	\N	\N	\N
1126	Jack Nixon	Browne	1904-09-03	1993-07-28	\N	3	1	\N	\N	\N
1135	Hubert Miles Gladwyn	Jebb	1900-04-25	1996-10-24	\N	11	1	\N	\N	\N
1157	George Leighton	Seager	1896-01-11	1963-10-17	\N	20	1	\N	\N	\N
1169	Geoffrey Clegg	Hutchinson	1893-10-14	1974-08-20	\N	9	1	\N	\N	\N
1180	Alick Drummond	Buchanan-Smith	1898-10-09	1984-07-28	\N	3	1	\N	\N	\N
1188	Richard	Llewelyn-Davies	1912-12-24	1981-10-27	\N	13	1	\N	\N	\N
1194	Roy Herbert	Thomson	1894-06-05	1976-08-04	\N	21	1	\N	\N	\N
1204	Keith Anderson Hope	Murray	1903-07-28	1993-10-10	\N	14	1	\N	\N	\N
1215	Harold Francis	Collison	1909-05-10	1995-12-29	\N	4	1	\N	\N	\N
1228	Michael Henry Colin	Hughes-Young	1912-10-28	1980-12-27	\N	9	1	\N	\N	\N
1238	Reginald Alfred	Wells-Pestell	1910-01-27	1991-01-17	\N	24	1	\N	\N	\N
1250	Richard	Beeching	1913-04-21	1985-03-23	\N	3	1	\N	\N	\N
1272	Evelyn Adelaide	Sharp	1903-05-25	1985-09-01	\N	20	2	\N	\N	\N
1283	Annie Patricia	Llewelyn-Davies	1915-07-16	1997-11-06	\N	13	2	\N	\N	\N
1291	Herbert William	Bowden	1905-01-20	1994-04-30	\N	3	1	\N	\N	\N
1299	William John St. Clair	Anstruther-Gray	1905-03-05	1985-08-06	\N	2	1	\N	\N	\N
1303	Laurence Norman	Helsby	1908-04-27	1978-12-05	\N	9	1	\N	\N	\N
1307	William David	Evans	1912-12-25	1985-06-27	\N	6	1	\N	\N	\N
1320	Christopher Frank	Kearton	1911-02-17	1992-07-02	\N	12	1	\N	\N	\N
1330	Evelyn Nigel Chetwode	Birch	1906-11-18	1981-03-08	\N	3	1	\N	\N	\N
1344	Charles Hector Fitzroy	Maclean	1916-05-05	1990-02-08	\N	14	1	\N	\N	\N
1363	Frederic	Seebohm	1909-01-18	1990-12-15	\N	20	1	\N	\N	\N
1375	Norman Crowther	Hunt	1920-03-13	1987-02-16	\N	9	1	\N	\N	\N
1385	Robert Hugh	Turton	1903-08-08	1994-01-17	\N	21	1	\N	\N	\N
1407	Alfred Walter Henry	Allen	1914-07-07	1985-01-14	\N	2	1	\N	\N	\N
1410	Herbert Edmund	Davies	1906-07-15	1992-12-27	\N	5	1	\N	\N	\N
1420	Mary Elizabeth Henderson	Stewart	1903-05-08	1984-12-28	\N	20	2	\N	\N	\N
1431	Derek Wilbraham	Pritchard	1910-06-08	1995-10-16	\N	17	1	\N	\N	\N
1441	Leonard Robert	Carr	1916-11-11	2012-02-17	\N	4	1	\N	\N	\N
1451	Alan Louis Charles	Bullock	1914-12-13	2004-02-02	\N	3	1	\N	\N	\N
1463	Thomas Frederick	Peart	1914-04-30	1988-08-26	\N	17	1	\N	\N	\N
1474	Kenneth William	Wedderburn	1927-04-13	2012-03-09	\N	24	1	\N	\N	\N
1483	Arthur Christopher John	Soames	1920-10-12	1987-09-16	\N	20	1	\N	\N	\N
1498	Terence George	Boston	1930-03-21	2011-07-23	\N	3	1	\N	\N	\N
2809	William Alexander Evering	Cecil	1912-05-31	1980-07-22	\N	4	1	\N	\N	\N
1518	Ralph	Harris	1924-12-10	2006-10-19	\N	9	1	\N	\N	\N
1520	Henry Oscar	Murton	1914-05-08	2009-07-05	\N	14	1	\N	\N	\N
1528	Frederick Donald	Coggan	1909-10-09	2000-05-17	\N	4	1	\N	\N	\N
1538	Henry Alexander	Benson	1909-08-02	1995-03-05	\N	3	1	\N	\N	\N
1549	Arthur Desmond Herne	Plummer	1914-05-25	2009-10-02	\N	17	1	\N	\N	\N
1561	Crawford Murray	MacLehose	1917-10-16	2000-05-27	\N	14	1	\N	\N	\N
1570	Francis	Taylor	1905-01-07	1995-02-15	\N	21	1	\N	\N	\N
1578	James Edward	Hanson	1922-01-20	2004-11-01	\N	9	1	\N	\N	\N
1598	Joseph	Grimond	1913-07-29	1993-10-24	\N	8	1	\N	\N	\N
1606	Helen Mary	Warnock	1924-04-14	2019-03-20	\N	24	2	\N	\N	\N
1618	Leonard Gordon	Wolfson	1927-11-11	2010-05-20	\N	24	1	\N	\N	\N
1627	William Francis	Deedes	1913-06-01	2007-08-17	\N	5	1	\N	\N	\N
1633	Alexander Andrew Mackay	Irvine	1940-06-23	\N	\N	10	1	\N	\N	\N
1643	Michael Francis Lovell	Cocks	1929-08-19	2001-03-26	\N	4	1	\N	\N	\N
1655	Peter Wynford Innes	Rees	1926-12-09	2008-11-30	\N	19	1	\N	\N	\N
1664	Alexander John	Mackenzie Stuart	1924-11-18	2000-04-01	\N	14	1	\N	\N	\N
1679	Ivor Seward	Richard	1932-05-30	2018-03-18	\N	19	1	\N	\N	\N
1693	David Charles	Waddington	1929-08-02	2017-02-24	\N	24	1	\N	\N	\N
1703	Frank Ashcroft	Judd	1935-03-28	\N	\N	11	1	\N	\N	\N
1723	Lynda	Chalker	1942-04-29	\N	\N	4	2	\N	\N	\N
1728	Cecil Edward	Parkinson	1931-09-01	2016-01-22	\N	17	1	\N	\N	\N
1736	Julian	Amery	1919-03-27	1996-09-03	\N	2	1	\N	\N	\N
1741	Bruce Bernard	Weatherill	1920-11-25	2007-05-06	\N	24	1	\N	\N	\N
1751	Bernard Richard	Braine	1914-06-24	2000-01-05	\N	3	1	\N	\N	\N
1760	Richard Samuel	Attenborough	1923-08-29	2014-08-24	\N	2	1	\N	\N	\N
1770	Denis Herbert	Howell	1923-09-04	1998-04-19	\N	9	1	\N	\N	\N
1781	Patricia Elizabeth	Rawlings	1939-01-27	\N	\N	19	2	\N	\N	\N
1792	Robert Henry Alexander	Eames	1937-04-27	\N	\N	6	1	\N	\N	\N
1801	Peter	Pilkington	1933-09-05	2011-02-14	\N	17	1	\N	\N	\N
1810	David Anthony	Currie	1946-12-09	\N	\N	4	1	\N	\N	\N
1820	Ian Charter	MacLaurin	1937-03-30	\N	\N	14	1	\N	\N	\N
1830	Andrew Rutherford	Hardie	1946-01-08	\N	\N	9	1	\N	\N	\N
1848	Marmaduke James	Hussey	1923-08-29	2006-12-27	\N	9	1	\N	\N	\N
1854	Stuart Jeffrey	Randall	1938-06-22	2012-08-11	\N	19	1	\N	\N	\N
1864	Michael Graham Ruddock	Sandberg	1927-05-31	2017-07-02	\N	20	1	\N	\N	\N
1876	William Armand Thomas Tristan	Garel-Jones	1941-02-28	\N	\N	8	1	\N	\N	\N
1889	Mark Oliver	Saville	1936-03-20	\N	\N	20	1	\N	\N	\N
1899	Hector Seymour Peter	Monro	1922-10-04	2006-08-30	\N	14	1	\N	\N	\N
1910	Manzila Pola	Uddin	1959-07-17	\N	\N	22	2	\N	\N	\N
1916	Norman Stewart Hughson	Lamont	1942-05-08	\N	\N	13	1	\N	\N	\N
1928	Diana Margaret	Maddock	1945-05-19	\N	\N	14	2	\N	\N	\N
1937	Peter Michael	Imbert	1933-04-27	2017-11-13	\N	10	1	\N	\N	\N
1945	Michael Bruce	Forsyth	1954-10-16	\N	\N	7	1	\N	\N	\N
1961	Alexander Charles	Carlile	1948-02-12	\N	\N	4	1	\N	\N	\N
1966	David Geoffrey Nigel	Filkin	1944-07-01	\N	\N	7	1	\N	\N	\N
1973	Kenneth John	Woolmer	1940-04-25	\N	\N	24	1	\N	\N	\N
1982	Anthony Fitzhardinge	Gueterbock	1939-09-20	\N	\N	8	1	\N	\N	\N
1995	Frederick James	Erroll	1914-05-27	2000-09-14	\N	6	1	\N	\N	\N
2006	Adam Hafejee	Patel	1940-06-07	2019-05-29	\N	17	1	\N	\N	\N
2016	David Trevor	Shutt	1942-03-16	\N	\N	20	1	\N	\N	\N
2028	Julian Charles Roland	Hunt	1941-09-05	\N	\N	9	1	\N	\N	\N
2038	Charles Ronald Llewelyn	Guthrie	1938-11-17	\N	\N	8	1	\N	\N	\N
2046	David George	Clark	1939-10-19	\N	\N	4	1	\N	\N	\N
2054	Thomas Jeremy	King	1933-07-13	\N	\N	12	1	\N	\N	\N
2071	William Douglas	Cullen	1935-11-18	\N	\N	4	1	\N	\N	\N
2073	Robert Douglas	Carswell	1934-06-28	\N	\N	4	1	\N	\N	\N
2077	Sushantha Kumar	Bhattacharyya	1940-06-06	2019-03-01	\N	3	1	\N	\N	\N
2087	Margaret Mary	Wall	1941-11-14	2017-01-25	\N	24	2	\N	\N	\N
2096	John Alston	Maxton	1936-05-05	\N	\N	14	1	\N	\N	\N
2105	Margaret Josephine	McDonagh	1961-06-26	\N	\N	14	2	\N	\N	\N
2118	David John	Ramsbotham	1934-11-06	\N	\N	19	1	\N	\N	\N
2126	Archibald Gavin	Hamilton	1941-12-30	\N	\N	9	1	\N	\N	\N
2151	Neil Forbes	Davidson	1950-09-13	\N	\N	5	1	\N	\N	\N
2158	Andrew	Adonis	1963-02-22	\N	\N	2	1	\N	\N	\N
2163	William Manuel	Morris	1938-10-19	\N	\N	14	1	\N	\N	\N
2173	David Sydney	Rowe-Beddoe	1937-12-19	\N	\N	19	1	\N	\N	\N
2181	Ian Paul	Livingston	1964-07-28	\N	\N	13	1	\N	\N	\N
2187	Zahida Parveen	Manzoor	1958-05-25	\N	\N	14	2	\N	\N	\N
2196	Michael John Dawson	Walker	1944-07-07	\N	\N	24	1	\N	\N	\N
2206	Ara Warkes	Darzi	1960-05-07	\N	\N	5	1	\N	\N	\N
2213	Robert Haldane	Smith	1944-08-08	\N	\N	20	1	\N	\N	\N
2220	Susan Catherine	Campbell	1948-10-10	\N	\N	4	2	\N	\N	\N
2228	Jonathan Henry	Sacks	1948-03-08	\N	\N	20	1	\N	\N	\N
2236	Nathanael Ming-Yan	Wei	1977-01-19	\N	\N	24	1	\N	\N	\N
2253	Floella Karen Yunies	Benjamin	1949-09-23	\N	\N	3	2	\N	\N	\N
2261	John Leslie	Prescott	1938-05-31	\N	\N	17	1	\N	\N	\N
2270	Andrew Fleming	Green	1941-08-06	\N	\N	8	1	\N	\N	\N
2278	Terence James	O'Neill	1957-03-17	\N	\N	16	1	\N	\N	\N
2286	Robert Wilfrid	Stevenson	1947-04-19	\N	\N	20	1	\N	\N	\N
2298	Edward Peter Lawless	Faulks	1950-08-19	\N	\N	7	1	\N	\N	\N
2302	John Stephen	Monks	1945-08-05	\N	\N	14	1	\N	\N	\N
2306	Michael Andrew Foster Jude	Kerr	1945-07-07	\N	\N	12	1	\N	\N	\N
2317	Alistair Basil	Cooke	1945-04-20	\N	\N	4	1	\N	\N	\N
2327	Reginald Norman Morgan	Empey	1947-10-26	\N	\N	6	1	\N	\N	\N
2335	Jonathan Andrew	Kestenbaum	1961-08-05	\N	\N	12	1	\N	\N	\N
2345	Bryony Katherine	Worthington	1971-09-19	\N	\N	24	2	\N	\N	\N
2352	David John	Maclean	1953-05-16	\N	\N	14	1	\N	\N	\N
2361	Gordon Joshua	Wasserman	1938-07-26	\N	\N	24	1	\N	\N	\N
2370	Ruby	McGregor-Smith	1963-02-22	\N	\N	14	2	\N	\N	\N
2379	Malcolm Gray	Bruce	1944-11-17	\N	\N	3	1	\N	\N	\N
2404	Gregory Leonard George	Barker	1966-03-08	\N	\N	3	1	\N	\N	\N
2415	Lucy Jeanne	Neville-Rolfe	1953-01-02	\N	\N	15	2	\N	\N	\N
2416	Michael John	Whitby	1948-02-06	\N	\N	24	1	\N	\N	\N
2810	William Hugh Amherst	Cecil	1940-12-28	2009-04-02	\N	4	1	\N	\N	\N
2811	Hugh William Amherst	Cecil	1968-07-17	\N	\N	4	1	\N	\N	\N
7	Alleyne	Fitzherbert	1753-03-01	1839-02-19	\N	7	1	\N	\N	\N
24	Cuthbert	Collingwood	1750-09-26	1810-03-07	\N	4	1	\N	\N	\N
40	Charles	Pierrepont	1737-11-14	1816-06-17	\N	17	1	\N	\N	\N
59	Richard	Trench Le Poer	1767-05-18	1837-11-24	\N	21	1	\N	\N	\N
82	Richard William Penn	Howe	1796-12-11	1870-05-12	\N	9	1	\N	\N	\N
108	John Fleming	Leicester	1762-04-04	1827-06-18	\N	13	1	\N	\N	\N
120	John Singleton	Copley	1772-05-21	1863-10-12	\N	4	1	\N	\N	\N
146	George James	Ludlow	1758-12-12	1842-04-16	\N	13	1	\N	\N	\N
170	Philip Charles	Sidney	1800-03-11	1851-03-04	\N	20	1	\N	\N	\N
201	John Thomas	Stanley	1766-11-26	1850-10-02	\N	20	1	\N	\N	\N
222	Richard Bulkeley Philipps	Philipps	1801-06-07	1857-01-03	\N	17	1	\N	\N	\N
229	Charles Noel	Noel	1781-10-02	1866-06-10	\N	15	1	\N	\N	\N
247	Henry Richard Charles	Wellesley	1804-06-17	1884-07-15	\N	24	1	\N	\N	\N
280	Edwin Richard Windham	Windham-Quin	1812-05-19	1871-10-06	\N	24	1	\N	\N	\N
302	Edward George	Fitz-alan Howard	1818-01-20	1883-12-01	\N	7	1	\N	\N	\N
333	Arthur Edward Holland Grey	Egerton	1833-11-25	1885-01-18	\N	6	1	\N	\N	\N
356	Alexander Dundas Ross	Cochrane Wishart Baillie	1816-11-24	1890-02-15	\N	4	1	\N	\N	\N
381	John Thomas	Freeman-Mitford	1805-09-09	1886-05-02	\N	7	1	\N	\N	\N
404	Richard de Aquila	Grosvenor	1837-01-28	1912-05-18	\N	8	1	\N	\N	\N
431	Edward Cecil	Guinness	1847-11-10	1927-10-07	\N	8	1	\N	\N	\N
455	Gilbert Henry	Heathcote-Drummond-Willoughby	1830-10-01	1910-12-24	\N	9	1	\N	\N	\N
488	Michael Arthur	Bass	1837-11-12	1909-02-01	\N	3	1	\N	\N	\N
509	Edward	Heneage	1840-03-29	1922-08-10	\N	9	1	\N	\N	\N
525	Alexander John	Forbes-Leith	1847-08-06	1925-11-14	\N	7	1	\N	\N	\N
545	Edmond George Petty	Fitzmaurice	1846-06-19	1935-06-21	\N	7	1	\N	\N	\N
559	Henry Hartley	Fowler	1830-05-16	1911-02-25	\N	7	1	\N	\N	\N
572	John Poynder	Dickson-Poynder	1866-10-31	1936-12-06	\N	5	1	\N	\N	\N
598	Samuel Hope	Morley	1845-07-03	1929-02-18	\N	14	1	\N	\N	\N
617	John Fielden	Brocklehurst	1852-05-13	1921-02-28	\N	3	1	\N	\N	\N
633	Savile Brinton	Crossley	1857-06-14	1935-02-25	\N	4	1	\N	\N	\N
648	Amelius Richard Mark	Lockwood	1847-08-17	1928-12-26	\N	13	1	\N	\N	\N
662	Matthew	Arthur	1852-03-09	1928-09-23	\N	2	1	\N	\N	\N
675	Alexander Albert	Mountbatten	1886-11-23	1960-02-23	\N	14	1	\N	\N	\N
693	Henry William	Forster	1866-01-31	1936-01-15	\N	7	1	\N	\N	\N
709	William St John Fremantle	Brodrick	1856-12-14	1942-02-13	\N	3	1	\N	\N	\N
736	Edgar Algernon Robert	Gascoyne-Cecil	1864-09-14	1958-11-24	\N	8	1	\N	\N	\N
756	Charles	Greenway	1857-06-13	1934-12-17	\N	8	1	\N	\N	\N
770	Anne Estella Sarah Penfold	Cave	\N	1938-01-07	\N	4	2	\N	\N	\N
794	Robert Stephenson Smyth	Baden-Powell	1857-02-22	1941-01-08	\N	3	1	\N	\N	\N
824	George Francis	Milne	1866-11-05	1948-03-23	\N	14	1	\N	\N	\N
840	Wyndham Raymond	Portal	1885-04-09	1949-05-06	\N	17	1	\N	\N	\N
864	Christopher	Addison	1869-06-19	1951-12-11	\N	2	1	\N	\N	\N
898	Arthur Michael	Samuel	1872-12-06	1942-08-17	\N	20	1	\N	\N	\N
914	Hugh Michael	Seely	1898-10-02	1970-04-01	\N	20	1	\N	\N	\N
941	Arthur Grey	Hazlerigg	1878-11-17	1949-05-25	\N	9	1	\N	\N	\N
957	Charles Ernest Leonard	Lyle	1882-07-22	1954-03-06	\N	13	1	\N	\N	\N
991	Wilfrid Guild	Normand	1884-05-06	1962-10-05	\N	15	1	\N	\N	\N
1007	William Francis Kyffin	Taylor	1854-07-09	1951-09-22	\N	21	1	\N	\N	\N
1030	William John	Molloy	1918-10-26	2001-05-26	\N	14	1	\N	\N	\N
1047	Harold Rupert Leofric George	Alexander	1891-12-10	1969-06-16	\N	2	1	\N	\N	\N
1071	Godfrey Martin	Huggins	1883-07-06	1971-05-08	\N	9	1	\N	\N	\N
1093	Patrick George Thomas	Buchan-Hepburn	1901-04-02	1974-11-05	\N	3	1	\N	\N	\N
1114	William Hartley	Shawcross	1902-02-04	2003-07-10	\N	20	1	\N	\N	\N
2431	James Rudolph	Palumbo	1963-06-06	\N	\N	17	1	\N	\N	\N
2438	Jonathan Michael	Caine	1966-04-11	\N	\N	4	1	\N	\N	\N
2447	Rona Alison	Fairhead	1961-08-28	\N	\N	7	2	\N	\N	\N
2451	Christopher Edward Wollaston MacKenzie	Geidt	1961-08-17	\N	\N	8	1	\N	\N	\N
2466	Gavin Laurence	Barwell	1972-01-23	\N	\N	3	1	\N	\N	\N
2478	Christine	Blower	1951-04-20	\N	\N	3	2	\N	\N	\N
2495	Charles Morgan Robinson	Morgan	1792-04-10	1875-04-16	\N	14	1	\N	\N	\N
2508	John Wingfield	Malcolm	1833-05-16	1902-03-06	\N	14	1	\N	\N	\N
2519	Robert Daniel Thwaites	Yerburgh	1889-12-10	1955-11-27	\N	26	1	\N	\N	\N
2527	Charles Frederick Algernon	Portal	1893-05-21	1971-04-22	\N	17	1	\N	\N	\N
2531	Valentine La Touche	McEntee	1871-01-16	1953-02-11	\N	14	1	\N	\N	\N
2542	Hendrie Dudley	Oakshott	1904-11-08	1975-02-01	\N	16	1	\N	\N	\N
2553	Denis Arthur	Greenhill	1913-11-07	2000-11-08	\N	8	1	\N	\N	\N
2561	Aubrey Leland Oakes	Buxton	1918-07-15	2009-09-01	\N	3	1	\N	\N	\N
2571	Harold Vincent	Mackintosh	1891-06-08	1964-12-27	\N	14	1	\N	\N	\N
2584	David Russell	Russell-Johnston	1932-07-28	2008-07-27	\N	19	1	\N	\N	\N
2593	George Patrick John Rushworth	Jellicoe	1918-04-04	2007-02-22	\N	11	1	\N	\N	\N
2603	Robert Michael Oldfield	Havers	1923-03-10	1992-04-01	\N	9	1	\N	\N	\N
2615	James Richard	O'Shaughnessy	1976-03-26	\N	\N	16	1	\N	\N	\N
2624	Rowan Douglas	Williams	1950-06-14	\N	\N	24	1	\N	\N	\N
2636	Charles	Dundas	1751-04-05	1832-06-30	\N	5	1	\N	\N	\N
2650	William Shepherd	Morrison	1893-08-10	1961-02-03	\N	14	1	\N	\N	\N
2657	Angus Edmund Upton	Maude	1912-09-08	1993-11-09	\N	14	1	\N	\N	\N
2666	Charles Rose	Ellis	1771-12-19	1845-07-01	\N	6	1	\N	\N	\N
2679	Catherine Susan	Fall	1967-10-02	\N	\N	7	2	\N	\N	\N
2691	Frederick Arthur	Stanley	1841-01-15	1908-06-14	\N	20	1	\N	\N	\N
2698	Archibald Philip	Primrose	1847-05-07	1929-05-21	\N	17	1	\N	\N	\N
2706	Gordon Thomas Calthrop	Campbell	1921-06-08	2005-04-26	\N	4	1	\N	\N	\N
2715	Cospatrick Alexander	Home	1799-10-27	1881-07-04	\N	9	1	\N	\N	\N
2726	Christopher Robin	Haskins	1937-05-30	\N	\N	9	1	\N	\N	\N
2735	Robert Thomas William	McCrea	1948-08-06	\N	\N	14	1	\N	\N	\N
2742	David John	Sainsbury	1940-10-24	\N	\N	20	1	\N	\N	\N
2743	Anthony Martin Grosvenor	Christopher	1925-04-25	\N	\N	4	1	\N	\N	\N
2755	Francis John Childs	Ganzoni	1882-01-19	1958-08-15	\N	8	1	\N	\N	\N
2765	Albert Victor Christian Edward	-	1864-01-08	1892-01-14	\N	1	1	\N	\N	\N
2784	Edward Montagu Stuart Granville	Stuart-Wortley-Mackenzie	1827-12-15	1899-05-13	\N	20	1	\N	\N	\N
1136	William Joseph	Slim	1891-08-06	1970-12-14	\N	20	1	\N	\N	\N
1154	Geoffrey Francis	Fisher	1887-05-05	1972-09-15	\N	7	1	\N	\N	\N
1173	Arthur Malcolm Trustram	Eve	1894-04-08	1976-12-03	\N	6	1	\N	\N	\N
1209	Hugh Mackintosh	Foot	1907-10-08	1990-09-05	\N	7	1	\N	\N	\N
1224	Robert Burnham	Renwick	1904-10-04	1973-09-30	\N	19	1	\N	\N	\N
1244	Lewis Coleman	Cohen	1897-03-28	1966-10-21	\N	4	1	\N	\N	\N
1267	William Hunter	McFadzean	1903-12-17	1996-01-14	\N	14	1	\N	\N	\N
1286	Edgar Louis	Granville	1898-02-12	1998-02-14	\N	8	1	\N	\N	\N
1310	William John Kenneth	Diplock	1907-12-08	1985-10-14	\N	5	1	\N	\N	\N
1332	Eric George Molyneux	Fletcher	1903-03-26	1990-06-09	\N	7	1	\N	\N	\N
1345	Horace Maybray	Maybray-King	1901-05-25	1986-09-03	\N	14	1	\N	\N	\N
1358	Charles James Dalrymple	Shaw	1906-08-15	1989-09-10	\N	20	1	\N	\N	\N
1376	Robert Alexander	Allan	1914-07-11	1979-04-04	\N	2	1	\N	\N	\N
1395	Thomas Charles	Pannell	1902-09-10	1980-03-23	\N	17	1	\N	\N	\N
1411	Arthur Michael	Ramsey	1904-11-14	1988-04-23	\N	19	1	\N	\N	\N
1423	Donald William Trevor	Bruce	1912-10-03	2005-04-18	\N	3	1	\N	\N	\N
1452	Paul Norman	Wilson	1908-10-24	1980-02-24	\N	24	1	\N	\N	\N
1468	Arthur Brian Deane	Faulkner	1921-02-18	1977-03-03	\N	7	1	\N	\N	\N
1489	William Henry	Sefton	1915-08-05	2001-09-09	\N	20	1	\N	\N	\N
1509	George Russell	Strauss	1901-07-18	1993-06-05	\N	20	1	\N	\N	\N
1521	Jean Kennedy	McFarlane	1926-04-01	2012-05-13	\N	14	2	\N	\N	\N
1544	Edward Stanley	Bishop	1920-10-03	1984-04-19	\N	3	1	\N	\N	\N
1562	Elizabeth Patricia	Carnegy	1925-04-25	2010-11-09	\N	4	2	\N	\N	\N
1590	Derek Colclough	Walker-Smith	1910-04-13	1992-01-22	\N	24	1	\N	\N	\N
1615	Hugh Drennan Baird	Morton	1930-04-10	1995-04-26	\N	14	1	\N	\N	\N
1636	Maurice Harold	Macmillan	1894-02-10	1986-12-29	\N	14	1	\N	\N	\N
1657	Immanuel	Jakobovits	1921-02-08	1999-10-31	\N	11	1	\N	\N	\N
1674	Daphne Margaret Sybil Désirée	Park	1921-09-01	2010-03-24	\N	17	2	\N	\N	\N
1692	Stephen Sherlock	Ross	1926-07-06	1993-05-10	\N	19	1	\N	\N	\N
1715	Nicolas Christopher Henry	Browne-Wilkinson	1930-03-30	2018-07-25	\N	3	1	\N	\N	\N
1743	Geraint Wyn	Howells	1925-04-15	2004-04-17	\N	9	1	\N	\N	\N
1771	Charles Randolph	Quirk	1920-07-12	2017-12-20	\N	18	1	\N	\N	\N
1787	Robert William Brian	McConnell	1922-11-25	2000-10-25	\N	14	1	\N	\N	\N
1813	Elizabeth Conway	Symons	1951-04-14	\N	\N	20	2	\N	\N	\N
1833	David Arthur Russell	Howell	1936-01-18	\N	\N	9	1	\N	\N	\N
1859	James Alexander	Douglas-Hamilton	1942-07-31	\N	\N	5	1	\N	\N	\N
1881	Greville Ewan	Janner	1928-07-11	2015-12-19	\N	11	1	\N	\N	\N
1902	Roy Sydney George	Hattersley	1932-12-28	\N	\N	9	1	\N	\N	\N
1926	Paul Edward Winston	White	1940-09-16	\N	\N	24	1	\N	\N	\N
1955	William Peter	Bradshaw	1936-09-09	\N	\N	3	1	\N	\N	\N
1980	George Islay MacNeill	Robertson	1946-04-12	\N	\N	19	1	\N	\N	\N
1996	Antony Charles Robert	Armstrong-Jones	1930-03-07	2017-01-13	\N	2	1	\N	\N	\N
2022	Lindsay Patricia	Granshaw	1954-08-21	\N	\N	8	2	\N	\N	\N
2036	Robert Michael James	Gascoyne-Cecil	1946-09-30	\N	\N	8	1	\N	\N	\N
2079	Greville Patrick Charles	Howard	1941-04-22	\N	\N	9	1	\N	\N	\N
2108	Edward	Rowlands	1940-01-23	\N	\N	19	1	\N	\N	\N
2127	David William George	Chidgey	1942-07-09	\N	\N	4	1	\N	\N	\N
2141	Katherine Patricia Irene	Adams	1947-12-27	\N	\N	2	2	\N	\N	\N
2174	Augustine Thomas	O'Donnell	1952-10-01	\N	\N	16	1	\N	\N	\N
2193	Molly Christine	Meacher	1940-05-15	\N	\N	14	2	\N	\N	\N
2233	Carys Davina	Grey-Thompson	1969-07-26	\N	\N	8	2	\N	\N	\N
2267	Angela Frances	Browning	1946-12-04	\N	\N	3	2	\N	\N	\N
2294	Susan Jane	Nye	1955-05-17	\N	\N	15	2	\N	\N	\N
2323	Robert Antony	Hayward	1949-03-11	\N	\N	9	1	\N	\N	\N
2354	Donald Thomas Younger	Curry	1944-04-04	\N	\N	4	1	\N	\N	\N
2378	David Lindsay	Willetts	1956-03-09	\N	\N	24	1	\N	\N	\N
2393	Stuart Alan Ransom	Rose	1949-03-17	\N	\N	19	1	\N	\N	\N
2409	Alistair Maclean	Darling	1953-11-28	\N	\N	5	1	\N	\N	\N
2427	Christine Mary	Humphreys	1947-05-26	\N	\N	9	2	\N	\N	\N
2461	Diana Francesca Caroline	Barran	1959-02-10	\N	\N	3	2	\N	\N	\N
2486	Alexander John	Randall	1955-08-05	\N	\N	19	1	\N	\N	\N
2500	Edward Hugessen	Knatchbull-Hugessen	1829-04-29	1893-02-06	\N	12	1	\N	\N	\N
2523	John William Beaumont	Pease	1869-07-04	1950-08-07	\N	17	1	\N	\N	\N
2529	George Robert	Shepherd	1881-08-19	1954-12-04	\N	20	1	\N	\N	\N
2551	Jocelyn Edward Salis	Simon	1911-01-15	2006-05-07	\N	20	1	\N	\N	\N
2578	Christopher Samuel	Tugendhat	1937-02-23	\N	\N	21	1	\N	\N	\N
2602	Heather Renwick	Brigstocke	1929-09-02	2004-04-30	\N	3	2	\N	\N	\N
2630	George	Harris	1746-03-18	1829-05-19	\N	9	1	\N	\N	\N
2637	Frederick James	Lamb	1782-04-17	1853-01-29	\N	13	1	\N	\N	\N
2668	George Hamilton	Chichester	1797-02-10	1883-10-20	\N	4	1	\N	\N	\N
2684	Charles Cuthbert Powell	Williams	1933-02-09	2019-12-30	\N	24	1	\N	\N	\N
2699	Adolphus Charles Alexander Albert Edward George Philip Louis Ladislaus	-	1868-08-13	1927-10-24	\N	1	1	\N	\N	\N
117	James Archibald Stuart Wortley	Mackenzie	1776-10-06	1845-12-19	\N	14	1	\N	\N	\N
279	William Meredyth	Somerville	\N	1873-12-07	\N	20	1	\N	\N	\N
418	William Henry Forester	Denison	1834-06-19	1900-04-19	\N	5	1	\N	\N	\N
2745	Margaret Omolola	Young	1951-06-01	\N	\N	26	2	\N	\N	\N
2760	Anne Hay-Mackenzie	Sutherland-Leveson-Gower	1829-04-21	1888-11-25	\N	20	2	\N	\N	\N
527	Robert George	Windsor-Clive	1857-08-27	1923-03-06	\N	24	1	\N	\N	\N
599	Charles Ernest Alfred French Somerset	Butler	1873-11-15	1931-11-02	\N	3	1	\N	\N	\N
708	Alexander Augustus Frederick William Alfred George	-	1874-04-14	1957-01-16	\N	1	1	\N	\N	\N
890	Cecil Bisshopp	Harmsworth	1869-09-28	1948-08-13	\N	9	1	\N	\N	\N
986	Louis Francis Albert Victor Nicholas	Mountbatten	1900-06-25	1979-08-27	\N	14	1	\N	\N	\N
1144	Cameron Fromanteel	Cobbold	1904-09-14	1987-11-01	\N	4	1	\N	\N	\N
1257	William Francis Kenrick	Wynne-Jones	1903-05-08	1982-11-08	\N	24	1	\N	\N	\N
1394	Arthur Leslie Noel Douglas	Houghton	1898-08-11	1996-05-02	\N	9	1	\N	\N	\N
1507	Robert Michael Maitland	Stewart	1906-11-06	1990-03-10	\N	20	1	\N	\N	\N
1588	David Leonard	Stoddart	1926-05-04	\N	\N	20	1	\N	\N	\N
1712	Geoffrey Leonard	Cheshire	1917-09-07	1992-07-31	\N	4	1	\N	\N	\N
1842	Patrick Barnabas Burke	Mayhew	1929-09-11	2016-06-25	\N	14	1	\N	\N	\N
1954	Christopher John	Rennard	1960-07-08	\N	\N	19	1	\N	\N	\N
2062	Robert Adam Ross	Maclennan	1936-06-26	2020-01-18	\N	14	1	\N	\N	\N
2136	Virginia Hilda Brunette Maxwell	Bottomley	1948-03-12	\N	\N	3	2	\N	\N	\N
2245	Margaret Eileen Joyce	Wheeler	1949-03-25	\N	\N	24	2	\N	\N	\N
2391	Caroline Elizabeth	Chisholm	1951-12-23	\N	\N	4	2	\N	\N	\N
2422	Christopher	Holmes	1971-10-15	\N	\N	9	1	\N	\N	\N
2483	Edward David Gerard	Llewellyn	1965-09-23	\N	\N	13	1	\N	\N	\N
2638	John Charles Herbert Welbore Ellis	Agar	1818-09-17	1896-12-19	\N	2	1	\N	\N	\N
2772	Edward Albert Christian George Andrew Patrick David	-	1894-06-23	1972-05-28	\N	1	1	\N	\N	\N
2812	Henry Elliott Chevallier	Kitchener	1846-10-05	1937-03-27	\N	12	1	\N	\N	\N
2813	Henry Herbert	Kitchener	1919-02-24	2011-12-16	\N	12	1	\N	\N	\N
2814	Nellie Lisa	Melles	1873-12-27	1962-05-28	\N	14	2	\N	\N	\N
2815	Michael Evan Victor	Baillie	1924-06-27	2013-05-30	\N	3	1	\N	\N	\N
2816	Evan Michael Ronald	Baillie	1949-03-19	\N	\N	3	1	\N	\N	\N
2817	William John Arthur Charles James	Cavendish-Bentinck	1857-12-28	1943-04-26	\N	4	1	\N	\N	\N
2818	William Arthur Henry	Cavendish-Bentinck	1893-03-16	1977-03-21	\N	4	1	\N	\N	\N
2819	Francis	Mackenzie	1852-08-03	1893-11-24	\N	14	1	\N	\N	\N
2820	Sibel Lilian	Mackenzie	1878-08-14	1962-05-20	\N	14	2	\N	\N	\N
2821	Roderick Grant Francis	Mackenzie	1904-10-24	1989-12-13	\N	14	1	\N	\N	\N
2822	John Ruaridh Grant	Mackenzie	1948-06-12	\N	\N	14	1	\N	\N	\N
2823	Stephen Michael Wedgwood	Benn	1951-08-21	\N	\N	3	1	\N	\N	\N
2824	Anthony Ulick David Dundas	Grigg	1934-01-12	2020-08-01	\N	8	1	\N	\N	\N
2825	Edward Sebastian	Grigg	1965-12-18	\N	\N	8	1	\N	\N	\N
2826	Henry Duncan	McLaren	1879-04-16	1953-05-23	\N	14	1	\N	\N	\N
2827	Charles Melville	McLaren	1913-04-16	2003-02-04	\N	14	1	\N	\N	\N
2828	Henry Charles	McLaren	1948-05-26	\N	\N	14	1	\N	\N	\N
2829	Henry Campbell	Bruce	1851-06-19	1929-02-20	\N	3	1	\N	\N	\N
2830	Clarence Napier	Bruce	1885-08-02	1957-10-04	\N	3	1	\N	\N	\N
2831	Morys George Lyndhurst	Bruce	1919-06-16	\N	\N	3	1	\N	\N	\N
2832	Alaster John Lyndhurst	Bruce	1947-05-02	\N	\N	3	1	\N	\N	\N
2833	George	Gordon	1879-01-20	1965-01-06	\N	8	1	\N	\N	\N
2834	Dudley Gladstone	Gordon	1883-05-06	1972-04-16	\N	8	1	\N	\N	\N
2835	David George Ian Alexander	Gordon	1908-01-21	1974-09-13	\N	8	1	\N	\N	\N
2836	Archibald Victor Dudley	Gordon	1913-07-09	\N	\N	8	1	\N	\N	\N
2837	Alastair Ninian John	Gordon	1920-07-20	2002-08-19	\N	8	1	\N	\N	\N
2838	Alexander George	Gordon	1955-03-31	2020-03-12	\N	8	1	\N	\N	\N
2839	George Ian Alastair	Gordon	1983-05-04	\N	\N	8	1	\N	\N	\N
2840	Reginald William Bransby	Nevill	1853-03-04	1927-10-13	\N	15	1	\N	\N	\N
2841	Henry Gilbert Ralph	Nevill	1854-09-02	1938-01-10	\N	15	1	\N	\N	\N
2842	Guy Temple Montacute	Nevill	1883-07-15	1954-03-30	\N	15	1	\N	\N	\N
2843	John Henry Guy	Nevill	1914-11-08	2000-02-23	\N	15	1	\N	\N	\N
2844	Christopher George Charles	Nevill	1955-04-23	\N	\N	15	1	\N	\N	\N
2845	Henry	Howard	\N	\N	Henry Howard styled Lord Walden, eldest son of Henry Earl of Suffolk	9	1	\N	\N	\N
2846	Hugh	\N	\N	\N	Hugh Viscount Cholmondeley (I) and Lord Cholmondeley (E)	\N	1	\N	\N	\N
2847	Sidney	\N	\N	\N	\N	\N	1	\N	\N	\N
2848	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2849	Thomas	\N	\N	\N	\N	\N	1	\N	\N	\N
2850	Evelyn	\N	\N	\N	\N	\N	1	\N	\N	\N
2851	Robert	\N	\N	\N	\N	\N	1	\N	\N	\N
2852	Thomas	Pelham	\N	\N	\N	17	1	\N	\N	\N
2853	William	Cowper	\N	\N	\N	4	1	\N	\N	\N
2854	James	\N	\N	\N	\N	\N	1	\N	\N	\N
2855	Charles Sloane	\N	\N	\N	\N	\N	1	\N	\N	\N
2856	Alexander	\N	\N	\N	Alexander Lord Bridport (I & GB)	\N	1	\N	\N	\N
2857	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2858	John	McClintock	\N	\N	\N	14	1	\N	\N	\N
2859	James	\N	\N	\N	James Marquess of Abercorn (GB) and Viscount Strabane	\N	1	\N	\N	\N
2860	Edmund Burke	Roche	\N	\N	\N	19	1	\N	\N	\N
2861	Patrick	Bellew	\N	\N	\N	3	1	\N	\N	\N
2862	Henry	\N	\N	\N	\N	\N	1	\N	\N	\N
2863	George Lewis	\N	\N	\N	\N	\N	1	\N	\N	\N
2864	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2865	Ralph	\N	\N	\N	\N	\N	1	\N	\N	\N
2866	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2867	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2868	John	Hervey	\N	\N	\N	9	1	\N	\N	\N
2869	Francis	Seymour Conway	\N	\N	\N	20	1	\N	\N	\N
2870	John	Leveson Gower	\N	\N	\N	13	1	\N	\N	\N
2871	Ernest Augustus	\N	\N	\N	\N	\N	1	\N	\N	\N
2872	Edward	\N	\N	\N	\N	\N	1	\N	\N	\N
2873	Francis	\N	\N	\N	\N	\N	1	\N	\N	\N
2874	Adam	Duncan	\N	\N	\N	5	1	\N	\N	\N
2875	Francis Humberstone	MacKenzie	\N	\N	\N	14	1	\N	\N	\N
2876	James	Drummond	\N	\N	\N	5	1	\N	\N	\N
2877	Thomas	Lister	\N	\N	\N	13	1	\N	\N	\N
2878	Thomas	Powys	\N	\N	\N	17	1	\N	\N	\N
2879	James	Daly	\N	\N	\N	5	1	\N	\N	\N
2880	Dominick	Browne	\N	\N	\N	3	1	\N	\N	\N
2881	Margaret	Talbot	\N	\N	\N	21	2	\N	\N	\N
2882	Standish	O'Grady	\N	\N	\N	16	1	\N	\N	\N
2883	John	\N	\N	\N	\N	\N	1	\N	\N	\N
2884	Catherine	Fitzgerald	\N	\N	\N	7	2	\N	\N	\N
\.


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('people_id_seq', 2884, true);


--
-- Data for Name: rank_labels; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY rank_labels (id, label, rank_id, gender_id) FROM stdin;
3	Earl	6	1
4	Lord	8	1
5	Marquess	9	1
6	Viscount	12	1
8	Duke	4	1
10	Prince	11	1
1	Baroness	8	2
2	Countess	6	2
7	Viscountess	12	2
9	Duchess	4	2
11	Lady	14	2
\.


--
-- Name: rank_labels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('rank_labels_id_seq', 11, true);


--
-- Data for Name: ranks; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY ranks (degree, label, id, is_peerage_rank) FROM stdin;
3	Earldom	6	t
5	Barony	8	t
2	Marquessate	9	t
4	Viscountcy	12	t
1	Dukedom	4	t
0	Prince	11	f
5	Lordship	14	t
\.


--
-- Name: ranks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('ranks_id_seq', 14, true);


--
-- Data for Name: reigns; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY reigns (id, start_on, end_on, kingdom_id, monarch_id) FROM stdin;
1	1952-02-06	\N	5	1
2	1936-12-11	1952-02-06	5	2
3	1936-01-20	1936-12-11	5	3
4	1910-05-06	1936-01-20	5	4
5	1901-01-22	1910-05-06	5	5
6	1837-06-20	1901-01-22	5	6
7	1830-06-26	1837-06-20	5	7
8	1820-01-29	1830-06-26	5	8
9	1760-10-25	1801-01-01	4	9
10	1760-10-25	1801-01-01	3	9
11	1801-01-01	1820-01-29	5	9
12	1727-06-11	1760-10-25	4	10
13	1727-06-11	1760-10-25	3	10
14	1714-08-01	1727-06-11	4	11
15	1714-08-01	1727-06-11	3	11
16	1702-03-08	1707-05-01	1	12
17	1702-03-08	1707-05-01	2	12
18	1707-05-01	1714-08-01	4	12
19	1702-03-08	1714-08-01	3	12
\.


--
-- Name: reigns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('reigns_id_seq', 19, true);


--
-- Data for Name: special_remainders; Type: TABLE DATA; Schema: public; Owner: michaelsmethurst
--

COPY special_remainders (id, description) FROM stdin;
1	Peerages which may be inherited by a male indirect descendant of the first holder, for example: a brother or a male cousin.
2	Peerages which may be inherited by a female direct descendant.
3	Peerages with rules of limited inheritance, for example: the 1st Baroness Abercromby, whose peerage was limited to male descendants of her late husband.
5	Peerages with particular rules of inheritance set out in letters patent.
\.


--
-- Name: special_remainders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: michaelsmethurst
--

SELECT pg_catalog.setval('special_remainders_id_seq', 5, true);


--
-- Name: administrations_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY administrations
    ADD CONSTRAINT administrations_pkey PRIMARY KEY (id);


--
-- Name: announcement_types_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcement_types
    ADD CONSTRAINT announcement_types_pkey PRIMARY KEY (id);


--
-- Name: announcements_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements
    ADD CONSTRAINT announcements_pkey PRIMARY KEY (id);


--
-- Name: genders_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY genders
    ADD CONSTRAINT genders_pkey PRIMARY KEY (id);


--
-- Name: jurisdictions_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY jurisdictions
    ADD CONSTRAINT jurisdictions_pkey PRIMARY KEY (id);


--
-- Name: kingdom_ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT kingdom_ranks_pkey PRIMARY KEY (id);


--
-- Name: kingdoms_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdoms
    ADD CONSTRAINT kingdoms_pkey PRIMARY KEY (id);


--
-- Name: law_lord_incumbencies_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies
    ADD CONSTRAINT law_lord_incumbencies_pkey PRIMARY KEY (id);


--
-- Name: letters_patent_times_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patent_times
    ADD CONSTRAINT letters_patent_times_pkey PRIMARY KEY (id);


--
-- Name: letters_patents_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT letters_patents_pkey PRIMARY KEY (id);


--
-- Name: letters_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters
    ADD CONSTRAINT letters_pkey PRIMARY KEY (id);


--
-- Name: monarchs_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY monarchs
    ADD CONSTRAINT monarchs_pkey PRIMARY KEY (id);


--
-- Name: peerage_holdings_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT peerage_holdings_pkey PRIMARY KEY (id);


--
-- Name: peerage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_types
    ADD CONSTRAINT peerage_types_pkey PRIMARY KEY (id);


--
-- Name: peerages_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT peerages_pkey PRIMARY KEY (id);


--
-- Name: people_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: rank_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT rank_labels_pkey PRIMARY KEY (id);


--
-- Name: ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY ranks
    ADD CONSTRAINT ranks_pkey PRIMARY KEY (id);


--
-- Name: reigns_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns
    ADD CONSTRAINT reigns_pkey PRIMARY KEY (id);


--
-- Name: special_remainders_pkey; Type: CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY special_remainders
    ADD CONSTRAINT special_remainders_pkey PRIMARY KEY (id);


--
-- Name: announcement_type; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY announcements
    ADD CONSTRAINT announcement_type FOREIGN KEY (announcement_type_id) REFERENCES announcement_types(id);


--
-- Name: fk_announcement; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_announcement FOREIGN KEY (announcement_id) REFERENCES announcements(id);


--
-- Name: fk_gender; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT fk_gender FOREIGN KEY (gender_id) REFERENCES genders(id);


--
-- Name: fk_gender; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT fk_gender FOREIGN KEY (gender_id) REFERENCES genders(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT fk_kingdom FOREIGN KEY (kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_letter; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY people
    ADD CONSTRAINT fk_letter FOREIGN KEY (letter_id) REFERENCES letters(id);


--
-- Name: fk_letters_patent_time; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_letters_patent_time FOREIGN KEY (letters_patent_time_id) REFERENCES letters_patent_times(id);


--
-- Name: fk_monarch; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY reigns
    ADD CONSTRAINT fk_monarch FOREIGN KEY (monarch_id) REFERENCES monarchs(id);


--
-- Name: fk_peerage; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT fk_peerage FOREIGN KEY (peerage_id) REFERENCES peerages(id);


--
-- Name: fk_person; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerage_holdings
    ADD CONSTRAINT fk_person FOREIGN KEY (person_id) REFERENCES people(id);


--
-- Name: fk_person; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_person FOREIGN KEY (person_id) REFERENCES people(id);


--
-- Name: fk_previous_kingdom; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_previous_kingdom FOREIGN KEY (previous_kingdom_id) REFERENCES kingdoms(id);


--
-- Name: fk_rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY rank_labels
    ADD CONSTRAINT fk_rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: fk_rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY kingdom_ranks
    ADD CONSTRAINT fk_rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: fk_reign; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY letters_patents
    ADD CONSTRAINT fk_reign FOREIGN KEY (reign_id) REFERENCES reigns(id);


--
-- Name: peerage; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY law_lord_incumbencies
    ADD CONSTRAINT peerage FOREIGN KEY (peerage_id) REFERENCES peerages(id);


--
-- Name: peerage_type; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT peerage_type FOREIGN KEY (peerage_type_id) REFERENCES peerage_types(id);


--
-- Name: rank; Type: FK CONSTRAINT; Schema: public; Owner: michaelsmethurst
--

ALTER TABLE ONLY peerages
    ADD CONSTRAINT rank FOREIGN KEY (rank_id) REFERENCES ranks(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

